''---------------------------------------------------------------------------------------
'' Module: basLiveBackup
'' Author: David Davey
''---------------------------------------------------------------------------------------
'
'Option Compare Database
'Option Explicit
'
'Const strTableStore As String = "tblCaptures"
'
'' The following DET transactions are NOT (yet) logged. -- Move DET Sheet.  Delete DET Sheet.
'' The logs are stored in the following tables in the the MBO Database
'' During "live" data entry, the transactions are also logged to corresponding tables on an external drive (e.g. a USB flash drive)
'
'Public Const strLiveDatabaseFilenamePrefix = "MBOLiveBackup"
'Const strDETDailyLiveBackup = "tblDETDaily_Log"
'Const strDETSpeciesLiveBackup = "tblDETSpecies_Log"
'Const strDETNetHoursLiveBackup = "tblDETNetHours_Log"
'Const strBandsSheetLiveBackup = "tblSheetNewBands_Log"
'Const strRecapturesSheetLiveBackup = "tblSheetRecaptures_Log"
'Const strCapturesLiveBackup = "tblCaptures_Log"
'
'Const conColorBackground_cbo_Logging_ON = &HB4FFB4    ' RGB(180,255,180)
'Const conColorBackground_txt_Logging_ON = &H80FF80    ' RGB(128, 255, 128)
'Const conColorBackground_cbo_Logging_OFF = &HB4B4FF   ' RGB(255,180,180)
'Const conColorBackground_txt_Logging_OFF = &H8080FF   ' RGB(255, 128, 128)
'
'Private strTimestampBands As String      ' "hh\hmm\mss
'Private strTimestampRecaptures As String ' "hh\hmm\mss
'
'
''---------------------------------------------------------------------------------------
'' ValidateExternalLogging_IfFailReportAndTurnOff
''---------------------------------------------------------------------------------------
'' Called from chkDataEntrySource_AfterUpdate()
'' frmMainMenu.Open()
''
'' Call ValidateExternalLogging_IfFailReportAndTurnOff(chkDataEntrySource, txtMsgLogging)
'
'Public Sub ValidateExternalLogging_IfFailReportAndTurnOff(ByRef chkDataEntrySource As CheckBox, ByRef txtMsgLogging As TextBox)
'
'      Dim strExternalDataEntryLoggingDatabaseFolder As String
'
'10    On Error GoTo Err_label
'
'20     strExternalDataEntryLoggingDatabaseFolder = GetSettingEx("USBFlashDriveBackupFolder")
'
'       ' Verify that logging to an external USB Flash drive is possible
'
'       Dim strExternalLoggingError As String
'30     strExternalLoggingError = ""
'
'40     Call ValidateExternalLogging(strExternalLoggingError)
'
'50     If strExternalLoggingError <> "" Then
'60         chkDataEntrySource = False
'70         txtMsgLogging = "Data Entry Logging to an external drive is OFF"
'80         txtMsgLogging.BackColor = conColorBackground_txt_Logging_OFF
'90         Call PutDataEntrySource("FromSheets")
'100        MsgBox strExternalLoggingError & vbCrLf & vbCrLf & _
'                   "Logging to an external drive has been turned OFF", vbCritical + vbExclamation + vbOKOnly, "Logging to an external drive"
'110        GoTo Exit_label
'120    End If
'
'130    txtMsgLogging = "Data Entry is logging to " & strExternalDataEntryLoggingDatabaseFolder
'140    txtMsgLogging.BackColor = conColorBackground_txt_Logging_ON
'
'          'DD Error Handler Start
'Exit_label:
'150       Exit Sub
'Err_label:
'160       Select Case Err.Number
'          Case Else
'170            Call LogError("basLiveBackup", "ValidateExternalLogging_IfFailReportAndTurnOff")
'180       End Select
'190       Resume Exit_label
'          ' DD Error Handler End
'End Sub
'
''---------------------------------------------------------------------------------------
'' chkDataEntrySource_AfterUpdate
''---------------------------------------------------------------------------------------
'' Called from frmMainMenu.chkDataEntrySource_AfterUpdate
''             frmSheetNewBandsMultiSize_v2,AfterUpdate
''             frmSheetRecaps_v2.chkDataEntrySource_AfterUpdate
''             frmCapturesEditOrDelete.chkDataEntrySource_AfterUpdate
''             frmDataFields.chkDataEntrySource_AfterUpdate
'
'Public Sub chkDataEntrySource_AfterUpdate(ByRef chkDataEntrySource As CheckBox, ByRef txtMsgLogging As TextBox)
'
'10    On Error GoTo Err_label
'
'      Dim fDataEntrySource As Boolean
'      Dim strDataEntrySource As String
'      Dim strExternalDataEntryLoggingDatabaseFolder As String
'
'20    fDataEntrySource = Nz(chkDataEntrySource)
'
'30    strDataEntrySource = IIf(fDataEntrySource, "Live", "FromSheets")
'40    Call PutDataEntrySource(strDataEntrySource)
'
'50    If Not fDataEntrySource Then
'60        txtMsgLogging = "Data Entry Logging is OFF"
'70        txtMsgLogging.BackColor = conColorBackground_txt_Logging_OFF
'80    Else
'90        Call ValidateExternalLogging_IfFailReportAndTurnOff(chkDataEntrySource, txtMsgLogging)
'100   End If
'
'          'DD Error Handler Start
'Exit_label:
'110       Exit Sub
'Err_label:
'120       Select Case Err.Number
'          Case Else
'130      Call LogError("basLiveBackup", "chkDataEntrySource_AfterUpdate")
'140       End Select
'150       Resume Exit_label
'          ' DD Error Handler End
'End Sub
'
''---------------------------------------------------------------------------------------
'' FillInDataSourceControls
''---------------------------------------------------------------------------------------
'
'Public Sub FillInDataSourceControls(ByRef chkDataEntrySource As CheckBox, ByRef txtMsgLogging As TextBox)
'
'      Dim strDataEntrySource As String
'      Dim fDataEntrySource As Boolean
'      Dim strExternalDataEntryLoggingDatabaseFolder As String
'
'10    On Error GoTo Err_label
'
'20    strDataEntrySource = GetDataEntrySource()
'30    fDataEntrySource = (strDataEntrySource = "Live")
'40    chkDataEntrySource = fDataEntrySource
'
'50    If Not fDataEntrySource Then
'
'60        txtMsgLogging = "Data Entry Logging is OFF"
'70        txtMsgLogging.BackColor = conColorBackground_txt_Logging_OFF
'80    Else
'90        strExternalDataEntryLoggingDatabaseFolder = GetSettingEx("USBFlashDriveBackupFolder")    '  GetSettingEx("USBFlashDriveBackupFolder")
'100       txtMsgLogging = "Data Entry is logging to " & strExternalDataEntryLoggingDatabaseFolder
'110       txtMsgLogging.BackColor = conColorBackground_txt_Logging_ON
'120   End If
'
'
'          'DD Error Handler Start
'Exit_label:
'130       Exit Sub
'Err_label:
'140       Select Case Err.Number
'          Case Else
'150            Call LogError("basLiveBackup", "FillInDataSourceControls")
'160       End Select
'170       Resume Exit_label
'          ' DD Error Handler End
'
'End Sub
'
'
'

'
''---------------------------------------------------------------------------------------
'' PromptToDisableOneRecordAtATimeBackup
''
'' Called when the external Live Backup database cannot be found
'' Called when writing to the  external Live Backup database fails
''
'' Prompt the scribe Yes/No if they wish to disable one record at a time logging
'' This will apply to all logging to an external database on a USB flash drive
''---------------------------------------------------------------------------------------
''
'' Called from
'' GetExternalLiveDataEntryDatabase
'' Log_NewBandsSheet
'' Log_RecapturesSheet
'' Log_Captures
'' Log_DETDaily
'' Log_DETSpecies
'' Log DETNetHours
'
'Private Sub PromptToDisableOneRecordAtATimeBackup()
'
'10    On Error GoTo Err_label
'
'20    If vbOK = MsgBox("Do you wish to disable live logging to a USB flash drive", vbYesNo, "Live Backup") Then
'30        PutDisableOneRecordAtATimeLiveBackupDET (True)
'40        PutDisableOneRecordAtATimeLiveBackupCaptures (True)
'50    End If
'
'          'DD Error Handler Start
'Exit_label:
'60        Exit Sub
'Err_label:
'70        Select Case Err.Number
'          Case Else
'80             Call LogError("basLiveBackup", "PromptToDisableOneRecordAtATimeBackupDET")
'90        End Select
'100       Resume Exit_label
'          ' DD Error Handler End
'End Sub
'
''--------------------------------------------------------------------------------------------------------
'' Log_NewBandsSheet
''
'' Logs a single Bands Sheet Daily Add, Update and Delete transaction
'' The caller must fill in all the data fields, Command, Source
'' Transactions are logged to a local table - strBandsSheetLiveBackup
'' During "live" data entry, the transactions are also logged to corresponding table on an external drive
''--------------------------------------------------------------------------------------------------------
'' Dim rec As SheetNewBandsType
'' Call Log_NewBandsSheet(rec)
'' Called From
'' Form_frmDataFields.Form_AfterUpdate
'' Form_frmSheetNewBandsMultiSize_v2.Form_Delete
'' Form_frmSheetNewBandsMultiSize_v2.cmdClearAll_Click
'' Form_frmSheetNewBandsMultiSize_v2.NewBands_Store_v2
'' basSheetNewBands_v2.Form_AfterUpdate_v2
'''--------------------------------------------------------------------------------------------------------
'' Copies all the fields from rec to tblSheetNewBands_Log
'
'Public Sub Log_NewBandsSheet(ByRef rec As SheetNewBandsType)
'
'      Dim rst As DAO.Recordset
'      Dim db As DAO.Database
'
'      Dim strDataEntrySource As String
'      Dim i As Integer
'
'10    On Error GoTo Err_label
'
'      '  Copies all the fields from rec to tblSheetNewBands_Log
'
'20    Set rst = CurrentDb.OpenRecordset(strBandsSheetLiveBackup)
'30    rst.AddNew
'40    rst("BandID") = rec.BandID
'50    rst("BandSizeID") = rec.BandSizeID
'60    rst("BandPrefix") = rec.BandPrefix
'70    rst("BandSuffix") = rec.BandSuffix
'80    rst("Species") = rec.Species
'90    rst("Age") = rec.Age
'100   rst("HowAged") = rec.HowAged
'110   rst("Sex") = rec.Sex
'120   rst("HowSexed") = rec.HowSexed
'130   rst("WingChord") = rec.WingChord
'140   rst("Fat") = rec.Fat
'150   rst("Weight") = rec.Weight
'160   rst("CaptureDate") = rec.CaptureDate
'170   rst("WeightTime") = rec.WeightTime
'180   rst("Bander") = rec.Bander
'190   rst("Net") = rec.Net
'200   rst("ProbableAge") = rec.ProbableAge
'210   rst("ProbableSex") = rec.ProbableSex
'220   rst("Scribe") = rec.Scribe
'230   rst("NotesForMBO") = rec.NotesForMBO
'240   rst("Valid") = rec.Valid
'250   rst("Invalid") = rec.Invalid
'260   rst("Duplicate") = rec.Duplicate
'270   rst("BypassErrors") = rec.BypassErrors
'280   rst("CaptureYear") = rec.CaptureYear
'290   rst("Disposition") = rec.Disposition
'300   rst("Location") = rec.Location
'310   rst("BirdStatus") = rec.BirdStatus
'320   rst("Program") = rec.Program
'330   rst("AutoHistory") = rec.AutoHistory
'340   rst("FCombined") = rec.FCombined
'350   For i = 1 To conMaxUserField
'360       rst("F" & i) = rec.F(i)
'370   Next
'380   rst("Flags") = rec.Flags
'390   For i = 1 To conMaxDataField
'400       rst("D" & i) = rec.d(i)
'410   Next i
'
'420   rst("Command") = rec.Command
'430   rst("Source") = rec.Source
'
'440   rst.Update
'450   rst.Close
'460   Set rst = Nothing
'
'      ' Log to the external strBandsSheetLiveBackup in the external live backup database
'
'470   strDataEntrySource = GetDataEntrySource()       ' "Live" or "From Sheets"
'480   If strDataEntrySource <> "Live" Or DisableOneRecordAtATimeLiveBackupCaptures() Then GoTo Exit_label
'
'490   Set db = GetExternalLiveDataEntryDatabase()
'495   If db Is Nothing Then GoTo Exit_label
'
'500   On Error GoTo Err_live_label
'
'510   Set rst = db.OpenRecordset(strBandsSheetLiveBackup)
'520   rst.AddNew
'530   rst("BandID") = rec.BandID
'540   rst("BandSizeID") = rec.BandSizeID
'550   rst("BandPrefix") = rec.BandPrefix
'560   rst("BandSuffix") = rec.BandSuffix
'570   rst("Species") = rec.Species
'580   rst("Age") = rec.Age
'590   rst("HowAged") = rec.HowAged
'600   rst("Sex") = rec.Sex
'610   rst("HowSexed") = rec.HowSexed
'620   rst("WingChord") = rec.WingChord
'630   rst("Fat") = rec.Fat
'640   rst("Weight") = rec.Weight
'650   rst("CaptureDate") = rec.CaptureDate
'660   rst("WeightTime") = rec.WeightTime
'670   rst("Bander") = rec.Bander
'680   rst("Net") = rec.Net
'690   rst("ProbableAge") = rec.ProbableAge
'700   rst("ProbableSex") = rec.ProbableSex
'710   rst("Scribe") = rec.Scribe
'720   rst("NotesForMBO") = rec.NotesForMBO
'730   rst("Valid") = rec.Valid
'740   rst("Invalid") = rec.Invalid
'750   rst("Duplicate") = rec.Duplicate
'760   rst("BypassErrors") = rec.BypassErrors
'770   rst("CaptureYear") = rec.CaptureYear
'780   rst("Disposition") = rec.Disposition
'790   rst("Location") = rec.Location
'800   rst("BirdStatus") = rec.BirdStatus
'810   rst("Program") = rec.Program
'820   rst("AutoHistory") = rec.AutoHistory
'830   rst("FCombined") = rec.FCombined
'840   For i = 1 To conMaxUserField
'850       rst("F" & i) = rec.F(i)
'860   Next
'870   rst("Flags") = rec.Flags
'880   For i = 1 To conMaxDataField
'890       rst("D" & i) = rec.d(i)
'900   Next i
'
'910   rst("Command") = rec.Command
'920   rst("Source") = rec.Source
'930   rst.Update
'940   rst.Close
'950   Set rst = Nothing
'
'
'960   If IsLoaded("frmSheetNewBandsMultiSize_v2") Then
'970   On Error Resume Next
'980       Forms("frmSheetNewBandsMultiSize_v2").Controls("txtCountLiveBackupDatabaseTransactions") = Forms("frmSheetNewBandsMultiSize_v2").Controls("txtCountLiveBackupDatabaseTransactions") + 1
'990   On Error GoTo Err_label
'1000  End If
'
'1010  db.Close
'
'1020  Set db = Nothing
'
'          'DD Error Handler Start
'Exit_label:
'1030      Exit Sub
'Err_label:
'1040      Select Case Err.Number
'          Case Else
'1050     Call LogError("basLiveBackup", "Log_NewBandsSheet")
'1060      End Select
'1070      Resume Exit_label
'          ' DD Error Handler End
'
'Err_live_label:
'1080      Select Case Err.Number
'          Case Else
'1090     Call LogError("basLiveBackup", "Log_NewBandsSheet", Silent:=True)
'1100     MsgBox "Failed to write to the Live Data Entry database on a USB flash drive" & vbCrLf & vbCrLf & _
'            CStr(Err.Number) & " " & Err.Description, vbOK + vbCritical, "Live Backup"
'1110     Call PromptToDisableOneRecordAtATimeBackup
'1120      End Select
'1130      Resume Exit_label
'
'End Sub
'
''--------------------------------------------------------------------------------------------------------
'' Log_RecapturesSheet
''
'' Logs a single recaptures Sheet Daily Add, Update and Delete transaction
'' The caller must fill in all the data fields, Command, Source
'' Transactions are logged to a local table - tblSheetRecaptures_Log
'' During "live" data entry, the transactions are also logged to corresponding table on an external drive
''--------------------------------------------------------------------------------------------------------
'' Copies all the fields from rec to tblSheetNewBands_Log
'
'Public Sub Log_RecapturesSheet(ByRef rec As SheetRecapturesType)
'
'      Dim rst As DAO.Recordset
'      Dim db As DAO.Database
'
'      Dim strDataEntrySource As String
'      Dim i As Integer
'
'10    On Error GoTo Err_label
'
'      ' Log to the local tblSheetRecaptures_Log
'
'20    Set rst = CurrentDb.OpenRecordset(strRecapturesSheetLiveBackup)
'30    rst.AddNew
'40    rst("BandID") = rec.BandID
'50    rst("BandPrefix") = rec.BandPrefix
'60    rst("BandSuffix") = rec.BandSuffix
'70    rst("Species") = rec.Species
'80    rst("WingChord") = rec.WingChord
'90    rst("Age") = rec.Age
'100   rst("HowAged") = rec.HowAged
'110   rst("Sex") = rec.Sex
'120   rst("HowSexed") = rec.HowSexed
'130   rst("Fat") = rec.Fat
'140   rst("Weight") = rec.Weight
'150   rst("CaptureDate") = rec.CaptureDate
'160   rst("WeightTime") = rec.WeightTime
'170   rst("Bander") = rec.Bander
'180   rst("Scribe") = rec.Scribe
'190   rst("Net") = rec.Net
'200   rst("NotesForMBO") = rec.NotesForMBO
'210   rst("Valid") = rec.Valid
'220   rst("Invalid") = rec.Invalid
'230   rst("Duplicate") = rec.Duplicate
'240   rst("BypassErrors") = rec.BypassErrors
'250   rst("ProbableAge") = rec.ProbableAge
'260   rst("ProbableSex") = rec.ProbableSex
'270   rst("CaptureYear") = rec.CaptureYear
'280   rst("Disposition") = rec.Disposition
'290   rst("Location") = rec.Location
'300   rst("BirdStatus") = rec.BirdStatus
'310   rst("HowObtainedCode") = rec.HowObtainedCode
'320   rst("PresentCondition") = rec.PresentCondition
'330   rst("Program") = rec.Program
'340   rst("AutoHistory") = rec.AutoHistory
'350   rst("FCombined") = rec.FCombined
'360   For i = 1 To conMaxUserField
'370       rst("F" & i) = rec.F(i)
'380   Next
'390   rst("Flags") = rec.Flags
'400   For i = 1 To conMaxDataField
'410       rst("D" & i) = rec.d(i)
'420   Next i
'
'430   rst("Command") = rec.Command
'440   rst("Source") = rec.Source
'
'450   rst.Update
'460   rst.Close
'470   Set rst = Nothing
'
'      ' Log to the external strBandsSheetLiveBackup table in the live backup database
'
'480   strDataEntrySource = GetDataEntrySource()
'490   If strDataEntrySource <> "Live" Or GetDisableOneRecordAtATimeLiveBackupCaptures() Then GoTo Exit_label
'
'500   Set db = GetExternalLiveDataEntryDatabase()
'510   If db Is Nothing Then GoTo Exit_label
'
'520   On Error GoTo Err_live_label
'
'530   Set rst = db.OpenRecordset(strRecapturesSheetLiveBackup)
'540   rst.AddNew
'550   rst("BandID") = rec.BandID
'560   rst("BandPrefix") = rec.BandPrefix
'570   rst("BandSuffix") = rec.BandSuffix
'580   rst("Species") = rec.Species
'590   rst("WingChord") = rec.WingChord
'600   rst("Age") = rec.Age
'610   rst("HowAged") = rec.HowAged
'620   rst("Sex") = rec.Sex
'630   rst("HowSexed") = rec.HowSexed
'640   rst("Fat") = rec.Fat
'650   rst("Weight") = rec.Weight
'660   rst("CaptureDate") = rec.CaptureDate
'670   rst("WeightTime") = rec.WeightTime
'680   rst("Bander") = rec.Bander
'690   rst("Scribe") = rec.Scribe
'700   rst("Net") = rec.Net
'710   rst("NotesForMBO") = rec.NotesForMBO
'720   rst("Valid") = rec.Valid
'730   rst("Invalid") = rec.Invalid
'740   rst("Duplicate") = rec.Duplicate
'750   rst("BypassErrors") = rec.BypassErrors
'760   rst("ProbableAge") = rec.ProbableAge
'770   rst("ProbableSex") = rec.ProbableSex
'780   rst("CaptureYear") = rec.CaptureYear
'790   rst("Disposition") = rec.Disposition
'800   rst("Location") = rec.Location
'810   rst("BirdStatus") = rec.BirdStatus
'820   rst("HowObtainedCode") = rec.HowObtainedCode
'830   rst("PresentCondition") = rec.PresentCondition
'840   rst("Program") = rec.Program
'850   rst("AutoHistory") = rec.AutoHistory
'860   rst("FCombined") = rec.FCombined
'870   For i = 1 To conMaxUserField
'880       rst("F" & i) = rec.F(i)
'890   Next
'900   rst("Flags") = rec.Flags
'910   For i = 1 To conMaxDataField
'920       rst("D" & i) = rec.d(i)
'930   Next i
'
'940   rst("Command") = rec.Command
'950   rst("Source") = rec.Source
'960   rst.Update
'970   rst.Close
'980   Set rst = Nothing
'
'990   If IsLoaded("frmSheetRecaps_v2") Then
'1000  On Error Resume Next
'1010      Forms("frmSheetRecaps_v2").Controls("txtCountLiveBackupDatabaseTransactions") = Forms("frmSheetRecaps_v2").Controls("txtCountLiveBackupDatabaseTransactions") + 1
'1020  On Error GoTo Err_label
'1030  End If
'
'1040  db.Close
'1050  Set db = Nothing
'
'          'DD Error Handler Start
'Exit_label:
'1060      Exit Sub
'Err_label:
'1070      Select Case Err.Number
'          Case Else
'1080          Call LogError("basLiveBackup", "Log_RecapturesSheet")
'1090      End Select
'1100      Resume Exit_label
'          ' DD Error Handler End
'
'Err_live_label:
'1110      Select Case Err.Number
'          Case Else
'1120          Call LogError("basLiveBackup", "Log_RecapturesSheet", Silent:=True)
'1130          MsgBox "Failed to write to the Live Data Entry database on a USB flash drive" & vbCrLf & vbCrLf & _
'              CStr(Err.Number) & " " & Err.Description, vbOK + vbCritical, "Live Backup"
'1140          Call PromptToDisableOneRecordAtATimeBackup
'1150      End Select
'1160      Resume Exit_label
'
'End Sub
'
''---------------------------------------------------------------------------------------
'' Log_Captures
''---------------------------------------------------------------------------------------
'
'Public Sub Log_Captures(ByRef B As CapturesType)
'
'Dim rstCapturesLog As DAO.Recordset
'Dim uf As Integer
'Dim df As Integer
'
'' Log to the local tblCaptures_Log
'
'10     On Error GoTo Err_label
'
'20    Set rstCapturesLog = CurrentDb.OpenRecordset(strCapturesLiveBackup, dbOpenDynaset)
'
'30    rstCapturesLog.AddNew
'
'40    rstCapturesLog("IDBand") = B.IDBand
'50    rstCapturesLog("Disposition") = B.Disposition
'60    rstCapturesLog("BandPrefix") = B.BandPrefix
'70    rstCapturesLog("BandSuffix") = B.BandSuffix
'80    rstCapturesLog("Species") = B.Species
'90    rstCapturesLog("WingChord") = B.WingChord
'100   rstCapturesLog("Age") = B.Age
'110   rstCapturesLog("HowAged") = B.HowAged
'120   rstCapturesLog("Sex") = B.Sex
'130   rstCapturesLog("HowSexed") = B.HowSexed
'140   rstCapturesLog("Fat") = B.Fat
'150   rstCapturesLog("Weight") = B.Weight
'160   rstCapturesLog("CaptureDate") = B.CaptureDate
'170   rstCapturesLog("WeightTime") = B.WeightTime
'180   rstCapturesLog("Bander") = B.Bander
'190   rstCapturesLog("Scribe") = B.Scribe
'200   rstCapturesLog("Net") = B.Net
'210   rstCapturesLog("NotesForMBO") = B.NotesForMBO
'
'220   rstCapturesLog("ToBeExported") = B.ToBeExported
'230   rstCapturesLog("Valid") = B.Valid
'240   rstCapturesLog("Invalid") = B.Invalid
'250   rstCapturesLog("BypassErrors") = B.BypassErrors
'260   rstCapturesLog("AutoHistory") = B.AutoHistory
'
'270   rstCapturesLog("ProbableAge") = B.ProbableAge
'280   rstCapturesLog("ProbableSex") = B.ProbableSex
'290   rstCapturesLog("Location") = B.Location
'300   rstCapturesLog("BirdStatus") = B.BirdStatus
'310   rstCapturesLog("PresentCondition") = B.PresentCondition
'320   rstCapturesLog("HowObtainedCode") = B.HowObtainedCode
'330   rstCapturesLog("FCombined") = B.FCombined
'340   rstCapturesLog("Program") = B.Program
'
'350   For uf = 1 To conMaxUserField
'360       rstCapturesLog("F" & uf) = B.F(uf)
'370   Next uf
'
'380   rstCapturesLog("Flags") = B.Flags
'
'390   For df = 1 To conMaxDataField
'400       rstCapturesLog("D" & df) = B.d(df)
'410   Next df
'
'420   rstCapturesLog("Command") = B.Command
'430   rstCapturesLog("Source") = B.Source
'440   rstCapturesLog("Timestamp") = Now
'
'450   rstCapturesLog.Update
'
'Dim strLog As String
'
'460   strLog = "tblCaptures #1: " & _
'        " Command=" & B.Command & ", Source=" & B.Source & _
'        ", Disposition=" & B.Disposition & ", Band=" & B.BandPrefix & "-" & B.BandSuffix & ", Species=" & B.Species & _
'        ", CaptureDate=" & B.CaptureDate & _
'        ", WeightTime=" & B.WeightTime & _
'        ", Net=" & B.Net & _
'        ", ToBeExported=" & B.ToBeExported & ", Valid=" & B.Valid & ", Invalid=" & B.Invalid
'470   log (strLog)
'480   strLog = "tblCaptures #2: " & _
'        " BypassErrors=" & B.BypassErrors & ", AutoHistory=" & B.AutoHistory & _
'        ", Location=" & B.Location & _
'        ", D18 (DET Category)=" & B.d(18) & _
'        ", D20 (Days since most recent prior capture)=" & B.d(20) & ", D21 (DET Date)=" & B.d(21) & ", D22 (Original Capture date)=" & B.d(22)
'490   log (strLog)
'500   strLog = "tblCaptures #3: " & _
'        " WingChord=" & B.WingChord & ", Age=" & B.Age & ", HowAged=" & B.HowAged & ", Sex=" & B.Sex & _
'        ", HowSexed=" & B.HowSexed & ", Fat=" & B.Fat & ", Weight=" & B.Weight & _
'        ", Bander=" & B.Bander & ", Scribe=" & B.Scribe & _
'        ", NotesForMBO=" & B.NotesForMBO & ", ToBeExported=" & B.ToBeExported & ", Valid=" & B.Valid & ", Invalid=" & B.Invalid
'510   log (strLog)
'520   strLog = "tblCaptures #4: " & _
'        " BypassErrors=" & B.BypassErrors & ", AutoHistory=" & B.AutoHistory & ", ProbableAge=" & B.ProbableAge & ", ProbableSex=" & B.ProbableSex & _
'        ", BirdStatus=" & B.BirdStatus & ", PresentCondition=" & B.PresentCondition & ", HowObtainedCode=" & B.HowObtainedCode
'530   log (strLog)
'540   strLog = "tblCaptures #5: " & _
'        " FCombined=" & B.FCombined & ", Program=" & B.Program & ", F1(Tail Lenght in mm)=" & B.F(1) & ", F2 (R2)=" & B.F(2) & _
'        ", F3 (Eye Colour)=" & B.F(3) & ", F4 (R4)=" & B.F(4) & ", F5 (R5)=" & B.F(5) & ", F6 (R6)=" & B.F(6)
'550   log (strLog)
'560   strLog = "tblCaptures #6: " & _
'        " F7 (Mouth Lining)=" & B.F(7) & ", F8 (Uppertail Covets)=" & B.F(8) & ", F9 (Skull) =" & B.F(9) & ", F10 (Spot length in mm)=" & B.F(10) & _
'        ", F11 (Tail Colour)=" & B.F(11) & ", F12 (Spot Colour)=" & B.F(12) & ", F13 (Spot Designation)=" & B.F(13) & ", F14 (Covet Edging)=" & B.F(14)
'570   log (strLog)
'580   strLog = "tblCaptures #7: " & _
'        " F15 (Tip R6 to brown flare)=" & B.F(15) & ", F16 (Orange Tips)=" & B.F(16) & ", F17 (Alula bars)=" & B.F(17) & ", F18 (Tarsus)=" & B.F(18) & ", F19 (Hummingbird band size)=" & B.F(19)
'590   log (strLog)
'600   strLog = "tblCaptures #8: " & _
'        " D1 (Replacement Band Number for Disposition 5 captures)=" & B.d(1) & ", D2 (DET Category Override)=" & B.d(2)
'610   log (strLog)
'620   strLog = "tblCaptures #9: " & _
'        " D3 (Aux Marker Type)=" & B.d(3) & ", D4 (Is Aux Marker Coded?)=" & B.d(4) & ", D5 (Aux Marker Code)=" & B.d(5) & ", D6 (Aux Marker Band Color)=" & B.d(6) & _
'        ", D7 (Aux Marker Code Color)=" & B.d(7) & ", D8 (Left Leg Color 1)=" & B.d(8)
'630   log (strLog)
'640   strLog = "tblCaptures #10: " & _
'        " D9 (xx)=" & B.d(9) & ", D10 (xx)=" & B.d(10) & _
'        ", D11 (R Leg Color 1)=" & B.d(11) & ", D12 (R Leg Color 2)=" & B.d(12) & ", D13 (R Leg Color 3)=" & B.d(13) & ", D14 (Last Bandit Export Timestamp)=" & B.d(14)
'650   log (strLog)
'660   strLog = "tblCaptures #11: " & _
'        " D15 (Count Bandit Exports)=" & B.d(15) & ", D16 (Creation Timestamp)=" & B.d(16) & ", D17(Modify Timestamp)=" & B.d(17) & _
'        ", D19 (To Be Deleted)=" & B.d(19) & B.d(21)
'670   log (strLog)
'
'' Log to the external strBandsSheetLiveBackup
'
'Dim strDataEntrySource As String
'Dim db As DAO.Database
'
'680   strDataEntrySource = GetDataEntrySource()
'690   If strDataEntrySource <> "Live" Or GetDisableOneRecordAtATimeLiveBackupDET() Then GoTo Exit_label
'
'700   Set db = GetExternalLiveDataEntryDatabase()
'710   If db Is Nothing Then GoTo Exit_label
'
'720   On Error GoTo Err_live_label
'
'730   Set rstCapturesLog = db.OpenRecordset(strCapturesLiveBackup, dbOpenDynaset)
'740   rstCapturesLog.AddNew
'750   rstCapturesLog("IDBand") = B.IDBand
'760   rstCapturesLog("Disposition") = B.Disposition
'770   rstCapturesLog("BandPrefix") = B.BandPrefix
'780   rstCapturesLog("BandSuffix") = B.BandSuffix
'790   rstCapturesLog("Species") = B.Species
'800   rstCapturesLog("WingChord") = B.WingChord
'810   rstCapturesLog("Age") = B.Age
'820   rstCapturesLog("HowAged") = B.HowAged
'830   rstCapturesLog("Sex") = B.Sex
'840   rstCapturesLog("HowSexed") = B.HowSexed
'850   rstCapturesLog("Fat") = B.Fat
'860   rstCapturesLog("Weight") = B.Weight
'870   rstCapturesLog("CaptureDate") = B.CaptureDate
'880   rstCapturesLog("WeightTime") = B.WeightTime
'890   rstCapturesLog("Bander") = B.Bander
'900   rstCapturesLog("Scribe") = B.Scribe
'910   rstCapturesLog("Net") = B.Net
'920   rstCapturesLog("NotesForMBO") = B.NotesForMBO
'
'930   rstCapturesLog("ToBeExported") = B.ToBeExported
'940   rstCapturesLog("Valid") = B.Valid
'950   rstCapturesLog("Invalid") = B.Invalid
'960   rstCapturesLog("BypassErrors") = B.BypassErrors
'970   rstCapturesLog("AutoHistory") = B.AutoHistory
'
'980   rstCapturesLog("ProbableAge") = B.ProbableAge
'990   rstCapturesLog("ProbableSex") = B.ProbableSex
'1000  rstCapturesLog("Location") = B.Location
'1010  rstCapturesLog("BirdStatus") = B.BirdStatus
'1020  rstCapturesLog("PresentCondition") = B.PresentCondition
'1030  rstCapturesLog("HowObtainedCode") = B.HowObtainedCode
'1040  rstCapturesLog("FCombined") = B.FCombined
'1050  rstCapturesLog("Program") = B.Program
'
'1060  For uf = 1 To conMaxUserField
'1070      rstCapturesLog("F" & uf) = B.F(uf)
'1080  Next uf
'
'1090  rstCapturesLog("Flags") = B.Flags
'
'1100  For df = 1 To conMaxDataField
'1110      rstCapturesLog("D" & df) = B.d(df)
'1120  Next df
'
'1130  rstCapturesLog("Command") = B.Command
'1140  rstCapturesLog("Source") = B.Source
'1150  rstCapturesLog("Timestamp") = Now
'1160  rstCapturesLog.Update
'1170  rstCapturesLog.Close
'1180  Set rstCapturesLog = Nothing
'
''If IsLoaded("frmSheetRecaps_v2") Then
''On Error Resume Next
''    Forms("frmSheetRecaps_v2").Controls("txtCountLiveBackupDatabaseTransactions") = Forms("frmSheetRecaps_v2").Controls("txtCountLiveBackupDatabaseTransactions") + 1
''On Error GoTo Err_label
''End If
'
'1190  db.Close
'1200  Set db = Nothing
'
'    'DD Error Handler Start
'Exit_label:
'1210      Exit Sub
'Err_label:
'1220      Select Case Err.Number
'    Case Else
'1230     Call LogError("basLiveBackup", "Log_Captures")
'1240      End Select
'1250      Resume Exit_label
'    ' DD Error Handler End
'
'
'Err_live_label:
'1260      Select Case Err.Number
'    Case Else
'1270    Call LogError("basLiveBackup", "Log_Captures", Silent:=False)
'1280    MsgBox "Failed to write to the Live Data Entry database on a USB flash drive" & vbCrLf & vbCrLf & _
'      CStr(Err.Number) & " " & Err.Description, vbOK + vbCritical, "Live Backup"
'1290    Call PromptToDisableOneRecordAtATimeBackup
'1300      End Select
'1310      Resume Exit_label
'
'End Sub
'
'
'
''--------------------------------------------------------------------------------------------------------
'' Log_DETDaily
''
'' Logs a single DET Daily Add, Update and Delete transaction
'' The caller must fill in all the data fields, Command, and Source. This procedure fills in the Timestamp
'' Transactions are logged to a local table - strDETDailyLiveBackup
'' During "live" data entry, the transactions are also logged to corresponding table on an external drive
'
'
''Public Type DETDailyType
''    Program          As String
''    Location         As String
''    DateEx           As Date
''    Observers        As Variant     ' Observer effort
''    SongbirdNets     As Variant
''    NonSongbirdNets  As Variant
''    JTrap            As Variant
''    OtherTrap        As Variant     ' Hummingbird effort
''    Heliogoland      As Variant
''    VisibleMigration As Variant
''    CoverageCode     As Variant
''    Timestamp        As Date
''    Command          As String
''    Source           As String
''End Type
'
'
''--------------------------------------------------------------------------------------------------------
'
''---------------------------------------------------------------------------------------
'' Log_DETDaily
''---------------------------------------------------------------------------------------
'
'Public Sub Log_DETDaily(ByRef rec As DETDailyType)
'
'Dim rst As DAO.Recordset
'Dim db As DAO.Database
'Dim datTimestamp As Date
'Dim strDataEntrySource As String
'
'20    On Error GoTo Err_label
'
'30    datTimestamp = Now()
'
'' Log to the local tblDETDaily_Log
'
'40    Set rst = CurrentDb.OpenRecordset(strDETDailyLiveBackup)
'50    rst.AddNew
'60    rst("Program") = rec.Program
'70    rst("Location") = rec.Location
'80    rst("DateEx") = rec.DateEx
'90    rst("Observers") = rec.Observers
'100   rst("SongbirdNets") = rec.SongbirdNets
'110   rst("NonSongbirdNets") = rec.NonSongbirdNets
'120   rst("JTrap") = rec.JTrap
'130   rst("OtherTrap") = rec.OtherTrap
'140   rst("Heliogoland") = rec.Heliogoland
'150   rst("VisibleMigration") = rec.VisibleMigration
'160   rst("CoverageCode") = rec.CoverageCode
'170   rst("Timestamp") = datTimestamp
'180   rst("Command") = rec.Command
'190   rst("Source") = rec.Source
'200   rst.Update
'210   rst.Close
'220   Set rst = Nothing
'
'Dim strLog As String
'
'230   strLog = "tblDETDaily: Command=" & rec.Command & ", Source=" & rec.Source & ", Program=" & rec.Program & ", Location=" & rec.Location & _
'        ", DETDate=" & rec.DateEx & ", Observers=" & rec.Observers & ", SongbirdNets=" & rec.SongbirdNets & ", OtherTrap(Hummingbird)=" & rec.OtherTrap & _
'        ", CoverageCode=" & rec.CoverageCode
'240   log (strLog)
'
'' Log to the external tblDETDaily_Log
'
'250   strDataEntrySource = GetDataEntrySource()
'260   If strDataEntrySource <> "Live" Or GetDisableOneRecordAtATimeLiveBackupDET() Then GoTo Exit_label
'
'270   Set db = GetExternalLiveDataEntryDatabase()
'280   If db Is Nothing Then GoTo Exit_label
'
'290   On Error GoTo Err_live_label
'
'300   Set rst = db.OpenRecordset(strDETDailyLiveBackup)
'310   rst.AddNew
'320   rst("Program") = rec.Program
'330   rst("Location") = rec.Location
'340   rst("DateEx") = rec.DateEx
'350   rst("Observers") = rec.Observers
'360   rst("SongbirdNets") = rec.SongbirdNets
'370   rst("NonSongbirdNets") = rec.NonSongbirdNets
'380   rst("JTrap") = rec.JTrap
'390   rst("OtherTrap") = rec.OtherTrap
'400   rst("Heliogoland") = rec.Heliogoland
'410   rst("VisibleMigration") = rec.VisibleMigration
'420   rst("CoverageCode") = rec.CoverageCode
'430   rst("Timestamp") = datTimestamp
'440   rst("Command") = rec.Command
'450   rst("Source") = rec.Source
'460   rst.Update
'470   rst.Close
'480   Set rst = Nothing
'
'
'490   db.Close
'
'500   Set db = Nothing
'
'
'
'
'Err_live_label:
'560       Select Case Err.Number
'    Case Else
'570      Call LogError("basLiveBackup", "Log_DETSpecies", Silent:=True)
'580      MsgBox "Failed to connect to the Live Data Entry database a USB flash drive" & vbCrLf & vbCrLf & _
'            "Please use the Summary command button to save the whole DET sheet to a USB flash drive" & vbCrLf & vbCrLf & _
'            CStr(Err.Number) & " " & Err.Description, vbOK + vbCritical, "Live Backup"
'590      Call PromptToDisableOneRecordAtATimeBackup
'600       End Select
'610       Resume Exit_label
'
'    'DD Error Handler Start
'Exit_label:
'620       Exit Sub
'Err_label:
'630       Select Case Err.Number
'    Case Else
'640      Call LogError("basLiveBackup", "Log_DETDaily")
'650       End Select
'660       Resume Exit_label
'    ' DD Error Handler End
'
'End Sub
'
''---------------------------------------------------------------------------------------
'' Log_DETSpecies
''---------------------------------------------------------------------------------------
'' Logs a single DET Species Add, Update and Delete ALL transaction.
'' The caller must fill in all the data fields, Command, and Source. This procedure fills in the Timestamp
'' Transactions are logged to a local table - strDETDailyLiveBackup
'' During "live" data entry, the transactions are also logged to corresponding table on an external drive
'
'Public Sub Log_DETSpecies(ByRef rec As DETSpeciesType)
'
'Dim rst As DAO.Recordset
'Dim db As DAO.Database
'Dim datTimestamp As Date
'Dim strDataEntrySource As String
'
'10    On Error GoTo Err_label
'
'20    datTimestamp = Now()
'
'' Log to the local tblDETSpecies_log
'
'30    Set rst = CurrentDb.OpenRecordset(strDETSpeciesLiveBackup)
'40    rst.AddNew
'50    rst("Program") = rec.Program
'60    rst("Location") = rec.Location
'70    rst("DateEx") = rec.DateEx
'80    rst("Species") = rec.Species
'90    rst("Observed") = rec.Observed
'100   rst("Census") = rec.Census
'110   rst("Banded") = rec.Banded
'120   rst("Repeats") = rec.Repeats
'130   rst("Returns") = rec.Returns
'140   rst("PKS") = rec.PKS
'150   rst("DET") = rec.DET
'160   rst("VisibleEx") = rec.VisibleEx
'170   rst("Casual") = rec.Casual
'180   rst("Observed3") = rec.Observed3
'190   rst("Observed4") = rec.Observed4
'200   rst("NonStandardBanded") = rec.NonStandardBanded
'210   rst("NonStandardRecaps") = rec.NonStandardRecaps
'220   rst("DailySpeciesTotal") = rec.DailySpeciesTotal
'230   rst("Timestamp") = datTimestamp
'240   rst("Command") = rec.Command
'250   rst("Source") = rec.Source
'260   rst.Update
'270   rst.Close
'280   Set rst = Nothing
'
'Dim strLog As String
'
'290   strLog = "tblDETSpecies: Command=" & rec.Command & ", Source=" & rec.Source & ", Program=" & rec.Program & ", Location=" & rec.Location & _
'        ", DETDate=" & rec.DateEx & ", Observed=" & rec.Observed & ", Census=" & rec.Census & ", Banded=" & rec.Banded & _
'        ", Repeats=" & rec.Repeats & ", Returns=" & rec.Returns & ", DET=" & rec.DET & ", Observed3(Alien)=" & rec.Observed3 & _
'        ", Observed4(Replacement)=" & rec.Observed4
'300   log (strLog)
'
'' Log to the external tblDETSpecies_Log
'
'310   strDataEntrySource = GetDataEntrySource()
'320   If strDataEntrySource <> "Live" Or GetDisableOneRecordAtATimeLiveBackupDET() Then GoTo Exit_label
'
'330   Set db = GetExternalLiveDataEntryDatabase()
'340   If db Is Nothing Then GoTo Exit_label
'
'350   On Error GoTo Err_live_label
'
'360   Set rst = db.OpenRecordset(strDETSpeciesLiveBackup)
'370   rst.AddNew
'380   rst("Program") = rec.Program
'390   rst("Location") = rec.Location
'400   rst("DateEx") = rec.DateEx
'410   rst("Species") = rec.Species
'420   rst("Observed") = rec.Observed
'430   rst("Census") = rec.Census
'440   rst("Banded") = rec.Banded
'450   rst("Repeats") = rec.Repeats
'460   rst("Returns") = rec.Returns
'470   rst("PKS") = rec.PKS
'480   rst("DET") = rec.DET
'490   rst("VisibleEx") = rec.VisibleEx
'500   rst("Casual") = rec.Casual
'510   rst("Observed3") = rec.Observed3
'520   rst("Observed4") = rec.Observed4
'530   rst("NonStandardBanded") = rec.NonStandardBanded
'540   rst("NonStandardRecaps") = rec.NonStandardRecaps
'550   rst("DailySpeciesTotal") = rec.DailySpeciesTotal
'560   rst("Timestamp") = datTimestamp
'570   rst("Command") = rec.Command
'580   rst("Source") = rec.Source
'590   rst.Update
'600   rst.Close
'610   Set rst = Nothing
'
'
'620   db.Close
'
'630   Set db = Nothing
'
'    'DD Error Handler Start
'Exit_label:
'640       Exit Sub
'Err_label:
'650       Select Case Err.Number
'    Case Else
'660      Call LogError("basLiveBackup", "Log_DETSpecies")
'670       End Select
'680       Resume Exit_label
'    ' DD Error Handler End
'
'Err_live_label:
'690       Select Case Err.Number
'    Case Else
'700      Call LogError("basLiveBackup", "Log_AddDETSpecies", Silent:=True)
'710      MsgBox "Failed to connect to the Live Data Entry database ono a USB flash drive" & vbCrLf & vbCrLf & _
'            "Please use the Summary command button to save the whole DET sheet to a USB flash drive" & vbCrLf & vbCrLf & _
'            CStr(Err.Number) & " " & Err.Description, vbOK + vbCritical, "Live Backup"
'720      Call PromptToDisableOneRecordAtATimeBackup
'730       End Select
'740       Resume Exit_label
'
'End Sub
'
''---------------------------------------------------------------------------------------
'' Log_DETNetHours
''
'' db is the external database
'' Logs a single DET Net Hours Add, Update and Delete transaction.
'' The caller must fill in all the data fields, Command, and Source. This procedure fills in the Timestamp
'' Transactions are logged to a local table - strDETDailyLiveBackup
'' During "live" data entry, the transactions are also logged to corresponding table on an external drive
''------------------------------------------------------------------------------------------------------
'
'Public Sub Log_DETNetHours(ByRef recNetHours As DETNetHoursType)
'
'      Dim strDataEntrySource As String
'      Dim rst As DAO.Recordset
'      Dim db As DAO.Database
'
'10    On Error GoTo Err_label
'
'20    recNetHours.Timestamp = Now()
'
'' Log to the local tblDETNetHours_Log
'
'30    Set rst = CurrentDb.OpenRecordset(strDETNetHoursLiveBackup)
'40    rst.AddNew
'50    rst("Program") = recNetHours.Program
'60    rst("Location") = recNetHours.Location
'70    rst("DateEx") = recNetHours.DateEx
'80    rst("NetID") = recNetHours.NetID
'90    rst("NetHours") = recNetHours.NetHours
'100   rst("Timestamp") = recNetHours.Timestamp
'110   rst("Command") = recNetHours.Command
'120   rst("Source") = recNetHours.Source
'130   rst.Update
'140   rst.Close
'150   Set rst = Nothing
'
'Dim strLog As String
'
'160   strLog = "tblDETNetHours: Command=" & recNetHours.Command & ", Source=" & recNetHours.Source & ", Program=" & recNetHours.Program & ", Location=" & recNetHours.Location & _
'        ", DETDate=" & recNetHours.DateEx & ", NetID=" & recNetHours.NetID & ", NetHours=" & recNetHours.NetHours
'170   log (strLog)
'
'
'' Log to the external tblDETNetHours_Log
'
'180   strDataEntrySource = GetDataEntrySource()
'190   If strDataEntrySource <> "Live" Or GetDisableOneRecordAtATimeLiveBackupDET() Then GoTo Exit_label
'
'
'200   Set db = GetExternalLiveDataEntryDatabase()
'210   If db Is Nothing Then GoTo Exit_label
'
'
'220   On Error GoTo Err_live_label
'
'230   Set rst = db.OpenRecordset(strDETNetHoursLiveBackup)
'240   rst.AddNew
'250   rst("Program") = recNetHours.Program
'260   rst("Location") = recNetHours.Location
'270   rst("DateEx") = recNetHours.DateEx
'280   rst("NetID") = recNetHours.NetID
'290   rst("NetHours") = recNetHours.NetHours
'300   rst("Timestamp") = recNetHours.Timestamp
'310   rst("Command") = recNetHours.Command
'320   rst("Source") = recNetHours.Source
'330   rst.Update
'340   rst.Close
'350   Set rst = Nothing
'
'360   db.Close
'
'370   Set db = Nothing
'
'    'DD Error Handler Start
'Exit_label:
'380       Exit Sub
'Err_label:
'390       Select Case Err.Number
'    Case Else
'400      Call LogError("basLiveBackup", "Log_DETNetHours")
'410       End Select
'420       Resume Exit_label
'    ' DD Error Handler End
'
'Err_live_label:
'430       Select Case Err.Number
'          Case Else
'440            Call LogError("basLiveBackup", "Log_DETNetHours", Silent:=True)
'450            MsgBox "Failed to connect to the Live Data Entry database on a USB flash drive" & vbCrLf & vbCrLf & _
'                  "Please use the Summary command button to save the whole DET sheet to a USB flash drive" & vbCrLf & vbCrLf & _
'                  CStr(Err.Number) & " " & Err.Description, vbOK + vbCritical, "Live Backup"
'460            Call PromptToDisableOneRecordAtATimeBackup
'470       End Select
'480       Resume Exit_label
'
'End Sub
'
''---------------------------------------------------------------------------------------
'' getLiveBackupFolder
''---------------------------------------------------------------------------------------
'' Returns the data entry source "Live" or "FromSheet"
'' If "Live", also returns the folderpath to the external Live backup folder
'
'Private Sub getLiveBackupFolder(ByRef strDataEntrySource As String, ByRef strLiveBackupFolder As String)
'
'10    On Error GoTo Err_label
'
'      ' Loop until data entry source is not Live OR
'      '            ( data entry source is Live AND the Live backup folder is found )
'
'
'20    strDataEntrySource = GetDataEntrySource()
'30    If strDataEntrySource <> "Live" Then GoTo Exit_label
'40    strLiveBackupFolder = GetSettingEx("USBFlashDriveBackupFolder")
'
'50    Do While Not FolderExists(strLiveBackupFolder)
'
'60        DoCmd.OpenForm "frmLiveBackupFolderpath", acNormal, , , , acDialog
'
'70        strDataEntrySource = GetDataEntrySource()
'80        If strDataEntrySource <> "Live" Then
'
'              ' Update the cboDataEntrySource on frmDETViewDaily2
'
'90            If IsLoaded("frmDETViewDaily2") Then
'100               Forms("frmDETViewDaily2").Controls("cboDataEntrySource") = "FromSheets"
'110           End If
'
'120           GoTo Exit_label
'130       End If
'140       strLiveBackupFolder = GetSettingEx("USBFlashDriveBackupFolder")
'
'150   Loop
'
'          'DD Error Handler Start
'Exit_label:
'160       Exit Sub
'Err_label:
'170       Select Case Err.Number
'          Case Else
'180            Call LogError("basLiveBackup", "getLiveBackupFolder")
'190       End Select
'200       Resume Exit_label
'          ' DD Error Handler End
'End Sub
'
''---------------------------------------------------------------------------------------
'' GetDriveLetterFromPath
''---------------------------------------------------------------------------------------
'' Returns the drive letter in upper case
'' If the path does not begin with a valid drive prefix, return ""                 Valid drive prefix:  letter ":"
'' The path can be a folderpath or a filepath
'' Returns "" for share names or network paths
'
'
'Public Function GetDriveLetterFromPath(ByVal strPath) As String
'
'      Dim strDriveLetter As String
'
'10    On Error GoTo Err_label
'
'20    GetDriveLetterFromPath = ""
'
'      ' Validate drive prefix:    letter ":"
'      ' Extract drive letter
'
'30    If Len(strPath) < 2 Then GoTo Exit_label
'40    strDriveLetter = UCase(Left(strPath, 1))
'50    If strDriveLetter < "A" Or strDriveLetter > "Z" Then GoTo Exit_label
'60    If Mid(strPath, 2, 1) <> ":" Then GoTo Exit_label
'
'70    GetDriveLetterFromPath = strDriveLetter
'
'    'DD Error Handler Start
'Exit_label:
'80        Exit Function
'Err_label:
'90        Select Case Err.Number
'    Case Else
'100      Call LogError("basLiveBackup", "GetDriveLetterFromPath")
'110       End Select
'120       Resume Exit_label
'    ' DD Error Handler End
'End Function
'
''---------------------------------------------------------------------------------------
'' IsFolderOnRemovableDrive
''---------------------------------------------------------------------------------------
'' Returns true if the folderpath begins with a valid drive prefix AND the drive is removable
'
'Public Function IsFolderOnRemovableDrive(ByVal strFolderpath As String, ByRef fValidDrivePrefix As Boolean) As Boolean
'
'      Dim strDriveLetter As String
'      Dim fso As Scripting.FileSystemObject
'      Dim drive As Scripting.drive
'
'10    On Error GoTo Err_label
'
'20    strDriveLetter = GetDriveLetterFromPath(strFolderpath)
'30    If strDriveLetter = "" Then
'40        fValidDrivePrefix = False
'50        IsFolderOnRemovableDrive = False
'60    Else
'
'          ' Is the drive removable?
'
'70        fValidDrivePrefix = True
'80        Set fso = New Scripting.FileSystemObject
'90        Set drive = fso.GetDrive(strDriveLetter)
'100       IsFolderOnRemovableDrive = (drive.DriveType = 1)   ' 1 = removable
'
'110   End If
'
'      'DD Error Handler Start
'Exit_label:
'120       Exit Function
'Err_label:
'130       Select Case Err.Number
'          Case Else
'140            Call LogError("basLiveBackup", "IsFolderOnRemovableDrive")
'150       End Select
'160       Resume Exit_label
'          ' DD Error Handler End
'End Function
'
''---------------------------------------------------------------------------------------
'' VerifyLiveBackupFileExists
''
'' Verify the LiveBackup Database File exists
'' If it does not exist, then create it
''---------------------------------------------------------------------------------------
'
'Private Sub VerifyLiveBackupFileExists(ByVal strLiveDatabaseFilepath As String)
'
'10    On Error GoTo Err_label
'
'      Dim ws As DAO.Workspace
'      Dim db As DAO.Database
'
'20    Set ws = DBEngine.Workspaces(0)
'
'30    If Not FileExists(strLiveDatabaseFilepath) Then
'40        Set db = ws.CreateDatabase(strLiveDatabaseFilepath, dbLangGeneral)
'50        DoCmd.TransferDatabase acExport, "Microsoft Access", strLiveDatabaseFilepath, acTable, strDETDailyLiveBackup, strDETDailyLiveBackup, StructureOnly:=True
'60        DoCmd.TransferDatabase acExport, "Microsoft Access", strLiveDatabaseFilepath, acTable, strDETSpeciesLiveBackup, strDETSpeciesLiveBackup, StructureOnly:=True
'70        DoCmd.TransferDatabase acExport, "Microsoft Access", strLiveDatabaseFilepath, acTable, strDETNetHoursLiveBackup, strDETNetHoursLiveBackup, StructureOnly:=True
'80        DoCmd.TransferDatabase acExport, "Microsoft Access", strLiveDatabaseFilepath, acTable, strBandsSheetLiveBackup, strBandsSheetLiveBackup, StructureOnly:=True
'90        DoCmd.TransferDatabase acExport, "Microsoft Access", strLiveDatabaseFilepath, acTable, strRecapturesSheetLiveBackup, strRecapturesSheetLiveBackup, StructureOnly:=True
'100       DoCmd.TransferDatabase acExport, "Microsoft Access", strLiveDatabaseFilepath, acTable, strCapturesLiveBackup, strCapturesLiveBackup, StructureOnly:=True
'
'110       db.Close
'120       Set db = Nothing
'130   End If
'
'          'DD Error Handler Start
'Exit_label:
'140       Exit Sub
'Err_label:
'150       Select Case Err.Number
'          Case Else
'160            Call LogError("basLiveBackup", "VerifyLiveBackupFileExists")
'170       End Select
'180       Resume Exit_label
'          ' DD Error Handler End
'
'End Sub
'
''----------------------------------------------------------------------------------------------
'' BandsOrRecaptures_LiveSnapshot
''
'' If data entry is Live, export the sheet to an Excel file on the USB flash drive backup folder
'' Each Excel file contains the Band and Recap snapshots for 1 day
'' Each export goes to a separate worksheet
''
'' Source = "Bands" or "Recaptures"
''
'' Returns an error message if anyting goes wrong.  Otherwise returns strErr = ""
''---------------------------------------------------------------------------------------
'
'Public Sub BandsOrRecaptures_LiveSnapshot(ByVal strSource As String, ByRef strErr As String)
'
'10    On Error GoTo Err_label
'
'      Dim strTimestamp As String
'
'20    strErr = ""
'
'30    If (GetDataEntrySource() = "Live") Then
'
'40        strErr = "FAILED to export a Live snapshot of " & strSource
'
'          ' Export the sheet to the USB Flash Drive
'          ' --------------------------------------
'          ' LOOP
'          '   Get the USB Flash Drive Folder
'          '   Verify the USB Flash Drive Folder exists
'          '   If the  USB Flash Drive Folder exists
'          '      Export the sheet
'          '      If the copy succeeds, EXIT LOOP
'          '      If the copy fails, say so then EXIT LOOP
'          '   If the USB Flash Drive Folder does not exist
'          '      Prompt for a path
'          '      Cancel => EXIT LOOP
'          ' END LOOP
'
'          Dim strTargetFilename              As String
'          Dim strUSBFlashDriveBackupFolder   As String
'          Dim strUSBFlashDriveBackupFilepath As String
'          Dim strTable As String
'
'50        strTable = IIf(strSource = "Bands", "tblSheetNewBandsMultiSize_v2", "tblSheetRecaps_v2")
'
'60        strTargetFilename = Format(Now(), "yyyy-mm-dd") & " Captures"
'70        strUSBFlashDriveBackupFolder = GetSettingEx("USBFlashDriveBackupFolder")
'80        strUSBFlashDriveBackupFilepath = TrailingSlash(strUSBFlashDriveBackupFolder) & strTargetFilename
'
'90        strTimestamp = Format(Now(), "yyyy-mm-dd hh\hnn\mss")
'100       Select Case strSource
'          Case "Bands"
'110           If strTimestamp = strTimestampBands Then
'120               strErr = "Failed to create Live snapshot - Please do not try to create more than 1 snapshot per second"
'130               GoTo Exit_label
'140           Else
'150               strTimestampBands = strTimestamp
'160           End If
'170       Case "Captures"
'180           If strTimestamp = strTimestampRecaptures Then
'190               strErr = "Failed to create Live snapshot - Please do not try to create more than 1 snapshot per second"
'200               GoTo Exit_label
'210           Else
'220               strTimestampRecaptures = strTimestamp
'230           End If
'240       End Select
'
'250       Do While True
'260           If FolderExists(strUSBFlashDriveBackupFolder) Then
'270               Call PutSettingEx("USBFlashDriveBackupFolder", strUSBFlashDriveBackupFolder)
'                  Dim strSheet As String
'280               strSheet = strSource & " " & strTimestamp
'
'290               On Error Resume Next
'300               DoCmd.TransferSpreadsheet acExport, acSpreadsheetTypeExcel8, strTable, strUSBFlashDriveBackupFilepath, HasFieldNames:=True, range:=strSheet
'310               If Err.Number <> 0 Then
'320                   Call LogError("basSheetNewBands_v2", "BandsOrRecaptures_LiveSnapshot", "TransferSpreadsheet failed", Silent:=True, DeveloperErrNumber:=1)
'330                   Err.Clear
'340                   On Error GoTo Err_label
'350                   Exit Do
'360               Else
'370                   strErr = ""
'380               End If
'
'390               Exit Do
'400           Else
'410               If vbOK <> MsgBox("The Live backup folder " & strUSBFlashDriveBackupFilepath & " does not exist" & vbCrLf & "Click OK if you would like to choose a USB flash drive backup folder" & vbCrLf & "Click Cancel if you do not want to copy the backup to a USB flash drive backup folder", vbOKCancel, "Backup") Then
'420                   Exit Do
'430               End If
'440               strUSBFlashDriveBackupFolder = GetFolder("C:")
'450               If strUSBFlashDriveBackupFolder = "" Then
'460                   Exit Do
'470               Else
'480                   strUSBFlashDriveBackupFilepath = TrailingSlash(strUSBFlashDriveBackupFolder) & strTargetFilename
'490               End If
'500           End If
'510       Loop
'
'520   End If
'
'          'DD Error Handler Start
'Exit_label:
'530       Exit Sub
'Err_label:
'540       Select Case Err.Number
'          Case Else
'550            Call LogError("basSheetNewBands_v2", "Bands_LiveSnapshot")
'560       End Select
'570       Resume Exit_label
'          ' DD Error Handler End
'End Sub
'
'
'
