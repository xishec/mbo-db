Option Compare Database
Option Explicit

Public Sub SQLExecute(ByVal db As DAO.Database, _
    ByVal strSQL As String, _
    ByVal strModule As String, _
    ByVal strProcedure As String, _
    Optional ByVal strMsg As String)

      Dim attempt As Integer
      Dim fOK As Boolean

10    On Error GoTo Err_label

20    fOK = False
30    For attempt = 1 To 3
40        On Error Resume Next
50        db.Execute strSQL
60        If Err.Number = 0 Then
70            fOK = True
80            Exit For
90        Else
100           Err.Clear
110       End If
120   Next attempt
130   On Error GoTo Err_label

140   If Not fOK Then
150       LogError strModule, strProcedure, _
              "(Silent) 3 failed attempts to execute a SQL statement"
160       If strMsg <> "" Then
170           MsgBox strMsg, "Database Write Failure"
180       End If
190   End If

      'DD Error Handler Start
Exit_label:
200        Exit Sub
Err_label:
210        Select Case Err.Number
           Case Else
220             Call LogError("Module1", "SQLExecute")
230        End Select
240        Resume Exit_label
      'DD Error Handler End

End Sub
