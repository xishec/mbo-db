'---------------------------------------------------------------------------------------
' Module: basMBO10Year_BirdsOfMBO_Charts
' Author: David Davey
'---------------------------------------------------------------------------------------

' Generation of the abundance charts for the section "Species Observed at MBO" (section 5,1)
' These tables were introduced in the MBO 15-Year Report.'
'
' This module has 1 Public procedure, namely MBO10YearProgramReportBirdsAtMBO_AbundanceCharts()
' The latter is called from MBO10YearProgramReport()
'
' Firstly, the tblMBO10Year_BirdsOfMBO_Abundance_Charts_Temp table is loaded from tblDETSpecies
' See below for a defintion of how the tblDETSpecies is modified as it is loaded into tblMBO10Year_BirdsOfMBO_Abundance_Charts_Temp
' tblMBO10Year_BirdsOfMBO_Abundance_Charts_Temp are also used when preparing the data for the Species appendix. (I regenerate it)

' = = = = = = = = = =

' tblMBO10Year_BirdsOfMBO_Abundance_Charts_Temp
' ------------------------------------------------------------------------------------------
' YearEx
' Season
' Period
' DateEx
' SpeciesGroup
' Species
' Banded
' Returns
' Repeats
' Alien
' Replacement
' DET
' ------------------------------------------------------------------------------------------
' tblDETSpecies x tblPrograms x tblSpecies x tblMBO10Year_SpeciesGroups_SpeciesObservedAtMBO
' HAVING YearEx BETWEEN argYearFirst AND argYearLast
' WHERE Location = "MBO"
'
' The records for ("UNAC","UNEM","UNGU") are excluded
' The records for ("LSGO","GSGO","SNGO") are merged into SNGO records. Then LSGO, GSGO are excluded.
' The records for ("TRFL","ALFL","WIFL") are combined into TRFL+ records. All these records are retained.
' The records for ("WPWA","YPWA","PAWA") are merged into PAWA records. The unmerged PAWA is excluded. WPWA, YPWA, the merged PAWA are retained.
' The records for LESC, GTSC, USCA are retained
'
' GROUP BY YearEx, Season, DateEx, SpeciesGroup
'
' SUM Banded, DET           (there can be multiple records for the same date)

' YearEx
' DateEx
'
' Season = toSeasonBirdsOfMBOAbundanceCharts(MonitoringProgramSeason, DateEX)
'    Spring = Spring + RTHU_Spring
'    Fall = Fall + RTHU_Fall + Owling that takes place in Fall
'    Summer = Summer + Nestbox
'    Winter = Winter + + Owling that takes place in Fall
'
' Period: toPeriodBirdsOfMBOAbundanceCharts([MonitoringProgramSeason],[DateEx])
'    N.B. The first week of Owling is #9
'
' HAVING Season IN ("Winter", "Spring", "Summer", "Fall")
' SpeciesGroup = SpeciesGroupSpeciesObservedAtMBOID

' When I generate the Species appendix I will
' exclude TRFL; rename TRFL+ to TRFL
' exclude PAWA
' exclude USCA

' When I count the number of true species in the 5.1 abundance tables, I will
' exclude TRFL, TRFL+          include WIFL, ALFL, the counts will be adjusted for TRFL
' exclude WPWA, YPWA           include the merged PAWA
' exclude USCA                 include LESC, GTSC, the counts will be adjusted for USCA
'                              include the merged SBGO

' When I count the number of individuals in the 5.1 abundance tables, I will
' exclude WIFL, ALFL, TRFL     include TRFL+
' exclude WPWA, YPWA           include the merged PAWA
'                              include the merged SBGO



' = = = = = = = = = =

Option Compare Database
Option Explicit

' intAbundanceCounters() is allocated in MBO10YearProgramReportSpeciesObservedAtMBO()

Private intAbundanceCounters() As Integer  '  (AbundanceCategory: 1 to 7, colPeriodFirst to colPeriodLast)

' The following module constants are initialised in MBO10YearProgramReportSpeciesObservedAtMBO()
' They are used as column numbers in both the Word tables
' (The Excel worksheets have their own set of column numbers)

Private colSpecies As Integer
Private colPeriodFirst As Integer
Private colNOV As Integer
Private colDEC As Integer
Private colJAN As Integer
Private colFEB As Integer
Private colMAR As Integer
Private colSpringFirst As Integer
Private colSpringLast As Integer
Private colJUN As Integer
Private colJUL As Integer
Private colFallFirst As Integer
Private colFallLast As Integer
Private colPeriodLast As Integer
Private colDetailsBase As Integer

' The array of colour constants intAbundanceLineColour() is loaded in MBO10YearProgramReportSpeciesObservedAtMBO()

Private lngAbundanceLineColour(1 To 6) As Long

' The colour constant con_lngColourAlternate constant is loaded in MBO10YearProgramReportSpeciesObservedAtMBO()

Private con_lngColourAlternate As Long ' Background colour for alternate rows

' Width of the species code column in points

Const con_lngXSpeciesWidth As Long = 37

' Relative report periods

Const conNOV As Integer = 1
Const conDEC As Integer = 2
Const conJAN As Integer = 3
Const conFEB As Integer = 4
Const conMAR As Integer = 5
Const conS1  As Integer = 1
Const conJUN As Integer = 1
Const conJUL As Integer = 2
Const conF1  As Integer = 1
Const conErr As Integer = -1

'---------------------------------------------------------------------------------------
' MBO10YearProgramReportSpeciesObservedAtMBO
'---------------------------------------------------------------------------------------
'
' Called from MBO10YearProgramReport()

Public Sub MBO10YearProgramReportBirdsAtMBO_AbundanceCharts( _
    ByVal intYearFirst As Integer, ByVal intYearLast As Integer, _
    ByRef wd As Word.Application, ByRef doc As Word.Document, _
    ByRef oExcel As Excel.Application, ByRef oBook As Excel.Workbook, _
    ByVal fDebug As Boolean)
          
10    On Error GoTo Err_label

20    If fDebug Then
30       wd.Visible = True
40    End If

      Dim strLocation As String
50    strLocation = "MBO"

      Dim intPeriodLastSpring As Integer
      Dim intPeriodLastFall As Integer

60    intPeriodLastSpring = getPeriodLast_Season("Spring")
70    intPeriodLastFall = getPeriodLast_Season("Fall")

80    Call initialise_module_constants


      ' ================================================================================================

      ' Load tbl15YearReport_BirdsOfMBO_Charts_DET_Temp        with DET info from  Winter, Spring, Summer, Fall
      '       Intermediate step: Loads tbl15YearReport_BirdsOfMBO_Charts_Temp
      '
      ' Load tbl15YearReport_BirdsOfMBO_Charts_Captures_Temp   with Capture info from Owling
      '       Intermediate step: Loads tbl15YearReport_BirdsOfMBO_Charts_Temp
      '
      ' Load tblMBO10YearProgramReport_Abundance_Temp from the above two tables


90    Call Load_tbl15YearReport_BirdsOfMBO_Charts_DET_Temp(intYearFirst, intYearLast)
100   Call Load_tbl15YearReport_BirdsOfMBO_Charts_Captures_Temp(intYearFirst, intYearLast)
110   Call Load_tblMBO10YearProgramReport_Abundance_Temp(intYearFirst, intYearLast)

120   Call Excel_Output(intYearFirst, intYearLast, oExcel, oBook, fOwling:=False, fDebug:=fDebug)
130   Call Excel_Output(intYearFirst, intYearLast, oExcel, oBook, fOwling:=True, fDebug:=fDebug)

140   Call Word_Output(intYearFirst, intYearLast, wd, doc)


    'DD Error Handler Start
Exit_label:
150       Exit Sub
Err_label:
160       Select Case Err.Number
    Case Else
170      Call LogError("basMBO10Year_BirdsOfMBO_Charts", "MBO10YearProgramReportBirdsAtMBO_AbundanceCharts")
180       End Select
190       Resume Exit_label
    ' DD Error Handler End
End Sub


Private Sub initialise_module_constants()
      ' Initialise the module constants

90    colSpecies = 1
100   colPeriodFirst = colSpecies + 1
110   colNOV = colPeriodFirst
120   colDEC = colNOV + 1
130   colJAN = colDEC + 1
140   colFEB = colJAN + 1
150   colMAR = colFEB + 1
160   colSpringFirst = colMAR + 1
170   colSpringLast = colSpringFirst + 10 - 1
180   colJUN = colSpringLast + 1
190   colJUL = colJUN + 1
200   colFallFirst = colJUL + 1
210   colFallLast = colFallFirst + 14 - 1
220   colPeriodLast = colFallLast

230   lngAbundanceLineColour(1) = RGB(178, 161, 199)
240   lngAbundanceLineColour(2) = RGB(0, 176, 240)
250   lngAbundanceLineColour(3) = RGB(146, 208, 80)
260   lngAbundanceLineColour(4) = RGB(255, 255, 0)
270   lngAbundanceLineColour(5) = RGB(255, 192, 0)
280   lngAbundanceLineColour(6) = RGB(255, 0, 0)

290   con_lngColourAlternate = RGB(239, 245, 245)

300   colDetailsBase = colPeriodLast + 1

      ' Allocate the abundance counters

310   ReDim intAbundanceCounters(1 To 7, colPeriodFirst To colPeriodLast) As Integer

      Dim intWeek As Integer

'320   strPeriod(-1) = "Err"
'330   strPeriod(0) = "Nov"
'340   strPeriod(1) = "Dec"
'350   strPeriod(2) = "Jan"
'360   strPeriod(3) = "Feb"
'370   strPeriod(4) = "Mar"
'380   For intWeek = 1 To 10
'390       strPeriod(4 + intWeek) = "S" & intWeek
'400   Next
'410   strPeriod(15) = "Jun"
'420   strPeriod(16) = "Jul"
'430   For intWeek = 1 To 14
'440       strPeriod(16 + intWeek) = "F" & intWeek
'450   Next
End Sub

'---------------------------------------------------------------------------------------
' word_output
'---------------------------------------------------------------------------------------
' If intYearFirst = 0, then do not generate a legend

Public Sub Word_Output(ByVal intYearFirst As Integer, ByVal intYearLast As Integer, ByRef wd As Word.Application, ByRef doc As Word.Document)


10    On Error GoTo Err_label

20    If intYearFirst = 0 Then
30        Call initialise_module_constants
40    End If
         
      Dim intPeriodLastSpring As Integer
      Dim intPeriodLastFall As Integer

50    intPeriodLastSpring = 10
60    intPeriodLastFall = 14

70    SysCmd acSysCmdSetStatus, "Species observed at MBO - Export to Word - Detail"
80    DoEvents

      Dim lngPageWidth As Long
      Dim lngLeftMargin As Long
      Dim lngRightMargin As Long

90    lngPageWidth = doc.PageSetup.PageWidth
100   lngLeftMargin = doc.PageSetup.LeftMargin
110   lngRightMargin = doc.PageSetup.RightMargin

      ' Get, in points, the X position and width of the species column
      ' Get the number of periods
      ' Get, in points, the width of each period column

      Dim lngXSpeciesStart As Long
      Dim lngXPeriodWidth As Long
      Dim lngNumberPeriods As Long
      Dim lngXSpeciesWidth As Long


120   Call TableWidth(doc, intPeriodLastSpring, intPeriodLastFall, lngXSpeciesStart, lngXSpeciesWidth, lngNumberPeriods, lngXPeriodWidth)

      ' Output the legend table

130   If intYearFirst <> 0 Then
140       Call Legend_Top(doc, lngPageWidth, lngLeftMargin, lngRightMargin, lngXSpeciesStart, lngXSpeciesWidth, lngNumberPeriods, lngXPeriodWidth, intYearFirst, intYearLast)
150   End If

      Dim range As Word.range
160   Set range = MoveInsertionPointToEndOfDocument(wd, doc)

170   range.InsertParagraphAfter
180   range.ParagraphFormat.Style = "ddBody"

190   Set range = MoveInsertionPointToEndOfDocument(wd, doc)

200   Call WordOutput_SpeciesGroup(doc, lngPageWidth, lngLeftMargin, lngRightMargin, lngXSpeciesStart, lngXSpeciesWidth, lngNumberPeriods, lngXPeriodWidth)

210   Set range = MoveInsertionPointToEndOfDocument(wd, doc)

220   range.InsertParagraphAfter
230   range.ParagraphFormat.Style = "ddBody"

240   SysCmd acSysCmdClearStatus
250   DoEvents

          'DD Error Handler Start
Exit_label:
260       Exit Sub
Err_label:
270       Select Case Err.Number
          Case Else
280      Call LogError("basMBO10Year_BirdsOfMBO_Charts", "word_output")
290       End Select
300       Resume Exit_label
          ' DD Error Handler End
End Sub


''---------------------------------------------------------------------------------------
'' MBO10YearProgramReportBirdsAtMBO_AbundanceCharts_FromExcel
''---------------------------------------------------------------------------------------
'
'Public Sub MBO10YearProgramReportBirdsAtMBO_AbundanceCharts_FromExcel( _
'    ByRef wd As Word.Application, ByRef doc As Word.Document, _
'    ByVal fDebug As Boolean)
'
'20    On Error GoTo Err_label
'
'30    If fDebug Then
'40       wd.Visible = True
'50    End If
'
'Dim intPeriodLastSpring As Integer
'Dim intPeriodLastFall As Integer
''
'60    intPeriodLastSpring = 10
'70    intPeriodLastFall = 14
'
'' Initialise the module constants
'
'80    colSpecies = 1
'90    colPeriodFirst = colSpecies + 1
'100   colNOV = colPeriodFirst
'110   colDEC = colNOV + 1
'120   colJAN = colDEC + 1
'130   colFEB = colJAN + 1
'140   colMAR = colFEB + 1
'150   colSpringFirst = colMAR + 1
'160   colSpringLast = colSpringFirst + intPeriodLastSpring - 1
'170   colJUN = colSpringLast + 1
'180   colJUL = colJUN + 1
'190   colFallFirst = colJUL + 1
'200   colFallLast = colFallFirst + intPeriodLastFall - 1
'210   colPeriodLast = colFallLast
'
'220   lngAbundanceLineColour(1) = RGB(178, 161, 199)
'230   lngAbundanceLineColour(2) = RGB(0, 176, 240)
'240   lngAbundanceLineColour(3) = RGB(146, 208, 80)
'250   lngAbundanceLineColour(4) = RGB(255, 255, 0)
'260   lngAbundanceLineColour(5) = RGB(255, 192, 0)
'270   lngAbundanceLineColour(6) = RGB(255, 0, 0)
'
'280   con_lngColourAlternate = RGB(239, 245, 245)
'
'290   colDetailsBase = colPeriodLast + 1
'
'' Output the pictures
'
'300   SysCmd acSysCmdSetStatus, "Abundance Charts"
'310   DoEvents
'
'Dim lngPageWidth As Long
'Dim lngLeftMargin As Long
'Dim lngRightMargin As Long
'
'320   lngPageWidth = doc.PageSetup.PageWidth
'330   lngLeftMargin = doc.PageSetup.LeftMargin
'340   lngRightMargin = doc.PageSetup.RightMargin
'
'' Get, in points, the X position and width of the species column
'' Get the number of periods
'' Get, in points, the width of each period column
'
'Dim lngXSpeciesStart As Long
'Dim lngXPeriodWidth As Long
'Dim lngNumberPeriods As Long
'Dim lngXSpeciesWidth As Long
'
'350   Call TableWidth(doc, intPeriodLastSpring, intPeriodLastFall, lngXSpeciesStart, lngXSpeciesWidth, lngNumberPeriods, lngXPeriodWidth)
'
''' Output the legend table
''
''430   Call Legend_Top(doc, lngPageWidth, lngLeftMargin, lngRightMargin, lngXSpeciesStart, lngXSpeciesWidth, lngNumberPeriods, lngXPeriodWidth)
''
'Dim range As Word.range
'360   Set range = MoveInsertionPointToEndOfDocument(wd, doc)
'
'370   range.InsertParagraphAfter
'380   range.ParagraphFormat.Style = "ddBody"
'
'390   Set range = MoveInsertionPointToEndOfDocument(wd, doc)
'
'400   Call WordOutput_SpeciesGroup(doc, lngPageWidth, lngLeftMargin, lngRightMargin, lngXSpeciesStart, lngXSpeciesWidth, lngNumberPeriods, lngXPeriodWidth)
'
'410   Set range = MoveInsertionPointToEndOfDocument(wd, doc)
'
'420   range.InsertParagraphAfter
'430   range.ParagraphFormat.Style = "ddBody"
'
'440   SysCmd acSysCmdClearStatus
'450   DoEvents
'
'    'DD Error Handler Start
'Exit_label:
'460       Exit Sub
'Err_label:
'470       Select Case Err.Number
'    Case Else
'480      Call LogError("basMBO10Year_BirdsOfMBO_Charts", "MBO10YearProgramReportBirdsAtMBO_AbundanceCharts_FromExcel")
'490       End Select
'500       Resume Exit_label
'    ' DD Error Handler End
'End Sub

'---------------------------------------------------------------------------------------
' Load_tbl15YearReport_BirdsOfMBO_Charts_Temp
'---------------------------------------------------------------------------------------
' Load tbl15YearReport_BirdsOfMBO_Charts_Temp
' with the DET info from Winter, Spring, Summer, Fall

' Called from Load_tbl15YearReport_BirdsOfMBO_Charts_DET_Temp()

Public Sub Load_tbl15YearReport_BirdsOfMBO_Charts_Temp(ByVal intYearFirst As Integer, ByVal intYearLast As Integer)

' tbl15YearReport_BirdsOfMBO_Charts_Temp
' ------------------------------------------
' YearEx
' Season    Report Season: "Winter","Spring","Summer","Fall"
' Period
' DateEx
' Species
' DET       DET for the "Winter","Spring","Summer","Fall" MPs
'           Captures for Owling MP
'
' Location = "MBO",
' MonitoringProgramSeason IN ("Winter","Spring","Summer","Fall")
' YearEx BETWEEN [argYearFirst] AND [argYearLast]
'
' Season = MonitoringProgramSeason

' ZAP tbl15YearReport_BirdsOfMBO_Charts_Temp

10    CurrentDb.Execute "Delete * From tbl15YearReport_BirdsOfMBO_Charts_Temp"

Dim qdf As DAO.QueryDef

' qry15YearReport_BirdsOfMBO_Charts_DET_Append
' --------------------------------------------
' tblDETSpecies x tblPrograms x tbllSpecies
' APPEND TO tbl15YearReport_BirdsOfMBO_Charts_Temp
'
' WHERE Location = "MBO"
' WHERE YearEx BETWEEN [argYearFirst] AND [argYearLast]
' WHERE MonitoringProgramSeason IN ("Winter","Spring","Summer","Fall")
' WHERE Species NOT IN ("UNSC","PAWA","HYWA","SNGO","LSGO","GSGO","TRFL")
' WHERE SseudoSpeciesType <> "Hybrid"
'
' Season = MonitoringProgramSeason
' Period: toPeriodBirdsOfMBOAbundanceCharts(MonitoringProgramSeason, DateEx)
'
' SELECT    YearEx, Season, DateEx, Species, DET
' APPEND TO YearEx, Season, DateEx, Species, DET

20    Set qdf = CurrentDb.QueryDefs("qry15YearReport_BirdsOfMBO_Charts_DET_Append")
30    qdf.Parameters("argYearFirst") = intYearFirst
40    qdf.Parameters("argYearLast") = intYearLast
50    qdf.Execute

' qry15YearReport_BirdsOfMBO_Charts_DET_TRFL_Append
' -------------------------------------------------
' tblDETSpecies x tblPrograms
' APPEND TO tbl15YearReport_BirdsOfMBO_Charts_DET_Temp
'
' WHERE Location = "MBO"
' WHERE YearEx BETWEEN [argYearFirst] AND [argYearLast]
' WHERE MonitoringProgramSeason IN ("Winter","Spring","Summer","Fall")
' WHERE Species IN ("WIFL","ALFL","TRFL")
'
' Season = MonitoringProgramSeason
' SpeciesEx = "TRFL"
'
' GROUP BY YearEx, ReportSeason, DateEx, SpeciesEx
' DET = SUM DET
'
' SELECT    YearEx, Season, DateEx, SpeciesEx, DET
' APPEND TO YearEx, Season, DateEx, Species,   DET

60    Set qdf = CurrentDb.QueryDefs("qry15YearReport_BirdsOfMBO_Charts_DET_TRFL_Append")
70    qdf.Parameters("argYearFirst") = intYearFirst
80    qdf.Parameters("argYearLast") = intYearLast
90    qdf.Execute

' qry15YearReport_BirdsOfMBO_Charts_DET_SNGO_Append
' -------------------------------------------------
' tblDETSpecies x tblPrograms
' APPEND TO tbl15YearReport_BirdsOfMBO_Charts_DET_Temp
'
' WHERE Location = "MBO"
' WHERE YearEx BETWEEN [argYearFirst] AND [argYearLast]
' WHERE MonitoringProgramSeason IN ("Winter","Spring","Summer","Fall")
' WHERE Species IN ("SNGO","LSGO","GSGO")
'
' Season = MonitoringProgramSeason
' SpeciesEx = "SNGO"
'
' GROUP BY YearEx, Season, DateEx, SpeciesEx
' DET = SUM DET
'
' SELECT    YearEx, Season, DateEx, SpeciesEx, DET
' APPEND TO YearEx, Season, DateEx, Species,   DET

110   Set qdf = CurrentDb.QueryDefs("qry15YearReport_BirdsOfMBO_Charts_DET_SNGO_Append")
120   qdf.Parameters("argYearFirst") = intYearFirst
130   qdf.Parameters("argYearLast") = intYearLast
140   qdf.Execute

    'DD Error Handler Start
Exit_label:
150       Exit Sub
Err_label:
160       Select Case Err.Number
    Case Else
170      Call LogError("basMBO10Year_BirdsOfMBO_Charts", "load_tbl15YearReport_BirdsOfMBO_Charts_Temp")
180       End Select
190       Resume Exit_label
    ' DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' Load_tbl15YearReport_BirdsOfMBO_Charts_Temp_With_OwlingCaptures
'---------------------------------------------------------------------------------------
' Called from load_tbl15YearReport_BirdsOfMBO_Charts_Captures_Temp
'
' Load tbl15YearReport_BirdsOfMBO_Charts_Temp
' with the Capture info from Owling

Public Sub Load_tbl15YearReport_BirdsOfMBO_Charts_Temp_With_OwlingCaptures(ByVal intYearFirst As Integer, ByVal intYearLast As Integer)

' tbl15YearReport_BirdsOfMBO_Charts_Captures_Temp
' -----------------------------------------------
' YearEx
' ReportSeason  "Winter", "Fall"
' DateEx
' Species
' DET = nz([Banded])+nz([Repeats])+nz([Returns])+nz([Observed3])+nz([Observed4])
'
' Location = "MBO",
' MonitoringProgramSeason  = "Owling"
' YearEx BETWEEN [argYearFirst] AND [argYearLast]
' Season = toSeasonBirdsOfMBOAbundanceCharts(MonitoringProgramSeason, DateEx)

' ZAP tbl15YearReport_BirdsOfMBO_Charts_Temp

10    CurrentDb.Execute "Delete * From tbl15YearReport_BirdsOfMBO_Charts_Temp"

' qry15YearReport_BirdsOfMBO_Charts_Captures_Append
' -------------------------------------------------
' tblDETSpecies x tblPrograms
' APPEND TO tbl15YearReport_BirdsOfMBO_Charts_Captures_Temp
'
' WHERE Location = "MBO"
' WHERE YearEx BETWEEN [argYearFirst] AND [argYearLast]
' WHERE MonitoringProgramSeason = "Owling"
'
' Season = MonitoringProgramSeason
' Captures: nz([Banded])+nz([Repeats])+nz([Returns])+nz([Observed3])+nz([Observed4])
' Period: toReportPeriod([MonitoringProgramSeason],[DateEx])
'
' SELECT    YearEx, Season, DateEx, Species, DET
' APPEND TO YearEx, Season, DateEx, Species, DET

20       On Error GoTo Err_label

Dim qdf As DAO.QueryDef

30    Set qdf = CurrentDb.QueryDefs("qry15YearReport_BirdsOfMBO_Charts_Captures_Append")
40    qdf.Parameters("argYearFirst") = intYearFirst
50    qdf.Parameters("argYearLast") = intYearLast
60    qdf.Execute

    'DD Error Handler Start
Exit_label:
70        Exit Sub
Err_label:
80        Select Case Err.Number
    Case Else
90       Call LogError("basMBO10Year_BirdsOfMBO_Charts", "Load_tbl15YearReport_BirdsOfMBO_Charts_Captures_Temp_Owling")
100       End Select
110       Resume Exit_label
    ' DD Error Handler End
End Sub

''---------------------------------------------------------------------------------------
'' Load_tblMBO10Year_BirdsOfMBO_Abundance_Charts_Temp
''---------------------------------------------------------------------------------------
''
'' Called from: MBO10YearProgramReportBirdsAtMBO_AbundanceCharts
''              MBO10YearProgramReportSpecies
'
'Public Sub Load_tblMBO10Year_BirdsOfMBO_Abundance_Charts_Temp(ByVal intYearFirst As Integer, ByVal intYearLast As Integer)
'
'10    On Error GoTo Err_label
'
'      Dim qdf As DAO.QueryDef
'
'20    CurrentDb.Execute "DELETE * FROM tblMBO10Year_BirdsOfMBO_Abundance_Charts_Temp"
'
'      ' qryMBO10Year_BirdsOfMBO_DETSpecies
'      ' ----------------------------------
'      ' Same as tblDETSpecies but making sure only the big 4 seasons have non-null values
'      ' DETEx: iif(MonitoringProgramSeason = "Winter" or MonitoringProgramSeason = "Spring" or MonitoringProgramSeason = "Summer" or MonitoringProgramSeason = "Fall",[DET], Null)
'
'
'      ' qryMBO10Year_BirdsOfMBO_DETSpecies_A
'      ' ----------------------------------------------------------------
'      ' RTHU_Spring are merged with Spring
'      ' Nestbox are merged with Summer
'      ' RTHU_Fall are merged with Fall
'      ' Owling records are merged with Fall/Winter
'
'      ' Then filtered for Location = "MBO",
'      '                  Season IN ("Winter","Spring","Summer","Fall")
'      '                  YearEx BETWEEN [argYearFirst] AND [argYearLast]
'      ' ----------------------------------------------------------------
'      ' qryMBO10Year_BirdsOfMBO_DETSpecies x tblPrograms
'      '
'      ' WHERE Location = "MBO"
'      ' HAVING YearEx BETWEEN [argYearFirst] AND [argYearLast]
'      ' HAVING toSeasonBirdsOfMBOAbundanceCharts(MonitoringProgramSeason, DateEX) IN ("Winter","Spring","Summer","Fall")
'      '
'      ' DateEX
'      ' Species
'      ' Banded: SUM Banded
'      ' Returns: SUM Returns
'      ' Repeats: SUM Repeats
'      ' Alien: SUM Observed3
'      ' Replacement: SUM Observed4
'      ' DET: SUM DETEX
'      ' Season = toSeasonBirdsOfMBOAbundanceCharts(MonitoringProgramSeason, DateEX)
'      '    Spring = Spring + RTHU_Spring
'      '    Fall = Fall + RTHU_Fall + Owling that takes place in Fall
'      '    Summer = Summer + Nestbox
'      '    Winter = Winter + + Owling that takes place in Fall
'      ' YearEx
'      '
'      ' GROUP BY YearEx, Season, DateEx
'      '
'      ' SELECT Season, YearEx, DateEx, Banded, Repeats, Returns, Alien, Replacement, DET
'
'      ' = = = = = = = = = =
'
'      ' qryMBO10Year_BirdsOfMBO_Abundance_Charts_Append
'      ' -------------------------------------------------------
'      ' APPEND TO tblMBO10Year_BirdsOfMBO_Abundance_Charts_Temp
'      ' qryMBO10Year_BirdsOfMBO_DETSpecies_A x tblSpecies
'
'      ' The records for ("UNAC","UNEM","UNGU") are excluded
'
'      ' The records for ("TRFL","ALFL","WIFL") are included
'      '         A subsequent append query will include merged TRFL+
'
'      ' The records for "PAWA"  are excluded
'      ' The records for "YPWA", "WPWA" are included
'      '         A subsequent append query will include merged PAWA
'
'      ' The records for ("LESC","GRSC", "USCA") are included
'
'      ' The records for ("LSGO","GSGO","SNGO") are excluded
'      '         A subsequent append query will include merged SNGO
'
'      ' ---------------------------------------------------------
'      ' Not In ("LSGO","GSGO","SNGO","UNAC","UNEM","UNGU","PAWA")
'      ' ---------------------------------------------------------
'
'      ' GROUP BY Season, YearEx, Period, DateEx, SpeciesGroup
'      ' SUM Banded, DET
'      '
'      ' SpeciesGroup = SpeciesGroupSpeciesObservedAtMBOID
'      '
'      ' Period: toPeriodBirdsOfMBOAbundanceCharts([MonitoringProgramSeason],[DateEx])
'      '
'      ' SELECT YearEx, Season, Period, SpeciesGroup, Species, Banded, Repeats, Returns, Alien, ReplacementDET
'
'30    Set qdf = CurrentDb.QueryDefs("qryMBO10Year_BirdsOfMBO_Abundance_Charts_Append")
'40    qdf.Parameters("argYearFirst") = intYearFirst
'50    qdf.Parameters("argYearLast") = intYearLast
'60    qdf.Execute
'
'      ' qryMBO10Year_BirdsOfMBO_Abundance_Charts_TRLF_Append
'      ' ---------------------------------------------------
'      ' APPEND TO tblMBO10Year_BirdsOfMBO_Abundance_Charts_Temp
'      ' qryMBO10Year_BirdsOfMBO_DETSpecies_A x tblSpecies
'      '
'      ' WHERE Species IN ("TRFL","ALFL","WIFL")
'      '
'      ' Species = 'TRFL+'
'      '
'      ' GROUP BY Season, YearEx, Period, DateEx, SpeciesGroup
'      ' SUM Banded, DET
'      '
'      ' SpeciesGroup = SpeciesGroupSpeciesObservedAtMBOID
'      '
'      ' Period: toPeriodBirdsOfMBOAbundanceCharts([MonitoringProgramSeason],[DateEx])
'      '
'      ' SELECT YearEx, Season, Period, SpeciesGroup, Species, Banded, DET
'
'70    Set qdf = CurrentDb.QueryDefs("qryMBO10Year_BirdsOfMBO_Abundance_Charts_TRFL_Append")
'80    qdf.Parameters("argYearFirst") = intYearFirst
'90    qdf.Parameters("argYearLast") = intYearLast
'100   qdf.Execute
'
'      ' qryMBO10Year_BirdsOfMBO_Abundance_Charts_SNGO_Append
'      ' ---------------------------------------------------
'      ' APPEND TO tblMBO10Year_BirdsOfMBO_Abundance_Charts_Temp
'      ' qryMBO10Year_BirdsOfMBO_DETSpecies_A x tblSpecies
'      '
'      ' WHERE Species IN ("LSGO","GSGO","SNGO")
'      '
'      ' Species = 'SNGO'
'      '
'      ' GROUP BY Season, YearEx, Period, DateEx, SpeciesGroup
'      ' SUM Banded, DET
'      '
'      ' SpeciesGroup = SpeciesGroupSpeciesObservedAtMBOID
'      '
'      ' Period: toPeriodBirdsOfMBOAbundanceCharts([MonitoringProgramSeason],[DateEx])
'      '
'      ' SELECT YearEx, Season, Period, SpeciesGroup, Species, Banded, DET
'
'110   Set qdf = CurrentDb.QueryDefs("qryMBO10Year_BirdsOfMBO_Abundance_Charts_SNGO_Append")
'120   qdf.Parameters("argYearFirst") = intYearFirst
'130   qdf.Parameters("argYearLast") = intYearLast
'140   qdf.Execute
'
'      ' qryMBO10Year_BirdsOfMBO_Abundance_Charts_PAWA_Append
'      ' ---------------------------------------------------
'      ' APPEND TO tblMBO10Year_BirdsOfMBO_Abundance_Charts_Temp
'      ' qryMBO10Year_BirdsOfMBO_DETSpecies_A x tblSpecies
'      '
'      ' WHERE Species IN ("PAWA","YPWA","WPWA")
'      '
'      ' Species = 'PAWA'
'      '
'      ' GROUP BY Season, YearEx, Period, DateEx, SpeciesGroup
'      ' SUM Banded, DET
'      '
'      ' SpeciesGroup = SpeciesGroupSpeciesObservedAtMBOID
'      '
'      ' Period: toPeriodBirdsOfMBOAbundanceCharts([MonitoringProgramSeason],[DateEx])
'      '
'      ' SELECT YearEx, Season, Period, SpeciesGroup, Species, Banded, DET
'
'150   Set qdf = CurrentDb.QueryDefs("qryMBO10Year_BirdsOfMBO_Abundance_Charts_PAWA_Append")
'160   qdf.Parameters("argYearFirst") = intYearFirst
'170   qdf.Parameters("argYearLast") = intYearLast
'180   qdf.Execute
'
'          'DD Error Handler Start
'Exit_label:
'190       Exit Sub
'Err_label:
'200       Select Case Err.Number
'          Case Else
'210      Call LogError("basMBO10Year_BirdsOfMBO_Charts", "Load_tblMBO10Year_BirdsOfMBO_Abundance_Charts_Temp")
'220       End Select
'230       Resume Exit_label
'          ' DD Error Handler End
'
'End Sub


'---------------------------------------------------------------------------------------
' toReportPeriod
'---------------------------------------------------------------------------------------
' Relative report periods

Public Function toReportPeriod(ByVal strSeason As String, datDateEx As Date) As Integer

20    On Error GoTo Err_label
          
      Dim datDay   As Date
      Dim toPeriod As String
      Dim intWeek As Integer

30    datDay = DateSerial(2000, Month(datDateEx), Day(datDateEx))

40    Select Case strSeason
      Case "Winter"
50        Select Case Month(datDateEx)
          Case 1
60            toPeriod = conJAN
70        Case 2
80            toPeriod = conFEB
90        Case 3 To 6
100           toPeriod = conMAR
110       Case 7 To 11
120           toPeriod = conNOV
130       Case 12
140           toPeriod = conDEC
150       End Select
160   Case "Spring", "RTHU_Spring"
170       intWeek = Int((datDay - DateSerial(2000, 3, 28)) / 7) + 1
180       If intWeek < 1 Or intWeek > 10 Then
190           toPeriod = conErr
200       Else
210           toPeriod = conS1 + intWeek - 1
220       End If
230   Case "Summer", "Nestbox"

      ' Include 2009-08-04 in period 2
      ' Include 2012-05-05 in period 1

240       Select Case Month(datDateEx)
          Case 1 To 6
250           toPeriod = conJUN
260       Case 7 To 12
270           toPeriod = conJUL
280       End Select
290   Case "Fall", "RTHU_Fall"
300       intWeek = Int((datDay - DateSerial(2000, 8, 1)) / 7) + 1
310       If Year(datDateEx) < 2015 Then
320           If intWeek < 1 Or intWeek > 13 Then
330               toPeriod = conErr
340           Else
350               toPeriod = conF1 + intWeek - 1
360           End If
370       Else
380           If intWeek < 1 Or intWeek > 14 Then
390               toPeriod = conErr
400           Else
410               toPeriod = conF1 + intWeek - 1
420           End If
430       End If
          
      ' Last day for FMMP 30-Oct before 2015
      '                    6 Nov on or after 2015

440   Case "Owling"
450       If Year(datDateEx) < 2015 Then
460           If datDay <= DateSerial(2000, 10, 30) Then
470               intWeek = Int((datDay - DateSerial(2000, 8, 1)) / 7) + 1
480               If intWeek < 1 Or intWeek > 13 Then
490                   toPeriod = conErr
500               Else
510                   toPeriod = conF1 + intWeek - 1
520               End If
530           Else
540               Select Case Month(datDateEx)
                   Case 1 To 9
550                    toPeriod = conErr
560                Case 10, 11
570                    toPeriod = conNOV
580                Case 12
590                    toPeriod = conDEC
600                End Select
610           End If
620       Else
630           If datDay <= DateSerial(2000, 11, 6) Then
640               intWeek = Int((datDay - DateSerial(2000, 8, 1)) / 7) + 1
650               If intWeek < 1 Or intWeek > 14 Then
660                   toPeriod = conErr
670               Else
680                   toPeriod = conF1 + intWeek - 1
690               End If
700           Else
710               Select Case Month(datDateEx)
                   Case 1 To 10
720                    toPeriod = conErr
730                Case 11
740                    toPeriod = conNOV
750                Case 12
760                    toPeriod = conDEC
770                End Select
780           End If
790       End If
800   Case Else
810       toPeriod = conErr
820   End Select

830   toReportPeriod = toPeriod

    'DD Error Handler Start
Exit_label:
840       Exit Function
Err_label:
850       Select Case Err.Number
    Case Else
860      Call LogError("basMBO10Year_BirdsOfMBO_Charts", "toReportPeriod")
870       End Select
880       Resume Exit_label
    ' DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' toPeriodGeneral
'---------------------------------------------------------------------------------------
' PRE: strSeason IN ("Winter", "Spring", "Summer", "Fall", "Owling", "NestBox", "RTHU_Spring", "RTHU_Fall")
' All Spring captures are between 28 Mar and 28 Mar + 10 weeks
' All Fall captures are between 1 Aug and 1 Aug + 13 weeks for 2005-2014
' All Fall captures are between 1 Aug and 1 Aug + 14 weeks for 2015-2019
' Owling has the following periods: same as Fall, any dates after the end of FMMP are classified as Winter
' Winter has 5 periods: Jul to Oct + Nov, Dec, Jan, Feb, Mar + Apr to Jun
' Summer, Nextbox have 2 periods: Jan to May + Jun, Jul + Aug to Dec
'
' Returns
' "aNOV"
' "bDEC"
' "cJAN"
' "dFEB"
' "eMAR"
' "gS1"
' "gS10"
' "hJUN"
' "jJUL"
' "kF1"
' "kF14"
' "mERR"

Public Function toPeriodGeneral(ByVal strSeason As String, datDateEx As Date) As String

10    On Error GoTo Err_label
          
      Dim datDay   As Date
      Dim toPeriod As String
      Dim intWeek As Integer

20    datDay = DateSerial(2000, Month(datDateEx), Day(datDateEx))

30    Select Case strSeason
      Case "Winter"
40        Select Case Month(datDateEx)
          Case 1
50            toPeriod = "cJAN"
60        Case 2
70            toPeriod = "dFEB"
80        Case 3 To 6
90            toPeriod = "eMAR"
100       Case 7 To 11
110           toPeriod = "aNOV"
120       Case 12
130           toPeriod = "bDEC"
140       End Select
150   Case "Spring", "RTHU_Spring"
160       intWeek = Int((datDay - DateSerial(2000, 3, 28)) / 7) + 1
170       If intWeek < 1 Or intWeek > 10 Then
180           toPeriod = "mERR"
190       Else
200           toPeriod = "gS" & Format(intWeek, "00")
210       End If
220   Case "Summer", "Nestbox"

      ' Include 2009-08-04 in period 2
      ' Include 2012-05-05 in period 1

230       Select Case Month(datDateEx)
          Case 1 To 6
240           toPeriod = "hJUN"
250       Case 7 To 12
260           toPeriod = "jJUL"
270       End Select
280   Case "Fall", "RTHU_Fall"
290       intWeek = Int((datDay - DateSerial(2000, 8, 1)) / 7) + 1
300       If Year(datDateEx) < 2015 Then
310           If intWeek < 1 Or intWeek > 13 Then
320               toPeriod = "mERR"
330           Else
340               toPeriod = "kF" & Format(intWeek, "00")
350           End If
360       Else
370           If intWeek < 1 Or intWeek > 14 Then
380               toPeriod = "mERR"
390           Else
400               toPeriod = "kF" & Format(intWeek, "00")
410           End If
420       End If
          
      ' Last day for FMMP 30-Oct before 2015
      '                    6 Nov on or after 2015

430   Case "Owling"
440       If Year(datDateEx) < 2015 Then
450           If datDay <= DateSerial(2000, 10, 30) Then
460               intWeek = Int((datDay - DateSerial(2000, 8, 1)) / 7) + 1
470               If intWeek < 1 Or intWeek > 13 Then
480                   toPeriod = "mERR"
490               Else
500                   toPeriod = "kF" & Format(intWeek, "00")
510               End If
520           Else
530               Select Case Month(datDateEx)
                   Case 1 To 9
540                    toPeriod = "mErr"
550                Case 10, 11
560                    toPeriod = "aNOV"
570                Case 12
580                    toPeriod = "bDEC"
590                End Select
600           End If
610       Else
620           If datDay <= DateSerial(2000, 11, 6) Then
630               intWeek = Int((datDay - DateSerial(2000, 8, 1)) / 7) + 1
640               If intWeek < 1 Or intWeek > 14 Then
650                   toPeriod = "mERR"
660               Else
670                   toPeriod = "kF" & Format(intWeek, "00")
680               End If
690           Else
700               Select Case Month(datDateEx)
                   Case 1 To 10
710                    toPeriod = "mErr"
720                Case 11
730                    toPeriod = "aNOV"
740                Case 12
750                    toPeriod = "bDEC"
760                End Select
770           End If
780       End If
790   Case Else
800       toPeriod = "mERR"
810   End Select

820   toPeriodGeneral = toPeriod

          'DD Error Handler Start
Exit_label:
830       Exit Function
Err_label:
840       Select Case Err.Number
          Case Else
850      Call LogError("basMBO10Year_BirdsOfMBO_Charts", "toPeriodGeneral")
860       End Select
870       Resume Exit_label
          ' DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' toPeriodBirdsOfMBOAbundanceCharts
'---------------------------------------------------------------------------------------
' PRE: strSeason IN ("Winter", "Spring", "Summer", "Fall"
' All Spring captures are between 28 Mar and 28 Mar + 10 weeks
' All Fall captures are between 1 Aug and 1 Aug + 14 weeks
'
' Called from qryMBO10Year_Species
'
' Winter has 5 periods: Jul to Oct + Nov, Dec, Jan, Feb, Mar + Apr to Jun
' Summer has 2 periods: Jan to May + Jun, Jul + Aug to Dec

Public Function toPeriodBirdsOfMBOAbundanceCharts(ByVal strSeason As String, datDateEx As Date) As Integer

10    On Error GoTo Err_label

      Dim datDay   As Date
      Dim toPeriod As Integer

20    datDay = DateSerial(2000, Month(datDateEx), Day(datDateEx))

30    Select Case strSeason
      Case "Winter"
40        Select Case Month(datDateEx)
          Case 7 To 11                          ' Jul - Nov
50            toPeriod = 1
60        Case 12
70            toPeriod = 2                      ' Dec
80        Case 1 To 3
90            toPeriod = 2 + Month(datDateEx)   ' Jan, Feb, Mar
100       Case 4 To 6
110           toPeriod = 5                      ' Apr - Jun
120       End Select
130   Case "Spring"
140       toPeriod = Int((datDay - DateSerial(2000, 3, 28)) / 7) + 1
150       If toPeriod < 1 Then
160           toPeriod = 1
170       End If
180   Case "Summer", "Nestbox"

      ' Include 2009-08-04 in period 2
      ' Include 2012-05-05 in period 1

190       Select Case Month(datDateEx)
          Case 1 To 6
200           toPeriod = 1
210       Case 7 To 12
220           toPeriod = 2
230       End Select
240   Case "Fall"
250       toPeriod = Int((datDay - DateSerial(2000, 8, 1)) / 7) + 1
260       If toPeriod < 1 Then
270           toPeriod = 1
280       End If
290   End Select

300   toPeriodBirdsOfMBOAbundanceCharts = toPeriod

          'DD Error Handler Start
Exit_label:
310       Exit Function
Err_label:
320       Select Case Err.Number
          Case Else
330      Call LogError("basMBO10Year_BirdsOfMBO_Charts", "toPeriodBirdsOfMBOAbundanceCharts")
340       End Select
350       Resume Exit_label
          ' DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' toSeasonBirdsOfMBOAbundanceCharts
'---------------------------------------------------------------------------------------
' Redestribute Owling into Fall or Winter based on the DET date
' For -2015  Winter started on 31 Oct
' For 2016-  Winter started on 7 Nov
'
' Reassign RTHU_Spring to Spring
' Reassign RTHU_Fall to Fall
' Reassign NESTBOX to Summer
'
' Called from qryMBO10Years_BirdsOfMBO_DETSpecies_A

Public Function toSeasonBirdsOfMBOAbundanceCharts(ByVal strSeason As String, datDateEx As Date) As String

10       On Error GoTo Err_label
         
20       Select Case strSeason
         Case "Owling"
             
30            If Year(datDateEx) < 2015 Then
40                If DateSerial(2000, Month(datDateEx), Day(datDateEx)) < DateSerial(2000, 10, 31) Then
50                    strSeason = "Fall"
60                Else
70                    strSeason = "Winter"
80                End If
90            Else
100                If DateSerial(2000, Month(datDateEx), Day(datDateEx)) < DateSerial(2000, 11, 7) Then
110                   strSeason = "Fall"
120               Else
130                   strSeason = "Winter"
140               End If
150           End If
160       Case "RTHU_Fall"
170           strSeason = "Fall"
180       Case "RTHU_Spring"
190           strSeason = "Spring"
200       Case "NESTBOX"
210           strSeason = "Summer"
220       End Select

230       toSeasonBirdsOfMBOAbundanceCharts = strSeason

          'DD Error Handler Start
Exit_label:
240       Exit Function
Err_label:
250       Select Case Err.Number
          Case Else
260            Call LogError("basMBO10Year_BirdsOfMBO_Charts", "toSeasonBirdsOfMBOAbundanceCharts")
270       End Select
280       Resume Exit_label
          ' DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' Load_tbl15YearReport_BirdsOfMBO_Charts_DET_Temp
'---------------------------------------------------------------------------------------
' Called from MBO10YearProgramReportBirdsAtMBO_AbundanceCharts()
'
' Loads tbl15YearReport_BirdsOfMBO_Charts_DET_Temp with the abundance stats from Winter, Spring, Summer, Fall

Public Sub Load_tbl15YearReport_BirdsOfMBO_Charts_DET_Temp(ByVal intYearFirst As Integer, ByVal intYearLast As Integer)

10    On Error GoTo Err_label

' Load tbl15YearReport_BirdsOfMBO_Charts_Temp with the DET info from Winter, Spring, Summer, Fall

20    Call Load_tbl15YearReport_BirdsOfMBO_Charts_Temp(intYearFirst, intYearLast)

' ZAP tbl15YearReport_BirdsOfMBO_Charts_Captures_Temp

30    CurrentDb.Execute "Delete * From tbl15YearReport_BirdsOfMBO_Charts_DET_Temp"

' Most of the following queries are also used for Owling Captures (where the captures are temporarily renamed to DET)

' qry15YearReport_BirdsOfMBO_Charts_YearsPresent_A
' -----------------------------------------------------------
' For each Season x Year x Period x Species, sum the DET (over DateEx)
' -----------------------------------------------------------
' tbl15YearReport_BirdsOfMBO_Charts_Temp
'
' GROUP BY Season
' GROUP BY Period
' GROUP BY Species
' DET = SUM( Nz(DET) )
' SELECT Season, YearEx, Period, Species, DET

' = = = = = = = = = =

' qry15YearReport_BirdsOfMBO_Charts_YearsPresent_B
' ----------------------------------------------------
' For each season x species, counts the number of years for which the total DET for the season x year x species was non-zero
' i.e. count the years in which a species was DETed in a given season x year
' ----------------------------------------------------
' qry15YearReport_BirdsIfMBO_Charts_YearsPresent_A
'
' GROUP BY Season
' GROUP BY Period
' GROUP BY Species
' YearsPresent: Sum(IIf([DET]>0,1,0))
' SELECT Season, Species, Period, YearsPresent

' = = = = = = = = = =

' qry15YearReport_BirdsOfMBO_Charts_CountDETDays_A
' -----------------------------------------------------
' For each season x year x date, sum the DET (over species)
' Only return records for which the sum of the DET was non zero
' -----------------------------------------------------
' tbl15YearReport_BirdsOfMBO_Charts_Temp
'
' GROUP BY Season
' GROUP BY YearEx
' GROUP BY Period
' GROUP BY DateEx
' SumOfDET: SUM DET
' HAVING SumOfDET > 0
' SELECT Season, YearEx, Period, DateEx, SumOfDET

' = = = = = = = = = =

' qry15YearReport_BirdsOfMBO_Charts_CountDETDays_B
' ---------------------------------------------------------------------------------
' For each season x period, count the number of days for which the DET was non-zero
' ---------------------------------------------------------------------------------
' qry15YearReport_BirdsOfMBO_Charts_CountDETDays_A
' GROUP BY Season
' GROUP BY Period
' CountDETDays: Sum(1)
' SELECT Season, Period, CountDETDays

' = = = = = = = = = =

' qry15YearReport_BirdsOfMBO_Charts_TotalDET
' ------------------------------------------------------------------
' For each species x season x period, sums the DET (over year, date)
' ------------------------------------------------------------------
' tbl15YearReport_BirdsOfMBO_Charts_Temp
'
' GROUP BY Season
' GROUP BY Period
' GROUP BY Species
' DET: SUM DET
' SELECT Season, Period, Species, DET

' qry15YearReport_BirdsOfMBO_Charts_DET
' ------------------------------------
' For each season x period x species
'   Select the season, period, species, species group
'   Select Sum Of DET = the sum of the DET (over all days, years)
'   Select YearsPresent = the number of years for which the total DET for the season x period was non-zero.  This will be the same for each species.
'   Select CountDETDays = the number of days, in the season x period, for which the DET was non-zero.  This will be the same for each species.
'   Mean DET = Sum of DET / CountDETDays
'
' tblSpecies x
' qry15YearReport_BirdsOfMBO_Charts_TotalDET x
' qry15YearReport_BirdsIfMBO_Charts_YearsPresent_B
' qry15YearReport_BirdsOfMBO_Charts_CountDETDays_B
'
' GroupEx: SpeciesGroupSpeciesObservedAtMBOID
' MeanDET: [DET]/[CountDETDays]
' ORDER BY AOUOrder
' SELECT Season, Period, Species, DET, CountDETDays, YearsPresent, MeanDET

' qry15YearReport_BirdsOfMBO_Charts_DET_B_Append
' ----------------------------------------------
' qry15YearReport_BirdsOfMBO_Charts_DET
' APPEND TO tbl15YearReport_BirdsOfMBO_Charts_DET_Temp

' SELECT     Season, Species, Period, DET, CountDETDays, YearsPresent, MeanDET
' APPEND TO  Season, Species, Period, DET, CountDETDays, YearsPresent, MeanDET

Dim qdf As DAO.QueryDef

40    Set qdf = CurrentDb.QueryDefs("qry15YearReport_BirdsOfMBO_Charts_DET_B_Append")
50    qdf.Execute


    'DD Error Handler Start
Exit_label:
60        Exit Sub
Err_label:
70        Select Case Err.Number
    Case Else
80       Call LogError("basMBO10Year_BirdsOfMBO_Charts", "load_tbl15YearReport_BirdsOfMBO_Charts_DET_Temp")
90        End Select
100       Resume Exit_label
    ' DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' load_tbl15YearReport_BirdsOfMBO_Charts_Captures_Temp
'---------------------------------------------------------------------------------------
' Load tbl15YearReport_BirdsOfMBO_Charts_Captures_Owling_Temp with Captures info from Owling

Public Sub Load_tbl15YearReport_BirdsOfMBO_Charts_Captures_Temp(ByVal intYearFirst As Integer, ByVal intYearLast As Integer)

10    On Error GoTo Err_label

' Load tbl15YearReport_BirdsOfMBO_Charts_Captures_Temp with the Owling Captures

20    Call Load_tbl15YearReport_BirdsOfMBO_Charts_Temp_With_OwlingCaptures(intYearFirst, intYearLast)

' ZAP tbl15YearReport_BirdsOfMBO_Charts_Captures_Temp

30    CurrentDb.Execute "Delete * From tbl15YearReport_BirdsOfMBO_Charts_Captures_Temp"

' Load tbl15YearReport_BirdsOfMBO_Charts_Captures_Temp

' qry15YearReport_BirdsOfMBO_Charts_Captures_B_Append
' --------------------------------------------
' qry15YearReport_BirdsOfMBO_Charts_DET
' APPEND TO tbl15YearReport_BirdsOfMBO_Charts_Captures_Temp
'
' SELECT     Season, Species, SumOfDET, CountDETDays, YearsPresent, MeanDET
' APPEND TO  Season, Species, SumOfCaptures, CountCaptureDays, CaptureYearsPresent, MeanCaptures


Dim qdf As DAO.QueryDef

40    Set qdf = CurrentDb.QueryDefs("qry15YearReport_BirdsOfMBO_Charts_Captures_B_Append")
50    qdf.Execute

    'DD Error Handler Start
Exit_label:
60        Exit Sub
Err_label:
70        Select Case Err.Number
    Case Else
80       Call LogError("basMBO10Year_BirdsOfMBO_Charts", "Load_tbl15YearReport_BirdsOfMBO_Charts_Captures_Temp")
90        End Select
100       Resume Exit_label
    ' DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' Load_tblMBO10YearProgramReport_Abundance_Temp
'---------------------------------------------------------------------------------------
' Called from MBO10YearProgramReportBirdsAtMBO_AbundanceCharts
'
' FULL OUTER JOIN tbl15YearReport_BirdsOfMBO_Charts_DET_Temp AND tbl15YearReport_BirdsOfMBO_Charts_Captures_Temp
' Load tblMBO10YearProgramReport_Abundance_Temp

Private Sub Load_tblMBO10YearProgramReport_Abundance_Temp(ByVal intYearFirst As Integer, ByVal intYearLast As Integer)

Dim strSQL As String
Dim qdf As DAO.QueryDef
Dim rst As DAO.Recordset
Dim row As Long
Dim strSpecies As String
Dim strSpeciesPrevious As String
Dim dblMeanDET As Double
Dim intYearsPresent As Integer
Dim intAbundance As Integer
Dim strSeason As String
Dim intPeriod As Integer
Dim dblMeanCaptures As Double
Dim intCaptureYearsPresent As Integer
Dim intCapturesAbundance As Integer

Dim intPeriodLastSpring As Integer
Dim intPeriodLastFall As Integer

   On Error GoTo Err_label

intPeriodLastSpring = getPeriodLast_Season("Spring")
intPeriodLastFall = getPeriodLast_Season("Fall")

' Full outer join of tbl15YearReport_BirdsOfMBO_Charts_DET_Temp and tbl15YearReport_BirdsOfMBO_Charts_Captures_Temp

' qry15YearReport_BirdsOfMBO_Charts_A
' -----------------------------------
' tbl15YearReport_BirdsOfMBO_Charts_DET_Temp LEFT OUTER JOIN tbl15YearReport_BirdsOfMBO_Charts_Captures_Temp
'
' SELECT Season, Period, Species, SumOfDET, CountDETDays, YearsPresent, MeanDET, SumOfCaptures, CountCaptureDays, YearsPresentCaptures, MeanCaptures


' qry15YearReport_BirdsOfMBO_Charts_B
' -----------------------------------
' tbl15YearReport_BirdsOfMBO_Charts_Captures_Temp LEFT OUTER JOIN tbl15YearReport_BirdsOfMBO_Charts_DET_Temp
'
' tbl15YearReport_BirdsOfMBO_Charts_DET_Temp.Season IS NULL
'
' SELECT Season, Period, Species, SumOfDET, CountDETDays, YearsPresent, MeanDET, SumOfCaptures, CountCaptureDays, YearsPresentCaptures, MeanCaptures

' qry15YearReport_BirdsOfMBO_Charts_Union
' ---------------------------------------
' qry15YearReport_BirdsOfMBO_Charts_A
' qry15YearReport_BirdsOfMBO_Charts_B

' qry15YearReport_BirdsOfMBO_Charts_C
' -----------------------------------
' qry15YearReport_BirdsOfMBO_Charts_Union x tblSpecies
'
' Species
' Period                      -1..30
' CountDETDays
' YearsPresent
' MeanDET
' CountCaptureDays
' CaptureYearsPresent
' MeanCaptures
' GroupEx
' AOUOrder

' ORBER BY GroupEx, AOS

' = = = = = = = = = =

' ZAP tblMBO10YearProgramReport_Abundance_Temp

DoCmd.SetWarnings False
CurrentDb.Execute "DELETE * FROM tblMBO10YearProgramReport_Abundance_Temp"
DoCmd.SetWarnings True

Dim rstAbundance As DAO.Recordset
Set rstAbundance = CurrentDb.OpenRecordset("tblMBO10YearProgramReport_Abundance_Temp")

' tblMBO10YearProgramReport_Abundance_Temp
' ----------------------------------------
' ID        AutoNumber
' Group     Text                      Species Group when generating a chart from DET sheets
'                                     Nominal groups when generating a chart from an "Abundance" Excel worksheet
' Species   Text
' AOS       Double
' Jan       Long
' Feb
' Mar
' S1
' ...
' S10
' Jun
' Jul
' F1
' ...
' F14
' Nov
' Dec

' = = = = = = = = =



Dim strGroupEx As String

strSQL = "qry15YearReport_BirdsOfMBO_Charts_C"
Set qdf = CurrentDb.QueryDefs(strSQL)
Set rst = qdf.OpenRecordset

row = 1
strSpeciesPrevious = ""

Do While Not rst.EOF

    strSpecies = Nz(rst("Species"))
    
    SysCmd acSysCmdSetStatus, "Load Abundance Table - " & strSpecies
    DoEvents
    
    If strSpecies <> strSpeciesPrevious Then
      
        If strSpeciesPrevious <> "" Then
            rstAbundance.Update
        End If
        rstAbundance.AddNew
        rstAbundance("Species") = strSpecies
        rstAbundance("GroupEx") = Nz(rst("GroupEx"))
        rstAbundance("OrderEx") = Nz(rst("AOUOrder"))

        row = row + 1

        strSpeciesPrevious = strSpecies
    End If
    
    dblMeanDET = Nz(rst("MeanDET"))
    intYearsPresent = Nz(rst("YearsPresent"))
    dblMeanCaptures = Nz(rst("MeanCaptures"))
    intCaptureYearsPresent = Nz(rst("CaptureYearsPresent"))
    strSeason = Nz(rst("Season"))
    intPeriod = Nz(rst("Period"))
    
    intAbundance = getAbundance(dblMeanDET, intYearsPresent, strSeason, intPeriod, intYearFirst, intYearLast)
    If intCaptureYearsPresent > 0 Then
        intCapturesAbundance = getAbundance(dblMeanCaptures, intCaptureYearsPresent, strSeason, intPeriod, intYearFirst, intYearLast)
        If intCapturesAbundance > intAbundance Then
            intAbundance = intCapturesAbundance
        End If
    End If
    
    If intPeriod <> conErr Then
        Select Case strSeason
        Case "Winter"
            Select Case intPeriod
            Case 1
                rstAbundance("NOV") = intAbundance
            Case 2
                rstAbundance("DEC") = intAbundance
            Case 3
                rstAbundance("JAN") = intAbundance
            Case 4
                rstAbundance("FEB") = intAbundance
            Case 5
                rstAbundance("MAR") = intAbundance
            End Select
        Case "Spring"
            rstAbundance("S" & CStr(intPeriod)) = intAbundance
        Case "Summer"
            Select Case intPeriod
            Case 1
                rstAbundance("JUN") = intAbundance
            Case 2
                rstAbundance("JUL") = intAbundance
            End Select
        Case "Fall"
            rstAbundance("F" & CStr(intPeriod)) = intAbundance
        End Select
    Else
        Call LogError("basMBO10Year_BirdsOfMBO_Charts", "Load_tblMBO10YearProgramReport_ABundance_Temp", "Invalid period")
        GoTo Exit_label
    End If

    rst.MoveNext
Loop
rstAbundance.Update
rst.Close
Set rst = Nothing



    'DD Error Handler Start
Exit_label:
    Exit Sub
Err_label:
    Select Case Err.Number
    Case Else
   Call LogError("basMBO10Year_BirdsOfMBO_Charts", "Load_tblMBO10YearProgramReport_ABundance_Temp")
    End Select
    Resume Exit_label
    ' DD Error Handler End

End Sub

''---------------------------------------------------------------------------------------
'' LoadAbundanceTable tblMBO10YearProgramReport_Abundance_Temp
''---------------------------------------------------------------------------------------
''
'' Called from MBO10YearProgramReportSpeciesObservedAtMBO()
'
'Private Sub LoadAbundanceTable(ByVal intyearFirst As Integer, ByVal intYearLast As Integer)
'
'      Dim strSQL As String
'      Dim qdf As dao.QueryDef
'      Dim rst As dao.Recordset
'      Dim row As Long
'      Dim strSpecies As String
'      Dim strSpeciesPrevious As String
'      Dim dblMeanDET As Double
'      Dim intYearsPresent As Integer
'      Dim intAbundance As Integer
'      Dim strSeason As String
'      Dim intPeriod As Integer
'
'      Dim intPeriodLastSpring As Integer
'      Dim intPeriodLastFall As Integer
'
'   On Error GoTo Err_label
'
'   On Error GoTo Err_label
'
'10    intPeriodLastSpring = getPeriodLast_Season("Spring")
'20    intPeriodLastFall = getPeriodLast_Season("Fall")
'
'      ' ZAP tblMBO10YearProgramReport_Abundance_Temp
'
'40    DoCmd.SetWarnings False
'50    CurrentDb.Execute "DELETE * FROM tblMBO10YearProgramReport_Abundance_Temp"
'60    DoCmd.SetWarnings True
'
'      Dim rstAbundance As dao.Recordset
'70    Set rstAbundance = CurrentDb.OpenRecordset("tblMBO10YearProgramReport_Abundance_Temp")
'
'' tblMBO10YearProgramReport_Abundance_Temp
'' ----------------------------------------
'' ID        AutoNumber
'' Group     Text                      Species Group when generating a chart from DET sheets
''                                     Nominal groups when generating a chart from an "Abundance" Excel worksheet
'' Species   Text
'' AOS       Double
'' Jan       Long
'' Feb
'' Mar
'' S1
'' ...
'' S10
'' Jun
'' Jul
'' F1
'' ...
'' F14
'' Nov
'' Dec
'
'' qryMBO10Year_BirdsOfMBO_Abundance_Charts_A
'' ------------------------------------------
'' Same as tblMBO10Year_BirdsOfMBO_Abundance_Charts_Temp
'' but with only the pseudospecies for the 5.1 Abundance Charts and the Species Appendix
'' -------------------------------------------------------------------------------------
'' tblMBO10Year_BirdsOfMBO_Abundance_Charts_Temp
''
'' WHERE Species NOT IN ("TRFL","PAWA","USCA")
'' SpeciesEx: Species
'
'' = = = = = = = = = =
'
'' qryMBO10Year_BirdsOfMBO_Abundance_Charts_B
'' ------------------------------------------
'' Same as tblMBO10Year_BirdsOfMBO_Abundance_Charts_Temp
'' but with only the pseudospecies for the 5.1 Abundance Charts and the Species Appendix
'' and TRFL+ has been renamed to TRFL
'' -------------------------------------------------------------------------------------
'' tblMBO10Year_BirdsOfMBO_Abundance_Charts_Temp
''
'' Species: iif(SpeciesEx = "TRFL+", "TRFL", SpeciesEx)
'
'' = = = = = = = = =
'
'' qryMBO10YearProgramReportAbundance_YearsPresent_A
'' -------------------------------------------------------
'' Sums the DET over each Season x Year x Period x Species
'' -------------------------------------------------------
'' qryMBO10Year_BirdsOfMBO_Abundance_Charts_B
''
'' GROUP BY Season
'' GROUP BY Period
'' GROUP BY Species
'' SumOfDET = SUM( Nz(DET) )
'' SELECT Season, YearEx, Period, Species, SumOfDET
'
'' = = = = = = = = = =
'
'' qryMBO10YearProgramReportAbundance_YearsPresent_B
'' ----------------------------------------------------
'' For each season x period x species, counts the number of years for which the total DET for the season x year x period x species was non-zero
'' i.e. count the years in which a species was DETed in a given season x year x period
'' ----------------------------------------------------
'' qryMBO10YearProgramReportAbundance_YearsPresent_A
''
'' GROUP BY Season
'' GROUP BY Period
'' GROUP BY Species
'' YearsPresent: Count(IIf([SumOfDET]>0,1,0))
'' SELECT Season, Period, Species, YearsPresent
'
'' = = = = = = = = = =
'
'' qryMBO10YearProgramReportAbundance_CountDETDays_A
'' -----------------------------------------------------
'' For each season x year x period x date, sum the DET (over species)
'' Only return records for which the sum of the DET was non zero
'' -----------------------------------------------------
'' qryMBO10Year_BirdsOfMBO_Abundance_Charts_B
''
'' GROUP BY Season
'' GROUP BY YearEx
'' GROUP BY Period
'' GROUP BY DateEx
'' SumOfDET: SUM DET
'' HAVING SumOfDET > 0
'' SELECT Season, YearEx, Period, DateEx, SumOfDET
'
'' = = = = = = = = = =
'
'' qryMBO10YearProgramReportAbundance_CountDETDays_B
'' ---------------------------------------------------------------------------------
'' For each season x period, count the number of days for which the DET was non-zero
'' ---------------------------------------------------------------------------------
'' qryMBO10YearProgramReportAbundance_CountDETDays_A
''
'' GROUP BY Season
'' GROUP BY Period
'' CountDETDays: Count(1)
'' SELECT Season, Period, CountDETDays
'
'' = = = = = = = = = =
'
'' qryMBO10YearProgramReportAbundance_TotalDET
'' -------------------------------------------------------
'' For each species x season x year x period, sums the DET
'' -------------------------------------------------------
'' qryMBO10YearProgramReportAbundance_YearsPresent_A
''
'' GROUP BY Season
'' GROUP BY Year
'' GROUP BY Period
'' GROUP BY Species
'' SumOfDET: SUM SumOfDET
'' SELECT Season, Period, Species, SumOfDET
'
'' qryMBO10YearProgramReportAbundance_A
'' ------------------------------------
'' For each season x period x species
''   Select the season, period, species, species group
''   Select Sum Of DET = the sum of the DET (over all days, years)
''   Select YearsPresent = the number of years for which the total DET for the season x period was non-zero.  This will be the same for each species.
''   Select CountDETDays = the number of days, in the season x period, for which the DET was non-zero.  This will be the same for each species.
''   Mean DET = Sum of DET / CountDETDays
''
'' tblSpecies
'' qryMBO10YearProgramReportAbundabce_TotalDET
'' qryMBO10YearProgramReportAbundance_YearsPresent_B
'' qryMBO10YearProgramReportAbundance_CountDETDays_B
''
'' GroupEx: SpeciesGroupSpeciesObservedAtMBOID
'' MeanDET: [SumOfDET]/[CountDETDays]
'' ORDER BY AOUOrder
'' SELECT Season, Period, GroupEx, Species, SumOfDET, CountDETDays, YearsPresent, MeanDET, AOUOrder
'
'
'Dim strGroupEx As String
'
'80    strSQL = "qryMBO10YearProgramReportAbundance_A"
'90    Set qdf = CurrentDb.QueryDefs(strSQL)
'100   Set rst = qdf.OpenRecordset
'
'110   row = 1
'120   strSpeciesPrevious = ""
'
'130   Do While Not rst.EOF
'
'140       strSpecies = Nz(rst("Species"))
'
'150       SysCmd acSysCmdSetStatus, "Load Abundance Table - " & strSpecies
'160       DoEvents
'
'170       If strSpecies <> strSpeciesPrevious Then
'
'180           If strSpeciesPrevious <> "" Then
'190               rstAbundance.Update
'200           End If
'210           rstAbundance.AddNew
'220           rstAbundance("Species") = strSpecies
'333           rstAbundance("GroupEx") = Nz(rst("GroupEx"))
'230           rstAbundance("OrderEx") = Nz(rst("AOUOrder"))
'
'240           row = row + 1
'
'250           strSpeciesPrevious = strSpecies
'260       End If
'
'270       dblMeanDET = Nz(rst("MeanDET"))
'280       intYearsPresent = Nz(rst("YearsPresent"))
'290       strSeason = Nz(rst("Season"))
'300       intPeriod = Nz(rst("Period"))
'
'310       intAbundance = getAbundance(dblMeanDET, intYearsPresent, strSeason, intPeriod, intyearFirst, intYearLast)
'
'320       Select Case strSeason
'          Case "Winter"
'330           Select Case intPeriod
'              Case 1
'340               rstAbundance("Nov") = intAbundance
'350           Case 2
'360               rstAbundance("Dec") = intAbundance
'370           Case 3
'380               rstAbundance("Jan") = intAbundance
'390           Case 4
'400               rstAbundance("Feb") = intAbundance
'410           Case 5
'420               rstAbundance("Mar") = intAbundance
'430            End Select
'440       Case "Spring"
'450           If intPeriod <= intPeriodLastSpring Then
'460               rstAbundance("S" & intPeriod) = intAbundance
'470           End If
'480       Case "Summer"
'490           Select Case intPeriod
'              Case 1
'500               rstAbundance("Jun") = intAbundance
'510           Case 2
'520               rstAbundance("Jul") = intAbundance
'530           End Select
'540       Case "Fall"
'550           If intPeriod <= intPeriodLastFall Then
'560               rstAbundance("F" & intPeriod) = intAbundance
'570           End If
'580       End Select
'
'590       rst.MoveNext
'600   Loop
'610   rstAbundance.Update
'620   rst.Close
'630   Set rst = Nothing
'
'
'    'DD Error Handler Start
'Exit_label:
'    Exit Sub
'Err_label:
'    Select Case Err.Number
'    Case Else
'         Call LogError("basMBO10Year_BirdsOfMBO_Charts", "LoadAbundanceTable")
'    End Select
'    Resume Exit_label
'    ' DD Error Handler End
'
'End Sub

'---------------------------------------------------------------------------------------
' Legend_Top
'---------------------------------------------------------------------------------------
'
' Output a word table for the legend

Private Sub Legend_Top(ByRef doc As Word.Document, _
    ByVal lngPageWidth As Long, ByVal lngLeftMargin As Long, ByVal lngRightMargin As Long, _
    ByVal lngXSpeciesStart As Long, ByVal lngXSpeciesWidth As Long, _
    ByVal lngNumberPeriods As Long, ByVal lngXPeriodWidth As Long, _
    ByVal intYearFirst As Integer, ByVal intYearLast As Integer)


20    On Error GoTo Err_label

Dim intNumYearsDividedByFive As Integer
Dim strNumYearsDividedByFive As String
Dim strNumYearsDividedByFivePlusOne As String

intNumYearsDividedByFive = Round((intYearLast - intYearFirst + 1) / 5)
strNumYearsDividedByFive = IntegertoString(intNumYearsDividedByFive)
strNumYearsDividedByFivePlusOne = IntegertoString(intNumYearsDividedByFive + 1)

         
      Dim range As Word.range
      Dim row As Long
      Dim col As Long

'30    With doc.PageSetup
'40        .LeftMargin = lngLeftMargin
'50        .RightMargin = lngRightMargin
'60        .TopMargin = doc.Application.InchesToPoints(0.79)
'70        .BottomMargin = doc.Application.InchesToPoints(0.79)
'80    End With
          
30    Set range = MoveInsertionPointToEndOfDocument(doc.Application, doc)
40    range.InsertParagraphAfter

50    Set range = MoveInsertionPointToEndOfDocument(doc.Application, doc)

60    doc.Tables.Add range:=range, NumRows:=6, NumColumns:=3, DefaultTableBehavior:=wdWord9TableBehavior, _
          AutoFitBehavior:=wdAutoFitFixed

70    range.Expand (wdTable)
80    With range.Tables(1)

90      .TopPadding = doc.Application.CentimetersToPoints(0)
100     .BottomPadding = doc.Application.CentimetersToPoints(0)
110     .LeftPadding = doc.Application.CentimetersToPoints(0)
120     .RightPadding = doc.Application.CentimetersToPoints(0)
130     .Spacing = 0
140     .AllowPageBreaks = True
150     .AllowAutoFit = True

' The legend table are 6 rows, namely "Very rare", "Rare", "Uncommon", "Fairly Common", "Common", "Abundant"
' The legend table has 3 columns: the row label, a picture of the line that represents an abundance level, a description of the abundance level

160       For row = 1 To 6
170           For col = 2 To 3
180             .Cell(row, col).LeftPadding = doc.Application.CentimetersToPoints(0.2)
190             .Cell(row, col).RightPadding = doc.Application.CentimetersToPoints(0.2)
200           Next
210       Next
       
220       .columns(1).Width = doc.Application.CentimetersToPoints(2.75)
230       .columns(2).Width = 20
240       .columns(3).Width = lngXSpeciesWidth + lngNumberPeriods * lngXPeriodWidth - .columns(1).Width - .columns(2).Width

250       .Cell(1, 1).range.Text = "Very rare"
260       .Cell(2, 1).range.Text = "Rare"
270       .Cell(3, 1).range.Text = "Uncommon"
280       .Cell(4, 1).range.Text = "Fairly common"
290       .Cell(5, 1).range.Text = "Common"
300       .Cell(6, 1).range.Text = "Abundant"
          
310       .Cell(1, 3).range.Text = "Generally occurring in at most " & strNumYearsDividedByFive & " year" & IIf(intNumYearsDividedByFive = 1, "", "s")
320       .Cell(2, 3).range.Text = "Generally occurring in at least " & strNumYearsDividedByFivePlusOne & " years, but with a mean daily count <1"
330       .Cell(3, 3).range.Text = "Generally occurring in at least " & strNumYearsDividedByFivePlusOne & " years, but with a mean daily count between 1 and 4.9"
340       .Cell(4, 3).range.Text = "Generally occurring in at least " & strNumYearsDividedByFivePlusOne & " years, but with a mean daily count between 5 and 9.9 "
350       .Cell(5, 3).range.Text = "Generally occurring in at least " & strNumYearsDividedByFivePlusOne & " years, but with a mean daily count between 10 and 49.9"
360       .Cell(6, 3).range.Text = "Generally occurring in at least " & strNumYearsDividedByFivePlusOne & " years, but with a mean daily count >50"
          
370       For row = 1 To 6
380           .Cell(row, 3).range.ParagraphFormat.Alignment = wdAlignParagraphLeft
390       Next
              
400       For row = 1 To 6
410           .Cell(row, 1).range.ParagraphFormat.Style = "ddMultiYearAbundanceTopLegendAbundanceLabel"
420           .Cell(row, 3).range.ParagraphFormat.Style = "ddMultiYearAbundanceTopLegendAbundanceImage"
430           .Cell(row, 3).range.ParagraphFormat.Style = "ddMultiYearAbundanceTopLegendAbundanceDescription"
440           .Cell(row, 1).VerticalAlignment = wdCellAlignVerticalCenter
450           .Cell(row, 3).VerticalAlignment = wdCellAlignVerticalCenter
460       Next
              
          ' Draw borders
          
470       For row = 1 To 6
480           .Rows(row).Borders(wdBorderTop).LineStyle = wdLineStyleSingle
490           For col = 1 To 3
500               .Cell(row, col).Borders(wdBorderLeft).LineStyle = wdLineStyleSingle
510           Next
520           .Cell(row, 3).Borders(wdBorderRight).LineStyle = wdLineStyleSingle
530       Next
540       .Rows(6).Borders(wdBorderBottom).LineStyle = wdLineStyleSingle
          
          Dim shpCanvas As Word.Shape
          Dim sh As Word.Shape
          
550       For row = 1 To 6
          
560           Set shpCanvas = doc.Shapes.AddCanvas(Left:=0, Top:=0, Width:=10, Height:=15, Anchor:=.Cell(row, 2).range)
                 
570           Set sh = shpCanvas.CanvasItems.AddLine( _
              BeginX:=0, _
              BeginY:=7, _
              EndX:=10, _
              EndY:=7)
580           sh.Line.Weight = row
590           sh.Line.ForeColor = lngAbundanceLineColour(row)
          
600       Next

610   End With

    'DD Error Handler Start
Exit_label:
620       Exit Sub
Err_label:
630       Select Case Err.Number
    Case Else
640      Call LogError("basMBO10Year_BirdsOfMBO_Charts", "Legend_Top")
650       End Select
660       Resume Exit_label
    ' DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' TableWidth
'---------------------------------------------------------------------------------------
'
' Get, in points, the X position and width of the species column
' Get the number of periods
' Get, in points, the width of each period column

Private Sub TableWidth(ByRef doc As Word.Document, _
    ByVal intPeriodLastSpring As Integer, ByVal intPeriodLastFall As Integer, _
    ByRef lngXSpeciesStart As Long, ByRef lngXSpeciesWidth As Long, _
    ByRef lngNumberPeriods As Long, ByRef lngXPeriodWidth As Long)

10       On Error GoTo Err_label

20    On Error GoTo Err_label

'      Dim intPeriodLastSpring As Integer
'      Dim intPeriodLastFall As Integer
'
'20    intPeriodLastSpring = getPeriodLast_Season("Spring")
'30    intPeriodLastFall = getPeriodLast_Season("Fall")

    Dim lngPageWidth As Long
    Dim lngLeftMargin As Long
    Dim lngRightMargin As Long

30    lngPageWidth = doc.PageSetup.PageWidth
40    lngLeftMargin = doc.PageSetup.LeftMargin
50    lngRightMargin = doc.PageSetup.RightMargin

' There are periods for Jan, Feb, Mar, each week of SMMP, Jun, Jul, each week of FMMP, Nov, Dec

60    lngNumberPeriods = 7 + intPeriodLastSpring + intPeriodLastFall
70    lngXSpeciesStart = 0
80    lngXSpeciesWidth = con_lngXSpeciesWidth
90    lngXPeriodWidth = (lngPageWidth - lngLeftMargin - lngRightMargin - lngXSpeciesWidth) / lngNumberPeriods - 0.1

    'DD Error Handler Start
Exit_label:
100       Exit Sub
Err_label:
110       Select Case Err.Number
    Case Else
120      Call LogError("basMBO10Year_BirdsOfMBO_Charts", "TableWidth")
130       End Select
140       Resume Exit_label
    ' DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' WordOutput_SpeciesGroup
'---------------------------------------------------------------------------------------

Private Sub WordOutput_SpeciesGroup(ByRef doc As Word.Document, _
    ByVal lngPageWidth As Long, ByVal lngLeftMargin As Long, ByVal lngRightMargin As Long, _
    ByVal lngXSpeciesStart As Long, ByVal lngXSpeciesWidth As Long, _
    ByVal lngNumberPeriods As Long, ByVal lngXPeriodWidth As Long)

10    On Error GoTo Err_label

20    With doc.PageSetup
30        .LeftMargin = lngLeftMargin
40        .RightMargin = lngRightMargin
50        .TopMargin = doc.Application.InchesToPoints(0.79)
60        .BottomMargin = doc.Application.InchesToPoints(0.79)
70    End With

      ' Loop over the groups
      
      Dim strSQL As String
80    strSQL = "SELECT GroupEx FROM tblMBO10YearProgramReport_Abundance_Temp  GROUP BY GroupEx ORDER BY GroupEx"

      Dim rst As DAO.Recordset
90    Set rst = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)
100   Do While Not rst.EOF
          
         Dim intGroupEx As Integer
         
110      If IsNumeric(Nz(rst("GroupEx"))) Then
120           intGroupEx = Nz(rst("GroupEx"))
130      Else
140         MsgBox "The group numbers must be integers", vbOKOnly, "Abundance Charts"
150         GoTo Exit_label
160     End If

170     SysCmd acSysCmdSetStatus, CStr(intGroupEx)
         
180      Call WordOutput_Detail(doc, lngPageWidth, lngLeftMargin, lngRightMargin, _
                                lngXSpeciesStart, lngXSpeciesWidth, lngNumberPeriods, lngXPeriodWidth, intGroupEx)
         
190       rst.MoveNext
200   Loop
210   rst.Close
220   Set rst = Nothing

230   SysCmd acSysCmdClearStatus

          'DD Error Handler Start
Exit_label:
240       Exit Sub
Err_label:
250       Select Case Err.Number
          Case Else
260      Call LogError("basMBO10Year_BirdsOfMBO_Charts", "WordOutput_SpeciesGroup")
270       End Select
280       Resume Exit_label
          ' DD Error Handler End
    End Sub

'---------------------------------------------------------------------------------------
' WordOutput_Detail
'---------------------------------------------------------------------------------------
' Draw an abundance picture for a given group of species
' The picture is of a table. The table has a header row and a column of labels.
' The header row of the table contains the names of the periods: Nov, Dec, Jan, Feb, Mar, S1, ..., Jun, Jul, F1, ..., Nov, Dec
' Each row is for a species
' The label column contains the species code
' Each cell contains a horizontal line. The colour and the weight (=> width) of the line represents the abundance of a species in a period

' If strGroup isn't "", then lngSpeciesGroupSpeciesObservedAtMBOID is ignored, and the procedure uses the data from the
'      tblMBO10YearProgramReport_Abundance_Temp table for the specified group
'
' Called from WordOutput_Detail()
'
' The measurements are in points

Private Sub WordOutput_Detail(ByRef doc As Word.Document, _
    ByVal lngPageWidth As Long, ByVal lngLeftMargin As Long, ByVal lngRightMargin As Long, _
    ByVal lngXSpeciesStart As Long, ByVal lngXSpeciesWidth As Long, _
    ByVal lngNumberPeriods As Long, ByVal lngXPeriodWidth As Long, _
    ByVal intGroupEx As Integer)

10    On Error GoTo Err_label

          Dim strWhere As String
20        strWhere = "GroupEx = " & intGroupEx

          Dim intCountSpecies As Integer
30        intCountSpecies = DCount("*", "tblMBO10YearProgramReport_Abundance_Temp", strWhere)

Dim intPeriodLastSpring As Integer
Dim intPeriodLastFall As Integer

40    intPeriodLastSpring = 10
50    intPeriodLastFall = 14

Dim lngCanvasWidth As Long
60    lngCanvasWidth = lngXSpeciesWidth + lngNumberPeriods * lngXPeriodWidth + 2

Dim lngXPeriodStart As Long
70    lngXPeriodStart = lngXSpeciesStart + lngXSpeciesWidth

Dim lngYSpeciesStart As Long
Dim lngYSpeciesHeight As Long

80    lngYSpeciesStart = 10
90    lngYSpeciesHeight = 10

Dim lngCanvasHeight As Long
100   lngCanvasHeight = intCountSpecies * lngYSpeciesHeight + 20

Dim lngLineWidth As Long
110   lngLineWidth = 1

Dim row As Long
Dim col As Long
Dim sh As Word.Shape
Dim lngStart1 As Long
Dim lngEnd1 As Long
Dim range As Word.range
Dim range1 As Word.range

120   Set range = MoveInsertionPointToEndOfDocument(doc.Application, doc)
130   range.InsertAfter CStr(intGroupEx)
140   range.InsertParagraphAfter
150   range.ParagraphFormat.Style = "ddBody"
160   Set range = MoveInsertionPointToEndOfDocument(doc.Application, doc)
170   range.InsertParagraphAfter
180   range.ParagraphFormat.Style = "ddBody"
190   Set range = MoveInsertionPointToEndOfDocument(doc.Application, doc)

200   lngStart1 = range.start
210   lngEnd1 = range.End
220   Set range1 = doc.range(lngStart1, lngEnd1)

' Create a canvas big enough to contain the picture

Dim shpCanvas As Word.Shape

230   Set shpCanvas = doc.Shapes.AddCanvas(Left:=0, Top:=0, Width:=lngCanvasWidth, Height:=lngCanvasHeight, Anchor:=range1)

240   shpCanvas.WrapFormat.AllowOverlap = False
250   shpCanvas.WrapFormat.Type = wdWrapInline

' Heading for the species column

260   Set sh = shpCanvas.CanvasItems.AddTextbox( _
    msoTextOrientationHorizontal, _
    Left:=0, _
    Top:=0, _
    Width:=lngXSpeciesWidth, _
    Height:=lngYSpeciesHeight)
270   sh.TextFrame.TextRange.Text = "Species"
280   sh.TextFrame.TextRange.Font.Size = 8
290   sh.TextFrame.TextRange.ParagraphFormat.Alignment = wdAlignParagraphLeft
300   sh.Line.Weight = 0
310   sh.Line.Visible = msoFalse
320   sh.TextFrame.MarginLeft = 2
330   sh.TextFrame.MarginRight = 0
340   sh.TextFrame.MarginTop = 0
350   sh.TextFrame.MarginBottom = 0
360   sh.Fill.ForeColor = vbBlack
370   sh.TextFrame.TextRange.Font.Color = RGB(255, 255, 255)
        
' Headings for the period columns
        
Dim strHeading As String

380   For col = colPeriodFirst To colPeriodLast
390       Set sh = shpCanvas.CanvasItems.AddTextbox( _
                msoTextOrientationHorizontal, _
                Left:=lngXPeriodStart + lngXPeriodWidth * (col - colPeriodFirst), _
                Top:=0, _
                Width:=lngXPeriodWidth, _
                Height:=lngYSpeciesHeight)
      
400   Select Case col
      Case colNOV:
410       strHeading = "Nov"
420   Case colDEC:
430       strHeading = "Dec"
440   Case colJAN:
450       strHeading = "Jan"
460   Case colFEB:
470       strHeading = "Feb"
480   Case colMAR:
490       strHeading = "Mar"
500   Case colSpringFirst To colSpringLast
510       strHeading = "S" & col - colSpringFirst + 1
520   Case colJUN:
530       strHeading = "Jun"
540   Case colJUL:
550       strHeading = "Jul"
560   Case colFallFirst To colFallLast
570       strHeading = "F" & col - colFallFirst + 1
580   End Select
          
590       sh.TextFrame.TextRange.Text = strHeading
600       sh.TextFrame.TextRange.Font.Size = 8
610       sh.TextFrame.TextRange.ParagraphFormat.Alignment = wdAlignParagraphCenter
620       sh.Line.Weight = 0
630       sh.Line.Visible = msoFalse
640       sh.TextFrame.MarginLeft = 0
650       sh.TextFrame.MarginRight = 0
660       sh.TextFrame.MarginTop = 0
670       sh.TextFrame.MarginBottom = 0
680       sh.Fill.ForeColor = vbBlack
690       sh.TextFrame.TextRange.Font.Color = RGB(255, 255, 255)

700   Next

' qryMBO10YearProgramReport_SpeciesObservedAtMBO
' ----------------------------------------------
' abundance info for each species in a MBO Multi-Year Program Report Species Group for Species Observed at MBO
' ---------------------------------------------------------------------------------------------------------------------------
' tblMBO10YearProgramReport_Abundance_Temp x tblSpecies x tblMBO10Year_SpeciesGroups_SpeciesObservedAtMBO
'
' SELECT * FROM tblMBO10YearProgramReport_Abundance_Temp, SpeciesGroup, SpeciesGroupSpeciesObservedAtMBOID, SpeciesGroup, AOUOrder


Dim strSQL As String

710   strSQL = _
            "SELECT * " & _
            " FROM tblMBO10YearProgramReport_Abundance_Temp " & _
            " WHERE GroupEx = " & intGroupEx & _
            " ORDER BY OrderEx"


Dim rst As DAO.Recordset
720   Set rst = CurrentDb.OpenRecordset(strSQL)

' Loop over species

730   row = 0
        
740   Do While Not rst.EOF
      
    ' row is the current row# - rows are numbered from 1 to lngSpeciesPerPage
    ' the header row is row# 0

750       row = row + 1

    ' Every second row, draw a row of very light blue filled rectangles

760       If row Mod 2 = 0 Then
770     Set sh = shpCanvas.CanvasItems.AddShape( _
            msoShapeRectangle, _
            Left:=0, _
            Top:=lngYSpeciesStart + (row - 1) * lngYSpeciesHeight, _
            Width:=lngXPeriodStart + lngXPeriodWidth * lngNumberPeriods, _
            Height:=lngYSpeciesHeight)
780     sh.Fill.ForeColor = con_lngColourAlternate
790     sh.Line.Visible = msoFalse
800       End If

    ' Row label
    
810       Set sh = shpCanvas.CanvasItems.AddTextbox( _
        msoTextOrientationHorizontal, _
        Left:=0, _
        Top:=lngYSpeciesStart + (row - 1) * lngYSpeciesHeight, _
        Width:=lngXSpeciesWidth, _
        Height:=lngYSpeciesHeight)
820       sh.TextFrame.TextRange.Text = rst("Species")
830       sh.TextFrame.TextRange.Font.Size = 9
840       sh.Line.Weight = 0
850       sh.Line.Visible = msoFalse
860       sh.TextFrame.MarginLeft = 2
870       sh.TextFrame.MarginRight = 0
880       sh.TextFrame.MarginTop = 0
890       sh.TextFrame.MarginBottom = 0
900       If row Mod 2 = 0 Then
910     sh.Fill.ForeColor = con_lngColourAlternate
920       End If

    ' Draw abundance line

930       For col = colPeriodFirst To colPeriodLast
940     Select Case col
            Case colNOV
950             lngLineWidth = Nz(rst("Nov"))
960         Case colDEC
970             lngLineWidth = Nz(rst("Dec"))
980         Case colJAN
990             lngLineWidth = Nz(rst("Jan"))
1000        Case colFEB
1010            lngLineWidth = Nz(rst("Feb"))
1020        Case colMAR
1030            lngLineWidth = Nz(rst("Mar"))
1040        Case colSpringFirst To colSpringLast
1050            lngLineWidth = Nz(rst("S" & col - colSpringFirst + 1))
1060        Case colJUN
1070            lngLineWidth = Nz(rst("Jun"))
1080        Case colJUL
1090            lngLineWidth = Nz(rst("Jul"))
1100        Case colFallFirst To colFallLast
1110            lngLineWidth = Nz(rst("F" & col - colFallFirst + 1))
1120    End Select
1130    If lngLineWidth > 0 Then
1140        Set sh = shpCanvas.CanvasItems.AddLine( _
                BeginX:=lngXPeriodStart + (col - colPeriodFirst) * lngXPeriodWidth, _
                BeginY:=lngYSpeciesHeight / 2 + lngYSpeciesStart + (row - 1) * lngYSpeciesHeight, _
                EndX:=lngXPeriodStart + (col - colPeriodFirst + 1) * lngXPeriodWidth, _
                EndY:=lngYSpeciesHeight / 2 + lngYSpeciesStart + (row - 1) * lngYSpeciesHeight)
1150        sh.Line.Weight = lngLineWidth * 1.5
1160        sh.Line.ForeColor = lngAbundanceLineColour(lngLineWidth)
            
1170    End If
1180      Next
    
1190      rst.MoveNext
1200  Loop
1210  rst.Close
1220  Set rst = Nothing

' Draw white vertical lines between periods
' Draw light blue vertical lines between seasons

1230  For col = colPeriodFirst To colPeriodLast

    ' Draw a white vertical line to the left of each period

1240      Set sh = shpCanvas.CanvasItems.AddLine( _
        BeginX:=lngXPeriodStart + lngXPeriodWidth * (col - colPeriodFirst), _
        BeginY:=0, _
        EndX:=lngXPeriodStart + lngXPeriodWidth * (col - colPeriodFirst), _
        EndY:=lngYSpeciesStart * row + lngYSpeciesHeight - 1)
1250      sh.Line.Style = msoLineSingle
1260      sh.Line.Weight = 1
1270      sh.Line.ForeColor = RGB(255, 255, 255)
    
    ' Draw a light blue vertical line to the left of each season
    
1280      Select Case col
    Case colPeriodFirst, colSpringFirst, colJUN, colFallFirst, colNOV
1290    Set sh = shpCanvas.CanvasItems.AddLine( _
            BeginX:=lngXPeriodStart + lngXPeriodWidth * (col - colPeriodFirst), _
            BeginY:=lngYSpeciesStart, _
            EndX:=lngXPeriodStart + lngXPeriodWidth * (col - colPeriodFirst), _
            EndY:=lngYSpeciesStart * row + lngYSpeciesHeight - 1)
1300    sh.Line.Style = msoLineSingle
1310    sh.Line.Weight = 1
1320    sh.Line.ForeColor = RGB(161, 190, 237)
1330      End Select
    
1340  Next

' Draw a light blue vertical left border

1350  Set sh = shpCanvas.CanvasItems.AddLine( _
    BeginX:=0, _
    BeginY:=lngYSpeciesStart, _
    EndX:=0, _
    EndY:=lngYSpeciesStart * row + lngYSpeciesHeight - 1)
1360  sh.Line.Style = msoLineSingle
1370  sh.Line.Weight = 1
1380  sh.Line.ForeColor = RGB(161, 190, 237)

' Draw a light blue vertical right border

1390  Set sh = shpCanvas.CanvasItems.AddLine( _
    BeginX:=lngXPeriodStart + lngXPeriodWidth * (colPeriodLast - colPeriodFirst + 1), _
    BeginY:=lngYSpeciesStart, _
    EndX:=lngXPeriodStart + lngXPeriodWidth * (colPeriodLast - colPeriodFirst + 1), _
    EndY:=lngYSpeciesStart * row + lngYSpeciesHeight - 1)
1400  sh.Line.Style = msoLineSingle
1410  sh.Line.Weight = 1
1420  sh.Line.ForeColor = RGB(161, 190, 237)

'    Delete the last page break
'
'    doc.range(lngStart_before_page_break, range.End).Find.Execute FindText:="^m", ReplaceWith:="", Replace:=wdReplaceAll



    'DD Error Handler Start
Exit_label:
1430      Exit Sub
Err_label:
1440      Select Case Err.Number
    Case Else
1450     Call LogError("basMBO10Year_BirdsOfMBO_Charts", "WordOutput_Detail")
1460      End Select
1470      Resume Exit_label
    ' DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' WordGenerateTableAbundance
'---------------------------------------------------------------------------------------
' entry:  range = a collapsed range that is the insertion point for the table
' exit:   range = range that includes the table

Private Sub WordGenerateTableAbundance( _
    ByRef doc As Word.Document, ByRef range As Word.range, _
    ByVal lngPageWidth As Long, ByVal lngLeftMargin As Long, ByRef lngRightMargin As Long, _
    ByVal lngXSpeciesStart As Long, ByVal lngXSpeciesWidth As Long, _
    ByVal lngNumberPeriods As Long, ByVal lngXPeriodWidth As Long)
          

10       On Error GoTo Err_label

20       On Error GoTo Err_label
          
      '20        doc.Application.Visible = True
          
      Dim intPeriodLastSpring As Integer
      Dim intPeriodLastFall As Integer

30    intPeriodLastSpring = getPeriodLast_Season("Spring")
40    intPeriodLastFall = getPeriodLast_Season("Fall")

      Dim row As Integer
      Dim col As Integer

50    On Error GoTo Err_label

      Dim colAbundanceFirst As Integer
      Dim colAbundanceLast As Integer

      'With doc.PageSetup
      '    .LeftMargin = lngLeftMargin
      '    .RightMargin = lngRightMargin
      '    .TopMargin = doc.Application.InchesToPoints(0.79)
      '    .BottomMargin = doc.Application.InchesToPoints(0.79)
      'End With

60    colAbundanceFirst = 2
70    colAbundanceLast = 8 + intPeriodLastSpring + intPeriodLastFall

80    doc.Tables.Add range:=range, NumRows:=9, NumColumns:=colAbundanceLast, DefaultTableBehavior:=wdWord9TableBehavior, _
          AutoFitBehavior:=wdAutoFitFixed
          
90    range.Expand (wdTable)
100   With range.Tables(1)

110       .Rows.Alignment = wdAlignRowLeft

120       For col = 1 To colAbundanceLast
130           .Cell(1, col).VerticalAlignment = wdCellAlignVerticalCenter
140       Next

150       .Rows.WrapAroundText = False

160       .LeftPadding = doc.Application.InchesToPoints(0)
170       .RightPadding = doc.Application.InchesToPoints(0)
180       .TopPadding = doc.Application.InchesToPoints(0.02)
190       .Spacing = 0
200       .AllowPageBreaks = True
210       .AllowAutoFit = False
          
220       .columns(1).Width = lngXSpeciesWidth
230       For col = colAbundanceFirst To colAbundanceLast
240           .columns(col).Width = lngXPeriodWidth
250       Next

260       row = 1
          
270       .Cell(row, 1).range.InsertAfter "COUNT OF SPECIES OBSERVED DURING EACH TIME PERIOD:"
280       .Cell(row, 1).Merge .Cell(row, colPeriodLast)
290       .Cell(row, 1).range.Shading.BackgroundPatternColor = RGB(166, 166, 166)
300       .Cell(row, 1).range.ParagraphFormat.Style = "ddMultiYearAbundanceSummaryTitle"
          
310       row = 2

320       .Cell(row, colSpecies).range.Text = "Species"
330       .Cell(row, colNOV).range.Text = "Nov"
340       .Cell(row, colDEC).range.Text = "Dec"
350       .Cell(row, colJAN).range.Text = "Jan"
360       .Cell(row, colFEB).range.Text = "Feb"
370       .Cell(row, colMAR).range.Text = "Mar"
380       For col = colSpringFirst To colSpringLast
390           .Cell(row, col).range.Text = "S" & (col - colSpringFirst + 1)
400       Next
410       .Cell(row, colJUN).range.Text = "Jun"
420       .Cell(row, colJUL).range.Text = "Jul"
430       For col = colFallFirst To colFallLast
440           .Cell(row, col).range.Text = "F" & (col - colFallFirst + 1)
450       Next

        
          ' Format Header Row
          
460       Call FormatWordTableRowAsHeader(.Rows(2), "ddAbundanceHeaderRow1")
          
          ' All cells are centred
          
470       .range.ParagraphFormat.Alignment = wdAlignParagraphCenter
          
          ' Draw horizontal lines
          
480       For row = 1 To 9
490           .Rows(row).Borders(wdBorderTop).LineStyle = wdLineStyleSingle
500       Next
510       .Rows(9).Borders(wdBorderBottom).LineStyle = wdLineStyleSingle

          ' Draw vertical lines
          
520       For row = 3 To 9
530           For col = colAbundanceFirst To colAbundanceLast
540               .Cell(row, col).Borders(wdBorderLeft).LineStyle = wdLineStyleDot
550           Next
          
560           .Cell(row, colSpecies).Borders(wdBorderLeft).LineStyle = wdLineStyleSingle
570           .Cell(row, colPeriodFirst).Borders(wdBorderLeft).LineStyle = wdLineStyleSingle
580           .Cell(row, colMAR).Borders(wdBorderRight).LineStyle = wdLineStyleSingle
590           .Cell(row, colJUN).Borders(wdBorderLeft).LineStyle = wdLineStyleSingle
600           .Cell(row, colJUL).Borders(wdBorderRight).LineStyle = wdLineStyleSingle
610           .Cell(row, colPeriodLast).Borders(wdBorderRight).LineStyle = wdLineStyleSingle
              
620           .Cell(row, colPeriodFirst).Borders(wdBorderLeft).LineWidth = wdLineWidth150pt
630           .Cell(row, colMAR).Borders(wdBorderRight).LineWidth = wdLineWidth150pt
640           .Cell(row, colJUN).Borders(wdBorderLeft).LineWidth = wdLineWidth150pt
650           .Cell(row, colJUL).Borders(wdBorderRight).LineWidth = wdLineWidth150pt
660           .Cell(row, colPeriodLast).Borders(wdBorderRight).LineWidth = wdLineWidth150pt
670       Next

680       row = 3
690       .Cell(row, 1).range.Text = "V. rare"
700       row = row + 1
710       .Cell(row, 1).range.Text = "Rare"
720       row = row + 1
730       .Cell(row, 1).range.Text = "Uncom."
740       row = row + 1
750       .Cell(row, 1).range.Text = "F. com."
760       row = row + 1
770       .Cell(row, 1).range.Text = "Common"
780       row = row + 1
790       .Cell(row, 1).range.Text = "Abundant"
800       row = row + 1
810       .Cell(row, 1).range.Text = "TOTAL"
          
820       For row = 3 To 9
830           .Cell(row, 1).range.ParagraphFormat.Style = "ddMultiYearAbundanceSummaryAbundanceLabel"
840       Next

850       For row = 3 To 9
860           For col = colAbundanceFirst To colAbundanceLast
870               .Cell(row, col).range.ParagraphFormat.Style = "ddMultiYearAbundanceSummaryData"
880           Next
890       Next

900       .Rows(9).Shading.BackgroundPatternColor = RGB(217, 217, 217)

910   End With

    'DD Error Handler Start
Exit_label:
920       Exit Sub
Err_label:
930       Select Case Err.Number
    Case Else
940      Call LogError("basMBO10Year_BirdsOfMBO_Charts", "WordGenerateTableAbundance")
950       End Select
960       Resume Exit_label
    ' DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' getAbundance
'
' This works for 5 or more years
'---------------------------------------------------------------------------------------

Private Function getAbundance(ByVal MeanDET As Double, ByVal YearsPresent As Integer, _
   ByVal strSeason As String, ByVal intPeriod As Integer, ByVal intYearFirst As Integer, ByVal intYearLast As Integer) As Integer


10    On Error GoTo Err_label
         
      Dim intYearsRange As Integer
         
20    If strSeason = "Fall" And intPeriod = 14 Then
40            If intYearFirst < 2015 Then intYearFirst = 2015
60    End If

70    intYearsRange = intYearLast - intYearFirst + 1
80    If intYearsRange < 5 Then
90        getAbundance = conAbundanceUnknown
100   ElseIf YearsPresent <= Round(0.2 * intYearsRange) Then
110       getAbundance = conAbundanceVeryRare
120   ElseIf MeanDET < 1 Then
130       getAbundance = conAbundanceRare
140   ElseIf MeanDET < 5 Then
150       getAbundance = conAbundanceUncommon
160   ElseIf MeanDET < 10 Then
170       getAbundance = conAbundanceFairlyCommon
180   ElseIf MeanDET < 50 Then
190       getAbundance = conAbundanceCommon
200   Else
210       getAbundance = conAbundanceAbundant
220   End If

    'DD Error Handler Start
Exit_label:
    Exit Function
Err_label:
    Select Case Err.Number
    Case Else
         Call LogError("basMBO10Year_BirdsOfMBO_Charts", "getAbundance")
    End Select
    Resume Exit_label
    ' DD Error Handler End
          
End Function

Private Sub Excel_Output( _
    ByVal intYearFirst As Integer, ByVal intYearLast As Integer, _
    ByRef oExcel As Excel.Application, _
    ByRef oBook As Excel.Workbook, _
    Optional ByVal fOwling As Boolean = False, _
    Optional ByVal fDebug As Boolean = False)
          
      Dim oSheet As Excel.Worksheet

      ' intAbundanceCounters( abundance category, column )
      ' use abundance category 7 for the grand totals

10    On Error GoTo Err_label
         
      ' The columns are SpeciesGroup, Species, NOV, DEC, JAN, FEB, MAR, S1 to Smax, JUN, JUL, F1 to Fmax, Species, NOV, DEC, JAN, FEB, MAR, S1 to Smax, JUN, JUL, F1 to F14

      Dim intPeriodLastSpring As Integer
      Dim intPeriodLastFall As Integer

20    intPeriodLastSpring = 10
30    intPeriodLastFall = 14

      Dim colSpeciesGroup As Integer
      Dim colSpecies As Integer
      Dim colPeriodFirst As Integer
      Dim colNOV As Integer
      Dim colDEC As Integer
      Dim colJAN As Integer
      Dim colFEB As Integer
      Dim colMAR As Integer
      Dim colSpringFirst As Integer
      Dim colSpringLast As Integer
      Dim colJUN As Integer
      Dim colJUL As Integer
      Dim colFallFirst As Integer
      Dim colFallLast As Integer
      Dim colPeriodLast As Integer
      Dim colDetailsBase As Integer

40    colSpeciesGroup = 1
50    colSpecies = 2
60    colPeriodFirst = colSpecies + 1
70    colNOV = colPeriodFirst
80    colDEC = colNOV + 1
90    colJAN = colDEC + 1
100   colFEB = colJAN + 1
110   colMAR = colFEB + 1
120   colSpringFirst = colMAR + 1
130   colSpringLast = colSpringFirst + intPeriodLastSpring - 1
140   colJUN = colSpringLast + 1
150   colJUL = colJUN + 1
160   colFallFirst = colJUL + 1
170   colFallLast = colFallFirst + intPeriodLastFall - 1
180   colPeriodLast = colFallLast
190   colDetailsBase = colPeriodLast + 1

200   Set oSheet = InsertSheet(oBook, "Global")

210   If fOwling Then
220       oSheet.Name = "Abundance Owls"
230   Else
240       oSheet.Name = "Abundance"
250   End If

      Dim row As Long
      Dim col As Integer

      Dim strSQL As String
      Dim qdf As DAO.QueryDef
      Dim rst As DAO.Recordset

      Dim intPeriod As Integer   '  the periods are absolute report periods 0..30

260   With oSheet

270   row = 1

280   .Cells(row, colSpeciesGroup) = "Group"
290   .Cells(row, colSpecies) = "Species"
300   .Cells(row, colJAN) = "JAN"
310   .Cells(row, colFEB) = "FEB"
320   .Cells(row, colMAR) = "MAR"
330   .Cells(row, colJUN) = "JUN"
340   .Cells(row, colJUL) = "JUL"
350   .Cells(row, colNOV) = "NOV"
360   .Cells(row, colDEC) = "DEC"
370   For intPeriod = 1 To intPeriodLastSpring
380       .Cells(row, colSpringFirst + intPeriod - 1) = "S" & intPeriod
390   Next
400   For intPeriod = 1 To intPeriodLastFall
410       .Cells(row, colFallFirst + intPeriod - 1) = "F" & intPeriod
420   Next

      ' Copy the headings from colSpecies .. colPeriodLast => colPeriodLast + 1 ..

430   For col = colSpecies To colPeriodLast
440       .Cells(row, col + colPeriodLast - 1) = .Cells(row, col)
450   Next

460   SysCmd acSysCmdSetStatus, "Abundance Charts Export to Excel"
470   DoEvents

480   If fOwling Then
490       strSQL = "qry15YearReport_BirdsofMBO_Charts_Captures_Excel"
500   Else
510       strSQL = "qry15YearReport_BirdsofMBO_Charts_DET_Excel"
520   End If

530   Set qdf = CurrentDb.QueryDefs(strSQL)
540   Set rst = qdf.OpenRecordset

      Dim intSpeciesGroup As Integer
      Dim strSpecies As String
      Dim strSpeciesPrevious As String
      Dim dblMeanDET As Double
      Dim intYearsPresent As Integer
      Dim intAbundance As Integer
      Dim strSeason As String
      Dim lngDET As Long
      Dim intCountDETDays As Integer

550   row = 1
560   strSpeciesPrevious = ""

      Dim intYearsRange As Integer
570   intYearsRange = intYearLast - intYearFirst + 1

580   Do While Not rst.EOF

590       strSpecies = Nz(rst("Species"))
600       intSpeciesGroup = Nz(rst("SpeciesGroup"))
          
610       SysCmd acSysCmdSetStatus, "Abundance Charts Export to Excel - " & strSpecies
620       DoEvents
          
630       If strSpecies <> strSpeciesPrevious Then
640           strSpeciesPrevious = strSpecies
650           row = row + 1
660           .Cells(row, colSpeciesGroup) = intSpeciesGroup
670           .Cells(row, colSpecies) = strSpecies
680           .Cells(row, colPeriodLast + 1) = strSpecies
690       End If
700       lngDET = Nz(rst("DET"))
710       dblMeanDET = Nz(rst("MeanDET"))
720       intYearsPresent = Nz(rst("YearsPresent"))
730       strSeason = Nz(rst("Season"))
740       intPeriod = Nz(rst("Period"))
750       intCountDETDays = Nz(rst("CountDETDays"))

760       intAbundance = getAbundance(dblMeanDET, intYearsPresent, strSeason, intPeriod, intYearFirst, intYearLast)

770       Select Case strSeason
          Case "Winter"
780           col = colNOV + intPeriod - 1
790       Case "Spring"
800           col = colSpringFirst + intPeriod - 1
810       Case "Summer"
820               col = colJUN + intPeriod - 1
830       Case "Fall"
840               col = colFallFirst + intPeriod - 1
850       End Select
          
860       If intAbundance <> conAbundanceUnknown Then
870           .Cells(row, col) = intAbundance
880           .Cells(row, colDetailsBase + col - 2) = "m=" & _
                  FormatNumberEnglish(dblMeanDET, 1) & "[" & lngDET & "/" & intCountDETDays & "], y=" & intYearsPresent
890       End If
        
          Dim lngColour As Long
900       Select Case intAbundance

          Case conAbundanceVeryRare
910           lngColour = RGB(178, 161, 199)
920             Case conAbundanceRare
930           lngColour = RGB(0, 176, 240)
940             Case conAbundanceUncommon
950           lngColour = RGB(146, 208, 80)
960             Case conAbundanceFairlyCommon
970           lngColour = vbYellow
980             Case conAbundanceCommon
990           lngColour = RGB(255, 192, 0)
1000            Case conAbundanceAbundant
1010          lngColour = vbRed
1020      End Select
1030      .Cells(row, col).Interior.Color = lngColour

1040      rst.MoveNext
1050  Loop
1060  rst.Close
1070  Set rst = Nothing

1080  .range(.columns(colPeriodFirst), .columns(colPeriodLast)).HorizontalAlignment = xlCenter
1090  .range(.columns(colPeriodLast + 2), .columns(colPeriodLast + 2 + colPeriodLast - colPeriodFirst)).HorizontalAlignment = xlCenter
1100  .range(.columns(1), .columns(65)).AutoFit

1110  .range("C2").Select
1120  oExcel.ActiveWindow.FreezePanes = True

1130  End With

1140  Set oSheet = Nothing

          'DD Error Handler Start
Exit_label:
1150      Exit Sub
Err_label:
1160      Select Case Err.Number
          Case Else
1170     Call LogError("basMBO10Year_BirdsOfMBO_Charts", "Excel_Output")
1180      End Select
1190      Resume Exit_label
          ' DD Error Handler End

End Sub
