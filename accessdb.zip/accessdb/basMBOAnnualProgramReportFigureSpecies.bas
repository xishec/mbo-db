'---------------------------------------------------------------------------------------
' Module    : basMBOAnnualProgramReportFigureSpecies
' Author    : David Davey
'---------------------------------------------------------------------------------------

Option Compare Database
Option Explicit


'---------------------------------------------------------------------------------------
' MBOAnnualProgramReportFigureSpecies
' fld = DET, Banded, Census
'
'---------------------------------------------------------------------------------------
' Figure Species

Public Sub MBOAnnualProgramReportFigureSpecies( _
    ByRef fValid As Boolean, _
    ByVal intYear As Integer, _
    ByVal strLocation As String, _
    ByVal strProgram As String, _
    ByVal strSeason As String, _
    ByRef wd As Word.Application, _
    ByRef doc As Word.Document, _
    ByRef oExcel As Excel.Application, _
    ByRef oBook As Excel.Workbook, _
    ByVal fld As String)

10    On Error GoTo Err_label

      ' Word - captions

      Dim range As Word.range

20    Set range = MoveInsertionPointToEndOfDocument(wd, doc)
30    range.InsertParagraphAfter

40    Select Case fld
      Case "Banded"
50        If strSeason = "Spring" Then
60            Call InsertTableCaptionXX(wd, doc, "Figure", _
                "4.2", _
                "Daily and running 7-day mean of species banded per day throughout spring " & intYear & ".", _
                "Daily and running 7-day mean of species banded per day throughout spring " & intYear)
70        Else
80            Call InsertTableCaptionXX(wd, doc, "Figure", _
                "6.2", _
                "Daily and running 7-day mean of species banded per day throughout fall " & intYear & ".", _
                "Daily and running 7-day mean of species banded per day throughout fall " & intYear)
90        End If
100   Case "DET"
110       If strSeason = "Spring" Then
120           Call InsertTableCaptionXX(wd, doc, "Figure", _
                "4.4", _
                "Daily species count and running 7-day mean of species observed throughout spring " & intYear & ".", _
                "Daily species count and running 7-day mean of species observed throughout spring " & intYear)
130       Else
140           Call InsertTableCaptionXX(wd, doc, "Figure", _
                "6.4", _
                "Daily species count and running 7-day mean of species observed throughout fall " & intYear & ".", _
                "Daily species count and running 7-day mean of species observed throughout fall " & intYear)
150       End If
160   Case "Census"
170   If strSeason = "Spring" Then
180       Call InsertTableCaptionXX(wd, doc, "Figure", _
              "4.3", _
              "Daily species count and running 7-day mean of species recorded on census throughout spring " & intYear & ".", _
              "Daily species count and running 7-day mean of species recorded on census throughout spring " & intYear)
190       Else
200       Call InsertTableCaptionXX(wd, doc, "Figure", _
              "6.3", _
              "Daily species count and running 7-day mean of species recorded on census throughout fall " & intYear & ".", _
              "Daily species count and running 7-day mean of species recorded on census throughout fall " & intYear)
210       End If
220   End Select

230   Set range = MoveInsertionPointToEndOfDocument(wd, doc)
240   range.InsertParagraphAfter


      'DD Error Handler Start
Exit_label:
250        Exit Sub
Err_label:
260        Select Case Err.Number
           Case Else
270       Call LogError("basMBOAnnualProgramReportFigureSpecies", "MBOAnnualProgramReportFigureSpecies")
280        End Select
290        Resume Exit_label
      'DD Error Handler End
End Sub
