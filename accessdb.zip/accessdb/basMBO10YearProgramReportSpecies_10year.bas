'---------------------------------------------------------------------------------------
'Module:      basMBO10YearProgramReportSpecies
'Author:      David Davey
'---------------------------------------------------------------------------------------
' Code used in the 10-year report
'
' Appendix D - Species
' Appendix D - Species TRFL
'
' For each species, there 5 tables (but, empty tables are deleted)
' Table 1 = Observed Summary
'       2 = Observed Winter + Spring
'       3 = Observed Summer + Fall
'       4 = Banded Winter + Spring
'       5 = Banded Summer + Fall
'
' Also generates an Excel worksheet ( Species or TRFL )
'
'Option Compare Database
'Option Explicit
'
' Statistics
'
'Const conDET As Integer = 0
'Const conBND As Integer = 1
'
'Const conStatSeasonFirst As Integer = 0
'Const conStatSeasonPeak As Integer = 1
'Const conStatSeasonLast As Integer = 2
'Const conStatSeasonSpan As Integer = 3
'Const conStatSeasonDays As Integer = 4
'Const conStatSeasonHigh As Integer = 5
'Const conStatSeasonTotal As Integer = 6
' Const conStatPeriodBirds As Integer = 7
'
'Const colSpringFirst As Integer = 4
'Const colSpringPeak As Integer = 5
'Const colSpringLast As Integer = 6
'Const colSpringSpan As Integer = 7
'Const colSpringDays As Integer = 8
'Const colSpringHigh As Integer = 9
'Const colSpringTotal As Integer = 10
'Const colFallFirst As Integer = 11
'Const colFallPeak As Integer = 12
'Const colFallLast As Integer = 13
'Const colFallSpan As Integer = 14
'Const colFallDays As Integer = 15
'Const colFallHigh As Integer = 16
'Const colFallTotal As Integer = 17
'
'Const conWinter As Integer = 0
'Const conSpring As Integer = 1
'Const conSummer As Integer = 2
'Const conFall As Integer = 3
'
'Private intYearFirst As Integer
'Private intYearLast As Integer
'Private strLocation As String
'Private strSeason As String
'Private fld As Integer
' Private strStat As String
'Private fDebug As Boolean
'
'Private dblStatPeriod() As Double
'Private dblStatSeason() As Double
'
'Private lngSpringFirstTotal As Long
'Private lngFallFirstTotal As Long
'
'Private lngSpringFirstCount As Long
'Private lngFallFirstCount As Long
'
'Private lngSpringLastTotal As Long
'Private lngFallLastTotal As Long
'Private lngSpringLastCount As Long
'Private lngFallLastCount As Long
'
'Private lngSpringHighTotal As Long
'Private lngSpringHighCount As Long
'Private lngFallHighTotal As Long
'Private lngFallHighCount As Long
'
'Private lngSpringTotalTotal As Long ' For a species, Spring Total DET
'Private lngSpringTotalCount As Long ' For a species, Spring Total ???
'Private lngFallTotalTotal As Long   ' For a species, Fall Total DET
'Private lngFallTotalCount As Long   ' For a species, Fall Total ???
'
'Private lngSpringPeakTotal As Long
'Private lngSpringPeakCount As Long
'Private lngFallPeakTotal As Long
'Private lngFallPeakCount As Long
'
'Private lngSpringSpeciesDETDaysTotal As Long
'Private lngSpringDETDaysTotal As Long
'Private lngSpringDETDaysCount As Long
'
'Private lngFallSpeciesDETDaysTotal As Long
'Private lngFallDETDaysTotal As Long
'Private lngFallDETDaysCount As Long
'
'
''---------------------------------------------------------------------------------------
'' MBO10YearProgramReportSpecies_NESTBOX
''---------------------------------------------------------------------------------------
'
'Public Sub MBO10YearProgramReportSpecies_NESTBOX( _
'    ByRef fValid As Boolean, _
'    ByVal intYearFirst As Integer, _
'    ByVal intYearLast As Integer, _
'    ByVal strLocation As String, _
'    ByRef wd As Word.Application, _
'    ByRef doc As Word.Document, _
'    ByRef oExcel As Excel.Application, _
'    ByRef oBook As Excel.Workbook, _
'    ByVal fDebug As Boolean)
'
'' Nestbox worksheet
'
'' qryMBO10YearProgramReportSpecies_Nestbox_A
'' ------------------------------------------
'' Program = "Nestlings"
'' Location = [argLocation]
'' DateEx
'' Species
'' Banded
'' Repeats
'' Returns
'' DET
'' YearEx = Year([DateEx])
'
'' qryMBO10YearProgramReportSpecies_Nestbox_B
'' ------------------------------------------
'' qryMBO10YearProgramReportSpecies_Nestbox_A x tblPrograms (joined by YearEx)
'' Location
'' DateEx
'' Species
'' Banded
'' Repeats
'' Returns
'' DET = Nz([Banded])+nz([Repeats])+nz([Returns])
'' WHERE MonitoringProgramSeason = "Summer"
'' Program = tblPrograms.Program
'
'' tblMBO10YearProgramReportSpecies_Temp
'' -------------------------------------
'' Same structure as tblMBO10YearProgramReportSpecies
'
'
'' qryMBO10YearProgramReportSpecies_Nestbox_Append
'' -----------------------------------------------
''
'
'' qryMBO10YearProgramReportSpecies_Nestbox_C
'' ------------------------------------------
'' tblMBO10YearProgramReportSpecies_Temp
''
'' GROUP BY Season
'' GROUP BY YearEx
'' GROUP BY Period
'' GROUP BY DateEx
'' GROUP BY Species
'' DET = SUM DET
'' Banded = SUM Banded
'' Returns = SUM Returns
'' Repeats = SUM Repeats
'
'' qryMBO10YearProgramReportSpecies_Nestbox_Append_B
'' -------------------------------------------------
'' tblMBO10YearProgramReportSpecies_Temp
'' append to tblMBO10YearProgramReportSpecies
'
'' Delete tblMBO10YearProgramReportSpecies_Temp
'
'10    On Error GoTo Err_label
'
'20    DoCmd.SetWarnings False
'30    On Error Resume Next
'40    DoCmd.DeleteObject acTable = acDefault, "tblMBO10YearProgramReportSpecies_Temp"
'50    On Error GoTo Err_label
'60    DoCmd.SetWarnings True
'
'' Copy tblMBO10YearProgramReportSpecies => tblMBO10YearProgramReportSpecies_Temp
'
'70    DoCmd.CopyObject NewName:="tblMBO10YearProgramReportSpecies_Temp", _
'    SourceObjectType:=acTable, _
'    SourceObjectName:="tblMBO10YearProgramReportSpecies"
'
'' Just keep the Nestbox species EABL, RWBL, HOWR, HOSP, TRES, EAKI
'
'Dim strSQL As String
'
'80    strSQL = "DELETE * FROM tblMBO10YearProgramReportSpecies_Temp WHERE " & _
'    " Species NOT IN ('EABL','RWBL', 'HOWR', 'HOSP', 'TRES', 'EAKI' )"
'90    CurrentDb.Execute strSQL
'
'' Append the Nestbox records
'
'Dim qdf As DAO.QueryDef
'
'100   Set qdf = CurrentDb.QueryDefs("qryMBO10YearProgramReportSpecies_Nestbox_Append")
'110   qdf.Parameters("argLocation").value = strLocation
'120   qdf.Parameters("argYearFirst").value = intYearFirst
'130   qdf.Parameters("argYearLast").value = intYearLast
'140   qdf.Execute
'
'' Merge the Summer records
'
'150   CurrentDb.Execute "DELETE * FROM tblMBO10YearProgramReportSpecies"
'
'160   Set qdf = CurrentDb.QueryDefs("qryMBO10YearProgramReportSpecies_Nestbox_Append_B")
'170   qdf.Execute
'
'180   Call MBO10YearProgramReportSpecies( _
'          intYearFirst, intYearLast, strLocation, _
'          wd, doc, oExcel, oBook, fDebug, "NESTBOX")
'
''DD Error Handler Start
'Exit_label:
'190        Exit Sub
'Err_label:
'200        Select Case Err.Number
'     Case Else
'210       Call LogError("basMBO10YearProgramReportSpecies_v2", "MBO10YearProgramReportSpecies_NESTBOX")
'220        End Select
'230        Resume Exit_label
''DD Error Handler End
'
'End Sub
'
'---------------------------------------------------------------------------------------
' MBO10YearProgramReportSpecies_NESTBOX
'---------------------------------------------------------------------------------------
'
'
'---------------------------------------------------------------------------------------
' MBO10YearProgramReportSpecies_TRFL
'---------------------------------------------------------------------------------------
'
'Public Sub MBO10YearProgramReportSpecies_TRFL( _
'    ByRef fValid As Boolean, _
'    ByVal intYearFirst As Integer, _
'    ByVal intYearLast As Integer, _
'    ByVal strLocation As String, _
'    ByRef wd As Word.Application, _
'    ByRef doc As Word.Document, _
'    ByRef oExcel As Excel.Application, _
'    ByRef oBook As Excel.Workbook, _
'    ByVal fDebug As Boolean)
'
'10    On Error GoTo Err_label
'
'      Dim qdf As DAO.QueryDef
'
'20    CurrentDb.Execute "DELETE * FROM tblMBO10YearProgramReportSpecies"
'
'30    Set qdf = CurrentDb.QueryDefs("qryMBO10YearProgramReportSpecies_Append_TRFL_WIFL_ALFL")
'40    qdf.Parameters("argLocation").value = strLocation
'50    qdf.Parameters("argYearFirst").value = intYearFirst
'60    qdf.Parameters("argYearLast").value = intYearLast
'70    qdf.Execute
'
'80    Call MBO10YearProgramReportSpecies( _
'          intYearFirst, intYearLast, strLocation, _
'          wd, doc, oExcel, oBook, fDebug, "TRFL")
'
'      ' DD Error Handler Start
'Exit_label:
'90         Exit Sub
'Err_label:
'100        Select Case Err.Number
'           Case Else
'110             Call LogError("basMBO10YearProgramReportSpecies", "MBO10YearProgramReportSpecies_TRFL")
'120        End Select
'130        Resume Exit_label
'      ' DD Error Handler End
'
'End Sub
'
'---------------------------------------------------------------------------------------
' MBO10YearProgramReportSpecies
'---------------------------------------------------------------------------------------
'
'Public Sub MBO10YearProgramReportSpecies( _
'    ByVal argYearFirst As Integer, _
'    ByVal argYearLast As Integer, _
'    ByVal argLocation As String, _
'    ByRef wd As Word.Application, _
'    ByRef doc As Word.Document, _
'    ByRef oExcel As Excel.Application, _
'    ByRef oBook As Excel.Workbook, _
'    ByVal arg_debug As Boolean, _
'    Optional ByVal strSpecialCase = "")
'
'10    On Error GoTo Err_label
'
'       Save Parameters
'
'20    intYearFirst = argYearFirst
'30    intYearLast = argYearLast
'40    strLocation = argLocation
'50    fDebug = arg_debug
'
'40          If fDebug Then
'50              oExcel.Visible = True
'60              wd.Visible = True
'70          End If
'
'      Dim lngStart As Long
'      Dim docRange As Word.range
'
'      Dim lngEnd As Long
'
'      Dim oSheet As Excel.Worksheet
'
'60    Set oSheet = InsertSheet(oBook, "Global")
'
'70    Select Case strSpecialCase
'      Case "TRFL"
'80        oSheet.Name = "TRFL"
'90    Case "NESTBOX"
'100       oSheet.Name = "Species-Nestbox"
'110   Case Else
'120       oSheet.Name = "Species"
'130   End Select
'
'140   With oSheet
'
'150   .Columns(colSpringFirst).NumberFormat = "mmm d"
'160   .Columns(colSpringLast).NumberFormat = "mmm d"
'170   .Columns(colFallFirst).NumberFormat = "mmm d"
'180   .Columns(colFallLast).NumberFormat = "mmm d"
'190   .Columns(colSpringPeak).NumberFormat = "mmm d"
'200   .Columns(colFallPeak).NumberFormat = "mmm d"
'
'       We need a list of the pseudo-species to be processed
'       Loop over all pseudo-species DET > 0 or BND > 0
'
'      Dim strSQL As String
'      Dim qdf As DAO.QueryDef
'      Dim rst As DAO.Recordset
'
'      Dim strSpecies As String
'      Dim fld As Integer
'      Dim intYear As Integer
'      Dim p As Integer
'
'       qryMBO10YearProgramReportSpecies_Species
'       ----------------------------------------
'       List of pseudo-species
'       ---------------------------------------------
'       tblMBO10YearProgramReportSpecies x tblSpecies
'       Group By Species
'       Season In ("Winter","Spring","Summer","Fall")
'       Order By AOUOrder
'       Report Species, SpeciesEnglish, SpeciesFrench, SpeciesScientific
'
'
'210    strSQL = "qryMBO10YearProgramReportSpecies_Species"
'
'            strSQL = "qryMBO10YearProgramReportSpecies_Species_HOLA"  ' for debugging
'            wd.Visible = True ' for debugging
'
'220   Set qdf = CurrentDb.QueryDefs(strSQL)
'230   Set rst = qdf.OpenRecordset
'
'240   If rst.EOF Then
'250       .Cells(1, 4) = "No records"
'260   Else
'
'           Header row 1
'
'270       .Cells(1, 4) = "Spring"
'280       .Cells(1, 11) = "Fall"
'290       .range(.Cells(1, 4), .Cells(1, 10)).Merge
'300       .range(.Cells(1, 11), .Cells(1, 17)).Merge
'
'310       .Cells(1, toColFromStatPeriod("Winter", 1)) = "Winter"
'320       .Cells(1, toColFromStatPeriod("Spring", 1)) = "Spring"
'330       .Cells(1, toColFromStatPeriod("Summer", 1)) = "Summer"
'340       .Cells(1, toColFromStatPeriod("Fall", 1)) = "Fall"
'350       .range(.Cells(1, toColFromStatPeriod("Winter", 1)), .Cells(1, toColFromStatPeriod("Winter", 6))).Merge
'360       .range(.Cells(1, toColFromStatPeriod("Spring", 1)), .Cells(1, toColFromStatPeriod("Spring", 11))).Merge
'370       .range(.Cells(1, toColFromStatPeriod("Summer", 1)), .Cells(1, toColFromStatPeriod("Summer", 3))).Merge
'380       .range(.Cells(1, toColFromStatPeriod("Fall", 1)), .Cells(1, toColFromStatPeriod("Fall", 14))).Merge
'
'           Header row 2
'
'390       .Cells(2, 1) = "Species"
'400       .Cells(2, 2) = "DET or Banded"
'410       .Cells(2, 3) = "Year"
'420       .Cells(2, 4) = "First"
'430       .Cells(2, 5) = "Peak"
'440       .Cells(2, 6) = "Last"
'450       .Cells(2, 7) = "Span"
'460       .Cells(2, 8) = "# Days"
'470       .Cells(2, 9) = "High"
'480       .Cells(2, 10) = "Total"
'490       .Cells(2, 11) = "First"
'500       .Cells(2, 12) = "Peak"
'510       .Cells(2, 13) = "Last"
'520       .Cells(2, 14) = "Span"
'530       .Cells(2, 15) = "# Days"
'540       .Cells(2, 16) = "High"
'550       .Cells(2, 17) = "Total"
'560       .Cells(2, 18) = "Nov"
'570       .Cells(2, 19) = "Dec"
'580       .Cells(2, 20) = "Jan"
'590       .Cells(2, 21) = "Feb"
'600       .Cells(2, 22) = "Mar"
'610       .Cells(2, 23) = "Winter"
'          Dim col As Integer
'
'620       col = 24
'630       For p = 1 To 10
'640           .Cells(2, col) = "S" & p
'650           col = col + 1
'660       Next
'
'670       .Cells(2, col) = "Spring"
'680       col = col + 1
'690       .Cells(2, col) = "Jun"
'700       col = col + 1
'710       .Cells(2, col) = "Jul"
'720       col = col + 1
'730       .Cells(2, col) = "Summer"
'740       col = col + 1
'
'750       For p = 1 To 13
'760           .Cells(2, col) = "F" & p
'770           col = col + 1
'780       Next
'790       .Cells(2, col) = "Fall"
'
'          Dim row As Long
'800       row = 3
'
'          Dim cntSpecies As Long
'          Dim cntTotalSpecies As Long
'
'810       cntSpecies = 1
'
'820       rst.MoveLast
'830       cntTotalSpecies = rst.RecordCount
'840       rst.MoveFirst
'
'          Dim datStartTime As Date
'          Dim datNowTime As Date
'          Dim lngTimeInMilliseconds As Long
'
'850       Do While Not rst.EOF
'860           strSpecies = Nz(rst("Species"))
'
'870           DoEvents
'
'880           SysCmd acSysCmdSetStatus, strSpecies & " " & cntSpecies & " of  " & cntTotalSpecies
'890           cntSpecies = cntSpecies + 1
'
'850             If fDebug Then
'860               If cntSpecies < 30 Or cntSpecies > 40 Then GoTo Next_Species
'870             End If
'
'900           If fDebug Then
'910               datStartTime = Now()
'920           End If
'
'930           If fDebug Then
'940               lngTimeInMilliseconds = CLng((Now() - datStartTime) * 24 * 60 * 60 * 1000)
'950               Debug.Print strSpecies & " " & cntSpecies & " start " & lngTimeInMilliseconds
'960           End If
'
'               Title - appears above a species tables
'
'              Dim strSpeciesEnglish As String
'              Dim strSpeciesFrench As String
'              Dim strSpeciesScientific As String
'
'970           strSpeciesEnglish = Nz(rst("SpeciesEnglish"))
'980           If strSpeciesEnglish = "" Then
'990               strSpeciesEnglish = Nz(rst("SubspeciesEnglish"))
'1000          End If
'1010          strSpeciesFrench = Nz(rst("SpeciesFrench"))
'1020          strSpeciesScientific = Nz(rst("SpeciesScientific"))
'
'1030          row = row + 2
'1040          .Cells(row, 1) = strSpecies & ": " & strSpeciesEnglish & " / (" & strSpeciesScientific & ")"
'1050          row = row + 1
'
'1060          Set docRange = MoveInsertionPointToEndOfDocument(wd, doc)
'
'1070          docRange.Style = "ddMultiYearSpeciesTitle"
'
'1080              docRange.InsertAfter strSpecies & ": " & strSpeciesEnglish & " / " & strSpeciesFrench & " ("
'1090              lngStart = doc.range.End
'1100              docRange.InsertAfter strSpeciesScientific
'1110              doc.range(lngStart - 1, doc.range.End).Font.Italic = True
'1120              Set docRange = doc.Characters.Last
'1130              docRange.InsertAfter ")"
'1140              docRange.InsertParagraphAfter
'                  docRange.ParagraphFormat.LeftIndent = wd.CentimetersToPoints(-0.62)
'1150              docRange.ParagraphFormat.KeepWithNext = True
'1160              docRange.ParagraphFormat.SpaceAfter = 3
'
'1170              If fDebug Then
'1180                  lngTimeInMilliseconds = CLng((Now() - datStartTime) * 24 * 60 * 60 * 1000)
'1190                  Debug.Print strSpecies & " " & cntSpecies & " after heading " & lngTimeInMilliseconds
'1200              End If
'
'1210          Set docRange = MoveInsertionPointToEndOfDocument(wd, doc)
'1220          Call WordGenerateTableSpecies(wd, doc, docRange)
'
'1230          lngEnd = doc.range.End
'1240          Set docRange = doc.range(lngStart, lngEnd)
'
'1250          If fDebug Then
'1260               lngTimeInMilliseconds = CLng((Now() - datStartTime) * 24 * 60 * 60 * 1000)
'1270               Debug.Print strSpecies & " end of cut and paste " & lngTimeInMilliseconds
'1280          End If
'
'              Dim intTable As Integer
'
'           Insert the rows we need for years
'           The template already contains three rows:
'                a row for the headings, a row for years and a row for the means
'
'1290          If intYearLast - intYearFirst + 1 > 1 Then
'1300              For intYear = intYearFirst To intYearLast - 1
'1310                  For intTable = 1 To 5
'1320                      docRange.Tables(intTable).Rows.Add BeforeRow:=docRange.Tables(intTable).Rows(2)
'1330                  Next
'1340              Next
'1350          End If
'
'1360          If fDebug Then
'1370               lngTimeInMilliseconds = CLng((Now() - datStartTime) * 24 * 60 * 60 * 1000)
'1380               Debug.Print strSpecies & " after insert rows " & lngTimeInMilliseconds
'1390          End If
'
'              Dim rowTable As Integer
'
'           Label the rows
'
'1400          If intYearLast - intYearFirst + 1 >= 1 Then
'1410              For intYear = intYearFirst To intYearLast
'1420                  rowTable = intYear - intYearFirst + 2
'1430                  For intTable = 1 To 5
'1440                      docRange.Tables(intTable).Cell(rowTable, 1).range.Text = intYear
'1450                  Next
'1460              Next
'1470          End If
'
'1480          If fDebug Then
'1490               lngTimeInMilliseconds = CLng((Now() - datStartTime) * 24 * 60 * 60 * 1000)
'1500               Debug.Print strSpecies & " after label rows " & lngTimeInMilliseconds
'1510          End If
'
'               Gray out cells with zero DET-Days or zero Capture-Years
'
'              Dim intSeason As Integer
'              Dim intPeriod As Integer
'              Dim intTableCol As Integer
'              Dim intTableRow As Integer
'
'1520          For intSeason = conWinter To conFall
'1530              For intYear = intYearFirst To intYearLast
'1540                intTableRow = intYear - intYearFirst + 2
'1550                For intPeriod = 1 To intPeriodLast_Season(intSeason)
'1560                    If getDETDays_SeasonYearPeriod(intSeason, intYear, intPeriod) = 0 Then
'
'1570                      Call getTableColFromFLDSeasonPeriod(conDET, toStrSeasonFromIntSeason(intSeason), intPeriod, intTable, intTableCol) ' => intTable, intTableCol
'1580                      docRange.Tables(intTable).Cell(intTableRow, intTableCol).range.Shading.BackgroundPatternColor = RGB(191, 191, 191)
'
'1590                    End If
'1600                    If getCaptureDays_SeasonYearPeriod(intSeason, intYear, intPeriod) = 0 Then
'
'1610                      Call getTableColFromFLDSeasonPeriod(conBND, toStrSeasonFromIntSeason(intSeason), intPeriod, intTable, intTableCol)
'1620                      docRange.Tables(intTable).Cell(intTableRow, intTableCol).range.Shading.BackgroundPatternColor = RGB(191, 191, 191)
'
'1630                    End If
'1640                Next
'1650              Next
'1660          Next
'
'1670          If fDebug Then
'1680               lngTimeInMilliseconds = CLng((Now() - datStartTime) * 24 * 60 * 60 * 1000)
'1690               Debug.Print strSpecies & "after gray out rows " & lngTimeInMilliseconds
'1700          End If
'
'1710          For fld = conDET To conBND
'
'1720              If fDebug Then
'1730                  lngTimeInMilliseconds = CLng((Now() - datStartTime) * 24 * 60 * 60 * 1000)
'1740                  If fld = conDET Then
'1750                       Debug.Print strSpecies & " DET: " & lngTimeInMilliseconds
'1760                  Else
'1770                       Debug.Print strSpecies & " BND: " & lngTimeInMilliseconds
'1780                  End If
'1790              End If
'
'1800              .Cells(row, 2) = IIf(fld = conDET, "DET", "BND")
'
'                  Dim rowSave As Long
'1810              rowSave = row
'
'1820              If fld = conDET Then
'1830                  lngSpringFirstTotal = 0
'1840                  lngFallFirstTotal = 0
'1850                  lngSpringFirstCount = 0
'1860                  lngFallFirstCount = 0
'1870                  lngSpringLastTotal = 0
'1880                  lngFallLastTotal = 0
'1890                  lngSpringLastCount = 0
'1900                  lngFallLastCount = 0
'1910                  lngSpringHighTotal = 0
'1920                  lngSpringHighCount = 0
'1930                  lngFallHighTotal = 0
'1940                  lngFallHighCount = 0
'1950                  lngSpringTotalTotal = 0
'1960                  lngSpringTotalCount = 0
'1970                  lngFallTotalTotal = 0
'1980                  lngFallTotalCount = 0
'1990                  lngSpringSpeciesDETDaysTotal = 0
'2000                  lngSpringDETDaysTotal = 0
'2010                  lngFallSpeciesDETDaysTotal = 0
'2020                  lngFallDETDaysTotal = 0
'2030                  lngSpringDETDaysCount = 0
'2040                  lngFallDETDaysCount = 0
'
'2050                  lngSpringPeakTotal = 0
'2060                  lngSpringPeakCount = 0
'2070                  lngFallPeakTotal = 0
'2080                  lngFallPeakCount = 0
'2090              End If
'
'2100              For intYear = intYearFirst To intYearLast
'2110                  .Cells(row, 3) = intYear
'
'2120                  Call StatSpeciesYear(fld, strSpecies, intYear, row, docRange, oSheet)
'
'2130                  If fDebug Then
'2140                      lngTimeInMilliseconds = CLng((Now() - datStartTime) * 24 * 60 * 60 * 1000)
'2150                          If fld = conDET Then
'2160                              Debug.Print strSpecies & " DET after StatSpeciesYear: " & lngTimeInMilliseconds
'2170                          Else
'2180                              Debug.Print strSpecies & " BND after StatSpeciesYear: " & lngTimeInMilliseconds
'2190                          End If
'2200                  End If
'
'2210                  row = row + 1
'2220              Next intYear
'
'2230              .range(.Cells(rowSave, 23), .Cells(row - 1, 23)).Interior.Color = RGB(184, 204, 228)
'2240              .range(.Cells(rowSave, 34), .Cells(row - 1, 34)).Interior.Color = RGB(214, 227, 188)
'2250              .range(.Cells(rowSave, 37), .Cells(row - 1, 37)).Interior.Color = RGB(229, 184, 183)
'2260              .range(.Cells(rowSave, 51), .Cells(row - 1, 51)).Interior.Color = RGB(255, 169, 83)
'
'2270              .Cells(row, 3) = "Mean"
'
'2280              .range(.Cells(row, 3), .Cells(row, 51)).Interior.Color = RGB(229, 223, 236)
'
'                   Fill in the row of means
'
'2290              Call StatSpeciesMean(fld, strSpecies, row, docRange, oSheet)
'
'2300              If fDebug Then
'2310                  datNowTime = Now()
'2320                  lngTimeInMilliseconds = CLng((datNowTime - datStartTime) * 24 * 60 * 60 * 1000)
'2330                  If fld = conDET Then
'2340                       Debug.Print strSpecies & " DET After StatSpecies: " & lngTimeInMilliseconds
'2350                  Else
'2360                       Debug.Print strSpecies & " BND After StatSpecies: " & lngTimeInMilliseconds
'2370                  End If
'2380              End If
'
'2390              row = row + 1
'                        If fDebug Then
'                          If row > 150 Then Exit Do
'                        End If
'2400          Next fld
'
'               Delete empty tables
'               Table #5, #3 are empty if Summer Mean and Fall Mean are blank. Columns 4, 18
'               Table #4, #2 are empty if Winter Mean and Spring Mean are blank, Columns 7, 18
'               row intYearLast - intYearFirst + 3
'
'              Dim strText1 As String
'              Dim strText2 As String
'
'2410          strText1 = docRange.Tables(5).Cell(intYearLast - intYearFirst + 3, 4).range.Text
'2420          strText2 = docRange.Tables(5).Cell(intYearLast - intYearFirst + 3, 18).range.Text
'2430          If Len(strText1) = 2 And Len(strText2) = 2 Then
'2440              docRange.Tables(5).Delete
'2450          End If
'
'2460          strText1 = docRange.Tables(4).Cell(intYearLast - intYearFirst + 3, 7).range.Text
'2470          strText2 = docRange.Tables(4).Cell(intYearLast - intYearFirst + 3, 18).range.Text
'2480          If Len(strText1) = 2 And Len(strText2) = 2 Then
'2490              docRange.Tables(4).Delete
'2500          End If
'
'2510          strText1 = docRange.Tables(3).Cell(intYearLast - intYearFirst + 3, 4).range.Text
'2520          strText2 = docRange.Tables(3).Cell(intYearLast - intYearFirst + 3, 18).range.Text
'2530          If Len(strText1) = 2 And Len(strText2) = 2 Then
'2540              docRange.Tables(3).Delete
'2550          End If
'
'2560          strText1 = docRange.Tables(2).Cell(intYearLast - intYearFirst + 3, 7).range.Text
'2570          strText2 = docRange.Tables(2).Cell(intYearLast - intYearFirst + 3, 18).range.Text
'2580          If Len(strText1) = 2 And Len(strText2) = 2 Then
'2590              docRange.Tables(2).Delete
'2600          End If
'
'2610          If fDebug Then
'2620            datNowTime = Now()
'2630            lngTimeInMilliseconds = CLng((datNowTime - datStartTime) * 24 * 60 * 60 * 1000)
'2640            Debug.Print strSpecies & " after delete unused tables End: " & lngTimeInMilliseconds; ""
'2650          End If
'
'Next_Species:
'2660          rst.MoveNext
'2670      Loop ' Species
'
'2680  End If
'2690  rst.Close
'2700  Set rst = Nothing
'
'2710  .range("d3").Select
'2720  oExcel.ActiveWindow.FreezePanes = True
'
'2730  End With
'2740  Set oSheet = Nothing
'
'
'      DD Error Handler Start
'Exit_label:
'2750       Exit Sub
'Err_label:
'2760       Select Case Err.Number
'           Case Else
'2770      Call LogError("basMBO10YearProgramReportSpecies", "MBO10YearProgramReportSpecies")
'2780       End Select
'2790       Resume Exit_label
'      DD Error Handler End
'End Sub
'
'---------------------------------------------------------------------------------------
' StatSpeciesYear
'---------------------------------------------------------------------------------------
'
' Process a single year
'
' Private Sub StatSpeciesYear( _
'    ByVal fld As Integer, _
'    ByVal strSpecies As String, _
'    ByVal intYear As Integer, _
'    ByVal row As Long, _
'    ByRef docRange As Word.range, _
'    ByRef oSheet As Excel.Worksheet)
'
'10    On Error GoTo Err_label
'
'      Dim strSQL As String
'      Dim qdf As DAO.QueryDef
'      Dim rst As DAO.Recordset
'
'      Dim strSeason As String
'      Dim intSeason As Integer
'      Dim intPeriod As Integer
'      Dim dblStat As Double
'      Dim intDays As Integer
'      Dim dblStatPerDay As Double
'
'      Dim intTable As Integer
'      Dim intTableCol As Integer
'      Dim intTableRow As Integer
'
'20    intTableRow = intYear - intYearFirst + 2
'
'      Dim dblHighPeriodSpringDET As Double
'      Dim dblHighPeriodFallDET As Double
'      Dim intPeakPeriodSpringDET As Integer
'      Dim intPeakPeriodFallDET As Integer
'      Dim dblHighPeriodSpringBanded As Double
'      Dim dblHighPeriodFallBanded As Double
'      Dim intPeakPeriodSpringBanded As Integer
'      Dim intPeakPeriodFallBanded As Integer
'
'30    dblHighPeriodSpringDET = 0
'40    dblHighPeriodFallDET = 0
'50    dblHighPeriodSpringBanded = 0
'60    dblHighPeriodFallBanded = 0
'
'70    With oSheet
'
'       qryMBO10YearProgramReportSpecies_BirdsPeriod
'       --------------------------------------------
'       tblMBO10YearProgramReportSpecies
'
'       WHERE YearEx = [argYear]
'       WHERE Species = [argSpecies]
'       WHERE Season IN   ("Winter","Spring","Summer","Fall")
'
'       GROUP BY Season, Period
'       Sum Banded, DET
'
'       SELECT Banded, DET, Period, Season
'
'80    strSQL = "qryMBO10YearProgramReportSpecies_BirdsPeriod"
'90    Set qdf = CurrentDb.QueryDefs(strSQL)
'100   qdf.Parameters("argYear").value = intYear
'110   qdf.Parameters("argSpecies").value = strSpecies
'120   Set rst = qdf.OpenRecordset
'130   Do While Not rst.EOF
'
'140       strSeason = Nz(rst("Season"))
'150       intSeason = toIntSeasonFromStrSeason(strSeason)
'160       intPeriod = Nz(rst("Period"))
'
'170       Select Case fld
'          Case conDET
'180           dblStat = Nz(rst("DET"))
'190           intDays = getDETDays_SeasonYearPeriod(intSeason, intYear, intPeriod)
'200           If intDays <> 0 Then
'210               dblStatPerDay = dblStat / intDays
'
'220               Select Case strSeason
'                  Case "Spring"
'230                   If dblStatPerDay > dblHighPeriodSpringDET Then
'240                       dblHighPeriodSpringDET = dblStatPerDay
'250                       intPeakPeriodSpringDET = intPeriod
'260                   End If
'270               Case "Fall"
'280                   If dblStatPerDay > dblHighPeriodFallDET Then
'290                       dblHighPeriodFallDET = dblStatPerDay
'300                       intPeakPeriodFallDET = intPeriod
'310                   End If
'320               End Select
'
'330               Call getTableColFromFLDSeasonPeriod(fld, strSeason, intPeriod, intTable, intTableCol)
'340               If dblStatPerDay >= 0.1 Then
'350                   .Cells(row, toColFromStatPeriod(strSeason, intPeriod)) = dblStatPerDay
'360                   .range(.Cells(row, toColFromStatPeriod(strSeason, intPeriod)), .Cells(row, toColFromStatPeriod(strSeason, intPeriod))).NumberFormat = "#0.0"
'370                   docRange.Tables(intTable).Cell(intTableRow, intTableCol).range.Text = _
'                          Replace(Format(dblStatPerDay, "#0.0"), ",", ".")
'380               Else
'390                   .Cells(row, toColFromStatPeriod(strSeason, intPeriod)) = dblStatPerDay
'400                   .range(.Cells(row, toColFromStatPeriod(strSeason, intPeriod)), .Cells(row, toColFromStatPeriod(strSeason, intPeriod))).NumberFormat = "#0.0"
'410                   docRange.Tables(intTable).Cell(intTableRow, intTableCol).range.Text = _
'                      Replace(Format(dblStatPerDay, "#0.00"), ",", ".")
'420               End If
'430           End If
'440       Case conBND
'450           dblStat = Nz(rst("Banded"))
'
'460           Select Case strSeason
'              Case "Spring"
'470               If dblStat > dblHighPeriodSpringBanded Then
'480                   dblHighPeriodSpringBanded = dblStat
'490                   intPeakPeriodSpringBanded = intPeriod
'500               End If
'510           Case "Fall"
'520               If dblStat > dblHighPeriodFallBanded Then
'530                   dblHighPeriodFallBanded = dblStat
'540                   intPeakPeriodFallBanded = intPeriod
'550               End If
'560           End Select
'
'570           If dblStat <> 0 Then
'580               .Cells(row, toColFromStatPeriod(strSeason, intPeriod)) = dblStat
'590               Call getTableColFromFLDSeasonPeriod(fld, strSeason, intPeriod, intTable, intTableCol)
'600               docRange.Tables(intTable).Cell(intTableRow, intTableCol).range.Text = dblStat
'610           End If
'620       End Select
'
'630       rst.MoveNext
'640   Loop
'650   rst.Close
'660   Set rst = Nothing
'
'       Colour the high period values red
'
'670   Select Case fld
'      Case conDET
'680       If dblHighPeriodSpringDET > 0 Then
'690           .range(.Cells(row, toColFromStatPeriod("Spring", intPeakPeriodSpringDET)), _
'                     .Cells(row, toColFromStatPeriod("Spring", intPeakPeriodSpringDET))).Font.Color = vbRed
'700           Call getTableColFromFLDSeasonPeriod(fld, "Spring", intPeakPeriodSpringDET, intTable, intTableCol)
'710           docRange.Tables(intTable).Cell(intTableRow, intTableCol).range.Font.Color = vbRed
'720       End If
'730       If dblHighPeriodFallDET > 0 Then
'740           .range(.Cells(row, toColFromStatPeriod("Fall", intPeakPeriodFallDET)), _
'                     .Cells(row, toColFromStatPeriod("Fall", intPeakPeriodFallDET))).Font.Color = vbRed
'750           Call getTableColFromFLDSeasonPeriod(fld, "Fall", intPeakPeriodFallDET, intTable, intTableCol)
'760           docRange.Tables(intTable).Cell(intTableRow, intTableCol).range.Font.Color = vbRed
'770   End If
'780   Case conBND
'790       If dblHighPeriodSpringBanded > 0 Then
'800           .range(.Cells(row, toColFromStatPeriod("Spring", intPeakPeriodSpringBanded)), _
'                     .Cells(row, toColFromStatPeriod("Spring", intPeakPeriodSpringBanded))).Font.Color = vbRed
'810           Call getTableColFromFLDSeasonPeriod(fld, "Spring", intPeakPeriodSpringBanded, intTable, intTableCol)
'820           docRange.Tables(intTable).Cell(intTableRow, intTableCol).range.Font.Color = vbRed
'830       End If
'840       If dblHighPeriodFallBanded > 0 Then
'850           .range(.Cells(row, toColFromStatPeriod("Fall", intPeakPeriodFallBanded)), _
'                     .Cells(row, toColFromStatPeriod("Fall", intPeakPeriodFallBanded))).Font.Color = vbRed
'860           Call getTableColFromFLDSeasonPeriod(fld, "Fall", intPeakPeriodFallBanded, intTable, intTableCol)
'870           docRange.Tables(intTable).Cell(intTableRow, intTableCol).range.Font.Color = vbRed
'880       End If
'890   End Select
'
'
'      Dim strStatPerDay As String
'      Dim strNumberFormat As String
'
'       qryMBO10YearProgramReportSpecies_BirdsSeason
'       --------------------------------------------
'       tblMBO10YearProgramReportSpecies
'
'       WHERE YearEx = [argYear]
'       WHERE Species = [argSpecies]
'       WHERE Season In ("Winter","Spring","Summer","Fall")
'       GROUP BY Season
'       Sum Banded, DET
'
'       SELECT Season, Banded, DET
'
'900   strSQL = "qryMBO10YearProgramReportSpecies_BirdsSeason"
'910   Set qdf = CurrentDb.QueryDefs(strSQL)
'920   qdf.Parameters("argYear").value = intYear
'930   qdf.Parameters("argSpecies").value = strSpecies
'940   Set rst = qdf.OpenRecordset
'950   Do While Not rst.EOF
'960       strSeason = Nz(rst("Season"))
'970       intSeason = toIntSeasonFromStrSeason(strSeason)
'980       Select Case fld
'          Case conDET
'990           dblStat = Nz(rst("DET"))
'1000          If dblStat <> 0 Then
'1010              intDays = getDETDays_SeasonYear(intSeason, intYear)
'1020              If intDays <> 0 Then
'1030                  dblStatPerDay = dblStat / intDays
'1040                  If Round(dblStatPerDay, 2) >= 0.1 Then
'1050                      dblStatPerDay = Round(dblStatPerDay, 1)
'1060                      strNumberFormat = "#0.00"
'1070                      strStatPerDay = FormatNumberEnglish(dblStatPerDay, 1)
'1080                  Else
'1090                      dblStatPerDay = Round(dblStatPerDay, 2)
'1100                      strNumberFormat = "#0.000"
'1110                      strStatPerDay = FormatNumberEnglish(dblStatPerDay, 2)
'1120                  End If
'1130                  Select Case strSeason
'                      Case "Winter"
'1140                      .Cells(row, 23) = dblStatPerDay
'1150                      .range(.Cells(row, 23), .Cells(row, 23)).NumberFormat = strNumberFormat
'1160                  Case "Spring"
'1170                      .Cells(row, 34) = dblStatPerDay
'1180                      .range(.Cells(row, 34), .Cells(row, 34)).NumberFormat = strNumberFormat
'1190                  Case "Summer"
'1200                      .Cells(row, 37) = dblStatPerDay
'1210                      .range(.Cells(row, 37), .Cells(row, 37)).NumberFormat = strNumberFormat
'1220                  Case "Fall"
'1230                      .Cells(row, 51) = dblStatPerDay
'1240                      .range(.Cells(row, 51), .Cells(row, 51)).NumberFormat = strNumberFormat
'1250                  End Select
'1260                  Select Case strSeason
'                      Case "Winter", "Spring", "Summer", "Fall"
'1270                      Call getTableColFromFLDSeason(fld, strSeason, intTable, intTableCol)
'1280                      docRange.Tables(intTable).Cell(intTableRow, intTableCol).range.Text = _
'                              strStatPerDay
'1290                End Select
'
'1300              End If
'1310          End If
'
'1320      Case conBND
'1330          dblStat = Nz(rst("Banded"))
'1340          If dblStat <> 0 Then
'1350              Select Case strSeason
'                  Case "Winter"
'1360                  .Cells(row, 23) = dblStat
'1370              Case "Spring"
'1380                  .Cells(row, 34) = dblStat
'1390              Case "Summer"
'1400                  .Cells(row, 37) = dblStat
'1410              Case "Fall"
'1420                  .Cells(row, 51) = dblStat
'1430              End Select
'1440              Select Case strSeason
'                  Case "Winter", "Spring", "Summer", "Fall"
'1450                  Call getTableColFromFLDSeason(fld, strSeason, intTable, intTableCol)
'1460                  docRange.Tables(intTable).Cell(intTableRow, intTableCol).range.Text = dblStat
'1470              End Select
'1480          End If
'
'1490      End Select
'
'1500      rst.MoveNext
'1510  Loop
'1520  rst.Close
'1530  Set rst = Nothing
'
'1540  If fld = conDET Then
'
'           First Date, Last Date, Span, High, Peak
'
'          Dim datFirstBird As Date
'          Dim datLastBird As Date
'          Dim lngHigh As Long
'          Dim lngCountBirds As Long
'          Dim lngCountDays As Long
'          Dim datPeak As Date
'          Dim rstPeak As DAO.Recordset
'
'           qryMBO10YearProgramReportSpecies_FirstLastDET
'           ---------------------------------------------
'           tblMBO10YearProgramReportSpecies
'
'           WHERE YearEx = [argYear]
'           WHERE Species = [argSpecies]
'           WHERE DET > 0
'           GROUP BY Season
'           FirstBird = Min DateEx
'           LastBird = Max DateEx
'           CountBirds = Sum DET
'           High = Max DET
'           CountDays = Count records
'
'           SELECT Season, CountDays, CountBirds, FirstBird, LastBird, High
'
'1550      strSQL = "qryMBO10YearProgramReportSpecies_FirstLastDET"
'
'1560      Set qdf = CurrentDb.QueryDefs(strSQL)
'1570      qdf.Parameters("argYear").value = intYear
'1580      qdf.Parameters("argSpecies").value = strSpecies
'1590      Set rst = qdf.OpenRecordset
'1600      Do While Not rst.EOF
'1610          strSeason = Nz(rst("Season"))
'1620          datFirstBird = Nz(rst("FirstBird"))
'1630          datLastBird = Nz(rst("LastBird"))
'1640          lngHigh = Nz(rst("High"))
'1650          lngCountBirds = Nz(rst("CountBirds"))
'1660          lngCountDays = Nz(rst("CountDays"))
'
'
'1670          Select Case strSeason
'              Case "Spring"
'1680              If datFirstBird <> 0 Then
'1690                  datFirstBird = DateSerial(2000, Month(datFirstBird), Day(datFirstBird))
'1700                  .Cells(row, colSpringFirst) = datFirstBird
'1710                  lngSpringFirstTotal = lngSpringFirstTotal + CLng(datFirstBird)
'1720                  lngSpringFirstCount = lngSpringFirstCount + 1
'1730                  Call getTableColFromFLDSeasonStat(fld, strSeason, conStatSeasonFirst, intTable, intTableCol)
'1740                  docRange.Tables(intTable).Cell(intTableRow, intTableCol).range.Text = _
'                        ConvertDateToEnglishString(datFirstBird, 1)
'1750              End If
'1760              If datLastBird <> 0 Then
'1770                  datLastBird = DateSerial(2000, Month(datLastBird), Day(datLastBird))
'1780                  .Cells(row, colSpringLast) = datLastBird
'1790                  lngSpringLastTotal = lngSpringLastTotal + CLng(datLastBird)
'1800                  lngSpringLastCount = lngSpringLastCount + 1
'1810                  Call getTableColFromFLDSeasonStat(fld, strSeason, conStatSeasonLast, intTable, intTableCol)
'1820                  docRange.Tables(intTable).Cell(intTableRow, intTableCol).range.Text = _
'                        ConvertDateToEnglishString(datLastBird, 1)
'1830              End If
'1840              If datFirstBird <> 0 And datLastBird <> 0 Then
'1850                  .Cells(row, colSpringSpan) = datLastBird - datFirstBird + 1
'1860                  Call getTableColFromFLDSeasonStat(fld, strSeason, conStatSeasonSpan, intTable, intTableCol)
'1870                  docRange.Tables(intTable).Cell(intTableRow, intTableCol).range.Text = _
'                        datLastBird - datFirstBird + 1
'1880              End If
'1890              If lngHigh > 0 Then
'1900                  .Cells(row, colSpringHigh) = lngHigh
'1910                  lngSpringHighTotal = lngSpringHighTotal + lngHigh
'1920                  lngSpringHighCount = lngSpringHighCount + 1
'1930                  Call getTableColFromFLDSeasonStat(fld, strSeason, conStatSeasonHigh, intTable, intTableCol)
'1940                  docRange.Tables(intTable).Cell(intTableRow, intTableCol).range.Text = lngHigh
'1950              End If
'1960              If lngCountBirds > 0 Then
'1970                  .Cells(row, colSpringTotal) = lngCountBirds
'1980                  lngSpringTotalTotal = lngSpringTotalTotal + lngCountBirds
'1990                  lngSpringTotalCount = lngSpringTotalCount + 1
'2000                  Call getTableColFromFLDSeasonStat(fld, strSeason, conStatSeasonTotal, intTable, intTableCol)
'2010                  docRange.Tables(intTable).Cell(intTableRow, intTableCol).range.Text = lngCountBirds
'2020              End If
'2030              If lngCountDays > 0 Then
'                      Dim strStat As String
'2040                  strStat = lngCountDays & " (" & _
'                          Round(100# * lngCountDays / getDETDays_SeasonYear(conSpring, intYear), 0) & "%)"
'2050                  .Cells(row, colSpringDays) = strStat
'2060                  lngSpringSpeciesDETDaysTotal = lngSpringSpeciesDETDaysTotal + lngCountDays
'2070                   lngSpringDETDaysTotal = lngSpringDETDaysTotal + getDETDays_SeasonYear(conSpring, intYear)
'2080                   lngSpringDETDaysCount = lngSpringDETDaysCount + 1
'2090                  Call getTableColFromFLDSeasonStat(fld, strSeason, conStatSeasonDays, intTable, intTableCol)
'2100                  docRange.Tables(intTable).Cell(intTableRow, intTableCol).range.Text = strStat
'
'2110              End If
'
'                   qryMBO10YearProgramReportSpecies_Peak
'                   ------------------------------------------------------------------
'                   For a given Season, Year, Species
'                     Determine the Peak Day (when the first High DET occurred)
'                   ------------------------------------------------------------------
'                   tblMBO10YearProgramReportSpecies
'
'                   WHERE YearEx = [argYear]
'                   WHERE Species = [argSpecies]
'                   WHERE DET = [argDET]
'                   SORT BY DateEx
'
'                   SELECT Season, DateEx, DET
'
'2120              strSQL = "qryMBO10YearProgramReportSpecies_Peak"
'2130              Set qdf = CurrentDb.QueryDefs(strSQL)
'2140              qdf.Parameters("argYearEx").value = intYear
'2150              qdf.Parameters("argSpecies").value = strSpecies
'2160              qdf.Parameters("argDET").value = lngHigh
'2170              qdf.Parameters("argSeason").value = "Spring"
'2180              Set rstPeak = qdf.OpenRecordset
'
'2190              If Not rstPeak.EOF Then
'2200                  datPeak = Nz(rstPeak("DateEx"))
'2210                  If datPeak > 0 Then
'2220                      datPeak = DateSerial(2000, Month(datPeak), Day(datPeak))
'2230                      .Cells(row, colSpringPeak) = datPeak
'2240                      Call getTableColFromFLDSeasonStat(fld, strSeason, conStatSeasonPeak, intTable, intTableCol)
'2250                      docRange.Tables(intTable).Cell(intTableRow, intTableCol).range.Text = _
'                            ConvertDateToEnglishString(datPeak, 1)
'2260                      lngSpringPeakTotal = lngSpringPeakTotal + datPeak
'2270                      lngSpringPeakCount = lngSpringPeakCount + 1
'2280                  End If
'2290              End If
'2300              rstPeak.Close
'
'2310          Case "Fall"
'
'2320              If datFirstBird <> 0 Then
'2330                  datFirstBird = DateSerial(2000, Month(datFirstBird), Day(datFirstBird))
'2340                  .Cells(row, colFallFirst) = datFirstBird
'2350                  lngFallFirstTotal = lngFallFirstTotal + CLng(datFirstBird)
'2360                  lngFallFirstCount = lngFallFirstCount + 1
'2370                  Call getTableColFromFLDSeasonStat(fld, strSeason, conStatSeasonFirst, intTable, intTableCol)
'2380                  docRange.Tables(intTable).Cell(intTableRow, intTableCol).range.Text = _
'                         ConvertDateToEnglishString(datFirstBird, 1)
'2390              End If
'2400              If datLastBird <> 0 Then
'2410                  datLastBird = DateSerial(2000, Month(datLastBird), Day(datLastBird))
'2420                  .Cells(row, colFallLast) = datLastBird
'2430                  lngFallLastTotal = lngFallLastTotal + CLng(datLastBird)
'2440                  lngFallLastCount = lngFallLastCount + 1
'2450                  Call getTableColFromFLDSeasonStat(fld, strSeason, conStatSeasonLast, intTable, intTableCol)
'2460                  docRange.Tables(intTable).Cell(intTableRow, intTableCol).range.Text = _
'                        ConvertDateToEnglishString(datLastBird, 1)
'2470              End If
'2480              If datFirstBird <> 0 And datLastBird <> 0 Then
'2490                  .Cells(row, colFallSpan) = datLastBird - datFirstBird + 1
'2500                  Call getTableColFromFLDSeasonStat(fld, strSeason, conStatSeasonSpan, intTable, intTableCol)
'2510                  docRange.Tables(intTable).Cell(intTableRow, intTableCol).range.Text = _
'                          datLastBird - datFirstBird + 1
'2520              End If
'2530              If lngHigh > 0 Then
'2540                  .Cells(row, colFallHigh) = lngHigh
'2550                  lngFallHighTotal = lngFallHighTotal + lngHigh
'2560                  lngFallHighCount = lngFallHighCount + 1
'2570                   Call getTableColFromFLDSeasonStat(fld, strSeason, conStatSeasonHigh, intTable, intTableCol)
'2580                  docRange.Tables(intTable).Cell(intTableRow, intTableCol).range.Text = lngHigh
'2590              End If
'2600              If lngCountBirds > 0 Then
'2610                  .Cells(row, colFallTotal) = lngCountBirds
'2620                  lngFallTotalTotal = lngFallTotalTotal + lngCountBirds
'2630                  lngFallTotalCount = lngFallTotalCount + 1
'2640                  Call getTableColFromFLDSeasonStat(fld, strSeason, conStatSeasonTotal, intTable, intTableCol)
'2650                  docRange.Tables(intTable).Cell(intTableRow, intTableCol).range.Text = lngCountBirds
'2660              End If
'2670              If lngCountDays > 0 Then
'2680                  strStat = lngCountDays & " (" & _
'                          Round(100# * lngCountDays / getDETDays_SeasonYear(conFall, intYear), 0) & "%)"
'2690                  .Cells(row, colFallDays) = strStat
'2700                  lngFallSpeciesDETDaysTotal = lngFallSpeciesDETDaysTotal + lngCountDays
'2710                  lngFallDETDaysTotal = lngFallDETDaysTotal + getDETDays_SeasonYear(conFall, intYear)
'2720                  lngFallDETDaysCount = lngFallDETDaysCount + 1
'2730                  Call getTableColFromFLDSeasonStat(fld, strSeason, conStatSeasonDays, intTable, intTableCol)
'2740                  docRange.Tables(intTable).Cell(intTableRow, intTableCol).range.Text = strStat
'
'2750              End If
'
'2760          strSQL = "qryMBO10YearProgramReportSpecies_Peak"
'2770          Set qdf = CurrentDb.QueryDefs(strSQL)
'2780          qdf.Parameters("argYearEx").value = intYear
'2790          qdf.Parameters("argSpecies").value = strSpecies
'2800          qdf.Parameters("argDET").value = lngHigh
'2810          qdf.Parameters("argSeason").value = "Fall"
'2820          Set rstPeak = qdf.OpenRecordset
'
'2830          If Not rstPeak.EOF Then
'2840              datPeak = Nz(rstPeak("DateEx"))
'2850              If datPeak > 0 Then
'2860                  datPeak = DateSerial(2000, Month(datPeak), Day(datPeak))
'2870                  .Cells(row, colFallPeak) = datPeak
'2880                  Call getTableColFromFLDSeasonStat(fld, strSeason, conStatSeasonPeak, intTable, intTableCol)
'2890                  docRange.Tables(intTable).Cell(intTableRow, intTableCol).range.Text = ConvertDateToEnglishString(datPeak, 1)
'2900                  lngFallPeakTotal = lngFallPeakTotal + datPeak
'2910                  lngFallPeakCount = lngFallPeakCount + 1
'2920              End If
'2930          End If
'2940          rstPeak.Close
'
'2950          End Select
'
'2960          rst.MoveNext
'2970      Loop
'2980      rst.Close
'2990      Set rst = Nothing
'
'3000  End If
'
'3010  End With
'
'      DD Error Handler Start
'Exit_label:
'3020       Exit Sub
'Err_label:
'3030       Select Case Err.Number
'           Case Else
'3040            Call LogError("basMBO10YearProgramReportSpecies", "StatSpeciesYear")
'3050       End Select
'3060       Resume Exit_label
'      DD Error Handler End
'
'End Sub
'
'---------------------------------------------------------------------------------------
' StatSpeciesMean
'---------------------------------------------------------------------------------------
'
' Fill in the row of means (calculated over all years)
'
'
'Private Sub StatSpeciesMean( _
'    ByVal fld As Integer, _
'    ByVal strSpecies As String, _
'    ByVal row As Long, _
'    ByRef docRange As Word.range, _
'    ByRef oSheet As Excel.Worksheet)
'
'10    On Error GoTo Err_label
'
'      Dim strSQL As String
'      Dim qdf As DAO.QueryDef
'      Dim rst As DAO.Recordset
'
'      Dim strSeason As String
'      Dim intSeason As Integer
'      Dim intPeriod As Integer
'      Dim dblStat As Double
'      Dim intDays As Integer
'      Dim dblStatPerDay As Double
'      Dim intYears As Integer
'
'      Dim intTable As Integer
'      Dim intTableCol As Integer
'      Dim intTableRow As Integer
'
'20    intTableRow = intYearLast - intYearFirst + 3
'
'      Dim dblHighPeriodSpringDET As Double
'      Dim dblHighPeriodFallDET As Double
'      Dim intPeakPeriodSpringDET As Integer
'      Dim intPeakPeriodFallDET As Integer
'      Dim dblHighPeriodSpringBanded As Double
'      Dim dblHighPeriodFallBanded As Double
'      Dim intPeakPeriodSpringBanded As Integer
'      Dim intPeakPeriodFallBanded As Integer
'
'30    dblHighPeriodSpringDET = 0
'40    dblHighPeriodFallDET = 0
'50    dblHighPeriodSpringBanded = 0
'60    dblHighPeriodFallBanded = 0
'
'      Dim strStatPerDay As String
'      Dim strStat       As String
'
'70    With oSheet
'
'       qryMBO10YearProgramReportSpecies_BirdsPeriod_Summary
'       --------------------------------------------
'       For each Season
'             DET: # Birds / # DET-Days
'             Banded: # Birds
'       --------------------------------------------
'       tblMBO10YearProgramReportSpecies
'       Group By Season, Period
'       WHERE Species = [argSpecies]
'       WHERE Season IN  ("Winter","Spring","Summer","Fall")
'       Banded = Sum Banded
'       DET = Sum DET
'
'80    strSQL = "qryMBO10YearProgramReportSpecies_BirdsPeriod_Summary"
'90    Set qdf = CurrentDb.QueryDefs(strSQL)
'100   qdf.Parameters("argSpecies").value = strSpecies
'
'110   Set rst = qdf.OpenRecordset
'120   Do While Not rst.EOF
'
'130       strSeason = Nz(rst("Season"))
'140       intSeason = toIntSeasonFromStrSeason(strSeason)
'150       intPeriod = Nz(rst("Period"))
'
'160       Select Case fld
'          Case conDET
'170           dblStat = Nz(rst("DET"))
'180           intDays = getDETDays_SeasonPeriod(intSeason, intPeriod)
'190           If intDays <> 0 And dblStat > 0 Then
'200               dblStatPerDay = dblStat / intDays
'
'210               Select Case strSeason
'                  Case "Spring"
'220                   If dblStatPerDay > dblHighPeriodSpringDET Then
'230                       dblHighPeriodSpringDET = dblStatPerDay
'240                       intPeakPeriodSpringDET = intPeriod
'250                   End If
'260               Case "Fall"
'270                   If dblStatPerDay > dblHighPeriodFallDET Then
'280                       dblHighPeriodFallDET = dblStatPerDay
'290                       intPeakPeriodFallDET = intPeriod
'300                   End If
'310               End Select
'
'                  Dim strNumberFormat As String
'
'320               If Round(dblStatPerDay, 2) >= 0.1 Then
'330                   strStatPerDay = FormatNumberEnglish(dblStatPerDay, 1)
'340                       strNumberFormat = "#0.0"
'350               Else
'360                   strStatPerDay = FormatNumberEnglish(dblStatPerDay, 2)
'370                       strNumberFormat = "#0.00"
'380               End If
'390               .Cells(row, toColFromStatPeriod(strSeason, intPeriod)) = dblStatPerDay
'400               .range(.Cells(row, toColFromStatPeriod(strSeason, intPeriod)), .Cells(row, toColFromStatPeriod(strSeason, intPeriod))).NumberFormat = strNumberFormat
'410               Call getTableColFromFLDSeasonPeriod(fld, strSeason, intPeriod, intTable, intTableCol)
'420               docRange.Tables(intTable).Cell(intTableRow, intTableCol).range.Text = _
'                    strStatPerDay
'
'430           End If
'440       Case conBND
'450           dblStat = Nz(rst("Banded"))
'460           intYears = getCapturesYears_SeasonPeriod(intSeason, intPeriod)
'470           If intYears <> 0 And dblStat > 0 Then
'480               dblStat = dblStat / intYears
'
'490               Select Case strSeason
'                  Case "Spring"
'500                   If dblStat > dblHighPeriodSpringBanded Then
'510                       dblHighPeriodSpringBanded = dblStat
'520                       intPeakPeriodSpringBanded = intPeriod
'530                   End If
'540               Case "Fall"
'550                   If dblStat > dblHighPeriodFallBanded Then
'560                       dblHighPeriodFallBanded = dblStat
'570                       intPeakPeriodFallBanded = intPeriod
'580                   End If
'590               End Select
'
'600               If Round(dblStat, 2) >= 0.1 Then
'610                   strStat = FormatNumberEnglish(dblStat, 1)
'620                   strNumberFormat = "#0.0"
'630               Else
'640                   strStat = FormatNumberEnglish(dblStat, 2)
'650                   strNumberFormat = "#0.00"
'660               End If
'
'670               .Cells(row, toColFromStatPeriod(strSeason, intPeriod)) = dblStat
'680               .range(.Cells(row, toColFromStatPeriod(strSeason, intPeriod)), .Cells(row, toColFromStatPeriod(strSeason, intPeriod))).NumberFormat = strNumberFormat
'
'690               Call getTableColFromFLDSeasonPeriod(fld, strSeason, intPeriod, intTable, intTableCol)
'700               docRange.Tables(intTable).Cell(intTableRow, intTableCol).range.Text = _
'                    strStat
'
'710           End If
'720       End Select
'
'730       rst.MoveNext
'740   Loop
'750   rst.Close
'760   Set rst = Nothing
'
'770   Select Case fld
'      Case conDET
'780       If dblHighPeriodSpringDET > 0 Then
'790           .range(.Cells(row, toColFromStatPeriod("Spring", intPeakPeriodSpringDET)), _
'                     .Cells(row, toColFromStatPeriod("Spring", intPeakPeriodSpringDET))).Font.Color = vbRed
'800           Call getTableColFromFLDSeasonPeriod(fld, "Spring", intPeakPeriodSpringDET, intTable, intTableCol)
'810           docRange.Tables(intTable).Cell(intTableRow, intTableCol).range.Font.Color = vbRed
'820       End If
'830       If dblHighPeriodFallDET > 0 Then
'840           .range(.Cells(row, toColFromStatPeriod("Fall", intPeakPeriodFallDET)), _
'                     .Cells(row, toColFromStatPeriod("Fall", intPeakPeriodFallDET))).Font.Color = vbRed
'850           Call getTableColFromFLDSeasonPeriod(fld, "Fall", intPeakPeriodFallDET, intTable, intTableCol)
'860           docRange.Tables(intTable).Cell(intTableRow, intTableCol).range.Font.Color = vbRed
'870   End If
'880   Case conBND
'890       If dblHighPeriodSpringBanded > 0 Then
'900           .range(.Cells(row, toColFromStatPeriod("Spring", intPeakPeriodSpringBanded)), _
'                     .Cells(row, toColFromStatPeriod("Spring", intPeakPeriodSpringBanded))).Font.Color = vbRed
'910           Call getTableColFromFLDSeasonPeriod(fld, "Spring", intPeakPeriodSpringBanded, intTable, intTableCol)
'920           docRange.Tables(intTable).Cell(intTableRow, intTableCol).range.Font.Color = vbRed
'930       End If
'940       If dblHighPeriodFallBanded > 0 Then
'950           .range(.Cells(row, toColFromStatPeriod("Fall", intPeakPeriodFallBanded)), _
'                     .Cells(row, toColFromStatPeriod("Fall", intPeakPeriodFallBanded))).Font.Color = vbRed
'960           Call getTableColFromFLDSeasonPeriod(fld, "Fall", intPeakPeriodFallBanded, intTable, intTableCol)
'970           docRange.Tables(intTable).Cell(intTableRow, intTableCol).range.Font.Color = vbRed
'980       End If
'990   End Select
'
'       Summary column for each season
'
'       qryMBO10YearProgramReportSpecies_BirdsSeason_Summary
'       ----------------------------------------------------
'       tblMBO10YearProgramReportSpecies
'       Species = [argSpecies]
'       Season In ("Winter","Spring","Summer","Fall")
'       Group By Season, YearEx
'       DET = Sum DET
'       Banded = Sum Banded
'
'1000  strSQL = "qryMBO10YearProgramReportSpecies_BirdsSeason_Summary"
'1010  Set qdf = CurrentDb.QueryDefs(strSQL)
'1020  qdf.Parameters("argSpecies").value = strSpecies
'1030  Set rst = qdf.OpenRecordset
'1040  Do While Not rst.EOF
'1050      strSeason = Nz(rst("Season"))
'1060      intSeason = toIntSeasonFromStrSeason(strSeason)
'1070      Select Case fld
'          Case conDET
'1080          dblStat = Nz(rst("DET"))
'1090          If dblStat <> 0 Then
'1100              intDays = getDETDays_Season(intSeason)
'1110              If intDays <> 0 Then
'1120                  dblStatPerDay = dblStat / intDays
'1130                  If Round(dblStatPerDay, 2) >= 0.1 Then
'1140                      strStatPerDay = FormatNumberEnglish(Round(dblStatPerDay, 1), 1)
'1150                      strNumberFormat = "#0.00"
'1160                  ElseIf Round(dblStatPerDay, 3) >= 0.01 Then
'1170                      strStatPerDay = FormatNumberEnglish(Round(dblStatPerDay, 2), 2)
'1180                      strNumberFormat = "#0.000"
'1190                  Else
'1200                      strStatPerDay = "<0.005"
'1210                      strNumberFormat = "#0.0000"
'1220                  End If
'1230              End If
'1240              Select Case strSeason
'                  Case "Winter"
'1250                  .Cells(row, 23) = dblStatPerDay
'1260                  .range(.Cells(row, 23), .Cells(row, 23)).NumberFormat = strNumberFormat
'1270              Case "Spring"
'1280                  .Cells(row, 34) = dblStatPerDay
'1290                  .range(.Cells(row, 34), .Cells(row, 34)).NumberFormat = strNumberFormat
'1300              Case "Summer"
'1310                  .Cells(row, 37) = dblStatPerDay
'1320                  .range(.Cells(row, 37), .Cells(row, 37)).NumberFormat = strNumberFormat
'1330              Case "Fall"
'1340                  .Cells(row, 51) = dblStatPerDay
'1350                  .range(.Cells(row, 51), .Cells(row, 51)).NumberFormat = strNumberFormat
'1360              End Select
'1370              Select Case strSeason
'                  Case "Winter", "Spring", "Summer", "Fall"
'1380                  Call getTableColFromFLDSeason(fld, strSeason, intTable, intTableCol)
'1390                  docRange.Tables(intTable).Cell(intTableRow, intTableCol).range.Text = _
'                          strStatPerDay
'1400                End Select
'1410          End If
'1420      Case conBND
'1430          dblStat = Nz(rst("Banded"))
'1440          If dblStat <> 0 Then
'1450              intYears = intCapturesYearsCountSeason(intSeason)
'1460              If intYears <> 0 Then
'1470                  dblStat = dblStat / intYears
'1480                  If Round(dblStat, 2) >= 0.1 Then
'1490                      strStat = FormatNumberEnglish(Round(dblStat, 1), 1)
'1500                      strNumberFormat = "#0.00"
'1510                  Else
'1520                      strStat = FormatNumberEnglish(Round(dblStat, 2), 2)
'1530                      strNumberFormat = "#0.000"
'1540                  End If
'1550                  Select Case strSeason
'                      Case "Winter"
'1560                      .Cells(row, 23) = dblStat
'1570                      .range(.Cells(row, 23), .Cells(row, 23)).NumberFormat = strNumberFormat
'1580                  Case "Spring"
'1590                      .Cells(row, 34) = dblStat
'1600                      .range(.Cells(row, 34), .Cells(row, 34)).NumberFormat = strNumberFormat
'1610                  Case "Summer"
'1620                      .Cells(row, 37) = dblStat
'1630                      .range(.Cells(row, 37), .Cells(row, 37)).NumberFormat = strNumberFormat
'1640                  Case "Fall"
'1650                      .Cells(row, 51) = dblStat
'1660                      .range(.Cells(row, 51), .Cells(row, 51)).NumberFormat = strNumberFormat
'1670                  End Select
'1680                  Select Case strSeason
'                      Case "Winter", "Spring", "Summer", "Fall"
'1690                      Call getTableColFromFLDSeason(fld, strSeason, intTable, intTableCol)
'1700                      docRange.Tables(intTable).Cell(intTableRow, intTableCol).range.Text = _
'                              strStat
'1710                  End Select
'1720              End If
'1730          End If
'
'1740      End Select
'
'1750      rst.MoveNext
'1760  Loop
'1770  rst.Close
'1780  Set rst = Nothing
'
'       Fill in the mean row of Table #1 (DET Spring and Fall)
'
'      Dim datSpringFirstMean As Date
'      Dim datFallFirstMean As Date
'      Dim datSpringLastMean As Date
'      Dim datFallLastMean As Date
'      Dim lngSpringSpanMean As Long
'      Dim lngFallSpanMean As Long
'      Dim lngSpringHighMean As Long
'      Dim lngFallHighMean As Long
'      Dim dblSpringTotalMean As Double
'      Dim dblFallTotalMean As Double
'      Dim datSpringPeakMean As Date
'      Dim datFallPeakMean As Date
'      Dim lngSpringSpeciesDETDaysMean As Long
'      Dim lngFallSpeciesDETDaysMean As Long
'      Dim lngSpringSpeciesDETDaysPercent As Long
'      Dim lngFallSpeciesDETDaysPercent As Long
'
'       Dim intTable As Integer
'       Dim intTableCol As Integer
'       Dim intTableRow As Integer
'
'1540        intTableRow = intTableRow
'
'1790  If fld = conDET Then
'
'1800      If lngSpringFirstCount > 0 Then
'1810          datSpringFirstMean = CDate(lngSpringFirstTotal / lngSpringFirstCount)
'1820          .Cells(row, colSpringFirst) = datSpringFirstMean
'1830          Call getTableColFromFLDSeasonStat(fld, "Spring", conStatSeasonFirst, intTable, intTableCol)
'1840          docRange.Tables(intTable).Cell(intTableRow, intTableCol).range.Text = _
'                ConvertDateToEnglishString(datSpringFirstMean, 1)
'1850      Else
'1860          datSpringFirstMean = 0
'1870      End If
'
'1880      If lngSpringLastCount > 0 Then
'1890          datSpringLastMean = CDate(lngSpringLastTotal / lngSpringLastCount)
'1900          .Cells(row, colSpringLast) = datSpringLastMean
'1910          Call getTableColFromFLDSeasonStat(fld, "Spring", conStatSeasonLast, intTable, intTableCol)
'1920          docRange.Tables(intTable).Cell(intTableRow, intTableCol).range.Text = _
'                ConvertDateToEnglishString(datSpringLastMean, 1)
'1930      Else
'1940          datSpringLastMean = 0
'1950      End If
'
'1960      If lngFallFirstCount > 0 Then
'1970          datFallFirstMean = CDate(lngFallFirstTotal / lngFallFirstCount)
'1980          .Cells(row, colFallFirst) = datFallFirstMean
'1990          Call getTableColFromFLDSeasonStat(fld, "Fall", conStatSeasonFirst, intTable, intTableCol)
'2000          docRange.Tables(intTable).Cell(intTableRow, intTableCol).range.Text = _
'                ConvertDateToEnglishString(datFallFirstMean, 1)
'2010      Else
'2020          datFallFirstMean = 0
'2030      End If
'
'2040      If lngFallLastCount > 0 Then
'2050          datFallLastMean = CDate(lngFallLastTotal / lngFallLastCount)
'2060          .Cells(row, colFallLast) = datFallLastMean
'2070          Call getTableColFromFLDSeasonStat(fld, "Fall", conStatSeasonLast, intTable, intTableCol)
'2080          docRange.Tables(intTable).Cell(intTableRow, intTableCol).range.Text = _
'                ConvertDateToEnglishString(datFallLastMean, 1)
'2090      Else
'2100          datFallLastMean = 0
'2110      End If
'
'2120      If datSpringFirstMean > 0 And datSpringLastMean > 0 Then
'2130          lngSpringSpanMean = datSpringLastMean - datSpringFirstMean + 1
'2140          .Cells(row, colSpringSpan) = lngSpringSpanMean
'2150          Call getTableColFromFLDSeasonStat(fld, "Spring", conStatSeasonSpan, intTable, intTableCol)
'2160          docRange.Tables(intTable).Cell(intTableRow, intTableCol).range.Text = lngSpringSpanMean
'2170      Else
'2180          lngSpringSpanMean = 0
'2190      End If
'
'2200      If datFallFirstMean > 0 And datFallLastMean > 0 Then
'2210          lngFallSpanMean = datFallLastMean - datFallFirstMean + 1
'2220          .Cells(row, colFallSpan) = lngFallSpanMean
'2230          Call getTableColFromFLDSeasonStat(fld, "Fall", conStatSeasonSpan, intTable, intTableCol)
'2240          docRange.Tables(intTable).Cell(intTableRow, intTableCol).range.Text = lngFallSpanMean
'2250      Else
'2260          lngFallSpanMean = 0
'2270      End If
'
'2280      If lngSpringHighCount > 0 Then
'2290          lngSpringHighMean = lngSpringHighTotal / lngSpringHighCount
'2300          .Cells(row, colSpringHigh) = lngSpringHighMean
'2310          Call getTableColFromFLDSeasonStat(fld, "Spring", conStatSeasonHigh, intTable, intTableCol)
'2320          docRange.Tables(intTable).Cell(intTableRow, intTableCol).range.Text = lngSpringHighMean
'2330      Else
'2340          lngSpringHighMean = 0
'2350      End If
'
'2360      If lngFallHighCount > 0 Then
'2370          lngFallHighMean = lngFallHighTotal / lngFallHighCount
'2380          .Cells(row, colFallHigh) = lngFallHighMean
'2390          Call getTableColFromFLDSeasonStat(fld, "Fall", conStatSeasonHigh, intTable, intTableCol)
'2400          docRange.Tables(intTable).Cell(intTableRow, intTableCol).range.Text = lngFallHighMean
'2410      Else
'2420          lngFallHighMean = 0
'2430      End If
'
'           Calculate Spring Mean Total
'
'2440      If intDETYearsCountSeason(conSpring) > 0 And lngSpringTotalTotal > 0 Then
'2450          dblSpringTotalMean = CDbl(lngSpringTotalTotal) / intDETYearsCountSeason(conSpring)
'2460          .Cells(row, colSpringTotal) = dblSpringTotalMean
'2470          .range(.Cells(row, colSpringTotal), .Cells(row, colSpringTotal)).NumberFormat = "General"
'2480          Call getTableColFromFLDSeasonStat(fld, "Spring", conStatSeasonTotal, intTable, intTableCol)
'2490          If dblSpringTotalMean >= 10 Then
'2500              docRange.Tables(intTable).Cell(intTableRow, intTableCol).range.Text = _
'                      Replace(Format(dblSpringTotalMean, "#0"), ",", ".")
'              ElseIf dblSpringTotalMean >= 1 Then
'                   docRange.Tables(intTable).Cell(intTableRow, intTableCol).range.Text = _
'                      Replace(Format(dblSpringTotalMean, "#0.0"), ",", ".")
'2510          Else
'2520               docRange.Tables(intTable).Cell(intTableRow, intTableCol).range.Text = _
'                      Replace(Format(dblSpringTotalMean, "#0.0"), ",", ".")
'2530          End If
'2540      Else
'2550          dblSpringTotalMean = 0
'2560      End If
'
'           Calculate Fall Mean Total
'
'2570      If intDETYearsCountSeason(conFall) > 0 And lngFallTotalTotal > 0 Then
'2580          dblFallTotalMean = CDbl(lngFallTotalTotal) / intDETYearsCountSeason(conFall)
'2590          .Cells(row, colFallTotal) = dblFallTotalMean
'2600                  .range(.Cells(row, colFallTotal), .Cells(row, colFallTotal)).NumberFormat = "General"
'2610          Call getTableColFromFLDSeasonStat(fld, "Fall", conStatSeasonTotal, intTable, intTableCol)
'2620          If dblFallTotalMean >= 10 Then
'2630              docRange.Tables(intTable).Cell(intTableRow, intTableCol).range.Text = _
'                      Replace(Format(dblFallTotalMean, "#0"), ",", ".")
'              ElseIf dblFallTotalMean >= 1 Then
'                   docRange.Tables(intTable).Cell(intTableRow, intTableCol).range.Text = _
'                      Replace(Format(dblFallTotalMean, "#0.0"), ",", ".")
'2640          Else
'2650               docRange.Tables(intTable).Cell(intTableRow, intTableCol).range.Text = _
'                      Replace(Format(dblFallTotalMean, "#0.0"), ",", ".")
'2660          End If
'2670      Else
'2680          dblFallTotalMean = 0
'2690      End If
'
'2700      If lngSpringPeakCount > 0 Then
'2710          datSpringPeakMean = CDate(lngSpringPeakTotal / lngSpringPeakCount)
'2720          .Cells(row, colSpringPeak) = datSpringPeakMean
'2730          .range(.Cells(row, colSpringPeak), .Cells(row, colSpringPeak)).NumberFormat = "mmm d"
'2740          Call getTableColFromFLDSeasonStat(fld, "Spring", conStatSeasonPeak, intTable, intTableCol)
'2750          docRange.Tables(intTable).Cell(intTableRow, intTableCol).range.Text = _
'                  ConvertDateToEnglishString(datSpringPeakMean, 1)
'2760      Else
'2770          datSpringPeakMean = 0
'2780      End If
'
'2790      If lngFallPeakCount > 0 Then
'2800          datFallPeakMean = CDate(lngFallPeakTotal / lngFallPeakCount)
'2810          .Cells(row, colFallPeak) = datFallPeakMean
'2820          .range(.Cells(row, colFallPeak), .Cells(row, colFallPeak)).NumberFormat = "mmm d"
'2830          Call getTableColFromFLDSeasonStat(fld, "Fall", conStatSeasonPeak, intTable, intTableCol)
'2840          docRange.Tables(intTable).Cell(intTableRow, intTableCol).range.Text = _
'                  ConvertDateToEnglishString(datFallPeakMean, 1)
'2850      Else
'2860          datFallPeakMean = 0
'2870      End If
'
'2880      If lngSpringDETDaysCount > 0 And lngSpringDETDaysTotal > 0 Then
'2890          lngSpringSpeciesDETDaysMean = lngSpringSpeciesDETDaysTotal / lngSpringDETDaysCount
'2900          lngSpringSpeciesDETDaysPercent = Round(100 * lngSpringSpeciesDETDaysTotal / lngSpringDETDaysTotal, 0)
'2910          strStat = lngSpringSpeciesDETDaysMean & " (" & _
'                  lngSpringSpeciesDETDaysPercent & "%)"
'2920          .Cells(row, colSpringDays) = strStat
'2930          Call getTableColFromFLDSeasonStat(fld, "Spring", conStatSeasonDays, intTable, intTableCol)
'2940          docRange.Tables(intTable).Cell(intTableRow, intTableCol).range.Text = strStat
'2950      Else
'2960          lngSpringSpeciesDETDaysMean = 0
'2970          lngSpringSpeciesDETDaysPercent = 0
'2980      End If
'
'2990      If lngFallDETDaysCount > 0 And lngFallDETDaysTotal > 0 Then
'3000          lngFallSpeciesDETDaysMean = lngFallSpeciesDETDaysTotal / lngFallDETDaysCount
'3010          lngFallSpeciesDETDaysPercent = Round(100 * lngFallSpeciesDETDaysTotal / lngFallDETDaysTotal, 0)
'3020          strStat = lngFallSpeciesDETDaysMean & " (" & _
'                  lngFallSpeciesDETDaysPercent & "%)"
'3030          .Cells(row, colFallDays) = strStat
'3040           Call getTableColFromFLDSeasonStat(fld, "Fall", conStatSeasonDays, intTable, intTableCol)
'3050          docRange.Tables(intTable).Cell(intTableRow, intTableCol).range.Text = strStat
'3060      Else
'3070          lngFallSpeciesDETDaysMean = 0
'3080          lngFallSpeciesDETDaysPercent = 0
'3090      End If
'
'3100  End If
'
'3110  End With
'
'      DD Error Handler Start
'Exit_label:
'3120       Exit Sub
'Err_label:
'3130       Select Case Err.Number
'           Case Else
'3140            Call LogError("basMBO10YearProgramReportSpecies", "StatSpeciesMean")
'3150       End Select
'3160       Resume Exit_label
'      DD Error Handler End
'    End Sub
'
'---------------------------------------------------------------------------------------
' toColFromStatSeason
'---------------------------------------------------------------------------------------
' Not called
'
'Private Function toColFromStatSeason(ByVal strSeason As String, ByVal stat As Integer)
'10    On Error GoTo Err_label
'
'20        Select Case strSeason
'          Case "Spring"
'30            Select Case stat
'              Case conStatSeasonFirst
'40                toColFromStatSeason = 4
'50            Case conStatSeasonPeak
'60                toColFromStatSeason = 5
'70            Case conStatSeasonLast
'80                toColFromStatSeason = 6
'90            Case conStatSeasonSpan
'100               toColFromStatSeason = 7
'110           Case conStatSeasonDays
'120               toColFromStatSeason = 8
'130           Case conStatSeasonHigh
'140               toColFromStatSeason = 9
'150           Case conStatSeasonTotal
'160               toColFromStatSeason = 10
'170           End Select
'180       Case "Fall"
'190           Select Case stat
'              Case conStatSeasonFirst
'200               toColFromStatSeason = 11
'210           Case conStatSeasonPeak
'220               toColFromStatSeason = 12
'230           Case conStatSeasonLast
'240               toColFromStatSeason = 13
'250           Case conStatSeasonSpan
'260               toColFromStatSeason = 14
'270           Case conStatSeasonDays
'280               toColFromStatSeason = 15
'290           Case conStatSeasonHigh
'300               toColFromStatSeason = 16
'310           Case conStatSeasonTotal
'320               toColFromStatSeason = 17
'330           End Select
'
'340       End Select
'
'      DD Error Handler Start
'Exit_label:
'350        Exit Function
'Err_label:
'360        Select Case Err.Number
'           Case Else
'370             Call LogError("basMBO10YearProgramReportSpecies", "toColFromStatSeason")
'380        End Select
'390        Resume Exit_label
'      DD Error Handler End
'End Function
'
'---------------------------------------------------------------------------------------
' toColFromStatPeriod
'---------------------------------------------------------------------------------------
'
'Private Function toColFromStatPeriod(ByVal strSeason As String, ByVal p As Integer)
'10    On Error GoTo Err_label
'
'20        Select Case strSeason
'          Case "Winter"
'30             toColFromStatPeriod = 17 + p
'40        Case "Spring"
'50            toColFromStatPeriod = 17 + 6 + p
'60        Case "Summer"
'70            toColFromStatPeriod = 17 + 6 + 11 + p
'80        Case "Fall"
'90            toColFromStatPeriod = 17 + 6 + 11 + 3 + p
'100       End Select
'
'      DD Error Handler Start
'Exit_label:
'110        Exit Function
'Err_label:
'120        Select Case Err.Number
'           Case Else
'130             Call LogError("basMBO10YearProgramReportSpecies", "toColFromStatPeriod")
'140        End Select
'150        Resume Exit_label
'      DD Error Handler End
'End Function
'
'---------------------------------------------------------------------------------------
' getTableColFromFLDSeasonPeriod
'---------------------------------------------------------------------------------------
' intFld strSeason => intTable intTableCol
' DET    Winter    => 2        intPeriod + 1
' DET    Spring    => 2        intPeriod + 7
' DET    Summer    => 3        intPeriod + 1
' DET    Fall      => 3        intPeriod + 4
' BND    Winter    => 4        intPeriod + 1
' BND    Spring    => 5        intPeriod + 7
' BND    Summer    => 6        intPeriod + 1
' BND    Fall      => 7        intPeriod + 4
'
'
'Private Sub getTableColFromFLDSeasonPeriod( _
'    ByVal intFld As Integer, ByVal strSeason As String, ByVal intPeriod As Integer, _
'    ByRef intTable As Integer, ByRef intTableCol As Integer)
'
'10    On Error GoTo Err_label
'
'20    Select Case intFld
'      Case conDET
'30        intTable = 2
'40    Case conBND
'50        intTable = 4
'60    End Select
'
'70    Select Case strSeason
'      Case "Winter"
'80        intTableCol = 1 + intPeriod
'90    Case "Spring"
'100       intTableCol = 7 + intPeriod
'110   Case "Summer"
'120       intTableCol = 1 + intPeriod
'130       intTable = intTable + 1
'140   Case "Fall"
'150       intTableCol = 4 + intPeriod
'160       intTable = intTable + 1
'170   End Select
'
'      DD Error Handler Start
'Exit_label:
'180        Exit Sub
'Err_label:
'190        Select Case Err.Number
'           Case Else
'200             Call LogError("basMBO10YearProgramReportSpecies", "getTableColFromFLDSeasonPeriod")
'210        End Select
'220        Resume Exit_label
'      DD Error Handler End
'
'End Sub
'
'---------------------------------------------------------------------------------------
' getTableColFromFLDSeason
'---------------------------------------------------------------------------------------
'
'Private Sub getTableColFromFLDSeason( _
'    ByVal intFld As Integer, ByVal strSeason As String, _
'    ByRef intTable As Integer, ByRef intTableCol As Integer)
'
'10    On Error GoTo Err_label
'
'20    Select Case intFld
'      Case conDET
'30        intTable = 2
'40    Case conBND
'50        intTable = 4
'60    End Select
'
'70    Select Case strSeason
'      Case "Winter"
'80        intTableCol = 7
'90    Case "Spring"
'100       intTableCol = 18
'110   Case "Summer"
'120       intTableCol = 4
'130       intTable = intTable + 1
'140   Case "Fall"
'150       intTableCol = 18
'160       intTable = intTable + 1
'170   Case Else
'180       MsgBox "Invalid season " & strSeason
'190       End
'200   End Select
'
'      DD Error Handler Start
'Exit_label:
'210        Exit Sub
'Err_label:
'220        Select Case Err.Number
'           Case Else
'230             Call LogError("basMBO10YearProgramReportSpecies", "getTableColFromFLDSeason")
'240        End Select
'250        Resume Exit_label
'      DD Error Handler End
'
'End Sub
'
'---------------------------------------------------------------------------------------
' getTableColFromFLDSeasonStat
' DET only
' Spring, Fall only
'---------------------------------------------------------------------------------------
' intFld is not used since both the OBS and BAND tables have the same layout
'
'Private Sub getTableColFromFLDSeasonStat( _
'    ByVal intFld As Integer, ByVal strSeason As String, ByVal intStat As Integer, _
'    ByRef intTable As Integer, ByRef intTableCol As Integer)
'
'10    On Error GoTo Err_label
'
'20    intTable = 1
'
'30    Select Case strSeason
'      Case "Spring"
'40        intTableCol = 2 + intStat
'50    Case "Fall"
'60        intTableCol = 9 + intStat
'70    End Select
'
'      DD Error Handler Start
'Exit_label:
'80         Exit Sub
'Err_label:
'90         Select Case Err.Number
'           Case Else
'100             Call LogError("basMBO10YearProgramReportSpecies", "getTableColFromFLDSeasonStat")
'110        End Select
'120        Resume Exit_label
'      DD Error Handler End
'
'End Sub
'
'
'---------------------------------------------------------------------------------------
' WordGenerateTableSpecies
'---------------------------------------------------------------------------------------
'
'Private Sub WordGenerateTableSpecies( _
'    ByRef wd As Word.Application, _
'    ByRef doc As Word.Document, _
'    ByRef range As Word.range)
'
'10    On Error GoTo Err_label
'
'      Dim lngColourSpring As Long
'      Dim lngColourFall As Long
'      Dim lngColourSummer As Long
'      Dim lngColourWinter As Long
'
'20    lngColourSpring = RGB(214, 227, 188)
'30    lngColourFall = RGB(255, 169, 83)
'40    lngColourSummer = RGB(229, 184, 183)
'50    lngColourWinter = RGB(184, 2014, 228)
'
'      Dim row As Integer
'      Dim col As Integer
'
'      Dim dblLeftPadding As Double    ' in cm
'      Dim dblRightPadding As Double
'      Dim dblTopPadding As Double
'      Dim dblBottomPadding As Double
'      Dim intNumColumns As Integer
'
'60    dblLeftPadding = 0.05
'70    dblRightPadding = 0.05
'80    dblTopPadding = 0
'90    dblBottomPadding = 0
'
'      Dim dblWidthColumn1 As Double
'      Dim dblWidthSeasonWinter As Double
'      Dim dblWidthSeasonSpring As Double
'      Dim dblWidthSeasonSummer As Double
'      Dim dblWidthSeasonFall As Double
'      Dim dblWidthPeriodWinterSpring As Double
'      Dim dblWidthPeriodSummerFall As Double
'
'
'100   dblWidthColumn1 = 1.59
'110   dblWidthSeasonWinter = 1.13
'120   dblWidthSeasonSpring = 1.13
'130   dblWidthSeasonSummer = 1.2
'140   dblWidthSeasonFall = 1.13
'150   dblWidthPeriodWinterSpring = (18.3 - dblWidthColumn1 - dblWidthSeasonWinter - dblWidthSeasonSpring) / 15
'160   dblWidthPeriodSummerFall = (18.3 - dblWidthColumn1 - dblWidthSeasonSummer - dblWidthSeasonFall) / 16
'
'      Dim intTable As Integer
'
'170   For intTable = 1 To 5
'
'180       Select Case intTable
'          Case 1
'190           intNumColumns = 15
'200       Case 2, 4
'210           intNumColumns = 18
'220       Case 3, 5
'230           intNumColumns = 19
'240       End Select
'
'250       doc.Tables.Add range:=range, NumRows:=3, NumColumns:=intNumColumns
'260       range.Expand (wdTable)
'270       With range.Tables(1)
'
'280           .Borders.InsideLineStyle = wdLineStyleSingle
'290           .Borders.OutsideLineStyle = wdLineStyleSingle
'
'300           .LeftPadding = doc.Application.CentimetersToPoints(dblLeftPadding)
'310           .RightPadding = doc.Application.CentimetersToPoints(dblRightPadding)
'320           .TopPadding = doc.Application.CentimetersToPoints(dblBottomPadding)
'330           .BottomPadding = doc.Application.CentimetersToPoints(dblBottomPadding)
'
'               Center the table
'
'340           .Rows.Alignment = wdAlignRowCenter
'
'350           .Columns(1).Width = doc.Application.CentimetersToPoints(dblWidthColumn1)
'
'360           Select Case intTable
'              Case 1, 2, 3
'370               .Cell(1, 1).range.Text = "Observed"
'380           Case 4, 5
'390               .Cell(1, 1).range.Text = "Banded"
'400           End Select
'
'410           .Cell(1, 1).Shading.BackgroundPatternColor = RGB(255, 255, 153)
'
'420           Select Case intTable
'              Case 1
'
'15                Columns
'
'430               .Columns(2).Width = doc.Application.CentimetersToPoints(1.16)
'440               .Columns(3).Width = doc.Application.CentimetersToPoints(1.16)
'450               .Columns(4).Width = doc.Application.CentimetersToPoints(1.16)
'460               .Columns(5).Width = doc.Application.CentimetersToPoints(1.3)
'470               .Columns(6).Width = doc.Application.CentimetersToPoints(1.16)
'480               .Columns(7).Width = doc.Application.CentimetersToPoints(1.16)
'490               .Columns(8).Width = doc.Application.CentimetersToPoints(1.16)
'500               .Columns(9).Width = doc.Application.CentimetersToPoints(1.59)
'510               .Columns(10).Width = doc.Application.CentimetersToPoints(1.16)
'520               .Columns(11).Width = doc.Application.CentimetersToPoints(1.16)
'530               .Columns(12).Width = doc.Application.CentimetersToPoints(1.09)
'540               .Columns(13).Width = doc.Application.CentimetersToPoints(1.3)
'550               .Columns(14).Width = doc.Application.CentimetersToPoints(1.09)
'560               .Columns(15).Width = doc.Application.CentimetersToPoints(1.16)
'
'
'Dim dblTableWidth As Double
'570   dblTableWidth = 0
'580   For col = 1 To 15
'590       dblTableWidth = dblTableWidth + .Columns(col).Width
'600   Next
'
'610               .Cell(1, 2).range.Text = "First"
'620               .Cell(1, 3).range.Text = "Peak"
'630               .Cell(1, 4).range.Text = "Last"
'640               .Cell(1, 5).range.Text = "Span"
'650               .Cell(1, 6).range.Text = "# days"
'660               .Cell(1, 7).range.Text = "High"
'670               .Cell(1, 8).range.Text = "Total"
'680               .Cell(1, 9).range.Text = "First"
'690               .Cell(1, 10).range.Text = "Peak"
'700               .Cell(1, 11).range.Text = "Last"
'710               .Cell(1, 12).range.Text = "Span"
'720               .Cell(1, 13).range.Text = "# days"
'730               .Cell(1, 14).range.Text = "High"
'740               .Cell(1, 15).range.Text = "Total"
'750               .Cell(3, 1).range.Text = "Mean"
'
'760               For col = 2 To 8
'770                   .Cell(1, col).Shading.BackgroundPatternColor = lngColourSpring
'780               Next
'790               For col = 9 To 15
'800                   .Cell(1, col).Shading.BackgroundPatternColor = lngColourFall
'810               Next
'820               .Cell(3, 1).Shading.BackgroundPatternColor = lngColourFall
'
'830               For row = 1 To 3
'840                   .Cell(row, 1).Borders(wdBorderRight).LineWidth = wdLineWidth150pt
'850                   .Cell(row, 8).Borders(wdBorderRight).LineWidth = wdLineWidth150pt
'860               Next
'
'870           Case 2, 4
'
'18                  Columns
'
'880               For col = 2 To 6
'890                   .Columns(2).Width = doc.Application.CentimetersToPoints(dblWidthPeriodWinterSpring)
'900               Next
'910               .Columns(7).Width = doc.Application.CentimetersToPoints(dblWidthSeasonWinter)
'920               For col = 8 To 17
'930                   .Columns(col).Width = doc.Application.CentimetersToPoints(dblWidthPeriodWinterSpring)
'940               Next
'
'Dim dblTable2Width As Double
'950   dblTable2Width = 0
'960   For col = 1 To 17
'970       dblTable2Width = dblTable2Width + .Columns(col).Width
'980   Next
'990   .Columns(18).Width = dblTableWidth - dblTable2Width
'
'1000              .Cell(1, 2).range.Text = "Nov"
'1010              .Cell(1, 3).range.Text = "Dec"
'1020              .Cell(1, 4).range.Text = "Jan"
'1030              .Cell(1, 5).range.Text = "Feb"
'1040              .Cell(1, 6).range.Text = "Mar"
'1050              .Cell(1, 7).range.Text = "Winter"
'1060              .Cell(1, 8).range.Text = "S1"
'1070              .Cell(1, 9).range.Text = "S2"
'1080              .Cell(1, 10).range.Text = "S3"
'1090              .Cell(1, 11).range.Text = "S4"
'1100              .Cell(1, 12).range.Text = "S5"
'1110              .Cell(1, 13).range.Text = "S6"
'1120              .Cell(1, 14).range.Text = "S7"
'1130              .Cell(1, 15).range.Text = "S8"
'1140              .Cell(1, 16).range.Text = "S9"
'1150              .Cell(1, 17).range.Text = "S10"
'1160              .Cell(1, 18).range.Text = "Spring"
'
'1170              For col = 1 To 7
'1180                  .Cell(1, col).Shading.BackgroundPatternColor = lngColourWinter
'1190              Next
'1200              For col = 8 To 18
'1210                  .Cell(1, col).Shading.BackgroundPatternColor = lngColourSpring
'1220              Next
'
'1230              .Cell(2, 7).Shading.BackgroundPatternColor = lngColourWinter
'1240              .Cell(2, 18).Shading.BackgroundPatternColor = lngColourSpring
'
'1250              For row = 1 To 3
'1260                  .Cell(row, 1).Borders(wdBorderRight).LineWidth = wdLineWidth150pt
'1270                  .Cell(row, 7).Borders(wdBorderRight).LineWidth = wdLineWidth150pt
'1280              Next
'
'1290          Case 3, 5
'
'19                  Columns
'
'1300              .Columns(2).Width = doc.Application.CentimetersToPoints(dblWidthPeriodSummerFall)
'1310              .Columns(3).Width = doc.Application.CentimetersToPoints(dblWidthPeriodSummerFall)
'1320              .Columns(4).Width = doc.Application.CentimetersToPoints(dblWidthSeasonSummer)
'1330              For col = 5 To 18
'1340                  .Columns(col).Width = doc.Application.CentimetersToPoints(dblWidthPeriodSummerFall)
'1350              Next
'
'Dim dblTable3Width As Double
'1360  dblTable3Width = 0
'1370  For col = 1 To 18
'1380      dblTable3Width = dblTable3Width + .Columns(col).Width
'1390  Next
'
'1400  .Columns(19).Width = dblTableWidth - dblTable3Width
'
'1410              .Cell(1, 2).range.Text = "Jun"
'1420              .Cell(1, 3).range.Text = "Jul"
'1430              .Cell(1, 4).range.Text = "Summer"
'1440              .Cell(1, 5).range.Text = "F1"
'1450              .Cell(1, 6).range.Text = "F2"
'1460              .Cell(1, 7).range.Text = "F3"
'1470              .Cell(1, 8).range.Text = "F4"
'1480              .Cell(1, 9).range.Text = "F5"
'1490              .Cell(1, 10).range.Text = "F6"
'1500              .Cell(1, 11).range.Text = "F7"
'1510              .Cell(1, 12).range.Text = "F8"
'1520              .Cell(1, 13).range.Text = "F9"
'1530              .Cell(1, 14).range.Text = "F10"
'1540              .Cell(1, 15).range.Text = "F11"
'1550              .Cell(1, 16).range.Text = "F12"
'1560              .Cell(1, 17).range.Text = "F13"
'1570              .Cell(1, 18).range.Text = "F14"
'1580              .Cell(1, 19).range.Text = "Fall"
'
'1590              .Cell(1, 2).Shading.BackgroundPatternColor = lngColourSummer
'1600              .Cell(1, 3).Shading.BackgroundPatternColor = lngColourSummer
'1610              .Cell(1, 4).Shading.BackgroundPatternColor = lngColourSummer
'1620              .Cell(1, 5).Shading.BackgroundPatternColor = lngColourFall
'1630              .Cell(1, 6).Shading.BackgroundPatternColor = lngColourFall
'1640              .Cell(1, 7).Shading.BackgroundPatternColor = lngColourFall
'1650              .Cell(1, 8).Shading.BackgroundPatternColor = lngColourFall
'1660              .Cell(1, 9).Shading.BackgroundPatternColor = lngColourFall
'1670              .Cell(1, 10).Shading.BackgroundPatternColor = lngColourFall
'1680              .Cell(1, 11).Shading.BackgroundPatternColor = lngColourFall
'1690              .Cell(1, 12).Shading.BackgroundPatternColor = lngColourFall
'1700              .Cell(1, 13).Shading.BackgroundPatternColor = lngColourFall
'1710              .Cell(1, 14).Shading.BackgroundPatternColor = lngColourFall
'1720              .Cell(1, 15).Shading.BackgroundPatternColor = lngColourFall
'1730              .Cell(1, 16).Shading.BackgroundPatternColor = lngColourFall
'1740              .Cell(1, 17).Shading.BackgroundPatternColor = lngColourFall
'1750              .Cell(1, 18).Shading.BackgroundPatternColor = lngColourFall
'1760              .Cell(1, 19).Shading.BackgroundPatternColor = lngColourFall
'
'1770              .Cell(2, 4).Shading.BackgroundPatternColor = lngColourSummer
'1780              .Cell(2, 19).Shading.BackgroundPatternColor = lngColourFall
'
'1790              For row = 1 To 3
'1800                  .Cell(row, 1).Borders(wdBorderRight).LineWidth = wdLineWidth150pt
'1810                  .Cell(row, 4).Borders(wdBorderRight).LineWidth = wdLineWidth150pt
'1820              Next
'
'1830           End Select
'
'1840          .Cell(3, 1).range.Text = "Mean"
'1850          .Rows(3).Shading.ForegroundPatternColor = RGB(229, 223, 236)
'
'1860          range.Style = "ddMultiYearSpeciesData"
'1870          .Rows(1).range.Style = "ddMultiYearSpeciesHeaderRow"
'1880          .Cell(2, 1).range.Style = "ddMultiYearSpeciesLabelColumn"
'1890          .Cell(3, 1).range.Style = "ddMultiYearSpeciesLabelColumn"
'1900          Select Case intTable
'              Case 1, 2, 3
'1910              .Cell(1, 1).range.Style = "ddMultiYearSpeciesLabelObserved"
'1920          Case 4, 5
'1930              .Cell(1, 1).range.Style = "ddMultiYearSpeciesLabelBanded"
'1940          End Select
'
'               Repeat heading row at the top of subsequent pages
'
'1950          .Rows.WrapAroundText = False
'
'1960      End With
'
'           Space after each table
'
'1970      Set range = MoveInsertionPointToEndOfDocument(wd, doc)
'1980      range.InsertParagraphAfter
'1990      range.Style = "ddMultiYearSpeciesTableAfter"
'2000      Set range = MoveInsertionPointToEndOfDocument(wd, doc)
'
'2010  Next
'
'          DD Error Handler Start
'Exit_label:
'2020      Exit Sub
'Err_label:
'2030      Select Case Err.Number
'          Case Else
'2040     Call LogError("basMBO10YearProgramReportSpecies", "WordGenerateTableSpecies")
'2050      End Select
'2060      Resume Exit_label
'           DD Error Handler End
'
'End Sub
'
