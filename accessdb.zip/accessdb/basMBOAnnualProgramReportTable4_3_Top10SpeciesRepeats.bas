'---------------------------------------------------------------------------------------
' Module    : basMBOAnnualProgramReportTable4_3_Top10SpeciesRepeats
' Author    : David Davey
'---------------------------------------------------------------------------------------


Option Compare Database
Option Explicit

'---------------------------------------------------------------------------------------
' MBOAnnualProgramReportTable4_3
'---------------------------------------------------------------------------------------
' Top 10 repeats during program
'
'     Species                 # repeats   # individuals
' 1.  Yellow Warbler             35          17
' 2.  Black-capped Chickadee     20          11
' 2.  Song Sparrow               20          12
' 2.  Red-winged Blackbird       20          18
' 5.  Northern Waterthrush       19          14
' ...
'

Public Sub MBOAnnualProgramReportTable4_3( _
    ByRef fValid As Boolean, _
    ByVal intYear As Integer, _
    ByVal strLocation As String, _
    ByVal strProgram As String, _
    ByVal strSeason As String, _
    ByRef wd As Word.Application, _
    ByRef doc As Word.Document, _
    ByRef oExcel As Excel.Application, _
    ByRef oBook As Excel.Workbook, _
    ByVal strTableCaptionHeading As String)

10    On Error GoTo Err_label

      'Dim intYear As Integer
      'Dim strLocation As String
      'Dim strProgram As String
      'Dim strSeason As String

20    SysCmd acSysCmdSetStatus, strSeason & " Top 10 repeats"

      Dim strSQL As String

      ' Save parameters
      '
      '20    intYear = argYear
      '30    strLocation = argLocation
      '40    strProgram = argProgram
      '50    strSeason = argSeason

30    fValid = True

40    If Not (strSeason = "Spring" Or strSeason = "Fall") Then GoTo Exit_label

50    If 0 = DCount("*", "tblDETSpecies", "[Program]='" & strProgram & "' AND [Location]='" & strLocation & "'") Then
60        fValid = False
70        GoTo Exit_label
80    End If

      ' Recalculate D18 (DETCategory) and D20 (Days since most recent prior capture) for each
      '     capture record in the given Location + program

      Dim datFrom As Date
      Dim datTo As Date
90    datFrom = #1/1/1900#
100   datTo = #1/1/3000#

110   strSQL = "DELETE * FROM tblErrorMessage"
120   CurrentDb.Execute strSQL

      Dim rstDETNoCategory As DAO.Recordset
130   Set rstDETNoCategory = CurrentDb.OpenRecordset("tblErrorMessage", dbOpenDynaset)

140   Call UpdateDETCategory(strProgram, strLocation, datFrom, datTo, rstDETNoCategory)

      ' qryMBOAnnualProgramReportTable4_3A
      ' --------------------------------------------
      ' List of species + count of repeat recaptures
      ' --------------------------------------------
      ' tblCaptures
      ' Program = ...
      ' Location = ...
      ' CaptureDate BETWEEN ... AND ...
      ' DETCategory (D18) = "Repeat"
      ' Report Species, CountRepeats = count repeat recapture records DESC

      Dim qdf As QueryDef
150   Set qdf = CurrentDb.QueryDefs("qryMBOAnnualProgramReportTable4_3A")
160   qdf.Parameters("argProgram").value = strProgram
170   qdf.Parameters("argLocation").value = strLocation

      Dim rst As DAO.Recordset
180   Set rst = qdf.OpenRecordset

      ' Create the top 10 table

      ' tblMBOAnnualProgramReportTable4_3B
      ' Rank
      ' Species
      ' Repeats (repeat recapture records)
      ' Row

      Dim rstTop10 As DAO.Recordset
190   Set rstTop10 = CurrentDb.OpenRecordset("tblMBOAnnualProgramReportTable4_3B", dbOpenDynaset)

200   CurrentDb.Execute "DELETE * FROM tblMBOAnnualProgramReportTable4_3B"

      Dim Species As String
      Dim CountSpecies As Integer
      Dim Repeats As Long
      Dim RepeatsSaved As Long
      Dim Rank As Integer
      Dim RankPrevious As Integer
      Dim row As Integer

210   row = 1
220   CountSpecies = 1
230   RepeatsSaved = -1
240   Do While Not rst.EOF

250     Species = Nz(rst("Species"), 0)
260     Repeats = Nz(rst("CountRepeats"), 0)

          ' Pause the ranking when two records have the same number of Repeats
          ' Catch up the ranking when two records do not have the same number of Repeats

270         If Repeats <> RepeatsSaved Then
280               Rank = CountSpecies
290               RankPrevious = Rank
300         Else
          
310         End If
320         If Rank > 10 Then Exit Do
330         CountSpecies = CountSpecies + 1
340         rstTop10.AddNew
350         rstTop10("Species") = Species
360         rstTop10("Repeats") = Repeats
370         rstTop10("Rank") = Rank
380         rstTop10("Row") = row
390         rstTop10.Update
          
400         RepeatsSaved = Repeats
410         row = row + 1
420         rst.MoveNext
430   Loop
440   rst.Close
450   rstTop10.Close
460   Set rst = Nothing
470   Set rstTop10 = Nothing

      ' Append the caption for Table 4-3 (Top 10 species recaptured)

      Dim strTableCaptionBody As String
      Dim strTableCaptionTC As String

      Dim range As Word.range
480   Set range = doc.Characters.Last

490   Select Case strSeason
      Case "Spring"

500   strTableCaptionBody = _
          "Top " & CountSpecies - 1 & " species recaptured most often during the " & intYear & " SMMP. (species with local breeding populations marked with an asterisk)."
510   strTableCaptionTC = _
          "Top " & CountSpecies - 1 & " species recaptured most often during the " & intYear & " SMMP"
520   Case "Fall"

530   strTableCaptionBody = _
          "Top " & CountSpecies - 1 & " species recaptured most often during the " & intYear & " FMMP. (species with local breeding populations marked with an asterisk)."
540   strTableCaptionTC = _
          "Top " & CountSpecies - 1 & " species recaptured most often during the " & intYear & " FMMP"
550   End Select

560   Call InsertTableCaptionXX(wd, doc, "Table", _
        strTableCaptionHeading, _
        strTableCaptionBody, _
        strTableCaptionTC)

      ' Table 4-3 (Top 10 species recaptured)

570   Set range = doc.Characters.Last
580   Call WordGenerateTableTop10SpeciesRepeats(doc, range)

      ' qryMBOAnnualProgramReportTable4_3C
      ' -------------------------------------------------
      ' For each species, list the repeat recapture bands
      ' -------------------------------------------------
      ' tblCaptures
      ' Location = ...
      ' Program = ...
      ' DETCategory (D18) = "Repeat"
      ' Group BY Species, BandPrefix, BandSuffix
      ' Report Species, BandPrefix, BandSuffix


      ' qryMBOAnnualProgramReportTable4_3D
      ' -----------------------------------------------
      ' List species + count repeat capture individuals
      ' -----------------------------------------------
      ' qryMBOAnnualProgramReportTable4_3C
      ' GROUP BY Species
      ' Report Species, CountBands = Count the repeat capture individuals


      ' qryMBOAnnualProgramReportTable4_3E
      ' based on tblMBOAnnualProgramReportTable4_3B (top 10 Repeats)
      '          qryMBOAnnualProgramReportTable4_3D (Count the bands for each species)
      '          tblSpecies (Species English Name)
      ' Row
      ' Rank
      ' SpeciesDescriptionMBO
      ' SpeciesEnglish
      ' Repeats
      ' CountBands
      ' SpeciesDescriptionMBOPrefix

      ' Add rows to the table

      Dim intRank As Integer
      Dim strSpeciesEnglish As String
      Dim intRepeats As Integer
      Dim intCountbands As Integer
      Dim strSpeciesDescriptionMBOPrefix As String           ' ** = Observed local breeder            * = Probable local breeder

      ' Dim Row As Long
590   row = 2

600   Set qdf = CurrentDb.QueryDefs("qryMBOAnnualProgramReportTable4_3E")
610   qdf.Parameters("argProgram").value = strProgram
620   qdf.Parameters("argLocation").value = strLocation

630   Set rst = qdf.OpenRecordset

640   Do While Not rst.EOF

650       If row <> 2 Then
660           range.Tables(1).Rows.Add
670       End If
          
680       intRank = Nz(rst("Rank"))
690       strSpeciesEnglish = Nz(rst("SpeciesEnglish"))
700       If strSpeciesEnglish = "" Then
710           strSpeciesEnglish = Nz(rst("SpeciesDescriptionMBO"))
720       End If
730       intRepeats = Nz(rst("Repeats"))
740       intCountbands = Nz(rst("CountBands"))
750       strSpeciesDescriptionMBOPrefix = Nz(rst("SpeciesDescriptionMBOPrefix"))

760       range.Tables(1).Cell(row, 1).range.Text = intRank & "."
770       range.Tables(1).Cell(row, 2).range.Text = strSpeciesEnglish & IIf(strSpeciesDescriptionMBOPrefix = "**", "*", "")
780       range.Tables(1).Cell(row, 3).range.Text = intRepeats
790       range.Tables(1).Cell(row, 4).range.Text = intCountbands
          
800       row = row + 1
810       rst.MoveNext
820   Loop
830   rst.Close
840   Set rst = Nothing

850   range.Tables(1).Rows(range.Tables(1).Rows.count).Cells.Borders(wdBorderBottom).LineStyle = wdLineStyleSingle
860   range.Tables(1).Rows.WrapAroundText = False
870   range.InsertParagraphAfter

      ' Create an Excel Worksheet

      Dim oSheet As Excel.Worksheet
880   Set oSheet = InsertSheet(oBook, strSeason)
890   oSheet.Name = strSeason & " Top 10 repeats"
           
900   With oSheet
           
          ' Export tblMBOAnnualProgramReportTable4_3B
          
          Dim colLocation As Integer
          Dim colProgram As Integer
          Dim colYear As Integer
          Dim colRank As Integer
          Dim colSpecies As Integer
          Dim colRepeats As Integer
          Dim colRow As Integer
          
          ' Dim intYear As Integer
          Dim strSpecies As String
          Dim lngRepeats As Long
          ' Dim intRank As Integer
          Dim intRow As Integer
          
910       colLocation = 1
920       colProgram = 2
930       colYear = 3
940       colRow = 4
950       colRank = 5
960       colSpecies = 6
970       colRepeats = 7
       
          ' Fill in headers
          
980       .Cells(1, colLocation) = "Location"
990       .Cells(1, colProgram) = "Monitoring Program"
1000      .Cells(1, colYear) = "Year"
1010      .Cells(1, colRow) = "Row"
1020      .Cells(1, colRank) = "Rank"
1030      .Cells(1, colSpecies) = "Species"
1040      .Cells(1, colRepeats) = "Repeats"

1050      Set rst = CurrentDb.OpenRecordset("tblMBOAnnualProgramReportTable4_3B", dbOpenDynaset)
         
      '   Dim row As Long
1060      row = 2
          
1070      Do While Not rst.EOF
          
1080            intRow = Nz(rst("Row"))
1090            intRank = Nz(rst("Rank"))
1100            strSpecies = Nz(rst("Species"))
1110            lngRepeats = Nz(rst("Repeats"))
              
                
1120            .Cells(row, colLocation) = strLocation
1130            .Cells(row, colProgram) = strProgram
1140            .Cells(row, colYear) = intYear
1150            .Cells(row, colRow) = intRow
1160            .Cells(row, colRank) = intRank
1170            .Cells(row, colSpecies) = strSpecies
1180            .Cells(row, colRepeats) = lngRepeats
              
1190            row = row + 1
1200            rst.MoveNext
1210      Loop
1220      rst.Close
1230      Set rst = Nothing
          
          Dim rowEnd As Long
1240      rowEnd = row - 1
          
1250      .range(.columns(1), .columns(colRepeats)).AutoFit
1260      .range(.columns(colYear), .columns(colRank)).HorizontalAlignment = xlCenter
1270      .range(.columns(colRepeats), .columns(colRepeats)).HorizontalAlignment = xlCenter
          
          ' Export qryMBOAnnualProgramReportTable4_3D
          
          Dim colCountBands As Integer
          
1280      colSpecies = 9
1290      colCountBands = 10

          ' Fill in headers
          
1300      .Cells(1, colSpecies) = "Species"
1310      .Cells(1, colCountBands) = "Bands"
          
          Dim lngCountBands As Long
          
1320      Set qdf = CurrentDb.QueryDefs("qryMBOAnnualProgramReportTable4_3D")
1330      qdf.Parameters("argProgram").value = strProgram
1340      qdf.Parameters("argLocation").value = strLocation
1350      Set rst = qdf.OpenRecordset
         
      '   Dim row As Long
1360      row = 2
          
1370      Do While Not rst.EOF
          
1380            strSpecies = Nz(rst("Species"))
1390            lngCountBands = Nz(rst("CountBands"))

1400            .Cells(row, colSpecies) = strSpecies
1410            .Cells(row, colCountBands) = lngCountBands
              
1420            row = row + 1
1430            rst.MoveNext
1440      Loop
1450      rst.Close
1460      Set rst = Nothing
          
      '    Dim rowEnd As Long
1470      rowEnd = row - 1
          
1480      .range(.columns(colSpecies), .columns(colCountBands)).AutoFit
1490      .range(.columns(colCountBands), .columns(colCountBands)).HorizontalAlignment = xlCenter

          ' Export qryMBOAnnualProgramReportTable4_3E

1500      colRow = 12
1510      colRank = 13
1520      colSpecies = 14
1530      colRepeats = 15
1540      colCountBands = 16

          ' Fill in headers
          
1550      .Cells(1, colRow) = "Row"
1560      .Cells(1, colRank) = "Rank"
1570      .Cells(1, colSpecies) = "Species"
1580      .Cells(1, colRepeats) = "Repeats"
1590      .Cells(1, colCountBands) = "Bands"
          
      '   Dim rst As DAO.Recordset
1600      Set qdf = CurrentDb.QueryDefs("qryMBOAnnualProgramReportTable4_3E")
1610      qdf.Parameters("argProgram").value = strProgram
1620      qdf.Parameters("argLocation").value = strLocation
1630      Set rst = qdf.OpenRecordset
         
      '   Dim row As Long
1640      row = 2
          
1650      Do While Not rst.EOF
          
1660            intRow = Nz(rst("Row"))
1670            intRank = Nz(rst("Rank"))
1680            strSpecies = Nz(rst("SpeciesDescriptionMBO"))
1690            lngRepeats = Nz(rst("Repeats"))
1700            lngCountBands = Nz(rst("CountBands"))
              
1710            .Cells(row, colRow) = intRow
1720            .Cells(row, colRank) = intRank
1730            .Cells(row, colSpecies) = strSpecies
1740            .Cells(row, colRepeats) = lngRepeats
1750            .Cells(row, colCountBands) = lngCountBands
              
1760            row = row + 1
1770            rst.MoveNext
1780      Loop
1790      rst.Close
1800      Set rst = Nothing
          
      '    Dim rowEnd As Long
1810      rowEnd = row - 1
          
1820      .range(.columns(colRow), .columns(colCountBands)).AutoFit
1830      .range(.columns(colRow), .columns(colRank)).HorizontalAlignment = xlCenter
1840      .range(.columns(colRepeats), .columns(colCountBands)).HorizontalAlignment = xlCenter
        
1850  End With

1860  Set oSheet = Nothing

1870  SysCmd acSysCmdClearStatus

      'DD Error Handler Start
Exit_label:
1880       Exit Sub
Err_label:
1890       Select Case Err.Number
           Case Else
1900      Call LogError("basMBOAnnualProgramReportTable4_3_Top10SpeciesRepeats", "MBOAnnualProgramReportTable4_3")
1910       End Select
1920       Resume Exit_label
      'DD Error Handler End

End Sub


'---------------------------------------------------------------------------------------
' WordGenerateTableTop10SpeciesRecaptured
'---------------------------------------------------------------------------------------
 
Private Sub WordGenerateTableTop10SpeciesRepeats( _
    ByRef doc As Word.Document, _
    ByRef range As Word.range)

10    On Error GoTo Err_label
    
Dim col As Integer

20    doc.Tables.Add range:=range, NumRows:=2, NumColumns:=4
    
30    range.Expand (wdTable)
40    With range.Tables(1)

50    .range.Style = "ddTop10SpeciesRepeatsData"

60    .LeftPadding = doc.Application.InchesToPoints(0.02)
70    .RightPadding = doc.Application.InchesToPoints(0.02)
80    .TopPadding = doc.Application.InchesToPoints(0.02)

' Center the table

90    .Rows.Alignment = wdAlignRowCenter
'         .Rows.HorizontalPosition = doc.Application.InchesToPoints(0)

' Center vertically row 1

100   .Rows(1).Cells.VerticalAlignment = wdCellAlignVerticalCenter

110   .columns(1).Width = doc.Application.InchesToPoints(0.3)
120   .columns(2).Width = doc.Application.InchesToPoints(2.01)
130   .columns(3).Width = doc.Application.InchesToPoints(1.17)
140   .columns(4).Width = doc.Application.InchesToPoints(1.4)

150   .Cell(1, 2).range.Text = "Species"
160   .Cell(1, 3).range.Text = "# Repeats"
170   .Cell(1, 4).range.Text = "# Individuals"

' Format Header Row

180   Call FormatWordTableRowAsHeader(.Rows(1))

' Format Label Columns

190   .Cell(2, 1).range.ParagraphFormat.Alignment = wdAlignParagraphCenter
200   .Cell(2, 2).range.ParagraphFormat.Alignment = wdAlignParagraphLeft

' Repeat heading row at the top of subsequent pages

210   .Rows(1).HeadingFormat = True
220   .Rows.WrapAroundText = False
    
230   End With

'DD Error Handler Start
Exit_label:
240        Exit Sub
Err_label:
250        Select Case Err.Number
     Case Else
260       Call LogError("basMBOAnnualProgramReportTable4_3_Top10SpeciesRepeats", "WordGenerateTableTop10SpeciesRecaptured")
270        End Select
280        Resume Exit_label
'DD Error Handler End

End Sub
