'---------------------------------------------------------------------------------------
' Module: basMBOAnnualProgramReport7DayMeanGraph
' Author: David Davey
'---------------------------------------------------------------------------------------

Option Compare Database
Option Explicit

Const conDET As Integer = 0
Const conBND As Integer = 1
Const conRET As Integer = 2
Const conREP As Integer = 3
Const conCNS As Integer = 4


' ====================================================================================================================================
' The following module variables are reinitialised for each chart: "Banded Birds", "Banded Species", "Census Species", "DET Species"
' ====================================================================================================================================

' For the annual reports I use real dates (There is only one year to graph, so I do not need standardized (year 2000) dates)
' The graphs in the annual report use 7-day means

'-------
' The following modue variables are copies of the arguments

Private intYear As Integer          ' Report year
Private strLocation As String       ' MBO
Private strSeason As String         ' "Spring" or "Fall"
Private oExcel As Excel.Application
Private oBook As Excel.Workbook
Private strChart As String          ' "Banded Birds", "Banded Species", "Census Species", "DET Species"
Private fDebug As Boolean

' ---------
' The following module variables are filled in by FirstLastDays()

Private datDayFirst As Date         ' first day for which the chart's stat > 0.  For Banding Birds and Banding Species, I use the first capture day instead.
                                    ' A capture day is a day for which the nets were opened bgw. a capture took place
                                    ' N.B. the first capture day <= the first banding day
Private datDayLast As Date          ' last day for which the chart's stat > 0. For Banding Birds and Banding Species, I use the last capture day instead.
                                    ' N.B. the last capture day >= the last banding day
' --------
' dblStat is loaded from BirdsBanded_LoadData() OR Species_LoadData()

Private dblStat() As Double         ' datDayFirst .. datDayLast         the stat recorded each day
                                    ' -1 = no stat
                                    ' 0 = captures > 0, but bandings = 0        this can only occur for Banding Birds and Banding Species

' --------
' the columns are loaded in MBOAnnualProgramReport7DayMeanGraph()

Private colDate As Long
Private colYear As Long
Private colMeanYear As Long
Private colChart As Long        ' Starting column for charts


'---------------------------------------------------------------------------------------
' MBOAnnualProgramReport7DayMeanGraph
'---------------------------------------------------------------------------------------
' 7-day means for Annual reports
 
Public Sub MBOAnnualProgramReport7DayMeanGraph( _
    ByVal argYear As Integer, _
    ByVal argLocation As String, _
    ByVal argSeason As String, _
    ByRef arg_excel As Excel.Application, _
    ByRef arg_book As Excel.Workbook, _
    ByVal arg_chart As String, _
    ByVal arg_debug As Boolean)
           
      ' Save parameters

10    On Error GoTo Err_label

20    intYear = argYear
30    strLocation = argLocation
40    strSeason = argSeason
50    Set oExcel = arg_excel
60    Set oBook = arg_book
70    strChart = arg_chart
80    fDebug = arg_debug

90    colDate = 1
100   colYear = colDate + 1
110   colMeanYear = colYear + 1
120   colChart = colMeanYear + 2


130   Call FirstLastDays(strChart)        ' fill in the module variables datDayFirst, datDayLast

      ' No data => no graph

140   If datDayFirst = 0 Then
150       GoTo Exit_label
160   End If

170   Select Case strChart
      Case "Banded Birds"
180       Call BirdsBanded_LoadData
190   Case "Banded Species"
200       Call Species_LoadData(conBND)
210   Case "Census Species"
220       Call Species_LoadData(conCNS)
230   Case "DET Species"
240       Call Species_LoadData(conDET)
250   End Select

260   Call AdjustBandingStatisticsForCaptureDaysWithNoBandings

270   Call ExportGraphToExcel

          'DD Error Handler Start
Exit_label:
280       Exit Sub
Err_label:
290       Select Case Err.Number
          Case Else
300            Call LogError("basMBOAnnualProgramReport7DayMeanGraph", "MBOAnnualProgramReport7DayMeanGraph")
310       End Select
320       Resume Exit_label
          ' DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' BirdsBanded
'---------------------------------------------------------------------------------------
' Uses module variables intYear, strSeason, strLocation.
' Fills in the module array dblStat()
 
Private Sub BirdsBanded_LoadData()

20    On Error GoTo Err_label

      Dim qdf As QueryDef
      Dim rst As DAO.Recordset
      Dim datDate As Date

      ' Initialise statistics

30    ReDim dblStat(datDayFirst To datDayLast)

40    For datDate = datDayFirst To datDayLast
50        dblStat(datDate) = -1
60    Next


      ' Birds Banded

      ' Fill in dblStat(day) with the number of birds banded on a day

      ' qryMBOAnnualProgramReport7DayMeanGraph_BandedBirds
      ' --------------------------------------------------
      ' tblDETSpecies x tblPrograms
      '
      ' WHERE YearEx = [argYear]                Report year
      ' WHERE Location = [argLocation]          MBO
      ' WHERE Season = [argSeason]              Spring or Fall
      ' WHERE Banded > 0
      ' GROUP BY DateEx
      ' CountBandedBirds = SUM Banded           we are summing over species
      ' HAVING CountBandedBirds > 0
      '
      ' Report DateEx, CountBandedBirds
      ' There is a record for every day in each year x season, for which banding of any species > 0


70    Set qdf = CurrentDb.QueryDefs("qryMBOAnnualProgramReport7DayMeanGraph_BandedBirds")
80    qdf.Parameters("argSeason").value = strSeason
90    qdf.Parameters("argLocation").value = strLocation
100   qdf.Parameters("argYear").value = intYear

110   Set rst = qdf.OpenRecordset

      Dim CountBandedBirds As Integer

120   Do While Not rst.EOF
130       CountBandedBirds = Nz(rst("CountBandedBirds"))
140       datDate = Nz(rst("DateEx"))
150       dblStat(datDate) = CountBandedBirds
160       rst.MoveNext
170   Loop
180   rst.Close
190   Set rst = Nothing

          'DD Error Handler Start
Exit_label:
200       Exit Sub
Err_label:
210       Select Case Err.Number
          Case Else
220      Call LogError("basMBOAnnualProgramReport7DayMeanGraph", "BirdsBanded_LoadData")
230       End Select
240       Resume Exit_label
          ' DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' Species
'---------------------------------------------------------------------------------------
       
Private Sub Species_LoadData(ByVal intFld As Integer)

      Dim qdf As QueryDef
      Dim rst As DAO.Recordset
      Dim strSQL As String

10    On Error GoTo Err_label


      ' ********** Just the first 10 days during debugging *******************

20    If fDebug Then
30        datDayLast = datDayFirst + 10
40    End If

      ' Initialise statistics

50    ReDim dblStat(datDayFirst To datDayLast)

      Dim datDate As Date

60    For datDate = datDayFirst To datDayLast
70        dblStat(datDate) = -1
80    Next

      ' Calculate the number of true species for each day x year

      Dim dicSpecies As Scripting.Dictionary
90    Set dicSpecies = New Scripting.Dictionary
      Dim strSpecies As String


100   Select Case intFld
      Case conBND
110       strSQL = "qryMBOAnnualProgramReport7DayMeanGraph_BandedSpecies"
120   Case conCNS
130       strSQL = "qryMBOAnnualProgramReport7DayMeanGraph_CensusSpecies"
140   Case conDET
150       strSQL = "qryMBOAnnualProgramReport7DayMeanGraph_DETSpecies"
160   End Select

    ' qryMBOAnnualProgramReport7DayMeanGraph_BandedSpecies
    ' ----------------------------------------------------
    ' tblDETSpecies x tblPrograms
    '
    ' WHERE YearEx = [argYear]                Report year
    ' WHERE Location = [argLocation]          MBO
    ' WHERE Season = [argSeason]              Spring or Fall
    ' WHERE Banded > 0
    ' WHERE DateEx = [argDateEx]
    '
    ' Report Species
    
    ' qryMBOAnnualProgramReport7DayMeanGraph_CensusSpecies
    ' ----------------------------------------------------
    ' Same as qryMBOAnnualProgramReport7DayMeanGraph_BandedSpecies but for Census instead of Banded
    
    ' qryMBOAnnualProgramReport7DayMeanGraph_DETSpecies
    ' ----------------------------------------------------
    ' Same as qryMBOAnnualProgramReport7DayMeanGraph_BandedSpecies but for DET instead of Banded

170   Set qdf = CurrentDb.QueryDefs(strSQL)

180   For datDate = datDayFirst To datDayLast

190     qdf.Parameters("argYear").value = intYear
200     qdf.Parameters("argSeason").value = strSeason
210     qdf.Parameters("argLocation").value = strLocation
220     qdf.Parameters("argDateEx").value = datDate
        
230     Set rst = qdf.OpenRecordset
        
        ' Skip if the stat was not measured
        
240     If Not rst.EOF Then
250         Do While Not rst.EOF
260             strSpecies = Nz(rst("Species"))
                 
                ' Add the species + superspecies to the dictionary
        
270             If Not dicSpecies.Exists(strSpecies) Then
280                 Call dicSpecies.Add(strSpecies, strSpecies)
290             End If
300             rst.MoveNext
310         Loop
320         rst.Close
330         Set rst = Nothing

            ' How many true species are in the dictionary ?
        
340         dblStat(datDate) = CountSpeciesInDictionary(dicSpecies)
                 
            ' Empty the dictionary

350         Call dicSpecies.RemoveAll
360     End If
370   Next datDate

          'DD Error Handler Start
Exit_label:
380       Exit Sub
Err_label:
390       Select Case Err.Number
          Case Else
400            Call LogError("basMBOAnnualProgramReport7DayMeanGraph", "Species_LoadData")
410       End Select
420       Resume Exit_label
          ' DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' FirstLastDays
'---------------------------------------------------------------------------------------
' strChart = "Banded Birds", "Banded Species", "Census Species", "DET Species"

Private Sub FirstLastDays(ByVal strChart As String)

      ' Fill in the module variables:
      '     datDayFirst As Date
      '     datDayLast As Date

10    On Error GoTo Err_label

      Dim qdf As QueryDef
      Dim rst As DAO.Recordset

20    Select Case strChart
      Case "Banded Birds", "Banded Species"


        ' qryMBOAnnualProgramReport7DayMeanGraph_A
        ' ----------------------------------------
        ' For a given season, x year, list the days with some captures
        ' -------------------------------------------------
        ' tblDETSpecies x tblPrograms
        '
        ' WHERE Location = [argLocation]
        ' WHERE MonitoringProgramSeason = [argSeason]
        ' WHERE YearEx = [argYear]
        ' HAVING Captures: Sum(Nz([Banded])+Nz([Returns])+Nz([Repeats])+Nz([Observed3])+Nz([Observed4])) > 0
        ' GROUP BY DateEx
        ' Report DateEx
        
        ' qryMBOAnnualProgramReport7DayMeanGraph_B
        ' ----------------------------------------
        ' For a given season x year, list the days where SongbirdNets > 0
        ' ----------------------------------------------------------
        'tblDETDaily x tblPrograms
        '
        ' WHERE Location = [argLocation]
        ' WHERE MonitoringProgramSeason = [argSeason]
        ' WHERE YearEx = [argYear]
        ' WHERE SongbirdNets > 0
        ' Report DateEx
        
        ' qryMBOAnnualProgramReport7DayMeanGraph_C
        ' ----------------------------------------
        ' Capture Days
        ' ----------------------------------------
        ' qryMBOAnnualProgramReport7DayMeanGraph_A UNION qryMBOAnnualProgramReport7DayMeanGraph_B
        '
        ' Report DateEx
        
        ' qryMBOAnnualProgramReport7DayMeanGraph_FirstLastCaptureDays
        ' -----------------------------------------------------------
        ' First and last capture days
        ' -----------------------------------------------------------
        ' qryMBOAnnualProgramReport7DayMeanGraph_C
        '
        ' FirstCaptureDay = MIN DateEx
        ' LastCaptureDay = MAX DateEx
        '
        ' Returns 0 records if there were no capture days
        ' Returns 1 record if there was at lest one capture day
        ' Returns FirstCaptureDay, LastCaptureDay
              
30            Set qdf = CurrentDb.QueryDefs("qryMBOAnnualProgramReport7DayMeanGraph_FirstLastCaptureDays")
40            qdf.Parameters("argYear").value = intYear
50            qdf.Parameters("argSeason").value = strSeason
60            qdf.Parameters("argLocation").value = strLocation
              
70            Set rst = qdf.OpenRecordset
              
80            If rst.EOF Then
90                datDayFirst = 0
100               datDayLast = 0
110           Else
120               datDayFirst = Nz(rst("FirstCaptureDay"))
130               datDayLast = Nz(rst("LastCaptureDay"))
140           End If

150   Case Else

160       Select Case strChart
              Case "Census Species"
170               Set qdf = CurrentDb.QueryDefs("qryMBO10YearProgramReport7DayMeanGraph_CensusMinMaxDates")
180           Case "DET Species"
190               Set qdf = CurrentDb.QueryDefs("qryMBO10YearProgramReport7DayMeanGraph_DETMinMaxDates")
200       End Select
          
          ' qryMBO10YearProgramReport7DayMeanGraph_CensusMinMaxDates
          ' --------------------------------------------------------
          ' For a given season x year determine the earliest and latest banding dates
          '
          ' tblDETSpecies x tblPrograms
          '
          ' WHERE YearEx = [argYear]
          ' WHERE Season = [argSeason]
          ' WHERE Location = [argLocation]
          ' WHERE Census > 0
          ' DateFirst = MIN DateEx
          ' DateLast = MAX DateEx

          ' qryMBO10YearProgramReport7DayMeanGraph_DETMinMaxDates
          ' --------------------------------------------------------
          ' The same as qryMBO10YearProgramReport7DayMeanGraph_CensusMinMaxDates, but for DET instead of Census
              
210       qdf.Parameters("argYear").value = intYear
220       qdf.Parameters("argSeason").value = strSeason
230       qdf.Parameters("argLocation").value = strLocation
          
240       Set rst = qdf.OpenRecordset
          
          ' There is either 1 record (when there was at least one data recorded) or 0 records
          
250       If rst.EOF Then
260           datDayFirst = 0
270           datDayLast = 0
280       Else
290           datDayFirst = Nz(rst("DateFirst"))
300           datDayLast = Nz(rst("DateLast"))
310       End If
          
320       rst.Close
330       Set rst = Nothing

340   End Select


          'DD Error Handler Start
Exit_label:
350       Exit Sub
Err_label:
360       Select Case Err.Number
          Case Else
370      Call LogError("basMBOAnnualProgramReport7DayMeanGraph", "FirstLastDays")
380       End Select
390       Resume Exit_label
          ' DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' ExportGraphToExcel
'---------------------------------------------------------------------------------------
' The data is in the modue array dblStat()
' strChart =  "Banded Birds", "Banded Species", "Census Species", "DET Species"

Private Sub ExportGraphToExcel()

      Dim datDate As Date
      Dim oSheet As Excel.Worksheet

10    On Error GoTo Err_label

20    Set oSheet = InsertSheet(oBook, strSeason)

      Dim strName As String

30    Select Case strChart
      Case "Banded Birds"
40        strName = strSeason & " Graph BND Bird"
50    Case "Banded Species"
60        strName = strSeason & " Graph BND Sp"
70    Case "Census Species"
80        strName = strSeason & " Graph CNS Sp"
90    Case "DET Species"
100       strName = strSeason & " Graph DET Sp"
110   End Select

120   oSheet.Name = strName

      ' Output to Excel

130   With oSheet

140   Select Case strChart
      Case "Banded Birds"
150       .Cells(1, 2) = "Banded Birds"
160   Case "Banded Species"
170       .Cells(1, 2) = "Banded Species"
180   Case "Census Species"
190       .Cells(1, 2) = "Census Species"
200   Case "DET Species"
210       .Cells(1, 2) = "DET Species"
220   End Select

      Dim dblValue As Double

230   For datDate = datDayFirst To datDayLast
240       .Cells(toRowFromDay(datDate), colDate) = datDate
250       dblValue = dblStat(datDate)
260       If dblValue >= 0 Then                                   ' for -1, leave the cell empty
270           .Cells(toRowFromDay(datDate), colYear) = dblValue
280       End If
290   Next

      ' Format the columns

      Dim lngRowFirst As Long
      Dim lngRowLast As Long
300   lngRowFirst = toRowFromDay(datDayFirst)
310   lngRowLast = toRowFromDay(datDayLast)

320   .range(.Cells(lngRowFirst, colDate), .Cells(lngRowLast, colDate)).NumberFormat = "[$-1009]dd-mmm"
330   .range(.Cells(lngRowFirst, colYear), .Cells(lngRowLast, colYear)).NumberFormat = "#0;-#0;0"
340   .range(.Cells(lngRowFirst, colMeanYear), .Cells(lngRowLast, colMeanYear)).NumberFormat = "#0.0;-#0.0;0"

      ' Calculate the means

350   Call Means(oSheet)

      ' Calculate maximums and minimums
      ' Highlight maximum and minimum values

360   Call MinMax(oSheet)

      ' oSheet.range(.Columns(1), .Columns(colMeanYear)).AutoFit

370   .Cells(1, 3) = "7-day running averages"

380   oSheet.range(.columns(1), .columns(colMeanYear)).AutoFit

      ' Generate a multi-year chart

      Dim strXAxisTitle As String
390   Select Case strChart
      Case "Banded Species"
400           strXAxisTitle = "# species banded daily"
410   Case "Census Species"
420           strXAxisTitle = "# species observed daily on census"
430   Case "DET Species"
440           strXAxisTitle = "# species observed daily"
450   End Select

      ' 510   Call MultiYearChart(oSheet, strXAxisTitle:=strXAxisTitle)

      '  Generate a chart for the current year

460   Call CurrentYearChart(oSheet)

470   .range("B2").Select
480   oBook.Application.ActiveWindow.FreezePanes = True


490   End With ' oSheet

500   Set oSheet = Nothing

          'DD Error Handler Start
Exit_label:
510       Exit Sub
Err_label:
520       Select Case Err.Number
          Case Else
530            Call LogError("basMBOAnnualProgramReport7DayMeanGraph", "ExportGraphToExcel")
540       End Select
550       Resume Exit_label
          ' DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' AdjustBandingStatisticsForCaptureDaysWithNoBandings
'---------------------------------------------------------------------------------------

Private Sub AdjustBandingStatisticsForCaptureDaysWithNoBandings()

      ' Insert zeros in dblStat() for Capture Days with no bandings - For Banded Birds OR Banded Species only

      ' =====================================================================================================================================================
      ' A Capture-Day is a day on which net hours > 0 OR  the sum over the day of  Nz(Banded) + Nz(Returns) + Nz(Repeats) + Nz(Alien) + Nz(Replacement)  >  0.
      ' =====================================================================================================================================================

10       On Error GoTo Err_label

20    If strChart = "Banded Birds" Or strChart = "Banded Species" Then

      ' qryMBOAnnualProgramReport7DayMeanGraph_A
      ' ----------------------------------------
      ' For a given season, x year, list the days with some captures
      ' -------------------------------------------------
      ' tblDETSpecies x tblPrograms
      '
      ' WHERE Location = [argLocation]
      ' WHERE MonitoringProgramSeason = [argSeason]
      ' WHERE YearEx = [argYear]
      ' HAVING Captures: Sum(Nz([Banded])+Nz([Returns])+Nz([Repeats])+Nz([Observed3])+Nz([Observed4])) > 0
      ' GROUP BY DateEx
      ' Report DateEx

      ' qryMBOAnnualProgramReport7DayMeanGraph_B
      ' ----------------------------------------
      ' For a given season x year, list the days where SongbirdNets > 0
      ' ----------------------------------------------------------
      'tblDETDaily x tblPrograms
      '
      ' WHERE Location = [argLocation]
      ' WHERE MonitoringProgramSeason = [argSeason]
      ' WHERE YearEx = [argYear]
      ' WHERE SongbirdNets > 0
      ' Report DateEx

      ' qryMBOAnnualProgramReport7DayMeanGraph_C
      ' ----------------------------------------
      ' Capture Days
      ' ----------------------------------------
      ' qryMBOAnnualProgramReport7DayMeanGraph_A UNION qryMBOAnnualProgramReport7DayMeanGraph_B
      '
      ' Report DateEx

      ' qryMBOAnnualProgramReport7DayMeanGraph_D
      ' ----------------------------------------
      ' For a given season x year, list the days with 0 bandings
      '  ---------------------------------------
      ' tblDETSpecies x tblPrograms
      '
      ' WHERE Location = [argLocation]
      ' WHERE MonitoringProgramSeason = [argSeason]
      ' WHERE YearEx = [argYear]
      ' GROUP BY DateEx
      ' BandedNonZero = SUM Nz([Banded])
      ' HAVING BandedNonZero = 0
      '
      ' Report DateEx

      ' qryMBOAnnualProgramReport7DayMeanGraph_E
      ' ----------------------------------------
      ' Capture Days with 0 bandings
      ' ----------------------------------------
      ' qryMBOAnnualProgramReport7DayMeanGraph_C x qryMBOAnnualProgramReport7DayMeanGraph_D
      '
      ' Report DateEx

      Dim datDateEx As Date

      Dim qdf As QueryDef
30    Set qdf = CurrentDb.QueryDefs("qryMBOAnnualProgramReport7DayMeanGraph_E")
40    qdf.Parameters("argYear").value = intYear
50    qdf.Parameters("argSeason").value = strSeason
60    qdf.Parameters("argLocation").value = strLocation

      Dim rst As DAO.Recordset
70    Set rst = qdf.OpenRecordset
80    Do While Not rst.EOF

90        datDateEx = Nz(rst("DateEx"))

          ' Double check we are not about to clobber a valid stat
          
100       If dblStat(datDateEx) = -1 Then
110           dblStat(datDateEx) = 0
120       End If

130       rst.MoveNext
140   Loop
150   rst.Close
160   Set rst = Nothing

170   End If

          'DD Error Handler Start
Exit_label:
180       Exit Sub
Err_label:
190       Select Case Err.Number
          Case Else
200      Call LogError("basMBOAnnualProgramReport7DayMeanGraph", "AdjustBandingStatisticsForCaptureDaysWithNoBandings")
210       End Select
220       Resume Exit_label
          ' DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' Means
'---------------------------------------------------------------------------------------
' Calculate the means
'
' The annual reports use 7-day means

Private Sub Means(ByRef oSheet As Excel.Worksheet)

10       On Error GoTo Err_label

         Dim datDate As Date
         Dim lngCount As Long
         Dim dblSum As Double
         Dim dblValue As Double

20    With oSheet

      Dim intOffset As Integer

30    intOffset = 3

40    For datDate = datDayFirst + 3 To datDayLast - 3
50        lngCount = 0
60        dblSum = 0
70        For intOffset = -3 To 3
80            dblValue = dblStat(datDate + intOffset)
90            If dblValue >= 0 Then
100               lngCount = lngCount + 1
110               dblSum = dblSum + dblValue
120           End If
130       Next
140       If lngCount > 0 Then
150           .Cells(toRowFromDay(datDate), colMeanYear) = dblSum / lngCount
160       End If
170   Next
          
180   End With

          'DD Error Handler Start
Exit_label:
190       Exit Sub
Err_label:
200       Select Case Err.Number
          Case Else
210      Call LogError("basMBOProgramReport_MeanGraphs", "Means")
220       End Select
230       Resume Exit_label
          ' DD Error Handler End
End Sub

Private Function toRowFromDay(ByVal datDate)

10    On Error GoTo Err_label

20    toRowFromDay = datDate - datDayFirst + 3
          
          'DD Error Handler Start
Exit_label:
30        Exit Function
Err_label:
40        Select Case Err.Number
          Case Else
50             Call LogError("basMBOAnnualProgramReport7DayMeanGraph", "toRowFromDay")
60        End Select
70        Resume Exit_label
          ' DD Error Handler End
End Function


'---------------------------------------------------------------------------------------
' MinMax
'---------------------------------------------------------------------------------------
' Calculate maximums of the raw data
' Highlight maximums of the raw data


Private Sub MinMax(ByRef oSheet As Excel.Worksheet)


          Dim dblMax As Double
          Dim datDate As Date
          Dim dblValue As Double

10    On Error GoTo Err_label

20    With oSheet

30    .Cells(toRowFromDay(datDayLast) + 1, 1) = "Max"
40    .range(.Cells(toRowFromDay(datDayLast) + 1, 1), .Cells(toRowFromDay(datDayLast) + 1, 1)).Font.Bold = True

50    dblMax = 0
60    For datDate = datDayFirst To datDayLast
70        dblValue = dblStat(datDate)
80        If dblValue >= 0 Then
90            If dblValue > dblMax Then
100               dblMax = dblValue
110           End If
120       End If
130   Next

140   .Cells(toRowFromDay(datDayLast) + 1, colYear) = dblMax

150   For datDate = datDayFirst To datDayLast
160       If dblStat(datDate) = dblMax Then
170           .range(.Cells(toRowFromDay(datDate), colYear), .Cells(toRowFromDay(datDate), colYear)).Interior.Color = vbYellow
180       End If
190   Next

200   .range(.Cells(toRowFromDay(datDayLast) + 1, colYear), .Cells(toRowFromDay(datDayLast) + 1, colYear)).NumberFormat = "#0;-#0;0"
210   .range(.Cells(toRowFromDay(datDayLast) + 1, colYear), .Cells(toRowFromDay(datDayLast) + 1, colYear)).Interior.Color = vbYellow


220   End With


          'DD Error Handler Start
Exit_label:
230       Exit Sub
Err_label:
240       Select Case Err.Number
          Case Else
250      Call LogError("basMBOAnnualProgramReport7DayMeanGraph", "MinMax")
260       End Select
270       Resume Exit_label
          ' DD Error Handler End

End Sub


'---------------------------------------------------------------------------------------
' CurrentYearChart
'---------------------------------------------------------------------------------------
' Chart for current year
'
' strSeason is a module-level variable

Private Sub CurrentYearChart(ByRef oSheet As Excel.Worksheet)

      Dim lngleft As Long
      Dim lngTop As Long
      Dim oChartObject As Excel.ChartObject
      Dim oChart As Excel.Chart
           
      ' The columns are 1, toColFromYear(intYear), toColMeanFromYear(intYear)
      ' The rows are rowTop, rowBottom

      Dim rowTop As Long
      Dim rowBottom As Long


10    On Error GoTo Err_label

20    rowTop = toRowFromDay(datDayFirst)
30    rowBottom = toRowFromDay(datDayLast)

40    With oSheet
            
50    lngleft = .range(.Cells(4, colChart), .Cells(4, colChart)).Left
60    lngTop = .range(.Cells(4, colChart), .Cells(4, colChart)).Top

70    Set oChartObject = oSheet.ChartObjects.Add(lngleft, lngTop, 600, 250)
80    Set oChart = oChartObject.Chart

      Dim oRange1 As Excel.range
      Dim oRange2 As Excel.range
      Dim oRange3 As Excel.range

90    Set oRange1 = .range(.Cells(rowTop, colDate), .Cells(rowBottom, colDate))                 ' dates
100   Set oRange2 = .range(.Cells(rowTop, colYear), .Cells(rowBottom, colYear))                 ' stat - bar graph
110   Set oRange3 = .range(.Cells(rowTop, colMeanYear), .Cells(rowBottom, colMeanYear))         ' 7- day average of stat - line graph

120   End With

130   With oChart
140       With .SeriesCollection.NewSeries
150           .XValues = oRange1
160           .Values = oRange2
170       End With
180       With .SeriesCollection.NewSeries
190           .XValues = oRange1
200           .Values = oRange3
210       End With

      '    .SetSourceData Source:=oExcel.Union(oRange1, oRange2, oRange3)
220       .HasLegend = False
230       .Axes(xlCategory, xlPrimary).TickLabels.Orientation = 90
240       Select Case strSeason
          Case "Spring"
250           If strChart = "Banded Birds" Or strChart = "Banded Specie" Then
260               .Axes(xlCategory).MajorUnit = 1
270           Else
280               .Axes(xlCategory).MajorUnit = 2
290           End If
300       Case "Fall"
310            .Axes(xlCategory).MajorUnit = 4
320       End Select
330       .SeriesCollection(1).ChartType = xlColumnClustered
340       .SeriesCollection(1).Interior.Color = RGB(0, 112, 192) ' blue
350       .SeriesCollection(2).ChartType = xlLine
360       .SeriesCollection(2).Border.Color = vbBlack
370       .PlotVisibleOnly = False

      '360       .Axes(xlCategory, xlPrimary).TickLabels.NumberFormat = "d-mmm"

380    End With
          
390   Set oChart = Nothing
400   Set oChartObject = Nothing

' 580   oSheet.range(oSheet.Columns(colDateYearLast), oSheet.Columns(colDateYearLast)).Hidden = True


          'DD Error Handler Start
Exit_label:
410       Exit Sub
Err_label:
420       Select Case Err.Number
          Case Else
430      Call LogError("basMBOProgramReport_MeanGraphs", "CurrentYearChart")
440       End Select
450       Resume Exit_label
          ' DD Error Handler End

End Sub
