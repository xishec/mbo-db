'---------------------------------------------------------------------------------------
' Module    : basMBOAnnualProgramReportTable3_5_Returns
' Author    : David Davey
'---------------------------------------------------------------------------------------

Option Compare Database
Option Explicit

'---------------------------------------------------------------------------------------
' MBOAnnualProgramReportTable3_5
'---------------------------------------------------------------------------------------
'
' List of returns captured during <season> sorted by time elapsed
' season = Winter, Spring, Summer, Fall

Public Sub MBOAnnualProgramReportTable3_5( _
    ByRef fValid As Boolean, _
    ByVal intYear As Integer, _
    ByVal strLocation As String, _
    ByVal strProgram As String, _
    ByVal strSeason As String, _
    ByRef wd As Word.Application, _
    ByRef doc As Word.Document, _
    ByRef oExcel As Excel.Application, _
    ByRef oBook As Excel.Workbook, _
    ByVal strTableCaptionHeading As String)

10    On Error GoTo Err_label

20    SysCmd acSysCmdSetStatus, strSeason & " returns"

30    fValid = True

      Dim range As Word.range
      Dim strTableCaptionBody As String

      Dim strFontName As String
40    strFontName = "Arial"

50    Set range = doc.Characters.Last

60    Select Case strSeason
      Case "Winter"
          Dim strWinterPeriod As String
70        strWinterPeriod = intYear - 1 & "-" & intYear
80        strTableCaptionBody = _
               "List of returns captured during the " & strWinterPeriod & " winter population monitoring program"
90    Case "Spring"
100       strTableCaptionBody = _
              "List of returns captured during the " & intYear & " SMMP"
110   Case "Summer"
120       strTableCaptionBody = _
              "List of returns captured during the " & intYear & " MAPS program"
130   Case "Fall"
140       strTableCaptionBody = _
              "List of returns captured during the " & intYear & " FMMP"
150   End Select


160    Call InsertTableCaptionXX(wd, doc, "Table", _
            strTableCaptionHeading, _
            strTableCaptionBody & ", sorted by time elapsed.", _
            strTableCaptionBody)

170   Set range = doc.Characters.Last
180   Call WordGenerateTableReturns(doc, range, strSeason, intYear)

      ' populate tblMBOAnnualProgramReport3_5
      '
      ' tblMBOAnnualProgramReport3_5
      ' ----------------------------------
      ' For a season, info for each return
      ' ----------------------------------
      ' ReportYear
      ' BandPrefix
      ' BandSuffix
      ' Species
      ' AgeReturn
      ' SexReturn
      ' AgeBanding
      ' SexBanding
      ' ReturnDate
      ' PriorCaptureDate
      ' BandingDate
      ' TimeElapsed
      ' Years
      ' Months
      ' Days


      Dim strPrefix As String
      Dim strSuffix As String
      Dim datCaptureDate As Date
      Dim datPriorCaptureDate As Date
      Dim lngTimeElapsed As Long
      Dim strSpecies As String
      Dim strAgeReturn As String
      Dim strSexReturn As String
      Dim strAgeBanding As String
      Dim strSexBanding As String
      Dim datReturnDate As Date
      Dim datBandingDate As Date

190   CurrentDb.Execute "DELETE * FROM tblMBOAnnualProgramReportTable3_5"

      Dim rst2 As DAO.Recordset
200   Set rst2 = CurrentDb.OpenRecordset("tblMBOAnnualProgramReportTable3_5", dbOpenDynaset)

      ' qryMBOAnnualProgramReport3_5
      ' -----------------------------------------------------------------------------------------------------------------------------------------------------
      ' For a season, for each recapture record, gather the info from the recapture record and from the corresponding banding (or ist foreign capture) record
      ' -----------------------------------------------------------------------------------------------------------------------------------------------------
      ' ReportYear
      ' BandPrefix
      ' BandSuffix
      ' RecaptureDate
      ' BandingDate
      ' AgeRecapture
      ' SexRecature
      ' AgeBanding
      ' SexBanding
      ' Species

      Dim qdf As QueryDef
210   Set qdf = CurrentDb.QueryDefs("qryMBOAnnualProgramReportTable3_5")
220   qdf.Parameters("argSeason").value = strSeason
230   qdf.Parameters("argLocation").value = strLocation

      Dim rst As DAO.Recordset
240   Set rst = qdf.OpenRecordset
250   Do While Not rst.EOF

260       strPrefix = Nz(rst("BandPrefix"))
270       strSuffix = Nz(rst("BandSuffix"))
280       datCaptureDate = Nz(rst("RecaptureDate"))
290       If datCaptureDate = 0 Then GoTo Continue_label
          
          Dim strWhere As String
300       strWhere = _
              "Location = '" & strLocation & "' AND " & _
              " BandPrefix = '" & strPrefix & "' AND " & _
              " BandSuffix = '" & strSuffix & "' AND " & _
              " Disposition IN ('1','R','F') AND " & _
              " CaptureDate < #" & Format(datCaptureDate, "mm/dd/yyyy") & "#"

310       datPriorCaptureDate = Nz(DMax("CaptureDate", "tblCaptures", strWhere))
320       If datPriorCaptureDate = 0 Then GoTo Continue_label
          
330       lngTimeElapsed = datCaptureDate - datPriorCaptureDate
340       If lngTimeElapsed < 90 Then GoTo Continue_label
          
350       rst2.AddNew
360       rst2("BandPrefix") = strPrefix
370       rst2("BandSuffix") = strSuffix
380       rst2("Species") = Nz(rst("Species"))
390       rst2("AgeReturn") = Nz(rst("AgeRecapture"))
400       rst2("SexReturn") = Nz(rst("SexRecapture"))
410       rst2("AgeBanding") = Nz(rst("AgeBanding"))
420       rst2("SexBanding") = Nz(rst("SexBanding"))
430       rst2("ReturnDate") = datCaptureDate
440       rst2("PriorCaptureDate") = datPriorCaptureDate
450       rst2("BandingDate") = Nz(rst("BandingDate"))
460       rst2("TimeElapsed") = lngTimeElapsed
470       rst2("ReportYear") = Nz(rst("YearEx"))

          Dim intYearsElapsed As Integer
          Dim intMonthsElapsed As Integer
          Dim intDaysElapsed As Integer
          
480       Call getTimeElapsed(datCaptureDate, datPriorCaptureDate, _
              intYearsElapsed, intMonthsElapsed, intDaysElapsed)

490       rst2("Years") = intYearsElapsed
500       rst2("Months") = intMonthsElapsed
510       rst2("Days") = intDaysElapsed

520       rst2.Update
          
Continue_label:
530       rst.MoveNext
540   Loop
550   rst.Close
560   Set rst = Nothing
570   rst2.Close
580   Set rst2 = Nothing

      Dim row As Long
590   row = 2

      Dim strSQL As String
600   strSQL = "SELECT * FROM tblMBOAnnualProgramReportTable3_5 WHERE [ReportYear] = " & intYear & " ORDER BY Years DESC, Months DESC, Days DESC, TimeElapsed DESC"
610   Set rst2 = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)
620   Do While Not rst2.EOF

630       If row <> 2 Then
640           range.Tables(1).Rows.Add
650       End If
          
660       strPrefix = Nz(rst2("BandPrefix"))
670       strSuffix = Nz(rst2("BandSuffix"))
680       strSpecies = Nz(rst2("Species"))
690       strAgeReturn = Nz(rst2("AgeReturn"))
700       strSexReturn = Nz(rst2("SexReturn"))
710       strAgeBanding = Nz(rst2("AgeBanding"))
720       strSexBanding = Nz(rst2("SexBanding"))
730       datReturnDate = Nz(rst2("ReturnDate"))
740       datPriorCaptureDate = Nz(rst2("PriorCaptureDate"))
750       datBandingDate = Nz(rst2("BandingDate"))
760       lngTimeElapsed = Nz(rst2("TimeElapsed"))
770       intYearsElapsed = Nz(rst2("Years"))
780       intMonthsElapsed = Nz(rst2("Months"))
790       intDaysElapsed = Nz(rst2("Days"))

800       range.Tables(1).Cell(row, 1).range.Text = strPrefix & "-" & strSuffix
810       range.Tables(1).Cell(row, 2).range.Text = strSpecies
820       range.Tables(1).Cell(row, 3).range.Text = getAgeSex(strAgeReturn, strSexReturn)
830       range.Tables(1).Cell(row, 4).range.Text = getAgeSex(strAgeBanding, strSexBanding)
840       range.Tables(1).Cell(row, 5).range.Text = _
              ConvertDateToEnglishString(datBandingDate, 2)
850       range.Tables(1).Cell(row, 6).range.Text = _
              ConvertDateToEnglishString(datPriorCaptureDate, 2)
860       range.Tables(1).Cell(row, 7).range.Text = _
              ConvertDateToEnglishString(datReturnDate, 3)
870       If intYearsElapsed >= 0 And intMonthsElapsed >= 0 And intDaysElapsed >= 0 Then
880           If intYearsElapsed > 0 Then
890               range.Tables(1).Cell(row, 8).range.Text = _
                      intYearsElapsed & IIf(intYearsElapsed > 1, " years", " year")
900           End If
910           If intMonthsElapsed > 0 Then
920               range.Tables(1).Cell(row, 9).range.Text = _
                      intMonthsElapsed & IIf(intMonthsElapsed > 1, " months", " month")
930           End If
940           If intDaysElapsed > 0 Then
950               range.Tables(1).Cell(row, 10).range.Text = _
                      intDaysElapsed & IIf(intDaysElapsed > 1, " days", " day")
960           End If
970       End If
          
980       row = row + 1
990       rst2.MoveNext
1000  Loop
1010  rst2.Close
1020  Set rst2 = Nothing

1030  range.Tables(1).Rows(range.Tables(1).Rows.count).Cells.Borders(wdBorderBottom).LineStyle = wdLineStyleSingle

1040  Set range = doc.Characters.Last
1050  range.InsertParagraphAfter

      ' Create an Excel Worksheet

      Dim oSheet As Excel.Worksheet
1060  Set oSheet = InsertSheet(oBook, strSeason)
1070  oSheet.Name = strSeason & " Returns"

1080  With oSheet

          Dim colLocation As Integer
          Dim colProgram As Integer
          Dim colYear As Integer
          Dim colBand As Integer
          Dim colSpecies As Integer
          Dim colAgeReturn As Integer
          Dim colSexReturn As Integer
          Dim colAgeBanded As Integer
          Dim colSexBanded As Integer
          Dim colDateReturn As Integer
          Dim colDatePriorCapture As Integer
          Dim colDateBanded As Integer
          Dim colTimeElapsed As Integer
          Dim colYearsElapsed As Integer
          Dim colMonthsElapsed As Integer
          Dim colDaysElapsed As Integer
          Dim colReportYearBirdsReturnedAfterOneYear As Integer
          Dim colCountBirdsReturnedAfterOneYear As Integer
          Dim colEnd As Integer
          
          Dim col As Long
1090      col = 1
1100      colBand = col
1110      col = col + 1
1120      colSpecies = col
1130      col = col + 1
1140      colAgeReturn = col
1150      col = col + 1
1160      colSexReturn = col
1170      col = col + 1
1180      colAgeBanded = col
1190      col = col + 1
1200      colSexBanded = col
1210      col = col + 1
1220      colDateReturn = col
1230      col = col + 1
1240      colDatePriorCapture = col
1250      col = col + 1
1260      colDateBanded = col
1270      col = col + 1
1280      colTimeElapsed = col
1290      col = col + 1
1300      colYearsElapsed = col
1310      col = col + 1
1320      colMonthsElapsed = col
1330      col = col + 1
1340      colDaysElapsed = col
1350      col = col + 2
1360      colReportYearBirdsReturnedAfterOneYear = col
1370      col = col + 1
1380      colCountBirdsReturnedAfterOneYear = col
1390      colEnd = col

          Dim strAgeBanded As String
          Dim strSexBanded As String
          Dim datDateReturn As Date
          Dim datDatePriorCapture As Date
          Dim datDateBanded As Date
          Dim lngDaysElapsed As Long
       
          ' Fill in headers
          
1400      row = 1
1410      .Cells(1, colReportYearBirdsReturnedAfterOneYear) = "Returns >= 1 Year"
          
1420      row = row + 1
1430      .Cells(row, colBand) = "Band"
1440      .Cells(row, colSpecies) = "Species"
1450      .Cells(row, colAgeReturn) = "Age Return"
1460      .Cells(row, colSexReturn) = "Sex Return"
1470      .Cells(row, colAgeBanded) = "Age Banded"
1480      .Cells(row, colSexBanded) = "Age Banded"
1490      .Cells(row, colDateReturn) = "Date Return"
1500      .Cells(row, colDatePriorCapture) = "Date Prior Capture"
1510      .Cells(row, colDateBanded) = "Date Banded"
1520      .Cells(row, colTimeElapsed) = "Recapture Days"
1530      .Cells(row, colYearsElapsed) = "Years"
1540      .Cells(row, colMonthsElapsed) = "Months"
1550      .Cells(row, colDaysElapsed) = "Days"
1560      .Cells(row, colReportYearBirdsReturnedAfterOneYear) = "Report Year"
1570      .Cells(row, colCountBirdsReturnedAfterOneYear) = "Count"
          
      '   Dim rst As DAO.Recordset

1580      strSQL = "SELECT * FROM tblMBOAnnualProgramReportTable3_5 WHERE [ReportYear] = " & intYear & " ORDER BY TimeElapsed DESC"
1590      Set rst = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)
         
1600      row = row + 1
          
1610      Do While Not rst.EOF
          
1620          strSpecies = Nz(rst("Species"))
1630          strPrefix = Nz(rst("BandPrefix"))
1640          strSuffix = Nz(rst("BandSuffix"))
1650          strAgeReturn = Nz(rst("AgeReturn"))
1660          strSexReturn = Nz(rst("SexReturn"))
1670          strAgeBanded = Nz(rst("AgeBanding"))
1680          strSexBanded = Nz(rst("SexBanding"))
1690          datDateReturn = Nz(rst("ReturnDate"))
1700          datDatePriorCapture = Nz(rst("PriorCaptureDate"))
1710          datDateBanded = Nz(rst("BandingDate"))
1720          lngTimeElapsed = Nz(rst("TimeElapsed"))
1730          intYearsElapsed = Nz(rst("Years"))
1740          intMonthsElapsed = Nz(rst("Months"))
1750          intDaysElapsed = Nz(rst("Days"))
              
1760          .Cells(row, colBand) = strPrefix & "-" & strSuffix
1770          .Cells(row, colSpecies) = strSpecies
1780          .Cells(row, colAgeReturn) = strAgeReturn
1790          .Cells(row, colSexReturn) = strSexReturn
1800          .Cells(row, colAgeBanded) = strAgeBanded
1810          .Cells(row, colSexBanded) = strSexBanded
1820          .Cells(row, colDateReturn) = datDateReturn
1830          .Cells(row, colDatePriorCapture) = datDatePriorCapture
1840          .Cells(row, colDateBanded) = datDateBanded
1850          .Cells(row, colTimeElapsed) = lngTimeElapsed
1860          .Cells(row, colYearsElapsed) = intYearsElapsed
1870          .Cells(row, colMonthsElapsed) = intMonthsElapsed
1880          .Cells(row, colDaysElapsed) = intDaysElapsed
              
1890          row = row + 1
1900          rst.MoveNext
1910      Loop
1920      rst.Close
1930      Set rst = Nothing
          
          Dim rowEnd As Long
1940      rowEnd = row - 1
          
1950      .range(.columns(colAgeReturn), .columns(colSexBanded)).HorizontalAlignment = xlCenter
1960      .range(.columns(colTimeElapsed), .columns(colTimeElapsed)).HorizontalAlignment = xlCenter
1970      .range(.columns(colDateReturn), .columns(colDateBanded)).NumberFormat = "d mmm yyyy"
1980      .range(.Cells(1, 1), .Cells(1, colDaysElapsed)).HorizontalAlignment = xlCenter


          ' For the season, for each year, report the number of returns > 1 year
          
          ' qryMBOAnnualProgramReportTable3_5A
          ' ----------------------------------
          ' tblMBOAnnualProgramReportTable3_5A
          '
          ' GROUP BY ReportYear
          ' COUNT *
          ' WHERE Years > 0
          ' Report ReportYear, Count
          
1990      row = 3

2000      strSQL = "SELECT * FROM qryMBOAnnualProgramReportTable3_5A ORDER BY Reportyear DESC"
2010      Set rst = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)

2020      Do While Not rst.EOF
          
2030          .Cells(row, colReportYearBirdsReturnedAfterOneYear) = Nz(rst("ReportYear"))
2040          .Cells(row, colCountBirdsReturnedAfterOneYear) = Nz(rst("Count"))
2050          row = row + 1
          
          
2060          rst.MoveNext
2070      Loop
2080      rst.Close
2090      Set rst = Nothing
          
2100      .range(.columns(1), .columns(colEnd)).AutoFit

2110  End With

2120  Set oSheet = Nothing

2130  SysCmd acSysCmdClearStatus

      'DD Error Handler Start
Exit_label:
2140       Exit Sub
Err_label:
2150       Select Case Err.Number
           Case Else
2160      Call LogError("basMBOAnnualProgramReportTable3_5_Returns", "MBOAnnualProgramReportTable3_5")
2170       End Select
2180       Resume Exit_label
      'DD Error Handler End

End Sub



'---------------------------------------------------------------------------------------
' DateSerialDavid
'---------------------------------------------------------------------------------------

Private Function DateSerialDavid(ByVal Year As Integer, ByVal Month As Integer, ByVal Day As Integer) As Date

      ' Year is correct
      ' Month >= 1
      ' Day can be 1 to 31

      ' Adjust Month and Year

10       On Error GoTo Err_label
         
20       Debug.Print Year & " " & Month & " " & Day

30    Year = Year + Fix((Month - 1) / 12)
40    Month = ((Month - 1) Mod 12) + 1

      ' If the date does not exist, bump to the next day

50    Select Case Month
      Case 1, 3, 5, 7, 8, 10, 12
60        If Day > 31 Then
70            Day = 1
80            Month = Month + 1
90            If Month = 13 Then
100               Year = Year + 1
110               Month = 1
120           End If
130       End If
140   Case 2  ' February
150   If isLeapYear(Year) Then
160       If Day > 29 Then
170           Day = 1
180           Month = Month + 1
190           If Month = 13 Then
200               Year = Year + 1
210               Month = 1
220           End If
230       End If
240   Else
250        If Day > 28 Then
260           Day = 1
270           Month = Month + 1
280           If Month = 13 Then
290               Year = Year + 1
300               Month = 1
310           End If
320       End If
330   End If
340   Case 4, 6, 9, 11
350       If Day > 30 Then
360           Day = 1
370           Month = Month + 1
380           If Month = 13 Then
390               Year = Year + 1
400               Month = 1
410           End If
420       End If
430   End Select

440   DateSerialDavid = DateSerial(Year, Month, Day)

450   Debug.Print "DateSerialDavid " & DateSerialDavid

          'DD Error Handler Start
Exit_label:
460       Exit Function
Err_label:
470       Select Case Err.Number
          Case Else
480      Call LogError("basMBOAnnualProgramReportTable3_5_Returns", "DateSerialDavid")
490       End Select
500       Resume Exit_label
          ' DD Error Handler End

End Function




'---------------------------------------------------------------------------------------
' WordGenerateTableReturns
'---------------------------------------------------------------------------------------
' entry:  range = a collapsed range that is the insertion point for the table
' exit:   range = range that includes the table

Private Sub WordGenerateTableReturns( _
    ByRef doc As Word.Document, _
    ByRef range As Word.range, _
    ByVal strSeason As String, _
    ByVal intYear As Integer)

      Dim row As Integer
      Dim col As Integer

10    On Error GoTo Err_label

20    doc.Tables.Add range:=range, NumRows:=2, NumColumns:=10
          
30    range.Expand (wdTable)
40    With range.Tables(1)

50        .range.Style = "ddReturnsData"

60        .Rows.Alignment = wdAlignRowCenter
70        .Rows.WrapAroundText = False

80        .LeftPadding = doc.Application.InchesToPoints(0.02)
90        .RightPadding = doc.Application.InchesToPoints(0.02)
100       .TopPadding = doc.Application.InchesToPoints(0.02)
          
' 90        .Rows.HorizontalPosition = doc.Application.InchesToPoints(0.03)
          
110       .columns(1).Width = doc.Application.InchesToPoints(0.73)
120       .columns(2).Width = doc.Application.InchesToPoints(0.52)
130       .columns(3).Width = doc.Application.InchesToPoints(0.57)
140       .columns(4).Width = doc.Application.InchesToPoints(0.69)
150       .columns(5).Width = doc.Application.InchesToPoints(0.79)
160       .columns(6).Width = doc.Application.InchesToPoints(0.89)
170       .columns(7).Width = doc.Application.InchesToPoints(0.59)
180       .columns(8).Width = doc.Application.InchesToPoints(0.49)
190       .columns(9).Width = doc.Application.InchesToPoints(0.69)
200       .columns(10).Width = doc.Application.InchesToPoints(0.51)
          
210       .Cell(1, 1).range.Text = "Band number"
220       .Cell(1, 2).range.Text = "Species"
230       Select Case strSeason
          Case "Winter"
240           .Cell(1, 3).range.Text = "Age/sex at return"
250       Case Else
260           .Cell(1, 3).range.Text = "Age/sex in " & intYear
270       End Select
280       .Cell(1, 4).range.Text = "Age/sex at banding"
290       .Cell(1, 5).range.Text = "Banding date"
300       .Cell(1, 6).range.Text = "Previous capture"
310       Select Case strSeason
          Case "Winter"
320           .Cell(1, 7).range.Text = intYear - 1 & "-" & Right(intYear, 2) & " return"
330       Case Else
340           .Cell(1, 7).range.Text = intYear & " return"
350       End Select
360       .Cell(1, 8).range.Text = "Time elapsed"

          ' Format Header Row
          
370       Call FormatWordTableRowAsHeader(.Rows(1))
          
          ' Center vertically row 1
          
380       .Rows(1).Cells.VerticalAlignment = wdCellAlignVerticalCenter
          
          ' Merge row 1 : col 8+9+10

390       .Cell(1, 8).Merge .Cell(1, 10)

' Repeat heading row at the top of subsequent pages

400   .Rows(1).HeadingFormat = True
410   .Rows.WrapAroundText = False

420   End With

'DD Error Handler Start
Exit_label:
430        Exit Sub
Err_label:
440        Select Case Err.Number
     Case Else
450       Call LogError("basMBOAnnualProgramReportTable3_5_Returns", "WordGenerateTableReturns")
460        End Select
470        Resume Exit_label
'DD Error Handler End

End Sub
