Option Compare Database
Option Explicit

Private m_CurrentRecordPositionSheetNewBands As Long
Private m_CurrentRecordPositionSheetRecaps As Long
Private m_CurrentRecordPositionCaptures As Long
Private m_OrderByCaptures As String

Public Property Get CurrentRecordPositionSheetNewBands() As Long
10    If 1 <= m_CurrentRecordPositionSheetNewBands And m_CurrentRecordPositionSheetNewBands <= 100 Then
20        CurrentRecordPositionSheetNewBands = m_CurrentRecordPositionSheetNewBands
30    Else
40        CurrentRecordPositionSheetNewBands = 1
50    End If
End Property

Public Property Let CurrentRecordPositionSheetNewBands(ByVal CurrentRecordPositionSheetNewBands As Long)
10    If 1 <= CurrentRecordPositionSheetNewBands And CurrentRecordPositionSheetNewBands <= 100 Then
20        m_CurrentRecordPositionSheetNewBands = CurrentRecordPositionSheetNewBands
30    Else
40        m_CurrentRecordPositionSheetNewBands = 1
50    End If
End Property

Public Property Get CurrentRecordPositionSheetRecaps() As Long

10        CurrentRecordPositionSheetRecaps = m_CurrentRecordPositionSheetRecaps

End Property

Public Property Let CurrentRecordPositionSheetRecaps(ByVal lCurrentRecordPositionSheetRecaps As Long)

10        m_CurrentRecordPositionSheetRecaps = lCurrentRecordPositionSheetRecaps

End Property

Public Property Get CurrentRecordPositionCaptures() As Long

10        CurrentRecordPositionCaptures = m_CurrentRecordPositionCaptures

End Property

Public Property Let CurrentRecordPositionCaptures(ByVal lCurrentRecordPositionCaptures As Long)

10        m_CurrentRecordPositionCaptures = lCurrentRecordPositionCaptures

End Property

Public Property Get OrderByCaptures() As String

10        OrderByCaptures = m_OrderByCaptures

End Property

Public Property Let OrderByCaptures(ByVal sOrderByCaptures As String)

10        m_OrderByCaptures = sOrderByCaptures

End Property
