'---------------------------------------------------------------------------------------
' Module    : basUtilityBackEnd
' Author    : David Davey
'---------------------------------------------------------------------------------------

Option Compare Database
Option Explicit

Const strDefaultCMMNSiteCode As String = "MBO"


'---------------------------------------------------------------------------------------
' PutSettingEx
'---------------------------------------------------------------------------------------

Public Sub PutSettingEx(ByVal strName As String, ByVal strValue As String)
10       On Error GoTo Err_label

20    Select Case strName
      Case "MBODataEntryReplicationFolder", _
           "MBODataEntryReplicationFolderMaximumNumberOfFiles", _
           "USBFlashDriveBackupFolder", _
           "USBFlashDriveBackupFolderMaximumNumberOfDatabaseFiles", _
           "PathToBackupProgram"
30         If isDavidPC() Then
40            Call AddEntry_DAVID(strName, strValue)
50         Else
60            Call AddEntry(strName, strValue)
70         End If
80    Case Else
90          Call AddEntry(strName, strValue)
100   End Select


          'DD Error Handler Start
Exit_label:
110       Exit Sub
Err_label:
120       Select Case Err.Number
          Case Else
130            Call LogError("basUtilityBackEnd", "PutSettingEx")
140       End Select
150       Resume Exit_label
          ' DD Error Handler End

End Sub


'---------------------------------------------------------------------------------------
' GetSettingEx
'---------------------------------------------------------------------------------------

Public Function GetSettingEx(ByVal strName As String)
10       On Error GoTo Err_label

20    Select Case strName
      Case "MBODataEntryReplicationFolder", _
           "MBODataEntryReplicationFolderMaximumNumberOfFiles", _
           "USBFlashDriveBackupFolder", _
           "USBFlashDriveBackupFolderMaximumNumberOfDatabaseFiles", _
           "PathToBackupProgram"
30         If isDavidPC Then
40            GetSettingEx = LookupEntry_DAVID(strName)
50         Else
60            GetSettingEx = LookupEntry(strName)
70         End If
80    Case Else
90         GetSettingEx = LookupEntry(strName)
100   End Select

          'DD Error Handler Start
Exit_label:
110       Exit Function
Err_label:
120       Select Case Err.Number
          Case Else
130            Call LogError("basUtilityBackEnd", "GetSettingEx")
140       End Select
150       Resume Exit_label
          ' DD Error Handler End
End Function


'---------------------------------------------------------------------------------------
' AddEntry_DAVID
'---------------------------------------------------------------------------------------

Private Sub AddEntry_DAVID(ByVal strName As String, ByVal strValue As String)
      Dim strSQL As String
      Dim rst As DAO.Recordset

10       On Error GoTo Err_label

20    strSQL = "SELECT * FROM tblSettings_DAVID WHERE [Name] = '" & strName & "'"
30    Set rst = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)

40    If rst.EOF Then
50        rst.AddNew
60        rst("Name") = strName
70        rst("ValueEx") = strValue
80        rst.Update
90    Else
100       rst.Edit
110       rst("ValueEx") = strValue
120       rst.Update
130   End If
140   rst.Close
150   Set rst = Nothing

          'DD Error Handler Start
Exit_label:
160       Exit Sub
Err_label:
170       Select Case Err.Number
          Case Else
180            Call LogError("basUtilityBackEnd", "AddEntry_DAVID")
190       End Select
200       Resume Exit_label
          ' DD Error Handler End
End Sub


'---------------------------------------------------------------------------------------
' LookupEntry_DAVID
'---------------------------------------------------------------------------------------

Private Function LookupEntry_DAVID(ByVal strName As String)
10       On Error GoTo Err_label

20    LookupEntry_DAVID = Nz(DLookup("ValueEx", "tblSettings_DAVID", "Name = '" & strName & "'"))

    'DD Error Handler Start
Exit_label:
30        Exit Function
Err_label:
40        Select Case Err.Number
    Case Else
50       Call LogError("basUtilityBackEnd", "LookupEntry_DAVID")
60        End Select
70        Resume Exit_label
    ' DD Error Handler End
End Function


'---------------------------------------------------------------------------------------
' AddEntry
'
' Given Name change ValueEx in tblUtilityBackEnd
' Add a Name, Value pair to tblUtilityBackEnd if it does not already exist
'---------------------------------------------------------------------------------------
 
Private Sub AddEntry(ByVal strName As String, ByVal strValue As String)
      
10    On Error GoTo Err_label

      Dim strSQL As String
      Dim rst As DAO.Recordset

20    strSQL = "SELECT * FROM tblUtilityBackEnd WHERE [Name] = '" & strName & "'"
30    Set rst = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)

40    If rst.EOF Then
50        rst.AddNew
60        rst("Name") = strName
70        rst("ValueEx") = strValue
80        rst.Update
90    Else
100       rst.Edit
110       rst("ValueEx") = strValue
120       rst.Update
130   End If
140   rst.Close
150   Set rst = Nothing

      'DD Error Handler Start
Exit_label:
160        Exit Sub
Err_label:
170        Select Case Err.Number
           Case Else
180       Call LogError("basUtilityBackEnd", "AddEntry", "strSQL=" & strSQL)
190        End Select
200        Resume Exit_label
      'DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' LookupEntry
'---------------------------------------------------------------------------------------
 
Private Function LookupEntry(ByVal strName As String) As String
10    On Error GoTo Err_label

20    LookupEntry = Nz(DLookup("ValueEx", "tblUtilityBackEnd", "Name = '" & strName & "'"))
        
      'DD Error Handler Start
Exit_label:
30         Exit Function
Err_label:
40         Select Case Err.Number
           Case Else
50              Call LogError("basUtilityBackEnd", "LookupEntry")
60         End Select
70         Resume Exit_label
      'DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' AddEntry_Long
'
' Given Name change ValueLong in tblUtilityBackEnd
' Add a Name, ValueLong pair to tblUtilityBackEnd if it does not already exist
'---------------------------------------------------------------------------------------
 
Private Sub AddEntry_Long(ByVal strName As String, ByVal lngValue As Long)
      
10    On Error GoTo Err_label

Dim strSQL As String
Dim rst As DAO.Recordset

20    strSQL = "SELECT * FROM tblUtilityBackEnd WHERE [Name] = '" & strName & "'"
30    Set rst = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)

40    If rst.EOF Then
50        rst.AddNew
60        rst("Name") = strName
70        rst("ValueLong") = lngValue
80        rst.Update
90    Else
100       rst.Edit
110       rst("ValueLong") = lngValue
120       rst.Update
130   End If
140   rst.Close
150   Set rst = Nothing

      'DD Error Handler Start
Exit_label:
160        Exit Sub
Err_label:
170        Select Case Err.Number
           Case Else
180       Call LogError("basUtilityBackEnd", "AddEntry_Long", "strSQL=" & strSQL)
190        End Select
200        Resume Exit_label
      'DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' LookupEntry_Long
'---------------------------------------------------------------------------------------
 
Private Function LookupEntry_Long(ByVal strName As String) As Long
10    On Error GoTo Err_label

20    LookupEntry_Long = Nz(DLookup("ValueLong", "tblUtilityBackEnd", "Name = '" & strName & "'"))
        
      'DD Error Handler Start
Exit_label:
30         Exit Function
Err_label:
40         Select Case Err.Number
           Case Else
50              Call LogError("basUtilityBackEnd", "LookupEntry_Long")
60         End Select
70         Resume Exit_label
      'DD Error Handler End
End Function


'---------------------------------------------------------------------------------------
' AddEntry_Date
'
' Given Name change ValueDate in tblUtilityBackEnd
' Add a Name, ValueDate pair to tblUtilityBackEnd if it does not already exist
'---------------------------------------------------------------------------------------
 
Private Sub AddEntry_Date(ByVal strName As String, ByVal datValue As Date)
      
10    On Error GoTo Err_label

Dim strSQL As String
Dim rst As DAO.Recordset

20    strSQL = "SELECT * FROM tblUtilityBackEnd WHERE [Name] = '" & strName & "'"
30    Set rst = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)

40    If rst.EOF Then
50        rst.AddNew
60        rst("Name") = strName
70        rst("ValueDate") = datValue
80        rst.Update
90    Else
100       rst.Edit
110       rst("ValueDate") = datValue
120       rst.Update
130   End If
140   rst.Close
150   Set rst = Nothing

      'DD Error Handler Start
Exit_label:
160        Exit Sub
Err_label:
170        Select Case Err.Number
           Case Else
180       Call LogError("basUtilityBackEnd", "AddEntry_Date", "strSQL=" & strSQL)
190        End Select
200        Resume Exit_label
      'DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' LookupEntry_Date
'---------------------------------------------------------------------------------------
 
Private Function LookupEntry_Date(ByVal strName As String) As Date
10    On Error GoTo Err_label

20    LookupEntry_Date = Nz(DLookup("ValueDate", "tblUtilityBackEnd", "Name = '" & strName & "'"))
        
      'DD Error Handler Start
Exit_label:
30         Exit Function
Err_label:
40         Select Case Err.Number
           Case Else
50              Call LogError("basUtilityBackEnd", "LookupEntry_Date")
60         End Select
70         Resume Exit_label
      'DD Error Handler End
End Function


'---------------------------------------------------------------------------------------
' PutAuxMarkerBandColor
'---------------------------------------------------------------------------------------
 
Public Sub PutAuxMarkerBandColor(ByVal intColor As Integer)
10    On Error GoTo Err_label

20    Call AddEntry("AuxMarkerBandColor", IIf(intColor = 0, "", CStr(intColor)))

      'DD Error Handler Start
Exit_label:
30         Exit Sub
Err_label:
40         Select Case Err.Number
           Case Else
50              Call LogError("basUtilityBackEnd", "PutAuxMarkerBandColor")
60         End Select
70         Resume Exit_label
      'DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' GetAuxMarkerBandColor
'---------------------------------------------------------------------------------------
 
Public Function GetAuxMarkerBandColor() As Integer
10    On Error GoTo Err_label

Dim strColor As String
20    strColor = LookupEntry("AuxMarkerBandColor")
30    If strColor = "" Then
40        GetAuxMarkerBandColor = 0
50    Else
60        GetAuxMarkerBandColor = CInt(strColor)
70    End If


      'DD Error Handler Start
Exit_label:
80         Exit Function
Err_label:
90         Select Case Err.Number
           Case Else
100             Call LogError("basUtilityBackEnd", "GetAuxMarkerBandColor")
110        End Select
120        Resume Exit_label
      'DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' PutAuxMarkerCodeColor
'---------------------------------------------------------------------------------------
 
Public Sub PutAuxMarkerCodeColor(ByVal intColor As Integer)
10    On Error GoTo Err_label

20    Call AddEntry("AuxMarkerCodeColor", IIf(intColor = 0, "", CStr(intColor)))

      'DD Error Handler Start
Exit_label:
30         Exit Sub
Err_label:
40         Select Case Err.Number
           Case Else
50              Call LogError("basUtilityBackEnd", "PutAuxMarkerCodeColor")
60         End Select
70         Resume Exit_label
      'DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' GetAuxMarkerCodeColor
'---------------------------------------------------------------------------------------
 
Public Function GetAuxMarkerCodeColor() As Integer
10    On Error GoTo Err_label

Dim strColor As String
20    strColor = LookupEntry("AuxMarkerCodeColor")

30    If strColor = "" Then
40        GetAuxMarkerCodeColor = 0
50    Else
60        GetAuxMarkerCodeColor = CInt(strColor)
70    End If

      'DD Error Handler Start
Exit_label:
80         Exit Function
Err_label:
90         Select Case Err.Number
           Case Else
100             Call LogError("basUtilityBackEnd", "GetAuxMarkerCodeColor")
110        End Select
120        Resume Exit_label
      'DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' PutAuxMarkerCode
'---------------------------------------------------------------------------------------
 
Public Sub PutAuxMarkerCode(ByVal strAuxMarkerCode As String)
10    On Error GoTo Err_label

20    Call AddEntry("AuxMarkerCode", strAuxMarkerCode)

      'DD Error Handler Start
Exit_label:
30         Exit Sub
Err_label:
40         Select Case Err.Number
           Case Else
50              Call LogError("basUtilityBackEnd", "PutAuxMarkerCode")
60         End Select
70         Resume Exit_label
      'DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' GetAuxMarkerCode
'---------------------------------------------------------------------------------------
 
Public Function GetAuxMarkerCode() As String
10    On Error GoTo Err_label

20    GetAuxMarkerCode = LookupEntry("AuxMarkerCode")

'DD Error Handler Start
Exit_label:
30         Exit Function
Err_label:
40         Select Case Err.Number
     Case Else
50        Call LogError("basUtilityBackEnd", "GetAuxMarkerCode")
60         End Select
70         Resume Exit_label
'DD Error Handler End

End Function



'---------------------------------------------------------------------------------------
' PutIsAuxMarkerCoded
'---------------------------------------------------------------------------------------
 
Public Sub PutIsAuxMarkerCoded(ByVal strIsAuxMarkerCoded As String)

10    On Error GoTo Err_label

20    Call AddEntry("IsAuxMarkerCoded", strIsAuxMarkerCoded)

'DD Error Handler Start
Exit_label:
30         Exit Sub
Err_label:
40         Select Case Err.Number
     Case Else
50        Call LogError("basUtilityBackEnd", "PutIsAuxMarkerCoded")
60         End Select
70         Resume Exit_label
'DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' GetIsAuxMarkerCoded
'---------------------------------------------------------------------------------------
 
Public Function GetIsAuxMarkerCoded() As String

10    On Error GoTo Err_label

20    GetIsAuxMarkerCoded = LookupEntry("IsAuxMarkerCoded")

'DD Error Handler Start
Exit_label:
30         Exit Function
Err_label:
40         Select Case Err.Number
     Case Else
50        Call LogError("basUtilityBackEnd", "GetIsAuxMarkerCoded")
60         End Select
70         Resume Exit_label
'DD Error Handler End

End Function

'---------------------------------------------------------------------------------------
' PutAuxMarkerType
'---------------------------------------------------------------------------------------
 
Public Sub PutAuxMarkerType(ByVal strAuxMarkerType As String)

10    On Error GoTo Err_label

20    Call AddEntry("AuxMarkerType", strAuxMarkerType)

      'DD Error Handler Start
Exit_label:
30         Exit Sub
Err_label:
40         Select Case Err.Number
           Case Else
50        Call LogError("basUtilityBackEnd", "PutAuxMarkerType")
60         End Select
70         Resume Exit_label
      'DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' GetLegColor
'---------------------------------------------------------------------------------------
 
Public Function GetLegColor(ByVal strSide As String, ByVal intNumber As Integer) As Integer

10    On Error GoTo Err_label

20    Select Case strSide
      Case "Left"
30        Select Case intNumber
          Case 1:
40            GetLegColor = CInt(LookupEntry("LegColorLeft1"))
50        Case 2:
60            GetLegColor = CInt(LookupEntry("LegColorLeft2"))
70        Case 3:
80            GetLegColor = CInt(LookupEntry("LegColorLeft3"))
90        End Select
100   Case "Right"
110       Select Case intNumber
          Case 1:
120           GetLegColor = CInt(LookupEntry("LegColorRight1"))
130       Case 2:
140           GetLegColor = CInt(LookupEntry("LegColorRight2"))
150       Case 3:
160           GetLegColor = CInt(LookupEntry("LegColorRight3"))
170       End Select
180   End Select

      'DD Error Handler Start
Exit_label:
190        Exit Function
Err_label:
200        Select Case Err.Number
           Case Else
210             Call LogError("basUtilityBackEnd", "GetLegColor")
220        End Select
230        Resume Exit_label
      'DD Error Handler End

End Function

'---------------------------------------------------------------------------------------
' PutLegColor
'---------------------------------------------------------------------------------------
 
Public Sub PutLegColor(ByVal intLegColor As Integer, ByVal strSide As String, ByVal intNumber As Integer)

10    On Error GoTo Err_label

20    Select Case strSide
      Case "Left"
30        Select Case intNumber
          Case 1:
40            Call AddEntry("LegColorLeft1", CStr(intLegColor))
50        Case 2:
60            Call AddEntry("LegColorLeft2", CStr(intLegColor))
70        Case 3:
80            Call AddEntry("LegColorLeft3", CStr(intLegColor))
90        End Select
100   Case "Right"
110       Select Case intNumber
          Case 1:
120           Call AddEntry("LegColorRight1", CStr(intLegColor))
130       Case 2:
140           Call AddEntry("LegColorRight2", CStr(intLegColor))
150       Case 3:
160           Call AddEntry("LegColorRight3", CStr(intLegColor))
170       End Select
180   End Select

      'DD Error Handler Start
Exit_label:
190        Exit Sub
Err_label:
200        Select Case Err.Number
           Case Else
210             Call LogError("basUtilityBackEnd", "PutLegColor")
220        End Select
230        Resume Exit_label
      'DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' GetAuxMarkerType
'---------------------------------------------------------------------------------------
 
Public Function GetAuxMarkerType() As String
10    On Error GoTo Err_label

20    GetAuxMarkerType = LookupEntry("AuxMarkerType")

      'DD Error Handler Start
Exit_label:
30         Exit Function
Err_label:
40         Select Case Err.Number
           Case Else
50        Call LogError("basUtilityBackEnd", "GetAuxMarkerType")
60         End Select
70         Resume Exit_label
      'DD Error Handler End

End Function

'---------------------------------------------------------------------------------------
' PutCMMNSiteCode
'---------------------------------------------------------------------------------------
 
Public Sub PutCMMNSiteCode(ByVal strCMMNSiteCode As String)
10    On Error GoTo Err_label

20    Call AddEntry("CMMNSiteCode", strCMMNSiteCode)

      'DD Error Handler Start
Exit_label:
30         Exit Sub
Err_label:
40         Select Case Err.Number
           Case Else
50        Call LogError("basUtilityBackEnd", "PutCMMNSiteCode")
60         End Select
70         Resume Exit_label
      'DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' GetCMMNSiteCode
'---------------------------------------------------------------------------------------
 
Public Function GetCMMNSiteCode() As String
10    On Error GoTo Err_label

20    GetCMMNSiteCode = LookupEntry("CMMNSiteCode")

30    If GetCMMNSiteCode = "" Then
40        Call PutCMMNSiteCode(strDefaultCMMNSiteCode)
50        GetCMMNSiteCode = strDefaultCMMNSiteCode
60    End If

      'DD Error Handler Start
Exit_label:
70         Exit Function
Err_label:
80         Select Case Err.Number
           Case Else
90        Call LogError("basUtilityBackEnd", "GetCMMNSiteCode")
100        End Select
110        Resume Exit_label
      'DD Error Handler End

End Function

'---------------------------------------------------------------------------------------
' PutBandingSummarySpring
'---------------------------------------------------------------------------------------
 
'Public Sub PutBandingSummarySpring(ByVal fSpring As Boolean)
'10    On Error GoTo Err_label
'
'20    Call AddEntry("BandingSummarySpring", IIf(fSpring, "True", "False"))
'
'      'DD Error Handler Start
'Exit_label:
'30         Exit Sub
'Err_label:
'40         Select Case err.Number
'           Case Else
'50              Call LogError("basUtilityBackEnd", "PutBandingSummarySpring")
'60         End Select
'70         Resume Exit_label
'      'DD Error Handler End
'End Sub

'---------------------------------------------------------------------------------------
' GetBandingSummarySpring
'---------------------------------------------------------------------------------------
 
'Public Function GetBandingSummarySpring() As Boolean
'      Dim strSeason As String
'10    On Error GoTo Err_label
'
'20    strSeason = LookupEntry("BandingSummarySpring")
'30    If strSeason = "" Then
'40        Call PutBandingSummarySpring(True)
'50        strSeason = "True"
'60    End If
'70    GetBandingSummarySpring = IIf(strSeason = "True", True, False)
'
''DD Error Handler Start
'Exit_label:
'80         Exit Function
'Err_label:
'90         Select Case err.Number
'     Case Else
'100       Call LogError("basUtilityBackEnd", "GetBandingSummarySpring")
'110        End Select
'120        Resume Exit_label
''DD Error Handler End
'End Function

'---------------------------------------------------------------------------------------
' PutBandingSummarySummer
'---------------------------------------------------------------------------------------
 
'Public Sub PutBandingSummarySummer(ByVal fSummer As Boolean)
'10    On Error GoTo Err_label
'
'20    Call AddEntry("BandingSummarySummer", IIf(fSummer, "True", "False"))
'
'      'DD Error Handler Start
'Exit_label:
'30         Exit Sub
'Err_label:
'40         Select Case err.Number
'           Case Else
'50              Call LogError("basUtilityBackEnd", "PutBandingSummarySummer")
'60         End Select
'70         Resume Exit_label
'      'DD Error Handler End
'End Sub

'---------------------------------------------------------------------------------------
' GetBandingSummarySummer
'---------------------------------------------------------------------------------------
 
'Public Function GetBandingSummarySummer() As Boolean
'      Dim strSeason As String
'10    On Error GoTo Err_label
'
'20    strSeason = LookupEntry("BandingSummarySummer")
'30    If strSeason = "" Then
'40        Call PutBandingSummarySummer(True)
'50        strSeason = "True"
'60    End If
'70    GetBandingSummarySummer = IIf(strSeason = "True", True, False)
'
'      'DD Error Handler Start
'Exit_label:
'80         Exit Function
'Err_label:
'90         Select Case err.Number
'           Case Else
'100             Call LogError("basUtilityBackEnd", "GetBandingSummarySummer")
'110        End Select
'120        Resume Exit_label
'      'DD Error Handler End
'End Function

'---------------------------------------------------------------------------------------
' PutBandingSummaryFall
'---------------------------------------------------------------------------------------
 
'Public Sub PutBandingSummaryFall(ByVal fFall As Boolean)
'10    On Error GoTo Err_label
'
'20    Call AddEntry("BandingSummaryFall", IIf(fFall, "True", "False"))
'
'      'DD Error Handler Start
'Exit_label:
'30         Exit Sub
'Err_label:
'40         Select Case err.Number
'           Case Else
'50              Call LogError("basUtilityBackEnd", "PutBandingSummaryFall")
'60         End Select
'70         Resume Exit_label
'      'DD Error Handler End
'End Sub

'---------------------------------------------------------------------------------------
' GetBandingSummaryFall
'---------------------------------------------------------------------------------------
 
'Public Function GetBandingSummaryFall() As Boolean
'      Dim strSeason As String
'10    On Error GoTo Err_label
'
'20    strSeason = LookupEntry("BandingSummaryFall")
'30    If strSeason = "" Then
'40        Call PutBandingSummaryFall(True)
'50        strSeason = "True"
'60    End If
'70    GetBandingSummaryFall = IIf(strSeason = "True", True, False)
'
'      'DD Error Handler Start
'Exit_label:
'80         Exit Function
'Err_label:
'90         Select Case err.Number
'           Case Else
'100             Call LogError("basUtilityBackEnd", "GetBandingSummaryFall")
'110        End Select
'120        Resume Exit_label
'      'DD Error Handler End
'End Function

'---------------------------------------------------------------------------------------
' PutBandingSummaryWinter
'---------------------------------------------------------------------------------------
 
'Public Sub PutBandingSummaryWinter(ByVal fWinter As Boolean)
'10    On Error GoTo Err_label
'
'20    Call AddEntry("BandingSummaryWinter", IIf(fWinter, "True", "False"))
'
'      'DD Error Handler Start
'Exit_label:
'30         Exit Sub
'Err_label:
'40         Select Case err.Number
'           Case Else
'50              Call LogError("basUtilityBackEnd", "PutBandingSummaryWinter")
'60         End Select
'70         Resume Exit_label
'      'DD Error Handler End
'End Sub

'---------------------------------------------------------------------------------------
' GetBandingSummaryWinter
'---------------------------------------------------------------------------------------
 
'Public Function GetBandingSummaryWinter() As Boolean
'      Dim strSeason As String
'10    On Error GoTo Err_label
'
'20    strSeason = LookupEntry("BandingSummaryWinter")
'30    If strSeason = "" Then
'40        Call PutBandingSummaryWinter(True)
'50        strSeason = "True"
'60    End If
'70    GetBandingSummaryWinter = IIf(strSeason = "True", True, False)
'
'      'DD Error Handler Start
'Exit_label:
'80         Exit Function
'Err_label:
'90         Select Case err.Number
'           Case Else
'100             Call LogError("basUtilityBackEnd", "GetBandingSummaryWinter")
'110        End Select
'120        Resume Exit_label
'      'DD Error Handler End
'End Function

'---------------------------------------------------------------------------------------
' PutBandingSummaryFirstYear
'---------------------------------------------------------------------------------------
 
Public Sub PutBandingSummaryFirstYear(ByVal intFirstYear As Integer)
10    On Error GoTo Err_label

20    Call AddEntry("BandingSummaryFirstYear", CStr(intFirstYear))

      'DD Error Handler Start
Exit_label:
30         Exit Sub
Err_label:
40         Select Case Err.Number
           Case Else
50              Call LogError("basUtilityBackEnd", "PutBandingSummaryFirstYear")
60         End Select
70         Resume Exit_label
      'DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' GetBandingSummaryFirstYear
'---------------------------------------------------------------------------------------
 
Public Function GetBandingSummaryFirstYear() As Integer
      Dim strFirstYear As String
10    On Error GoTo Err_label

20    strFirstYear = LookupEntry("BandingSummaryFirstYear")
30    If strFirstYear = "" Then
40        Call PutBandingSummaryFirstYear(2004)
50        strFirstYear = "2004"
60    End If
70    GetBandingSummaryFirstYear = CInt(strFirstYear)

      'DD Error Handler Start
Exit_label:
80         Exit Function
Err_label:
90         Select Case Err.Number
           Case Else
100             Call LogError("basUtilityBackEnd", "GetBandingSummaryFirstYear")
110        End Select
120        Resume Exit_label
      'DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' PutBandingSummaryLastYear
'---------------------------------------------------------------------------------------
 
Public Sub PutBandingSummaryLastYear(ByVal intLastYear As Integer)
10    On Error GoTo Err_label

20    Call AddEntry("BandingSummaryLastYear", CStr(intLastYear))

      'DD Error Handler Start
Exit_label:
30         Exit Sub
Err_label:
40         Select Case Err.Number
           Case Else
50              Call LogError("basUtilityBackEnd", "PutBandingSummaryLastYear")
60         End Select
70         Resume Exit_label
      'DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' GetBandingSummaryLastYear
'---------------------------------------------------------------------------------------
 
Public Function GetBandingSummaryLastYear() As Integer
10    On Error GoTo Err_label

      Dim strLastYear As String
20    strLastYear = LookupEntry("BandingSummaryLastYear")
30    If strLastYear = "" Then
40        Call PutBandingSummaryLastYear(2004)
50        strLastYear = "2004"
60    End If
70    GetBandingSummaryLastYear = CInt(strLastYear)

      'DD Error Handler Start
Exit_label:
80         Exit Function
Err_label:
90         Select Case Err.Number
           Case Else
100             Call LogError("basUtilityBackEnd", "GetBandingSummaryLastYear")
110        End Select
120        Resume Exit_label
      'DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' PutBandingSummaryFirstSeason
'---------------------------------------------------------------------------------------
 
Public Sub PutBandingSummaryFirstSeason(ByVal strFirstSeason As String)
10    On Error GoTo Err_label

20    Call AddEntry("BandingSummaryFirstSeason", strFirstSeason)

      'DD Error Handler Start
Exit_label:
30         Exit Sub
Err_label:
40         Select Case Err.Number
           Case Else
50              Call LogError("basUtilityBackEnd", "PutBandingSummaryFirstSeason")
60         End Select
70         Resume Exit_label
      'DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' GetBandingSummaryFirstSeason
'---------------------------------------------------------------------------------------
 
Public Function GetBandingSummaryFirstSeason() As String
      Dim strFirstSeason As String
10    On Error GoTo Err_label

20    strFirstSeason = LookupEntry("BandingSummaryFirstSeason")
30    If strFirstSeason = "" Then
40        Call PutBandingSummaryFirstSeason("Spring")
50        strFirstSeason = "Spring"
60    End If
70    GetBandingSummaryFirstSeason = strFirstSeason

      'DD Error Handler Start
Exit_label:
80         Exit Function
Err_label:
90         Select Case Err.Number
           Case Else
100             Call LogError("basUtilityBackEnd", "GetBandingSummaryFirstSeason")
110        End Select
120        Resume Exit_label
      'DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' PutBandingSummaryLastSeason
'---------------------------------------------------------------------------------------
 
Public Sub PutBandingSummaryLastSeason(ByVal strLastSeason As String)
10    On Error GoTo Err_label

20    Call AddEntry("BandingSummaryLastSeason", strLastSeason)

      'DD Error Handler Start
Exit_label:
30         Exit Sub
Err_label:
40         Select Case Err.Number
           Case Else
50              Call LogError("basUtilityBackEnd", "PutBandingSummaryLastSeason")
60         End Select
70         Resume Exit_label
      'DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' GetBandingSummaryLastSeason
'---------------------------------------------------------------------------------------
 
Public Function GetBandingSummaryLastSeason() As String
10    On Error GoTo Err_label

      Dim strLastSeason As String
20    strLastSeason = LookupEntry("BandingSummaryLastSeason")
30    If strLastSeason = "" Then
40        Call PutBandingSummaryLastSeason("Winter")
50        strLastSeason = "Winter"
60    End If
70    GetBandingSummaryLastSeason = strLastSeason

      'DD Error Handler Start
Exit_label:
80         Exit Function
Err_label:
90         Select Case Err.Number
           Case Else
100             Call LogError("basUtilityBackEnd", "GetBandingSummaryLastSeason")
110        End Select
120        Resume Exit_label
      'DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' PutBandingSummaryFolder
'---------------------------------------------------------------------------------------
 
Public Sub PutBandingSummaryFolder(ByVal strFolder As String)
10    On Error GoTo Err_label

20    Call AddEntry("BandingSummaryFolder", strFolder)

      'DD Error Handler Start
Exit_label:
30         Exit Sub
Err_label:
40         Select Case Err.Number
           Case Else
50              Call LogError("basUtilityBackEnd", "PutBandingSummaryFolder")
60         End Select
70         Resume Exit_label
      'DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' GetBandingSummaryFolder
'---------------------------------------------------------------------------------------
 
Public Function GetBandingSummaryFolder() As String
10    On Error GoTo Err_label

      Dim strFolder As String
20    strFolder = LookupEntry("BandingSummaryFolder")
30    If strFolder = "" Then
40        strFolder = Rep_Documents()
50        Call PutBandingSummaryFolder(strFolder)
60    End If
70    GetBandingSummaryFolder = strFolder

      'DD Error Handler Start
Exit_label:
80         Exit Function
Err_label:
90         Select Case Err.Number
           Case Else
100             Call LogError("basUtilityBackEnd", "GetBandingSummaryFolder")
110        End Select
120        Resume Exit_label
      'DD Error Handler End
End Function



'---------------------------------------------------------------------------------------
' PutCaptureShortYear
'---------------------------------------------------------------------------------------
 
Public Sub PutCaptureShortYear(ByVal strShortYear As String)
10    On Error GoTo Err_label

20    Call AddEntry("CaptureShortYear", strShortYear)

      'DD Error Handler Start
Exit_label:
30         Exit Sub
Err_label:
40         Select Case Err.Number
           Case Else
50              Call LogError("basUtilityBackEnd", "PutCaptureShortYear")
60         End Select
70         Resume Exit_label
      'DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' GetCaptureShortYear
'---------------------------------------------------------------------------------------
 
Public Function GetCaptureShortYear() As String
10    On Error GoTo Err_label

      Dim strCaptureShortYear As String

20    strCaptureShortYear = LookupEntry("CaptureShortYear")
30    GetCaptureShortYear = strCaptureShortYear

      'DD Error Handler Start
Exit_label:
40         Exit Function
Err_label:
50         Select Case Err.Number
           Case Else
60              Call LogError("basUtilityBackEnd", "GetCaptureShortYear")
70         End Select
80         Resume Exit_label
      'DD Error Handler End
End Function



'---------------------------------------------------------------------------------------
' PutCaptureProgram
'---------------------------------------------------------------------------------------
 
Public Sub PutCaptureProgram(ByVal strProgram As String)
10    On Error GoTo Err_label

20    Call AddEntry("CaptureProgram", strProgram)

      'DD Error Handler Start
Exit_label:
30         Exit Sub
Err_label:
40         Select Case Err.Number
           Case Else
50              Call LogError("basUtilityBackEnd", "PutCaptureProgram")
60         End Select
70         Resume Exit_label
      'DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' GetCaptureProgram
'---------------------------------------------------------------------------------------
 
Public Function GetCaptureProgram() As String
10    On Error GoTo Err_label

      Dim strCaptureProgram As String

20    strCaptureProgram = LookupEntry("CaptureProgram")
30    GetCaptureProgram = strCaptureProgram

      'DD Error Handler Start
Exit_label:
40         Exit Function
Err_label:
50         Select Case Err.Number
           Case Else
60              Call LogError("basUtilityBackEnd", "GetCaptureProgram")
70         End Select
80         Resume Exit_label
      'DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' PutCaptureLocation
'---------------------------------------------------------------------------------------
 
Public Sub PutCaptureLocation(ByVal strLocation As String)
10    On Error GoTo Err_label

20    Call AddEntry("CaptureLocation", strLocation)

      'DD Error Handler Start
Exit_label:
30         Exit Sub
Err_label:
40         Select Case Err.Number
           Case Else
50              Call LogError("basUtilityBackEnd", "PutCaptureLocation")
60         End Select
70         Resume Exit_label
      'DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' GetCaptureLocation
'---------------------------------------------------------------------------------------
 
Public Function GetCaptureLocation() As String
10    On Error GoTo Err_label

      Dim strCaptureLocation As String

20    strCaptureLocation = LookupEntry("CaptureLocation")
30    GetCaptureLocation = strCaptureLocation

      'DD Error Handler Start
Exit_label:
40         Exit Function
Err_label:
50         Select Case Err.Number
           Case Else
60              Call LogError("basUtilityBackEnd", "GetCaptureLocation")
70         End Select
80         Resume Exit_label
      'DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' PutSheetNewBandsImportFolder
'---------------------------------------------------------------------------------------
 
Public Sub PutSheetNewBandsImportFolder(ByVal strFolder As String)
10    On Error GoTo Err_label

20    Call AddEntry("SheetNewBandsImportFolder", strFolder)

      'DD Error Handler Start
Exit_label:
30         Exit Sub
Err_label:
40         Select Case Err.Number
           Case Else
50              Call LogError("basUtilityBackEnd", "PutSheetNewBandsImportFolder")
60         End Select
70         Resume Exit_label
      'DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' GetSheetNewBandsImportFolder
'---------------------------------------------------------------------------------------
 
Public Function GetSheetNewBandsImportFolder() As String
10    On Error GoTo Err_label

      Dim strFolder As String
20    strFolder = LookupEntry("SheetNewBandsImportFolder")
30    If strFolder = "" Then
40        strFolder = Rep_Documents()
50        Call PutSheetNewBandsImportFolder(strFolder)
60    End If
70    GetSheetNewBandsImportFolder = strFolder

      'DD Error Handler Start
Exit_label:
80         Exit Function
Err_label:
90         Select Case Err.Number
           Case Else
100             Call LogError("basUtilityBackEnd", "GetSheetNewBandsImportFolder")
110        End Select
120        Resume Exit_label
      'DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' PutDETAnnualReportsYear
'---------------------------------------------------------------------------------------
 
Public Sub PutDETAnnualReportsYear(ByVal intYear As Integer)
10    On Error GoTo Err_label

20    Call AddEntry("DETAnnualReportsYear", CStr(intYear))

      'DD Error Handler Start
Exit_label:
30         Exit Sub
Err_label:
40         Select Case Err.Number
           Case Else
50              Call LogError("basUtilityBackEnd", "PutDETAnnualReportsYear")
60         End Select
70         Resume Exit_label
      'DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' GetDETAnnualReportsYear
'---------------------------------------------------------------------------------------
 
Public Function GetDETAnnualReportsYear() As Integer
10    On Error GoTo Err_label

      Dim intDETAnnualReportsYear As Integer
      Dim strDETAnnualReportsYear As String

20    strDETAnnualReportsYear = LookupEntry("DETAnnualReportsYear")
30    If strDETAnnualReportsYear = "" Then
40        intDETAnnualReportsYear = Year(Now())
50        Call AddEntry("DETAnnualReportsYear", CStr(intDETAnnualReportsYear))
60    Else
70        intDETAnnualReportsYear = CInt(strDETAnnualReportsYear)
80    End If
90    GetDETAnnualReportsYear = intDETAnnualReportsYear

      'DD Error Handler Start
Exit_label:
100        Exit Function
Err_label:
110        Select Case Err.Number
           Case Else
120             Call LogError("basUtilityBackEnd", "GetDETAnnualReportsYear")
130        End Select
140        Resume Exit_label
      'DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' PutDETAnnualReportsLocation
'---------------------------------------------------------------------------------------
 
Public Sub PutDETAnnualReportsLocation(ByVal strLocation As String)
10    On Error GoTo Err_label

20    Call AddEntry("DETAnnualReportsLocation", strLocation)

      'DD Error Handler Start
Exit_label:
30         Exit Sub
Err_label:
40         Select Case Err.Number
           Case Else
50              Call LogError("basUtilityBackEnd", "PutDETAnnualReportsLocation")
60         End Select
70         Resume Exit_label
      'DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' GetDETAnnualReportsLocation
'---------------------------------------------------------------------------------------
 
Public Function GetDETAnnualReportsLocation() As String
10    On Error GoTo Err_label

      Dim strDETAnnualReportsLocation As String

20    strDETAnnualReportsLocation = LookupEntry("DETAnnualReportsLocation")
30    If strDETAnnualReportsLocation = "" Then
40        strDETAnnualReportsLocation = "MBO"
50        Call AddEntry("DETAnnualReportsLocation", "MBO")
60    End If
70    GetDETAnnualReportsLocation = strDETAnnualReportsLocation

      'DD Error Handler Start
Exit_label:
80         Exit Function
Err_label:
90         Select Case Err.Number
           Case Else
100             Call LogError("basUtilityBackEnd", "GetDETAnnualReportsLocation")
110        End Select
120        Resume Exit_label
      'DD Error Handler End
End Function
 
'---------------------------------------------------------------------------------------
' PutDETMonitoringProgramReportsProgram
'---------------------------------------------------------------------------------------
 
Public Sub PutDETMonitoringProgramReportsProgram(ByVal strProgram As String)
10    On Error GoTo Err_label

20    If DCount("*", "tblPrograms", "[Program] = '" & strProgram & "'") = 0 Then
30        strProgram = "" = ""
40    End If

50    Call AddEntry("DETMonitoringProgramReportsProgram", strProgram)

'DD Error Handler Start
Exit_label:
60         Exit Sub
Err_label:
70         Select Case Err.Number
     Case Else
80        Call LogError("basUtilityBackEnd", "PutDETMonitoringProgramReportsProgram")
90         End Select
100        Resume Exit_label
'DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' GetDETMonitoringProgramReportsProgram
'---------------------------------------------------------------------------------------
 
Public Function GetDETMonitoringProgramReportsProgram() As String
10    On Error GoTo Err_label

      Dim strProgram As String

20    strProgram = LookupEntry("DETMonitoringProgramReportsProgram")
30    If DCount("*", "tblPrograms", "[Program] = '" & strProgram & "'") = 0 Then
40        strProgram = ""
50    End If

60    GetDETMonitoringProgramReportsProgram = strProgram

      'DD Error Handler Start
Exit_label:
70         Exit Function
Err_label:
80         Select Case Err.Number
           Case Else
90              Call LogError("basUtilityBackEnd", "GetDETMonitoringProgramReportsProgram")
100        End Select
110        Resume Exit_label
      'DD Error Handler End

End Function

'---------------------------------------------------------------------------------------
' PutDETMonitoringProgramReportsLocation
'---------------------------------------------------------------------------------------
 
Public Sub PutDETMonitoringProgramReportsLocation(ByVal strLocation As String)
10    On Error GoTo Err_label

20    If DCount("*", "tblLocations", "[LocationID] = '" & strLocation & "'") = 0 Then
30        strLocation = "" = ""
40    End If

50    Call AddEntry("DETMonitoringProgramReportsLocation", strLocation)

'DD Error Handler Start
Exit_label:
60         Exit Sub
Err_label:
70         Select Case Err.Number
     Case Else
80        Call LogError("basUtilityBackEnd", "PutDETMonitoringProgramReportsLocation")
90         End Select
100        Resume Exit_label
'DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' GetDETMonitoringProgramReportsLocation
'---------------------------------------------------------------------------------------
 
Public Function GetDETMonitoringProgramReportsLocation() As String
10    On Error GoTo Err_label

      Dim strLocation As String

20    strLocation = LookupEntry("DETMonitoringProgramReportsLocation")
30    If DCount("*", "tblLocations", "[LocationID] = '" & strLocation & "'") = 0 Then
40        strLocation = ""
50    End If

60    GetDETMonitoringProgramReportsLocation = strLocation

      'DD Error Handler Start
Exit_label:
70         Exit Function
Err_label:
80         Select Case Err.Number
           Case Else
90              Call LogError("basUtilityBackEnd", "GetDETMonitoringLocationReportsProgram")
100        End Select
110        Resume Exit_label
      'DD Error Handler End

End Function

'---------------------------------------------------------------------------------------
' PutExportFolder
'---------------------------------------------------------------------------------------
 
Public Sub PutExportFolder(ByVal strFolder As String)
10    On Error GoTo Err_label

20    Call AddEntry("ExportFolder", strFolder)

      'DD Error Handler Start
Exit_label:
30         Exit Sub
Err_label:
40         Select Case Err.Number
           Case Else
50              Call LogError("basUtilityBackEnd", "PutExportFolder")
60         End Select
70         Resume Exit_label
      'DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' GetExportFolder
'---------------------------------------------------------------------------------------
 
Public Function GetExportFolder() As String
10    On Error GoTo Err_label

      Dim strFolder As String
20    strFolder = LookupEntry("ExportFolder")
30    If strFolder = "" Then
40        strFolder = Rep_Documents()
50        Call PutExportFolder(strFolder)
60    End If
70    GetExportFolder = strFolder

      'DD Error Handler Start
Exit_label:
80         Exit Function
Err_label:
90         Select Case Err.Number
           Case Else
100             Call LogError("basUtilityBackEnd", "GetExportFolder")
110        End Select
120        Resume Exit_label
      'DD Error Handler End
End Function


'---------------------------------------------------------------------------------------
' PutDET10YearReportsYearLast
'---------------------------------------------------------------------------------------
 
Public Sub PutDET10YearReportsYearLast(ByVal intYear As Integer)
10    On Error GoTo Err_label

20    Call AddEntry("DET10YearReportsYearLast", CStr(intYear))

      'DD Error Handler Start
Exit_label:
30         Exit Sub
Err_label:
40         Select Case Err.Number
           Case Else
50              Call LogError("basUtilityBackEnd", "PutDET10YearReportsYearLast")
60         End Select
70         Resume Exit_label
      'DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' GetDET10YearReportsYearLast
'---------------------------------------------------------------------------------------
 
Public Function GetDET10YearReportsYearLast() As Integer
10    On Error GoTo Err_label

      Dim intDET10YearReportsYear As Integer
      Dim strDET10YearReportsYear As String

20    strDET10YearReportsYear = LookupEntry("DET10YearReportsYearLast")
30    If strDET10YearReportsYear = "" Then
40        intDET10YearReportsYear = Year(Now())
50        Call AddEntry("DET10YearReportsYearLast", CStr(intDET10YearReportsYear))
60    Else
70        intDET10YearReportsYear = CInt(strDET10YearReportsYear)
80    End If
90    GetDET10YearReportsYearLast = intDET10YearReportsYear

      'DD Error Handler Start
Exit_label:
100        Exit Function
Err_label:
110        Select Case Err.Number
           Case Else
120             Call LogError("basUtilityBackEnd", "GetDET10YearReportsYearLast")
130        End Select
140        Resume Exit_label
      'DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' PutDET10YearReportsYearFirst
'---------------------------------------------------------------------------------------
 
Public Sub PutDET10YearReportsYearFirst(ByVal intYear As Integer)
10    On Error GoTo Err_label

20    Call AddEntry("DET10YearReportsYearFirst", CStr(intYear))

      'DD Error Handler Start
Exit_label:
30         Exit Sub
Err_label:
40         Select Case Err.Number
           Case Else
50              Call LogError("basUtilityBackEnd", "PutDET10YearReportsYearFirst")
60         End Select
70         Resume Exit_label
      'DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' GetDET10YearReportsYearFirst
'---------------------------------------------------------------------------------------
 
Public Function GetDET10YearReportsYearFirst() As Integer
10    On Error GoTo Err_label

      Dim intDET10YearReportsYear As Integer
      Dim strDET10YearReportsYear As String

20    strDET10YearReportsYear = LookupEntry("DET10YearReportsYearFirst")
30    If strDET10YearReportsYear = "" Then
40        intDET10YearReportsYear = Year(Now())
50        Call AddEntry("DET10YearReportsYearFirst", CStr(intDET10YearReportsYear))
60    Else
70        intDET10YearReportsYear = CInt(strDET10YearReportsYear)
80    End If
90    GetDET10YearReportsYearFirst = intDET10YearReportsYear

      'DD Error Handler Start
Exit_label:
100        Exit Function
Err_label:
110        Select Case Err.Number
           Case Else
120             Call LogError("basUtilityBackEnd", "GetDET10YearReportsYearFirst")
130        End Select
140        Resume Exit_label
      'DD Error Handler End
End Function


'---------------------------------------------------------------------------------------
' PutDET10YearReportsLocation
'---------------------------------------------------------------------------------------
 
Public Sub PutDET10YearReportsLocation(ByVal strLocation As String)
10    On Error GoTo Err_label

20    Call AddEntry("DET10YearReportsLocation", strLocation)

      'DD Error Handler Start
Exit_label:
30         Exit Sub
Err_label:
40         Select Case Err.Number
           Case Else
50              Call LogError("basUtilityBackEnd", "PutDET10YearReportsLocation")
60         End Select
70         Resume Exit_label
      'DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' GetDET10YearReportsLocation
'---------------------------------------------------------------------------------------
 
Public Function GetDET10YearReportsLocation() As String
10    On Error GoTo Err_label

      Dim strDET10YearReportsLocation As String

20    strDET10YearReportsLocation = LookupEntry("DET10YearReportsLocation")
30    If strDET10YearReportsLocation = "" Then
40        strDET10YearReportsLocation = "MBO"
50        Call AddEntry("DET10YearReportsLocation", "MBO")
60    End If
70    GetDET10YearReportsLocation = strDET10YearReportsLocation

      'DD Error Handler Start
Exit_label:
80         Exit Function
Err_label:
90         Select Case Err.Number
           Case Else
100             Call LogError("basUtilityBackEnd", "GetDET10YearReportsLocation")
110        End Select
120        Resume Exit_label
      'DD Error Handler End
End Function
 
'---------------------------------------------------------------------------------------
' PutDebug
'
' "True", "False"
'---------------------------------------------------------------------------------------
 
Public Sub PutDebug(ByVal strDebug As String)
10    On Error GoTo Err_label

20    Call AddEntry("Debug", strDebug)

      'DD Error Handler End

'DD Error Handler Start
Exit_label:
30         Exit Sub
Err_label:
40         Select Case Err.Number
     Case Else
50        Call LogError("basUtilityBackEnd", "PutDebug")
60         End Select
70         Resume Exit_label
'DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' GetDebug
'---------------------------------------------------------------------------------------
 
Public Function GetDebug() As String

10    On Error GoTo Err_label

      Dim strDebug As String

20    strDebug = LookupEntry("Debug")
30    If strDebug = "" Then
40        strDebug = "False"
50        Call AddEntry("Debug", "False")
60    End If
70    GetDebug = strDebug

'DD Error Handler Start
Exit_label:
80         Exit Function
Err_label:
90         Select Case Err.Number
     Case Else
100       Call LogError("basUtilityBackEnd", "GetDebug")
110        End Select
120        Resume Exit_label
'DD Error Handler End
End Function



'---------------------------------------------------------------------------------------
' PutDETCombinedWeeklyReportsProgram
'---------------------------------------------------------------------------------------
 
Public Sub PutDETCombinedWeeklyReportsProgram(ByVal strProgram As String)
10    On Error GoTo Err_label

20    If DCount("*", "tblPrograms", "[Program] = '" & strProgram & "'") = 0 Then
30        strProgram = "" = ""
40    End If

50    Call AddEntry("DETCombinedWeeklyReportsProgram", strProgram)

'DD Error Handler Start
Exit_label:
60         Exit Sub
Err_label:
70         Select Case Err.Number
     Case Else
80        Call LogError("basUtilityBackEnd", "PutDETCombinedWeeklyReportsProgram")
90         End Select
100        Resume Exit_label
'DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' GetDETCombinedWeeklyReportsProgram
'---------------------------------------------------------------------------------------
 
Public Function GetDETCombinedWeeklyReportsProgram() As String
10    On Error GoTo Err_label

      Dim strProgram As String

20    strProgram = LookupEntry("DETCombinedWeeklyReportsProgram")
30    If DCount("*", "tblPrograms", "[Program] = '" & strProgram & "'") = 0 Then
40        strProgram = ""
50    End If

60    GetDETCombinedWeeklyReportsProgram = strProgram

      'DD Error Handler Start
Exit_label:
70         Exit Function
Err_label:
80         Select Case Err.Number
           Case Else
90              Call LogError("basUtilityBackEnd", "GetDETCombinedWeeklyReportsProgram")
100        End Select
110        Resume Exit_label
      'DD Error Handler End

End Function

'---------------------------------------------------------------------------------------
' PutDETCombinedWeeklyReportsLocation
'---------------------------------------------------------------------------------------
 
Public Sub PutDETCombinedWeeklyReportsLocation(ByVal strLocation As String)
10    On Error GoTo Err_label

20    If DCount("*", "tblLocations", "[LocationID] = '" & strLocation & "'") = 0 Then
30        strLocation = "" = ""
40    End If

50    Call AddEntry("DETCombinedWeeklyReportsLocation", strLocation)

'DD Error Handler Start
Exit_label:
60         Exit Sub
Err_label:
70         Select Case Err.Number
     Case Else
80        Call LogError("basUtilityBackEnd", "PutDETCombinedWeeklyReportsLocation")
90         End Select
100        Resume Exit_label
'DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' GetDETCombinedWeeklyReportsLocation
'---------------------------------------------------------------------------------------
 
Public Function GetDETCombinedWeeklyReportsLocation() As String
10    On Error GoTo Err_label

      Dim strLocation As String

20    strLocation = LookupEntry("DETCombinedWeeklyReportsLocation")
30    If DCount("*", "tblLocations", "[LocationID] = '" & strLocation & "'") = 0 Then
40        strLocation = ""
50    End If

60    GetDETCombinedWeeklyReportsLocation = strLocation

      'DD Error Handler Start
Exit_label:
70         Exit Function
Err_label:
80         Select Case Err.Number
           Case Else
90              Call LogError("basUtilityBackEnd", "GetDETCombinedWeeklyReportsLocation")
100        End Select
110        Resume Exit_label
      'DD Error Handler End

End Function

'---------------------------------------------------------------------------------------
' PutDETCombinedWeeklyReportsPeriod
'---------------------------------------------------------------------------------------
 
Public Sub PutDETCombinedWeeklyReportsPeriod(ByVal intPeriod As Integer)
10    On Error GoTo Err_label

20    Call AddEntry("DETCombinedWeeklyReportsPeriod", CStr(intPeriod))

      'DD Error Handler Start
Exit_label:
30         Exit Sub
Err_label:
40         Select Case Err.Number
           Case Else
50              Call LogError("basUtilityBackEnd", "GetDETCombinedWeeklyReportsPeriod")
60         End Select
70         Resume Exit_label
      'DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' GetDETCombinedWeeklyReportsPeriod
'---------------------------------------------------------------------------------------
 
Public Function GetDETCombinedWeeklyReportsPeriod() As Integer
10    On Error GoTo Err_label
20    On Error Resume Next
30    GetDETCombinedWeeklyReportsPeriod = LookupEntry("DETCombinedWeeklyReportsPeriod")
40    If Err.Number <> 0 Then
50        GetDETCombinedWeeklyReportsPeriod = 0
60    End If
      'DD Error Handler Start
Exit_label:
70         Exit Function
Err_label:
80         Select Case Err.Number
           Case Else
90              Call LogError("basUtilityBackEnd", "GetDETCombinedWeeklyReportsPeriod")
100        End Select
110        Resume Exit_label
      'DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' PutDETCombinedWeeklyReportsFrom
'---------------------------------------------------------------------------------------
 
Public Sub PutDETCombinedWeeklyReportsFrom(ByVal datFrom As Date)
10    On Error GoTo Err_label

20    Call AddEntry("DETCombinedWeeklyReportsFrom", Format(datFrom, "yyyy-mm-dd"))

      'DD Error Handler Start
Exit_label:
30         Exit Sub
Err_label:
40         Select Case Err.Number
           Case Else
50              Call LogError("basUtilityBackEnd", "PutDETCombinedWeeklyReportsFrom")
60         End Select
70         Resume Exit_label
      'DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' GetDETCombinedWeeklyReportsFrom
' Date is stored as a string yyyy-mm-dd
'---------------------------------------------------------------------------------------
 
Public Function GetDETCombinedWeeklyReportsFrom() As Date
10    On Error GoTo Err_label

      Dim strDate As String
      Dim datDate As Date
      Dim intYear As Integer
      Dim intMonth As Integer
      Dim intDay As Integer

20    strDate = LookupEntry("DETCombinedWeeklyReportsFrom")
30    If strDate = "" Then
40        GetDETCombinedWeeklyReportsFrom = Now()
50    Else
60        On Error Resume Next
70        intYear = CInt(Left(strDate, 4))
80        intMonth = CInt(Mid(strDate, 6, 2))
90        intDay = CInt(Mid(strDate, 9, 2))
100       datDate = DateSerial(intYear, intMonth, intDay)
110       If Err.Number <> 0 Then
120           GetDETCombinedWeeklyReportsFrom = Now()
130       Else
140           GetDETCombinedWeeklyReportsFrom = datDate
150       End If
160   End If

      'DD Error Handler Start
Exit_label:
170        Exit Function
Err_label:
180        Select Case Err.Number
           Case Else
190             Call LogError("basUtilityBackEnd", "GetDETCombinedWeeklyReportsFrom")
200        End Select
210        Resume Exit_label
      'DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' PutDETCombinedWeeklyReportsTo
'---------------------------------------------------------------------------------------
 
Public Sub PutDETCombinedWeeklyReportsTo(ByVal datFrom As Date)
10    On Error GoTo Err_label

20    Call AddEntry("DETCombinedWeeklyReportsTo", Format(datFrom, "yyyy-mm-dd"))

      'DD Error Handler Start
Exit_label:
30         Exit Sub
Err_label:
40         Select Case Err.Number
           Case Else
50              Call LogError("basUtilityBackEnd", "PutDETCombinedWeeklyReportsTo")
60         End Select
70         Resume Exit_label
      'DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' GetDETCombinedWeeklyReportsTo
' Date is stored as a string yyyy-mm-dd
'---------------------------------------------------------------------------------------
 
Public Function GetDETCombinedWeeklyReportsTo() As Date
10    On Error GoTo Err_label

      Dim strDate As String
      Dim datDate As Date
      Dim intYear As Integer
      Dim intMonth As Integer
      Dim intDay As Integer

20    strDate = LookupEntry("DETCombinedWeeklyReportsTo")
30    If strDate = "" Then
40        GetDETCombinedWeeklyReportsTo = Now()
50    Else
60        On Error Resume Next
70        intYear = CInt(Left(strDate, 4))
80        intMonth = CInt(Mid(strDate, 6, 2))
90        intDay = CInt(Mid(strDate, 9, 2))
100       datDate = DateSerial(intYear, intMonth, intDay)
110       If Err.Number <> 0 Then
120           GetDETCombinedWeeklyReportsTo = Now()
130       Else
140           GetDETCombinedWeeklyReportsTo = datDate
150       End If
160   End If

      'DD Error Handler Start
Exit_label:
170        Exit Function
Err_label:
180        Select Case Err.Number
           Case Else
190             Call LogError("basUtilityBackEnd", "GetDETCombinedWeeklyReportsTo")
200        End Select
210        Resume Exit_label
      'DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' PutDETCombinedWeeklyReportsDebug
'
' "True", "False"
'---------------------------------------------------------------------------------------
 
Public Sub PutDETCombinedWeeklyReportsDebug(ByVal strDebug As String)
10    On Error GoTo Err_label

20    Call AddEntry("DETCombinedWeeklyReportsDebug", strDebug)

      'DD Error Handler End

'DD Error Handler Start
Exit_label:
30         Exit Sub
Err_label:
40         Select Case Err.Number
     Case Else
50        Call LogError("basUtilityBackEnd", "PutDETCombinedWeeklyReportsDebug")
60         End Select
70         Resume Exit_label
'DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' GetDETCombinedWeeklyReportsDebug
'---------------------------------------------------------------------------------------
 
Public Function GetDETCombinedWeeklyReportsDebug() As String

10    On Error GoTo Err_label

      Dim strDebug As String

20    strDebug = LookupEntry("DETCombinedWeeklyReportsDebug")
30    If strDebug = "" Then
40        strDebug = "False"
50        Call AddEntry("DETCombinedWeeklyReportsDebug", "False")
60    End If
70    GetDETCombinedWeeklyReportsDebug = strDebug

'DD Error Handler Start
Exit_label:
80         Exit Function
Err_label:
90         Select Case Err.Number
     Case Else
100       Call LogError("basUtilityBackEnd", "GetDETCombinedWeeklyReportsDebug")
110        End Select
120        Resume Exit_label
'DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' PutDETCombinedWeeklyReportsFilepath
'---------------------------------------------------------------------------------------
 
Public Sub PutDETCombinedWeeklyReportsFilepath(ByVal strFilepath As String)
10    On Error GoTo Err_label

20    Call AddEntry("DETCombinedWeeklyReportsFilepath", strFilepath)

      'DD Error Handler End

'DD Error Handler Start
Exit_label:
30         Exit Sub
Err_label:
40         Select Case Err.Number
     Case Else
50        Call LogError("basUtilityBackEnd", "PutDETCombinedWeeklyReportsFilepath")
60         End Select
70         Resume Exit_label
'DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' GetDETCombinedWeeklyReportsFilepath
'---------------------------------------------------------------------------------------
 
Public Function GetDETCombinedWeeklyReportsFilepath() As String

10    On Error GoTo Err_label

      Dim strFilepath As String

20    strFilepath = LookupEntry("DETCombinedWeeklyReportsFilepath")
30    GetDETCombinedWeeklyReportsFilepath = strFilepath

'DD Error Handler Start
Exit_label:
40         Exit Function
Err_label:
50         Select Case Err.Number
     Case Else
60        Call LogError("basUtilityBackEnd", "GetDETCombinedWeeklyReportsFilepath")
70         End Select
80         Resume Exit_label
'DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' PutFillNetHours
'---------------------------------------------------------------------------------------
 
Public Sub PutFillNetHours(ByVal strPutFillNetHours As String)
10    On Error GoTo Err_label

20    Call AddEntry("FillNetHours", strPutFillNetHours)

      'DD Error Handler End

'DD Error Handler Start
Exit_label:
30         Exit Sub
Err_label:
40         Select Case Err.Number
     Case Else
50        Call LogError("basUtilityBackEnd", "PutFillNetHours")
60         End Select
70         Resume Exit_label
'DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' GetFillNetHours
'---------------------------------------------------------------------------------------
 
Public Function GetFillNetHours() As String

10    On Error GoTo Err_label

      Dim strFillNetHours As String

20    strFillNetHours = LookupEntry("FillNetHours")
30    GetFillNetHours = strFillNetHours

'DD Error Handler Start
Exit_label:
40         Exit Function
Err_label:
50         Select Case Err.Number
     Case Else
60        Call LogError("basUtilityBackEnd", "GetFillNetHours")
70         End Select
80         Resume Exit_label
'DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' PutMostRecentStoredRecapture
'---------------------------------------------------------------------------------------
' Called whenever a capture record is moved from the recatures sheet to the captures table
'
' band species capture_date_dd-mmm-yyyy weight_time_hh:mm (IDBand)
 
Public Sub PutMostRecentStoredRecapture(ByVal strMostRecentStoredRecapture As String)
10    On Error GoTo Err_label

20    Call AddEntry("MostRecentStoredRecapture", strMostRecentStoredRecapture)

      'DD Error Handler End

'DD Error Handler Start
Exit_label:
30         Exit Sub
Err_label:
40         Select Case Err.Number
     Case Else
50        Call LogError("basUtilityBackEnd", "PutMostRecentStoredRecapture")
60         End Select
70         Resume Exit_label
'DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' GetMostRecentStoredRecapture
'---------------------------------------------------------------------------------------
 
Public Function GetMostRecentStoredRecapture() As String

10    On Error GoTo Err_label

      Dim strMostRecentStoredRecapture As String

20    strMostRecentStoredRecapture = LookupEntry("MostRecentStoredRecapture")
30    GetMostRecentStoredRecapture = strMostRecentStoredRecapture

'DD Error Handler Start
Exit_label:
40         Exit Function
Err_label:
50         Select Case Err.Number
     Case Else
60        Call LogError("basUtilityBackEnd", "GetMostRecentStoredRecapture")
70         End Select
80         Resume Exit_label
'DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' PutDETSpeciesForm_DETSpeciesFilterID
'---------------------------------------------------------------------------------------
' Called from frmDETSpeciesForm
 
Public Sub PutDETSpeciesForm_DETSpeciesFilterID(ByVal strDETSpeciesFilterID As String)
10    On Error GoTo Err_label

20    On Error GoTo Err_label

30    If strDETSpeciesFilterID <> "" Then
40        If DCount("*", "tblDETSpeciesFilters", "[DETSpeciesFilterID] = '" & strDETSpeciesFilterID & "'") = 0 Then
50      strDETSpeciesFilterID = ""
60        End If
70    End If

80    Call AddEntry("DETSpeciesForm_DETSpeciesFilterID", strDETSpeciesFilterID)

'DD Error Handler Start
Exit_label:
90         Exit Sub
Err_label:
100        Select Case Err.Number
     Case Else
110       Call LogError("basUtilityBackEnd", "PutDETSpeciesForm_DETSpeciesFilterID")
120        End Select
130        Resume Exit_label
'DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' GetDETSpeciesForm_DETSpeciesFilterID
'---------------------------------------------------------------------------------------
 
Public Function GetDETSpeciesForm_DETSpeciesFilterID() As String

10    On Error GoTo Err_label

20    On Error GoTo Err_label

      Dim strDETSpeciesFilterID As String

30    strDETSpeciesFilterID = LookupEntry("DETSpeciesForm_DETSpeciesFilterID")

40    If strDETSpeciesFilterID <> "" Then
50        If DCount("*", "tblDETSpeciesFilters", "[DETSpeciesFilterID] = '" & strDETSpeciesFilterID & "'") = 0 Then
60      strDETSpeciesFilterID = ""
70        End If
80    End If

90    GetDETSpeciesForm_DETSpeciesFilterID = strDETSpeciesFilterID

'DD Error Handler Start
Exit_label:
100        Exit Function
Err_label:
110        Select Case Err.Number
     Case Else
120       Call LogError("basUtilityBackEnd", "GetDETSpeciesForm_DETSpeciesFilterID")
130        End Select
140        Resume Exit_label
'DD Error Handler End

End Function

'---------------------------------------------------------------------------------------
' PutBanditBandInventoryImportFolder
'---------------------------------------------------------------------------------------
 
Public Sub PutBanditBandInventoryImportFolder(ByVal strFilepath As String)
10    On Error GoTo Err_label

20    Call AddEntry("BanditBandInventoryImportFolder", strFilepath)

      'DD Error Handler End

'DD Error Handler Start
Exit_label:
30         Exit Sub
Err_label:
40         Select Case Err.Number
     Case Else
50        Call LogError("basUtilityBackEnd", "PutBanditBandInventoryImportFolder")
60         End Select
70         Resume Exit_label
'DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' GetBanditBandInventoryImportFolder
'---------------------------------------------------------------------------------------
 
Public Function GetBanditBandInventoryImportFolder() As String

10    On Error GoTo Err_label

      Dim strFilepath As String

20    strFilepath = LookupEntry("BanditBandInventoryImportFolder")
30    GetBanditBandInventoryImportFolder = strFilepath

'DD Error Handler Start
Exit_label:
40         Exit Function
Err_label:
50         Select Case Err.Number
     Case Else
60        Call LogError("basUtilityBackEnd", "GetBanditBandInventoryImportFolder")
70         End Select
80         Resume Exit_label
'DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' PutBanditBandInventoryImportWorksheet
'---------------------------------------------------------------------------------------
 
Public Sub PutBanditBandInventoryImportWorksheet(ByVal strFilepath As String)
10    On Error GoTo Err_label

20    Call AddEntry("BanditBandInventoryImportWorksheet", strFilepath)

      'DD Error Handler End

'DD Error Handler Start
Exit_label:
30         Exit Sub
Err_label:
40         Select Case Err.Number
     Case Else
50        Call LogError("basUtilityBackEnd", "PutBanditBandInventoryImportWorksheet")
60         End Select
70         Resume Exit_label
'DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' GetBanditBandInventoryImportWorksheet
'---------------------------------------------------------------------------------------
 
Public Function GetBanditBandInventoryImportWorksheet() As String

10    On Error GoTo Err_label

      Dim strFilepath As String

20    strFilepath = LookupEntry("BanditBandInventoryImportWorksheet")
30    GetBanditBandInventoryImportWorksheet = strFilepath

'DD Error Handler Start
Exit_label:
40         Exit Function
Err_label:
50         Select Case Err.Number
     Case Else
60        Call LogError("basUtilityBackEnd", "GetBanditBandInventoryImportWorksheet")
70         End Select
80         Resume Exit_label
'DD Error Handler End
End Function




'---------------------------------------------------------------------------------------
' PutEmailAddressListForReports
'---------------------------------------------------------------------------------------
 
Public Sub PutEmailAddressListForReports(ByVal strEmailAddressListForReports As String)

10       On Error GoTo Err_label

20    Call AddEntry("EmailAddressListForReports", strEmailAddressListForReports)

    'DD Error Handler Start
Exit_label:
30        Exit Sub
Err_label:
40        Select Case Err.Number
    Case Else
50       Call LogError("basUtilityBackEnd", "PutEmailAddressListForReports")
60        End Select
70        Resume Exit_label
    ' DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' GetEmailAddressListForReports
'---------------------------------------------------------------------------------------
 
Public Function GetEmailAddressListForReports() As String

10    On Error GoTo Err_label

      Dim strEmailAddressListForReports As String

20    strEmailAddressListForReports = LookupEntry("EmailAddressListForReports")
30    GetEmailAddressListForReports = strEmailAddressListForReports

    'DD Error Handler Start
Exit_label:
40        Exit Function
Err_label:
50        Select Case Err.Number
    Case Else
60       Call LogError("basUtilityBackEnd", "GetEmailAddressListForReports")
70        End Select
80        Resume Exit_label
    ' DD Error Handler End
End Function


'---------------------------------------------------------------------------------------
' PutEmailAddressListForErrors
'---------------------------------------------------------------------------------------
 
Public Sub PutEmailAddressListForErrors(ByVal strEmailAddressListForErrors As String)

10     On Error GoTo Err_label

20    Call AddEntry("EmailAddressListForErrors", strEmailAddressListForErrors)

    'DD Error Handler Start
Exit_label:
30        Exit Sub
Err_label:
40        Select Case Err.Number
    Case Else
50       Call LogError("basUtilityBackEnd", "PutEmailAddressListForErrors")
60        End Select
70        Resume Exit_label
    ' DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' GetEmailAddressListForErrors
'---------------------------------------------------------------------------------------
 
Public Function GetEmailAddressListForErrors() As String

10    On Error GoTo Err_label

      Dim strEmailAddressListForErrors As String

20    strEmailAddressListForErrors = LookupEntry("EmailAddressListForErrors")
30    GetEmailAddressListForErrors = strEmailAddressListForErrors

    'DD Error Handler Start
Exit_label:
40        Exit Function
Err_label:
50        Select Case Err.Number
    Case Else
60       Call LogError("basUtilityBackEnd", "GetEmailAddressListForErrors")
70        End Select
80        Resume Exit_label
    ' DD Error Handler End
End Function


'---------------------------------------------------------------------------------------
' PutMBODataEntryReplicationFolder
'---------------------------------------------------------------------------------------
 
Public Sub PutMBODataEntryReplicationFolder(ByVal strMBODataEntryReplicationFolder As String)

10       On Error GoTo Err_label

20    Call AddEntry("MBODataEntryReplicationFolder", strMBODataEntryReplicationFolder)

    'DD Error Handler Start
Exit_label:
30        Exit Sub
Err_label:
40        Select Case Err.Number
    Case Else
50       Call LogError("basUtilityBackEnd", "PutMBODataEntryReplicationFolder")
60        End Select
70        Resume Exit_label
    ' DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' GetMBODataEntryReplicationFolder
'---------------------------------------------------------------------------------------
 
Public Function GetMBODataEntryReplicationFolder() As String

10    On Error GoTo Err_label

      Dim strMBODataEntryReplicationFolder As String

20    strMBODataEntryReplicationFolder = LookupEntry("MBODataEntryReplicationFolder")
30    GetMBODataEntryReplicationFolder = strMBODataEntryReplicationFolder

    'DD Error Handler Start
Exit_label:
40        Exit Function
Err_label:
50        Select Case Err.Number
    Case Else
60       Call LogError("basUtilityBackEnd", "GetMBODataEntryReplicationFolder")
70        End Select
80        Resume Exit_label
    ' DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' PutMBODataEntryReplicationFolder_MBO
'---------------------------------------------------------------------------------------
 
Public Sub PutMBODataEntryReplicationFolder_MBO(ByVal strMBODataEntryReplicationFolder_MBO As String)

10       On Error GoTo Err_label

20    Call AddEntry("MBODataEntryReplicationFolder_MBO", strMBODataEntryReplicationFolder_MBO)

    'DD Error Handler Start
Exit_label:
30        Exit Sub
Err_label:
40        Select Case Err.Number
    Case Else
50       Call LogError("basUtilityBackEnd", "PutMBODataEntryReplicationFolder_MBO")
60        End Select
70        Resume Exit_label
    ' DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' GetMBODataEntryReplicationFolder_MBO
'---------------------------------------------------------------------------------------
 
Public Function GetMBODataEntryReplicationFolder_MBO() As String

10    On Error GoTo Err_label

      Dim strMBODataEntryReplicationFolder_MBO As String

20    strMBODataEntryReplicationFolder_MBO = LookupEntry("MBODataEntryReplicationFolder_MBO")
30    GetMBODataEntryReplicationFolder_MBO = strMBODataEntryReplicationFolder_MBO

    'DD Error Handler Start
Exit_label:
40        Exit Function
Err_label:
50        Select Case Err.Number
    Case Else
60       Call LogError("basUtilityBackEnd", "GetMBODataEntryReplicationFolder_MBO")
70        End Select
80        Resume Exit_label
    ' DD Error Handler End
End Function


'---------------------------------------------------------------------------------------
' PutMBODataEntryReplicationFolder_David
'---------------------------------------------------------------------------------------
 
Public Sub PutMBODataEntryReplicationFolder_David(ByVal strMBODataEntryReplicationFolder_David As String)

10       On Error GoTo Err_label

20    Call AddEntry("MBODataEntryReplicationFolder_David", strMBODataEntryReplicationFolder_David)

    'DD Error Handler Start
Exit_label:
30        Exit Sub
Err_label:
40        Select Case Err.Number
    Case Else
50       Call LogError("basUtilityBackEnd", "PutMBODataEntryReplicationFolder_David")
60        End Select
70        Resume Exit_label
    ' DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' GetMBODataEntryReplicationFolder_David
'---------------------------------------------------------------------------------------
 
Public Function GetMBODataEntryReplicationFolder_David() As String

10    On Error GoTo Err_label

      Dim strMBODataEntryReplicationFolder_David As String

20    strMBODataEntryReplicationFolder_David = LookupEntry("MBODataEntryReplicationFolder_David")
30    GetMBODataEntryReplicationFolder_David = strMBODataEntryReplicationFolder_David

    'DD Error Handler Start
Exit_label:
40        Exit Function
Err_label:
50        Select Case Err.Number
    Case Else
60       Call LogError("basUtilityBackEnd", "GetMBODataEntryReplicationFolder_David")
70        End Select
80        Resume Exit_label
    ' DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' PutPathToBackupProgram
'---------------------------------------------------------------------------------------
 
Public Sub PutPathToBackupProgram(ByVal strPathToBackupProgram As String)

10       On Error GoTo Err_label

20    Call AddEntry("PathToBackupProgram", strPathToBackupProgram)

    'DD Error Handler Start
Exit_label:
30        Exit Sub
Err_label:
40        Select Case Err.Number
    Case Else
50       Call LogError("basUtilityBackEnd", "PutPathToBackupProgram")
60        End Select
70        Resume Exit_label
    ' DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' GetPathToBackupProgram
'---------------------------------------------------------------------------------------
 
Public Function GetPathToBackupProgram() As String

10    On Error GoTo Err_label

      Dim strPathToBackupProgram As String

20    strPathToBackupProgram = LookupEntry("PathToBackupProgram")
30    GetPathToBackupProgram = strPathToBackupProgram

    'DD Error Handler Start
Exit_label:
40        Exit Function
Err_label:
50        Select Case Err.Number
    Case Else
60       Call LogError("basUtilityBackEnd", "GetPathToBackupProgram")
70        End Select
80        Resume Exit_label
    ' DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' PutPathToBackupProgram_MBO
'---------------------------------------------------------------------------------------
 
Public Sub PutPathToBackupProgram_MBO(ByVal strPathToBackupProgram_MBO As String)

10       On Error GoTo Err_label

20    Call AddEntry("PathToBackupProgram_MBO", strPathToBackupProgram_MBO)

    'DD Error Handler Start
Exit_label:
30        Exit Sub
Err_label:
40        Select Case Err.Number
    Case Else
50       Call LogError("basUtilityBackEnd", "PutPathToBackupProgram_MBO")
60        End Select
70        Resume Exit_label
    ' DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' GetPathToBackupProgram_MBO
'---------------------------------------------------------------------------------------
 
Public Function GetPathToBackupProgram_MBO() As String

10    On Error GoTo Err_label

      Dim strPathToBackupProgram_MBO As String

20    strPathToBackupProgram_MBO = LookupEntry("PathToBackupProgram_MBO")
30    GetPathToBackupProgram_MBO = strPathToBackupProgram_MBO

    'DD Error Handler Start
Exit_label:
40        Exit Function
Err_label:
50        Select Case Err.Number
    Case Else
60       Call LogError("basUtilityBackEnd", "GetPathToBackupProgram_MBO")
70        End Select
80        Resume Exit_label
    ' DD Error Handler End
End Function


'---------------------------------------------------------------------------------------
' PutPathToBackupProgram_David
'---------------------------------------------------------------------------------------
 
Public Sub PutPathToBackupProgram_David(ByVal strPathToBackupProgram_David As String)

10       On Error GoTo Err_label

20    Call AddEntry("PathToBackupProgram_David", strPathToBackupProgram_David)

    'DD Error Handler Start
Exit_label:
30        Exit Sub
Err_label:
40        Select Case Err.Number
    Case Else
50       Call LogError("basUtilityBackEnd", "PutPathToBackupProgram_David")
60        End Select
70        Resume Exit_label
    ' DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' GetPathToBackupProgram_David
'---------------------------------------------------------------------------------------
 
Public Function GetPathToBackupProgram_David() As String

10    On Error GoTo Err_label

      Dim strPathToBackupProgram_David As String

20    strPathToBackupProgram_David = LookupEntry("PathToBackupProgram_David")
30    GetPathToBackupProgram_David = strPathToBackupProgram_David

    'DD Error Handler Start
Exit_label:
40        Exit Function
Err_label:
50        Select Case Err.Number
    Case Else
60       Call LogError("basUtilityBackEnd", "GetPathToBackupProgram_David")
70        End Select
80        Resume Exit_label
    ' DD Error Handler End
End Function




'---------------------------------------------------------------------------------------
' PutLoadTablesSourceFilepath
'---------------------------------------------------------------------------------------
 
Public Sub PutLoadTablesSourceFilepath(ByVal strLoadTablesSourceFilepath As String)

10       On Error GoTo Err_label

20    Call AddEntry("LoadTablesSourceFilepath", strLoadTablesSourceFilepath)

    'DD Error Handler Start
Exit_label:
30        Exit Sub
Err_label:
40        Select Case Err.Number
    Case Else
50       Call LogError("basUtilityBackEnd", "PutLoadTablesSourceFilepath")
60        End Select
70        Resume Exit_label
    ' DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' GetLoadTablesSourceFilepath
'---------------------------------------------------------------------------------------
 
Public Function GetLoadTablesSourceFilepath() As String

10    On Error GoTo Err_label

      Dim strLoadTablesSourceFilepath As String

20    strLoadTablesSourceFilepath = LookupEntry("LoadTablesSourceFilepath")
30    GetLoadTablesSourceFilepath = strLoadTablesSourceFilepath

    'DD Error Handler Start
Exit_label:
40        Exit Function
Err_label:
50        Select Case Err.Number
    Case Else
60       Call LogError("basUtilityBackEnd", "GetLoadTablesSourceFilepath")
70        End Select
80        Resume Exit_label
    ' DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' PutDisplaySilentErrors
'---------------------------------------------------------------------------------------
 
Public Sub PutDisplaySilentErrors(ByVal fDisplaySilentErrors As Boolean)

10       On Error GoTo Err_label

20    Call AddEntry("DisplaySilentErrors", IIf(fDisplaySilentErrors, "True", "False"))

    'DD Error Handler Start
Exit_label:
30        Exit Sub
Err_label:
40        Select Case Err.Number
    Case Else
50       Call LogError("basUtilityBackEnd", "PutDisplaySilentErrors")
60        End Select
70        Resume Exit_label
    ' DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' GetDisplaySilentErrors
'---------------------------------------------------------------------------------------
 
Public Function GetDisplaySilentErrors() As Boolean

10    On Error GoTo Err_label

      Dim strGetDisplaySilentErrors As String

20    strGetDisplaySilentErrors = LookupEntry("DisplaySilentErrors")
30    GetDisplaySilentErrors = IIf(strGetDisplaySilentErrors = "True", True, False)

          'DD Error Handler Start
Exit_label:
40        Exit Function
Err_label:
50        Select Case Err.Number
          Case Else
60       Call LogError("basUtilityBackEnd", "GetDisplaySilentErrors")
70        End Select
80        Resume Exit_label
          ' DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' PutRowsPerPageBandInventoryWordReport
'---------------------------------------------------------------------------------------
 
Public Sub PutRowsPerPageBandInventoryWordReport(ByVal intRowsPerPageBandInventoryWordReport As Integer)

10       On Error GoTo Err_label

20    Call AddEntry("RowsPerPageBandInventoryWordReport", CStr(intRowsPerPageBandInventoryWordReport))

    'DD Error Handler Start
Exit_label:
30        Exit Sub
Err_label:
40        Select Case Err.Number
    Case Else
50       Call LogError("basUtilityBackEnd", "PutRowsPerPageBandInventoryWordReport")
60        End Select
70        Resume Exit_label
    ' DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' GetRowsPerPageBandInventoryWordReport
'---------------------------------------------------------------------------------------
 
Public Function GetRowsPerPageBandInventoryWordReport() As Integer

10    On Error GoTo Err_label

      Dim strRowsPerPageBandInventoryWordReport As String

20    strRowsPerPageBandInventoryWordReport = LookupEntry("RowsPerPageBandInventoryWordReport")
30    If strRowsPerPageBandInventoryWordReport = "" Then
40      GetRowsPerPageBandInventoryWordReport = 0
50    Else
60      GetRowsPerPageBandInventoryWordReport = CInt(strRowsPerPageBandInventoryWordReport)
70    End If

          'DD Error Handler Start
Exit_label:
80        Exit Function
Err_label:
90        Select Case Err.Number
          Case Else
100      Call LogError("basUtilityBackEnd", "GetRowsPerPageBandInventoryWordReport")
110       End Select
120       Resume Exit_label
          ' DD Error Handler End
End Function


'---------------------------------------------------------------------------------------
' PutMBO10YearProgramReport_AbundanceRowsOnFirstPage
'---------------------------------------------------------------------------------------
 
Public Sub PutMBO10YearProgramReport_AbundanceRowsOnFirstPage(ByVal intMBO10YearProgramReport_AbundanceRowsOnFirstPage As Integer)

10       On Error GoTo Err_label

20    Call AddEntry("MBO10YearProgramReport_AbundanceRowsOnFirstPage", CStr(intMBO10YearProgramReport_AbundanceRowsOnFirstPage))

    'DD Error Handler Start
Exit_label:
30        Exit Sub
Err_label:
40        Select Case Err.Number
    Case Else
50       Call LogError("basUtilityBackEnd", "PutMBO10YearProgramReport_AbundanceRowsOnFirstPage")
60        End Select
70        Resume Exit_label
    ' DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' GetMBO10YearProgramReport_AbundanceRowsOnFirstPage
'---------------------------------------------------------------------------------------
 
Public Function GetMBO10YearProgramReport_AbundanceRowsOnFirstPage() As Integer

On Error GoTo Err_label

Dim strMBO10YearProgramReport_AbundanceRowsOnFirstPage As String

strMBO10YearProgramReport_AbundanceRowsOnFirstPage = LookupEntry("MBO10YearProgramReport_AbundanceRowsOnFirstPage")
If strMBO10YearProgramReport_AbundanceRowsOnFirstPage = "" Then
  GetMBO10YearProgramReport_AbundanceRowsOnFirstPage = 0
Else
  GetMBO10YearProgramReport_AbundanceRowsOnFirstPage = CInt(strMBO10YearProgramReport_AbundanceRowsOnFirstPage)
End If

If GetMBO10YearProgramReport_AbundanceRowsOnFirstPage = 0 Then
    GetMBO10YearProgramReport_AbundanceRowsOnFirstPage = 25
End If

    'DD Error Handler Start
Exit_label:
    Exit Function
Err_label:
    Select Case Err.Number
    Case Else
   Call LogError("basUtilityBackEnd", "GetMBO10YearProgramReport_AbundanceRowsOnFirstPage")
    End Select
    Resume Exit_label
    ' DD Error Handler End
End Function

''---------------------------------------------------------------------------------------
'' PutMBODataEntryReplicationFolderMaximumNumberOfFiles
''---------------------------------------------------------------------------------------
'
'Public Sub PutMBODataEntryReplicationFolderMaximumNumberOfFiles(ByVal intMBODataEntryReplicationFolderMaximumNumberOfFiles As Integer)
'
'10       On Error GoTo Err_label
'
'20    Call AddEntry("MBODataEntryReplicationFolderMaximumNumberOfFiles", CStr(intMBODataEntryReplicationFolderMaximumNumberOfFiles))
'
'    'DD Error Handler Start
'Exit_label:
'30        Exit Sub
'Err_label:
'40        Select Case Err.Number
'    Case Else
'50       Call LogError("basUtilityBackEnd", "PutMBO10YearProgramReport_AbundanceRowsOnFirstPage")
'60        End Select
'70        Resume Exit_label
'    ' DD Error Handler End
'
'
'End Sub

''---------------------------------------------------------------------------------------
'' GetMBODataEntryReplicationFolderMaximumNumberOfFiles
''---------------------------------------------------------------------------------------
'
'Public Function GetMBODataEntryReplicationFolderMaximumNumberOfFiles() As Integer
'
'10    On Error GoTo Err_label
'
'      Dim strMBODataEntryReplicationFolderMaximumNumberOfFiles As String
'
'20    strMBODataEntryReplicationFolderMaximumNumberOfFiles = LookupEntry("MBODataEntryReplicationFolderMaximumNumberOfFiles")
'30    If strMBODataEntryReplicationFolderMaximumNumberOfFiles = "" Then
'40      GetMBODataEntryReplicationFolderMaximumNumberOfFiles = 100
'50    Else
'60      GetMBODataEntryReplicationFolderMaximumNumberOfFiles = CInt(strMBODataEntryReplicationFolderMaximumNumberOfFiles)
'70    End If
'
'          'DD Error Handler Start
'Exit_label:
'80        Exit Function
'Err_label:
'90        Select Case Err.Number
'          Case Else
'100      Call LogError("basUtilityBackEnd", "GetMBO10YearProgramReport_AbundanceRowsOnFirstPage")
'110       End Select
'120       Resume Exit_label
'          ' DD Error Handler End
'
'
'End Function

''---------------------------------------------------------------------------------------
'' PutMBODataEntryReplicationFolderMaximumNumberOfFiles_MBO
''---------------------------------------------------------------------------------------
'
'Public Sub PutMBODataEntryReplicationFolderMaximumNumberOfFiles_MBO(ByVal intMBODataEntryReplicationFolderMaximumNumberOfFiles As Integer)
'
'10       On Error GoTo Err_label
'
'20    Call AddEntry("MBODataEntryReplicationFolderMaximumNumberOfFiles_MBO", CStr(intMBODataEntryReplicationFolderMaximumNumberOfFiles))
'
'    'DD Error Handler Start
'Exit_label:
'30        Exit Sub
'Err_label:
'40        Select Case Err.Number
'    Case Else
'50       Call LogError("basUtilityBackEnd", "PutMBODataEntryReplicationFolderMaximumNumberOfFiles_MBO")
'60        End Select
'70        Resume Exit_label
'    ' DD Error Handler End
'
'
'End Sub

''---------------------------------------------------------------------------------------
'' GetMBODataEntryReplicationFolderMaximumNumberOfFiles_MBO
''---------------------------------------------------------------------------------------
'
'Public Function GetMBODataEntryReplicationFolderMaximumNumberOfFiles_MBO() As Integer
'
'10    On Error GoTo Err_label
'
'      Dim strMBODataEntryReplicationFolderMaximumNumberOfFiles As String
'
'20    strMBODataEntryReplicationFolderMaximumNumberOfFiles = LookupEntry("MBODataEntryReplicationFolderMaximumNumberOfFiles_MBO")
'30    If strMBODataEntryReplicationFolderMaximumNumberOfFiles = "" Then
'40      GetMBODataEntryReplicationFolderMaximumNumberOfFiles_MBO = 100
'50    Else
'60      GetMBODataEntryReplicationFolderMaximumNumberOfFiles_MBO = CInt(strMBODataEntryReplicationFolderMaximumNumberOfFiles)
'70    End If
'
'          'DD Error Handler Start
'Exit_label:
'80        Exit Function
'Err_label:
'90        Select Case Err.Number
'          Case Else
'100      Call LogError("basUtilityBackEnd", "GetMBODataEntryReplicationFolderMaximumNumberOfFiles_MBO")
'110       End Select
'120       Resume Exit_label
'          ' DD Error Handler End
'
'End Function

''---------------------------------------------------------------------------------------
'' PutMBODataEntryReplicationFolderMaximumNumberOfFiles_David
''---------------------------------------------------------------------------------------
'
'Public Sub PutMBODataEntryReplicationFolderMaximumNumberOfFiles_David(ByVal intMBODataEntryReplicationFolderMaximumNumberOfFiles As Integer)
'
'10       On Error GoTo Err_label
'
'20    Call AddEntry("MBODataEntryReplicationFolderMaximumNumberOfFiles_David", CStr(intMBODataEntryReplicationFolderMaximumNumberOfFiles))
'
'    'DD Error Handler Start
'Exit_label:
'30        Exit Sub
'Err_label:
'40        Select Case Err.Number
'    Case Else
'50       Call LogError("basUtilityBackEnd", "PutMBODataEntryReplicationFolderMaximumNumberOfFiles_David")
'60        End Select
'70        Resume Exit_label
'    ' DD Error Handler End
'
'
'End Sub

''---------------------------------------------------------------------------------------
'' GetMBODataEntryReplicationFolderMaximumNumberOfFiles_David
''---------------------------------------------------------------------------------------
'
'Public Function GetMBODataEntryReplicationFolderMaximumNumberOfFiles_David() As Integer
'
'10    On Error GoTo Err_label
'
'      Dim strMBODataEntryReplicationFolderMaximumNumberOfFiles As String
'
'20    strMBODataEntryReplicationFolderMaximumNumberOfFiles = LookupEntry("MBODataEntryReplicationFolderMaximumNumberOfFiles_David")
'30    If strMBODataEntryReplicationFolderMaximumNumberOfFiles = "" Then
'40      GetMBODataEntryReplicationFolderMaximumNumberOfFiles_David = 100
'50    Else
'60      GetMBODataEntryReplicationFolderMaximumNumberOfFiles_David = CInt(strMBODataEntryReplicationFolderMaximumNumberOfFiles)
'70    End If
'
'          'DD Error Handler Start
'Exit_label:
'80        Exit Function
'Err_label:
'90        Select Case Err.Number
'          Case Else
'100      Call LogError("basUtilityBackEnd", "GetMBODataEntryReplicationFolderMaximumNumberOfFiles_David")
'110       End Select
'120       Resume Exit_label
'          ' DD Error Handler End
'
'End Function

'---------------------------------------------------------------------------------------
' PutSheetOrderControls
' The order of the controls on the New Bands Sheet and the Recatures Sheet
'---------------------------------------------------------------------------------------
 
Public Sub PutSheetOrderControls(ByVal intSheetOrderControls As Integer)

10       On Error GoTo Err_label

20    Call AddEntry("SheetOrderControls", CStr(intSheetOrderControls))

    'DD Error Handler Start
Exit_label:
30        Exit Sub
Err_label:
40        Select Case Err.Number
    Case Else
50       Call LogError("basUtilityBackEnd", "PutSheetOrderControls")
60        End Select
70        Resume Exit_label
    ' DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' GetSheetOrderControls
'---------------------------------------------------------------------------------------
 
Public Function GetSheetOrderControls() As Integer

10    On Error GoTo Err_label

      Dim strGetSheetOrderControls As String

20    strGetSheetOrderControls = LookupEntry("SheetOrderControls")
30    If strGetSheetOrderControls = "" Then
40      GetSheetOrderControls = 1
50    Else
60      GetSheetOrderControls = CInt(strGetSheetOrderControls)
70    End If

    'DD Error Handler Start
Exit_label:
80        Exit Function
Err_label:
90        Select Case Err.Number
    Case Else
100      Call LogError("basUtilityBackEnd", "GetSheetOrderControls")
110       End Select
120       Resume Exit_label
    ' DD Error Handler End

End Function

'---------------------------------------------------------------------------------------
' PutDataEntrySource
'
' "FromSheets" = Simon is copying data from banding sheets - transactions are not logged to a USB Flash Drive => faster data entry
' "Live"       = Data entry at the banding station - each transaction must be logged to a USB Flash Drive
'---------------------------------------------------------------------------------------
 
Public Sub PutDataEntrySource(ByVal strDataEntrySource As String)

10    On Error GoTo Err_label

20    Call AddEntry("DataEntrySource", strDataEntrySource)

    'DD Error Handler Start
Exit_label:
30        Exit Sub
Err_label:
40        Select Case Err.Number
    Case Else
50       Call LogError("basUtilityBackEnd", "PutDataEntrySource")
60        End Select
70        Resume Exit_label
    ' DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' GetDataEntrySource
'---------------------------------------------------------------------------------------
 
Public Function GetDataEntrySource() As String

10    On Error GoTo Err_label

      Dim strDataEntrySource As String

20    strDataEntrySource = LookupEntry("DataEntrySource")
30    GetDataEntrySource = strDataEntrySource

    'DD Error Handler Start
Exit_label:
40        Exit Function
Err_label:
50        Select Case Err.Number
    Case Else
60       Call LogError("basUtilityBackEnd", "GetDataEntrySource")
70        End Select
80        Resume Exit_label
    ' DD Error Handler End

End Function




'---------------------------------------------------------------------------------------
' PutDisableOneRecordAtATimeLiveBackupDET
'---------------------------------------------------------------------------------------
 
Public Sub PutDisableOneRecordAtATimeLiveBackupDET(ByVal fDisableOneRecordAtATimeLiveBackupDET As Boolean)

10    On Error GoTo Err_label

20    Call AddEntry("DisableOneRecordAtATimeLiveBackupDET", IIf(fDisableOneRecordAtATimeLiveBackupDET, "True", "False"))

    'DD Error Handler Start
Exit_label:
30        Exit Sub
Err_label:
40        Select Case Err.Number
    Case Else
50       Call LogError("basUtilityBackEnd", "DisableOneRecordAtATimeLiveBackupDET")
60        End Select
70        Resume Exit_label
    ' DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' GetDisableOneRecordAtATimeLiveBackupDET
'---------------------------------------------------------------------------------------
 
Public Function GetDisableOneRecordAtATimeLiveBackupDET() As Boolean

10    On Error GoTo Err_label

      Dim strDisableOneRecordAtATimeLiveBackupDET As String

20    strDisableOneRecordAtATimeLiveBackupDET = LookupEntry("DisableOneRecordAtATimeLiveBackupDET")
30    GetDisableOneRecordAtATimeLiveBackupDET = IIf(strDisableOneRecordAtATimeLiveBackupDET = "True", True, False)

    'DD Error Handler Start
Exit_label:
40        Exit Function
Err_label:
50        Select Case Err.Number
    Case Else
60       Call LogError("basUtilityBackEnd", "GetDisableOneRecordAtATimeLiveBackupDET")
70        End Select
80        Resume Exit_label
    ' DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' PutDisableOneRecordAtATimeLiveBackupCaptures
'---------------------------------------------------------------------------------------
 
Public Sub PutDisableOneRecordAtATimeLiveBackupCaptures(ByVal fDisableOneRecordAtATimeLiveBackupCaptures As Boolean)

10    On Error GoTo Err_label

20    Call AddEntry("DisableOneRecordAtATimeLiveBackupCaptures", IIf(fDisableOneRecordAtATimeLiveBackupCaptures, "True", "False"))

    'DD Error Handler Start
Exit_label:
30        Exit Sub
Err_label:
40        Select Case Err.Number
    Case Else
50       Call LogError("basUtilityBackEnd", "DisableOneRecordAtATimeLiveBackupCaptures")
60        End Select
70        Resume Exit_label
    ' DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' GetDisableOneRecordAtATimeLiveBackupCaptures
'---------------------------------------------------------------------------------------
 
Public Function GetDisableOneRecordAtATimeLiveBackupCaptures() As Boolean

10    On Error GoTo Err_label

      Dim strDisableOneRecordAtATimeLiveBackupCaptures As String

20    strDisableOneRecordAtATimeLiveBackupCaptures = LookupEntry("DisableOneRecordAtATimeLiveBackupCaptures")
30    GetDisableOneRecordAtATimeLiveBackupCaptures = IIf(strDisableOneRecordAtATimeLiveBackupCaptures = "True", True, False)

    'DD Error Handler Start
Exit_label:
40        Exit Function
Err_label:
50        Select Case Err.Number
    Case Else
60       Call LogError("basUtilityBackEnd", "GetDisableOneRecordAtATimeLiveBackupCaptures")
70        End Select
80        Resume Exit_label
    ' DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' PutMBOLiveBackupVersion
'
'---------------------------------------------------------------------------------------
 
Public Sub PutMBOLiveBackupVersion(ByVal lngMBOLiveBackupVersion As Long)

10    On Error GoTo Err_label

20    Call AddEntry_Long("PutMBOLiveBackupVersion", lngMBOLiveBackupVersion)

    'DD Error Handler Start
Exit_label:
30        Exit Sub
Err_label:
40        Select Case Err.Number
    Case Else
50       Call LogError("basUtilityBackEnd", "PutMBOLiveBackupVersion")
60        End Select
70        Resume Exit_label
    ' DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' GetMBOLiveBackupVersion
'---------------------------------------------------------------------------------------
 
Public Function GetMBOLiveBackupVersion() As Long

10    On Error GoTo Err_label

20    GetMBOLiveBackupVersion = LookupEntry_Long("PutMBOLiveBackupVersion")

    'DD Error Handler Start
Exit_label:
30        Exit Function
Err_label:
40        Select Case Err.Number
    Case Else
50       Call LogError("basUtilityBackEnd", "GetMBOLiveBackupVersion")
60        End Select
70        Resume Exit_label
    ' DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' PutTimestampSuffix
'
' A 4 digit number that is appended to timestamps to distinguish between records that were entered during the same second.
'---------------------------------------------------------------------------------------
 
Public Sub PutTimestampSuffix(ByVal lngTimestampSuffix As Long)

10    On Error GoTo Err_label

20    Call AddEntry_Long("TimestampSuffix", lngTimestampSuffix)

    'DD Error Handler Start
Exit_label:
30        Exit Sub
Err_label:
40        Select Case Err.Number
    Case Else
50       Call LogError("basUtilityBackEnd", "PutTimestampSuffix")
60        End Select
70        Resume Exit_label
    ' DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' GetTimestampSuffix
'---------------------------------------------------------------------------------------
 
Public Function GetTimestampSuffix() As Long

10    On Error GoTo Err_label

20    GetTimestampSuffix = LookupEntry_Long("TimestampSuffix")

    'DD Error Handler Start
Exit_label:
30        Exit Function
Err_label:
40        Select Case Err.Number
    Case Else
50       Call LogError("basUtilityBackEnd", "GetTimestampSuffix")
60        End Select
70        Resume Exit_label
    ' DD Error Handler End

End Function

'---------------------------------------------------------------------------------------
' PutPermit
'---------------------------------------------------------------------------------------
 
Public Sub PutPermit(ByVal strPermit As String)

10    On Error GoTo Err_label

20    Call AddEntry("Permit", strPermit)

    'DD Error Handler Start
Exit_label:
30        Exit Sub
Err_label:
40        Select Case Err.Number
    Case Else
50       Call LogError("basUtilityBackEnd", "PutPermit")
60        End Select
70        Resume Exit_label
    ' DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' GetPermit
'---------------------------------------------------------------------------------------
 
Public Function GetPermit() As String

10    On Error GoTo Err_label

20    GetPermit = LookupEntry("Permit")

    'DD Error Handler Start
Exit_label:
30        Exit Function
Err_label:
40        Select Case Err.Number
    Case Else
50       Call LogError("basUtilityBackEnd", "GetPermit")
60        End Select
70        Resume Exit_label
    ' DD Error Handler End

End Function

' ErrorLoggingMaxEmailsPerDay                Long
' ErrorLoggingDateOfPreviousEmail            Date
' ErrorLoggingCountEmailsToday               Long

'---------------------------------------------------------------------------------------
' PutErrorLoggingMaxEmailsPerDay
'---------------------------------------------------------------------------------------
 
Public Sub PutErrorLoggingMaxEmailsPerDay(ByVal lngErrorLoggingMaxEmailsPerDay As Long)

10    On Error GoTo Err_label

20    Call AddEntry_Long("ErrorLoggingMaxEmailsPerDay", lngErrorLoggingMaxEmailsPerDay)

    'DD Error Handler Start
Exit_label:
30        Exit Sub
Err_label:
40        Select Case Err.Number
    Case Else
50       Call LogError("basUtilityBackEnd", "PutErrorLoggingMaxEmailsPerDay")
60        End Select
70        Resume Exit_label
    ' DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' GetErrorLoggingMaxEmailsPerDay
'---------------------------------------------------------------------------------------
 
Public Function GetErrorLoggingMaxEmailsPerDay() As Long

10    On Error GoTo Err_label

20    GetErrorLoggingMaxEmailsPerDay = LookupEntry_Long("ErrorLoggingMaxEmailsPerDay")

    'DD Error Handler Start
Exit_label:
30        Exit Function
Err_label:
40        Select Case Err.Number
    Case Else
50       Call LogError("basUtilityBackEnd", "GetErrorLoggingMaxEmailsPerDay")
60        End Select
70        Resume Exit_label
    ' DD Error Handler End

End Function

'---------------------------------------------------------------------------------------
' PutErrorLoggingCountEmailsToday
'---------------------------------------------------------------------------------------
 
Public Sub PutErrorLoggingCountEmailsToday(ByVal lngErrorLoggingCountEmailsToday As Long)

10    On Error GoTo Err_label

20    Call AddEntry_Long("ErrorLoggingCountEmailsToday", lngErrorLoggingCountEmailsToday)

    'DD Error Handler Start
Exit_label:
30        Exit Sub
Err_label:
40        Select Case Err.Number
    Case Else
50       Call LogError("basUtilityBackEnd", "PutErrorLoggingCountEmailsToday")
60        End Select
70        Resume Exit_label
    ' DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' GetErrorLoggingCountEmailsToday
'---------------------------------------------------------------------------------------
 
Public Function GetErrorLoggingCountEmailsToday() As Long

10    On Error GoTo Err_label

20    GetErrorLoggingCountEmailsToday = LookupEntry_Long("ErrorLoggingCountEmailsToday")

    'DD Error Handler Start
Exit_label:
30        Exit Function
Err_label:
40        Select Case Err.Number
    Case Else
50       Call LogError("basUtilityBackEnd", "GetErrorLoggingCountEmailsToday")
60        End Select
70        Resume Exit_label
    ' DD Error Handler End

End Function

'---------------------------------------------------------------------------------------
' PutErrorLoggingDateOfPreviousEmail
'---------------------------------------------------------------------------------------
 
Public Sub PutErrorLoggingDateOfPreviousEmail(ByVal datErrorLoggingDateOfPreviousEmail As Date)

10    On Error GoTo Err_label

20    Call AddEntry_Date("ErrorLoggingDateOfPreviousEmail", datErrorLoggingDateOfPreviousEmail)

    'DD Error Handler Start
Exit_label:
30        Exit Sub
Err_label:
40        Select Case Err.Number
    Case Else
50       Call LogError("basUtilityBackEnd", "PutErrorLoggingDateOfPreviousEmail")
60        End Select
70        Resume Exit_label
    ' DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' GetErrorLoggingDateOfPreviousEmail
'---------------------------------------------------------------------------------------
 
Public Function GetErrorLoggingDateOfPreviousEmail() As Date

10    On Error GoTo Err_label

20    GetErrorLoggingDateOfPreviousEmail = LookupEntry_Date("ErrorLoggingDateOfPreviousEmail")

    'DD Error Handler Start
Exit_label:
30        Exit Function
Err_label:
40        Select Case Err.Number
    Case Else
50       Call LogError("basUtilityBackEnd", "GetErrorLoggingDateOfPreviousEmail")
60        End Select
70        Resume Exit_label
    ' DD Error Handler End

End Function



'---------------------------------------------------------------------------------------
' PutAbundanceChartYearLast
'---------------------------------------------------------------------------------------
 
Public Sub PutAbundanceChartYearLast(ByVal intYear As Integer)

10    On Error GoTo Err_label

20    Call AddEntry("AbundanceChartYearLast", CStr(intYear))

    'DD Error Handler Start
Exit_label:
30        Exit Sub
Err_label:
40        Select Case Err.Number
    Case Else
50       Call LogError("basUtilityBackEnd", "PutAbundanceChartYearLast")
60        End Select
70        Resume Exit_label
    ' DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' GetAbundanceChartYearLast
'---------------------------------------------------------------------------------------
 
Public Function GetAbundanceChartYearLast() As Integer

10    On Error GoTo Err_label

      Dim intYear As Integer
      Dim strYear As String

20    strYear = LookupEntry("AbundanceChartYearLast")
30    If strYear = "" Then
40        intYear = Year(Now())
50        Call AddEntry("AbundanceChartYearLast", CStr(intYear))
60    Else
70        intYear = CInt(strYear)
80    End If
90    GetAbundanceChartYearLast = intYear

    'DD Error Handler Start
Exit_label:
    Exit Function
Err_label:
    Select Case Err.Number
    Case Else
         Call LogError("basUtilityBackEnd", "GetAbundanceChartYearLast")
    End Select
    Resume Exit_label
    ' DD Error Handler End
End Function


'---------------------------------------------------------------------------------------
' PutVolunteersSortBy
'---------------------------------------------------------------------------------------
 
Public Sub PutVolunteersSortBy(ByVal strSortBy As String)

10    On Error GoTo Err_label

20    Select Case strSortBy
      Case "Sort by name", "Sort by code"
30    Case Else
40      strSortBy = "Sort by name"
50    End Select

60    Call AddEntry("VolunteersSortBy", strSortBy)

    'DD Error Handler Start
Exit_label:
70        Exit Sub
Err_label:
80        Select Case Err.Number
    Case Else
90       Call LogError("basUtilityBackEnd", "PutVolunteersSortBy")
100       End Select
110       Resume Exit_label
    ' DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' GetVolunteersSortBy
'---------------------------------------------------------------------------------------
 
Public Function GetVolunteersSortBy() As String


10    On Error GoTo Err_label

      Dim strSortBy As String

20    strSortBy = LookupEntry("VolunteersSortBy")

      Select Case strSortBy
      Case "Sort by name", "Sort by code"
      Case Else
        strSortBy = "Sort by name"
      End Select

90    GetVolunteersSortBy = strSortBy

    'DD Error Handler Start
Exit_label:
    Exit Function
Err_label:
    Select Case Err.Number
    Case Else
         Call LogError("basUtilityBackEnd", "GetVolunteersSortBy")
    End Select
    Resume Exit_label
    ' DD Error Handler End
End Function


'---------------------------------------------------------------------------------------
' PutDET15YearReportSpeciesParts
'---------------------------------------------------------------------------------------

Public Sub Put15YearReportSpeciesParts(ByVal lngSpeciesParts As Long)

10    On Error GoTo Err_label

60    Call AddEntry_Long("15YearReportSpeciesParts", lngSpeciesParts)

    'DD Error Handler Start
Exit_label:
70        Exit Sub
Err_label:
80        Select Case Err.Number
    Case Else
90       Call LogError("basUtilityBackEnd", "Put15YearReportSpeciesParts")
100       End Select
110       Resume Exit_label
    ' DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' GetVolunteersSortBy
'---------------------------------------------------------------------------------------
 
Public Function Get15YearReportSpeciesParts() As Long


10    On Error GoTo Err_label

20    Get15YearReportSpeciesParts = LookupEntry_Long("15YearReportSpeciesParts")

    'DD Error Handler Start
Exit_label:
    Exit Function
Err_label:
    Select Case Err.Number
    Case Else
         Call LogError("basUtilityBackEnd", "Get15YearReportSpeciesParts")
    End Select
    Resume Exit_label
    ' DD Error Handler End
End Function


'---------------------------------------------------------------------------------------
' PutBBLTemplateFilepath
'---------------------------------------------------------------------------------------
' Public Sub PutBBLTemplateFilepath(ByVal strFileType, ByVal strBBLTemplateFilepath As String)
' strFileType = "Banding", "Recaps", "BandingAUX", "RecapsAUX"
'
' Save the path to the BBL template file
'---------------------------------------------------------------------------------------
 
Public Sub PutBBLTemplateFilepath(ByVal strFileType, ByVal strBBLTemplateFilepath As String)

10    On Error GoTo Err_label

20    Select Case strFileType
      Case "Banding"
30        Call AddEntry("BBLTemplateFilepath_Banding", strBBLTemplateFilepath)
40    Case "Recaps"
50        Call AddEntry("BBLTemplateFilepath_Recaps", strBBLTemplateFilepath)
60    Case "BandingAUX"
70        Call AddEntry("BBLTemplateFilepath_BandingAUX", strBBLTemplateFilepath)
80    Case "RecapsAUX"
90        Call AddEntry("BBLTemplateFilepath_RecapsAUX", strBBLTemplateFilepath)
100   End Select

          'DD Error Handler Start
Exit_label:
110       Exit Sub
Err_label:
120       Select Case Err.Number
          Case Else
130      Call LogError("basUtilityBackEnd", "PutBBLTemplateFilepath")
140       End Select
150       Resume Exit_label
          ' DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' GetBBLTemplateFilepath
'---------------------------------------------------------------------------------------
' Public Function GetBBLTemplateFilepath(ByVal strFileType) As String
' strFileType = "Banding", "Recaps", "BandingAUX", "RecapsAUX"
' Get the path to the BBL template file
' If the stored path is "", return the path to the Documents folder
'---------------------------------------------------------------------------------------
 
Public Function GetBBLTemplateFilepath(ByVal strFileType) As String

On Error GoTo Err_label

Dim strBBLTemplateFilepath As String

Select Case strFileType
Case "Banding"
    strBBLTemplateFilepath = LookupEntry("BBLTemplateFilepath_Banding")
Case "Recaps"
    strBBLTemplateFilepath = LookupEntry("BBLTemplateFilepath_Recaps")
Case "BandingAUX"
    strBBLTemplateFilepath = LookupEntry("BBLTemplateFilepath_BandingAUX")
Case "RecapsAUX"
    strBBLTemplateFilepath = LookupEntry("BBLTemplateFilepath_RecapsAUX")
End Select

If strBBLTemplateFilepath = "" Then
    strBBLTemplateFilepath = Rep_Documents()
End If

GetBBLTemplateFilepath = strBBLTemplateFilepath

    'DD Error Handler Start
Exit_label:
    Exit Function
Err_label:
    Select Case Err.Number
    Case Else
   Call LogError("basUtilityBackEnd", "GetBBLTemplateFilepath")
    End Select
    Resume Exit_label
    ' DD Error Handler End
End Function
