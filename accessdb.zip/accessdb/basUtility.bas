'---------------------------------------------------------------------------------------
' Module    : basUtility
' Author    : David Davey
'---------------------------------------------------------------------------------------

Option Compare Database
Option Explicit


'Declare Function MessageBoxTimeout Lib "user32.dll" Alias "MessageBoxTimeoutA" ( _
'ByVal hwnd As Long, _
'ByVal lpText As String, _
'ByVal lpCaption As String, _
'ByVal uType As Long, _
'ByVal wLanguageID As Long, _
'ByVal lngMilliseconds As Long) As Long
'

#If VBA7 Then
    Public Declare PtrSafe Function MessageBoxTimeout Lib "user32.dll" Alias "MessageBoxTimeoutA" ( _
    ByVal hwnd As LongPtr, _
    ByVal lpText As String, _
    ByVal lpCaption As String, _
    ByVal uType As Long, _
    ByVal wLanguageID As Long, _
    ByVal lngMilliseconds As Long) As Long
#Else
    Public Declare Function MessageBoxTimeout Lib "user32.dll" Alias "MessageBoxTimeoutA" ( _
    ByVal hwnd As Long, _
    ByVal lpText As String, _
    ByVal lpCaption As String, _
    ByVal uType As Long, _
    ByVal wLanguageID As Long, _
    ByVal lngMilliseconds As Long) As Long
#End If


'Private Declare Function FindWindow Lib "USER32" Alias "FindWindowA" ( _
'ByVal lpClassName As String, _
'ByVal lpWindowName As String) As Long




Public Const isDebug As Boolean = True

Public fUnload As Boolean

'---------------------------------------------------------------------------------------
' IntegertoString
'---------------------------------------------------------------------------------------

Public Function IntegertoString(ByVal intInteger As Integer) As String
10       On Error GoTo Err_label

20    Select Case intInteger
      Case 1:
30        IntegertoString = "one"
40    Case 2:
50        IntegertoString = "two"
60    Case 3:
70        IntegertoString = "three"
80    Case 4:
90        IntegertoString = "four"
100   Case 5:
110       IntegertoString = "five"
120   Case 6:
130       IntegertoString = "six"
140   Case 7:
150       IntegertoString = "seven"
160   Case 8:
170       IntegertoString = "eight"
180   Case 9:
190       IntegertoString = "nine"
200   Case 10:
210       IntegertoString = "ten"
220   Case Else:
230       IntegertoString = CStr(intInteger)
240   End Select

          'DD Error Handler Start
Exit_label:
250       Exit Function
Err_label:
260       Select Case Err.Number
          Case Else
270            Call LogError("basUtility", "IntegertoString")
280       End Select
290       Resume Exit_label
          ' DD Error Handler End

End Function

'---------------------------------------------------------------------------------------
' GetWinDeviceName
'---------------------------------------------------------------------------------------
' Function GetWinDeviceName() As String
' Returns the Windoews Device Name of this PC

Public Function GetWinDeviceName() As String
10       On Error GoTo Err_label

20    GetWinDeviceName = VBA.Environ$("computername")

          'DD Error Handler Start
Exit_label:
30        Exit Function
Err_label:
40        Select Case Err.Number
          Case Else
50             Call LogError("basUtility", "GetWinDeviceName")
60        End Select
70        Resume Exit_label
          ' DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' isDavidPC
'
' Returns True if the MBO Database is running on David's PC
'---------------------------------------------------------------------------------------

Public Function isDavidPC() As Boolean

On Error GoTo Err_label

If GetSettingEx("IsDavidPCAlwaysReturnFalse") = "True" Then
    isDavidPC = False
Else
    isDavidPC = (VBA.Environ$("computername") = "PC-DAVID" Or VBA.Environ$("computername") = "DAVID-PC")
End If

    'DD Error Handler Start
Exit_label:
    Exit Function
Err_label:
    Select Case Err.Number
    Case Else
   Call LogError("basUtility", "isDavidPC")
    End Select
    Resume Exit_label
    ' DD Error Handler End
End Function


Sub Environ_Test()
   Debug.Print VBA.Environ$("computername")
End Sub


'---------------------------------------------------------------------------------------
' RefreshTitleBar
'---------------------------------------------------------------------------------------
 
Public Sub MBODataEntryRefreshTitleBar()
10    On Error GoTo Err_label

'      Dim db As Database
'      Dim strVersion As String
'
'20    Set db = CurrentDb
'
'30    strVersion = GetVersion()
'40    db.Properties("AppTitle").value = "MBO Data Entry " & strVersion & _
'          "  (" & CurrentProject.Name & ") " & strSuffix
'50    Application.RefreshTitleBar


      Dim db As Database
20    Set db = CurrentDb
30    db.Properties("AppIcon").value = CurrentProject.path & "\MBO.ico"
      Dim strVersion As String
40    strVersion = GetVersion()
50    db.Properties("AppTitle").value = "MBO Data Entry " & strVersion & _
          "  (" & CurrentProject.Name & ") "
60    db.Properties("UseAppIconForFrmRpt").value = True
70    Application.RefreshTitleBar

'DD Error Handler Start
Exit_label:
80         Exit Sub
Err_label:
90         Select Case Err.Number
     Case Else
100       Call LogError("Form_frmWordExcelInstances", "RefreshTitleBar")
110        End Select
120        Resume Exit_label
'DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' IsLoaded
'---------------------------------------------------------------------------------------
 
Function IsLoaded(ByVal strFormName As String) As Boolean
      ' Returns True if the specified form is open in Form view or Datasheet view.
10    On Error GoTo Err_label

      Dim oAccessObject As AccessObject

20    IsLoaded = False
30    Set oAccessObject = CurrentProject.AllForms(strFormName)
40    If oAccessObject.IsLoaded Then
50        If oAccessObject.CurrentView <> acCurViewDesign Then
60            IsLoaded = True
70        End If
80    End If

      'DD Error Handler Start
Exit_label:
90         Exit Function
Err_label:
100        Select Case Err.Number
           Case Else
110       Call LogError("basUtility", "IsLoaded")
120        End Select
130        Resume Exit_label
      'DD Error Handler End
End Function

' ---------------------------------------------------------------------------
' IsTime(ByVal strTime As String) As Boolean
' ---------------------------------------------------------------------------

Function IsTime(ByVal strTime As String) As Boolean

      Dim datTime As Date
      Dim fResult As Boolean

10    On Error GoTo Err_label

20    Err.Clear

30    On Error Resume Next
40    datTime = strTime
50    If Error.Number = 0 Then
60        fResult = True
70    Else
80        fResult = (Error.Number = 0)
90    End If

100   Err.Clear

110   IsTime = fResult

      'DD Error Handler Start
Exit_label:
120        Exit Function
Err_label:
130        Select Case Err.Number
           Case Else
140       Call LogError("basUtility", "IsTime")
150        End Select
160        Resume Exit_label
      'DD Error Handler End
End Function

' ---------------------------------------------------------------------------
' ConvertCaptureDateAndCaptureYearToVBADate
'
' strCaptureDate    MMDD
' strCaptureYear    YYYY
'
' If MMDDYYYY is not a valid date, return Null
'
' ---------------------------------------------------------------------------

Function ConvertCaptureDateAndCaptureYearToVBADate( _
    ByVal strCaptureDate As String, _
    ByVal strCaptureYear As String) As Variant
    
10    On Error GoTo Err_label

      Dim fValid As Boolean
20    fValid = True

      Dim chr As String

30    If Len(strCaptureDate) <> 4 Or Len(strCaptureYear) <> 4 Then
40        fValid = False
50    Else
          
          Dim i As Integer
60        For i = 1 To 4
70            chr = Mid(strCaptureDate, i, 1)
80            If chr < "0" Or chr > "9" Then
90                fValid = False
100           End If
110       Next i
          
120       For i = 1 To 4
130           chr = Mid(strCaptureYear, i, 1)
140           If chr < "0" Or chr > "9" Then
150               fValid = False
160           End If
170      Next i
180   End If
       
190   If fValid Then
          Dim intYear As Integer
          Dim intMonth As Integer
          Dim intDay As Integer
          Dim datDateSerial As Date
          
200       intYear = CInt(strCaptureYear)
210       intMonth = CInt(Left(strCaptureDate, 2))
220       intDay = CInt(Right(strCaptureDate, 2))

230       If intMonth > 12 Or intDay > 31 Then
240           fValid = False
250       Else
260           datDateSerial = DateSerial(intYear, intMonth, intDay)
270           If Not (Year(datDateSerial) = intYear And _
                  Month(datDateSerial) = intMonth And _
                  Day(datDateSerial) = intDay) Then
280               fValid = False
290           End If
300       End If
310   End If

320   If fValid Then
330       ConvertCaptureDateAndCaptureYearToVBADate = _
              datDateSerial
340   Else
350       ConvertCaptureDateAndCaptureYearToVBADate = Null
360   End If

      'DD Error Handler Start
Exit_label:
370        Exit Function
Err_label:
380        Select Case Err.Number
           Case Else
390       Call LogError("basUtility", "ConvertCaptureDateAndCaptureYearToVBADate")
400        End Select
410        Resume Exit_label
      'DD Error Handler End
End Function

' ---------------------------------------------------------------------------
' ConvertWeightTimeToVBADate
'
' strCaptureTime   HHM
' HH 00 to 23
' M   0 to 5
'
' If HHM is not a valid time, return Null
'
' ---------------------------------------------------------------------------

Function ConvertWeightTimeToVBADate(ByVal strWeightTime As String) As Variant
10    On Error GoTo Err_label

      Dim fValid As Boolean
20    fValid = True

      Dim chr As String
      Dim intWeightTime As Integer

30    If Len(strWeightTime) <> 3 Then
40        fValid = False
50    Else

          Dim strHH As String
          Dim strM As String
          Dim intHH As String
          Dim intM As String
          
60        strHH = Left(strWeightTime, 2)
70        strM = Right(strWeightTime, 1)
80        If Not IsNumeric(strHH) Or Not IsNumeric(strM) Then
90            fValid = False
100       Else
110           intHH = CInt(strHH)
120           intM = CInt(strM)
130           If (intHH < 0 Or intHH > 23) Or (intM < 0 Or intM > 5) Then
140               fValid = False
150           End If
160       End If
170   End If
           
180   If fValid Then
190       ConvertWeightTimeToVBADate = CDate(strHH & ":" & strM & "0")
200   Else
210       ConvertWeightTimeToVBADate = Null
220   End If

      'DD Error Handler Start
Exit_label:
230        Exit Function
Err_label:
240        Select Case Err.Number
           Case Else
250           Call LogError("basUtility", "ConvertWeightTimeToVBADate", strWeightTime)
260        End Select
270        Resume Exit_label
      'DD Error Handler End
End Function

' ---------------------------------------------------------------------------
' ConvertWeightToVBADouble
'
' 9999 => 999.9
'
' If Weight is not between 1 and 9999 return Null
'
' Assumption
' argument has been trimmed
' ---------------------------------------------------------------------------

Function ConvertWeightToVBADouble(ByVal strWeight As String) As Variant
10    On Error GoTo Err_label

20    On Error Resume Next

      Dim fValid As Boolean
      Dim chr As String
      Dim lenWeight As Integer

30    fValid = True
40    lenWeight = Len(strWeight)

50    If lenWeight = 0 Then
60        fValid = False
70    Else
          Dim i As Integer
80        For i = 1 To lenWeight
90            chr = Mid(strWeight, i, 1)
100           If chr < "0" Or chr > "9" Then
110               fValid = False
120           End If
130       Next i
140   End If
       
150   If fValid Then
160       ConvertWeightToVBADouble = CDbl(strWeight) * 0.1
170   Else
180       ConvertWeightToVBADouble = Null
190   End If

      'DD Error Handler Start
Exit_label:
200        Exit Function
Err_label:
210        Select Case Err.Number
           Case Else
220       Call LogError("basUtility", "ConvertWeightToVBADouble")
230        End Select
240        Resume Exit_label
      'DD Error Handler End
End Function

' ---------------------------------------------------------------------------
' ConvertWingChordToVBALong
'
' If WingChord is not an integer between 1 and 999 inclusive, return Null
'
' Assumption
' argument has been trimmed
' ---------------------------------------------------------------------------

Function ConvertWingChordToVBALong(ByVal strWingChord As String) As Variant
10    On Error GoTo Err_label

      Dim fValid As Boolean
      Dim chr As String
      Dim lenWingChord As Integer

20    fValid = True
30    lenWingChord = Len(strWingChord)

40    If lenWingChord = 0 Then
50        fValid = False
60    Else
          Dim i As Integer
70        For i = 1 To lenWingChord
80            chr = Mid(strWingChord, i, 1)
90            If chr < "0" Or chr > "9" Then
100               fValid = False
110           End If
120       Next i
130   End If
       
140   If fValid Then
150       ConvertWingChordToVBALong = CDbl(strWingChord)
160   Else
170       ConvertWingChordToVBALong = Null
180   End If

      'DD Error Handler Start
Exit_label:
190        Exit Function
Err_label:
200        Select Case Err.Number
           Case Else
210       Call LogError("basUtility", "ConvertWingChordToVBALong")
220        End Select
230        Resume Exit_label
      'DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' IsLeapYear
'---------------------------------------------------------------------------------------
 
Public Function isLeapYear(ByVal intYear) As Boolean
10    On Error GoTo Err_label

20        isLeapYear = IsDate("29 Feb " & CStr(intYear))

      'DD Error Handler Start
Exit_label:
30         Exit Function
Err_label:
40         Select Case Err.Number
           Case Else
50              Call LogError("basUtility", "IsLeapYear")
60         End Select
70         Resume Exit_label
      'DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' CloseAllForms
'---------------------------------------------------------------------------------------
 
Public Sub CloseAllForms()
      Dim lngLoop As Long
10    On Error GoTo Err_label

20        For lngLoop = (Forms.count - 1) To 1 Step -1
30            DoCmd.Close acForm, Forms(lngLoop).Name
40        Next lngLoop

      'DD Error Handler Start
Exit_label:
50         Exit Sub
Err_label:
60         Select Case Err.Number
           Case Else
70              Call LogError("basUtility", "CloseAllForms")
80         End Select
90         Resume Exit_label
      'DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' CloseAllReports
'---------------------------------------------------------------------------------------
 
Public Sub CloseAllReports()
      Dim i As Long
10    On Error GoTo Err_label

20    For i = Reports.count - 1 To 0 Step -1
30        DoCmd.Close acReport, Reports(i).Name
40    Next i

      'DD Error Handler Start
Exit_label:
50         Exit Sub
Err_label:
60         Select Case Err.Number
           Case Else
70              Call LogError("basUtility", "CloseAllReports")
80         End Select
90         Resume Exit_label
      'DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' CloseAllFormsExcept_MainMenu_Maintenance_Backup
'---------------------------------------------------------------------------------------
 
Public Sub CloseAllFormsExcept_MainMenu_Maintenance_Backup()
      Dim lngLoop As Long

10    On Error GoTo Err_label

20    For lngLoop = (Forms.count - 1) To 1 Step -1
30        If Forms(lngLoop).Name <> "frmMainmenu" And _
              Forms(lngLoop).Name <> "frmMaintenance" And _
               Forms(lngLoop).Name <> "frmBackup" Then
40            DoCmd.Close acForm, Forms(lngLoop).Name
50        End If
60    Next lngLoop

      'DD Error Handler Start
Exit_label:
70         Exit Sub
Err_label:
80         Select Case Err.Number
           Case Else
90              Call LogError("basUtility", "CloseAllFormsExcept_MainMenu_Maintenance_Backup")
100        End Select
110        Resume Exit_label
      'DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' ConvertDateToEnglishString
'
' 1 = mmm d
' 2 = d mmm yyyy
' 3 = d mmm
' 4 = mmmm d
' 5 = m d
' 6 = d mmm yy

' A zero date returns an empty string
'---------------------------------------------------------------------------------------
 
Public Function ConvertDateToEnglishString( _
    ByVal datDate As Date, _
    ByVal intFormat As Integer) As String
          
10    On Error GoTo Err_label

      Dim strMonthShort As String
      Dim strMonthLong As String
      
20    If datDate = 0 Then
30      ConvertDateToEnglishString = ""
40      GoTo Exit_label
50    End If
      
      
60    Select Case Month(datDate)
      Case 1:
70        strMonthShort = "Jan"
80        strMonthLong = "January"
90    Case 2:
100       strMonthShort = "Feb"
110       strMonthLong = "February"
120   Case 3:
130       strMonthShort = "Mar"
140       strMonthLong = "March"
150   Case 4:
160       strMonthShort = "Apr"
170       strMonthLong = "April"
180   Case 5:
190       strMonthShort = "May"
200       strMonthLong = "May"
210   Case 6:
220       strMonthShort = "Jun"
230       strMonthLong = "June"
240   Case 7:
250       strMonthShort = "Jul"
260       strMonthLong = "July"
270   Case 8:
280       strMonthShort = "Aug"
290       strMonthLong = "August"
300   Case 9:
310       strMonthShort = "Sep"
320       strMonthLong = "September"
330   Case 10:
340       strMonthShort = "Oct"
350       strMonthLong = "October"
360   Case 11:
370       strMonthShort = "Nov"
380       strMonthLong = "November"
390   Case 12:
400       strMonthShort = "Dec"
410       strMonthLong = "December"
420   Case Else
430       strMonthShort = ""
440   End Select

450   If strMonthShort = "" Then
460       ConvertDateToEnglishString = Format(datDate, "yyyy-mm-dd")
470       GoTo Exit_label
480   End If

490   Select Case intFormat
      Case 1: ' mmm d
500       ConvertDateToEnglishString = strMonthShort & " " & Day(datDate)
510   Case 2: ' d mmm yyyy
520       ConvertDateToEnglishString = Day(datDate) & " " & strMonthShort & " " & Year(datDate)
530   Case 3: ' d mmm
540       ConvertDateToEnglishString = Day(datDate) & " " & strMonthShort
550   Case 4: ' mmmm d
560       ConvertDateToEnglishString = strMonthLong & " " & Day(datDate)
570   Case 5: ' m d
580       ConvertDateToEnglishString = Format(datDate, "m-d")
590   Case 6: ' d mmm yy
600       ConvertDateToEnglishString = Day(datDate) & " " & strMonthShort & " " & Right(Year(datDate), 2)
610   Case Else
620       ConvertDateToEnglishString = Format(datDate, "yyyy-mm-dd")
630   End Select

      'DD Error Handler Start
Exit_label:
640        Exit Function
Err_label:
650        Select Case Err.Number
           Case Else
660             Call LogError("basUtility", "ConvertDateToEnglishString")
670        End Select
680        Resume Exit_label
      'DD Error Handler End
              
End Function

'---------------------------------------------------------------------------------------
' FormatNumberEnglish
'---------------------------------------------------------------------------------------
 
Public Function FormatNumberEnglish( _
    ByVal dblNumber As Double, _
    ByVal intDecimals As Integer) As String
          
10    On Error GoTo Err_label
          
      Dim strFormat As String

20    Select Case intDecimals
      Case 0:
30        strFormat = "#0"
40    Case 1:
50        strFormat = "#0.0"
60    Case 2:
70        strFormat = "#0.00"
80    Case Else
90        strFormat = "#Fixed"
100   End Select
110   FormatNumberEnglish = Replace(Format(dblNumber, strFormat), ",", ".")

      'DD Error Handler Start
Exit_label:
120        Exit Function
Err_label:
130        Select Case Err.Number
           Case Else
140             Call LogError("basUtility", "FormatNumberEnglish")
150        End Select
160        Resume Exit_label
      'DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
'addPropertyToForm
'---------------------------------------------------------------------------------------

Function addPropertyToForm( _
    x_propertyName As String, _
    x_value As Variant, _
    x_formName As String) _
As Boolean

10    On Error GoTo Err_label

20    CurrentProject.AllForms(x_formName).Properties(x_propertyName).value = x_value
30    addPropertyToForm = True

      'DD Error Handler Start
Exit_label:
40         Exit Function
Err_label:
50         Select Case Err.Number
           Case 2455
60             CurrentProject.AllForms(x_formName).Properties.Add x_propertyName, Nz(x_value)
70             Resume Next
80         Case Else
90              Call LogError("basUtility", "addPropertyToForm")
100        End Select
110        Resume Exit_label
      'DD Error Handler End

End Function

'---------------------------------------------------------------------------------------
'ZStr
'---------------------------------------------------------------------------------------

Public Function ZStr(ByVal str As String) As String
10    On Error GoTo Err_label

20    On Error GoTo Err_label

30    If str = "" Then
40        ZStr = "Null"
50    Else
60        ZStr = str
70    End If

'DD Error Handler Start
Exit_label:
80         Exit Function
Err_label:
90         Select Case Err.Number
     Case Else
100       Call LogError("basUtility", "ZStr")
110        End Select
120        Resume Exit_label
'DD Error Handler End


End Function

'---------------------------------------------------------------------------------------
'ZLng
'---------------------------------------------------------------------------------------

Public Function ZLng(ByVal lng As Long) As String
10    On Error GoTo Err_label

20    If lng = 0 Then
30        ZLng = "Null"
40    Else
50        ZLng = CStr(lng)
60    End If

      'DD Error Handler Start
Exit_label:
70         Exit Function
Err_label:
80         Select Case Err.Number
           Case Else
90              Call LogError("basUtility", "ZLng")
100        End Select
110        Resume Exit_label
      'DD Error Handler End

End Function

'---------------------------------------------------------------------------------------
'ZDat
'---------------------------------------------------------------------------------------

Public Function ZDat(ByVal dat As Date) As String
10    On Error GoTo Err_label

20    If dat = 0 Then
30        ZDat = "Null"
40    Else
50        ZDat = Format(dat, "d-mmm-yyyy")
60    End If

'DD Error Handler Start
Exit_label:
70         Exit Function
Err_label:
80         Select Case Err.Number
     Case Else
90        Call LogError("basUtility", "ZDat")
100        End Select
110        Resume Exit_label
'DD Error Handler End


End Function

'---------------------------------------------------------------------------------------
' TableExists
'---------------------------------------------------------------------------------------

Public Function TableExists(tableName As String) As Boolean

          ' Presume that table does not exist.
10       On Error GoTo Err_label

20        TableExists = False

          ' Define iterator to query the object model.
          Dim iTable As Integer

          ' Loop through object catalogue and compare with search term.
30        For iTable = 0 To CurrentData.AllTables.count - 1
40            If CurrentData.AllTables(iTable).Name = tableName Then
50                TableExists = True
60                Exit Function
70            End If
80        Next iTable

          'DD Error Handler Start
Exit_label:
90        Exit Function
Err_label:
100       Select Case Err.Number
          Case Else
110            Call LogError("basUtility", "TableExists")
120       End Select
130       Resume Exit_label
          ' DD Error Handler End

End Function

'---------------------------------------------------------------------------------------
' MessageBoxTimer
'---------------------------------------------------------------------------------------

'        Public Enum MessageBoxReturnStatus
'        {
'            OK = 1,
'            Cancel = 2,
'            Abort = 3,
'            Retry = 4,
'            Ignore = 5,
'            Yes = 6,
'            No = 7,
'            TryAgain = 10,
'            Continue = 11
'        }
'
'        Public Enum MessageBoxType
'        {
'            OK = 0,
'            OK_Cancel = 1,
'            Abort_Retry_Ignore = 2,
'            Yes_No_Cancel = 3,
'            Yes_No = 4,
'            Retry_Cancel = 5,
'            Cancel_TryAgain_Continue = 6
'        }


Public Sub MessageBoxTimer(ByVal strMessage As String, ByVal strHeader As String, ByVal intTimeoutInSeconds As Integer)
          Dim retval As Long
          Const intOK = 0
10       On Error GoTo Err_label

20        retval = MessageBoxTimeout(FindWindow(vbNullString, strHeader), strMessage, strHeader, intOK, 0, intTimeoutInSeconds * 1000)

          'DD Error Handler Start
Exit_label:
30        Exit Sub
Err_label:
40        Select Case Err.Number
          Case Else
50             Call LogError("basUtility", "MessageBoxTimer")
60        End Select
70        Resume Exit_label
          ' DD Error Handler End
End Sub

Sub MessageBoxTimer_Test()
    Call MessageBoxTimer("test", "header", 3)
End Sub

'---------------------------------------------------------------------------------------
' getTimeElapsed
'---------------------------------------------------------------------------------------
' Get the number of years, months and days between two dates

Public Sub getTimeElapsed( _
     ByVal datLater As Date, ByVal datEarlier As Date, _
     ByRef intYears As Integer, ByRef intMonths As Integer, ByRef intDays As Integer)
           
      ' PRE: datLater > datEarlier
        
      Dim intYearLater As Integer
      Dim intYearEarlier As Integer
      Dim intMonthLater As Integer
      Dim intMonthEarlier As Integer
      Dim intDayLater As Integer
      Dim intDayEarlier As Integer
           
10    On Error GoTo Err_label

20    intYearLater = Year(datLater)
30    intYearEarlier = Year(datEarlier)
40    intMonthLater = Month(datLater)
50    intMonthEarlier = Month(datEarlier)
60    intDayLater = Day(datLater)
70    intDayEarlier = Day(datEarlier)
           
80    If intMonthLater > intMonthEarlier Then
90        intYears = intYearLater - intYearEarlier
100   ElseIf intMonthLater < intMonthEarlier Then
110       intYears = intYearLater - intYearEarlier - 1
120   Else
130       If intDayLater >= intDayEarlier Then
140           intYears = intYearLater - intYearEarlier
150       Else
160           intYears = intYearLater - intYearEarlier - 1
170       End If
180   End If

190   If intMonthLater > intMonthEarlier Then
200       If intDayLater >= intDayEarlier Then
210           intMonths = intMonthLater - intMonthEarlier
220       Else
230           intMonths = intMonthLater - intMonthEarlier - 1
240       End If
250   ElseIf intMonthLater < intMonthEarlier Then
260       If intDayLater >= intDayEarlier Then
270           intMonths = intMonthLater - intMonthEarlier + 12
280       Else
290           intMonths = intMonthLater - intMonthEarlier + 11
300       End If
310   Else
320       If intDayLater >= intDayEarlier Then
330           intMonths = 0
340       Else
350           intMonths = 11
360       End If
370   End If

380   intDays = datLater - DateSerial( _
    Year(datEarlier) + intYears, _
    Month(datEarlier) + intMonths, _
    Day(datEarlier))
    
'   Debug.Print "getTimeElapsed" & " " & datEarlier & " " & datLater & " " & intYears & " " & intMonths & " " & intDays


'DD Error Handler Start
Exit_label:
390        Exit Sub
Err_label:
400        Select Case Err.Number
     Case Else
410       Call LogError("basMBOAnnualProgramReportTable3_5_Returns", "getTimeElapsed")
420        End Select
430        Resume Exit_label
'DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' strGetTimElapsedInDays
'---------------------------------------------------------------------------------------

Public Function strGetTimElapsedInDays(ByVal datLater As Date, ByVal datEarlier As Date) As String

      Dim intYears As Integer
      Dim intMonths As Integer
      Dim intDays As Integer
      Dim strTimeElapsed As String

10    On Error GoTo Err_label

20    If datLater = 0 Or datEarlier = 0 Then
30        strGetTimElapsedInDays = ""
40    Else
50        Call getTimeElapsed(datLater, datEarlier, intYears, intMonths, intDays)
      '    If intYears = 3 Then
      '        Debug.Print datLater, datEarlier, intYears, intMonths, intDays
      '    End If
          
60        strTimeElapsed = ""
70        If intYears > 0 Then
80            strTimeElapsed = strTimeElapsed & str(intYears) & " year"
90            If intYears > 1 Then
100               strTimeElapsed = strTimeElapsed & "s"
110           End If
120       End If
          
130       If intMonths > 0 Then
140           If strTimeElapsed <> "" Then
150               strTimeElapsed = strTimeElapsed & ", "
160           End If
170           strTimeElapsed = strTimeElapsed & str(intMonths) & " month"
180           If intMonths > 1 Then
190               strTimeElapsed = strTimeElapsed & "s"
200           End If
210       End If
          
220       If intDays > 0 Then
230           If strTimeElapsed <> "" Then
240               strTimeElapsed = strTimeElapsed & ", "
250           End If
260           strTimeElapsed = strTimeElapsed & str(intDays) & " day"
270           If intDays > 1 Then
280               strTimeElapsed = strTimeElapsed & "s"
290           End If
300       End If
          
310       strGetTimElapsedInDays = strTimeElapsed
320   End If

          'DD Error Handler Start
Exit_label:
330       Exit Function
Err_label:
340       Select Case Err.Number
          Case Else
350            Call LogError("basUtility", "strGetTimElapsedInDays")
360       End Select
370       Resume Exit_label
          ' DD Error Handler End

End Function



'---------------------------------------------------------------------------------------
' UnitTest_getTimeElapsed
'---------------------------------------------------------------------------------------
' PRE tblUnitTest_getTimeElapsed exists
'
' This procedure is called from the immediate window
' It is only used for testing the getTimeElapsed procedure

Public Sub UnitTest_getTimeElapsed()

      Dim oExcel As Excel.Application
10    Set oExcel = New Excel.Application


      Dim datEarlier As Date
      Dim datLater   As Date
      Dim intYears   As Integer
      Dim intMonths  As Integer
      Dim intDays    As Integer

20       On Error GoTo Err_label

30    CurrentDb.Execute "DElETE * FROM tblUnitTest_getTimeElapsed"

      Dim rst As DAO.Recordset
40    Set rst = CurrentDb.OpenRecordset("tblUnitTest_getTimeElapsed")

50    For datEarlier = DateSerial(2004, 9, 1) To DateSerial(2005, 1, 1) - 1
60        For datLater = DateSerial(2004, 12, 1) To DateSerial(2005, 4, 1) - 1
70            If datLater - datEarlier > 90 Then
80                rst.AddNew
90                rst("DateEarlier") = datEarlier
100               rst("DateLater") = datLater
110               rst("PeriodInDays") = datLater - datEarlier
120               Call getTimeElapsed(datLater, datEarlier, intYears, intMonths, intDays)
130               rst("YearsEx") = intYears
140               rst("MonthsEx") = intMonths
150               rst("DaysEx") = intDays
                  
160               rst("ExcelMonths") = IIf(Day(datLater) >= Day(datEarlier), 0, -1) + (Year(datLater) - Year(datEarlier)) * 12 + Month(datLater) - Month(datEarlier)
                  
                  
170               rst.Update
180           End If
190       Next
200   Next
210   rst.Close
220   Set rst = Nothing


          'DD Error Handler Start
Exit_label:
230       Exit Sub
Err_label:
240       Select Case Err.Number
          Case Else
250            Call LogError("basMBOAnnualProgramReportTable3_5_Returns", "UnitTest_getTimeElapsed")
260       End Select
270       Resume Exit_label
          ' DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' IsPositiveInteger
'
' Returns True iff the argument is a positive integer
'---------------------------------------------------------------------------------------

Public Function IsPositiveInteger(ByRef varValue As Variant) As Boolean

      Dim dblValue As Double
      Dim intValue As Integer

   On Error GoTo Err_label

10       On Error GoTo Err_label

20    IsPositiveInteger = True

30    If IsNull(varValue) Then
40        IsPositiveInteger = False
50        GoTo Exit_label
60    End If

70    If Not IsNumeric(varValue) Then
80        IsPositiveInteger = False
90        GoTo Exit_label
100   End If

110   dblValue = Nz(varValue)
120   intValue = Int(dblValue)

130   If intValue <> dblValue Then
140       IsPositiveInteger = False
150       GoTo Exit_label
160   End If

170   If intValue <= 0 Then
180       IsPositiveInteger = False
190       GoTo Exit_label
200   End If

    'DD Error Handler Start
Exit_label:
    Exit Function
Err_label:
    Select Case Err.Number
    Case Else
         Call LogError("basUtility", "IsPositiveInteger")
    End Select
    Resume Exit_label
    ' DD Error Handler End
          
End Function

'---------------------------------------------------------------------------------------
' IsNonNegativeInteger
'
' Returns True iff the argument is a non-negative integer
'---------------------------------------------------------------------------------------

Public Function IsNonNegativeInteger(ByRef varValue As Variant) As Boolean

      Dim dblValue As Double
      Dim intValue As Integer

10    On Error GoTo Err_label

20    IsNonNegativeInteger = True

30    If IsNull(varValue) Then
40        IsNonNegativeInteger = False
50        GoTo Exit_label
60    End If

70    If Not IsNumeric(varValue) Then
80        IsNonNegativeInteger = False
90        GoTo Exit_label
100   End If

110   dblValue = Nz(varValue)
120   intValue = Int(dblValue)

130   If intValue <> dblValue Then
140       IsNonNegativeInteger = False
150       GoTo Exit_label
160   End If

170   If intValue < 0 Then
180       IsNonNegativeInteger = False
190       GoTo Exit_label
200   End If

    'DD Error Handler Start
Exit_label:
210       Exit Function
Err_label:
220       Select Case Err.Number
    Case Else
230      Call LogError("basUtility", "IsNonNegativeInteger")
240       End Select
250       Resume Exit_label
    ' DD Error Handler End
          
End Function

'---------------------------------------------------------------------------------------
' DateSerialEx
'
' Same as DateSerial, but the arguments are validated
'---------------------------------------------------------------------------------------

Public Function DateSerialEx(ByVal Year As Integer, ByVal Month As Integer, ByVal Day As Integer) As Variant

10       On Error GoTo Err_label

20        If IsYearMonthDayValid(Year, Month, Day) Then
30            DateSerialEx = DateSerial(Year, Month, Day)
40        Else
50            DateSerialEx = Null
60        End If

          'DD Error Handler Start
Exit_label:
70        Exit Function
Err_label:
80        Select Case Err.Number
          Case Else
90             Call LogError("basUtility", "DateSerialEx")
100       End Select
110       Resume Exit_label
          ' DD Error Handler End
End Function
