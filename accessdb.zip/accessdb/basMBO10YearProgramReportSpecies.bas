'---------------------------------------------------------------------------------------
' Module    : basMBO10YearProgramReportSpecies
' Author    : David Davey
'---------------------------------------------------------------------------------------
' 15 Year report

Option Compare Database
Option Explicit

' getDETDays_SeasonYear(intSeason, intYear) is defined in basMBOProgramReport_SeasonYearPeriod
' --------------------------------------------------------------------------------------------
Const conWinter  As Integer = 0
Const conSpring  As Integer = 1
Const conSummer  As Integer = 2
Const conFall    As Integer = 3

' The following arrays are allocated in Load_CapturePeriods()

Dim ReportPeriodHasCaptures() As Boolean        ' (year, intSeason, period)
Dim ReportSeasonHasCaptures() As Boolean        ' (year, intSeason)
Dim CntReportPeriodsWithCaptures() As Integer   ' (intSeason, period)
Dim CntReportSeasonsWithCaptures() As Integer   ' (intSeason)


' lngSpeciesDETSummary() contains summary statistics for the Word Species DET table
' ---------------------------------------------------------------------------------
Const conSpeciesDETSummaryFirst = 0
Const conFirstTotal = 0
Const conFirstCount = 1
Const conPeakTotal = 2
Const conPeakCount = 3
Const conLastTotal = 4
Const conLastCount = 5
Const conSpanTotal = 6
Const conSpanCount = 7
Const conSpeciesDETDaysTotal = 8
Const conDETDaysTotal = 9
Const conDETDaysCount = 10
Const conHighTotal = 11
Const conHighCount = 12
Const conTotalTotal = 13
Const conTotalCount = 14
Const conSpeciesDETSummaryLast = 14

Const conDET = 0
Const conBND = 1

Const conColourWI = &HEED6BD
Const conColourSP = &HD9EFE2
Const conColourSU = &HACCAF7
Const conColourFA = &H66D9FF
Const conColourZeroDET = &HD9D9D9
Const conColourZeroBND = &HD9D9D9
Const conColourMean = &HE6C4E6


'---------------------------------------------------------------------------------------
' MBO10YearProgramReportSpecies
'---------------------------------------------------------------------------------------

Public Sub MBO10YearProgramReportSpecies( _
    ByVal intYearFirst As Integer, _
    ByVal intYearLast As Integer, _
    ByRef wd As Word.Application, _
    ByRef docSpecies() As Word.Document, _
    Optional ByVal intSpeciesParts As Integer = 2, _
    Optional ByVal intSpeciesNumberFrom = 1, _
    Optional ByVal intSpeciesNumberTo = 1000, _
    Optional ByVal strSpecies As String = "")
          
10    On Error GoTo Err_label

20    Call Load_CapturePeriods(intYearFirst, intYearLast)

      '   For DET statistics

30    Call Load_tbl15YearReport_Species_DET_Temp(intYearFirst, intYearLast)

      '   For Banded statistics

40    Call Load_tbl15YearReport_Species_Banded_Temp(intYearFirst, intYearLast)

50    ReDim docSpecies(1 To intSpeciesParts) As Word.Document

60    ReDim intSpeciesFrom(1 To intSpeciesParts) As Integer
70    ReDim intSpeciesTo(1 To intSpeciesParts) As Integer

80    If strSpecies <> "" Then

      ' Report a single species

90        Set docSpecies(1) = wd.Documents.Add
100       docSpecies(1).SpellingChecked = True
110       Call SetDefaultMargins(docSpecies(1))
120       Call CreateStyles(docSpecies(1))
130       Call MBO10YearProgramReportSpecies_Part( _
            intYearFirst, intYearLast, _
            wd, docSpecies(1), _
            1, 1000, strSpecies)
140   Else

          
          Dim intTotalSpecies As Integer
150       intTotalSpecies = getTotalSpecies()

160       If intTotalSpecies < intSpeciesNumberTo Then
170           intSpeciesNumberTo = intTotalSpecies
180       End If
          
190       If intSpeciesParts = 1 Then

          ' Report all species in the specified range in 1 document

200           Set docSpecies(1) = wd.Documents.Add
210           docSpecies(1).SpellingChecked = True
220           Call SetDefaultMargins(docSpecies(1))
230           Call CreateStyles(docSpecies(1))
240           Call MBO10YearProgramReportSpecies_Part( _
                intYearFirst, intYearLast, _
                wd, docSpecies(1), _
                intSpeciesNumberFrom, intSpeciesNumberTo, strSpecies)
250       Else

              ' Report all species in the specified range in 2 or more documents

              Dim i As Integer
          
260           intSpeciesFrom(1) = intSpeciesNumberFrom
270           For i = 1 To intSpeciesParts - 1
280               intSpeciesTo(i) = intSpeciesFrom(i) + (intSpeciesNumberTo - intSpeciesNumberFrom) / 2
290               intSpeciesFrom(i + 1) = intSpeciesTo(i) + 1
300           Next
310           intSpeciesTo(intSpeciesParts) = intSpeciesNumberTo
       
320           For i = 1 To intSpeciesParts
330               Set docSpecies(i) = wd.Documents.Add
340               docSpecies(i).SpellingChecked = True
350               Call SetDefaultMargins(docSpecies(i))
360               Call CreateStyles(docSpecies(i))
370               Call MBO10YearProgramReportSpecies_Part( _
                    intYearFirst, intYearLast, _
                    wd, docSpecies(i), _
                    intSpeciesFrom(i), intSpeciesTo(i), strSpecies)
380            Next
390       End If
400   End If

          'DD Error Handler Start
Exit_label:
410       Exit Sub
Err_label:
420       Select Case Err.Number
          Case Else
430            Call LogError("basMBO10YearProgramReportSpecies", "MBO10YearProgramReportSpecies")
440       End Select
450       Resume Exit_label
          ' DD Error Handler End
          
End Sub


'---------------------------------------------------------------------------------------
' MBO10YearProgramReportSpecies_Part
'
' There are three tables (but, empty tables are deleted)
'[1] Season DET
'[2] Period DET
'[3] Period BND
'
' Switch to landscape
' Loop over all pseudo-species in  tblMBO10Year_BirdsOfMBO_Abundance_Charts_Temp
'   Write out the Season DET table
'   Write out the Period DET table
'   Write out the Period BND table
' Switch back to portrait
'
' If strSpecies is not "" then only generate the tables for the specified pseudo-species

Private Sub MBO10YearProgramReportSpecies_Part( _
    ByVal intYearFirst As Integer, _
    ByVal intYearLast As Integer, _
    ByRef wd As Word.Application, _
    ByRef doc As Word.Document, _
    Optional ByVal intSpeciesNumberFrom = 1, _
    Optional ByVal intSpeciesNumberTo = 1000, _
    Optional ByVal strSpecies As String = "")

10    On Error GoTo Err_label

      Dim range As Word.range
      Dim lngStart As Long
      Dim lngEnd As Long
       
      ' Switch to landscape

20    Call SetPageOrientation(doc, "Landscape")

30    Set range = MoveInsertionPointToEndOfDocument(wd, doc)

      ' Save and Set the page margins

      Dim sglLeftMargin_Save As Single
      Dim sglRightMargin_Save As Single
      Dim sglTopMargin_Save As Single
      Dim sglBottomMargin_Save As Single

40    With doc.PageSetup
50        sglLeftMargin_Save = .LeftMargin
60        sglRightMargin_Save = .RightMargin
70        sglTopMargin_Save = .TopMargin
80        sglBottomMargin_Save = .BottomMargin
90        .LeftMargin = doc.Application.InchesToPoints(0.5)
100       .RightMargin = doc.Application.InchesToPoints(0.5)
110       .TopMargin = doc.Application.CentimetersToPoints(1.25)
120       .BottomMargin = doc.Application.CentimetersToPoints(1.75)
130   End With

      Dim strSQL As String
      Dim qdf As DAO.QueryDef
      Dim rst As DAO.Recordset


      ' I need a list of all the pseudospecies in tbl15YearReport_Species_DET_Temp or tbl15YearReport_Species_Banded_Temp
      '
      ' qry15YearReportSpecies_DET
      ' ------------------------------------
      ' tbl15YearReport_Species_DET_Temp
      '
      ' Group By Species
      ' Report Species

      ' qry15YearReportSpecies_Banded
      ' ------------------------------------
      ' tbl15YearReport_Species_Banded_Temp
      '
      ' Group By Species
      ' Report Species

      ' qry15YearReportSpecies_DET_or_Banded_Union
      ' ------------------------------------------
      ' qry15YearReportSpecies_DET UNION qry15YearReportSpecies_Banded
      '
      ' Report Species

      ' qry15YearReportSpecies_All
      ' --------------------------
      ' qry15YearReportSpecies_DET_or_Banded_Union x tblSpecies
      '
      ' Order By AOU
      ' SubspeciesEnglish = SpeciesDescriptionMBO
      ' Report Species, SubspeciesEnglish, SpeciesEnglish, SpeciesFrench, SpeciesScientific

      ' qry15YearReportSpecies_Single
      ' -----------------------------
      ' qry15YearReportSpecies_All
      '
      ' [argSpecies] = strSpecies
      ' Report Species, SubspeciesEnglish, SpeciesEnglish, SpeciesFrench, SpeciesScientific

      ' If strSpecies <> "" then report a single pseudo-species
      ' Otherwise report all pseudo-species that are in tbl15YearReport_Species_DET_Temp or tbl15YearReport_Species_Banded_Temp


140       If Len(strSpecies) > 0 Then
150           Set qdf = CurrentDb.QueryDefs("qry15YearReportSpecies_Single")
160           qdf.Parameters("argSpecies") = strSpecies
170           wd.Visible = True
180       Else
190           Set qdf = CurrentDb.QueryDefs("qry15YearReportSpecies_All")
200       End If


210   Set rst = qdf.OpenRecordset

      Dim cntSpecies As Long
      Dim cntTotalSpecies As Long

220   cntSpecies = 1

230   If rst.EOF Then
240       rst.Close
250       Set rst = Nothing
260       GoTo Exit_label
270   End If

280   rst.MoveLast
290   cntTotalSpecies = rst.RecordCount
300   rst.MoveFirst
            
310   Do While Not rst.EOF

320       If cntSpecies < intSpeciesNumberFrom Then
330           cntSpecies = cntSpecies + 1
340           GoTo Next_Species
350       ElseIf cntSpecies > intSpeciesNumberTo Then
360           Exit Do
370       End If

380       strSpecies = Nz(rst("Species"))

390       DoEvents
          
400       SysCmd acSysCmdSetStatus, strSpecies & " " & cntSpecies & " of  " & cntTotalSpecies
410       cntSpecies = cntSpecies + 1
          
          ' Title - appears above a species tables
          
          Dim strSpeciesEnglish As String
          Dim strSpeciesFrench As String
          Dim strSpeciesScientific As String
          
420       strSpeciesEnglish = Nz(rst("SpeciesEnglish"))
430       If strSpeciesEnglish = "" Then
440           strSpeciesEnglish = Nz(rst("SubspeciesEnglish"))
450       End If
460       strSpeciesFrench = Nz(rst("SpeciesFrench"))
470       strSpeciesScientific = Nz(rst("SpeciesScientific"))
          
480       Set range = MoveInsertionPointToEndOfDocument(wd, doc)
490       range.Style = "ddMultiYearSpeciesTitle"
          
500       range.InsertAfter strSpecies & ": " & strSpeciesEnglish & " / " & strSpeciesFrench & " ("
510       lngStart = doc.range.End
520       range.InsertAfter strSpeciesScientific
530       doc.range(lngStart - 1, doc.range.End).Font.Italic = True
540       Set range = doc.Characters.Last
550       range.InsertAfter ")"
560       range.InsertParagraphAfter
570       range.ParagraphFormat.KeepWithNext = True
580       range.ParagraphFormat.SpaceAfter = 3

          Dim strWhere As String

          ' Write the Species Season Word Table if the Total (over all report years, Spring and Fall report season) of the Species-DET > 0

590       strWhere = "[Species] = '" & strSpecies & "' AND Season IN ('Spring', 'Fall')"
600       If DSum("DET", "tbl15YearReport_Species_DET_Temp", strWhere) > 0 Then
610           Set range = MoveInsertionPointToEndOfDocument(wd, doc)
620           Call SpeciesSeasonDET_Table(strSpecies, intYearFirst, intYearLast, wd, doc)
630       End If
          
          ' Write the Species DET Period Word Table if the Total (over all report years, all report seasons) of the Species-DET > 0

640       strWhere = "[Species] = '" & strSpecies & "'"
650       If DSum("DET", "tbl15YearReport_Species_DET_Temp", strWhere) > 0 Then
660           Set range = MoveInsertionPointToEndOfDocument(wd, doc)
670           Call SpeciesPeriodFld_Table("DET", strSpecies, intYearFirst, intYearLast, wd, doc)
680       End If

          ' Write the Species BND Period Word Table if the Total (over all report years, all report seasons) of the Species-BND > 0

690       strWhere = "[Species] = '" & strSpecies & "'"
700       If DSum("Banded", "tbl15YearReport_Species_Banded_Temp", strWhere) > 0 Then
710           Set range = MoveInsertionPointToEndOfDocument(wd, doc)
720           Call SpeciesPeriodFld_Table("BND", strSpecies, intYearFirst, intYearLast, wd, doc)
730       End If
          
          ' Append an empty paragraph
          ' Page break after each species
          
740       Set range = MoveInsertionPointToEndOfDocument(wd, doc)
          
750       range.InsertParagraphAfter
760       range.Style = "ddBase"
          
770       Set range = MoveInsertionPointToEndOfDocument(wd, doc)
780       range.InsertBreak wdPageBreak

Next_Species:
790      rst.MoveNext
          
800   Loop ' Species

810   DoEvents
820   Sleep (10000)
830   DoEvents

840   rst.Close
850   Set rst = Nothing

          'DD Error Handler Start
Exit_label:
860       Exit Sub
Err_label:
870       Select Case Err.Number
          Case Else
880      Call LogError("basMBO10YearProgramReportSpecies", "MBO10YearProgramReportSpecies_Part", "strSpecies = " & strSpecies)
890       End Select
900       Resume Exit_label
          ' DD Error Handler End
    End Sub

'---------------------------------------------------------------------------------------
' getTotalSpecies
'
' Returns the total number of species in tbl15YearReport_Species_DET_Temp
'---------------------------------------------------------------------------------------
' PRE: tbl15YearReport_Species_DET_Temp has been loaded

Public Function getTotalSpecies()

      Dim rst As DAO.Recordset

      ' qryMBO10YearProgramReportSpecies_Species
      ' --------------------------------------------------------------------------------
      ' List of pseudo-species
      ' --------------------------------------------------------------------------------
      ' tbl15YearReport_Species_DET_Temp x tblSpecies
      ' Group By Species
      ' Order By AOUOrder
      ' Report Species, SpeciesEnglish, SpeciesFrench, SpeciesScientific

10    On Error GoTo Err_label

20    Set rst = CurrentDb.OpenRecordset("qryMBO10YearProgramReportSpecies_Species")
30    rst.MoveLast
40    getTotalSpecies = rst.RecordCount
50    rst.Close
60    Set rst = Nothing

          'DD Error Handler Start
Exit_label:
70        Exit Function
Err_label:
80        Select Case Err.Number
          Case Else
90       Call LogError("basMBO10YearProgramReportSpecies", "getCountSpecies")
100       End Select
110       Resume Exit_label
          ' DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' Load_CapturePeriods
'---------------------------------------------------------------------------------------

Private Sub Load_CapturePeriods(ByVal intYearFirst As Integer, ByVal intYearLast As Integer)

10    On Error GoTo Err_label

20    ReDim ReportPeriodHasCaptures(intYearFirst To intYearLast, conWinter To conFall, 1 To 14) As Boolean   ' (year, intSeason, period)
30    ReDim ReportSeasonHasCaptures(intYearFirst To intYearLast, conWinter To conFall) As Boolean            ' (year, intSeason)
40    ReDim CntReportPeriodsWithCaptures(conWinter To conFall, 1 To 14) As Integer                           ' (intSeason, period)
50    ReDim CntReportSeasonsWithCaptures(conWinter To conFall) As Integer                                    ' (intSeason)

      Dim intYear As Integer
      Dim intSeason As Integer
      Dim intPeriod As Integer

60    For intSeason = conWinter To conFall
70        For intPeriod = 1 To 14
80            For intYear = intYearFirst To intYearLast
90                ReportPeriodHasCaptures(intYear, intSeason, intPeriod) = False
100           Next
110           CntReportPeriodsWithCaptures(intSeason, intPeriod) = 0
120       Next
130   Next

140   For intSeason = conWinter To conFall
150       For intYear = intYearFirst To intYearLast
160           ReportSeasonHasCaptures(intYear, intSeason) = False
170       Next
180       CntReportSeasonsWithCaptures(intSeason) = 0
190   Next

      ' qry15YearReport_Species_CapturePeriods_A
      ' ----------------------------------------
      ' Load ReportPeriodHasCaptures
      ' ----------------------------------------
      ' tbl15YearReport_Species_Banded_Temp
      '
      ' GROUP BY Season, YearEx, Period
      ' Captures: SUM Captures
      '
      ' HAVING SUM Captures > 0
      '
      ' SELECT Season, YearEx, Period

      ' = = = = = = = = = =

      ' qry15YearReport_Species_CapturePeriods_B
      ' ----------------------------------------
      ' Load CntReportPeriodsWithCaptures
      ' ----------------------------------------
      ' qry15YearReport_Species_CapturePeriods_A
      '
      ' GROUP BY Season, Period
      '
      ' CntCapturePeriods: IIf([Captures]>0,1,0)
      '
      ' SELECT Season, Period


      ' qry15YearReport_Species_CapturePeriods_C
      ' ----------------------------------------
      ' Load ReportSeasonHasCaptures
      ' ----------------------------------------
      ' tbl15YearReport_Species_Banded_Temp
      '
      ' GROUP BY Season, YearEx
      ' Captures: SUM Captures
      '
      ' HAVING SUM Captures > 0
      '
      ' SELECT Season, YearEx

      ' = = = = = = = = = =

      ' qry15YearReport_Species_CapturePeriods_D
      ' ----------------------------------------
      ' Load CntReportSeasonsWithCaptures
      ' ----------------------------------------
      ' qry15YearReport_Species_CapturePeriods_C
      '
      ' GROUP BY Season
      '
      ' CntCapturePeriods: IIf([Captures]>0,1,0)
      '
      ' SELECT Season

      Dim strSeason As String
      Dim rst As DAO.Recordset

200   Set rst = CurrentDb.OpenRecordset("qry15YearReport_Species_CapturePeriods_A")
210   Do While Not rst.EOF
220       intYear = Nz(rst("YearEx"))
230       strSeason = Nz(rst("Season"))
240       intSeason = toIntSeasonFromStrSeason(strSeason)
250       intPeriod = Nz(rst("Period"))
260       ReportPeriodHasCaptures(intYear, intSeason, intPeriod) = (Nz(rst("Captures")) > 0)
270       rst.MoveNext
280   Loop
290   rst.Close
300   Set rst = Nothing

310   Set rst = CurrentDb.OpenRecordset("qry15YearReport_Species_CapturePeriods_B")
320   Do While Not rst.EOF
330       strSeason = Nz(rst("Season"))
340       intSeason = toIntSeasonFromStrSeason(strSeason)
350       intPeriod = Nz(rst("Period"))
360       CntReportPeriodsWithCaptures(intSeason, intPeriod) = Nz(rst("CntCapturePeriods"))
370       rst.MoveNext
380   Loop
390   rst.Close
400   Set rst = Nothing

410   Set rst = CurrentDb.OpenRecordset("qry15YearReport_Species_CapturePeriods_C")
420   Do While Not rst.EOF
430       intYear = Nz(rst("YearEx"))
440       strSeason = Nz(rst("Season"))
450       intSeason = toIntSeasonFromStrSeason(strSeason)
460       ReportSeasonHasCaptures(intYear, intSeason) = (Nz(rst("Captures")) > 0)
470       rst.MoveNext
480   Loop
490   rst.Close
500   Set rst = Nothing

510   Set rst = CurrentDb.OpenRecordset("qry15YearReport_Species_CapturePeriods_D")
520   Do While Not rst.EOF
530       strSeason = Nz(rst("Season"))
540       intSeason = toIntSeasonFromStrSeason(strSeason)
550       CntReportSeasonsWithCaptures(intSeason) = Nz(rst("CntCapturePeriods"))
560       rst.MoveNext
570   Loop
580   rst.Close
590   Set rst = Nothing

          'DD Error Handler Start
Exit_label:
600       Exit Sub
Err_label:
610       Select Case Err.Number
          Case Else
620            Call LogError("basMBO10YearProgramReportSpecies", "Load_CapturePeriods")
630       End Select
640       Resume Exit_label
          ' DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' Load_tbl15YearReport_Species_DET_Temp
'---------------------------------------------------------------------------------------

Private Sub Load_tbl15YearReport_Species_DET_Temp(ByVal intYearFirst As Integer, ByVal intYearLast As Integer)

10    On Error GoTo Err_label

      Dim qdf As DAO.QueryDef

20    CurrentDb.Execute "DELETE * FROM tbl15YearReport_Species_DET_Temp"

      ' qry15YearReport_Species_DET_Append
      ' ----------------------------------------------------------------
      ' APPEND TO tbl15YearReport_Species_DET_Temp
      ' tblDETSpecies x tblPrograms x tblSpecies
      '
      ' WHERE Location = "MBO"
      ' WHERE YearEx BETWEEN [argYearFirst] AND [argYearLast]
      ' WHERE MonitoringProgramSeason IN ("Winter","Spring","Summer","Fall")
      ' WHERE Species NOT IN ("HYWA","TRFL", "PAWA", "USCA", "LSGO","GSGO","SNGO")
      ' WHERE PseudoSpeciesType <> "Hybrid"
      '
      ' Period: toReportPeriod([MonitoringProgramSeason],[DateEx])
      '
      ' SELECT    MonitoringProgramSeason, YearEx, Period, DateEx, Species, DET
      ' APPEND TO Season,                  YearEx, Period, DateEx, Species, DET


30    Set qdf = CurrentDb.QueryDefs("qry15YearReport_Species_DET_Append")
40    qdf.Parameters("argYearFirst") = intYearFirst
50    qdf.Parameters("argYearLast") = intYearLast
60    qdf.Execute

      ' qry15YearReport_Species_DET_TRFL_Append
      ' ---------------------------------------------------
      ' APPEND TO tbl15YearReport_Species_DET_Temp
      ' tblDETSpecies x tblPrograms
      '
      ' WHERE Location = "MBO"
      ' WHERE YearEx BETWEEN [argYearFirst] AND [argYearLast]
      ' WHERE MonitoringProgramSeason IN ("Winter","Spring","Summer","Fall")
      ' WHERE Species IN ("TRFL","ALFL","WIFL")
      '
      ' Period: toReportPeriod([MonitoringProgramSeason],[DateEx])
      ' SpeciesEx = "TRFL"
      '
      ' GROUP BY MonitoringProgramSeason, YearEx, Period, DateEx, SpeciesEx
      '
      ' SELECT    MonitoringProgramSeason, YearEx, Period, DateEx, SpeciesEx, SUM DET
      ' APPEND TO Season,                  YearEx, Period, DateEx, Species,   DET


70    Set qdf = CurrentDb.QueryDefs("qry15YearReport_Species_DET_TRFL_Append")
80    qdf.Parameters("argYearFirst") = intYearFirst
90    qdf.Parameters("argYearLast") = intYearLast
100   qdf.Execute

      ' qry15YearReport_Species_DET_SNGO_Append
      ' ---------------------------------------------------
      ' APPEND TO tbl15YearReport_Species_DET_Temp
      ' tblDETSpecies x tblPrograms
      '
      ' WHERE Location = "MBO"
      ' WHERE YearEx BETWEEN [argYearFirst] AND [argYearLast]
      ' WHERE MonitoringProgramSeason IN ("Winter","Spring","Summer","Fall")
      ' WHERE Species IN ("LSGO","GSGO","SNGO")
      '
      ' Period: toReportPeriod([MonitoringProgramSeason],[DateEx])
      ' SpeciesEx = "SNGO"
      
      ' GROUP BY MonitoringProgramSeason, YearEx, Period, DateEx, SpeciesEx
      ' DET: SUM DET
      '
      ' SELECT    MonitoringProgramSeason, YearEx, Period, DateEx, SpeciesEx, DET
      ' APPEND TO Season,                  YearEx, Period, DateEx, Species,   DET


110   Set qdf = CurrentDb.QueryDefs("qry15YearReport_Species_DET_SNGO_Append")
120   qdf.Parameters("argYearFirst") = intYearFirst
130   qdf.Parameters("argYearLast") = intYearLast
140   qdf.Execute

    'DD Error Handler Start
Exit_label:
150       Exit Sub
Err_label:
160       Select Case Err.Number
    Case Else
170      Call LogError("basMBO10YearProgramReportSpecies", "Load_tbl15YearReport_Species_DET_Temp")
180       End Select
190       Resume Exit_label
    ' DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' Load_tbl15YearReport_Species_Banded_Temp
'---------------------------------------------------------------------------------------

Private Sub Load_tbl15YearReport_Species_Banded_Temp(ByVal intYearFirst As Integer, ByVal intYearLast As Integer)

10    On Error GoTo Err_label

      Dim qdf As DAO.QueryDef

20    CurrentDb.Execute "DELETE * FROM tbl15YearReport_Species_Banded_Temp"

      ' qry15YearReport_Species_Banded_Append
      ' ----------------------------------------------------------------
      ' APPEND TO tbl15YearReport_Species_Banded_Temp
      ' tblDETSpecies x tblPrograms x tblSpecies
      '
      ' WHERE Location = "MBO"
      ' WHERE YearEx BETWEEN [argYearFirst] AND [argYearLast]
      ' WHERE MonitoringProgramSeason IN ("Winter","Spring","Summer","Fall","Owling","Nestbox","RTHU_Spring","RTHU_Fall")
      ' WHERE Species NOT IN ("HYWA", "TRFL", "PAWA", "USCA", "LSGO","GSGO","SNGO")
      ' WHERE PseudoSpeciesType <> "Hybrid"
      '
      ' Period: toReportPeriod([MonitoringProgramSeason],[DateEx])
      ' Season: toReportSeason([MonitoringProgramSeason],[DateEx])
      ' Captures: Nz([Banded])+Nz([Repeats])+Nz([Returns])+Nz([Observed3])+Nz([Observed4])
      '
      ' SELECT    Season, YearEx, Period, DateEx, Species, Banded, Captures
      ' APPEND TO Season, YearEx, Period, DateEx, Species, Banded, Captures


30    Set qdf = CurrentDb.QueryDefs("qry15YearReport_Species_Banded_Append")
40    qdf.Parameters("argYearFirst") = intYearFirst
50    qdf.Parameters("argYearLast") = intYearLast
60    qdf.Execute

      ' qry15YearReport_Species_Banded_TRFL_Append
      ' ---------------------------------------------------
      ' APPEND TO tbl15YearReport_Species_Banded_Temp
      ' tblDETSpecies x tblPrograms
      '
      ' WHERE Location = "MBO"
      ' WHERE YearEx BETWEEN [argYearFirst] AND [argYearLast]
      ' WHERE MonitoringProgramSeason IN ("Winter","Spring","Summer","Fall","Owling","Nestbox","RTHU_Spring","RTHU_Fa
      ' WHERE Species IN ("TRFL","ALFL","WIFL")
      '
      ' Period: toReportPeriod([MonitoringProgramSeason],[DateEx])
      ' Season: toReportSeason([MonitoringProgramSeason],[DateEx])
      ' Captures: Nz([Banded])+Nz([Repeats])+Nz([Returns])+Nz([Observed3])+Nz([Observed4])
      ' SpeciesEx = "TRFL"
      '
      ' GROUP BY MonitoringProgramSeason, YearEx, Period, DateEx, SpeciesEx
      ' SUM Banded, Captures
      '
      ' SELECT    MonitoringProgramSeason, YearEx, Period, DateEx, SpeciesEx, SUM Banded, SUM Captures
      ' APPEND TO Season,                  YearEx, Period, DateEx, Species,   Bnaded,     Captures


70    Set qdf = CurrentDb.QueryDefs("qry15YearReport_Species_Banded_TRFL_Append")
80    qdf.Parameters("argYearFirst") = intYearFirst
90    qdf.Parameters("argYearLast") = intYearLast
100   qdf.Execute

      ' qry15YearReport_Species_Banded_SNGO_Append
      ' ---------------------------------------------------
      ' APPEND TO tbl15YearReport_Species_Banded_Temp
      ' tblDETSpecies x tblPrograms
      '
      ' WHERE Location = "MBO"
      ' WHERE YearEx BETWEEN [argYearFirst] AND [argYearLast]
      ' WHERE MonitoringProgramSeason IN ("Winter","Spring","Summer","Fall","Owling","Nestbox","RTHU_Spring","RTHU_Fa
      ' WHERE Species IN ("LSGO","GSGO","SNGO")
      '
      ' Period: toReportPeriod([MonitoringProgramSeason],[DateEx])
      ' Season: toReportSeason([MonitoringProgramSeason],[DateEx])
      ' Captures: Nz([Banded])+Nz([Repeats])+Nz([Returns])+Nz([Observed3])+Nz([Observed4])
      ' SpeciesEx = "SNGO"
      
      ' GROUP BY MonitoringProgramSeason, YearEx, Period, DateEx, SpeciesEx
      ' SUM Banded, Captures
      '
      ' SELECT    MonitoringProgramSeason, YearEx, Period, DateEx, SpeciesEx, SUM Banded, SUM Captures
      ' APPEND TO Season,                  YearEx, Period, DateEx, Species,   Banded,     Captures


110   Set qdf = CurrentDb.QueryDefs("qry15YearReport_Species_Banded_SNGO_Append")
120   qdf.Parameters("argYearFirst") = intYearFirst
130   qdf.Parameters("argYearLast") = intYearLast
140   qdf.Execute

    'DD Error Handler Start
Exit_label:
150       Exit Sub
Err_label:
160       Select Case Err.Number
    Case Else
170      Call LogError("basMBO10YearProgramReportSpecies", "Load_tbl15YearReport_Species_Banded_Temp")
180       End Select
190       Resume Exit_label
    ' DD Error Handler End

End Sub
'---------------------------------------------------------------------------------------
' load_tblMBO10YearProgramReportSpecies_from_tbl10Year_BirdsofMBO_Abundance_Charts_Temp
'---------------------------------------------------------------------------------------

'Private Sub load_tblMBO10YearProgramReportSpecies_from_tbl10Year_BirdsofMBO_Abundance_Charts_Temp()
'
'      ' tblMBO10YearProgramReportSpecies
'      ' ----------------------------------------------------------
'      ' Contains the base DETSpecies data for the Species appendix
'      ' ----------------------------------------------------------
'      ' Same as tbl10Year_BirdsofMBO_Abundance_Charts_Temp
'      ' but with only the pseudospecies for the Species Appendix
'      '       Exclude TRFL, PAWA, USCA.  Then TRFL+  renamed to TRFL
'      ' Exclude the SpeciesGroup column
'      '
'      ' YearEx
'      ' Season
'      ' Period
'      ' DateEx
'      ' Species
'      ' Banded
'      ' Returns
'      ' Repeats
'      ' Alien
'      ' Replacement
'      ' DET
'
'10       On Error GoTo Err_label
'
'20    CurrentDb.Execute "DELETE * FROM tblMBO10YearProgramReportSpecies"
'
'      ' qryMBO10Year_Species
'      ' ------------------------------------------
'      ' Same as tblMBO10Year_BirdsOfMBO_Abundance_Charts_Temp
'      ' but with only the pseudospecies for the Species Appendix
'      ' -------------------------------------------------------------------------------------
'      ' tblMBO10Year_BirdsOfMBO_Abundance_Charts_Temp
'      '
'      ' WHERE Species NOT IN ("TRFL","PAWA","USCA")
'      ' SpeciesEx: Species
'
'      ' = = = = = = = = = =
'
'      ' qryMBO10Year_Species_Append
'      ' ------------------------------------------
'      ' qryMBO10Year_Species
'      ' append to
'      ' but with only the pseudospecies for the Species Appendix
'      ' and TRFL+ has been renamed to TRFL
'      ' -------------------------------------------------------------------------------------
'      ' tblMBO10Year_BirdsOfMBO_Abundance_Charts_Temp
'      ' tblMBO10YearProgramReportSpecies
'      '
'      ' Species: iif(SpeciesEx = "TRFL+", "TRFL", SpeciesEx)
'
'      ' = = = = = = = = =
'
'30    CurrentDb.Execute "qryMBO10Year_Species_Append"
'
'          'DD Error Handler Start
'Exit_label:
'40        Exit Sub
'Err_label:
'50        Select Case Err.Number
'          Case Else
'60             Call LogError("basMBO10YearProgramReportSpecies", "load_tblMBO10YearProgramReportSpecies_from_tbl10Year_BirdsofMBO_Abundance_Charts_Temp")
'70        End Select
'80        Resume Exit_label
'          ' DD Error Handler End
'
'End Sub

'---------------------------------------------------------------------------------------
' StatSpeciesYear_Banded
'---------------------------------------------------------------------------------------
' Banded Period Table
' For a given year
' Fill in the year x period cells for each report period
' Fill in the year x seasob cells for each report season

 Private Sub StatSpeciesYear_Banded( _
    ByVal intYearFirst As Integer, ByVal intYearLast As Integer, _
    ByVal strSpecies As String, _
    ByVal intYear As Integer, _
    ByRef table As Word.table)

20    On Error GoTo Err_label

      Dim intNrYears As Integer
30    intNrYears = intYearLast - intYearFirst + 1

      Dim strSQL As String
      Dim qdf As DAO.QueryDef
      Dim rst As DAO.Recordset

      Dim strSeason As String
      Dim intSeason As Integer
      Dim intPeriod As Integer
      Dim dblStat As Double
      Dim intDays As Integer
      Dim dblStatPerDay As Double

      Dim col As Integer
      Dim row As Integer

40    row = intYear - intYearFirst + 2

      Dim dblHighPeriodSpringDET As Double
      Dim dblHighPeriodFallDET As Double
      Dim intPeakPeriodSpringDET As Integer
      Dim intPeakPeriodFallDET As Integer
      Dim dblHighPeriodSpringBanded As Double
      Dim dblHighPeriodFallBanded As Double
      Dim intPeakPeriodSpringBanded As Integer
      Dim intPeakPeriodFallBanded As Integer

50    dblHighPeriodSpringDET = 0
60    dblHighPeriodFallDET = 0
70    dblHighPeriodSpringBanded = 0
80    dblHighPeriodFallBanded = 0

90    With table

          ' Gray out cells with zero Captures

100       For intSeason = conWinter To conFall
110             row = intYear - intYearFirst + 2
120             For intPeriod = 1 To getPeriodLast_intSeason(intSeason)
130                 If Not ReportPeriodHasCaptures(intYear, intSeason, intPeriod) Then
140                   col = toColFromSeasonPeriod(toStrSeasonFromIntSeason(intSeason), intPeriod)
150                   .Cell(row, col).range.Shading.BackgroundPatternColor = conColourZeroBND
160                 End If
170             Next
180       Next

          ' Special case: Prior to the 15-year report gray out Fall period 14

190       If intNrYears <= 10 Then
200           row = intYear - intYearFirst + 2
210           col = toColFromSeasonPeriod("Fall", 14)
220           .Cell(row, col).range.Shading.BackgroundPatternColor = conColourZeroBND
230       End If


          ' qry15YearReport_Species_Banded_Period
          ' --------------------------------------------
          ' tbl15YearReport_Species_Banded_Temp
          '
          ' WHERE YearEx = [argYear]
          ' WHERE Species = [argSpecies]
          
          ' GROUP BY Season, Period
          ' Banded: SUM Banded
          '
          ' SELECT Banded, Period, Season
          
240       strSQL = "qry15YearReport_Species_Banded_Period"
250       Set qdf = CurrentDb.QueryDefs(strSQL)
260       qdf.Parameters("argYear").value = intYear
270       qdf.Parameters("argSpecies").value = strSpecies
280       Set rst = qdf.OpenRecordset
290       Do While Not rst.EOF
          
300           strSeason = Nz(rst("Season"))
310           intSeason = toIntSeasonFromStrSeason(strSeason)
320           intPeriod = Nz(rst("Period"))

330             dblStat = Nz(rst("Banded"))
              
340             Select Case strSeason
                Case "Spring"
350                 If dblStat > dblHighPeriodSpringBanded Then
360                     dblHighPeriodSpringBanded = dblStat
370                     intPeakPeriodSpringBanded = intPeriod
380                 End If
390             Case "Fall"
400                 If dblStat > dblHighPeriodFallBanded Then
410                     dblHighPeriodFallBanded = dblStat
420                     intPeakPeriodFallBanded = intPeriod
430                 End If
440             End Select
              
450             If dblStat <> 0 Then
460                 col = toColFromSeasonPeriod(strSeason, intPeriod)
470                 .Cell(row, col).range.Text = dblStat
480             End If

                
490           rst.MoveNext
500       Loop
510       rst.Close
520       Set rst = Nothing
          
          ' Colour the high period values red
          

530       If dblHighPeriodSpringBanded > 0 Then
540           col = toColFromSeasonPeriod("Spring", intPeakPeriodSpringBanded)
550           .Cell(row, col).range.Font.Color = vbRed
560       End If
          
570       If dblHighPeriodFallBanded > 0 Then
580           col = toColFromSeasonPeriod("Fall", intPeakPeriodFallBanded)
590           .Cell(row, col).range.Font.Color = vbRed
600       End If

          ' ===== Seasons ===================================================
          
          ' Gray out cells with zero Captures

610       For intSeason = conWinter To conFall
620           row = intYear - intYearFirst + 2
630           If Not ReportSeasonHasCaptures(intYear, intSeason) Then
640               col = toColFromSeason(toStrSeasonFromIntSeason(intSeason))
650              .Cell(row, col).range.Shading.BackgroundPatternColor = conColourZeroBND
660            End If
670       Next

          Dim strStatPerDay As String
          Dim strNumberFormat As String
          
          ' qry15YearReport_Species_Banded_Season
          ' --------------------------------------------
          ' tbl15YearReport_Species_Banded_Temp
          '
          ' WHERE YearEx = [argYear]
          ' WHERE Species = [argSpecies]
          '
          ' GROUP BY Season
          ' SUM Banded, DET
          '
          ' SELECT Season, Banded
          
680       strSQL = "qry15YearReport_Species_Banded_Season"
690       Set qdf = CurrentDb.QueryDefs(strSQL)
700       qdf.Parameters("argYear").value = intYear
710       qdf.Parameters("argSpecies").value = strSpecies
720       Set rst = qdf.OpenRecordset
730       Do While Not rst.EOF
740           strSeason = Nz(rst("Season"))
750           intSeason = toIntSeasonFromStrSeason(strSeason)
              
760           dblStat = Nz(rst("Banded"))
770           If dblStat <> 0 Then
780               Select Case strSeason
                  Case "Winter", "Spring", "Summer", "Fall"
790                   col = toColFromSeason(strSeason)
800                   .Cell(row, col).range.Text = dblStat
810               End Select
820           End If

830           rst.MoveNext
840       Loop
850       rst.Close
860       Set rst = Nothing

870   End With

          'DD Error Handler Start
Exit_label:
880       Exit Sub
Err_label:
890       Select Case Err.Number
          Case Else
900      Call LogError("basMBO10YearProgramReportSpecies", "StatSpeciesYear_Banded")
910       End Select
920       Resume Exit_label
          ' DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' StatSpeciesYear
'---------------------------------------------------------------------------------------
' process a single year DET period table

 Private Sub StatSpeciesYear_DET( _
    ByVal intYearFirst As Integer, ByVal intYearLast As Integer, _
    ByVal strSpecies As String, _
    ByVal intYear As Integer, _
    ByRef table As Word.table)

10    On Error GoTo Err_label

      Dim intNrYears As Integer
20    intNrYears = intYearLast - intYearFirst + 1

      Dim strSQL As String
      Dim qdf As DAO.QueryDef
      Dim rst As DAO.Recordset

      Dim strSeason As String
      Dim intSeason As Integer
      Dim intPeriod As Integer
      Dim dblStat As Double
      Dim intDays As Integer
      Dim dblStatPerDay As Double

      Dim col As Integer
      Dim row As Integer

30    row = intYear - intYearFirst + 2

      Dim dblHighPeriodSpringDET As Double
      Dim dblHighPeriodFallDET As Double
      Dim intPeakPeriodSpringDET As Integer
      Dim intPeakPeriodFallDET As Integer

40    dblHighPeriodSpringDET = 0
50    dblHighPeriodFallDET = 0

60    With table

          ' Gray out cells with zero DET-Days or zero Capture-Years

70        For intSeason = conWinter To conFall
80              row = intYear - intYearFirst + 2
90              For intPeriod = 1 To getPeriodLast_intSeason(intSeason)
100                 If getDETDays_SeasonYearPeriod(intSeason, intYear, intPeriod) = 0 Then
110                   col = toColFromSeasonPeriod(toStrSeasonFromIntSeason(intSeason), intPeriod)
120                   .Cell(row, col).range.Shading.BackgroundPatternColor = conColourZeroDET
130                 End If
140             Next
150       Next

          ' Special case: Prior to the 15-year report gray out Fall period 14

160       If intNrYears <= 10 Then

170           row = intYear - intYearFirst + 2
180           col = toColFromSeasonPeriod("Fall", 14)
190           .Cell(row, col).range.Shading.BackgroundPatternColor = conColourZeroDET

200       End If

          ' qry15YearReport_Species_DET_Period
          ' ---------------------------------------------------------
          ' Given a year x species, for each season x period, SUM DET
          ' ---------------------------------------------------------
          ' tbl15YearReport_Species_DET_Temp
          '
          ' WHERE YearEx = [argYear]
          ' WHERE Species = [argSpecies]
          
          ' GROUP BY Season, Period
          ' DET: SUM DET
          '
          ' SELECT DET, Period, Season
          
210       strSQL = "qry15YearReport_Species_DET_Period"
220       Set qdf = CurrentDb.QueryDefs(strSQL)
230       qdf.Parameters("argYear").value = intYear
240       qdf.Parameters("argSpecies").value = strSpecies
250       Set rst = qdf.OpenRecordset
260       Do While Not rst.EOF
          
270           strSeason = Nz(rst("Season"))
280           intSeason = toIntSeasonFromStrSeason(strSeason)
290           intPeriod = Nz(rst("Period"))
                
300           dblStat = Nz(rst("DET"))
310           intDays = getDETDays_SeasonYearPeriod(intSeason, intYear, intPeriod)
320           If intDays <> 0 Then
330               dblStatPerDay = dblStat / intDays
              
340               Select Case strSeason
                  Case "Spring"
350                   If dblStatPerDay > dblHighPeriodSpringDET Then
360                       dblHighPeriodSpringDET = dblStatPerDay
370                       intPeakPeriodSpringDET = intPeriod
380                   End If
390               Case "Fall"
400                   If dblStatPerDay > dblHighPeriodFallDET Then
410                       dblHighPeriodFallDET = dblStatPerDay
420                       intPeakPeriodFallDET = intPeriod
430                   End If
440               End Select
              
450               col = toColFromSeasonPeriod(strSeason, intPeriod)
460               If dblStatPerDay >= 0.1 Then
470                   .Cell(row, col).range.Text = _
                          Replace(Format(dblStatPerDay, "#0.0"), ",", ".")
480               Else
490                   .Cell(row, col).range.Text = _
                          Replace(Format(dblStatPerDay, "#0.00"), ",", ".")
500               End If
510           End If

                
520           rst.MoveNext
530       Loop
540       rst.Close
550       Set rst = Nothing
          
          ' Colour the high period values red
          
560       If dblHighPeriodSpringDET > 0 Then
            
570           col = toColFromSeasonPeriod("Spring", intPeakPeriodSpringDET)
580           .Cell(row, col).range.Font.Color = vbRed
590       End If
600       If dblHighPeriodFallDET > 0 Then
          
610           col = toColFromSeasonPeriod("Fall", intPeakPeriodFallDET)
620           .Cell(row, col).range.Font.Color = vbRed
630       End If
          
          Dim strStatPerDay As String
          Dim strNumberFormat As String
          
          ' qry15YearReport_Species_DET_Season
          ' -----------------------------------------
          ' Given a species, for each season, SUM DET
          ' -----------------------------------------
          ' tbl15YearReport_Species_DET_Temp
          '
          ' WHERE YearEx = [argYear]
          ' WHERE Species = [argSpecies]
          
          ' GROUP BY Season
          ' DET: SUM DET
          '
          ' SELECT DET, Season
          
640       strSQL = "qryMBO10YearProgramReportSpecies_BirdsSeason"
650       Set qdf = CurrentDb.QueryDefs(strSQL)
660       qdf.Parameters("argYear").value = intYear
670       qdf.Parameters("argSpecies").value = strSpecies
680       Set rst = qdf.OpenRecordset
690       Do While Not rst.EOF
700           strSeason = Nz(rst("Season"))
710           intSeason = toIntSeasonFromStrSeason(strSeason)
              
720           dblStat = Nz(rst("DET"))
730           If dblStat <> 0 Then
740               intDays = getDETDays_SeasonYear(intSeason, intYear)
750               If intDays <> 0 Then
760                   dblStatPerDay = dblStat / intDays
770                   If Round(dblStatPerDay, 2) >= 0.1 Then
780                       dblStatPerDay = Round(dblStatPerDay, 1)
790                       strNumberFormat = "#0.00"
800                       strStatPerDay = FormatNumberEnglish(dblStatPerDay, 1)
810                   Else
820                       dblStatPerDay = Round(dblStatPerDay, 2)
830                       strNumberFormat = "#0.000"
840                       strStatPerDay = FormatNumberEnglish(dblStatPerDay, 2)
850                   End If
              
860                   Select Case strSeason
                      Case "Winter", "Spring", "Summer", "Fall"
870                       col = toColFromSeason(strSeason)
880                       .Cell(row, col).range.Text = _
                              strStatPerDay
890                 End Select
              
900               End If
910           End If
          

          
920       rst.MoveNext
930       Loop
940       rst.Close
950       Set rst = Nothing

960   End With


          'DD Error Handler Start
Exit_label:
970       Exit Sub
Err_label:
980       Select Case Err.Number
          Case Else
990      Call LogError("basMBO10YearProgramReportSpecies", "StatSpeciesYear_DET")
1000      End Select
1010      Resume Exit_label
          ' DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' StatSpeciesMean_Banded
'---------------------------------------------------------------------------------------
'
' Banded Period Tablle

' Fill in the row of means (calculated over all years) for each period
' Fill in the row of means (calculated over all years) for each season

Private Sub StatSpeciesMean_Banded( _
    ByVal intYearFirst, _
    ByVal intYearLast, _
    ByVal strSpecies As String, _
    ByRef table As Word.table)

10    On Error GoTo Err_label

      Dim intNrYears As Integer
20    intNrYears = intYearLast - intYearFirst + 1

      Dim strSQL As String
      Dim qdf As DAO.QueryDef
      Dim rst As DAO.Recordset

      Dim strSeason As String
      Dim intSeason As Integer
      Dim intPeriod As Integer
      Dim dblStat As Double
      Dim intDays As Integer
      Dim dblStatPerDay As Double
      Dim intYears As Integer

      Dim col As Integer
      Dim row As Integer

30    row = intNrYears + 2

      Dim dblHighPeriodSpringDET As Double
      Dim dblHighPeriodFallDET As Double
      Dim intPeakPeriodSpringDET As Integer
      Dim intPeakPeriodFallDET As Integer
      Dim dblHighPeriodSpringBanded As Double
      Dim dblHighPeriodFallBanded As Double
      Dim intPeakPeriodSpringBanded As Integer
      Dim intPeakPeriodFallBanded As Integer

40    dblHighPeriodSpringDET = 0
50    dblHighPeriodFallDET = 0
60    dblHighPeriodSpringBanded = 0
70    dblHighPeriodFallBanded = 0

      Dim strStatPerDay As String
      Dim strStat       As String
      Dim strNumberFormat As String

80    With table


          ' qry15YearReport_Species_Banded_Period_Summary
          ' --------------------------------------------
          ' For each Season
          '       Banded: # Birds
          ' --------------------------------------------
          ' tbl15YearReport_Species_DET_Temp
          '
          ' Group By Season, Period
          ' WHERE Species = [argSpecies]
          ' Banded = Sum Banded
          
90        strSQL = "qry15YearReport_Species_Banded_Period_Summary"
100       Set qdf = CurrentDb.QueryDefs(strSQL)
110       qdf.Parameters("argSpecies").value = strSpecies
          
120       Set rst = qdf.OpenRecordset
130       Do While Not rst.EOF
          
140           strSeason = Nz(rst("Season"))
150           intSeason = toIntSeasonFromStrSeason(strSeason)
160           intPeriod = Nz(rst("Period"))
          
170           dblStat = Nz(rst("Banded"))
180           intYears = CntReportPeriodsWithCaptures(intSeason, intPeriod)
190           If intYears <> 0 And dblStat > 0 Then
200               dblStat = dblStat / intYears

210               Select Case strSeason
                  Case "Spring"
220                   If dblStat > dblHighPeriodSpringBanded Then
230                       dblHighPeriodSpringBanded = dblStat
240                       intPeakPeriodSpringBanded = intPeriod
250                   End If
260               Case "Fall"
270                   If dblStat > dblHighPeriodFallBanded Then
280                       dblHighPeriodFallBanded = dblStat
290                       intPeakPeriodFallBanded = intPeriod
300                   End If
310               End Select

320               If Round(dblStat, 2) >= 0.1 Then
330                   strStat = FormatNumberEnglish(dblStat, 1)
340                   strNumberFormat = "#0.0"
350               Else
360                   strStat = FormatNumberEnglish(dblStat, 2)
370                   strNumberFormat = "#0.00"
380               End If

390               col = toColFromSeasonPeriod(strSeason, intPeriod)
400              .Cell(row, col).range.Text = strStat

410           End If
          
420           rst.MoveNext
430       Loop
440       rst.Close
450       Set rst = Nothing
          
460       If dblHighPeriodSpringBanded > 0 Then
470           col = toColFromSeasonPeriod("Spring", intPeakPeriodSpringBanded)
480          .Cell(row, col).range.Font.Color = vbRed
490       End If
          
500       If dblHighPeriodFallBanded > 0 Then
510           col = toColFromSeasonPeriod("Fall", intPeakPeriodFallBanded)
520          .Cell(row, col).range.Font.Color = vbRed
530       End If

          ' Summary column for each season
          
          ' qry15YearReport_Species_Banded_Season_Summary
          ' ----------------------------------------------------
          ' tbl15YearReport_Species_Banded_Temp
          '
          ' Species = [argSpecies]
          ' Group By Season, YearEx
          ' DET = Sum DET
          ' Banded = Sum Banded
          
540       strSQL = "qry15YearReport_Species_Banded_Season_Summary"
550       Set qdf = CurrentDb.QueryDefs(strSQL)
560       qdf.Parameters("argSpecies").value = strSpecies
570       Set rst = qdf.OpenRecordset
580       Do While Not rst.EOF
590           strSeason = Nz(rst("Season"))
600           intSeason = toIntSeasonFromStrSeason(strSeason)

610           dblStat = Nz(rst("Banded"))
620           If dblStat <> 0 Then
630               intYears = CntReportSeasonsWithCaptures(intSeason)
640               If intYears <> 0 Then
650                   dblStat = dblStat / intYears
660                   If Round(dblStat, 2) >= 0.1 Then
670                       strStat = FormatNumberEnglish(Round(dblStat, 1), 1)
680                       strNumberFormat = "#0.00"
690                   Else
700                       strStat = FormatNumberEnglish(Round(dblStat, 2), 2)
710                       strNumberFormat = "#0.000"
720                   End If

730                   Select Case strSeason
                      Case "Winter", "Spring", "Summer", "Fall"
740                       col = toColFromSeason(strSeason)
750                      .Cell(row, col).range.Text = strStat
760                   End Select
770               End If
780           End If

790           rst.MoveNext
800       Loop
810       rst.Close
820       Set rst = Nothing

          ' Special case: Prior to the 15-year report gray out Fall period 14

830       If intNrYears <= 10 Then

840           col = toColFromSeasonPeriod("Fall", 14)
850           .Cell(row, col).range.Shading.BackgroundPatternColor = conColourZeroBND

860       End If

870   End With

          'DD Error Handler Start
Exit_label:
880       Exit Sub
Err_label:
890       Select Case Err.Number
          Case Else
900      Call LogError("basMBO10YearProgramReportSpecies", "StatSpeciesMean_Banded")
910       End Select
920       Resume Exit_label
          ' DD Error Handler End
    End Sub

'---------------------------------------------------------------------------------------
' StatSpeciesMean_DET
'---------------------------------------------------------------------------------------
'
' DET Period table
' The  row of means
' Fill in the  means (calculated over all years) for each report period
' Fill in the  means (calculated over all years) for each report season

Private Sub StatSpeciesMean_DET( _
    ByVal intYearFirst As Integer, ByVal intYearLast As Integer, _
    ByVal strSpecies As String, _
    ByRef table As Word.table)

10    On Error GoTo Err_label

      Dim intNrYears As Integer
20    intNrYears = intYearLast - intYearFirst + 1

      Dim strSQL As String
      Dim qdf As DAO.QueryDef
      Dim rst As DAO.Recordset

      Dim strSeason As String
      Dim intSeason As Integer
      Dim intPeriod As Integer
      Dim dblStat As Double
      Dim intDays As Integer
      Dim dblStatPerDay As Double
      Dim intYears As Integer

      Dim col As Integer
      Dim row As Integer

30    row = intNrYears + 2

      Dim dblHighPeriodSpringDET As Double
      Dim dblHighPeriodFallDET As Double
      Dim intPeakPeriodSpringDET As Integer
      Dim intPeakPeriodFallDET As Integer
      Dim dblHighPeriodSpringBanded As Double
      Dim dblHighPeriodFallBanded As Double
      Dim intPeakPeriodSpringBanded As Integer
      Dim intPeakPeriodFallBanded As Integer

40    dblHighPeriodSpringDET = 0
50    dblHighPeriodFallDET = 0
60    dblHighPeriodSpringBanded = 0
70    dblHighPeriodFallBanded = 0

      Dim strStatPerDay As String
      Dim strStat       As String

80    With table

          ' qry15YearReport_Species_DET_Period_Summary
          ' --------------------------------------------
          ' For each Season
          '       DET: # Birds / # DET-Days
          '       Banded: # Birds
          ' --------------------------------------------
          ' tbl15YearReport_Species_DET_Temp
          '
          ' Group By Season, Period
          ' DET = Sum DET
          
90        strSQL = "qry15YearReport_Species_DET_Period_Summary"
100       Set qdf = CurrentDb.QueryDefs(strSQL)
110       qdf.Parameters("argSpecies").value = strSpecies
          
120       Set rst = qdf.OpenRecordset
130       Do While Not rst.EOF
          
140           strSeason = Nz(rst("Season"))
150           intSeason = toIntSeasonFromStrSeason(strSeason)
160           intPeriod = Nz(rst("Period"))
          

170           dblStat = Nz(rst("DET"))
180           intDays = getDETDays_SeasonPeriod(intSeason, intPeriod)
190           If intDays <> 0 And dblStat > 0 Then
200               dblStatPerDay = dblStat / intDays

210               Select Case strSeason
                  Case "Spring"
220                   If dblStatPerDay > dblHighPeriodSpringDET Then
230                       dblHighPeriodSpringDET = dblStatPerDay
240                       intPeakPeriodSpringDET = intPeriod
250                   End If
260               Case "Fall"
270                   If dblStatPerDay > dblHighPeriodFallDET Then
280                       dblHighPeriodFallDET = dblStatPerDay
290                       intPeakPeriodFallDET = intPeriod
300                   End If
310               End Select

                  Dim strNumberFormat As String

320               If Round(dblStatPerDay, 2) >= 0.1 Then
330                   strStatPerDay = FormatNumberEnglish(dblStatPerDay, 1)
340                       strNumberFormat = "#0.0"
350               Else
360                   strStatPerDay = FormatNumberEnglish(dblStatPerDay, 2)
370                       strNumberFormat = "#0.00"
380               End If


390               col = toColFromSeasonPeriod(strSeason, intPeriod)
400              .Cell(row, col).range.Text = _
                    strStatPerDay
          
410               End If

          
420           rst.MoveNext
430       Loop
440       rst.Close
450       Set rst = Nothing
          

460       If dblHighPeriodSpringDET > 0 Then

470           col = toColFromSeasonPeriod("Spring", intPeakPeriodSpringDET)
480          .Cell(row, col).range.Font.Color = vbRed
490       End If
500       If dblHighPeriodFallDET > 0 Then

510           col = toColFromSeasonPeriod("Fall", intPeakPeriodFallDET)
520          .Cell(row, col).range.Font.Color = vbRed
530       End If

          ' Summary column for each season
          
          ' qry15YearReport_Species_DET_Season_Summary
          ' ----------------------------------------------------
          ' tbl15YearReport_Species_DET_Temp
          '
          ' Species = [argSpecies]
          ' Group By Season, YearEx
          ' DET = Sum DET
          
540       strSQL = "qry15YearReport_Species_DET_Season_Summary"
550       Set qdf = CurrentDb.QueryDefs(strSQL)
560       qdf.Parameters("argSpecies").value = strSpecies
570       Set rst = qdf.OpenRecordset
580       Do While Not rst.EOF
590           strSeason = Nz(rst("Season"))
600           intSeason = toIntSeasonFromStrSeason(strSeason)

610           dblStat = Nz(rst("DET"))
620           If dblStat <> 0 Then
630               intDays = getDETDays_Season(intSeason)
640               If intDays <> 0 Then
650                   dblStatPerDay = dblStat / intDays
660                   If Round(dblStatPerDay, 2) >= 0.1 Then
670                       strStatPerDay = FormatNumberEnglish(Round(dblStatPerDay, 1), 1)
680                       strNumberFormat = "#0.00"
690                   ElseIf Round(dblStatPerDay, 3) >= 0.01 Then
700                       strStatPerDay = FormatNumberEnglish(Round(dblStatPerDay, 2), 2)
710                       strNumberFormat = "#0.000"
720                   Else
730                       strStatPerDay = "<0.005"
740                       strNumberFormat = "#0.0000"
750                   End If
760               End If

770               Select Case strSeason
                  Case "Winter", "Spring", "Summer", "Fall"
780                   col = toColFromSeason(strSeason)
790                  .Cell(row, col).range.Text = _
                          strStatPerDay
800                 End Select
810           End If

          
820           rst.MoveNext
830       Loop
840       rst.Close
850       Set rst = Nothing

          ' Special case: Prior to the 15-year report gray out Fall period 14

860       If intNrYears <= 10 Then

870           col = toColFromSeasonPeriod("Fall", 14)
880           .Cell(row, col).range.Shading.BackgroundPatternColor = conColourZeroDET

890       End If

900   End With

          'DD Error Handler Start
Exit_label:
910       Exit Sub
Err_label:
920       Select Case Err.Number
          Case Else
930            Call LogError("basMBO10YearProgramReportSpecies", "StatSpeciesMean_DET")
940       End Select
950       Resume Exit_label
          ' DD Error Handler End
    End Sub

'------------------------------------------------------------------------------------------------------------
' SpeciesPeriodFld_Table
'
' If strFld = "DET", then generate the DET Period table
' If strFld = "BND", then generate the BND Period table
'-------------------------------------------------------------------------------------------------------------
' Called twice from MBO10YearProgramReportSeason - once for strFld = "DET", the fecond time for strFld = "BND"

Private Sub SpeciesPeriodFld_Table(ByVal strFLD As String, ByVal strSpecies As String, _
    ByVal intYearFirst As Integer, ByVal intYearLast As Integer, _
    ByRef wd As Word.Application, ByRef doc As Word.Document)
          
10    On Error GoTo Err_label

      Dim row As Integer
      Dim col As Integer

      Dim dblLeftPadding As Double    ' in cm
      Dim dblRightPadding As Double
      Dim dblTopPadding As Double
      Dim dblBottomPadding As Double
      Dim intNumColumns As Integer

20    dblLeftPadding = 0
30    dblRightPadding = 0
40    dblTopPadding = 0
50    dblBottomPadding = 0

      Dim dblWidthColumn1 As Double
      Dim dblWidthSeasonWinter As Double
      Dim dblWidthSeasonSpring As Double
      Dim dblWidthSeasonSummer As Double
      Dim dblWidthSeasonFall As Double
      Dim dblWidthPeriodWinterSpring As Double
      Dim dblWidthPeriodSummerFall As Double

      Dim dblWidthColumn As Double
      Dim dblWidthColumnSeason As Double

60    dblWidthColumn1 = 0.99
70    dblWidthColumnSeason = 0.75
80    dblWidthColumn = (25.4 - dblWidthColumn1 - 4 * dblWidthColumnSeason) / 31

      Dim range As Word.range
90    Set range = MoveInsertionPointToEndOfDocument(wd, doc)

      Dim table As Word.table

      Dim intNrYears As Integer
100   intNrYears = intYearLast - intYearFirst + 1

110   intNumColumns = 36

120   doc.Tables.Add range:=range, NumRows:=2 + intNrYears, NumColumns:=intNumColumns
130   range.Expand (wdTable)

140   Set table = range.Tables(1)
150   With table

160       .Borders.InsideLineStyle = wdLineStyleSingle
170       .Borders.OutsideLineStyle = wdLineStyleSingle
180       .Borders.OutsideLineWidth = wdLineWidth150pt

190       .LeftPadding = doc.Application.CentimetersToPoints(dblLeftPadding)
200       .RightPadding = doc.Application.CentimetersToPoints(dblRightPadding)
210       .TopPadding = doc.Application.CentimetersToPoints(dblBottomPadding)
220       .BottomPadding = doc.Application.CentimetersToPoints(dblBottomPadding)

          ' Center the table

230       .Rows.Alignment = wdAlignRowCenter

240       .columns(1).Width = doc.Application.CentimetersToPoints(dblWidthColumn1)

250       Select Case strFLD
          Case "DET"
260           .Cell(1, 1).range.Text = "OBS"
270       Case "BND"
280           .Cell(1, 1).range.Text = "BAND"
290       End Select

          ' cols
          ' -----------------------------------------------------
          ' 2 to 6   Winter periods
          ' 7        Winter season
          ' 8 to 17  Spring periods
          ' 18       Spring season
          ' 19 to 20 Summer periods
          ' 21       Summer season
          ' 22 to 35 Fall periods
          ' 36       Fall season


300       For col = 2 To 36
310           .columns(col).Width = doc.Application.CentimetersToPoints(dblWidthColumn)
320       Next
330       .columns(7).Width = doc.Application.CentimetersToPoints(dblWidthColumnSeason)
340       .columns(18).Width = doc.Application.CentimetersToPoints(dblWidthColumnSeason)
350       .columns(21).Width = doc.Application.CentimetersToPoints(dblWidthColumnSeason)
360       .columns(36).Width = doc.Application.CentimetersToPoints(dblWidthColumnSeason)

370       .Cell(1, 2).range.Text = "Nov"
380       .Cell(1, 3).range.Text = "Dec"
390       .Cell(1, 4).range.Text = "Jan"
400       .Cell(1, 5).range.Text = "Feb"
410       .Cell(1, 6).range.Text = "Mar"
420       .Cell(1, 7).range.Text = "WI"
430       .Cell(1, 8).range.Text = "S1"
440       .Cell(1, 9).range.Text = "S2"
450       .Cell(1, 10).range.Text = "S3"
460       .Cell(1, 11).range.Text = "S4"
470       .Cell(1, 12).range.Text = "S5"
480       .Cell(1, 13).range.Text = "S6"
490       .Cell(1, 14).range.Text = "S7"
500       .Cell(1, 15).range.Text = "S8"
510       .Cell(1, 16).range.Text = "S9"
520       .Cell(1, 17).range.Text = "S10"
530       .Cell(1, 18).range.Text = "SP"
540       .Cell(1, 19).range.Text = "Jun"
550       .Cell(1, 20).range.Text = "Jul"
560       .Cell(1, 21).range.Text = "SU"
570       .Cell(1, 22).range.Text = "F1"
580       .Cell(1, 23).range.Text = "F2"
590       .Cell(1, 24).range.Text = "F3"
600       .Cell(1, 25).range.Text = "F4"
610       .Cell(1, 26).range.Text = "F5"
620       .Cell(1, 27).range.Text = "F6"
630       .Cell(1, 28).range.Text = "F7"
640       .Cell(1, 29).range.Text = "F8"
650       .Cell(1, 30).range.Text = "F9"
660       .Cell(1, 31).range.Text = "F10"
670       .Cell(1, 32).range.Text = "F11"
680       .Cell(1, 33).range.Text = "F12"
690       .Cell(1, 34).range.Text = "F13"
700       .Cell(1, 35).range.Text = "F14"
710       .Cell(1, 36).range.Text = "FA"

720       For col = 2 To 7
730           .Cell(1, col).Shading.BackgroundPatternColor = conColourWI
740       Next
750       For col = 8 To 18
760           .Cell(1, col).Shading.BackgroundPatternColor = conColourSP
770       Next
780       For col = 19 To 21
790           .Cell(1, col).Shading.BackgroundPatternColor = conColourSU
800       Next
810       For col = 22 To 36
820           .Cell(1, col).Shading.BackgroundPatternColor = conColourFA
830       Next
          
840       For row = 2 To 2 + intNrYears
850           .Cell(row, 7).Shading.BackgroundPatternColor = conColourWI
860           .Cell(row, 18).Shading.BackgroundPatternColor = conColourSP
870           .Cell(row, 21).Shading.BackgroundPatternColor = conColourSU
880           .Cell(row, 36).Shading.BackgroundPatternColor = conColourFA
890       Next


900       For col = 1 To 6
910           .Cell(2 + intNrYears, col).Shading.BackgroundPatternColor = conColourMean
920       Next
930       For col = 8 To 17
940           .Cell(2 + intNrYears, col).Shading.BackgroundPatternColor = conColourMean
950       Next
960       For col = 19 To 20
970           .Cell(2 + intNrYears, col).Shading.BackgroundPatternColor = conColourMean
980       Next
990       For col = 22 To 35
1000          .Cell(2 + intNrYears, col).Shading.BackgroundPatternColor = conColourMean
1010      Next

1020      For row = 1 To 2 + 2 * intNrYears
1030          .Cell(row, 1).Borders(wdBorderRight).LineWidth = wdLineWidth150pt
1040          .Cell(row, 6).Borders(wdBorderRight).LineWidth = wdLineWidth150pt
1050          .Cell(row, 7).Borders(wdBorderRight).LineWidth = wdLineWidth150pt
1060          .Cell(row, 17).Borders(wdBorderRight).LineWidth = wdLineWidth150pt
1070          .Cell(row, 18).Borders(wdBorderRight).LineWidth = wdLineWidth150pt
1080          .Cell(row, 20).Borders(wdBorderRight).LineWidth = wdLineWidth150pt
1090          .Cell(row, 21).Borders(wdBorderRight).LineWidth = wdLineWidth150pt
1100          .Cell(row, 35).Borders(wdBorderRight).LineWidth = wdLineWidth150pt
1110     Next
1120     .Rows(1).Borders(wdBorderBottom).LineWidth = wdLineWidth150pt
                             
          Dim i As Integer
1130      For i = 1 To intNrYears
1140          .Cell(i + 1, 1).range.Text = intYearFirst + i - 1
1150      Next
1160      .Cell(2 + intNrYears, 1).range.Text = "Mean"
          
1170      range.Style = "ddMultiYearSpecies_Period_Detail"
1180      .Rows(1).range.Style = "ddMultiYearSpecies_Period_Heading"
1190      For row = 1 To 2 + intNrYears
1200          .Cell(row, 1).range.Style = "ddMultiYearSpecies_Period_Label"
1210      Next

          ' Repeat heading row at the top of subsequent pages

1220      .Rows.WrapAroundText = False

1230  End With

      ' Fill table with info.

      Dim intFld As Integer
1240  intFld = IIf(strFLD = "DET", conDET, conBND)

      Dim intYear As Integer

1250  For intYear = intYearFirst To intYearLast
1260      If intFld = conDET Then
1270           Call StatSpeciesYear_DET(intYearFirst, intYearLast, strSpecies, intYear, table)
1280      Else
1290          Call StatSpeciesYear_Banded(intYearFirst, intYearLast, strSpecies, intYear, table)
1300      End If
1310  Next

1320  If intFld = conDET Then
1330      Call StatSpeciesMean_DET(intYearFirst, intYearLast, strSpecies, table)
1340  Else
1350      Call StatSpeciesMean_Banded(intYearFirst, intYearLast, strSpecies, table)
1360  End If

      ' Space after each table

1370  Set range = MoveInsertionPointToEndOfDocument(wd, doc)
1380  range.InsertParagraphAfter
1390  range.Style = "ddMultiYearSpeciesTableAfter"
1400  Set range = MoveInsertionPointToEndOfDocument(wd, doc)

          'DD Error Handler Start
Exit_label:
1410      Exit Sub
Err_label:
1420      Select Case Err.Number
          Case Else
1430     Call LogError("basMBO10YearProgramReportSpecies", "SpeciesPeriodFld_Table", "strFLD = " & strFLD & " strSpecies = " & strSpecies)
1440      End Select
1450      Resume Exit_label
          ' DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' SpeciesSeasonDET_Table
'---------------------------------------------------------------------------------------
'
' intNrYears = intYearLast-intYearFirst+1            15 for the 15-year report
'
' Create the species season DET table
'   9 rows
'   3 + 2 * intNrYears colums

' col
' -----------------------------------------------------------------------
'   1                                   statistic's name
'   2 to 1+intNrYears                   year within spring
'   2+intNrYears                        AVG for spring
'   3+intNrYears to 2 + 2 * intNrYears  year within fall
'   3 + 2 * intNrYears                  AVG for fall


Private Sub SpeciesSeasonDET_Table(ByVal strSpecies As String, _
    ByVal intYearFirst As Integer, ByVal intYearLast As Integer, _
    ByRef wd As Word.Application, ByRef doc As Word.Document)

10    On Error GoTo Err_label

      Dim col As Integer

      Dim dblLeftPadding As Double    ' in cm
      Dim dblRightPadding As Double
      Dim dblTopPadding As Double
      Dim dblBottomPadding As Double

20    dblLeftPadding = 0.05
30    dblRightPadding = 0.05
40    dblTopPadding = 0
50    dblBottomPadding = 0

      Dim dblWidthColumn1 As Double
      Dim dblWidthPeriodSpring As Double
      Dim dblWidthSeasonSpring As Double
      Dim dblWidthPeriodFall As Double
      Dim dblWidthSeasonFall As Double
      Dim dblWidthColumn As Double

      Dim intNrYears As Integer
      Dim row As Long

60    intNrYears = intYearLast - intYearFirst + 1

70    If intNrYears = 15 Then
80        dblWidthColumn1 = 1.08
90        dblWidthColumn = (25.4 - dblWidthColumn1) / 32
          
100       dblWidthPeriodSpring = dblWidthColumn
110       dblWidthSeasonSpring = dblWidthColumn
120       dblWidthPeriodFall = dblWidthColumn
130       dblWidthSeasonFall = dblWidthColumn
140   Else
150       dblWidthColumn1 = 0.99
160       dblWidthColumn = 0.76
170       dblWidthPeriodSpring = dblWidthColumn
180       dblWidthSeasonSpring = dblWidthColumn
190       dblWidthPeriodFall = dblWidthColumn
200       dblWidthSeasonFall = dblWidthColumn
210   End If

      Dim range As Word.range
220   Set range = MoveInsertionPointToEndOfDocument(wd, doc)

      ' To add multiple tables in Word: after adding a table, move the cursor to the end of the document and type a paragraph return

      ' Add a table with 9 rows and (3 + 2 * intNrYears) columns at the end of the document

230   doc.Tables.Add range:=range, NumRows:=9, NumColumns:=3 + 2 * intNrYears
240   range.Expand (wdTable)

      Dim table As Word.table
250   Set table = range.Tables(1)

260   With table

270       .Borders.InsideLineStyle = wdLineStyleSingle
280       .Borders.OutsideLineStyle = wdLineStyleSingle
290       .Borders.OutsideLineWidth = wdLineWidth150pt

300       For row = 1 To 9
310           .Cell(row, 1).Borders(wdBorderRight).LineWidth = wdLineWidth150pt
320           .Cell(row, 2 + intNrYears).Borders(wdBorderRight).LineWidth = wdLineWidth150pt
330       Next
340      .Rows(1).Borders(wdBorderBottom).LineWidth = wdLineWidth150pt

350       .LeftPadding = doc.Application.CentimetersToPoints(dblLeftPadding)
360       .RightPadding = doc.Application.CentimetersToPoints(dblRightPadding)
370       .TopPadding = doc.Application.CentimetersToPoints(dblBottomPadding)
380       .BottomPadding = doc.Application.CentimetersToPoints(dblBottomPadding)

          ' Center the table

390       .Rows.Alignment = wdAlignRowCenter

          ' Column widths
          
400       .columns(1).Width = doc.Application.CentimetersToPoints(dblWidthColumn1)
410       For col = 2 To 1 + intNrYears
420           .columns(col).Width = doc.Application.CentimetersToPoints(dblWidthPeriodSpring)
430       Next
440       .columns(2 + intNrYears).Width = doc.Application.CentimetersToPoints(dblWidthSeasonSpring)
450       For col = 3 + intNrYears To 2 + 2 * intNrYears
460           .columns(col).Width = doc.Application.CentimetersToPoints(dblWidthPeriodFall)
470       Next
480       .columns(3 + 2 * intNrYears).Width = doc.Application.CentimetersToPoints(dblWidthSeasonFall)

          ' Column headings

          Dim intYear As Integer

490       If intYearLast - intYearFirst + 1 >= 1 Then
500           For intYear = intYearFirst To intYearLast
510               col = 2 + intYear - intYearFirst
520               .Cell(1, col).range.Text = intYear
530               col = 3 + intNrYears + intYear - intYearFirst
540               .Cell(1, col).range.Text = intYear
550           Next
560           .Cell(1, 2 + intNrYears).range.Text = "AVG"
570           .Cell(1, 3 + 2 * intNrYears).range.Text = "AVG"
580       End If

          ' Row labels

590       .Cell(2, 1).range.Text = "First"
600       .Cell(3, 1).range.Text = "Peak"
610       .Cell(4, 1).range.Text = "Last"
620       .Cell(5, 1).range.Text = "Span"
630       .Cell(6, 1).range.Text = "# days"
640       .Cell(7, 1).range.Text = "% days"
650       .Cell(8, 1).range.Text = "High"
660       .Cell(9, 1).range.Text = "Total"

          ' Column background colours

670       For col = 2 To 2 + intNrYears
680           .Cell(1, col).Shading.BackgroundPatternColor = conColourSP
690       Next
700       For col = 3 + intNrYears To 3 + 2 * intNrYears
710           .Cell(1, col).Shading.BackgroundPatternColor = conColourFA
720       Next

730       For row = 2 To 9
740           .Cell(row, 2 + intNrYears).Shading.BackgroundPatternColor = conColourMean
750           .Cell(row, 3 + 2 * intNrYears).Shading.BackgroundPatternColor = conColourMean
760       Next

770       range.Style = "ddMultiYearSpecies_SpeciesDET_Detail"
780       .Rows(1).range.Style = "ddMultiYearSpecies_SpeciesDET_Heading"
790       For row = 2 To 9
800         .Cell(row, 1).range.Style = "ddMultiYearSpecies_SpeciesDET_Label"
810         .Cell(row, 2 + intNrYears).range.Style = "ddMultiYearSpecies_SpeciesDET_Summary"
820         .Cell(row, 3 + 2 * intNrYears).range.Style = "ddMultiYearSpecies_SpeciesDET_Summary"
830       Next

          ' Repeat heading row at the top of subsequent pages

840       .Rows.WrapAroundText = False

850   End With

      Dim lngSpeciesDETSummary(conSpeciesDETSummaryFirst To conSpeciesDETSummaryLast) As Long
      Dim i

      ' Fill in the detail and summary data for Spring


860   For i = conSpeciesDETSummaryFirst To conSpeciesDETSummaryLast
870       lngSpeciesDETSummary(i) = 0
880   Next

890   For intYear = intYearFirst To intYearLast
900       Call SpeciesSeason_DET_Season_Detail(intYearFirst, intYearLast, strSpecies, "Spring", intYear, range, lngSpeciesDETSummary)
910   Next

920   Call SpeciesSeason_DET_Season_Average(intYearFirst, intYearLast, "Spring", range, lngSpeciesDETSummary)

      ' Fill in the detail and summary data for Fall

930   For i = conSpeciesDETSummaryFirst To conSpeciesDETSummaryLast
940       lngSpeciesDETSummary(i) = 0
950   Next
960   For intYear = intYearFirst To intYearLast
970       Call SpeciesSeason_DET_Season_Detail(intYearFirst, intYearLast, strSpecies, "Fall", intYear, range, lngSpeciesDETSummary)
980   Next

990   Call SpeciesSeason_DET_Season_Average(intYearFirst, intYearLast, "Fall", range, lngSpeciesDETSummary)

      ' Move the cursor to the end of the document and type a paragraph return

1000  Set range = MoveInsertionPointToEndOfDocument(wd, doc)
1010  range.InsertParagraphAfter
1020  range.Style = "ddMultiYearSpeciesTableAfter"
1030  Set range = MoveInsertionPointToEndOfDocument(wd, doc)


          'DD Error Handler Start
Exit_label:
1040      Exit Sub
Err_label:
1050      Select Case Err.Number
          Case Else
1060           Call LogError("basMBO10YearProgramReportSpecies", "SpeciesSeasonDET_Table")
1070      End Select
1080      Resume Exit_label
          ' DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' SpeciesSeason_DET_Season_Detail
'---------------------------------------------------------------------------------------
' Season table - process a species x year x season
'
' In the 15-year report, the Word range contains one table. Its rows are statistics and its columns are years (or seasons)
'
' col                                                           col in 15-year report
' -----------------------------------------------------------------------------------
'   1                                   statistic's name
'   2 to 1+intNrYears                   year within spring      2 to 16
'   2+intNrYears                        AVG for spring          17
'   3+intNrYears to 2 + 2 * intNrYears  year within fall        18 to 32
'   3 + 2 * intNrYears                  AVG for fall            33
'
' The logic for getting the row and col for a season x year x statistic cell is factored into a sub
' so it should be easy to change to using  multiple tables bgw transpose the table
' I will have to redesign the table(s) though.


Private Sub SpeciesSeason_DET_Season_Detail( _
   ByVal intYearFirst As Integer, intYearLast As Integer, _
   ByVal strSpecies As String, _
   ByVal strSeason As String, _
   ByVal intYear As Integer, _
   ByRef range As Word.range, _
   ByRef lngSpeciesDETSummary() As Long)

20    On Error GoTo Err_label

      Dim strSQL As String
      Dim qdf As DAO.QueryDef
      Dim rst As DAO.Recordset
      Dim intTable As Integer

      Dim datFirstBird As Date
      Dim datLastBird As Date
      Dim lngHigh As Long
      Dim lngCountBirds As Long
      Dim lngCountDays As Long
      Dim datPeak As Date
      Dim rstPeak As DAO.Recordset

      Dim row As Long
      Dim col As Long

30    intTable = 1

      ' qryMBO10YearProgramReportSpecies_FirstLastDET
      ' ---------------------------------------------
      ' tbl15YearReport_Species_DET_Temp
      '
      ' WHERE YearEx = [argYear]
      ' WHERE Species = [argSpecies]
      ' WHERE DET > 0
      ' GROUP BY Season
      ' FirstBird = Min DateEx
      ' LastBird = Max DateEx
      ' CountBirds = Sum DET
      ' High = Max DET
      ' CountDays = Count records
      '
      ' SELECT Season, CountDays, CountBirds, FirstBird, LastBird, High

      ' qryMBO10YearProgramReportSpecies_FirstLastDET_Season
      ' ----------------------------------------------------
      ' qryMBO10YearProgramReportSpecies_FirstLastDET
      '
      ' WHERE Season = [argSeason]
      '
      ' SELECT Season, CountDays, CountBirds, FirstBird, LastBird, High


40    strSQL = "qryMBO10YearProgramReportSpecies_FirstLastDET_Season"

50    Set qdf = CurrentDb.QueryDefs(strSQL)
60    qdf.Parameters("argYear").value = intYear
70    qdf.Parameters("argSpecies").value = strSpecies
80    qdf.Parameters("argSeason").value = strSeason
90    Set rst = qdf.OpenRecordset
100   Do While Not rst.EOF

110        datFirstBird = Nz(rst("FirstBird"))
120        datLastBird = Nz(rst("LastBird"))
130        lngHigh = Nz(rst("High"))
140        lngCountBirds = Nz(rst("CountBirds"))
150        lngCountDays = Nz(rst("CountDays"))

160       If datFirstBird <> 0 Then
170           datFirstBird = DateSerial(2000, Month(datFirstBird), Day(datFirstBird))
180           Call getTableSeasonDET_Detail_RowCol(intYearFirst, intYearLast, strSeason, intYear, "First", row, col)
190           range.Tables(intTable).Cell(row, col).range.Text = _
                ConvertDateToEnglishString(datFirstBird, 5)
                
200           lngSpeciesDETSummary(conFirstTotal) = lngSpeciesDETSummary(conFirstTotal) + CLng(datFirstBird)
210           lngSpeciesDETSummary(conFirstCount) = lngSpeciesDETSummary(conFirstCount) + 1
220       End If
          
230       If datLastBird <> 0 Then
240           datLastBird = DateSerial(2000, Month(datLastBird), Day(datLastBird))
250           Call getTableSeasonDET_Detail_RowCol(intYearFirst, intYearLast, strSeason, intYear, "Last", row, col)
260           range.Tables(intTable).Cell(row, col).range.Text = _
                ConvertDateToEnglishString(datLastBird, 5)

270           lngSpeciesDETSummary(conLastTotal) = lngSpeciesDETSummary(conLastTotal) + CLng(datLastBird)
280           lngSpeciesDETSummary(conLastCount) = lngSpeciesDETSummary(conLastCount) + 1

290       End If
          
300       If datFirstBird <> 0 And datLastBird <> 0 Then
310             Call getTableSeasonDET_Detail_RowCol(intYearFirst, intYearLast, strSeason, intYear, "Span", row, col)
320             range.Tables(intTable).Cell(row, col).range.Text = _
                    datLastBird - datFirstBird + 1
                
330             lngSpeciesDETSummary(conSpanTotal) = lngSpeciesDETSummary(conSpanTotal) + (datLastBird - datFirstBird + 1)
340             lngSpeciesDETSummary(conSpanCount) = lngSpeciesDETSummary(conSpanCount) + 1
                
350       End If
          
360       If lngHigh > 0 Then
370           Call getTableSeasonDET_Detail_RowCol(intYearFirst, intYearLast, strSeason, intYear, "High", row, col)
380           range.Tables(intTable).Cell(row, col).range.Text = lngHigh
              
390           lngSpeciesDETSummary(conHighTotal) = lngSpeciesDETSummary(conHighTotal) + lngHigh
400           lngSpeciesDETSummary(conHighCount) = lngSpeciesDETSummary(conHighCount) + 1
410       End If
          
420       If lngCountBirds > 0 Then
430           Call getTableSeasonDET_Detail_RowCol(intYearFirst, intYearLast, strSeason, intYear, "Total", row, col)
440           range.Tables(intTable).Cell(row, col).range.Text = lngCountBirds
              
450           lngSpeciesDETSummary(conTotalTotal) = lngSpeciesDETSummary(conTotalTotal) + lngCountBirds
460           lngSpeciesDETSummary(conTotalCount) = lngSpeciesDETSummary(conTotalCount) + 1
470       End If
          
          Dim intDETDays As Integer
          
480       intDETDays = getDETDays_SeasonYear(IIf(strSeason = "Spring", conSpring, conFall), intYear)
          
490       If lngCountDays > 0 Then
500           Call getTableSeasonDET_Detail_RowCol(intYearFirst, intYearLast, strSeason, intYear, "NrDays", row, col)
510           range.Tables(intTable).Cell(row, col).range.Text = lngCountDays
520           Call getTableSeasonDET_Detail_RowCol(intYearFirst, intYearLast, strSeason, intYear, "PercentDays", row, col)
530           range.Tables(intTable).Cell(row, col).range.Text = Round(100# * lngCountDays / intDETDays, 0)
              
              ' lngSpeciesDETDaysTotal = the total number of days, summed over all years, for which this species DET > 0
              ' lngDETDaysTotal = the total number of DET days (i.e. any species DET > 0) summed over all years
              ' lngDETDaysCount = the number of years for which this species DET > 0

540           lngSpeciesDETSummary(conSpeciesDETDaysTotal) = lngSpeciesDETSummary(conSpeciesDETDaysTotal) + lngCountDays
550           lngSpeciesDETSummary(conDETDaysTotal) = lngSpeciesDETSummary(conDETDaysTotal) + intDETDays
560           lngSpeciesDETSummary(conDETDaysCount) = lngSpeciesDETSummary(conDETDaysCount) + 1
570       End If


          ' qryMBO10YearProgramReportSpecies_Peak
          ' ------------------------------------------------------------------
          ' For a given Season, Year, Species
          '   Determine the Peak Day (when the first High DET occurred)
          ' ------------------------------------------------------------------
          ' tbl15YearReport_Species_DET_Temp
          '
          ' WHERE Season = [argSeason]
          ' WHERE YearEx = [argYear]
          ' WHERE Species = [argSpecies]
          ' WHERE DET = [argDET]
          ' SORT BY DateEx
          '
          ' SELECT Season, DateEx, DET

610       strSQL = "qryMBO10YearProgramReportSpecies_Peak"
620       Set qdf = CurrentDb.QueryDefs(strSQL)
630       qdf.Parameters("argYearEx").value = intYear
640       qdf.Parameters("argSpecies").value = strSpecies
650       qdf.Parameters("argDET").value = lngHigh
660       qdf.Parameters("argSeason").value = strSeason
670       Set rstPeak = qdf.OpenRecordset

680       If Not rstPeak.EOF Then
690           datPeak = Nz(rstPeak("DateEx"))
700           If datPeak > 0 Then
710               datPeak = DateSerial(2000, Month(datPeak), Day(datPeak))
720               Call getTableSeasonDET_Detail_RowCol(intYearFirst, intYearLast, strSeason, intYear, "Peak", row, col)
730               range.Tables(intTable).Cell(row, col).range.Text = _
                    ConvertDateToEnglishString(datPeak, 5)
740               lngSpeciesDETSummary(conPeakTotal) = lngSpeciesDETSummary(conPeakTotal) + CLng(datPeak)
750               lngSpeciesDETSummary(conPeakCount) = lngSpeciesDETSummary(conPeakCount) + 1
760           End If
770       End If
780       rstPeak.Close

790       rst.MoveNext
800   Loop
810   rst.Close
820   Set rst = Nothing

          'DD Error Handler Start
Exit_label:
830       Exit Sub
Err_label:
840       Select Case Err.Number
          Case Else
850      Call LogError("basMBO10YearProgramReportSpecies", "SpeciesSeason_DET_Season_Detail")
860       End Select
870       Resume Exit_label
          ' DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' SpeciesSeason_DET_Season_Average
'---------------------------------------------------------------------------------------

Private Sub SpeciesSeason_DET_Season_Average(ByVal intYearFirst As Integer, ByVal intYearLast As Integer, _
    ByVal strSeason As String, ByRef range As Word.range, ByRef lngSpeciesDETSummary() As Long)

      Dim intTable As Integer
      Dim row As Long
      Dim col As Long

10       On Error GoTo Err_label

20    intTable = 1

30    If lngSpeciesDETSummary(conFirstCount) > 0 Then
40    Call getTableSeasonDET_Average_RowCol(intYearFirst, intYearLast, strSeason, "First", row, col)
50        range.Tables(intTable).Cell(row, col).range.Text = _
              ConvertDateToEnglishString(CDate(lngSpeciesDETSummary(conFirstTotal) / lngSpeciesDETSummary(conFirstCount)), 5)
60    End If

70    If lngSpeciesDETSummary(conPeakCount) > 0 Then
80    Call getTableSeasonDET_Average_RowCol(intYearFirst, intYearLast, strSeason, "Peak", row, col)
90        range.Tables(intTable).Cell(row, col).range.Text = _
              ConvertDateToEnglishString(CDate(lngSpeciesDETSummary(conPeakTotal) / lngSpeciesDETSummary(conPeakCount)), 5)
100   End If

110   If lngSpeciesDETSummary(conLastCount) > 0 Then
120       Call getTableSeasonDET_Average_RowCol(intYearFirst, intYearLast, strSeason, "Last", row, col)
130       range.Tables(intTable).Cell(row, col).range.Text = _
              ConvertDateToEnglishString(CDate(lngSpeciesDETSummary(conLastTotal) / lngSpeciesDETSummary(conLastCount)), 5)
140   End If

150   If lngSpeciesDETSummary(conSpanCount) > 0 Then
160       Call getTableSeasonDET_Average_RowCol(intYearFirst, intYearLast, strSeason, "Span", row, col)
170       range.Tables(intTable).Cell(row, col).range.Text = _
              Round(lngSpeciesDETSummary(conSpanTotal) / lngSpeciesDETSummary(conSpanCount), 0)
180   End If

190   If lngSpeciesDETSummary(conDETDaysCount) > 0 Then
200       Call getTableSeasonDET_Average_RowCol(intYearFirst, intYearLast, strSeason, "NrDays", row, col)
210       range.Tables(intTable).Cell(row, col).range.Text = _
              Round(lngSpeciesDETSummary(conSpeciesDETDaysTotal) / lngSpeciesDETSummary(conDETDaysCount), 0)
220   End If

230   If lngSpeciesDETSummary(conDETDaysTotal) > 0 Then
240       Call getTableSeasonDET_Average_RowCol(intYearFirst, intYearLast, strSeason, "PercentDays", row, col)
250       range.Tables(intTable).Cell(row, col).range.Text = _
              Round(100 * lngSpeciesDETSummary(conSpeciesDETDaysTotal) / lngSpeciesDETSummary(conDETDaysTotal), 0)
260   End If

270   If lngSpeciesDETSummary(conHighCount) > 0 Then
280       Call getTableSeasonDET_Average_RowCol(intYearFirst, intYearLast, strSeason, "High", row, col)
290       range.Tables(intTable).Cell(row, col).range.Text = _
              Round(lngSpeciesDETSummary(conHighTotal) / lngSpeciesDETSummary(conHighCount), 0)
300   End If
          
      Dim intDETDays As Integer
      Dim intDETYears As Integer
      Dim intYear As Integer

310   For intYear = intYearFirst To intYearLast
320       intDETDays = getDETDays_SeasonYear(IIf(strSeason = "Spring", conSpring, conFall), intYear)
330       If intDETDays > 0 Then
340           intDETYears = intDETYears + 1
350       End If
360   Next

370   Call getTableSeasonDET_Average_RowCol(intYearFirst, intYearLast, strSeason, "Total", row, col)
380   range.Tables(intTable).Cell(row, col).range.Text = _
          Round(lngSpeciesDETSummary(conTotalTotal) / intDETYears, 0)

          'DD Error Handler Start
Exit_label:
390       Exit Sub
Err_label:
400       Select Case Err.Number
          Case Else
410            Call LogError("basMBO10YearProgramReportSpecies", "SpeciesSeason_DET_Season_Average")
420       End Select
430       Resume Exit_label
          ' DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' getTableSeasonDET_Detail_RowCol
'---------------------------------------------------------------------------------------

Private Sub getTableSeasonDET_Detail_RowCol(ByVal intYearFirst As Integer, ByVal intYearLast As Integer, _
    ByVal strSeason As String, ByVal intYear As Integer, ByVal strTableSeasonDETStat As String, _
    ByRef row As Long, ByRef col As Long)
          
      '
      ' col                                                           col in 15-year report
      ' -----------------------------------------------------------------------------------
      '   1                                   statistic's name
      '   2 to 1+intNrYears                   year within spring      2 to 16
      '   2+intNrYears                        AVG for spring          17
      '   3+intNrYears to 2 + 2 * intNrYears  year within fall        18 to 32
      '   3 + 2 * intNrYears                  AVG for fall            33
          
      ' strTableSeasonDETStat "First", "Peak", "Last", "Span", "NrDays", "PercentDays", "High", "Total"

      Dim intNrYears As Integer
10       On Error GoTo Err_label

20    intNrYears = intYearLast - intYearFirst + 1

      Dim colSeasonOffset As Long
30    colSeasonOffset = IIf(strSeason = "Spring", 2, 3 + intNrYears)

40    Select Case strTableSeasonDETStat
      Case "First"
50        row = 2
60    Case "Peak"
70        row = 3
80    Case "Last"
90        row = 4
100   Case "Span"
110       row = 5
120   Case "NrDays"
130       row = 6
140   Case "PercentDays"
150       row = 7
160   Case "High"
170       row = 8
180   Case "Total"
190       row = 9
200   End Select

210   col = colSeasonOffset + (intYear - intYearFirst)

          'DD Error Handler Start
Exit_label:
220       Exit Sub
Err_label:
230       Select Case Err.Number
          Case Else
240            Call LogError("basMBO10YearProgramReportSpecies", "getTableSeasonDET_Detail_RowCol")
250       End Select
260       Resume Exit_label
          ' DD Error Handler End
          
End Sub

Private Sub getTableSeasonDET_Average_RowCol(ByVal intYearFirst As Integer, ByVal intYearLast As Integer, _
    ByVal strSeason As String, ByVal strTableSeasonDETStat As String, _
    ByRef row As Long, ByRef col As Long)
          
      '
      ' col                                                           col in 15-year report
      ' -----------------------------------------------------------------------------------
      '   1                                   statistic's name
      '   2 to 1+intNrYears                   year within spring      2 to 16
      '   2+intNrYears                        AVG for spring          17
      '   3+intNrYears to 2 + 2 * intNrYears  year within fall        18 to 32
      '   3 + 2 * intNrYears                  AVG for fall            33
          
      ' strTableSeasonDETStat "First", "Peak", "Last", "Span", "NrDays", "PercentDays", "High", "Total"

      Dim intNrYears As Integer
10    intNrYears = intYearLast - intYearFirst + 1

20    Select Case strTableSeasonDETStat
      Case "First"
30        row = 2
40    Case "Peak"
50        row = 3
60    Case "Last"
70        row = 4
80    Case "Span"
90        row = 5
100   Case "NrDays"
110       row = 6
120   Case "PercentDays"
130       row = 7
140   Case "High"
150       row = 8
160   Case "Total"
170       row = 9
180   End Select

190   col = IIf(strSeason = "Spring", 2 + intNrYears, 3 + 2 * intNrYears)
          
End Sub

'---------------------------------------------------------------------------------------
' toColFromSeason
'---------------------------------------------------------------------------------------

Private Function toColFromSeason(ByVal strSeason As String) As Integer
   On Error GoTo Err_label

70    Select Case strSeason
      Case "Winter"
80        toColFromSeason = 7
90    Case "Spring"
100       toColFromSeason = 18
110   Case "Summer"
120       toColFromSeason = 21
140   Case "Fall"
150       toColFromSeason = 36
170   End Select

    'DD Error Handler Start
Exit_label:
    Exit Function
Err_label:
    Select Case Err.Number
    Case Else
         Call LogError("basMBO10YearProgramReportSpecies", "toColFromSeason")
    End Select
    Resume Exit_label
    ' DD Error Handler End
End Function

' cols
' -----------------------------------------------------
' 2 to 6   Winter periods
' 7        Winter season
' 8 to 17  Spring periods
' 18       Spring season
' 19 to 20 Summer periods
' 21       Summer season
' 22 to 35 Fall periods
' 36       Fall season

Private Function toColFromSeasonPeriod(ByVal strSeason As String, ByVal intPeriod As Integer) As Integer

10    On Error GoTo Err_label

70    Select Case strSeason
      Case "Winter"
80        toColFromSeasonPeriod = 1 + intPeriod
90    Case "Spring"
100       toColFromSeasonPeriod = 7 + intPeriod
110   Case "Summer"
120       toColFromSeasonPeriod = 18 + intPeriod
140   Case "Fall"
150       toColFromSeasonPeriod = 21 + intPeriod
170   End Select


    'DD Error Handler Start
Exit_label:
    Exit Function
Err_label:
    Select Case Err.Number
    Case Else
         Call LogError("basMBO10YearProgramReportSpecies", "toColFromSeasonPeriod")
    End Select
    Resume Exit_label
    ' DD Error Handler End

End Function

''---------------------------------------------------------------------------------------
'' toRelativeReportPeriod
''---------------------------------------------------------------------------------------
'' This works for both MP Seasons and Report Seasons
''
'' Returns the period relative to the Report Season
'' Winter: 1 = Nov, ...
'' Spring: 1 to 10
'' Summer: 1 = JUN, 2 = JUL
'' Fall: 1 to 14
'
'Public Function toRelativeReportPeriod(ByVal strSeason As String, datDateEx As Date) As Integer
'
'   On Error GoTo Err_label
'
'20    On Error GoTo Err_label
'
'      Dim datDay   As Date
'      Dim toPeriod As String
'      Dim intWeek As Integer
'
'30    datDay = DateSerial(2000, Month(datDateEx), Day(datDateEx))
'
'40    Select Case strSeason
'      Case "Winter"
'50        Select Case Month(datDateEx)
'          Case 1
'60            toPeriod = 3
'70        Case 2
'80            toPeriod = 4
'90        Case 3 To 6
'100           toPeriod = 5
'110       Case 7 To 11
'120           toPeriod = 1
'130       Case 12
'140           toPeriod = 2
'150       End Select
'160   Case "Spring", "RTHU_Spring"
'170       intWeek = Int((datDay - DateSerial(2000, 3, 28)) / 7) + 1
'180       If intWeek < 1 Or intWeek > 10 Then
'190           toPeriod = -1
'200       Else
'210           toPeriod = intWeek
'220       End If
'230   Case "Summer", "Nestbox"
'
'      ' Include 2009-08-04 in period 2
'      ' Include 2012-05-05 in period 1
'
'240       Select Case Month(datDateEx)
'          Case 1 To 6
'250           toPeriod = 1
'260       Case 7 To 12
'270           toPeriod = 2
'280       End Select
'290   Case "Fall", "RTHU_Fall"
'300       intWeek = Int((datDay - DateSerial(2000, 8, 1)) / 7) + 1
'310       If Year(datDateEx) < 2015 Then
'320           If intWeek < 1 Or intWeek > 13 Then
'330               toPeriod = -1
'340           Else
'350               toPeriod = intWeek
'360           End If
'370       Else
'380           If intWeek < 1 Or intWeek > 14 Then
'390               toPeriod = -1
'400           Else
'410               toPeriod = intWeek
'420           End If
'430       End If
'
'      ' Last day for FMMP 30-Oct before 2015
'      '                    6 Nov on or after 2015
'
'440   Case "Owling"
'450       If Year(datDateEx) < 2015 Then
'460           If datDay <= DateSerial(2000, 10, 30) Then
'470               intWeek = Int((datDay - DateSerial(2000, 8, 1)) / 7) + 1
'480               If intWeek < 1 Or intWeek > 13 Then
'490                   toPeriod = -1
'500               Else
'510                   toPeriod = intWeek
'520               End If
'530           Else
'540               Select Case Month(datDateEx)
'                   Case 1 To 9
'550                    toPeriod = -1
'560                Case 10, 11
'570                    toPeriod = 1
'580                Case 12
'590                    toPeriod = 2
'600                End Select
'610           End If
'620       Else
'630           If datDay <= DateSerial(2000, 11, 6) Then
'640               intWeek = Int((datDay - DateSerial(2000, 8, 1)) / 7) + 1
'650               If intWeek < 1 Or intWeek > 14 Then
'660                   toPeriod = -1
'670               Else
'680                   toPeriod = intWeek
'690               End If
'700           Else
'710               Select Case Month(datDateEx)
'                   Case 1 To 10
'720                    toPeriod = -1
'730                Case 11
'740                    toPeriod = 1
'750                Case 12
'760                    toPeriod = 2
'770                End Select
'780           End If
'790       End If
'800   Case Else
'810       toPeriod = -1
'820   End Select
'
'830   toRelativeReportPeriod = toPeriod
'
'    'DD Error Handler Start
'Exit_label:
'    Exit Function
'Err_label:
'    Select Case Err.Number
'    Case Else
'         Call LogError("basMBO10YearProgramReportSpecies", "toRelativeReportPeriod")
'    End Select
'    Resume Exit_label
'    ' DD Error Handler End
'End Function

'---------------------------------------------------------------------------------------
' toReportSeason
'---------------------------------------------------------------------------------------
' Redestribute Owling into Fall or Winter based on the DET date
' For -2015  Winter started on 31 Oct
' For 2016-  Winter started on 7 Nov
'
' Reassign RTHU_Spring to Spring
' Reassign RTHU_Fall to Fall
' Reassign NESTBOX to Summer
'
' Called from qry15YearReport_Species_BND_Append

Public Function toReportSeason(ByVal strSeason As String, datDateEx As Date) As String

10       On Error GoTo Err_label
         
20       Select Case strSeason
         Case "Owling"
             
30            If Year(datDateEx) < 2015 Then
40                If DateSerial(2000, Month(datDateEx), Day(datDateEx)) < DateSerial(2000, 10, 31) Then
50                    strSeason = "Fall"
60                Else
70                    strSeason = "Winter"
80                End If
90            Else
100                If DateSerial(2000, Month(datDateEx), Day(datDateEx)) < DateSerial(2000, 11, 7) Then
110                   strSeason = "Fall"
120               Else
130                   strSeason = "Winter"
140               End If
150           End If
160       Case "RTHU_Fall"
170           strSeason = "Fall"
180       Case "RTHU_Spring"
190           strSeason = "Spring"
200       Case "NESTBOX"
210           strSeason = "Summer"
220       End Select

230       toReportSeason = strSeason

          'DD Error Handler Start
Exit_label:
240       Exit Function
Err_label:
250       Select Case Err.Number
          Case Else
260            Call LogError("basMBO10Year_BirdsOfMBO_Charts", "toReportSeason")
270       End Select
280       Resume Exit_label
          ' DD Error Handler End
End Function
