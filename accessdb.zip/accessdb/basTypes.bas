Option Compare Database
Option Explicit

Public Type SheetNewBandRecordType
    BandID         As Long
    LineNumber     As String
    Disposition    As String
    BandSizeID     As Long
    BandPrefix     As String
    BandSuffix     As String
    Species        As String
    WingChord      As String
    Age            As String
    HowAged        As String
    Sex            As String
    HowSexed       As String
    Fat            As String
    Weight         As String
    CaptureDate    As String
    WeightTime     As String
    Bander         As String
    Scribe         As String
    Net            As String
    NotesForMBO    As String
    Valid          As String
    Invalid        As String
    Duplicate      As String
    BypassErrors   As Boolean
    AutoHistory    As Boolean
    ProbableAge    As String
    ProbableSex    As String
    CaptureYear    As String
    Location       As String
    Program        As String
    BirdStatus     As String
    FCombined          As String
    F(conMaxUserField) As String
    Flags              As String
    D(conMaxDataField) As String
End Type

Public Type SheetNewCaptureRecordType
    BandID         As Long
    LineNumber     As String
    BandSizeID     As Long
    BandPrefix     As String
    BandSuffix     As String
    Species        As String
    WingChord      As String
    Age            As String
    HowAged        As String
    Sex            As String
    HowSexed       As String
    Fat            As String
    Weight         As String
    CaptureDate    As String
    WeightTime     As String
    Bander         As String
    Scribe         As String
    Net            As String
    NotesForMBO    As String
    ProbableAge    As String
    ProbableSex    As String
    CaptureYear    As String
    Disposition    As String
    Location       As String
    BirdStatus     As String
    Program        As String
    AutoHistory        As Boolean
    F(conMaxUserField) As String
    D(conMaxDataField) As String
    FCombined          As String
    Flags              As String
End Type

Public Type BandsType
    IDBand             As Long
    Disposition        As String
    BandPrefix         As String
    BandSuffix         As String
    Species            As String
    WingChord          As Long
    Age                As String
    HowAged            As String
    Sex                As String
    HowSexed           As String
    Fat                As String
    Weight             As Double
    CaptureDate        As Date
    WeightTime         As Date
    Bander             As String
    Scribe             As String
    Net                As String
    NotesForMBO        As String
    ToBeExported       As Boolean
    Valid              As String
    Invalid            As String
    BypassErrors       As Boolean
    AutoHistory        As Boolean
    ProbableAge        As String
    ProbableSex        As String
    Location           As String
    BirdStatus         As String
    PresentCondition   As String
    HowObtainedCode    As String
    Program            As String
    FCombined          As String
    F(conMaxUserField) As String
    D(conMaxDataField) As String
    Flags              As String
End Type

'Public Type SheetNewBandRecordType
'    BandID         As Long
'    LineNumber     As String
'    Disposition    As String
'    BandSizeID     As Long
'    BandPrefix     As String
'    BandSuffix     As String
'    Species        As String
'    WingChord      As String
'    Age            As String
'    HowAged        As String
'    Sex            As String
'    HowSexed       As String
'    Fat            As String
'    Weight         As String
'    CaptureDate    As String
'    WeightTime     As String
'    Bander         As String
'    Scribe         As String
'    Net            As String
'    NotesForMBO    As String
'    Valid          As String
'    Invalid        As String
'    Duplicate      As String
'    BypassErrors   As Boolean
'    AutoHistory    As Boolean
'    ProbableAge    As String
'    ProbableSex    As String
'    CaptureYear    As String
'    Location       As String
'    Program        As String
'    BirdStatus     As String
'    FCombined          As String
'    F(conMaxUserField) As String
'    Flags              As String
'    D(conMaxDataField) As String
'End Type

Public Type SheetRecaptureRecordType
    BandID         As Long
    LineNumber     As String  ' Its in the table, but no longer used
    Disposition    As String
    BandPrefix     As String
    BandSuffix     As String
    Species        As String
    WingChord      As String
    Age            As String
    HowAged        As String
    Sex            As String
    HowSexed       As String
    Fat            As String
    Weight         As String
    CaptureDate    As String
    WeightTime     As String
    Bander         As String
    Scribe         As String
    Net            As String
    NotesForMBO    As String
    Valid          As String
    Invalid        As String
    BypassErrors   As Boolean
    AutoHistory    As Boolean
    ProbableAge    As String
    ProbableSex    As String
    CaptureYear    As String
    Location       As String
    Program        As String
    BirdStatus     As String
    PresentCondition   As String
    HowObtainedCode    As String
    CaptureCount       As Long
    FCombined          As String
    F(conMaxUserField) As String
    Flags              As String
    D(conMaxDataField) As String
End Type

Public Type CapturesRecordType
    IDBand             As Long
    Disposition        As String
    BandPrefix         As String
    BandSuffix         As String
    Species            As String
    WingChord          As Long
    Age                As String
    HowAged            As String
    Sex                As String
    HowSexed           As String
    Fat                As String
    Weight             As Double
    CaptureDate        As Date
    WeightTime         As Variant   ' Date OR Null
    Bander             As String
    Scribe             As String
    Net                As String
    NotesForMBO        As String
    ToBeExported       As Boolean
    Valid              As String
    Invalid            As String
    BypassErrors       As Boolean
    AutoHistory        As Boolean
    ProbableAge        As String
    ProbableSex        As String
    Location           As String
    Program            As String
    BirdStatus         As String
    PresentCondition   As String
    HowObtainedCode    As String
    FCombined          As String
    F(conMaxUserField) As String
    Flags              As String
    D(conMaxDataField) As String
End Type


Public Type CapturesImportStatistics
    countNewCaptureRecords          As Long ' New bands  stored
    countRecaptureRecords           As Long ' New recaptures stored
    countDuplicateNewCaptureRecords As Long ' Duplicate Bands - rejected
    countDuplicateRecaptureRecords  As Long ' Duplicate Recaptures - rejected
    countRejectedRecords            As Long ' Records with non-bypassable errors
    countSkippedEqualRecords        As Long ' Records skipped since they are equal to a stored record
End Type

Public Type IsValidType
    IsBandValid As Boolean
    IsDateValid As Boolean
    IsSpeciesValid As Boolean
    IsSexValid As Boolean
    IsDispositionValid As Boolean
    varValid As Variant
    varInvalid As Variant
    IsMultiRecordError As Boolean
End Type

Public Type SheetNewBandsType
    BandID             As Variant
    Disposition        As Variant
    BandSizeID         As Variant
    BandPrefix         As Variant
    BandSuffix         As Variant
    Species            As Variant
    WingChord          As Variant
    Age                As Variant
    HowAged            As Variant
    Sex                As Variant
    HowSexed           As Variant
    Fat                As Variant
    Weight             As Variant
    CaptureDate        As Variant
    WeightTime         As Variant
    Bander             As Variant
    Scribe             As Variant
    Net                As Variant
    NotesForMBO        As Variant
    Valid              As Variant
    Invalid            As Variant
    Duplicate          As Variant
    BypassErrors       As Variant
    AutoHistory        As Variant
    ProbableAge        As Variant
    ProbableSex        As Variant
    CaptureYear        As Variant
    Location           As Variant
    Program            As Variant
    BirdStatus         As Variant
    FCombined          As Variant
    F(conMaxUserField) As Variant
    D(conMaxDataField) As Variant
    Flags              As Variant
    Command            As String
    Source             As String
End Type

Public Type SheetRecapturesType
    BandID             As Variant
    Disposition        As Variant
    BandPrefix         As Variant
    BandSuffix         As Variant
    Species            As Variant
    WingChord          As Variant
    Age                As Variant
    HowAged            As Variant
    Sex                As Variant
    HowSexed           As Variant
    Fat                As Variant
    Weight             As Variant
    CaptureDate        As Variant
    WeightTime         As Variant
    Bander             As Variant
    Scribe             As Variant
    Net                As Variant
    NotesForMBO        As Variant
    Valid              As Variant
    Invalid            As Variant
    Duplicate          As Variant
    BypassErrors       As Variant
    AutoHistory        As Variant
    ProbableAge        As Variant
    ProbableSex        As Variant
    CaptureYear        As Variant
    Location           As Variant
    Program            As Variant
    BirdStatus         As Variant
    PresentCondition   As Variant
    HowObtainedCode    As Variant
    CaptureCount       As Variant
    FCombined          As Variant
    F(conMaxUserField) As Variant
    D(conMaxDataField) As Variant
    Flags              As Variant
    Command            As String
    Source             As String
End Type

Public Type CapturesType
    IDBand             As Variant
    Disposition        As Variant
    BandPrefix         As Variant
    BandSuffix         As Variant
    Species            As Variant
    WingChord          As Variant
    Age                As Variant
    HowAged            As Variant
    Sex                As Variant
    HowSexed           As Variant
    Fat                As Variant
    Weight             As Variant
    CaptureDate        As Variant
    WeightTime         As Variant
    Bander             As Variant
    Scribe             As Variant
    Net                As Variant
    NotesForMBO        As Variant
    ToBeExported       As Variant
    Valid              As Variant
    Invalid            As Variant
    BypassErrors       As Variant
    AutoHistory        As Variant
    ProbableAge        As Variant
    ProbableSex        As Variant
    Location           As Variant
    Program            As Variant
    BirdStatus         As Variant
    PresentCondition   As Variant
    HowObtainedCode    As Variant
    FCombined          As Variant
    F(conMaxUserField) As Variant
    D(conMaxDataField) As Variant
    Flags              As Variant
    Command            As String
    Source             As String
End Type

Public Type DETDailyType
    Program          As String
    Location         As String
    DateEx           As Date
    Observers        As Variant     ' Observer effort
    SongbirdNets     As Variant
    NonSongbirdNets  As Variant
    JTrap            As Variant
    OtherTrap        As Variant     ' Hummingbird effort
    Heliogoland      As Variant
    VisibleMigration As Variant
    CoverageCode     As Variant
    Timestamp        As Date
    Command          As String
    Source           As String
    IDLog            As Long
End Type

Public Type DETSpeciesType
    Program           As String
    Location          As String
    DateEx            As Date
    Species           As String
    Observed          As Variant
    Census            As Variant
    Banded            As Variant
    Repeats           As Variant
    Returns           As Variant
    PKS               As Variant           ' no longer used
    DET               As Variant
    VisibleEx         As Variant           ' not used
    Casual            As Variant            ' not used
    Observed3         As Variant           ' Alien
    Observed4         As Variant           ' Replacement
    NonStandardBanded As Variant           ' not used
    NonStandardRecaps As Variant           ' not used
    DailySpeciesTotal As Variant           ' not used
    Timestamp         As Date
    Command           As String
    Source            As String
    IDLog             As Long
End Type

Public Type DETNetHoursType
    Program           As String
    Location          As String
    DateEx            As Date
    NetID             As String
    NetHours          As Variant      ' Double OR Null
    Timestamp         As Date
    Command           As String
    Source            As String
    IDLog             As Long
End Type

Public Type ErrorLogging
    DateEx              As Date
    ErrNumber           As Long
    ErrDescription      As String
    ModuleEx            As String
    ProcedureEx         As String
    Erl                 As Long
    VersionFrontEnd     As String
    DeveloperMessage    As String
    DeveloperErrNumber  As Long
End Type
