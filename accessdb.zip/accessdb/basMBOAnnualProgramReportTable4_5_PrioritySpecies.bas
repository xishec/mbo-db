'---------------------------------------------------------------------------------------
' Module    : basMBOAnnualProgramReportTable4_5_PrioritySpecies
' Author    : David Davey
'---------------------------------------------------------------------------------------

Option Compare Database
Option Explicit

Private intYear As Integer
Private strLocation As String
Private strProgram As String
Private strSeason As String

'---------------------------------------------------------------------------------------
' MBOAnnualProgramReportTable4_5
'---------------------------------------------------------------------------------------
' Priority Species

Public Sub MBOAnnualProgramReportTable4_5( _
    ByRef fValid As Boolean, _
    ByVal intYear As Integer, _
    ByVal strLocation As String, _
    ByVal strProgram As String, _
    ByVal strSeason As String, _
    ByRef wd As Word.Application, _
    ByRef doc As Word.Document, _
    ByRef oExcel As Excel.Application, _
    ByRef oBook As Excel.Workbook, _
    ByVal strTableCaptionHeading As String)

10    On Error GoTo Err_label

20    SysCmd acSysCmdSetStatus, strSeason & " Priority species"

30    fValid = True

      Dim strSQL As String

40    If Not (strSeason = "Spring" Or strSeason = "Fall") Then GoTo Exit_label


50    If 0 = DCount("*", "tblDETSpecies", "[Program]='" & strProgram & "' AND [Location]='" & strLocation & "'") Then

60        fValid = False
70        GoTo Exit_label
80    End If

      Dim range As Word.range
      Dim strFontName As String

90    strFontName = "Arial"

      ' Append the caption for Table Priority Species


      Dim strTableCaptionBody As String
      Dim strTableCaptionTC As String

100   Select Case strSeason
      Case "Spring"
110   strTableCaptionBody = _
          "Summary of priority species observed and banded during the " & intYear & " SMMP.  Detailed category definitions are provided in Gahbauer et al. (2014)."
120   strTableCaptionTC = _
          "Summary of priority species observed and banded during the " & intYear & " SMMP"

130   Case "Fall"
140   strTableCaptionBody = _
          "Summary of priority species observed and banded during the " & intYear & " FMMP.  Detailed category definitions are provided in Gahbauer et al. (2014)."
150   strTableCaptionTC = _
          "Summary of priority species observed and banded during the " & intYear & " FMMP"
160   End Select

170   Set range = doc.Characters.Last
180   range.InsertParagraphAfter

190   Call InsertTableCaptionXX(wd, doc, "Table", _
        strTableCaptionHeading, _
        strTableCaptionBody, _
        strTableCaptionTC)

      ' Append Table Priority Species

200   Set range = doc.Characters.Last
210   Call WordGenerateTablePrioritySpecies(doc, range, strFontName)

      ' Fill in the Word table

      ' qryDETSpecies_No_WPWA_YPWA
      ' --------------------------
      ' Same as tblDETSpecies without WPWA, YPWA and PAWA

      ' qryDETSpecies_PAWA
      ' ------------------
      ' Just the PAWA, WPWA, YPWA records from tblDETSpecies merged into PAWA records.
      ' ------------------------------------------------------------------------------
      ' tblDETSpecies
      '
      ' GROUP By Program
      ' GROUP By Location
      ' GROUP By DateEx
      ' WHERE Species In ("PAWA","WPWA","YPWA")
      ' GROUP By Species = "PAWA"
      ' Observed = SUM Observed
      ' Census = SUM Census
      ' Banded = SUM Banded
      ' Repeats = SUM Repeats
      ' Returns = SUM Returns
      ' plus other fields that we don't use
          
      ' qryDETSpecies_AdjustedForPalmWarbler
      ' ------------------------------------
      ' UNION qryDETSpecies_No_WPWA_YPWA_PAWA
      '       qryDETSpecies_PAWA

      ' qryMBOAnnualProgramReportTable4_5A
      ' ----------------------------------
      ' Summary of birds banded and DET for given program, location
      ' ----------------------------------
      ' Make Table Query (the following queries do not work unless I make a table from this query ...)
      ' => tblMBOAnnualProgramReportTable4_5A
      ' FROM qryDETSpecies_AdjustedForPalmWarbler
      ' WHERE Program = argProgram
      ' WHERE Location = argLocation
      ' GROUP BY Species
      ' Banded = SUM Banded
      ' DET = SUM DET

      ' qryMBOAnnualProgramReportTable4_5B
      ' ----------------------------------
      ' For each priority species count the birds banded
      ' For each priority species count the birds DET
      ' ----------------------------------
      ' FROM tblSpecies LEFT OUTER JOIN tblMBOAnnualProgramReportTable4_5A
      ' Species
      ' SpeciesEnglish: SpeciesDescriptionMBO
      ' PriorityCategory   Not Null
      ' DETBirds
      ' BandedBirds
      ' ORDER BY PriorityCategory, AOUOrder

      ' qryMBOAnnualProgramReportTable4_5C
      ' ----------------------------------
      ' For each priority category, count the banded species
      ' For each priority category, count the DET species
      ' For each priority category, count the species (in the priority category)
      ' ----------------------------------
      ' from qryMBOAnnualProgramReportTable4_5B
      ' PriorityCategory
      ' TotalSpecies  = Total number of species in the priority category
      ' BandedSpecies = Total number of species banded in priority category
      ' DETSpecies    = Total number of species 'observed' (in DET) in priority category


      ' qryMBOAnnualProgramReportTable4_5D
      ' from qryMBOAnnualProgramReportTable4_5B
      ' GROUP BY PriorityCategory
      ' BandedBirds = Total number of individuals banded in priority category

      ' qryMBOAnnualProgramReportTable4_5D
      ' from qryMBOAnnualProgramReportTable4_5B, qryMBOAnnualProgramReportTable4_5C
      ' PriorityCategory ASC
      ' Total             = Total number of species in the priority category
      ' DET               = Total number of species 'observed' (in DET) in priority category
      ' Banded            = Total number of species banded in priority category
      ' IndividualsBanded = Total number of individuals banded in priority category

      Dim strPriority As String
      Dim intTotalPriority As Integer
      Dim intTotalDET As Integer
      Dim intTotalBanded As Integer
      Dim lngTotalIndividualsBanded As Long

      ' Delete tblMBOAnnualProgramReportTable4_5A

220   DoCmd.SetWarnings False
230   On Error Resume Next
240   DoCmd.DeleteObject acTable = acDefault, "tblMBOAnnualProgramReportTable4_5A"
250   On Error GoTo Err_label
260   DoCmd.SetWarnings True

      ' Create the temporary table tblMBOAnnualProgramReportTable4_5A

      Dim qdf As QueryDef
270   Set qdf = CurrentDb.QueryDefs("qryMBOAnnualProgramReportTable4_5A")
280   qdf.Parameters("argProgram").value = strProgram
290   qdf.Parameters("argLocation").value = strLocation
300   qdf.Execute

      Dim rst As DAO.Recordset

310   Set rst = CurrentDb.OpenRecordset("qryMBOAnnualProgramReportTable4_5E")

320   Do While Not rst.EOF
          
330       strPriority = Nz(rst("PriorityCategory"))
340       intTotalDET = Nz(rst("DET"))
350       intTotalBanded = Nz(rst("Banded"))
360       lngTotalIndividualsBanded = Nz(rst("IndividualsBanded"))

370       intTotalPriority = DCount("*", "tblSpecies", "PriorityCategory = '" & strPriority & "'")

          Dim column As Integer
380       Select Case strPriority
          Case "A"
390           column = 2
400       Case "B"
410           column = 3
420       Case "C"
430           column = 4
440       Case "D"
450           column = 5
460       End Select
          
470       range.Tables(1).Cell(2, column).range.Text = intTotalPriority
480       range.Tables(1).Cell(3, column).range.Text = intTotalDET
490       range.Tables(1).Cell(4, column).range.Text = intTotalBanded
500       range.Tables(1).Cell(5, column).range.Text = lngTotalIndividualsBanded

510       rst.MoveNext
520   Loop
530   rst.Close
540   Set rst = Nothing
550   Set qdf = Nothing

560   range.Tables(1).Rows.WrapAroundText = False
570   range.InsertParagraphAfter

      ' Create an Excel Worksheet

      Dim colLocation As Integer
      Dim colProgram As Integer
      Dim colPriority As Integer
      Dim colSpecies As Integer
      Dim colSpeciesEnglish As Integer
      Dim colDET As Integer
      Dim colBanded As Integer

580   colPriority = 1
590   colSpecies = 2
600   colSpeciesEnglish = 3
610   colDET = 4
620   colBanded = 5

      Dim lngCountPrioritySpeciesBanded As Long
      Dim lngCountPriorityIndividualsBanded As Long
      Dim lngCountPrioritySpeciesDET As Long

      Dim lngCountPrioritySpecies As Long
      Dim lngCountIndividualsBanded As Long

      Dim lngCount

630   lngCountPrioritySpeciesBanded = 0
640   lngCountPriorityIndividualsBanded = 0
650   lngCountPrioritySpeciesDET = 0

660   lngCountPrioritySpecies = DCount("*", "tblSpecies", "nz([PriorityCategory])<>''")


      Dim oSheet As Excel.Worksheet
670   Set oSheet = InsertSheet(oBook, strSeason)
680   oSheet.Name = strSeason & " Priority"

690   With oSheet

          Dim row As Long
700       row = 1

          ' Reserve row 1 for a comment

710       row = row + 1
       
          ' Fill in headers
          
720       .Cells(row, colPriority) = "Priority"
730       .Cells(row, colSpecies) = "Species"
740       .Cells(row, colDET) = "DET"
750       .Cells(row, colBanded) = "Banded"
760       row = row + 1
          
      '    Dim rst As DAO.Recordset

770       Set rst = CurrentDb.OpenRecordset("qryMBOAnnualProgramReportTable4_5B")
          
      '    Dim strPriority As String
          Dim strSpecies As String
          Dim lngDET As Long
          Dim lngBanded As Long
          Dim strSpeciesEnglish As String
          
          
780       Do While Not rst.EOF
          
790           strPriority = Nz(rst("PriorityCategory"))
800           strSpecies = Nz(rst("Species"))
810           strSpeciesEnglish = Nz(rst("SpeciesEnglish"))
820           lngDET = Nz(rst("DETBirds"))
830           lngBanded = Nz(rst("BandedBirds"))
              
840           .Cells(row, colPriority) = strPriority
850           .Cells(row, colSpecies) = strSpecies
860           .Cells(row, colSpeciesEnglish) = strSpeciesEnglish
870           If lngDET > 0 Then
880               .Cells(row, colDET) = lngDET
890                lngCountPrioritySpeciesDET = lngCountPrioritySpeciesDET + 1
900           End If
910           If lngBanded > 0 Then
920               .Cells(row, colBanded) = lngBanded
930               lngCountPrioritySpeciesBanded = lngCountPrioritySpeciesBanded + 1
940               lngCountPriorityIndividualsBanded = lngCountPriorityIndividualsBanded + lngBanded
950           End If
              
960           row = row + 1
970           rst.MoveNext
980       Loop
990       rst.Close
1000      Set rst = Nothing
          
1010      .range(.columns(1), .columns(colBanded)).AutoFit
          
          Dim intYearEx As Integer
          Dim colYearFirst As Integer
          Dim colYearLast As Integer
          
1020      colYearFirst = 4
1030      colYearLast = colYearFirst + (intYear - 2005)
          
          Dim col As Long
          
1040      row = row + 1
          
1050      .Cells(row, 2) = "Year"
1060      .Cells(row + 1, 2) = "Priority Species"
1070      .Cells(row + 2, 2) = "Banded Priority Species"
1080      .Cells(row + 3, 2) = "% Banded Priority Species"
1090      .Cells(row + 4, 2) = "Observed (DET) Priority Species"
1100      .Cells(row + 5, 2) = "% Observed (DET) Priority Species"
1110      .Cells(row + 7, 2) = "Banded Individuals"
1120      .Cells(row + 8, 2) = "Banded Priority Individuals"
1130      .Cells(row + 9, 2) = "%Banded Priority Individuals"

          ' Banded Individuals
          
1140      Set qdf = CurrentDb.QueryDefs("qryMBOAnnualProgramReportTable4_5H")
1150      qdf.Parameters("argSeason").value = strSeason
1160      qdf.Parameters("argLocation").value = strLocation
1170      Set rst = qdf.OpenRecordset
          
1180      Do While Not rst.EOF
1190          intYearEx = Nz(rst("YearEx"))
1200          If intYearEx <= intYear And intYear >= 2005 Then
1210              col = intYearEx - 2005 + 4
1220              .Cells(row + 7, col) = Nz(rst("BandedIndividuals"))
1230          End If
1240          rst.MoveNext
1250      Loop
1260      rst.Close
          
          ' PriorityBandedSpecies, PriorityDETSpecies
1270      Set qdf = CurrentDb.QueryDefs("qryMBOAnnualProgramReportTable4_5I")
1280      qdf.Parameters("argSeason").value = strSeason
1290      qdf.Parameters("argLocation").value = strLocation
1300      Set rst = qdf.OpenRecordset
          
1310      Do While Not rst.EOF
1320          intYearEx = Nz(rst("YearEx"))
1330          If intYearEx <= intYear And intYear >= 2005 Then
1340              col = intYearEx - 2005 + 4
1350             .Cells(row + 2, col) = Nz(rst("PriorityBandedSpecies"))
1360              .Cells(row + 4, col) = Nz(rst("PriorityDETSpecies"))
1370          End If
1380          rst.MoveNext
1390      Loop
1400      rst.Close

          ' PriorityBandedIndividuals
          
1410      Set qdf = CurrentDb.QueryDefs("qryMBOAnnualProgramReportTable4_5J")
1420      qdf.Parameters("argSeason").value = strSeason
1430      qdf.Parameters("argLocation").value = strLocation
1440      Set rst = qdf.OpenRecordset
          
1450      Do While Not rst.EOF
1460          intYearEx = Nz(rst("YearEx"))
1470          If intYearEx <= intYear And intYear >= 2005 Then
1480              col = intYearEx - 2005 + 4
1490              .Cells(row + 8, col) = Nz(rst("PriorityBandedIndividuals"))
1500          End If
1510          rst.MoveNext
1520      Loop
1530      rst.Close

          ' PrioritySpecies
          
          Dim intPrioritySpecies As Integer
1540      intPrioritySpecies = DCount("*", "tblSpecies", "PseudoSpeciesType = 'Species' AND Nz(PriorityCategory) <> ''")
1550      For intYearEx = 2005 To intYear
1560          col = intYearEx - 2005 + 4
1570          .Cells(row + 1, col) = intPrioritySpecies
1580      Next
          
          ' Percentages
          
1590      For intYearEx = 2005 To intYear
1600          col = (intYearEx - 2005) + colYearFirst
1610          .Cells(row, col) = intYearEx
1620          .Cells(row + 3, col) = .Cells(row + 2, col) / intPrioritySpecies
1630          .Cells(row + 5, col) = .Cells(row + 4, col) / intPrioritySpecies
1635          If .Cells(row + 7, col) <> 0 Then
1640               .Cells(row + 9, col) = .Cells(row + 8, col) / .Cells(row + 7, col)
1645          End If
1650      Next
          
1660      .range(.Cells(row + 3, colYearFirst), .Cells(row + 3, colYearLast)).NumberFormat = "0%"
1670      .range(.Cells(row + 5, colYearFirst), .Cells(row + 5, colYearLast)).NumberFormat = "0%"
1680      .range(.Cells(row + 9, colYearFirst), .Cells(row + 9, colYearLast)).NumberFormat = "0%"
1690      .range(.columns(4), .columns(colBanded)).AutoFit


1700      .Cells(1, 1) = strSeason & " " & intYear & " - Priority Species"

1710  End With

1720  Set oSheet = Nothing

1730  SysCmd acSysCmdClearStatus

      'DD Error Handler Start
Exit_label:
1740       Exit Sub
Err_label:
1750       Select Case Err.Number
           Case Else
1760      Call LogError("basMBOAnnualProgramReportTable4_5_PrioritySpecies", "MBOAnnualProgramReportTable4_5")
1770       End Select
1780       Resume Exit_label
      'DD Error Handler End

End Sub


''---------------------------------------------------------------------------------------
'' MBOAnnualProgramReportTable4_5
''---------------------------------------------------------------------------------------
'' Priority Species
'
'Public Sub MBOAnnualProgramReportTable4_5( _
'    ByRef fValid As Boolean, _
'    ByVal intYear As Integer, _
'    ByVal strLocation As String, _
'    ByVal strProgram As String, _
'    ByVal strSeason As String, _
'    ByRef wd As Word.Application, _
'    ByRef doc As Word.Document, _
'    ByRef oExcel As Excel.Application, _
'    ByRef oBook As Excel.Workbook, _
'    ByVal strTableCaptionHeading As String)
'
'10    On Error GoTo Err_label
'
'20    SysCmd acSysCmdSetStatus, strSeason & " Priority species"
'
'30    fValid = True
'
'      Dim strSQL As String
'
'40    If Not (strSeason = "Spring" Or strSeason = "Fall") Then GoTo Exit_label
'
'
'50    If 0 = DCount("*", "tblDETSpecies", "[Program]='" & strProgram & "' AND [Location]='" & strLocation & "'") Then
'
'60        fValid = False
'70        GoTo Exit_label
'80    End If
'
'      Dim range As Word.range
'      Dim strFontName As String
'
'90    strFontName = "Arial"
'
'      ' Append the caption for Table Priority Species
'
'
'      Dim strTableCaptionBody As String
'      Dim strTableCaptionTC As String
'
'100   Select Case strSeason
'      Case "Spring"
'110   strTableCaptionBody = _
'          "Summary of priority species observed and banded during the " & intYear & " SMMP.  Detailed category definitions are provided in Gahbauer et al. (2014)."
'120   strTableCaptionTC = _
'          "Summary of priority species observed and banded during the " & intYear & " SMMP"
'
'130   Case "Fall"
'140   strTableCaptionBody = _
'          "Summary of priority species observed and banded during the " & intYear & " FMMP.  Detailed category definitions are provided in Gahbauer et al. (2014)."
'150   strTableCaptionTC = _
'          "Summary of priority species observed and banded during the " & intYear & " FMMP"
'160   End Select
'
'170   Set range = doc.Characters.Last
'180   range.InsertParagraphAfter
'
'190   Call InsertTableCaptionXX(wd, doc, "Table", _
'        strTableCaptionHeading, _
'        strTableCaptionBody, _
'        strTableCaptionTC)
'
'      ' Append Table Priority Species
'
'200   Set range = doc.Characters.Last
'210   Call WordGenerateTablePrioritySpecies(doc, range, strFontName)
'
'      ' Fill in the Word table
'
'      ' qryDETSpecies_No_WPWA_YPWA
'      ' --------------------------
'      ' Same as tblDETSpecies without WPWA, YPWA and PAWA
'
'      ' qryDETSpecies_PAWA
'      ' ------------------
'      ' Just the PAWA, WPWA, YPWA records from tblDETSpecies merged into PAWA records.
'      ' ------------------------------------------------------------------------------
'      ' tblDETSpecies
'      '
'      ' GROUP By Program
'      ' GROUP By Location
'      ' GROUP By DateEx
'      ' WHERE Species In ("PAWA","WPWA","YPWA")
'      ' GROUP By Species = "PAWA"
'      ' Observed = SUM Observed
'      ' Census = SUM Census
'      ' Banded = SUM Banded
'      ' Repeats = SUM Repeats
'      ' Returns = SUM Returns
'      ' plus other fields that we don't use
'
'      ' qryDETSpecies_AdjustedForPalmWarbler
'      ' ------------------------------------
'      ' UNION qryDETSpecies_No_WPWA_YPWA_PAWA
'      '       qryDETSpecies_PAWA
'
'      ' qryMBOAnnualProgramReportTable4_5A
'      ' ----------------------------------
'      ' Summary of birds banded and DET for given program, location
'      ' ----------------------------------
'      ' Make Table Query (the following queries do not work unless I make a table from this query ...)
'      ' => tblMBOAnnualProgramReportTable4_5A
'      ' FROM qryDETSpecies_AdjustedForPalmWarbler
'      ' WHERE Program = argProgram
'      ' WHERE Location = argLocation
'      ' GROUP BY Species
'      ' Banded = SUM Banded
'      ' DET = SUM DET
'
'      ' qryMBOAnnualProgramReportTable4_5B
'      ' ----------------------------------
'      ' For each priority species count the birds banded
'      ' For each priority species count the birds DET
'      ' ----------------------------------
'      ' FROM tblSpecies LEFT OUTER JOIN tblMBOAnnualProgramReportTable4_5A
'      ' Species
'      ' SpeciesEnglish: SpeciesDescriptionMBO
'      ' PriorityCategory   Not Null
'      ' DETBirds
'      ' BandedBirds
'      ' ORDER BY PriorityCategory, AOUOrder
'
'      ' qryMBOAnnualProgramReportTable4_5C
'      ' ----------------------------------
'      ' For each priority category, count the banded species
'      ' For each priority category, count the DET species
'      ' For each priority category, count the species (in the priority category)
'      ' ----------------------------------
'      ' from qryMBOAnnualProgramReportTable4_5B
'      ' PriorityCategory
'      ' TotalSpecies  = Total number of species in the priority category
'      ' BandedSpecies = Total number of species banded in priority category
'      ' DETSpecies    = Total number of species 'observed' (in DET) in priority category
'
'
'      ' qryMBOAnnualProgramReportTable4_5D
'      ' from qryMBOAnnualProgramReportTable4_5B
'      ' GROUP BY PriorityCategory
'      ' BandedBirds = Total number of individuals banded in priority category
'
'      ' qryMBOAnnualProgramReportTable4_5D
'      ' from qryMBOAnnualProgramReportTable4_5B, qryMBOAnnualProgramReportTable4_5C
'      ' PriorityCategory ASC
'      ' Total             = Total number of species in the priority category
'      ' DET               = Total number of species 'observed' (in DET) in priority category
'      ' Banded            = Total number of species banded in priority category
'      ' IndividualsBanded = Total number of individuals banded in priority category
'
'      Dim strPriority As String
'      Dim intTotalPriority As Integer
'      Dim intTotalDET As Integer
'      Dim intTotalBanded As Integer
'      Dim lngTotalIndividualsBanded As Long
'
'      ' Delete tblMBOAnnualProgramReportTable4_5A
'
'220   DoCmd.SetWarnings False
'230   On Error Resume Next
'240   DoCmd.DeleteObject acTable = acDefault, "tblMBOAnnualProgramReportTable4_5A"
'250   On Error GoTo Err_label
'260   DoCmd.SetWarnings True
'
'      ' Create the temporary table tblMBOAnnualProgramReportTable4_5A
'
'      Dim qdf As QueryDef
'270   Set qdf = CurrentDb.QueryDefs("qryMBOAnnualProgramReportTable4_5A")
'280   qdf.Parameters("argProgram").value = strProgram
'290   qdf.Parameters("argLocation").value = strLocation
'300   qdf.Execute
'
'      Dim rst As DAO.Recordset
'
'310   Set rst = CurrentDb.OpenRecordset("qryMBOAnnualProgramReportTable4_5E")
'
'320   Do While Not rst.EOF
'
'330       strPriority = Nz(rst("PriorityCategory"))
'340       intTotalDET = Nz(rst("DET"))
'350       intTotalBanded = Nz(rst("Banded"))
'360       lngTotalIndividualsBanded = Nz(rst("IndividualsBanded"))
'
'370       intTotalPriority = DCount("*", "tblSpecies", "PriorityCategory = '" & strPriority & "'")
'
'          Dim column As Integer
'380       Select Case strPriority
'          Case "A"
'390           column = 2
'400       Case "B"
'410           column = 3
'420       Case "C"
'430           column = 4
'440       Case "D"
'450           column = 5
'460       End Select
'
'470       range.tables(1).Cell(2, column).range.Text = intTotalPriority
'480       range.tables(1).Cell(3, column).range.Text = intTotalDET
'490       range.tables(1).Cell(4, column).range.Text = intTotalBanded
'500       range.tables(1).Cell(5, column).range.Text = lngTotalIndividualsBanded
'
'510       rst.MoveNext
'520   Loop
'530   rst.Close
'540   Set rst = Nothing
'550   Set qdf = Nothing
'
'560   range.tables(1).Rows.WrapAroundText = False
'570   range.InsertParagraphAfter
'
'      ' Create an Excel Worksheet
'
'      Dim colLocation As Integer
'      Dim colProgram As Integer
'      Dim colPriority As Integer
'      Dim colSpecies As Integer
'      Dim colSpeciesEnglish As Integer
'      Dim colDET As Integer
'      Dim colBanded As Integer
'
'580   colPriority = 1
'590   colSpecies = 2
'600   colSpeciesEnglish = 3
'610   colDET = 4
'620   colBanded = 5
'
'      Dim lngCountPrioritySpeciesBanded As Long
'      Dim lngCountPriorityIndividualsBanded As Long
'      Dim lngCountPrioritySpeciesDET As Long
'
'      Dim lngCountPrioritySpecies As Long
'      Dim lngCountIndividualsBanded As Long
'
'      Dim lngCount
'
'630   lngCountPrioritySpeciesBanded = 0
'640   lngCountPriorityIndividualsBanded = 0
'650   lngCountPrioritySpeciesDET = 0
'
'660   lngCountPrioritySpecies = DCount("*", "tblSpecies", "nz([PriorityCategory])<>''")
'
'
'      Dim oSheet As Excel.Worksheet
'670   Set oSheet = InsertSheet(oBook, strSeason)
'680   oSheet.Name = strSeason & " Priority"
'
'690   With oSheet
'
'          Dim row As Long
'700       row = 1
'
'          ' Reserve row 1 for a comment
'
'710       row = row + 1
'
'          ' Fill in headers
'
'720       .Cells(row, colPriority) = "Priority"
'730       .Cells(row, colSpecies) = "Species"
'740       .Cells(row, colDET) = "DET"
'750       .Cells(row, colBanded) = "Banded"
'760       row = row + 1
'
'      '    Dim rst As DAO.Recordset
'
'770       Set rst = CurrentDb.OpenRecordset("qryMBOAnnualProgramReportTable4_5B")
'
'      '    Dim strPriority As String
'          Dim strSpecies As String
'          Dim lngDET As Long
'          Dim lngBanded As Long
'          Dim strSpeciesEnglish As String
'
'
'780       Do While Not rst.EOF
'
'790           strPriority = Nz(rst("PriorityCategory"))
'800           strSpecies = Nz(rst("Species"))
'810           strSpeciesEnglish = Nz(rst("SpeciesEnglish"))
'820           lngDET = Nz(rst("DETBirds"))
'830           lngBanded = Nz(rst("BandedBirds"))
'
'840           .Cells(row, colPriority) = strPriority
'850           .Cells(row, colSpecies) = strSpecies
'860           .Cells(row, colSpeciesEnglish) = strSpeciesEnglish
'870           If lngDET > 0 Then
'880               .Cells(row, colDET) = lngDET
'890                lngCountPrioritySpeciesDET = lngCountPrioritySpeciesDET + 1
'900           End If
'910           If lngBanded > 0 Then
'920               .Cells(row, colBanded) = lngBanded
'930               lngCountPrioritySpeciesBanded = lngCountPrioritySpeciesBanded + 1
'940               lngCountPriorityIndividualsBanded = lngCountPriorityIndividualsBanded + lngBanded
'950           End If
'
'960           row = row + 1
'970           rst.MoveNext
'980       Loop
'990       rst.Close
'1000      Set rst = Nothing
'
'1010      .range(.Columns(1), .Columns(colBanded)).AutoFit
'
'          Dim strWhere As String
'1020          strWhere = _
'              "[Program] = '" & strProgram & "' AND " & _
'              "[Location] = '" & strLocation & "'"
'
'1030      lngTotalIndividualsBanded = Nz(DSum("Banded", "tblDETSpecies", strWhere))
'
'1040      row = row + 1
'1050      .Cells(row, 3) = lngCountPrioritySpeciesBanded & " (" & Round(100 * lngCountPrioritySpeciesBanded / lngCountPrioritySpecies) & "% = " & lngCountPrioritySpeciesBanded & "/" & lngCountPrioritySpecies & ")   priority species banded"
'1060      row = row + 1
'1070      .Cells(row, 3) = lngCountPriorityIndividualsBanded & " (" & Round(100 * lngCountPriorityIndividualsBanded / lngTotalIndividualsBanded) & "% = " & lngCountPriorityIndividualsBanded & "/" & lngTotalIndividualsBanded & ")   priority individuals banded"
'1080      row = row + 1
'1090      .Cells(row, 3) = lngCountPrioritySpeciesDET & " (" & Round(100 * lngCountPrioritySpeciesDET / lngCountPrioritySpecies) & "% = " & lngCountPrioritySpeciesDET & "/" & lngCountPrioritySpecies & ")   priority species observed (DET)"
'1100      row = row + 1
'
'1110      .Cells(1, 1) = strSeason & " " & intYear & " - Priority Species"
'
'1120  End With
'
'1130  Set oSheet = Nothing
'
'1140  SysCmd acSysCmdClearStatus
'
'      'DD Error Handler Start
'Exit_label:
'1150       Exit Sub
'Err_label:
'1160       Select Case Err.Number
'           Case Else
'1170      Call LogError("basMBOAnnualProgramReportTable4_5_PrioritySpecies", "MBOAnnualProgramReportTable4_5")
'1180       End Select
'1190       Resume Exit_label
'      'DD Error Handler End
'
'End Sub


'---------------------------------------------------------------------------------------
' WordGenerateTablePrioritySpecies
'---------------------------------------------------------------------------------------
' entry:  range = a collapsed range that is the insertion point for the table
' exit:   range = range that includes the table

Private Sub WordGenerateTablePrioritySpecies( _
    ByRef doc As Word.Document, _
    ByRef range As Word.range, _
    ByVal strFontName As String)

10    On Error GoTo Err_label

20    On Error GoTo Err_label

      Dim row As Integer
      Dim col As Integer

30    doc.Tables.Add range:=range, NumRows:=5, NumColumns:=5
          
40    range.Expand (wdTable)
50    With range.Tables(1)

60        .range.Style = "ddPrioritySpeciesData"

70        .Rows.Alignment = wdAlignRowCenter
80        .Rows.WrapAroundText = False

90        .LeftPadding = doc.Application.InchesToPoints(0.08)
100       .RightPadding = doc.Application.InchesToPoints(0.08)
110       .TopPadding = doc.Application.InchesToPoints(0.02)
          
' 90        .Rows.HorizontalPosition = doc.Application.InchesToPoints(0.08)
          
120       .columns(1).Width = doc.Application.InchesToPoints(2.34)
130       .columns(2).Width = doc.Application.InchesToPoints(1)
140       .columns(3).Width = doc.Application.InchesToPoints(1)
150       .columns(4).Width = doc.Application.InchesToPoints(1)
160       .columns(5).Width = doc.Application.InchesToPoints(1)
170       .Cell(1, 2).range.Text = "Priority A"
180       .Cell(1, 3).range.Text = "Priority B"
190       .Cell(1, 4).range.Text = "Priority C"
200       .Cell(1, 5).range.Text = "Priority D"
210       .Cell(2, 1).range.Text = "Number of species in category"
220       .Cell(3, 1).range.Text = "Number of species observed"
230       .Cell(4, 1).range.Text = "Number of species banded"
240       .Cell(5, 1).range.Text = "Number of individuals banded"
          
          ' Format Header Row
          
250       Call FormatWordTableRowAsHeader(.Rows(1))
        
          ' Format Column 1
          
260       For row = 1 To 5
270           .Cell(row, 1).range.Style = "ddLabelsColumn"
280       Next

          ' Draw a line at the bottom of the table
          
290       .Rows(5).Borders(wdBorderBottom).LineStyle = wdLineStyleSingle

' Repeat heading row at the top of subsequent pages

300   .Rows(1).HeadingFormat = True
310   .Rows.WrapAroundText = False

320   End With

      'DD Error Handler Start
Exit_label:
330        Exit Sub
Err_label:
340        Select Case Err.Number
           Case Else
350       Call LogError("Form_frmDevbasMBOAnnualProgramReportTable4_5_PrioritySpecieselopersTests", "WordGenerateTablePrioritySpecies")
360        End Select
370        Resume Exit_label
      'DD Error Handler End



End Sub
