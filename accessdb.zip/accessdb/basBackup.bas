Option Compare Database
Option Explicit

' If we are running on David's computer AND fDebug = True, create the backup in the same folder as the database
' If we are running on David's computer AND fDebug = False, do not backup
' If we are not running on David's computer, create the backup in the Google Drive Replication folder


Const fDebug As Boolean = True

''---------------------------------------------------------------------------------------
'' backup
''
'' I no longer backup from within the MBO Database program
''---------------------------------------------------------------------------------------



'---------------------------------------------------------------------------------------
' Export
'
' Returns strTargetFilepath - the filepath to the database file
' if no database file was created, strTargetFilepath = ""
'---------------------------------------------------------------------------------------
 
Private Sub Export( _
    ByVal strTargetFolderpath As String, _
    ByVal strVersion As String, _
    ByVal fDavid_PC As Boolean, _
    ByRef strTargetFilename As String, _
    ByRef strTargetFilepath As String, _
    ByRef strTimestamp As String)

10    On Error GoTo Err_label

      Dim ws As Workspace
      Dim db As Database

20    If fDavid_PC Then
30        If fDebug Then
40            strTargetFolderpath = CurrentProject.path
50        Else
          
          ' Skip if running on David's computer
          
60            strTargetFilepath = ""
70            GoTo Exit_label
80        End If
90    Else
          
100       If Not FolderExists(strTargetFolderpath) Then
110           Call LogError("basLoadTables", "Export", strTargetFolderpath & " - Target does not exist", Silent:=True)
120           GoTo Exit_label
130       End If

140   End If

150   strTimestamp = Format(Now(), "yyyy-mm-dd hh\hnn\mss")
160   strTargetFilename = strTimestamp & " MBO Data Tables " & IIf(strVersion = "", "", "v" & strVersion) & ".accdb"
170   strTargetFilepath = strTargetFolderpath & "\" & strTargetFilename

      ' If the target file exists then destroy it

180   If FileExists(strTargetFilepath) Then
190       On Error Resume Next
200       Kill strTargetFilepath
210       On Error GoTo Exit_label
220   End If

      ' create a new target database

230   Set ws = DBEngine.Workspaces(0)
240   Set db = ws.CreateDatabase(strTargetFilepath, dbLangGeneral)

      ' Copy ALL data tables
      '   Skip system tables
      '   Skip tables whose name end in "_Backup"

      Dim tbl As DAO.TableDef
      Dim strTablename As String

250   For Each tbl In CurrentDb.TableDefs
260       strTablename = tbl.Name
270       If Left(strTablename, 1) <> "~" And Left(strTablename, 4) <> "MSys" And Right(strTablename, 7) <> "_Backup" And Right(strTablename, 5) <> "_Temp" Then
           
280           SysCmd acSysCmdSetStatus, strTablename
              
              ' Export a table
              
290           On Error GoTo Err_label
300           DoCmd.TransferDatabase acExport, "Microsoft Access", strTargetFilepath, acTable, strTablename, strTablename, False
310           If Err.Number <> 0 Then
320               MsgBox "Failed to export to " & strTargetFilepath & " - Table: " & strTablename
330               GoTo Exit_label
340           End If
350       End If
360   Next


370   db.Close
380   Set db = Nothing

390   Set ws = Nothing

400   SysCmd acSysCmdClearStatus

          'DD Error Handler Start
Exit_label:
410       Exit Sub
Err_label:
420       Select Case Err.Number
          Case Else
430      Call LogError("basBackup", "Export")
440       End Select
450       Resume Exit_label
          ' DD Error Handler End

End Sub




'---------------------------------------------------------------------------------------
' IfLiveDataEntryVerifyBackupFolderExists
'---------------------------------------------------------------------------------------
' There are two possible outcomes
' The user has chosen "Data entry from sheets" OR
' ( the user has chose "Live data entry" AND the backup folder exists)

' strDataEntrySource = "Live" OR "FromSheets"
' strFolderpath  -- the folder exists, if strDataEntrySource = "Live"

'---------------------------------------------------------------------------------------
' IfLiveDataEntryVerifyBackupFolderExists
'---------------------------------------------------------------------------------------

Public Sub IfLiveDataEntryVerifyBackupFolderExists(ByRef strDataEntrySource As String, ByRef strUSBFlashDriveBackupFolder As String)

10       On Error GoTo Err_label
         
      ' Possible values for GetDataEntrySource()
      ' ----------------------------------------
      ' Live
      ' FromSheets
         
20    strDataEntrySource = GetDataEntrySource()

30    If (strDataEntrySource = "Live") Then
           
          ' LOOP
          '   Get the USB Flash Drive Folder
          '   Verify the USB Flash Drive Folder exists
          '   If the  USB Flash Drive Folder exists
          '      Return
          '   If the USB Flash Drive Folder does not exist
          '      Prompt for a path
          '      Cancel => Change the Data Entry Source to "FromSheets"
          ' END LOOP

40        strUSBFlashDriveBackupFolder = GetSettingEx("USBFlashDriveBackupFolder")

50        Do While True
60            If FolderExists(strUSBFlashDriveBackupFolder) Then
70                Call PutSettingEx("USBFlashDriveBackupFolder", strUSBFlashDriveBackupFolder)
80                Exit Do
90            Else
100               DoCmd.OpenForm "frmBackupUSBFlashDriveFolderpath", acNormal, , , , acDialog


                  
                  
      '            If vbOK <> MsgBox("The USB flash drive backup folder " & strUSBFlashDriveBackupFolder & " does not exist" & vbCrLf & _
      '                "Click OK if you would like to try again (perhaps there was no choose a USB flash drive backup folder" & vbCrLf & _
      '                "Click Cancel if you are not doing ""Live"" data entry", vbOKCancel, "Backup") Then
      '                strDataEntrySource = "FromSheets"
      '                PutDataEntrySource ("FromSheets")
      '                Exit Do
      '            End If
      '            msgbox "x",
                  Dim strUSBFlashDriveBackupFolder_Save As String
110               strUSBFlashDriveBackupFolder_Save = strUSBFlashDriveBackupFolder
                  
120               strUSBFlashDriveBackupFolder = GetFolder("C:")
130               If strUSBFlashDriveBackupFolder = "" Then
140                   strUSBFlashDriveBackupFolder = strUSBFlashDriveBackupFolder_Save
150               End If
                  
                  ' Let's try again
                  
160           End If
170       Loop

180   End If


          'DD Error Handler Start
Exit_label:
190       Exit Sub
Err_label:
200       Select Case Err.Number
          Case Else
210            Call LogError("basBackup", "IfLiveDataEntryVerifyBackupFolderExists")
220       End Select
230       Resume Exit_label
          ' DD Error Handler End
End Sub

'Public Sub Test_IfLiveDataEntryVerifyBackupFolderExists()
'
'Dim strDataEntrySource As String
'Dim strUSBFlashDriveBackupFolder As String
'Call IfLiveDataEntryVerifyBackupFolderExists(strDataEntrySource, strUSBFlashDriveBackupFolder)
'
'End Sub
