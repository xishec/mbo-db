'---------------------------------------------------------------------------------------
' Module    : basMBOAnnualProgramReportTableA
' Author    : David Davey
'---------------------------------------------------------------------------------------

Const conSpringTableA       As Integer = 0
Const conFallTableA         As Integer = 1
Const conMaxWeeks           As Integer = 14

Const conStatTableA_MeanBirdsPerDay As Integer = 0
Const conStatTableA_DaysObserved    As Integer = 1
Const conStatTableA_Processed       As Integer = 2

' Seasons

Const conNonSeason As Integer = -1
Const conWinter  As Integer = 0
Const conSpring  As Integer = 1
Const conSummer  As Integer = 2
Const conFall    As Integer = 3
Const conOwling  As Integer = 4
Const conRTHU    As Integer = 5
Const conNestbox As Integer = 6
Const conSummerNestbox As Integer = 7

Const conDETSeasonFirst As Integer = -1
Const conDETSeasonLast  As Integer = 3

Const intSeasonFirst As Integer = -1
Const intSeasonLast  As Integer = 7


' A statistic is a capture day statistic, a census day statistic, a DET day statistic, or a DET or capture day statistic
' A capture day statistic is measured iff the day is a capture day
' etc

' Public Function getStatDays(ByVal intStat As Integer) As Integer

' Season x Year x Period statistics
' ---------------------------------

'Public dblStatSeasonYearPeriod() As Double  ' (intStatFirst To intStatLast, intSeasonFirst To intSeasonLastEx, _
'                                            '  intYearFirst To intYearLastEx, 1 To intPeriodLastEx)


' =========================================================================================================
' tblMBOAnnualProgramReportTableA_DETSpecies is a modifed version of tblDETSpecies
' where LSGO, GSGO, SNGO => SNGO
'       ALFL, WIFL are as in tblDETSpecies
'       TRFL, ALFL, WIFL => TRFL
'       "UNSG","UNAC","UNEM","UNGU","UNSC","PAWA","UNPW" have been deleted
' tblMBOAnnualProgramReportTableA_DETSpecies only includes records for a specified report year
'                                            it contains records for Spring and Fall

' tblMBOAnnualProgramReportTableA is
' tblMBOAnnualProgramReportTableA_DETSpecies + related fields from tblSpecies and tblPrograms
' SpeciesEnglish = SpeciesDescriptionMBO
' SpeciesFrench
' SpeciesScientific
' AOUOrder
' Week: toPeriod([Season],[DateEx],[DateFrom])
' DaysObserved  (will always be 1)
' ==========================================================================================================


' tblMBOAnnualProgramReportTableA_DETSpecies
' ------------------------------------------
' YearEx
' Season
' Program
' Location
' DateEx
' Species
' DET
' Banded
' Returns
' Repeats

' qryMBOAnnualProgramReportTableA_DETSpecies_Append
' -------------------------------------------------
' Append Query => tblMBOAnnualProgramReportTableA_DETSpecies
' ----------------------------------------------------------
' tblDETSpecies x tblPrograms
'
' YearEx = [argYearEx]
' Location = [argLocation]
' Program
' Season = FIRST MonitoringProgramSeason In ('Spring','Fall')
' GROUP BY  Program
' GROUP BY Location = [argLocation]
' GROUP BY DateEx
' GROUP BY Species Not In ("TRFL", "LSGO","GSGO","SNGO","UNSG","UNAC","UNEM","UNGU","UNSC","PAWA","UNPW")
' SUM = SUM DET
' Banded = SUM Banded
' Returns = SUM Returns
' Repeats = SUM Repeats
'
' NB we remove TRFL but let ALFL and WIFL through. We add "TRFL" below

' qryMBOAnnualProgramReportTableA_DETSpecies_SNGO_Append
' ------------------------------------------------------
' tblDETSpecies x tblPrograms
'
' YearEx = [argYearEx]
' Season = MonitoringProgramSeason In ('Spring','Fall')
' GROUP BY  Program
' GROUP BY Location = [argLocation]
' GROUP BY DateEx
' WHERE Species In ("SNGO","GSGO","LSGO")
' DET = SUM DET
' Banded = SUM Banded
' Returns = SUM Returns
' Repeats = SUM Repeats

' qryMBOAnnualProgramReportTableA_DETSpecies_SNGO_Append
' ------------------------------------------------------
' Append Query => tblMBOAnnualProgramReportTableA_DETSpecies
' ----------------------------------------------------------
' qryMBOAnnualProgramReportTableA_DETSpecies_SNGO_Append
'
' YearEx
' Season
' Program
' Location
' Species = "SNGO"
' DET
' Banded
' Returns
' Repeats

' qryMBOAnnualProgramReportTableA_DETSpecies_TRFL
' qryMBOAnnualProgramReportTableA_DETSpecies_TRFL_Append
' ------------------------------------------------------
' As for SNGO but  Species In ("ALFL","WIFL")


' tblMBOAnnualProgramReportTableA
' -------------------------------
' YearEx
' Season
' Program
' Location
' Species
' SpeciesEnglish
' SpeciesFrench
' AOUOrder
' Week
' DET
' Banded
' Returns
' Repeats
' DateEx

' qryMBOAnnualProgramReportTableA
' -------------------------------
' Append Query => tblMBOAnnualProgramReportTableA
' -------------------------------------------------------
' tblMBOAnnualProgramReportTableA_DETSpecies x tblSpecies
'
' GROUP BY YearEx
' GROUP BY Season
' GROUP BY Program
' GROUP BY Location
' GROUP BY Species
' SpeciesEnglish = GROUP BY SpeciesDescriptionMBO
' GROUP BY SpeciesFrench
' GROUP BY SpeciesScientific
' GROUP BY AOUOrder
' Week = GROUP BY Period =  Int(1+([DateEx]-[DateFrom])/7)
' DET = SUM DET
' Banded = SUM Banded
' Returns = SUM Returns
' Repeats = SUM Repeats
' GROUP BY DateEx

' =============================================================================

' Maximum weeks in each season

Private intMaxWeeksTableA(conSpringTableA To conFallTableA) As Integer
Private intMaxWeeks As Integer  ' max(intMaxWeeksTableA(conSpringTableA),intMaxWeeksTableA(conFallTableA))

Option Compare Database
Option Explicit

'    DET(conSpringTableA To conFallTableA, 1 To conMaxWeeks) As Integer
'    Banded(conSpringTableA To conFallTableA, 1 To conMaxWeeks) As Integer
'    Returns(conSpringTableA To conFallTableA, 1 To conMaxWeeks) As Integer
'    Repeats(conSpringTableA To conFallTableA, 1 To conMaxWeeks) As Integer
'    DaysObserved(conSpringTableA To conFallTableA, 1 To conMaxWeeks) As Integer

Private Type MBOAnnualProgramReportTableAData
    Species As String
    SpeciesCode As String       ' True species code.  Filled iff different from Species
    SpeciesEnglish As String    ' not used
    SpeciesFrench As String
    SpeciesScientific As String
    DET() As Integer
    Banded() As Integer
    Returns() As Integer
    Repeats() As Integer
    DaysObserved() As Integer
    PseudospeciesEnglish As String   ' SpeciesDescriptionMBO
End Type

Private intYear As Integer
Private strLocation As String
Private strSpringProgram As String
Private strFallProgram As String

Private data As MBOAnnualProgramReportTableAData
Dim strDetailData() As String ' (conSpringTableA To conFallTableA, 1 To conMaxWeeks)

'---------------------------------------------------------------------------------------
' MBOAnnualProgramReportTableA
'---------------------------------------------------------------------------------------
 
Public Sub MBOAnnualProgramReportTableA( _
    ByRef fValid As Boolean, _
    ByVal argYear As Integer, _
    ByVal argLocation As String, _
    ByVal argSpringProgram As String, _
    ByVal argFallProgram As String, _
    ByRef wd As Word.Application, _
    ByRef doc As Word.Document, _
    ByRef oExcel As Excel.Application, _
    ByRef oBook As Excel.Workbook, _
    ByRef strListOfSpecies() As String, _
    Optional ByVal strSpecialCase As String = "")
          
10    On Error GoTo Err_label

20    SysCmd acSysCmdSetStatus, "Appendix A - Species"

'    wd.Visible = True

      ' Save parameters

30    intYear = argYear
40    strLocation = argLocation
50    strSpringProgram = argSpringProgram
60    strFallProgram = argFallProgram

70    intMaxWeeksTableA(conSpringTableA) = intPeriodLast_Season(conSpring)
80    intMaxWeeksTableA(conFallTableA) = intPeriodLast_Season(conFall)

90    intMaxWeeks = IIf(intMaxWeeksTableA(conSpringTableA) > intMaxWeeksTableA(conFallTableA), _
          intMaxWeeksTableA(conSpringTableA), intMaxWeeksTableA(conFallTableA))

100   ReDim data.DET(conSpringTableA To conFallTableA, 1 To intMaxWeeks) As Integer
110   ReDim data.Banded(conSpringTableA To conFallTableA, 1 To intMaxWeeks) As Integer
120   ReDim data.Returns(conSpringTableA To conFallTableA, 1 To intMaxWeeks) As Integer
130   ReDim data.Repeats(conSpringTableA To conFallTableA, 1 To intMaxWeeks) As Integer
140   ReDim data.DaysObserved(conSpringTableA To conFallTableA, 1 To intMaxWeeks) As Integer

150   ReDim strDetailData(conSpringTableA To conFallTableA, conStatTableA_MeanBirdsPerDay To conStatTableA_Processed, 1 To intMaxWeeks) As String
        
160   fValid = True

170   Call MBOAnnualProgramReportTableAGenerate(strListOfSpecies, strSpecialCase)   ' Generate the data

      ' Count the species

      Dim lngTotalSpecies As Long
      Dim lngCountSpecies As Long
180   lngTotalSpecies = DCount("*", "qryMBOAnnualProgramReportTableACountSpecies", "True")
190   lngCountSpecies = 1

      Dim rst As DAO.Recordset
      Dim strSQL As String
200   strSQL = "SELECT * FROM tblMBOAnnualProgramReportTableA order by AOUOrder, DateEx"
210   Set rst = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)

220   If rst.EOF Then
230       fValid = False
240       Exit Sub
250   End If

      Dim strSpeciesPrevious As String
260   strSpeciesPrevious = Nz(rst("Species"), "")
      Dim strSpecies As String

270   Call MBOAnnualProgramReportTableA_Header(rst)

      Dim i As Long
280   i = 1
290   Do While Not rst.EOF
300       strSpecies = Nz(rst("Species"), "")

310       If strSpecies <> strSpeciesPrevious Then

320           DoEvents
          
330           SysCmd acSysCmdSetStatus, strSpecies & " " & lngCountSpecies & " of  " & lngTotalSpecies
340           lngCountSpecies = lngCountSpecies + 1

'350           If i > 5 Then
'360               Exit Sub
'370           End If
350           i = i + 1
      '260           If i > 39 Then
360           Call MBOAnnualProgramReportTableA_Footer(doc)
      '280           End If
370           Call MBOAnnualProgramReportTableA_Header(rst)
380           strSpeciesPrevious = strSpecies
390       End If
400       Call MBOAnnualProgramReportTableA_Detail(rst)
410       rst.MoveNext
420   Loop
430   Call MBOAnnualProgramReportTableA_Footer(doc)
440   rst.Close

450   SysCmd acSysCmdClearStatus

      'DD Error Handler Start
Exit_label:
460        Exit Sub
Err_label:
470        Select Case Err.Number
           Case Else
480             Call LogError("basMBOAnnualProgramReportTableA", "MBOAnnualProgramReportTableA")
490        End Select
500        Resume Exit_label
      'DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' WordGenerateTableA
' Called for each species
'---------------------------------------------------------------------------------------
' entry:  range = a collapsed range that is the insertion point for the table
' exit:   range = range that includes the 2 tables

Private Sub WordGenerateTableA( _
    ByRef doc As Word.Document, _
    ByRef range As Word.range)
          
10    On Error GoTo Err_label

      Dim row As Integer
      Dim col As Integer
      Dim colTotal As Integer

      ' Spring

20    colTotal = intMaxWeeksTableA(conSpringTableA) + 2

30    doc.Tables.Add range:=range, NumRows:=6, NumColumns:=colTotal
40    range.Expand (wdTable)

50    With range.Tables(1)

60        .range.Style = "ddSpeciesData"
70        .LeftPadding = doc.Application.InchesToPoints(0.02)
80        .RightPadding = doc.Application.InchesToPoints(0.02)
90        .TopPadding = doc.Application.InchesToPoints(0.02)
          
      '100       For row = 3 To 5
      '110           .Cell(row, 1).LeftPadding = doc.Application.InchesToPoints(0.02)
      '120           .Cell(row, 1).RightPadding = doc.Application.InchesToPoints(0.02)
      '130       Next

100      .Rows(1).Shading.BackgroundPatternColor = RGB(191, 191, 191)

110       For col = 2 To colTotal
120           .Cell(2, col).Shading.BackgroundPatternColor = RGB(217, 217, 217)
130       Next
          
140       For row = 3 To 5
150           .Cell(row, 1).Shading.BackgroundPatternColor = RGB(191, 191, 191)
160       Next
          
      '    .Borders.Enable = True
          
170       For row = 1 To 6
180           .Rows(row).Borders(wdBorderTop).LineStyle = wdLineStyleSingle
190       Next
200       .Rows.Borders(wdBorderBottom).LineStyle = wdLineStyleSingle
210       For col = 1 To colTotal
220           .columns(col).Borders(wdBorderLeft).LineStyle = wdLineStyleSingle
230       Next
240       .columns(colTotal).Borders(wdBorderRight).LineStyle = wdLineStyleSingle
250       .Cell(2, 1).Borders(wdBorderLeft).LineStyle = wdLineStyleNone
260       .Cell(6, 1).Borders(wdBorderLeft).LineStyle = wdLineStyleNone
270       .Cell(6, 1).Borders(wdBorderBottom).LineStyle = wdLineStyleNone

280       .Rows.HorizontalPosition = wdAlignRowCenter

          Dim dblWeekWidth As Double
290       dblWeekWidth = Round((7.05 - 0.77 - 0.47) / (colTotal - 2), 3)

          Dim dblCumulativeWidthInPoints As Double
300       dblCumulativeWidthInPoints = 0

310       .columns(1).Width = doc.Application.InchesToPoints(0.77)
320       dblCumulativeWidthInPoints = .columns(1).Width
          
330       For col = 2 To colTotal - 1
340           .columns(col).Width = doc.Application.InchesToPoints(dblWeekWidth)
350           dblCumulativeWidthInPoints = dblCumulativeWidthInPoints + .columns(col).Width
360       Next

370       .columns(colTotal).Width = doc.Application.InchesToPoints(0.47)
380       dblCumulativeWidthInPoints = dblCumulativeWidthInPoints + .columns(colTotal).Width
          
      '410       .Columns(colTotal).Width = doc.Application.InchesToPoints(7.09) - dblCumulativeWidthInPoints

390       .Cell(1, 4).Merge .Cell(1, colTotal)
400       .Cell(1, 1).Width = doc.Application.InchesToPoints(0.77 + (CDbl(4) / 7) * dblWeekWidth)
410       .Cell(1, 2).Width = doc.Application.InchesToPoints((CDbl(30) / 7) * dblWeekWidth)
420       .Cell(1, 3).Width = doc.Application.InchesToPoints((CDbl(31) / 7) * dblWeekWidth)
430       .Cell(1, 4).Width = dblCumulativeWidthInPoints - doc.Application.InchesToPoints(0.77 + (CDbl(4 + 30 + 31) / 7) * dblWeekWidth)
440       .Cell(6, 5).Merge .Cell(6, colTotal)
450       .Cell(6, 2).Width = doc.Application.InchesToPoints(1.5)
460       .Cell(6, 3).Width = doc.Application.InchesToPoints(1.5)
470       .Cell(6, 4).Width = doc.Application.InchesToPoints(1.5)
480       .Cell(6, 5).Width = dblCumulativeWidthInPoints - doc.Application.InchesToPoints(0.77 + 1.5 + 1.5 + 1.5)
          
490       .Rows(1).range.Style = "ddSpeciesHeaderRow1"
500       .Rows(2).range.Style = "ddSpeciesHeaderRow2"

510       For row = 3 To 5
520           .Cell(row, 1).range.Style = "ddSpeciesLabelsColumn"
530       Next
540       .Rows(6).range.Style = "ddSpeciesLastRow"

          
550       .Cell(1, 1).range.Text = "MARCH"
560       .Cell(1, 2).range.Text = "APRIL"
570       .Cell(1, 3).range.Text = "MAY"
580       .Cell(1, 4).range.Text = "JUNE"
590       For col = 2 To colTotal - 1
600           .Cell(2, col).range.Text = "WEEK " & col - 1
610       Next
620       .Cell(2, colTotal).range.Text = "TOTAL"
630       .Cell(3, 1).range.Text = "# BIRDS / DAY"
640       .Cell(4, 1).range.Text = "# DAYS OBSERVED"
650       .Cell(5, 1).range.Text = "# PROCESSED"

660       For row = 2 To 5
670           .Cell(row, colTotal).range.Bold = True
680       Next
          
690   End With

      Dim rangeInsertionPoint As Word.range

700   Set rangeInsertionPoint = range.Duplicate
710   rangeInsertionPoint.Collapse (wdCollapseEnd)

720   rangeInsertionPoint.InsertParagraphAfter
730   rangeInsertionPoint.Style = "ddSpeciesBetweenTables"
740   range.Expand (wdParagraph)

      ' Fall

750   colTotal = intMaxWeeksTableA(conFallTableA) + 2

760   Set rangeInsertionPoint = range.Duplicate
770   rangeInsertionPoint.Collapse (wdCollapseEnd)

780   doc.Tables.Add range:=rangeInsertionPoint, NumRows:=6, NumColumns:=colTotal
790   range.Expand (wdTable)

800   With range.Tables(2)

810       .range.Style = "ddSpeciesData"
820       .LeftPadding = doc.Application.InchesToPoints(0.02)
830       .RightPadding = doc.Application.InchesToPoints(0.02)
840       .TopPadding = doc.Application.InchesToPoints(0.02)
          
      '850       For row = 3 To 5
      '860           .Cell(row, 1).LeftPadding = doc.Application.InchesToPoints(0.08)
      '870           .Cell(row, 1).RightPadding = doc.Application.InchesToPoints(0.08)
      '880       Next

850       For col = 2 To colTotal
860           .Cell(1, col).Shading.BackgroundPatternColor = RGB(191, 191, 191)
870           .Cell(2, col).Shading.BackgroundPatternColor = RGB(217, 217, 217)
880       Next
          
890       For row = 3 To 5
900           .Cell(row, 1).Shading.BackgroundPatternColor = RGB(191, 191, 191)
910       Next

      '    .Borders.Enable = True
          
920       For row = 1 To 6
930           .Rows(row).Borders(wdBorderTop).LineStyle = wdLineStyleSingle
940       Next
950       .Rows.Borders(wdBorderBottom).LineStyle = wdLineStyleSingle
960       For col = 1 To colTotal
970           .columns(col).Borders(wdBorderLeft).LineStyle = wdLineStyleSingle
980       Next
990       .columns(colTotal).Borders(wdBorderRight).LineStyle = wdLineStyleSingle
1000      .Cell(1, 1).Borders(wdBorderTop).LineStyle = wdLineStyleNone
1010      .Cell(1, 1).Borders(wdBorderLeft).LineStyle = wdLineStyleNone
1020      .Cell(1, 1).Borders(wdBorderBottom).LineStyle = wdLineStyleNone
1030      .Cell(2, 1).Borders(wdBorderLeft).LineStyle = wdLineStyleNone
1040      .Cell(6, 1).Borders(wdBorderLeft).LineStyle = wdLineStyleNone
1050      .Cell(6, 1).Borders(wdBorderBottom).LineStyle = wdLineStyleNone

1060      .Rows.HorizontalPosition = wdAlignRowCenter

      '    Dim dblWeekWidth As Double
1070      dblWeekWidth = Round((7.05 - 0.77 - 0.47) / (colTotal - 2), 3)

      '    Dim dblCumulativeWidthInPoints As Double
1080      dblCumulativeWidthInPoints = 0

1090      .columns(1).Width = doc.Application.InchesToPoints(0.77)
1100      dblCumulativeWidthInPoints = .columns(1).Width
          
1110      For col = 2 To colTotal - 1
1120          .columns(col).Width = doc.Application.InchesToPoints(dblWeekWidth)
1130          dblCumulativeWidthInPoints = dblCumulativeWidthInPoints + .columns(col).Width
1140      Next

1150      .columns(colTotal).Width = doc.Application.InchesToPoints(0.47)
1160      dblCumulativeWidthInPoints = dblCumulativeWidthInPoints + .columns(colTotal).Width

          
      '1190      .Columns(colTotal).Width = doc.Application.InchesToPoints(7.09) - dblCumulativeWidthInPoints
                    
1170      .Cell(1, 5).Merge .Cell(1, (intMaxWeeksTableA(conFallTableA) + 2))
1180      .Cell(1, 1).Width = doc.Application.InchesToPoints(0.77)
1190      .Cell(1, 2).Width = doc.Application.InchesToPoints(dblWeekWidth * 4.429) ' AUG
1200      .Cell(1, 3).Width = doc.Application.InchesToPoints(dblWeekWidth * 4.286) ' SEP
1210      .Cell(1, 4).Width = doc.Application.InchesToPoints(dblWeekWidth * 4.429) ' OCT
1220      .Cell(1, 5).Width = dblCumulativeWidthInPoints - doc.Application.InchesToPoints(0.77 + dblWeekWidth * 13.144) ' NOV or none
1230      .Cell(6, 5).Merge .Cell(6, colTotal)
1240      .Cell(6, 2).Width = doc.Application.InchesToPoints(1.5)
1250      .Cell(6, 3).Width = doc.Application.InchesToPoints(1.5)
1260      .Cell(6, 4).Width = doc.Application.InchesToPoints(1.5)
1270      .Cell(6, 5).Width = dblCumulativeWidthInPoints - doc.Application.InchesToPoints(0.77 + 1.5 + 1.5 + 1.5)
          
1280      .Rows(1).range.Style = "ddSpeciesHeaderRow1"
1290      .Rows(2).range.Style = "ddSpeciesHeaderRow2"
       
1300      For row = 3 To 5
1310          .Cell(row, 1).range.Style = "ddSpeciesLabelsColumn"
1320      Next
1330      .Rows(6).range.Style = "ddSpeciesLastRow"

          
1340      .Cell(1, 2).range.Text = "AUGUST"
1350      .Cell(1, 3).range.Text = "SEPTEMBER"
1360      .Cell(1, 4).range.Text = "OCTOBER"
1370      If intMaxWeeksTableA(conFallTableA) >= 14 Then
1380          .Cell(1, 5).range.Text = "NOVEMBER"
1390      Else
1400          .Cell(1, 5).Shading.BackgroundPatternColor = vbWhite
1410          .Cell(1, 5).Borders(wdBorderTop).LineStyle = wdLineStyleNone
1420          .Cell(1, 5).Borders(wdBorderRight).LineStyle = wdLineStyleNone
1430      End If
          
1440      For col = 2 To colTotal - 1
1450          .Cell(2, col).range.Text = "WEEK " & col - 1
1460      Next
1470      .Cell(2, intMaxWeeksTableA(conFallTableA) + 2).range.Text = "TOTAL"
1480      .Cell(3, 1).range.Text = "# BIRDS / DAY"
1490      .Cell(4, 1).range.Text = "# DAYS OBSERVED"
1500      .Cell(5, 1).range.Text = "# PROCESSED"
          
1510      For row = 2 To 5
1520          .Cell(row, colTotal).range.Bold = True
1530      Next
          
      '1510      range.InsertParagraphAfter
      '1520      range.Expand (wdParagraph)

          Dim rangeExtraSpace As Word.range
          
1540      Set rangeExtraSpace = doc.Characters.Last
1550      rangeExtraSpace.InsertParagraphAfter
1560      rangeExtraSpace.Style = "ddBody"
1570      rangeExtraSpace.InsertParagraphAfter
1580      rangeExtraSpace.Style = "ddBody"
1590      rangeExtraSpace.InsertParagraphAfter
1600      rangeExtraSpace.Style = "ddBody"

          
1610  End With

      'DD Error Handler Start
Exit_label:
1620       Exit Sub
Err_label:
1630       Select Case Err.Number
           Case Else
1640            Call LogError("basMBOAnnualProgramReportTableA", "WordGenerateTableA")
1650       End Select
1660       Resume Exit_label
      'DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' MBOAnnualProgramReportTableAGenerate
'---------------------------------------------------------------------------------------
 
Private Sub MBOAnnualProgramReportTableAGenerate(ByRef strListOfSpecies() As String, ByVal strSpecialCase As String)

      ' ZAP tblMBOAnnualProgramReportTableA_DETSpecies and
      '     tblMBOAnnualProgramReportTableA

      Dim strSQL As String
10    On Error GoTo Err_label

          Dim datProgramOfficialStartDateSpring As Date
          Dim datProgramOfficialEndDateSpring As Date
          Dim datProgramOfficialStartDateFall As Date
          Dim datProgramOfficialEndDateFall As Date
          
20        datProgramOfficialStartDateSpring = datProgramOfficialStartDate_SeasonYear(conSpring, intYear)
30        datProgramOfficialEndDateSpring = datProgramOfficialStartDateSpring + 7 * intPeriodLast_SeasonYear(conSpring, intYear) - 1
40        datProgramOfficialStartDateFall = datProgramOfficialStartDate_SeasonYear(conFall, intYear)
50        datProgramOfficialEndDateFall = datProgramOfficialStartDateFall + 7 * intPeriodLast_SeasonYear(conFall, intYear) - 1
     



60    strSQL = "DELETE * FROM tblMBOAnnualProgramReportTableA_DETSpecies"
70    CurrentDb.Execute strSQL
80    strSQL = "DELETE * FROM tblMBOAnnualProgramReportTableA"
90    CurrentDb.Execute strSQL

      ' Load tblMBOAnnualProgramReportTableA_DETSpecies and
      '      tblMBOAnnualProgramReportTableA

      Dim qdf As DAO.QueryDef

100   Select Case strSpecialCase
      Case ""

110       If Len(strListOfSpecies(0)) = 0 Then
          
120           Set qdf = CurrentDb.QueryDefs("qryMBOAnnualProgramReportTableA_DETSpecies_Append")
130           qdf.Parameters("argYearEx") = intYear
140           qdf.Parameters("argLocation") = strLocation
150           qdf.Execute
              
160           Set qdf = CurrentDb.QueryDefs("qryMBOAnnualProgramReportTableA_DETSpecies_SNGO_Append")
170           qdf.Parameters("argYearEx") = intYear
180           qdf.Parameters("argLocation") = strLocation
190           qdf.Execute
              
200           Set qdf = CurrentDb.QueryDefs("qryMBOAnnualProgramReportTableA_DETSpecies_TRFL_Append")
210           qdf.Parameters("argYearEx") = intYear
220           qdf.Parameters("argLocation") = strLocation
230           qdf.Execute
                
240       ElseIf UBound(strListOfSpecies) = 0 Then

250           Set qdf = CurrentDb.QueryDefs("qryMBOAnnualProgramReportTableA_DETSpecies_species_Append")
260           qdf.Parameters("argYearEx") = intYear
270           qdf.Parameters("argLocation") = strLocation
280           qdf.Parameters("argSpecies") = strListOfSpecies(0)
290           qdf.Execute
300       Else


              Dim i As Integer
310           For i = 0 To UBound(strListOfSpecies)
320               Set qdf = CurrentDb.QueryDefs("qryMBOAnnualProgramReportTableA_DETSpecies_species_Append")
330               qdf.Parameters("argYearEx") = intYear
340               qdf.Parameters("argLocation") = strLocation
350               qdf.Parameters("argSpecies") = strListOfSpecies(i)
360               qdf.Execute
370           Next
380       End If
          
390   Case "RTHU"

          ' qryAnnualReportTableA_DETSpecies_RTHU_Spring_Append
          ' -----------------------------------------------------
          ' tblDETSpecies x tbpPrograms
          '
          ' WHERE Location = [argLocation]
          ' WHERE DateEx BETWEEN [argDateFirst] and [argDateLast]
          ' WHERE YeraEx = [argYear]
          ' WHERE Species = "RTHU"
          ' WHERE MonitoringProgramSeason IN ("Spring", "RTHU" )
          ' GROUP BY DateEx
          ' Season = "Spring"
          ' Banded = SUM Banded
          ' Repeats = SUM Repeats
          ' Returns = SUM Returns
          ' DET = SUM DET
          ' Program = [argProgram]
          
          ' qryAnnualReportTableA_DETSpecies_RTHU_Fall_Append
          ' ---------------------------------------------------------------------------
          ' Same as qryAnnualReportTableA_DETSpecies_RTHU_Spring_Append, but for Fall
          
         
          
440       Set qdf = CurrentDb.QueryDefs("qryAnnualReportTableA_DETSpecies_RTHU_Spring_Append")
450       qdf.Parameters("argLocation") = strLocation
460       qdf.Parameters("argDateFirst") = datProgramOfficialStartDateSpring
470       qdf.Parameters("argDateLast") = datProgramOfficialEndDateSpring
480       qdf.Parameters("argYear") = intYear
490       qdf.Parameters("argProgram") = strSpringProgram
500       qdf.Execute
          
          
510       Set qdf = CurrentDb.QueryDefs("qryAnnualReportTableA_DETSpecies_RTHU_Fall_Append")
520       qdf.Parameters("argLocation") = strLocation
530       qdf.Parameters("argDateFirst") = datProgramOfficialStartDateFall
540       qdf.Parameters("argDateLast") = datProgramOfficialEndDateFall
550       qdf.Parameters("argYear") = intYear
560       qdf.Parameters("argProgram") = strFallProgram
570       qdf.Execute

580   Case "Owling"

          ' Combine Owling with Fall
          ' Only report the species DETed during Owling
          
          ' For every species DETed in the report year's Owling program
          
          ' qryAnnualReportTableA_DETSpecies_Owling
          ' ---------------------------------------
          '
          
          
          
          

590       Set qdf = CurrentDb.QueryDefs("qryAnnualReportTableA_DETSpecies_Owling")
600       qdf.Parameters("argLocation").value = strLocation
610       qdf.Parameters("argYear").value = intYear
          Dim rst As DAO.Recordset
620       Set rst = qdf.OpenRecordset
630       Do While Not rst.EOF
          
              Dim strSpecies As String
640           strSpecies = Nz(rst("Species"))
          
650           Set qdf = CurrentDb.QueryDefs("qryAnnualReportTableA_DETSpecies_Owling_Spring_Append")
660           qdf.Parameters("argLocation") = strLocation
670           qdf.Parameters("argDateFirst") = datProgramOfficialStartDateSpring
680           qdf.Parameters("argDateLast") = datProgramOfficialEndDateSpring
690           qdf.Parameters("argYear") = intYear
700           qdf.Parameters("argProgram") = strSpringProgram
710           qdf.Parameters("argSpecies") = strSpecies
720           qdf.Execute
              
              
730           Set qdf = CurrentDb.QueryDefs("qryAnnualReportTableA_DETSpecies_Owling_Fall_Append")
740           qdf.Parameters("argLocation") = strLocation
750           qdf.Parameters("argDateFirst") = datProgramOfficialStartDateFall
760           qdf.Parameters("argDateLast") = datProgramOfficialEndDateFall
770           qdf.Parameters("argYear") = intYear
780           qdf.Parameters("argProgram") = strFallProgram
790           qdf.Parameters("argSpecies") = strSpecies
800           qdf.Execute
          
810           rst.MoveNext
820       Loop
830       rst.Close
840       Set rst = Nothing



850   End Select

860   Set qdf = CurrentDb.QueryDefs("qryMBOAnnualProgramReportTableA_Append")
870   qdf.Execute

      'DD Error Handler Start
Exit_label:
880        Exit Sub
Err_label:
890        Select Case Err.Number
           Case Else
900       Call LogError("basMBOAnnualProgramReportTableA", "MBOAnnualProgramReportTableAGenerate")
910        End Select
920        Resume Exit_label
      'DD Error Handler End

End Sub



'---------------------------------------------------------------------------------------
' MBOAnnualProgramReportTableA_Header
'---------------------------------------------------------------------------------------
 
Private Sub MBOAnnualProgramReportTableA_Header(ByRef rst As DAO.Recordset)
10    On Error GoTo Err_label

      Dim indexSeason As Integer
      Dim indexWeek As Integer

      ' Initialise data

20    data.Species = Nz(rst("Species"), "")
30    data.SpeciesCode = Nz(rst("SpeciesCode"), "")
      'data.SpeciesEnglish = Nz(rst("SpeciesEnglish"), "")
      'If data.SpeciesEnglish = "" Then
      '    data.SpeciesEnglish = Nz(rst("SubspeciesEnglish"), "")
      'End If
40    data.PseudospeciesEnglish = Nz(rst("PseudoSpeciesEnglish"))
50    data.SpeciesFrench = Nz(rst("SpeciesFrench"), "")
60    data.SpeciesScientific = Nz(rst("SpeciesScientific"), "")

70    For indexSeason = conSpringTableA To conFallTableA
80        For indexWeek = 1 To intMaxWeeksTableA(indexSeason)
90            data.DET(indexSeason, indexWeek) = 0
100           data.Banded(indexSeason, indexWeek) = 0
110           data.Returns(indexSeason, indexWeek) = 0
120           data.Repeats(indexSeason, indexWeek) = 0
130           data.DaysObserved(indexSeason, indexWeek) = 0
140       Next indexWeek
150   Next indexSeason

      'DD Error Handler Start
Exit_label:
160        Exit Sub
Err_label:
170        Select Case Err.Number
           Case Else
180             Call LogError("basMBOAnnualProgramReportTableA", "MBOAnnualProgramReportTableA_Header")
190        End Select
200        Resume Exit_label
      'DD Error Handler End
          
End Sub

'---------------------------------------------------------------------------------------
' MBOAnnualProgramReportTableA_Detail
'---------------------------------------------------------------------------------------
 
Private Sub MBOAnnualProgramReportTableA_Detail(ByRef rst As DAO.Recordset)

      Dim strSeason As String
      Dim intSeason As String
      Dim intWeek As Integer
      Dim intBanded As Integer
      Dim intReturns As Integer
      Dim intRepeats As Integer
      Dim intDET As Integer
      Dim intDaysObserved As Integer

10    On Error GoTo Err_label

20    strSeason = Nz(rst("Season"), "")
30    intWeek = Nz(rst("Week"), 0)
40    intBanded = Nz(rst("Banded"), 0)
50    intReturns = Nz(rst("Returns"), 0)
60    intRepeats = Nz(rst("Repeats"), 0)
70    intDET = Nz(rst("DET"), 0)

80    Select Case strSeason
      Case "Spring"
90        intSeason = conSpringTableA
100   Case "Fall"
110       intSeason = conFallTableA
120   End Select

130   data.Banded(intSeason, intWeek) = data.Banded(intSeason, intWeek) + intBanded
140   data.Returns(intSeason, intWeek) = data.Returns(intSeason, intWeek) + intReturns
150   data.Repeats(intSeason, intWeek) = data.Repeats(intSeason, intWeek) + intRepeats
160   data.DET(intSeason, intWeek) = data.DET(intSeason, intWeek) + intDET
170   data.DaysObserved(intSeason, intWeek) = data.DaysObserved(intSeason, intWeek) + 1

      'DD Error Handler Start
Exit_label:
180        Exit Sub
Err_label:
190        Select Case Err.Number
           Case Else
200             Call LogError("basMBOAnnualProgramReportTableA", "MBOAnnualProgramReportTableA_Detail")
210        End Select
220        Resume Exit_label
      'DD Error Handler End
          
End Sub

'---------------------------------------------------------------------------------------
' MBOAnnualProgramReportTableA_Footer
' Called for each species
'---------------------------------------------------------------------------------------
 
Private Sub MBOAnnualProgramReportTableA_Footer(ByRef doc As Word.Document)
10    On Error GoTo Err_label

      '  Generate the title

      ' Special case for Canada Goose. Replace CAGO with CANG

20    If data.Species = "CAGO" Then
30        data.Species = "CANG"
40    End If

      Dim strTitle As String

      ' If there is a true species code then output "<true species code> (<pseudospecies code>):  <pseudospecies English name>"
      ' Otherwise output "<pseudospecies code>:  <pseudospecies English name>"

50    If data.SpeciesCode <> "" And (data.SpeciesCode <> data.Species) Then
60        strTitle = data.SpeciesCode & " (" & data.Species & "):  " & data.PseudospeciesEnglish
70    Else
80        strTitle = data.Species & ":  " & data.PseudospeciesEnglish
90    End If

100   If data.SpeciesFrench <> "" Then
110       strTitle = strTitle & " / " & data.SpeciesFrench
120   End If
130   If data.SpeciesScientific <> "" Then
140       strTitle = strTitle & " (" & data.SpeciesScientific & ")"
150   End If

      Dim range As Word.range

160   Set range = doc.Characters.Last
170   range.InsertAfter strTitle
180   range.InsertParagraphAfter
190   range.Style = "ddSpeciesTitle"

      ' Appendix A (Species)

200   Set range = doc.Characters.Last
210   Call WordGenerateTableA(doc, range)
                                                
      ' Initialise strDetailData

      Dim intSeasonTableA As Integer
      
      
      Dim intStatTableA As Integer
      Dim intWeek As Integer

220   For intSeasonTableA = conSpringTableA To conFallTableA
230       For intStatTableA = conStatTableA_MeanBirdsPerDay To conStatTableA_Processed
240           For intWeek = 1 To intMaxWeeksTableA(intSeasonTableA)
250               strDetailData(intSeasonTableA, intStatTableA, intWeek) = ""
260           Next
270       Next
280   Next

      Dim lngTotalBirds(conSpringTableA To conFallTableA) As Long

290   lngTotalBirds(conSpringTableA) = 0
300   lngTotalBirds(conFallTableA) = 0

      ' Dim intWeek As Integer

310   For intSeasonTableA = conSpringTableA To conFallTableA
320       For intWeek = 1 To intMaxWeeksTableA(intSeasonTableA)
330           lngTotalBirds(intSeasonTableA) = lngTotalBirds(intSeasonTableA) + data.DET(intSeasonTableA, intWeek)
340       Next intWeek
350   Next

      Dim lngTotalBanded As Long
      Dim lngTotalReturns As Long
      Dim lngTotalRepeats As Long
      Dim lngTotalDaysObserved As Long
      Dim strWhere As String
      Dim datFirstObserved As Date
      Dim datLastObserved As Date
      Dim lngPeakNumber As Long
      Dim datPeakDate As Date
      Dim strSQL As String
      Dim strPeakDateEx As String
      Dim datDateEx As Date
      Dim strTotalMeanBirdsPerDay(conSpringTableA To conFallTableA) As String
      Dim strTotalDaysObserved(conSpringTableA To conFallTableA) As String
      Dim strDateFirstObserved(conSpringTableA To conFallTableA) As String
      Dim strDateLastObserved(conSpringTableA To conFallTableA) As String
      Dim strPeakNumber(conSpringTableA To conFallTableA) As String
      Dim strPeakDate(conSpringTableA To conFallTableA) As String
      Dim strNumberOfIndividualsAtPeak(conSpringTableA To conFallTableA) As String
      Dim strTotalProcessed(conSpringTableA To conFallTableA) As String
      Dim i As Integer


      ' Spring

360   If lngTotalBirds(conSpringTableA) <> 0 Then

370       lngTotalBanded = 0
380       lngTotalReturns = 0
390       lngTotalRepeats = 0
400       lngTotalDaysObserved = 0

410       For i = 1 To intMaxWeeksTableA(conSpringTableA)

420           If data.DET(conSpringTableA, i) <> 0 And dblStatSeasonYearPeriod(conStatDETDays, conSpring, intYear, i) <> 0 Then
430               strDetailData(conSpringTableA, conStatTableA_MeanBirdsPerDay, i) = _
                    FormatNumberEnglish(data.DET(conSpringTableA, i) / dblStatSeasonYearPeriod(conStatDETDays, conSpring, intYear, i), 2)
440           End If
              
450           If data.DaysObserved(conSpringTableA, i) <> 0 Then
      '            If data.DaysObserved(conSpringTableA, i) = 7 Then
460                   strDetailData(conSpringTableA, conStatTableA_DaysObserved, i) = data.DaysObserved(conSpringTableA, i)
      '            Else
      '                strDetailData(conSpringTableA, conStatTableA_DaysObserved, i) = data.DaysObserved(conSpringTableA, i) & " of " & _
      '                    dblStatSeasonYearPeriod(conStatDETDays, conSpring, intYear, i)
      '            End If
470           End If

480           If data.Repeats(conSpringTableA, i) <> 0 Or data.Returns(conSpringTableA, i) <> 0 Then
490               strDetailData(conSpringTableA, conStatTableA_Processed, i) = _
                      data.Banded(conSpringTableA, i) & "-" & _
                      data.Returns(conSpringTableA, i) & "-" & _
                      data.Repeats(conSpringTableA, i)

500               lngTotalBanded = lngTotalBanded + data.Banded(conSpringTableA, i)
510               lngTotalRepeats = lngTotalRepeats + data.Repeats(conSpringTableA, i)
520               lngTotalReturns = lngTotalReturns + data.Returns(conSpringTableA, i)
530           ElseIf data.Banded(conSpringTableA, i) <> 0 Then
540               strDetailData(conSpringTableA, conStatTableA_Processed, i) = data.Banded(conSpringTableA, i)
550               lngTotalBanded = lngTotalBanded + data.Banded(conSpringTableA, i)
560           End If

570           lngTotalDaysObserved = lngTotalDaysObserved + data.DaysObserved(conSpringTableA, i)
580       Next i

590       If dblStatSeasonYearPeriod(conStatDETDays, conSpring, intYear, intPeriodTotal) <> 0 Then
600           strTotalMeanBirdsPerDay(conSpringTableA) = _
                  FormatNumberEnglish(lngTotalBirds(conSpringTableA) / dblStatSeasonYearPeriod(conStatDETDays, conSpring, intYear, intPeriodTotal), 2)
610       End If

620       If lngTotalDaysObserved <> 0 Then
630           strTotalDaysObserved(conSpringTableA) = lngTotalDaysObserved
640       End If

650       If lngTotalReturns <> 0 Or lngTotalRepeats <> 0 Then
660           strTotalProcessed(conSpringTableA) = lngTotalBanded & "-" & lngTotalReturns & "-" & lngTotalRepeats
670       ElseIf lngTotalBanded <> 0 Then
680           strTotalProcessed(conSpringTableA) = lngTotalBanded
690       End If

          ' First Observed, Last Observed

700       strWhere = _
              "Program = '" & strSpringProgram & "' AND " & _
              "Location = '" & strLocation & "' AND " & _
              "Species = '" & data.Species & "' AND " & _
              "DET > 0"
710       datFirstObserved = Nz(DMin("DateEx", "tblMBOAnnualProgramReportTableA_DETSpecies", strWhere))
720       If datFirstObserved <> 0 Then
730           strDateFirstObserved(conSpringTableA) = ConvertDateToEnglishString(datFirstObserved, 4)
740       End If
750       datLastObserved = Nz(DMax("DateEx", "tblMBOAnnualProgramReportTableA_DETSpecies", strWhere))
760       If datLastObserved <> 0 Then
770           strDateLastObserved(conSpringTableA) = ConvertDateToEnglishString(datLastObserved, 4)
780       End If

          ' Peak Number

790       lngPeakNumber = Nz(DMax("DET", "tblMBOAnnualProgramReportTableA_DETSpecies", strWhere), 0)
800       If lngPeakNumber <> 0 Then
810           strPeakNumber(conSpringTableA) = lngPeakNumber
820       End If

          ' Peak Date(s)

830       strWhere = _
              "Program = '" & strSpringProgram & "' AND " & _
              "Location = '" & strLocation & "' AND " & _
              "Species = '" & data.Species & "' AND " & _
              "DET = " & lngPeakNumber

          Dim intCountPeakNumber As Integer
840       intCountPeakNumber = Nz(DCount("DateEx", "tblMBOAnnualProgramReportTableA_DETSpecies", strWhere), 0)

850       strNumberOfIndividualsAtPeak(conSpringTableA) = lngPeakNumber

860       If intCountPeakNumber = 1 Then
870           datPeakDate = Nz(DFirst("DateEx", "tblMBOAnnualProgramReportTableA_DETSpecies", strWhere), 0)
880           If datPeakDate <> 0 Then
890               strPeakDate(conSpringTableA) = ConvertDateToEnglishString(datPeakDate, 4)
900           End If
910       ElseIf intCountPeakNumber <= 3 Then
              Dim rst As DAO.Recordset
920           strSQL = _
                  "SELECT DateEX FROM tblMBOAnnualProgramReportTableA_DETSpecies WHERE " & strWhere & " ORDER BY DateEx"
930           Set rst = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)
940           strPeakDateEx = ""
950           Do While Not rst.EOF
960               datDateEx = Nz(rst("DateEx"), 0)
970               If datDateEx <> 0 Then
980                   If strPeakDateEx = "" Then
990                       strPeakDateEx = ConvertDateToEnglishString(datDateEx, 1)
1000                  Else
1010                      strPeakDateEx = strPeakDateEx & ", " & ConvertDateToEnglishString(datDateEx, 1)
1020                  End If
1030              End If
1040              rst.MoveNext
1050          Loop
1060          rst.Close
1070          strPeakDate(conSpringTableA) = strPeakDateEx
1080      Else
1090          strPeakDate(conSpringTableA) = intCountPeakNumber & " dates"
1100      End If

1110  End If

      ' Fall

1120  If lngTotalBirds(conFallTableA) <> 0 Then

1130      lngTotalBanded = 0
1140      lngTotalReturns = 0
1150      lngTotalRepeats = 0
1160      lngTotalDaysObserved = 0

1170      For i = 1 To intMaxWeeksTableA(conFallTableA)
          
1180          If data.DET(conFallTableA, i) <> 0 And dblStatSeasonYearPeriod(conStatDETDays, conFall, intYear, i) <> 0 Then
1190              strDetailData(conFallTableA, conStatTableA_MeanBirdsPerDay, i) = _
                    FormatNumberEnglish(data.DET(conFallTableA, i) / dblStatSeasonYearPeriod(conStatDETDays, conFall, intYear, i), 2)
1200          End If
              
1210          If data.DaysObserved(conFallTableA, i) <> 0 Then
      '            If data.DaysObserved(conFallTableA, i) = 7 Then
1220                  strDetailData(conFallTableA, conStatTableA_DaysObserved, i) = data.DaysObserved(conFallTableA, i)
      '            Else
      '                strDetailData(conFallTableA, conStatTableA_DaysObserved, i) = data.DaysObserved(conFallTableA, i) & " of " & _
      '                    dblStatSeasonYearPeriod(conStatDETDays, conFall, intYear, i)
      '            End If
1230          End If
              
1240          If data.Repeats(conFallTableA, i) <> 0 Or data.Returns(conFallTableA, i) <> 0 Then
1250              strDetailData(conFallTableA, conStatTableA_Processed, i) = _
                      data.Banded(conFallTableA, i) & "-" & _
                      data.Returns(conFallTableA, i) & "-" & _
                      data.Repeats(conFallTableA, i)
1260              lngTotalBanded = lngTotalBanded + data.Banded(conFallTableA, i)
1270              lngTotalRepeats = lngTotalRepeats + data.Repeats(conFallTableA, i)
1280              lngTotalReturns = lngTotalReturns + data.Returns(conFallTableA, i)
1290          ElseIf data.Banded(conFallTableA, i) <> 0 Then
1300              strDetailData(conFallTableA, conStatTableA_Processed, i) = data.Banded(conFallTableA, i)
1310              lngTotalBanded = lngTotalBanded + data.Banded(conFallTableA, i)
1320          End If
              
1330          lngTotalDaysObserved = lngTotalDaysObserved + data.DaysObserved(conFallTableA, i)
1340      Next i

1350      If dblStatSeasonYearPeriod(conStatDETDays, conFall, intYear, intPeriodTotal) <> 0 Then
1360          strTotalMeanBirdsPerDay(conFallTableA) = _
                  FormatNumberEnglish(lngTotalBirds(conFallTableA) / dblStatSeasonYearPeriod(conStatDETDays, conFall, intYear, intPeriodTotal), 2)
1370      End If
          
1380      If lngTotalDaysObserved <> 0 Then
1390          strTotalDaysObserved(conFallTableA) = lngTotalDaysObserved
1400      End If

1410      If lngTotalReturns <> 0 Or lngTotalRepeats <> 0 Then
1420          strTotalProcessed(conFallTableA) = lngTotalBanded & "-" & lngTotalReturns & "-" & lngTotalRepeats
1430      ElseIf lngTotalBanded <> 0 Then
1440          strTotalProcessed(conFallTableA) = lngTotalBanded
1450      End If

1460      strWhere = _
              "Program = '" & strFallProgram & "' AND " & _
              "Location = '" & strLocation & "' AND " & _
              "Species = '" & data.Species & "' AND " & _
              "DET > 0"
1470      datFirstObserved = Nz(DMin("DateEx", "tblMBOAnnualProgramReportTableA_DETSpecies", strWhere))
1480      If datFirstObserved <> 0 Then
1490          strDateFirstObserved(conFallTableA) = ConvertDateToEnglishString(datFirstObserved, 4)
1500      End If
1510      datLastObserved = Nz(DMax("DateEx", "tblMBOAnnualProgramReportTableA_DETSpecies", strWhere))
1520      If datLastObserved <> 0 Then
1530          strDateLastObserved(conFallTableA) = ConvertDateToEnglishString(datLastObserved, 4)
1540      End If

1550      lngPeakNumber = Nz(DMax("DET", "tblMBOAnnualProgramReportTableA_DETSpecies", strWhere), 0)
1560      If lngPeakNumber <> 0 Then
1570          strPeakNumber(conFallTableA) = lngPeakNumber
1580      End If

1590      strWhere = _
              "Program = '" & strFallProgram & "' AND " & _
              "Location = '" & strLocation & "' AND " & _
              "Species = '" & data.Species & "' AND " & _
              "DET = " & lngPeakNumber

1600      datPeakDate = Nz(DFirst("DateEx", "tblMBOAnnualProgramReportTableA_DETSpecies", strWhere), 0)
1610      If datPeakDate <> 0 Then
1620          strPeakDate(conFallTableA) = ConvertDateToEnglishString(datPeakDate, 4)
1630      End If

          ' Peak Date(s)

1640      strWhere = _
              "Program = '" & strFallProgram & "' AND " & _
              "Location = '" & strLocation & "' AND " & _
              "Species = '" & data.Species & "' AND " & _
              "DET = " & lngPeakNumber

1650      intCountPeakNumber = Nz(DCount("DateEx", "tblMBOAnnualProgramReportTableA_DETSpecies", strWhere), 0)

1660      strNumberOfIndividualsAtPeak(conFallTableA) = lngPeakNumber

1670      If intCountPeakNumber = 1 Then
1680          datPeakDate = Nz(DFirst("DateEx", "tblMBOAnnualProgramReportTableA_DETSpecies", strWhere), 0)
1690          If datPeakDate <> 0 Then
1700              strPeakDate(conFallTableA) = ConvertDateToEnglishString(datPeakDate, 4)
1710          End If
1720      ElseIf intCountPeakNumber <= 3 Then
1730          strSQL = _
                  "SELECT DateEX FROM tblMBOAnnualProgramReportTableA_DETSpecies WHERE " & strWhere & " ORDER BY DateEx"
1740          Set rst = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)
1750          strPeakDateEx = ""
1760          Do While Not rst.EOF
1770              datDateEx = Nz(rst("DateEx"), 0)
1780              If datDateEx <> 0 Then
1790                  If strPeakDateEx = "" Then
1800                      strPeakDateEx = ConvertDateToEnglishString(datDateEx, 1)
1810                  Else
1820                  strPeakDateEx = strPeakDateEx & ", " & ConvertDateToEnglishString(datDateEx, 1)
1830                  End If
1840              End If
1850              rst.MoveNext
1860          Loop
1870          rst.Close
1880          strPeakDate(conFallTableA) = strPeakDateEx
1890      Else
1900          strPeakDate(conFallTableA) = intCountPeakNumber & " dates"
1910      End If

1920  End If

      ' Fill in the Word tables

      Dim intColumnTotalSpring As Integer
      Dim intColumnTotalFall As Integer
1930  intColumnTotalSpring = intMaxWeeksTableA(conSpringTableA) + 2
1940  intColumnTotalFall = intMaxWeeksTableA(conFallTableA) + 2

1950  If lngTotalBirds(0) <> 0 Then
1960      With range.Tables(1)
1970          .Cell(3, intColumnTotalSpring).range.Text = strTotalMeanBirdsPerDay(conSpringTableA)
1980          .Cell(4, intColumnTotalSpring).range.Text = strTotalDaysObserved(conSpringTableA)
1990          .Cell(5, intColumnTotalSpring).range.Text = strTotalProcessed(conSpringTableA)
2000          .Cell(6, 2).range.Text = "FIRST OBSERVED: " & strDateFirstObserved(conSpringTableA)
2010          .Cell(6, 3).range.Text = "LAST OBSERVED: " & strDateLastObserved(conSpringTableA)
2020          .Cell(6, 4).range.Text = "PEAK DATE: " & strPeakDate(conSpringTableA)
2030          .Cell(6, 5).range.Text = "PEAK NUMBER OF INDIVIDUALS: " & strNumberOfIndividualsAtPeak(conSpringTableA)
2040      End With
2050  End If

2060  If lngTotalBirds(1) <> 0 Then
2070      With range.Tables(2)
2080          .Cell(3, intColumnTotalFall).range.Text = strTotalMeanBirdsPerDay(conFallTableA)
2090          .Cell(4, intColumnTotalFall).range.Text = strTotalDaysObserved(conFallTableA)
2100          .Cell(5, intColumnTotalFall).range.Text = strTotalProcessed(conFallTableA)
2110          .Cell(6, 2).range.Text = "FIRST OBSERVED: " & strDateFirstObserved(conFallTableA)
2120          .Cell(6, 3).range.Text = "LAST OBSERVED: " & strDateLastObserved(conFallTableA)
2130          .Cell(6, 4).range.Text = "PEAK DATE: " & strPeakDate(conFallTableA)
2140          .Cell(6, 5).range.Text = "PEAK NUMBER OF INDIVIDUALS: " & strNumberOfIndividualsAtPeak(conFallTableA)
2150      End With
2160  End If

2170  For intSeasonTableA = conSpringTableA To conFallTableA
2180      For intStatTableA = conStatTableA_MeanBirdsPerDay To conStatTableA_Processed
2190          For intWeek = 1 To intMaxWeeksTableA(intSeasonTableA)
2200              range.Tables(intSeasonTableA + 1).Cell(intStatTableA + 3, intWeek + 1).range.Text = _
                      strDetailData(intSeasonTableA, intStatTableA, intWeek)
2210          Next
2220      Next
2230  Next

      ' Delete any empty processed rows

      Dim rangeReplace As Word.range

2240  Set rangeReplace = range.Duplicate
2250  If strTotalProcessed(conSpringTableA) = "" Then
2260      rangeReplace.Tables(1).Rows(5).Delete
2270  End If
2280  If strTotalProcessed(conFallTableA) = "" Then
2290      rangeReplace.Tables(2).Rows(5).Delete
2300  End If

      ' Delete any empty tables

2310  If strTotalMeanBirdsPerDay(conFallTableA) = "" Then
2320      rangeReplace.Tables(2).Delete
2330  End If
2340  If strTotalMeanBirdsPerDay(conSpringTableA) = "" Then
          Dim rng As Word.range
2350      Set rng = rangeReplace.Tables(1).range
2360      rng.Move unit:=wdParagraph, count:=1
2370      rangeReplace.Tables(1).Delete
2380      rng.Delete
2390      Set rng = Nothing
2400  End If

2410  Set rangeReplace = Nothing

      'DD Error Handler Start
Exit_label:
2420       Exit Sub
Err_label:
2430       Select Case Err.Number
           Case Else
2440      Call LogError("basMBOAnnualProgramReportTableA", "MBOAnnualProgramReportTableA_Footer")
2450       End Select
2460       Resume Exit_label
      'DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' MBOAnnualProgramReportTableA_BCCH
'
' No longer called  (Used to be used by David for checking a species (by default BCCH) in Appendix A
'---------------------------------------------------------------------------------------
 
Public Sub MBOAnnualProgramReportTableA_BCCH( _
    ByVal intYear As Integer, _
    ByVal strLocation As String, _
    ByRef oExcel As Excel.Application, _
    ByRef oBook As Excel.Workbook, _
    Optional ByVal strSpecies As String = "BCCH")

10    On Error GoTo Err_label

20    SysCmd acSysCmdSetStatus, "Table A - " & strSpecies & " validation"

      ' Create an Excel Worksheet

      Dim oSheet As Excel.Worksheet
30    Set oSheet = oBook.Worksheets.Add(After:=oBook.Worksheets(oBook.Worksheets.count))
40    oSheet.Name = "David " & strSpecies
50    With oSheet

      Dim qdf As QueryDef
      Dim rst As DAO.Recordset
      Dim strSeason As String
      Dim intSeason As Integer
      Dim intPeriod As Integer
      Dim datDate As Date
      Dim lngBanded As Long
      Dim lngReturns As Long
      Dim lngRepeats As Long
      Dim lngAlien As Long
      Dim lngDET As Long
      Dim row As Long
      Dim col As Long
      Dim rowLast As Long

      Dim datProgramDateFirst As Date
      Dim datProgramDateLast As Date
      Dim datProgramOfficialStartDate As Date

      Const colSeason As Integer = 1
      Const colPeriod As Integer = 2
      Const colDate As Integer = 3
      Const colBanded As Integer = 4
      Const colReturns As Integer = 5
      Const colRepeats As Integer = 6
      Const colAlien As Integer = 7
      Const colDET As Integer = 8
      Const colDETDay As Integer = 9
      Const colMeanDET As Integer = 10
      Const colDaysSpeciesObserved As Integer = 11
      Const colLast As Integer = 11

60    row = 1

      Dim rowBase As Long
70    rowBase = row

80    For intSeason = intSeasonFirst To intSeasonLast - 1
90        strSeason = toStrSeasonFromIntSeason(intSeason)
          
100       row = rowBase
            
110       datProgramDateFirst = datProgramDateFirst_SeasonYear(intSeason, intYear)
120       datProgramDateLast = datProgramDateLast_SeasonYear(intSeason, intYear)
130       datProgramOfficialStartDate = datProgramOfficialStartDate_SeasonYear(intSeason, intYear)

      Dim datProgramDateFirstEx As Date


140       If datProgramDateFirst <> 0 And datProgramDateLast <> 0 And datProgramOfficialStartDate <> 0 Then
       
150           If datProgramOfficialStartDate <= datProgramDateFirst Then
160               datProgramDateFirstEx = datProgramOfficialStartDate
170           Else
180               datProgramDateFirstEx = datProgramDateFirst
190           End If

          
200           .Cells(row, colSeason) = "Season"
210           .Cells(row, colPeriod) = "Period"
220           .Cells(row, colDate) = "Date"
230           .Cells(row, colBanded) = "BND"
240           .Cells(row, colReturns) = "RET"
250           .Cells(row, colRepeats) = "REP"
260           .Cells(row, colAlien) = "A"
270           .Cells(row, colDET) = "DET"
280           .Cells(row, colDETDay) = "DET Day"
290           .Cells(row, colMeanDET) = "Mean DET"
300           .Cells(row, colDaysSpeciesObserved) = "Days species observed"
310           .Rows(row).Font.Bold = True
320           row = row + 1
              
330           For datDate = datProgramDateFirstEx To datProgramDateLast
340               .Cells(row, colSeason) = strSeason
350               If datDate < datProgramOfficialStartDate Then
360                   .Cells(row, colPeriod) = 1
370                   .Cells(row, colPeriod).Font.Color = vbRed
380               Else
390                   intPeriod = toPeriod(strSeason, datDate, datProgramOfficialStartDate)
400                   .Cells(row, colPeriod) = intPeriod
410               End If
420               .Cells(row, colDate) = datDate
430               row = row + 1
440           Next
450           rowLast = row - 1

460           Set qdf = CurrentDb.QueryDefs("qryMBOAnnualProgramReportTableA_BCCH")
470           qdf.Parameters("argLocation") = strLocation
480           qdf.Parameters("argYear") = intYear
490           qdf.Parameters("argSeason") = strSeason
500           qdf.Parameters("argSpecies") = strSpecies
          
510           Set rst = qdf.OpenRecordset
          
520           If rst.EOF Then GoTo Continue_label
                 
530           Do While Not rst.EOF

540               datDate = Nz(rst("DateEx"))
550               lngBanded = Nz(rst("Banded"))
560               lngReturns = Nz(rst("Returns"))
570               lngRepeats = Nz(rst("Repeats"))
580               lngAlien = Nz(rst("Alien"))
590               lngDET = Nz(rst("DET"))
                          
600               row = datDate - datProgramDateFirstEx + rowBase + 1
                          
610               .Cells(row, 13) = datDate
620               .Cells(row, colBanded) = lngBanded
630               .Cells(row, colReturns) = lngReturns
640               .Cells(row, colRepeats) = lngRepeats
650               .Cells(row, colAlien) = lngAlien
660               .Cells(row, colDET) = lngDET
670               .Cells(row, colDaysSpeciesObserved) = IIf(lngDET > 0, 1, 0)
                  
680               rst.MoveNext
690           Loop
700           rst.Close
710           Set rst = Nothing
          
              ' Peak values
              
              Dim lngMaxDET As Long
720           lngMaxDET = 0
730           For row = rowBase + 1 To rowLast
740               If lngMaxDET < .Cells(row, colDET) Then
750                   lngMaxDET = .Cells(row, colDET)
760               End If
770           Next
              
              ' Highlight peak values
              
780           For row = rowBase + 1 To rowLast
790               If lngMaxDET = .Cells(row, colDET) Then
800                   .Cells(row, colDET).Interior.Color = vbYellow
810               End If
820           Next

              ' DET Days
              
              Dim lngDETDay As Long
              
830           Set qdf = CurrentDb.QueryDefs("qryMBOAnnualProgramReportTableA_DETDay")
840           qdf.Parameters("argLocation") = strLocation
850           qdf.Parameters("argYear") = intYear
860           qdf.Parameters("argSeason") = strSeason
          
870           Set rst = qdf.OpenRecordset
          
880           If rst.EOF Then GoTo Continue_label
                 
890           Do While Not rst.EOF
              
900               datDate = Nz(rst("DateEx"))
910               lngDETDay = IIf(Nz(rst("DET")) > 0, 1, 0)
                          
920               row = datDate - datProgramDateFirstEx + rowBase + 1
930               .Cells(row, colDETDay) = lngDETDay
                  
940               rst.MoveNext
950           Loop
960           rst.Close
970           Set rst = Nothing

              ' Subtotals
                  
980           If rowLast > rowBase Then
990               .range(.Cells(rowBase, 1), .Cells(rowLast, colDaysSpeciesObserved)).Subtotal _
                  GroupBy:=colPeriod, Function:=xlSum, TotalList:=Array(colBanded, colReturns, colRepeats, colAlien, colDET, colDETDay, colDaysSpeciesObserved), _
                  Replace:=True, PageBreaks:=False, SummaryBelowData:=True
                  
1000              rowLast = .Cells(.Rows.count, "B").End(xlUp).row ' last row with data in the B column
1010          End If
              
              ' Mean DET
              
1020          For row = rowBase + 1 To rowLast
1030              If .Cells(row, colDate) = "" Then
1040                  If .Cells(row, colDETDay) > 0 Then
1050                      .Cells(row, colMeanDET) = .Cells(row, colDET) / .Cells(row, colDETDay)
1060                  End If
1070                  .range(.Cells(row, colSeason), .Cells(row, colDaysSpeciesObserved)).Interior.Color = RGB(219, 238, 243) ' pale blue
1080              End If
1090          Next

1100          rowBase = rowLast + 2
          
1110      End If
          
Continue_label:
1120  Next

1130  .columns(colMeanDET).NumberFormat = "#0.00"
1140  .columns(colDate).NumberFormat = "d mmm yyyy"
1150  .range(.columns(colPeriod), .columns(colDaysSpeciesObserved)).HorizontalAlignment = xlCenter

1160  .range(.columns(1), .columns(colLast + 2)).AutoFit
1170  .range("A2").Select

1180  oExcel.ActiveWindow.FreezePanes = True

1190  End With
1200  SysCmd acSysCmdClearStatus

      'DD Error Handler Start
Exit_label:
1210       Exit Sub
Err_label:
1220       Select Case Err.Number
           Case Else
1230      Call LogError("basMBOAnnualProgramReportTableA", "MBOAnnualProgramReportTableA_BCCH")
1240       End Select
1250       Resume Exit_label
      'DD Error Handler End
   End Sub
