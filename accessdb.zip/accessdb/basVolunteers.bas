'---------------------------------------------------------------------------------------
' Module    : basVolunteers
' Author    : David Davey
'---------------------------------------------------------------------------------------

Option Compare Database
Option Explicit

'---------------------------------------------------------------------------------------
' ExportAssistants_andBICsToExcel_Click
'---------------------------------------------------------------------------------------
 
Public Sub ExportAssistants_andBICsToExcel( _
    ByVal strProgram As String, _
    ByVal intYear As Integer, _
    ByVal strSeason As String, _
    ByVal strLocation As String, _
    ByVal intPeriod As Integer, _
    ByVal datFrom As Date, _
    ByVal datTo As Date, _
    ByRef oExcel As Excel.Application, _
    ByRef oBook As Excel.Workbook)
          
10    On Error GoTo Err_label

      Dim strSQL As String
      Dim rst As DAO.Recordset
      Dim List As String
      Dim strFilter As String
      Dim strHTML As String
      Dim Fullname As String
         
      '20    If Not IsHeaderValid Then
      '30       Exit Sub
      '40    End If

      Dim strTitle As String
20    strTitle = _
          "MBO Volunteers " & intYear & " " & strSeason & " (" & strProgram & _
          ") Week/Period " & intPeriod & " From " & Format(datFrom, "yyyy/mm/d") & " to " & _
          Format(datTo, "yyyy/mm/d")

      Dim oSheet As Excel.Worksheet
30    Set oSheet = oBook.Worksheets.Add(After:=oBook.Worksheets(oBook.Worksheets.count))
40    oSheet.Name = "Volunteers"

50    With oSheet

60    strHTML = "<p><strong>"

      ' Process BICs

      Dim intCountBICs As Integer
70    intCountBICs = 0

80    List = ""

90    strFilter = _
                    "[Program] = '" & strProgram & "' AND " & _
                    "[Location] = '" & strLocation & "' AND " & _
                    "[Week] = " & intPeriod & " AND " & _
                    " ([IsBic] = True AND [IsCurrent] = True )"

100   strSQL = _
          "SELECT VolunteerFullname FROM qryVolunteersByWeek " & _
          "WHERE " & strFilter & " " & _
          "ORDER BY VolunteerLastname, VolunteerFirstnames"

110   Set rst = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)
120   Do While Not rst.EOF
130       Fullname = Trim(Nz(rst("VolunteerFullname"), ""))
         
140       If Fullname <> "" Then
150           intCountBICs = intCountBICs + 1
160           If List = "" Then
170               List = Fullname
180           Else
190               List = List & ", " & Fullname
200           End If
210       End If
         
220       rst.MoveNext
230   Loop
240   rst.Close
          
250   If intCountBICs = 1 Then
260       .Cells(3, 1) = "Bander-in-charge:"
270       strHTML = strHTML & "Bander-in-charge: </strong>"
280   ElseIf intCountBICs > 1 Then
290       .Cells(3, 1) = "Banders-in-charge:"
300       strHTML = strHTML & "Banders-in-charge: </strong>"
310   End If
320   .Cells(3, 2) = List

330   strHTML = strHTML & List & "<br><strong>Assistants: </strong>"

      ' Process assistants

340   List = ""

350   strFilter = _
                    "[Program] = '" & strProgram & "' AND " & _
                    "[Location] = '" & strLocation & "' AND " & _
                    "[Week] = " & intPeriod & " AND " & _
                    "NOT ([IsBic] = True AND [IsCurrent] = True )"

360   strSQL = _
          "SELECT VolunteerFullname FROM qryVolunteersByWeek " & _
          "WHERE " & strFilter & " " & _
          "ORDER BY VolunteerLastname, VolunteerFirstnames"
          

370   Set rst = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)
380   Do While Not rst.EOF

390       Fullname = Trim(Nz(rst("VolunteerFullname"), ""))
         
400       If Fullname <> "" Then
410           If List = "" Then
420               List = Fullname
430           Else
440               List = List & ", " & Fullname
450           End If
460       End If
         
470       rst.MoveNext
480   Loop
490   rst.Close
         
500   .Cells(4, 1) = "Assistants:"
510   .Cells(4, 2) = List

520   strHTML = strHTML & List & "</p>"

530   .Cells(6, 2) = strHTML

540   .range(.columns(1), .columns(2)).AutoFit

550   .Cells(1, 1) = strTitle

560   .range(.Cells(1, 1), .Cells(4, 1)).Font.Bold = True

570   End With
580   Set oSheet = Nothing


      'DD Error Handler Start
Exit_label:
590        Exit Sub
Err_label:
600        Select Case Err.Number
           Case Else
610             Call LogError("basVolunteers", "ExportAssistants_andBICsToExcel")
620        End Select
630        Resume Exit_label
      'DD Error Handler End

End Sub
