Option Compare Database
Option Explicit

Public Const conMaxUserField As Integer = 40
Public Const conMaxDataField As Integer = 40
Public Const conMaxDETEffort As Integer = 8
Public Const conDefaultStagingAreaFilepath = "C:\MBO Data Entry\Android"

Public Const conUpdateValidationFlagsTrue As Boolean = True
Public Const conUpdateValidationFlagsFalse As Boolean = False
