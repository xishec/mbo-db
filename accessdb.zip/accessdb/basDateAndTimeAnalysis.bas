'---------------------------------------------------------------------------------------
' Module    : basDateAndTimeAnalysis
' Author    : David Davey
'---------------------------------------------------------------------------------------

Option Compare Database
Option Explicit

'---------------------------------------------------------------------------------------
' BandingBeforeRecaptureAnalysis
'---------------------------------------------------------------------------------------
 
Public Sub BandingBeforeRecaptureAnalysis( _
    ByVal Disposition As String, _
    ByVal Prefix As String, ByVal Suffix As String, _
    ByVal CaptureDate As Date, _
    ByVal WeightTime As Variant, _
    ByRef strErr As String)
          
10    On Error GoTo Err_label

      Dim strCriterion As String
      Dim datEarliestRecaptureDate As Date
      Dim datEarliestRecaptureTime As Date

20    strErr = ""

30    Select Case Disposition
      Case "1", "5", "6", "S", "D"

      ' [1]  There is no same-band recapture record => ok
      ' [2]  There is at least one same-band recapture record
      ' [2.1] Banding Date < earliest Recapture Date => ok
      ' [2.2] Banding Date > earliest Recapture Date => error
      ' [2.3] Banding Date = earliest Recapture Date
      ' [2.3.1]  Banding Time is blank => ok
      ' [2.3.2]  ALL same-day recapture Time is blank => ok
      ' [2.3.3]  Banding and at least one recapture Times are non-blank
      ' [2.3.3.1] Banding Time <= earliest same day Recapture Time => ok
      ' [2.3.3.2] Banding Time > earliest same-day Recapture Time => error

40        strCriterion = _
              "BandPrefix = '" & Prefix & "' AND " & _
              "BandSuffix = '" & Suffix & "' AND " & _
              "(Disposition in ('R','F'))"
              
50        If DCount("*", "tblCaptures", strCriterion) = 0 Then
          ' [1] There is no same-band recapture record => ok
60            Exit Sub
70        End If
          
          ' [2] There is at least one same-band recapture record
80        datEarliestRecaptureDate = Nz(DMin("CaptureDate", "tblCaptures", strCriterion))
90        If CaptureDate < datEarliestRecaptureDate Then
          ' [2.1] Banding Date < earliest Recapture Date => ok
100           Exit Sub
110       ElseIf CaptureDate > datEarliestRecaptureDate Then
          ' [2.2] Banding Date > earliest Recapture Date => error
120           strErr = Prefix & "-" & Suffix & " was recaptured before it was banded" & vbCrLf
130           Exit Sub
140       End If
          
          ' [2.3] Banding Date = earliest Recapture Date
          
150       If IsNull(WeightTime) Then
          ' [2.3.1] Banding Time is blank => ok
160           Exit Sub
170       End If

180       strCriterion = _
               "BandPrefix = '" & Prefix & "' AND " & _
               "BandSuffix = '" & Suffix & "' AND " & _
               "(Disposition in ('R','F')) AND " & _
               "CaptureDate = #" & Format(CaptureDate, "mm/dd/yyyy") & "# AND " & _
               "WeightTime is not Null"
               
190        If DCount("*", "tblCaptures", strCriterion) = 0 Then
           ' [2.3.2]  ALL same-day recapture Time is blank => ok
200           Exit Sub
210        End If
          
           ' [2.3.3]  Banding and at least one recapture Times are non-blank
           
220       strCriterion = _
              "BandPrefix = '" & Prefix & "' AND " & _
              "BandSuffix = '" & Suffix & "' AND " & _
              "(Disposition in ('R','F')) AND " & _
              "CaptureDate = #" & Format(CaptureDate, "mm/dd/yyyy") & "#"
          
230       datEarliestRecaptureTime = Nz(DMin("WeightTime", "tblCaptures", strCriterion))
          
240       If WeightTime <= datEarliestRecaptureTime Then
          ' [2.3.3.1] Banding Time <= earliest same day Recapture Time => ok
250          Exit Sub
260       End If
          
          ' [2.3.3.2] Banding Time > earliest same-day Recapture Time => error
270       strErr = Prefix & "-" & Suffix & " was recaptured before it was banded" & vbCrLf
280       Exit Sub
             
290   Case "R", "F"

      ' [1] There is no same-band banding 1, 6, D, S, 9, 5 record => ok
      ' [2] There is a same-band banding 1, 6, D, S, 9, 5  record
      ' [2.1]  Recapture Date < Banding Date => error
      ' [2.2]  Recapture Date > Banding Date => ok
      ' [2.3]  Recapture Date = Banding Date
      ' [2.3.1]  Recapture Time is blank => ok
      ' [2.3.2]  Banding Time is blank => ok
      ' [2.3.3]  Banding and Recapture Times are not blank
      ' [2.3.3.1]  Recapture Time < Banding Time => error
      ' [2.3.3.2]  Recapture Time >= Banding Time => ok


300       strCriterion = _
              "BandPrefix = '" & Prefix & "' AND " & _
              "BandSuffix = '" & Suffix & "' AND " & _
              "(Disposition  in ('1','6','D','S','9','5')) "
310       If DCount("*", "tblCaptures", strCriterion) = 0 Then
          ' [1] There is no same-band banding 1, 6, D, S, 9, 5 record => ok
320       Else
          ' [2] There is a same-band banding 1, 6, D, S, 9, 5  record
              Dim datBandingDate As Date
330           datBandingDate = Nz(DLookup("CaptureDate", "tblCaptures", strCriterion))
340           If CaptureDate < datBandingDate Then
              ' [2.1]  Recapture Date < Banding Date => error
350               strErr = Prefix & "-" & Suffix & " was recaptured before it was banded" & vbCrLf
360           ElseIf CaptureDate > datBandingDate Then
              ' [2.2]  Recapture Date > Banding Date => ok
370           Else
              ' [2.3]  Recapture Date = Banding Date
380               If IsNull(WeightTime) Then
                  ' [2.3.1]  Recapture Time is blank => ok
390               Else
                      Dim varBandingWeightTime As Variant
400                    varBandingWeightTime = DLookup("WeightTime", "tblCaptures", strCriterion)
410                   If IsNull(varBandingWeightTime) Then
                      ' [2.3.2]  Banding Time is blank => ok
420                   Else
                      ' [2.3.3]  Banding and Recapture Times are not blank
                          Dim datBandingWeightTime As Date
430                       datBandingWeightTime = CDate(varBandingWeightTime)
440                       If WeightTime < datBandingWeightTime Then
                          ' [2.3.3.1]  Recapture Time < Banding Time => error
450                           strErr = Prefix & "-" & Suffix & " was recaptured before it was banded" & vbCrLf
460                       Else
                          ' [2.3.3.2]  Recapture Time >= Banding Time => ok
470                       End If
480                   End If
490               End If
500           End If
510       End If
520   End Select

      'DD Error Handler Start
Exit_label:
530        Exit Sub
Err_label:
540        Select Case Err.Number
           Case Else
550             Call LogError("basDateAndTimeAnalysis", "BandingBeforeRecaptureAnalysis")
560        End Select
570        Resume Exit_label
      'DD Error Handler End
          
End Sub

' ---------------------------------------------------------------------------
' SameDayAnalysis

'   Same day capture for the same program ?

' PRE: Prefix, Suffix, CaptureDate are valid
' WeightTime can be null or valid
' Program can be "" or valid
' If IDBand is 0 then search all capture records
' Otherwise search all recapture records except this record

' ---------------------------------------------------------------------------

Public Sub SameDayAnalysis( _
    ByVal Disposition As String, _
    ByVal Prefix As String, ByVal Suffix As String, _
    ByVal CaptureDate As Date, _
    ByVal WeightTime As Variant, _
    ByVal Program As String, _
    ByVal IDBand As Long, _
    ByRef strErr As String, _
    ByRef fDuplicateRecapture As Boolean)
          
10    On Error GoTo Err_label

20    fDuplicateRecapture = False

      Dim strCriterion As String
      Dim datEarliestRecaptureDate As Date

30    strErr = ""

40    Select Case Disposition
      Case "1", "5", "6", "S", "D"

      ' If the user is changing the disposition from F to 1 we must exclude
      ' this record from searches.  May as well always exclude this record
      ' when IDBand <> 0

      ' [1]  There is no same-band recapture record => ok
      ' [2]  There is at least one same-band recapture record
      ' [2.1] Banding Date <> ALL same-band Recapture Date => ok
      ' [2.2] Banding Date = ANY same-band Recapture Date
      ' [2.2.1]  Banding program is blank => error
      ' [2.2.2]  ANY same-day recapture program is blank => error
      ' [2.2.3]  Banding and ALL same-day recapture programs are non-blank
      ' [2.2.3.1]  Banding program = ANY same-day recapture program => error
      ' [2.2.3.2]  Banding program <> ALL same-day recapture programs => ok

50        strCriterion = _
              "BandPrefix = '" & Prefix & "' AND " & _
              "BandSuffix = '" & Suffix & "' AND " & _
              "(Disposition in ('R','F'))"
60        If IDBand <> 0 Then
70            strCriterion = strCriterion & " AND IDBand <> " & IDBand
80        End If
              
90        If DCount("*", "tblCaptures", strCriterion) = 0 Then
          ' [1]  There is no same-band recapture record => ok
100           Exit Sub
110       End If
          
          ' [2] There is at least one same-band recapture record
120       strCriterion = _
              "BandPrefix = '" & Prefix & "' AND " & _
              "BandSuffix = '" & Suffix & "' AND " & _
              "(Disposition in ('R','F')) AND " & _
              "CaptureDate = #" & Format(CaptureDate, "mm/dd/yyyy") & "#"
130       If IDBand <> 0 Then
140           strCriterion = strCriterion & " AND IDBand <> " & IDBand
150       End If
160       If DCount("*", "tblCaptures", strCriterion) = 0 Then
          ' [2.1] Banding Date <> ALL same-band Recapture Date => ok
170           Exit Sub
180       End If
          
190       datEarliestRecaptureDate = Nz(DMin("CaptureDate", "tblCaptures", strCriterion))
200       If CaptureDate < datEarliestRecaptureDate Then
          ' [2.1] ok
210           Exit Sub
220       End If
          
          ' [2.2] Banding Date = ANY same-band Recapture Date
          
230       If Program = "" Then
          ' [2.2.1] Banding Program is blank => Same day capture error
240           strErr = Prefix & "-" & Suffix & " was recaptured on the same date" & vbCrLf
250           Exit Sub
260       End If
          
270       strCriterion = _
             "BandPrefix = '" & Prefix & "' AND " & _
             "BandSuffix = '" & Suffix & "' AND " & _
             "(Disposition in ('R','F')) AND " & _
             "CaptureDate = #" & Format(CaptureDate, "mm/dd/yyyy") & "# AND " & _
             "Trim(Nz(Program)) = ''"
280       If IDBand <> 0 Then
290           strCriterion = strCriterion & " AND IDBand <> " & IDBand
300       End If
             
310       If DCount("*", "tblCaptures", strCriterion) > 0 Then
          ' [2.2.2] ANY same-day recapture program is blank => error
320           strErr = Prefix & "-" & Suffix & " was recaptured on the same date" & vbCrLf
330           Exit Sub
340       End If
          
          ' [2.2.3]  Banding and ALL same-day recapture programs are non-blank
              
350       strCriterion = _
              "BandPrefix = '" & Prefix & "' AND " & _
              "BandSuffix = '" & Suffix & "' AND " & _
              "(Disposition in ('R','F')) AND " & _
              "CaptureDate = #" & Format(CaptureDate, "mm/dd/yyyy") & "# AND " & _
              "Program = '" & Program & "'"
360       If IDBand <> 0 Then
370           strCriterion = strCriterion & " AND IDBand <> " & IDBand
380       End If
              
390       If DCount("*", "tblCaptures", strCriterion) > 0 Then
          ' [2.2.3.1]  Banding program = ANY same-day recapture program => error
400           strErr = Prefix & "-" & Suffix & " was recaptured on the same date" & vbCrLf
410           Exit Sub
420       End If

          ' [2.3.3.2] Banding program <> ALL same-day recapture programs
                 
430   Case "R", "F"

      ' N.B. Exclude '4', '8' and '9' capture records from searches

      ' [1] There is no other same-band same-date capture record  => ok
      ' [2] There is at least one other same band, same date capture record
      ' [2.1]  This recapture program is blank => error
      ' [2.2]  There is at least one other same band, same date, blank program capture record => error
      ' [2.3]  All other same band, same date capture record, have non blank programs
      ' [2.3.1]   There is at least one other same band, same date, same program capture record  => error
      ' [2.3.2]   All other same band, same date capture records  have their program <> this program => ok

440   strCriterion = _
          "BandPrefix = '" & Prefix & "' AND " & _
          "BandSuffix = '" & Suffix & "' AND " & _
          "(Disposition not in ('4','8','9')) AND " & _
          "CaptureDate = #" & Format(CaptureDate, "mm/dd/yyyy") & "#"
450   If IDBand <> 0 Then
460     strCriterion = strCriterion & " AND IDBand <> " & IDBand
470   End If
        
480   If DCount("*", "tblCaptures", strCriterion) = 0 Then
      ' [1] There is no other same-band same-date capture record  => ok
490   Else
      ' [2] There is at least one other same band, same date capture record
500       If Program = "" Then
          ' [2.1]  This recapture program is blank => error
510           strErr = Prefix & "-" & Suffix & " captured twice on same day" & vbCrLf
520       Else
530           strCriterion = _
                  "BandPrefix = '" & Prefix & "' AND " & _
                  "BandSuffix = '" & Suffix & "' AND " & _
                  "(Disposition not in ('4','8','9')) AND " & _
                  "CaptureDate = #" & Format(CaptureDate, "mm/dd/yyyy") & "# AND " & _
                  "Trim(Nz(Program)) = '' "
540           If IDBand <> 0 Then
550               strCriterion = strCriterion & " AND IDBand <> " & IDBand
560           End If
570           If DCount("*", "tblCaptures", strCriterion) > 0 Then
              ' [2.2]  There is at least one other same band, same date, blank program capture record => error
580               strErr = Prefix & "-" & Suffix & " captured twice on same day" & vbCrLf
590               fDuplicateRecapture = True
600           Else
              ' [2.3]  All other same band, same date capture record, have non blank programs
610               strCriterion = _
                      "BandPrefix = '" & Prefix & "' AND " & _
                      "BandSuffix = '" & Suffix & "' AND " & _
                      "(Disposition not in ('4','8','9')) AND " & _
                      "CaptureDate = #" & Format(CaptureDate, "mm/dd/yyyy") & "# AND " & _
                      "Program = '" & Program & "'"
620               If IDBand <> 0 Then
630                   strCriterion = strCriterion & " AND IDBand <> " & IDBand
640               End If
650               If DCount("*", "tblCaptures", strCriterion) > 0 Then
                  ' [2.3.1]   There is at least one other same band, same date, same program capture record  => error
660                   strErr = Prefix & "-" & Suffix & " captured twice on same day" & vbCrLf
670                   fDuplicateRecapture = True
680               Else
                  ' [2.3.2]   All other same band, same date capture records  have their program <> this program => ok
690               End If
700           End If
710       End If
720   End If

730   End Select

      'DD Error Handler Start
Exit_label:
740        Exit Sub
Err_label:
750        Select Case Err.Number
           Case Else
760             Call LogError("basDateAndTimeAnalysis", "SameDayAnalysis")
770        End Select
780        Resume Exit_label
      'DD Error Handler End

End Sub

' ---------------------------------------------------------------------------
' DateAndTimeAnalysis

'   Recaptured before it was banded ?
'   Same day capture for the same program ?

' PRE: Prefix, Suffix, CaptureDate are valid
' WeightTime can be null or valid
' Program can be "" or valid
' If IDBand is 0 then search all capture records
' Otherwise search all capture records except this record

' ---------------------------------------------------------------------------

Public Sub DateAndTimeAnalysis( _
    ByVal Disposition As String, _
    ByVal Prefix As String, ByVal Suffix As String, _
    ByVal CaptureDate As Date, _
    ByVal WeightTime As Variant, _
    ByVal Program As String, _
    ByVal IDBand As Long, _
    ByRef strErr As String, _
    ByRef fDuplicateRecapture As Boolean)
          
10    On Error GoTo Err_label

20    fDuplicateRecapture = False

30    Call BandingBeforeRecaptureAnalysis(Disposition, Prefix, Suffix, CaptureDate, _
           WeightTime, strErr)
40    If strErr = "" Then
50        Call SameDayAnalysis(Disposition, Prefix, Suffix, CaptureDate, _
              WeightTime, Program, IDBand, strErr, fDuplicateRecapture)
60    End If

      'DD Error Handler Start
Exit_label:
70         Exit Sub
Err_label:
80         Select Case Err.Number
           Case Else
90        Call LogError("basDateAndTimeAnalysis", "DateAndTimeAnalysis")
100        End Select
110        Resume Exit_label
      'DD Error Handler End
End Sub
