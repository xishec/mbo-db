'---------------------------------------------------------------------------------------
' Module: basMBOProgramReport_Word
' Author: David Davey
'---------------------------------------------------------------------------------------

Option Compare Database
Option Explicit

Private fCheckGrammarAsYouTypeSave As Boolean
Private fCheckSpellingAsYouTypeSave As Boolean

'---------------------------------------------------------------------------------------
' WordInitialise
'
' PRE wd, doc have been initialised
'---------------------------------------------------------------------------------------
' Called from MBOAnnualProgramReport() and MBO10YearProgramReport()

Public Sub WordInitialise(ByRef wd As Word.Application, ByRef doc As Word.Document)

10    On Error GoTo Err_label

20    Set wd = New Word.Application

30    Call Sleep(2000)
40    DoEvents

50    wd.DisplayAlerts = wdAlertsNone

60    fCheckGrammarAsYouTypeSave = wd.Options.CheckGrammarAsYouType
70    fCheckSpellingAsYouTypeSave = wd.Options.CheckSpellingAsYouType

80    wd.Options.CheckGrammarAsYouType = False
90    wd.Options.CheckSpellingAsYouType = False

100   Set doc = wd.Documents.Add
           
110   doc.SpellingChecked = True

120   Call SetDefaultMargins(doc)

180   Call CreateStyles(doc)

          'DD Error Handler Start
Exit_label:
190       Exit Sub
Err_label:
200       Select Case Err.Number
          Case Else
210           Call LogError("basMBOProgramReport_Word", "WordInitialise")
220       End Select
230       Resume Exit_label
          ' DD Error Handler End

End Sub

Public Sub SetPageOrientation(ByRef doc As Word.Document, Optional ByRef strOrientation As String = "Portrait")

10    On Error GoTo Err_label

      Dim rangeA As Word.range

20    Set rangeA = MoveInsertionPointToEndOfDocument(doc.Application, doc)

30    rangeA.InsertBreak wdSectionBreakNextPage
40    If strOrientation = "Landscape" Then
50        rangeA.PageSetup.Orientation = wdOrientLandscape
60    Else
70        rangeA.PageSetup.Orientation = wdOrientPortrait
80    End If

          'DD Error Handler Start
Exit_label:
90        Exit Sub
Err_label:
100       Select Case Err.Number
          Case Else
110       Call LogError("basMBOProgramReport_Word", "SetPortrait")
120       End Select
130       Resume Exit_label
          ' DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' SetDefaultMargins
'
' Sets the default margins for the current last section of the document
'---------------------------------------------------------------------------------------

Public Sub SetDefaultMargins(ByRef doc As Word.Document)

      ' Set all margins to 0.79"

10    On Error GoTo Err_label

20    With doc.Sections.Last.PageSetup
30        .LeftMargin = doc.Application.InchesToPoints(0.79)
40        .RightMargin = doc.Application.InchesToPoints(0.79)
50        .TopMargin = doc.Application.InchesToPoints(0.79)
60        .BottomMargin = doc.Application.InchesToPoints(0.79)
70    End With

          'DD Error Handler Start
Exit_label:
80        Exit Sub
Err_label:
90        Select Case Err.Number
          Case Else
110           Call LogError("basMBOProgramReport_Word", "SetDefaultMargins")
120       End Select
130       Resume Exit_label
          ' DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' wordFinalise
'---------------------------------------------------------------------------------------

Public Sub wordFinalise(ByRef wd As Word.Application, ByRef doc As Word.Document)
10       On Error GoTo Err_label

15    DoEvents

      Dim obj As Word.TableOfFigures
      
      DoEvents
      Sleep (1000)
20    For Each obj In doc.TablesOfFigures
30        obj.Update
40    Next

50    wd.DisplayAlerts = wdAlertsMessageBox

60    wd.Options.CheckGrammarAsYouType = fCheckGrammarAsYouTypeSave
70    wd.Options.CheckSpellingAsYouType = fCheckSpellingAsYouTypeSave

    'DD Error Handler Start
Exit_label:
80        Exit Sub
Err_label:
90        Select Case Err.Number
    Case Else
100      Call LogError("basMBOProgramReport_Word", "wordFinalise")
110       End Select
120       Resume Exit_label
    ' DD Error Handler End
End Sub


'---------------------------------------------------------------------------------------
' CreateStyles
'---------------------------------------------------------------------------------------
' These styles are shared by the Annual and Multi-year reports

Public Sub CreateStyles(ByRef doc As Word.Document)

      Dim oStyle As Word.Style

      ' Style ddBase

10    On Error GoTo Err_label

20    Set oStyle = doc.Styles.Add(Name:="ddBase", Type:=wdStyleTypeParagraph)

30    With oStyle
40        .LanguageID = wdEnglishCanadian
50        .AutomaticallyUpdate = False
60        .NextParagraphStyle = "ddBase"
70        .BaseStyle = ""
80        With .Font
90            .Name = "Calibri"
100           .Size = 11
110       End With
120       With .ParagraphFormat
130           .Alignment = wdAlignParagraphLeft
140           .LineSpacingRule = wdLineSpaceSingle
150           .SpaceBefore = 0
160           .SpaceAfter = 0
170       End With
180   End With

      ' Style ddBody

190   On Error GoTo Err_label

200   Set oStyle = doc.Styles.Add(Name:="ddBody", Type:=wdStyleTypeParagraph)

210   With oStyle
220       .NextParagraphStyle = "ddBody"
230       .BaseStyle = "ddBase"
240       With .ParagraphFormat
250           .Alignment = wdAlignParagraphJustify
260           .SpaceAfter = 6
270       End With
280   End With

      '      ' Style ddBody L06
      '
      '290   Set oStyle = doc.Styles.Add(Name:="ddBody L06", Type:=wdStyleTypeParagraph)
      '
      '300   With oStyle
      '310       .NextParagraphStyle = "ddBody L06"
      '320       .BaseStyle = "ddBase"
      '330       With .ParagraphFormat
      '340           .SpaceAfter = 6
      '350       End With
      '360   End With

      '      ' Style ddBody L00
      '
      '370   Set oStyle = doc.Styles.Add(Name:="ddBody L00", Type:=wdStyleTypeParagraph)
      '
      '380   With oStyle
      '390       .NextParagraphStyle = "ddBody L00"
      '400       .BaseStyle = "ddBase"
      '410   End With

      ' Style ddTableAfter

290   Set oStyle = doc.Styles.Add(Name:="ddTableAfter", Type:=wdStyleTypeParagraph)

300   With oStyle
310       .LanguageID = wdEnglishCanadian
320       .AutomaticallyUpdate = False
330       .NextParagraphStyle = "ddTableAfter"
340       .BaseStyle = ""
350       With .Font
360           .Name = "Calibri"
370           .Size = 11
380       End With
390       With .ParagraphFormat
400           .Alignment = wdAlignParagraphLeft
410           .LineSpacingRule = wdLineSpaceSingle
420           .SpaceBefore = 0
430           .SpaceAfter = 0
440       End With
450   End With

      ' Style Table of Figures

      Dim intRetries As Integer
460   For intRetries = 1 To 10

470       On Error Resume Next
480       Err.Clear

490       If StyleExists(doc, "Table of Figures") Then
500           Set oStyle = doc.Styles("Table of Figures")
510           With oStyle
520               .BaseStyle = "ddBase"
530               With .ParagraphFormat
540                   .RightIndent = doc.Application.InchesToPoints(0.1)
550                   .LeftIndent = doc.Application.InchesToPoints(0.5)
560                   .FirstLineIndent = doc.Application.InchesToPoints(-0.5)
570                   .TabStops.Add Position:=doc.Application.InchesToPoints(6.92), Alignment:=wdAlignTabRight
580               End With
590            End With
600       End If

610       If Err.Number = 0 Then Exit For
620       Sleep 1000
630       LogError "basMBOAnnualProgramReport", "CreateStyles", "Failed on attempt #" & intRetries, True
640   Next

650   If intRetries = 11 Then
660       LogError "basMBOAnnualProgramReport", "CreateStyles", "Failed after 10 attempts", False
670       End
680   End If

      ' Style ddTableCaption

690   Set oStyle = doc.Styles.Add(Name:="ddTableCaption", Type:=wdStyleTypeParagraph)

700   With oStyle
710       .BaseStyle = "ddBase"
720       .ParagraphFormat.FirstLineIndent = doc.Application.InchesToPoints(0.1)
730       .ParagraphFormat.KeepWithNext = True
740       .ParagraphFormat.SpaceBefore = 11
750       .ParagraphFormat.SpaceAfter = 3
760   End With

      ' Style ddTableTOC

770   Set oStyle = doc.Styles.Add(Name:="ddTableTOC", Type:=wdStyleTypeParagraph)

780   With oStyle
790       .BaseStyle = "ddBase"
800       .ParagraphFormat.FirstLineIndent = doc.Application.InchesToPoints(0.1)
810       .ParagraphFormat.KeepWithNext = True
820   End With

      ' Style ddTableCaptionAfter

830   Set oStyle = doc.Styles.Add(Name:="ddTableCaptionAfter", Type:=wdStyleTypeParagraph)

840   With oStyle
850       .BaseStyle = "ddBase"
860       .ParagraphFormat.FirstLineIndent = doc.Application.InchesToPoints(0.1)
870       .Font.Size = 3
880       .ParagraphFormat.KeepWithNext = True
890   End With

      ' Style ddFigureCaption

900   Set oStyle = doc.Styles.Add(Name:="ddFigureCaption", Type:=wdStyleTypeParagraph)

910   With oStyle
920       .BaseStyle = "ddBase"
930       .ParagraphFormat.FirstLineIndent = doc.Application.InchesToPoints(0.1)
940       .ParagraphFormat.SpaceBefore = 3
950       .ParagraphFormat.SpaceAfter = 17
960   End With

      ' Style ddFigureTOC

970   Set oStyle = doc.Styles.Add(Name:="ddFigureTOC", Type:=wdStyleTypeParagraph)

980   With oStyle
990       .BaseStyle = "ddBase"
1000      .ParagraphFormat.FirstLineIndent = doc.Application.InchesToPoints(0.1)
1010      .ParagraphFormat.SpaceAfter = 0
1020  End With

      ' Style ddPhotoCaption

1030  Set oStyle = doc.Styles.Add(Name:="ddFigureCaption", Type:=wdStyleTypeParagraph)

1040  With oStyle
1050      .BaseStyle = "ddBase"
1060      .ParagraphFormat.SpaceBefore = 0
1070      .ParagraphFormat.SpaceAfter = 3
1080  End With

      ' Style "ddData"

1090  Set oStyle = doc.Styles.Add(Name:="ddData", Type:=wdStyleTypeParagraph)

1100  With oStyle

1110      .LanguageID = wdEnglishCanadian
1120      .AutomaticallyUpdate = False
1130      .NextParagraphStyle = "ddData"
1140      .BaseStyle = ""

1150      With .Font
1160          .Name = "Calibri"
1170          .Size = 10
1180      End With

1190      With .ParagraphFormat
1200          .Alignment = wdAlignParagraphCenter
1210          .LineSpacingRule = wdLineSpaceSingle
1220          .SpaceBefore = 0
1230          .SpaceAfter = 0
1240      End With
1250  End With

      ' Style "ddDataNarrow"

1260  Set oStyle = doc.Styles.Add(Name:="ddDataNarrow", Type:=wdStyleTypeParagraph)

1270  With oStyle

1280      .LanguageID = wdEnglishCanadian
1290      .AutomaticallyUpdate = False
1300      .NextParagraphStyle = "ddDataNarrow"
1310      .BaseStyle = ""

1320      With .Font
1330          .Name = "Arial Narrow"
1340          .Size = 10
1350      End With

1360      With .ParagraphFormat
1370          .Alignment = wdAlignParagraphCenter
1380          .LineSpacingRule = wdLineSpaceSingle
1390          .SpaceBefore = 0
1400          .SpaceAfter = 0
1410      End With
1420  End With



      ' Style "ddHeaderRow"

1430  Set oStyle = doc.Styles.Add(Name:="ddHeaderRow", Type:=wdStyleTypeParagraph)

1440  With oStyle

1450      .NextParagraphStyle = "ddData"
1460      .BaseStyle = "ddData"

1470      With .Font
1480          .Color = wdColorWhite
1490          .Bold = True
1500          .Size = 9
1510      End With

1520  End With

      ' Style "ddLabelsColumn"

1530  Set oStyle = doc.Styles.Add(Name:="ddLabelsColumn", Type:=wdStyleTypeParagraph)

1540  With oStyle

1550      .NextParagraphStyle = "ddData"
1560      .BaseStyle = "ddData"
1570      .ParagraphFormat.Alignment = wdAlignParagraphLeft

1580      With .Font
1590          .Bold = True
1600      End With

1610  End With

      ' Style ddSummarySpacingBetweenTables

1620  On Error GoTo Err_label

1630  Set oStyle = doc.Styles.Add(Name:="ddSummarySpacingBetweenTables", Type:=wdStyleTypeParagraph)

1640  With oStyle
1650      .NextParagraphStyle = "ddSummarySpacingBetweenTables"
1660      .BaseStyle = "ddBase"
1670      With .Font
1680          .Size = 2
1690      End With
1700      With .ParagraphFormat
1710          .LineSpacingRule = wdLineSpaceSingle
1720          .SpaceBefore = 0
1730          .SpaceAfter = 0
1740      End With
1750  End With

1760  Call NewStyle(doc, "ddTOCFiguresHeading", "ddBase", 0)
1770  Call NewStyle(doc, "ddTOCTablesHeading", "ddBase", 0)

1780  Call NewStyle(doc, "ddEffortData", "ddData", 0)
1790  Call NewStyle(doc, "ddSummaryData", "ddData", 0)
1800  Call NewStyle(doc, "ddSummaryNA", "ddSummaryData", -1)
1810  Call NewStyle(doc, "ddTop10SpeciesBandedData", "ddDataNarrow", -2)
1820  Call NewStyle(doc, "ddReturnsData", "ddData", -1)
1830  Call NewStyle(doc, "ddTop10SpeciesRepeatsData", "ddData", -1)
1840  Call NewStyle(doc, "ddPrioritySpeciesData", "ddData", 0)
1850  Call NewStyle(doc, "ddNetUsageData", "ddData", 0)
1860  Call NewStyle(doc, "ddSpeciesTitle", "ddData", 1, wdAlignParagraphLeft, fBold:=True)
1870  Call NewStyle(doc, "ddSpeciesData", "ddData", -3)
1880  Call NewStyle(doc, "ddSpeciesHeaderRow1", "ddData", -1)
1890  Call NewStyle(doc, "ddSpeciesHeaderRow2", "ddData", -3)
1900  Call NewStyle(doc, "ddSpeciesLastRow", "ddData", -3)
1910  Call NewStyle(doc, "ddSpeciesLabelsColumn", "ddData", -3)
1920  Call NewStyle(doc, "ddSpeciesBetweenTables", "ddData", 0, dblSize:=2#)
1930  Call NewStyle(doc, "ddHeaderRowTop10SpeciesBandedWinterRow1", "ddHeaderRow", -1, fBold:=True)
1940  Call NewStyle(doc, "ddHeaderRowTop10SpeciesBandedWinterRow2", "ddHeaderRow", 0, fBold:=True)

1950  With doc.Styles("ddHeaderRowTop10SpeciesBandedWinterRow1").ParagraphFormat
1960      .LineSpacingRule = wdLineSpaceExactly
1970      .LineSpacing = 8
1980  End With
1990  With doc.Styles("ddHeaderRowTop10SpeciesBandedWinterRow2").ParagraphFormat
2000      .LineSpacingRule = wdLineSpaceExactly
2010      .LineSpacing = 9
2020  End With

2030  Call NewStyle(doc, "ddOverviewData", "ddData", -3)
2040  Call NewStyle(doc, "ddOverviewLabelColumn", "ddLabelsColumn", -3, wdAlignParagraphCenter)
2050  Call NewStyle(doc, "ddOverviewYearColumn", "ddLabelsColumn", -3, wdAlignParagraphCenter)
2060  Call NewStyle(doc, "ddOverviewHeaderRow", "ddHeaderRow", 0)
2070  Call NewStyle(doc, "ddOverviewHeaderYear", "ddHeaderRow", -1)
2080  Call NewStyle(doc, "ddOverviewHeaderFinal", "ddHeaderRow", -1)

2090  Call NewStyle(doc, "ddTop10HeaderRow", "ddHeaderRow", 0)
2100  Call NewStyle(doc, "ddTop10Data", "ddData", -1, wdAlignParagraphCenter)
2110  Call NewStyle(doc, "ddTop10Title", "ddData", -1, wdAlignParagraphCenter, fBold:=True)
2120  Call NewStyle(doc, "ddMultiYearTop10ColumnHeader", "ddData", -1, wdAlignParagraphCenter)
2130  Call NewStyle(doc, "ddMultiYearTop10NoXXXDuringPeriod", "ddData", -2, wdAlignParagraphCenter)
2140  Call NewStyle(doc, "ddMultiYearTop10Data", "ddData", -2, wdAlignParagraphCenter)
2150  Call NewStyle(doc, "ddMultiYearTop10DataMYWA", "ddMultiYearTop10Data", -1, wdAlignParagraphCenter)

2160  Call NewStyle(doc, "ddMultiYearSpeciesTitle", "ddBase", 0, fBold:=True)
2170  Call NewStyle(doc, "ddMultiYearSpeciesHeaderRow", "ddData", -2, fBold:=True)
2180  Call NewStyle(doc, "ddMultiYearSpeciesLabelColumn", "ddData", -2, fBold:=True)
2190  Call NewStyle(doc, "ddMultiYearSpeciesLabelObserved", "ddData", -2, fBold:=True, lngFontColour:=RGB(112, 48, 160))
2200  Call NewStyle(doc, "ddMultiYearSpeciesLabelBanded", "ddData", -2, fBold:=True, lngFontColour:=RGB(192, 0, 0))
2210  Call NewStyle(doc, "ddMultiYearSpeciesData", "ddData", -2, wdAlignParagraphCenter)
2220  Call NewStyle(doc, "ddMultiYearSpeciesTableAfter", "ddBase", 0, dblSize:=2#, dblSpaceAfter:=0)
2230  Call NewStyle(doc, "ddMultiYearSpecies_SpeciesDET_Label", "ddData", -2.5, fBold:=True)
2240  Call NewStyle(doc, "ddMultiYearSpecies_SpeciesDET_Heading", "ddData", -2.5, fBold:=True)
2250  Call NewStyle(doc, "ddMultiYearSpecies_SpeciesDET_Detail", "ddData", -2.5, fBold:=False)
2260  Call NewStyle(doc, "ddMultiYearSpecies_SpeciesDET_Summary", "ddData", -2.5, fBold:=False)

2270  Call NewStyle(doc, "ddMultiYearSpecies_Period_Label", "ddData", -2.5, fBold:=True)
2280  Call NewStyle(doc, "ddMultiYearSpecies_Period_Heading", "ddDataNarrow", -2.5, fBold:=True)
2290  Call NewStyle(doc, "ddMultiYearSpecies_Period_Detail", "ddDataNarrow", -2.5, fBold:=False)
2300  Call NewStyle(doc, "ddMultiYearSpecies_Period_SeasonSummary", "ddDataNarrow", -2.5, fBold:=False)

2310  Call NewStyle(doc, "ddMultiYearSeasonal", "ddBase", -1, dblSpaceAfter:=3)
2320  Call NewStyle(doc, "ddMultiYearSeasonalPeriod", "ddMultiYearSeasonal", 0, fBold:=True)
2330  Call NewStyle(doc, "ddMultiYearSeasonalData", "ddMultiYearSeasonal", 0)
2340  Call NewStyle(doc, "ddMultiYearSeasonalSpeciesObserved", "ddMultiYearSeasonal", 0, fBold:=True, lngFontColour:=RGB(128, 128, 128), fItalic:=True)

2350  Call NewStyle(doc, "ddAbundanceHeaderRow1", "ddData", -2)
2360  Call NewStyle(doc, "ddAbundanceData", "ddData", -2)
2370  Call NewStyle(doc, "ddMultiYearAbundanceTopLegendAbundanceLabel", "ddData", -2, wdAlignParagraphCenter, fBold:=True)
2380  Call NewStyle(doc, "ddMultiYearAbundanceTopLegendAbundanceImage", "ddData", -2, wdAlignParagraphCenter, dblSpaceBefore:=0, dblSpaceAfter:=0)
2390  Call NewStyle(doc, "ddMultiYearAbundanceTopLegendAbundanceDescription", "ddData", -2, wdAlignParagraphLeft)
2400  Call NewStyle(doc, "ddMultiYearAbundanceSummaryAbundanceLabel", "ddData", -2.5, wdAlignParagraphCenter, fBold:=True)
2410  Call NewStyle(doc, "ddMultiYearAbundanceSummaryData", "ddData", -2, wdAlignParagraphCenter)
2420  Call NewStyle(doc, "ddMultiYearAbundanceSummaryTitle", "ddData", -2, wdAlignParagraphCenter, fBold:=True, dblSpaceBefore:=3, dblSpaceAfter:=3)

2430  Call NewStyle(doc, "ddMultiYearEncountersHeaderRow", "ddData", -2, wdAlignParagraphCenter)
2440  Call NewStyle(doc, "ddMultiYearEncountersData", "ddData", -2, wdAlignParagraphCenter)

2450  Call NewStyle(doc, "ddMultiYear_BirdsOfMBO_Header", "ddData", -2, wdAlignParagraphCenter, fBold:=True)
2460  Call NewStyle(doc, "ddMultiYear_BirdsOfMBO_Header_Total", "ddData", -2, wdAlignParagraphCenter, fBold:=True, lngFontColour:=vbWhite)
2470  Call NewStyle(doc, "ddMultiYear_BirdsOfMBO_Label", "ddData", -2, wdAlignParagraphLeft)
2480  Call NewStyle(doc, "ddMultiYear_BirdsOfMBO_Data", "ddData", -2, wdAlignParagraphCenter)

2490  Call NewStyle(doc, "ddMultiYear_Volunteers", "ddBase", -1)
2500  With doc.Styles("ddMultiYear_Volunteers").ParagraphFormat
2510        .TabStops.Add Position:=doc.Application.CentimetersToPoints(4)
2520        .TabHangingIndent (1)
2530  End With



      'DD Error Handler Start
Exit_label:
2540       Exit Sub
Err_label:
2550       Select Case Err.Numbe
           Case Else
2560      Call LogError("basMBOAnnualProgramReport", "CreateStyles")
2570       End Select
2580       Resume Exit_label
      'DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' NewStyle
'---------------------------------------------------------------------------------------

Private Sub NewStyle(ByRef doc As Word.Document, _
    ByVal strNewStyleName As String, _
    ByVal strBaseStyleName As String, _
    ByVal dblPointsIncrease As Double, _
    Optional ByVal intAlignment As Integer = -1, _
    Optional ByVal fBold As Boolean = False, _
    Optional ByVal dblSize As Double = -1#, _
    Optional ByVal lngFontColour As Long = -1, _
    Optional ByVal dblSpaceAfter As Double = -1, _
    Optional ByVal fItalic As Boolean, _
    Optional ByVal dblSpaceBefore As Double = -1)

   On Error GoTo Err_label

10    On Error GoTo Err_label

      Dim oStyle As Word.Style

20    Set oStyle = doc.Styles.Add(Name:=strNewStyleName, Type:=wdStyleTypeParagraph)

30    With oStyle

40        .NextParagraphStyle = strBaseStyleName
50        .BaseStyle = strBaseStyleName

60        If intAlignment <> -1 Then
70            .ParagraphFormat.Alignment = intAlignment
80        End If

90        With .Font
100           If dblSize > 0 Then
110               .Size = dblSize
120           Else
130               .Size = doc.Styles(strBaseStyleName).Font.Size + dblPointsIncrease
140           End If
150           .Bold = fBold
160           If lngFontColour <> -1 Then
170               .Color = lngFontColour
180           End If
190           .Italic = fItalic

200       End With

210       If dblSpaceAfter <> -1 Then
220           .ParagraphFormat.SpaceAfter = dblSpaceAfter
230       End If

240       If dblSpaceBefore <> -1 Then
250           .ParagraphFormat.SpaceBefore = dblSpaceBefore
260       End If

270   End With

    'DD Error Handler Start
Exit_label:
    Exit Sub
Err_label:
    Select Case Err.Number
    Case Else
         Call LogError("basMBOProgramReport_Word", "NewStyle")
    End Select
    Resume Exit_label
    ' DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' WordGenerateCaption
'---------------------------------------------------------------------------------------
' strTableOrFigure:       "Table", "Figure"
' strTableCaptionHeading:  table#, figure#
' strTableCaptionBody:     caption for the table of tables;   A period is appended for the caption in the body

Public Sub WordGenerateCaption(ByRef wd As Word.Application, ByRef doc As Word.Document, _
    ByVal strTableOrFigure As String, _
    ByVal strTableCaptionHeading As String, _
    ByVal strTableCaptionBody As String)

10    On Error GoTo Err_label

20    Call InsertTableCaptionXX(wd, doc, strTableOrFigure, _
        strTableCaptionHeading, _
        strTableCaptionBody & ".", _
        strTableCaptionBody)

    'DD Error Handler Start
Exit_label:
30        Exit Sub
Err_label:
40        Select Case Err.Number
    Case Else
50       Call LogError("basMBOProgramReport_Word", "WordGenerateCaption")
60        End Select
70        Resume Exit_label
    ' DD Error Handler End

End Sub


'---------------------------------------------------------------------------------------
' InsertTableCaptionXX
'
' strTableOrFigure: "Table", "Figure"
' strID:             table#, figure#
' strCaption:        caption in the body
' strTC:             entry in the Table of tables/figures
'---------------------------------------------------------------------------------------

Public Sub InsertTableCaptionXX(ByRef wd As Word.Application, ByRef doc As Word.Document, _
    ByVal strTableOrFigure As String, _
    ByVal strID As String, _
    ByVal strCaption As String, _
    ByVal strTC As String)

      Dim range As Word.range
      Dim lngStart As Long
      Dim lngEnd As Long
      Dim strTableID As String

      Dim lngSectionAStart As Long
      Dim lngStrongStart As Long
      Dim lngStrongEnd As Long
      Dim lngSectionAEnd As Long
      Dim lngSectionBStart As Long
      Dim lngSectionBEnd As Long
      Dim lngSectionCStart As Long
      Dim lngSectionCEnd As Long

10    On Error GoTo Err_label

20    strTableID = IIf(strTableOrFigure = "Figure", "F", "T")

30    Set range = doc.Characters.Last
40    lngSectionAStart = range.start
50    lngStrongStart = range.start

60    range.InsertAfter IIf(strTableOrFigure = "Figure", "Figure ", "Table ") & strID & ":  "
70    lngStrongEnd = range.End

80    range.InsertAfter strCaption
90    range.InsertParagraphAfter
100   lngSectionAEnd = range.End

110   Set range = doc.Characters.Last
120   lngSectionBStart = range.start

130   doc.TablesOfContents.MarkEntry range:=range, Entry:=strID & ":" & vbTab & strTC, _
         TableID:=strTableID, level:=1

140   Set range = doc.Characters.Last
150   range.InsertParagraphAfter
160   lngSectionBEnd = range.End

170   Set range = doc.Characters.Last
180   lngSectionCStart = range.start
190   range.InsertParagraphAfter
200   lngSectionCEnd = range.End

210   doc.range(lngSectionAStart, lngSectionAEnd).Style = _
          IIf(strTableOrFigure = "Figure", "ddFigureCaption", "ddTableCaption")

220   doc.range(lngSectionBStart, lngSectionBEnd).Style = _
          IIf(strTableOrFigure = "Figure", "ddFigureTOC", "ddTableTOC")

230   doc.range(lngSectionCStart, lngSectionCEnd).Style = _
          IIf(strTableOrFigure = "Figure", "ddFigureCaption", "ddTableCaption")

240   doc.range(lngStrongStart, lngStrongEnd - 1).Style = "Strong"

250   doc.range(lngSectionAStart, lngSectionAEnd).Select
260   wd.Selection.InsertStyleSeparator

270   doc.range(lngSectionBStart, lngSectionBEnd).Select
280   wd.Selection.InsertStyleSeparator

    'DD Error Handler Start
Exit_label:
290       Exit Sub
Err_label:
300       Select Case Err.Number
    Case Else
310      Call LogError("basMBOProgramReport_Word", "InsertTableCaptionXX")
320       End Select
330       Resume Exit_label
    ' DD Error Handler End

    End Sub


'---------------------------------------------------------------------------------------
' MBOAnnualProgramReportTC
'---------------------------------------------------------------------------------------
 
Public Sub MBOProgramReportTC(ByRef wd As Word.Application, ByRef doc As Word.Document)

10    SysCmd acSysCmdSetStatus, "Tables of tables and figures"

      Dim range As Word.range

20    doc.ActiveWindow.View.ShowHiddenText = True
      
      ' Insert a table of tables (TC technology)

30    On Error GoTo Err_label

40    Set range = MoveInsertionPointToEndOfDocument(wd, doc)
50    range.InsertAfter "Figures:"
60    range.Style = "ddTOCTablesHeading"
70    range.Font.Bold = True

80    Set range = MoveInsertionPointToEndOfDocument(wd, doc)
90    With doc
100     .TablesOfFigures.Add range:=range, Caption:="", _
            IncludeLabel:=False, RightAlignPageNumbers:=True, UseHeadingStyles:=False, _
            UpperHeadingLevel:=1, LowerHeadingLevel:=3, UseFields:=True, TableID:="F", _
            IncludePageNumbers:=True, AddedStyles:="", UseHyperlinks:=False, _
            HidePageNumbersInWeb:=True
110     .TablesOfFigures(1).TabLeader = wdTabLeaderSpaces
120     .TablesOfFigures.Format = wdIndexIndent
130   End With

140   Set range = MoveInsertionPointToEndOfDocument(wd, doc)
150   range.InsertParagraphAfter
160   range.InsertParagraphAfter

      ' Insert a table of figures (TC technology)

170   Set range = MoveInsertionPointToEndOfDocument(wd, doc)
180   range.InsertAfter "Tables:"
190   range.Style = "ddTOCFiguresHeading"
200   range.Font.Bold = True

210   Set range = MoveInsertionPointToEndOfDocument(wd, doc)
220   With doc
230     .TablesOfFigures.Add range:=range, Caption:="", _
            IncludeLabel:=False, RightAlignPageNumbers:=True, UseHeadingStyles:=False, _
            UpperHeadingLevel:=1, LowerHeadingLevel:=3, UseFields:=True, TableID:="T", _
            IncludePageNumbers:=True, AddedStyles:="", UseHyperlinks:=False, _
            HidePageNumbersInWeb:=True
240     .TablesOfFigures(2).TabLeader = wdTabLeaderSpaces
250     .TablesOfFigures.Format = wdIndexIndent
260   End With

270   Set range = MoveInsertionPointToEndOfDocument(wd, doc)
280   range.InsertParagraphAfter
290   range.InsertParagraphAfter

300   SysCmd acSysCmdClearStatus

      'DD Error Handler Start
Exit_label:
310        Exit Sub
Err_label:
320        Select Case Err.Number
           Case Else
330             Call LogError("basMBOAnnualProgramReportTC", "MBOAnnualProgramReportTC")
340        End Select
350        Resume Exit_label
      'DD Error Handler End

End Sub
