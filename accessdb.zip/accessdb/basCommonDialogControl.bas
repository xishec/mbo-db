'---------------------------------------------------------------------------------------
' Module: basCommonDialogControl
' Author: David Davey
'---------------------------------------------------------------------------------------

Option Compare Database
Option Explicit

'---------------------------------------------------------------------------------------
' FileOpenDialog
'---------------------------------------------------------------------------------------
' If strDirectory contains an invalid path, this function will use the path to the Documents folder
' If the user cancels, this function returns ""
' Otherwise it returns the full path to the selected file

Private Function FileOpenDialog( _
    ByVal strExcelorAccess As String, _
    ByVal strDirectory As String, _
    ByVal strTitleForDialog As String) As String
          
10    On Error GoTo Err_label

      Dim F As Office.FileDialog
      Dim strFilepath As String
      Dim strDefaultTitle As String

20    Select Case strExcelorAccess
      Case "Excel"
30        strDefaultTitle = "Open an Excel file"
40    Case "Access"
50        strDefaultTitle = "Open an Access file"
60    Case Else
70            strDefaultTitle = "Open a file"
80    End Select

90    If Nz(strDirectory) = "" Then
100       strDirectory = Rep_Documents()
110   End If

120   If strTitleForDialog = "" Then
130       strTitleForDialog = strDefaultTitle
140   End If

150   Set F = Application.FileDialog(msoFileDialogOpen)
160   F.AllowMultiSelect = False
170   F.Filters.Clear
180   Select Case strExcelorAccess
      Case "Excel"
190       F.Filters.Add "Excel *.xlsx,*.xlsm)", "*.xlsx;*.xlsm"
200   Case "Access"
210       F.Filters.Add "Access (*.accdb)", "*.accdb"
220   Case Else
230   End Select

240   F.Filters.Add "All files (*.*)", "*.*"
250   F.Title = strTitleForDialog
260   F.InitialFileName = strDirectory

      ' There is a known bug when using the dialog box.  It occurs if you call GetOpenFileNameA too
      ' The user can only see the last few characters of the filepath
      ' If the user presses the Home key then the user gets to see all of the filepath
      ' The hack is for code to press the Home key


270   On Error Resume Next
280   SendKeys "{Home}"
290   On Error Resume Next

300   If F.Show = -1 Then
310       If F.SelectedItems.count = 0 Then
              ' No file was selected - I don't think this is possible, but just in case
              ' Either the user selects a file or cancels
320           strFilepath = ""
330       Else
340           strFilepath = F.SelectedItems(1)
350       End If
360   Else
370       strFilepath = ""
380   End If

390   FileOpenDialog = strFilepath

      'DD Error Handler Start
Exit_label:
400        Exit Function
Err_label:
410        Select Case Err.Number
           Case Else
420             Call LogError("basCommonDialogControl", "FileOpenDialog")
430        End Select
440        Resume Exit_label
      'DD Error Handler End
End Function

Public Function FileOpenDialogAccess( _
    Optional ByVal strDirectory As String = "", _
    Optional ByVal strTitleForDialog As String = "") As String
          
10       On Error GoTo Err_label

20        FileOpenDialogAccess = FileOpenDialog("Access", strDirectory, strTitleForDialog)
          
          'DD Error Handler Start
Exit_label:
30        Exit Function
Err_label:
40        Select Case Err.Number
          Case Else
50             Call LogError("basCommonDialogControl", "FileOpenDialogAccess")
60        End Select
70        Resume Exit_label
          ' DD Error Handler End
          
End Function

'---------------------------------------------------------------------------------------
' FileOpenDialogExcel
'---------------------------------------------------------------------------------------
'Dim strDirectory As String
'Dim strTitleForDialog As String
'
'strDirectory = ""
'strTitleForDialog = ""
'Call FileOpenDialogExcel(strDirectory, strTitleForDialog)

' Public Function FileOpenDialogExcel( _
'   Optional ByVal strDirectory As String = "", _
'   Optional ByVal strTitleForDialog As String = "") As String
'
' Browse for an Excel file that is to be opened
'---------------------------------------------------------------------------------------

Public Function FileOpenDialogExcel( _
    Optional ByVal strDirectory As String = "", _
    Optional ByVal strTitleForDialog As String = "") As String
          
10       On Error GoTo Err_label

20        FileOpenDialogExcel = FileOpenDialog("Excel", strDirectory, strTitleForDialog)
          
          'DD Error Handler Start
Exit_label:
30        Exit Function
Err_label:
40        Select Case Err.Number
          Case Else
50             Call LogError("basCommonDialogControl", "FileOpenDialogExcel")
60        End Select
70        Resume Exit_label
          ' DD Error Handler End
          
End Function

'---------------------------------------------------------------------------------------
' FileOpenDialog_Test
'---------------------------------------------------------------------------------------

Public Sub FileOpenDialog_Test()
      Dim strDirectory As String
      Dim strTitleForDialog As String

10    strDirectory = ""
20    strTitleForDialog = ""
30    Debug.Print FileOpenDialogExcel(strDirectory, strTitleForDialog)

40    strDirectory = "C:\"
50    strTitleForDialog = "My Title"
60    Debug.Print FileOpenDialogExcel(strDirectory, strTitleForDialog)

70    strDirectory = "Y:\"
80    strTitleForDialog = ""
90    Debug.Print FileOpenDialogExcel(strDirectory, strTitleForDialog)


100   strDirectory = ""
110   strTitleForDialog = ""
120   Debug.Print FileOpenDialogAccess(strDirectory, strTitleForDialog)

End Sub


'---------------------------------------------------------------------------------------
' FileSaveDialog
'---------------------------------------------------------------------------------------

Private Function FileSaveDialog( _
    ByVal strExcelorWordorHTMLorTxt As String, _
    ByVal strInitialSaveFilename As String, _
    ByVal strDirectory As String, _
    ByVal strTitleForDialog As String) As String
          
10    On Error GoTo Err_label

      Dim F As Office.FileDialog
      Dim strFilepath As String
      Dim strDefaultTitle As String

20    Select Case strExcelorWordorHTMLorTxt
      Case "Excel"
30        strDefaultTitle = "Save an Excel file"
40    Case "Word"
50        strDefaultTitle = "Save a Word file"
60    Case "HTML"
70        strDefaultTitle = "Save a HTML file"
80    Case "Txt"
90        strDefaultTitle = "Save a Text file"
100   Case Else
110           strDefaultTitle = "Save a file"
120   End Select

130   If Nz(strDirectory) = "" Then
140       strDirectory = Rep_Documents()
150   End If

160   If strTitleForDialog = "" Then
170       strTitleForDialog = strDefaultTitle
180   End If

190   Set F = Application.FileDialog(msoFileDialogSaveAs)
200   F.AllowMultiSelect = False

      ' Office.FileDialog refuses to use Filters when saving as ...

210   F.Title = strTitleForDialog
220   F.InitialFileName = TrailingSlash(strDirectory) & strInitialSaveFilename

230   If F.Show = -1 Then
240       If F.SelectedItems.count = 0 Then
              ' No file was selected - I don't think this is possible, but just in case
              ' Either the user selects a file or cancels
250           strFilepath = ""
260       Else
270           strFilepath = F.SelectedItems(1)
280       End If
290   Else
300       strFilepath = ""
310   End If

320   FileSaveDialog = strFilepath

          'DD Error Handler Start
Exit_label:
330       Exit Function
Err_label:
340       Select Case Err.Number
          Case Else
350      Call LogError("basCommonDialogControl", "FileSaveDialog")
360       End Select
370       Resume Exit_label
          ' DD Error Handler End

End Function

'---------------------------------------------------------------------------------------
' FileSaveDialogExcel
'---------------------------------------------------------------------------------------

Public Function FileSaveDialogExcel( _
    ByVal strInitialSaveFilename As String, _
    Optional ByVal strDirectory As String = "", _
    Optional ByVal strTitleForDialog As String = "") As String
          
10       On Error GoTo Err_label

20        If Right(strInitialSaveFilename, 5) <> ".xlsx" Then
30            strInitialSaveFilename = strInitialSaveFilename & ".xlsx"
40        End If
          
50        FileSaveDialogExcel = FileSaveDialog("Excel", strInitialSaveFilename, strDirectory, strTitleForDialog)
          

          'DD Error Handler Start
Exit_label:
60        Exit Function
Err_label:
70        Select Case Err.Number
          Case Else
80             Call LogError("basCommonDialogControl", "FileSaveDialogExcel")
90        End Select
100       Resume Exit_label
          ' DD Error Handler End
          
End Function
    
'---------------------------------------------------------------------------------------
' FileSaveDialogExcel
'---------------------------------------------------------------------------------------

Public Function FileSaveDialogWord( _
    ByVal strInitialSaveFilename As String, _
    Optional ByVal strDirectory As String = "", _
    Optional ByVal strTitleForDialog As String = "") As String
          
10       On Error GoTo Err_label

20        If Right(strInitialSaveFilename, 5) <> ".docx" Then
30           strInitialSaveFilename = strInitialSaveFilename & ".docx"
40        End If

50        FileSaveDialogWord = FileSaveDialog("Word", strInitialSaveFilename, strDirectory, strTitleForDialog)
          
          'DD Error Handler Start
Exit_label:
60        Exit Function
Err_label:
70        Select Case Err.Number
          Case Else
80             Call LogError("basCommonDialogControl", "FileSaveDialogWord")
90        End Select
100       Resume Exit_label
          ' DD Error Handler End
          
End Function
    

'---------------------------------------------------------------------------------------
' FileSaveDialogHTML
'---------------------------------------------------------------------------------------

Public Function FileSaveDialogHTML( _
    ByVal strInitialSaveFilename As String, _
    Optional ByVal strDirectory As String = "", _
    Optional ByVal strTitleForDialog As String = "") As String
          
10       On Error GoTo Err_label

20        If Right(strInitialSaveFilename, 5) <> ".html" Then
30           strInitialSaveFilename = strInitialSaveFilename & ".html"
40        End If

50        FileSaveDialogHTML = FileSaveDialog("HTML", strInitialSaveFilename, strDirectory, strTitleForDialog)
          
          'DD Error Handler Start
Exit_label:
60        Exit Function
Err_label:
70        Select Case Err.Number
          Case Else
80             Call LogError("basCommonDialogControl", "FileSaveDialogHTML")
90        End Select
100       Resume Exit_label
          ' DD Error Handler End
          
End Function
    

'---------------------------------------------------------------------------------------
' FileSaveDialogTxt
'---------------------------------------------------------------------------------------

Public Function FileSaveDialogTxt( _
    ByVal strInitialSaveFilename As String, _
    Optional ByVal strDirectory As String = "", _
    Optional ByVal strTitleForDialog As String = "") As String
          
10       On Error GoTo Err_label

20        If Right(strInitialSaveFilename, 4) <> ".txt" Then
30           strInitialSaveFilename = strInitialSaveFilename & ".txt"
40        End If

50        FileSaveDialogTxt = FileSaveDialog("Txt", strInitialSaveFilename, strDirectory, strTitleForDialog)
          
          'DD Error Handler Start
Exit_label:
60        Exit Function
Err_label:
70        Select Case Err.Number
          Case Else
80             Call LogError("basCommonDialogControl", "FileSaveDialogTxt")
90        End Select
100       Resume Exit_label
          ' DD Error Handler End
          
End Function

Public Function FileSaveDialog_Test()
      Dim strInitialSaveFilename As String
      Dim strDirectory As String
      Dim strDirectoryForDialog As String

10    On Error GoTo Err_label

20    strInitialSaveFilename = "test.txt"
30    strDirectory = ""
40    strDirectoryForDialog = "My title"
50    Debug.Print FileSaveDialogTxt(strInitialSaveFilename, strDirectory, strDirectoryForDialog)

60    strInitialSaveFilename = "test.html"
70    strDirectory = "C:\"
80    strDirectoryForDialog = ""
90    Debug.Print FileSaveDialogHTML(strInitialSaveFilename, strDirectory, strDirectoryForDialog)

100   strInitialSaveFilename = "test.xlsx"
110   strDirectory = ""
120   strDirectoryForDialog = ""
130   Debug.Print FileSaveDialogExcel(strInitialSaveFilename, strDirectory, strDirectoryForDialog)

140   strInitialSaveFilename = "test.docx"
150   strDirectory = ""
160   strDirectoryForDialog = ""
170   Debug.Print FileSaveDialogWord(strInitialSaveFilename, strDirectory, strDirectoryForDialog)

          'DD Error Handler Start
Exit_label:
180       Exit Function
Err_label:
190       Select Case Err.Number
          Case Else
200            Call LogError("basCommonDialogControl", "FileSaveDialog_Test")
210       End Select
220       Resume Exit_label
          ' DD Error Handler End
End Function


'Public Function BrowseForDirectory() As String
'Dim F As Office.FileDialog
'
'Dim strFolderpath As String
'
'Set F = Application.FileDialog(msoFileDialogFolderPicker)
'F.AllowMultiSelect = False
'F.Title = "Browse for a folder"
'F.InitialFileName = ""
'
'If F.Show = -1 Then
'    If F.SelectedItems.count = 0 Then
'        ' No file was selected - I don't think this is possible, but just in case
'        ' Either the user selects a file or cancels
'        strFolderpath = ""
'    Else
'        strFolderpath = F.SelectedItems(1)
'    End If
'Else
'    strFolderpath = ""
'End If
'
'BrowseForDirectory = strFolderpath
'End Function

Public Sub BrowseForDirectory_test()
Dim strFolderpath As String

strFolderpath = GetFolder("")
Debug.Print strFolderpath

strFolderpath = GetFolder("C:\")
Debug.Print strFolderpath

End Sub


''---------------------------------------------------------------------------------------
'' GetFolder
''
'' Returns "" if the user cancels
''---------------------------------------------------------------------------------------
'
'Public Function GetFolder(ByVal strInitialFolderpath As String) As String
'
'10       On Error GoTo Err_label
'
'          Dim fldr As FileDialog
'          Dim sItem As String
'
'20        sItem = ""
'
'30        Set fldr = Application.FileDialog(msoFileDialogFolderPicker)
'40        With fldr
'50            .Title = "Select a Folder"
'60            .AllowMultiSelect = False
'70            .InitialFileName = strInitialFolderpath
'80            If .Show <> -1 Then GoTo NextCode
'90            sItem = .SelectedItems(1)
'100       End With
'NextCode:
'110       GetFolder = sItem
'120       Set fldr = Nothing
'
'          'DD Error Handler Start
'Exit_label:
'130       Exit Function
'Err_label:
'140       Select Case Err.Number
'          Case Else
'150            Call LogError("basFileFolderOperations", "GetFolder")
'160       End Select
'170       Resume Exit_label
'          ' DD Error Handler End
'End Function





'Function ahtCommonFileOpenSave( _
'            Optional ByRef Flags As Variant, _
'            Optional ByVal InitialDir As Variant, _
'            Optional ByVal Filter As Variant, _
'            Optional ByVal FilterIndex As Variant, _
'            Optional ByVal DefaultExt As Variant, _
'            Optional ByVal FileName As Variant, _
'            Optional ByVal DialogTitle As Variant, _
'            Optional ByVal hwnd As Variant, _
'            Optional ByVal OpenFile As Variant) As Variant
'
'          ' This is the entry point you'll use to call the common
'          ' file open/save dialog. The parameters are listed
'          ' below, and all are optional.
'          '
'          ' In:
'          ' Flags: one or more of the ahtOFN_* constants, OR'd together.
'          ' InitialDir: the directory in which to first look
'          ' Filter: a set of file filters, set up by calling
'          ' AddFilterItem. See examples.
'          ' FilterIndex: 1-based integer indicating which filter
'          ' set to use, by default (1 if unspecified)
'          ' DefaultExt: Extension to use if the user doesn't enter one.
'          ' Only useful on file saves.
'          ' FileName: Default value for the file name text box.
'          ' DialogTitle: Title for the dialog.
'          ' hWnd: parent window handle
'          ' OpenFile: Boolean(True=Open File/False=Save As)
'          ' Out:
'          ' Return Value: Either Null or the selected filename
'          Dim OFN As tagOPENFILENAME
'          Dim strFilename As String
'          Dim strFileTitle As String
'          Dim fResult As Boolean
'
'          ' Give the dialog a caption title.
'10        If IsMissing(InitialDir) Then InitialDir = CurDir
'20        If IsMissing(Filter) Then Filter = ""
'30        If IsMissing(FilterIndex) Then FilterIndex = 1
'40        If IsMissing(Flags) Then Flags = 0&
'50        If IsMissing(DefaultExt) Then DefaultExt = ""
'60        If IsMissing(FileName) Then FileName = ""
'70        If IsMissing(DialogTitle) Then DialogTitle = ""
'80        If IsMissing(hwnd) Then hwnd = Application.hWndAccessApp
'90        If IsMissing(OpenFile) Then OpenFile = True
'          ' Allocate string space for the returned strings.
'100       strFilename = Left(FileName & String(256, 0), 256)
'110       strFileTitle = String(256, 0)
'          ' Set up the data structure before you call the function
'120       With OFN
'130           .lStructSize = Len(OFN)
'140           .hwndOwner = hwnd
'150           .strFilter = Filter
'160           .nFilterIndex = FilterIndex
'170           .strFile = strFilename
'180           .nMaxFile = Len(strFilename)
'190           .strFileTitle = strFileTitle
'200           .nMaxFileTitle = Len(strFileTitle)
'210           .strTitle = DialogTitle
'220           .Flags = Flags
'230           .strDefExt = DefaultExt
'240           .strInitialDir = InitialDir
'              ' Didn't think most people would want to deal with
'              ' these options.
'250           .hInstance = 0
'              '.strCustomFilter = ""
'              '.nMaxCustFilter = 0
'260           .lpfnHook = 0
'              'New for NT 4.0
'270           .strCustomFilter = String(255, 0)
'280           .nMaxCustFilter = 255
'290       End With
'          ' This will pass the desired data structure to the
'          ' Windows API, which will in turn it uses to display
'          ' the Open/Save As Dialog.
'300       If OpenFile Then
'310           fResult = aht_apiGetOpenFileName(OFN)
'320       Else
'330           fResult = aht_apiGetSaveFileName(OFN)
'340       End If
'
'          ' The function call filled in the strFileTitle member
'          ' of the structure. You'll have to write special code
'          ' to retrieve that if you're interested.
'350       If fResult Then
'              ' You might care to check the Flags member of the
'              ' structure to get information about the chosen file.
'              ' In this example, if you bothered to pass in a
'              ' value for Flags, we'll fill it in with the outgoing
'              ' Flags value.
'360           If Not IsMissing(Flags) Then Flags = OFN.Flags
'370           If Flags And ahtOFN_ALLOWMULTISELECT Then
'                  ' Return the full array.
'                  Dim items As Variant
'                  Dim value As String
'380               value = OFN.strFile
'                  ' Get rid of empty items:
'                  Dim i As Integer
'390               For i = Len(value) To 1 Step -1
'400                 If Mid$(value, i, 1) <> chr$(0) Then
'410                   Exit For
'420                 End If
'430               Next i
'440               value = Mid(value, 1, i)
'
'                  ' Break the list up at null characters:
'450               items = Split(value, chr(0))
'
'                  ' Loop through the items in the "array",
'                  ' and build full file names:
'                  Dim numItems As Integer
'                  Dim result() As String
'
'460               numItems = UBound(items) + 1
'470               If numItems > 1 Then
'480                   ReDim result(0 To numItems - 2)
'490                   For i = 1 To numItems - 1
'500                       result(i - 1) = FixPath(items(0)) & items(i)
'510                   Next i
'520                   ahtCommonFileOpenSave = result
'530               Else
'                      ' If you only select a single item,
'                      ' Windows just places it in item 0.
'540                   ahtCommonFileOpenSave = items(0)
'550               End If
'560           Else
'570               ahtCommonFileOpenSave = TrimNull(OFN.strFile)
'580           End If
'590       Else
'600           ahtCommonFileOpenSave = vbNullString
'610       End If
'End Function

'Function ahtAddFilterItem(strFilter As String, _
'    strDescription As String, Optional varItem As Variant) As String
'
'          ' Tack a new chunk onto the file filter.
'          ' That is, take the old value, stick onto it the description,
'          ' (like "Databases"), a null character, the skeleton
'          ' (like "*.mdb;*.mda") and a final null character.
'
'10        If IsMissing(varItem) Then varItem = "*.*"
'20        ahtAddFilterItem = strFilter & _
'                      strDescription & vbNullChar & _
'                      varItem & vbNullChar
'End Function
'
'Private Function TrimNull(ByVal strItem As String) As String
'          Dim intPos As Integer
'
'10        intPos = InStr(strItem, vbNullChar)
'20        If intPos > 0 Then
'30            TrimNull = Left(strItem, intPos - 1)
'40        Else
'50            TrimNull = strItem
'60        End If
'End Function

'Private Function FixPath(ByVal path As String) As String
'10        If Right$(path, 1) <> "\" Then
'20            FixPath = path & "\"
'30        Else
'40            FixPath = path
'50        End If
'End Function



''---------------------------------------------------------------------------------------
'' FileSaveDialogExcel
''
'' Prompts the user for a Filepath to an Excel file
'' If the file exists, the user must confirm if they wish to delete it.
''---------------------------------------------------------------------------------------
'
'Public Sub FileSaveDialogExcel( _
'    ByVal strInitialSaveFilename As String, _
'    ByVal strInitialSaveFolderpath As String, _
'    ByRef strSaveFilepath As String)
'
'      ' If the initial FolderPath is "", then use the Documents folder
'
'10    On Error GoTo Err_label
'
'20    If strInitialSaveFolderpath = "" Then
'30        strInitialSaveFolderpath = Rep_Documents()
'40    End If
'
'      Dim strFilter As String
'50    strFilter = ahtAddFilterItem(strFilter, "Excel Files (*.xlsx)", "*.xlsx")
'60    strSaveFilepath = ahtCommonFileOpenSave( _
'          InitialDir:=strInitialSaveFolderpath, _
'          OpenFile:=False, _
'          Filter:=strFilter, _
'          FileName:=strInitialSaveFilename, _
'          Flags:=ahtOFN_OVERWRITEPROMPT Or ahtOFN_READONLY)
'
'70    If FileExists(strSaveFilepath) Then
'80        On Error Resume Next
'90        SetAttr strSaveFilepath, vbNormal
'100       Kill strSaveFilepath
'110       On Error GoTo Err_label
'120   End If
'
'      'DD Error Handler Start
'Exit_label:
'130        Exit Sub
'Err_label:
'140        Select Case Err.Number
'           Case Else
'150             Call LogError("basCommonDialogControl", "FileSaveDialogExcel")
'160        End Select
'170        Resume Exit_label
'      'DD Error Handler End
'
'End Sub
'
'
''---------------------------------------------------------------------------------------
'' FileSaveDialogWord
''
'' Prompts the user for a Filepath to a Word file
'' If the file exists, the user must confirm if they wish to delete it.
''---------------------------------------------------------------------------------------
'
'Public Sub FileSaveDialogWord( _
'    ByVal strInitialSaveFilename As String, _
'    ByVal strInitialSaveFolderpath As String, _
'    ByRef strSaveFilepath As String)
'
'      ' If the initial FolderPath is "", then use the Documents folder
'
'10    On Error GoTo Err_label
'
'20    If strInitialSaveFolderpath = "" Then
'30        strInitialSaveFolderpath = Rep_Documents()
'40    End If
'
'      Dim strFilter As String
'50    strFilter = ahtAddFilterItem(strFilter, "Word Files (*.docx)", "*.docx")
'60    strSaveFilepath = ahtCommonFileOpenSave( _
'          InitialDir:=strInitialSaveFolderpath, _
'          OpenFile:=False, _
'          Filter:=strFilter, _
'          FileName:=strInitialSaveFilename, _
'          Flags:=ahtOFN_OVERWRITEPROMPT Or ahtOFN_READONLY)
'
'70    If FileExists(strSaveFilepath) Then
'80        On Error Resume Next
'90        SetAttr strSaveFilepath, vbNormal
'100       Kill strSaveFilepath
'110       On Error GoTo Err_label
'120   End If
'
'      'DD Error Handler Start
'Exit_label:
'130        Exit Sub
'Err_label:
'140        Select Case Err.Number
'           Case Else
'150             Call LogError("basCommonDialogControl", "FileSaveDialogWord")
'160        End Select
'170        Resume Exit_label
'      'DD Error Handler End
'
'End Sub
'
'
'
'
'
''---------------------------------------------------------------------------------------
'' FileSaveDialoghtml
''
'' Prompts the user for a Filepath to a Html file
'' If the file exists, the user must confirm if they wish to delete it.
'' If the initial FolderPath is "", then use on David's PC use the database folder; on all other PCs use the Documents folder
''---------------------------------------------------------------------------------------
'
'Public Sub FileSaveDialogHtml( _
'    ByVal strInitialSaveFilename As String, _
'    ByVal strInitialSaveFolderpath As String, _
'    ByRef strSaveFilepath As String)
'
'On Error GoTo Err_label
'
'If strInitialSaveFolderpath = "" Then
'    If isDavidPC() Then
'        strInitialSaveFolderpath = CurrentProject.path
'    Else
'        strInitialSaveFolderpath = Rep_Documents()
'    End If
'End If
'
'Dim strFilter As String
'strFilter = ahtAddFilterItem(strFilter, "Html Files (*.html)", "*.html")
'strSaveFilepath = ahtCommonFileOpenSave( _
'    InitialDir:=strInitialSaveFolderpath, _
'    OpenFile:=False, _
'    Filter:=strFilter, _
'    FileName:=strInitialSaveFilename, _
'    Flags:=ahtOFN_OVERWRITEPROMPT Or ahtOFN_READONLY)
'
'If FileExists(strSaveFilepath) Then
'    On Error Resume Next
'    SetAttr strSaveFilepath, vbNormal
'    Kill strSaveFilepath
'    On Error GoTo Err_label
'End If
'
''DD Error Handler Start
'Exit_label:
'     Exit Sub
'Err_label:
'     Select Case Err.Number
'     Case Else
'          Call LogError("basCommonDialogControl", "FileSaveDialogHtml")
'     End Select
'     Resume Exit_label
''DD Error Handler End
'
'End Sub
'
''---------------------------------------------------------------------------------------
'' FileSaveDialogTxt
''
'' Prompts the user for a Filepath to a .txt file
'' If the file exists, the user must confirm if they wish to delete it.
'' If the initial FolderPath is "", then on David's PC use the database folder; on all other PCs use the Documents folder
''---------------------------------------------------------------------------------------
'
'Public Sub FileSaveDialogTxt( _
'    ByVal strInitialSaveFilename As String, _
'    ByVal strInitialSaveFolderpath As String, _
'    ByRef strSaveFilepath As String)
'
'10    On Error GoTo Err_label
'
'20    If strInitialSaveFolderpath = "" Then
'30        If isDavidPC() Then
'40            strInitialSaveFolderpath = CurrentProject.path
'50        Else
'60            strInitialSaveFolderpath = Rep_Documents()
'70        End If
'80    End If
'
'      Dim strFilter As String
'90    strFilter = ahtAddFilterItem(strFilter, "Text Files (*.txt)", "*.txt")
'100   strSaveFilepath = ahtCommonFileOpenSave( _
'          InitialDir:=strInitialSaveFolderpath, _
'          OpenFile:=False, _
'          Filter:=strFilter, _
'          FileName:=strInitialSaveFilename, _
'          Flags:=ahtOFN_OVERWRITEPROMPT Or ahtOFN_READONLY)
'
'110   If FileExists(strSaveFilepath) Then
'120       On Error Resume Next
'130       SetAttr strSaveFilepath, vbNormal
'140       Kill strSaveFilepath
'150       On Error GoTo Err_label
'160   End If
'
'      'DD Error Handler Start
'Exit_label:
'170        Exit Sub
'Err_label:
'180        Select Case Err.Number
'           Case Else
'190             Call LogError("basCommonDialogControl", "FileSaveDialogTxt")
'200        End Select
'210        Resume Exit_label
'      'DD Error Handler End
'
'End Sub

'Function FileSaveDialogTxt_Test()
'    Dim strIntitialSaveFilename As String
'    Dim strInitialSaveFolderpath As String
'    Dim strSaveFilepath As String
'
'    strIntitialSaveFilename = "test.txt"
'    strInitialSaveFolderpath = ""
'
'    Call FileSaveDialogTxt(strIntitialSaveFilename, strInitialSaveFolderpath, strSaveFilepath)
'    Debug.Print strSaveFilepath
'End Function


''***************** Code Start **************
'' This code was originally written by Ken Getz.
'' It is not to be altered or distributed, 'except as part of an application.
'' You are free to use it in any application,
'' provided the copyright notice is left unchanged.
''
'' Code originally courtesy of:
'' Microsoft Access 95 How-To
'' Ken Getz and Paul Litwin
'' Waite Group Press, 1996
'' Revised to support multiple files:
'' 28 December 2007
'
'' 2025-02-21 modified the code to work on both 32-bit and 64-bit Access
'
'#If VBA7 Then
'    Type OPENFILENAME
'      lStructSize As Long
'      hwndOwner As LongPtr
'      hInstance As LongPtr
'      lpstrFilter As String
'      lpstrCustomFilter As String
'      nMaxCustFilter As Long
'      nFilterIndex As Long
'      lpstrFile As String
'      nMaxFile As Long
'      lpstrFileTitle As String
'      nMaxFileTitle As Long
'      lpstrInitialDir As String
'      lpstrTitle As String
'      Flags As Long
'      nFileOffset As Integer
'      nFileExtension As Integer
'      lpstrDefExt As String
'      lCustData As LongPtr
'      lpfnHook As LongPtr
'      lpTemplateName As String
'    End Type
'
'    Declare PtrSafe Function aht_apiGetOpenFileName Lib "comdlg32.dll" _
'    Alias "GetOpenFileNameA" (pOpenfilename As OPENFILENAME) As Boolean
'    Declare PtrSafe Function aht_apiGetSaveFileName Lib "comdlg32.dll" _
'    Alias "GetSaveFileNameA" (pOpenfilename As OPENFILENAME) As Boolean
'#Else
'    Type tagOPENFILENAME
'        lStructSize As Long
'        hwndOwner As Long
'        hInstance As Long
'        strFilter As String
'        strCustomFilter As String
'        nMaxCustFilter As Long
'        nFilterIndex As Long
'        strFile As String
'        nMaxFile As Long
'        strFileTitle As String
'        nMaxFileTitle As Long
'        strInitialDir As String
'        strTitle As String
'        Flags As Long
'        nFileOffset As Integer
'        nFileExtension As Integer
'        strDefExt As String
'        lCustData As Long
'        lpfnHook As Long
'        lpTemplateName As String
'    End Type
'
'    Declare Function aht_apiGetOpenFileName Lib "comdlg32.dll" _
'    Alias "GetOpenFileNameA" (OFN As tagOPENFILENAME) As Boolean
'    Declare Function aht_apiGetSaveFileName Lib "comdlg32.dll" _
'    Alias "GetSaveFileNameA" (pOpenfilename As tagOPENFILENAME) As Boolean
'#End If
'
'Global Const ahtOFN_READONLY = &H1
'Global Const ahtOFN_OVERWRITEPROMPT = &H2
'Global Const ahtOFN_HIDEREADONLY = &H4
'Global Const ahtOFN_NOCHANGEDIR = &H8
'Global Const ahtOFN_SHOWHELP = &H10
'' You won't use these.
''Global Const ahtOFN_ENABLEHOOK = &H20
''Global Const ahtOFN_ENABLETEMPLATE = &H40
''Global Const ahtOFN_ENABLETEMPLATEHANDLE = &H80
'Global Const ahtOFN_NOVALIDATE = &H100
'Global Const ahtOFN_ALLOWMULTISELECT = &H200
'Global Const ahtOFN_EXTENSIONDIFFERENT = &H400
'Global Const ahtOFN_PATHMUSTEXIST = &H800
'Global Const ahtOFN_FILEMUSTEXIST = &H1000
'Global Const ahtOFN_CREATEPROMPT = &H2000
'Global Const ahtOFN_SHAREAWARE = &H4000
'Global Const ahtOFN_NOREADONLYRETURN = &H8000
'Global Const ahtOFN_NOTESTFILECREATE = &H10000
'Global Const ahtOFN_NONETWORKBUTTON = &H20000
'Global Const ahtOFN_NOLONGNAMES = &H40000
'' New for Windows 95
'Global Const ahtOFN_EXPLORER = &H80000
'Global Const ahtOFN_NODEREFERENCELINKS = &H100000
'Global Const ahtOFN_LONGNAMES = &H200000
'
'Function TestIt()
'          Dim strFilter As String
'          Dim lngFlags As Long
'10        strFilter = ahtAddFilterItem(strFilter, "Access Files (*.mda, *.mdb)", _
'                          "*.MDA;*.MDB")
'20        strFilter = ahtAddFilterItem(strFilter, "dBASE Files (*.dbf)", "*.DBF")
'30        strFilter = ahtAddFilterItem(strFilter, "Text Files (*.txt)", "*.TXT")
'40        strFilter = ahtAddFilterItem(strFilter, "All Files (*.*)", "*.*")
'
'          ' Uncomment this line to try the example
'          ' allowing multiple file names:
'          ' lngFlags = ahtOFN_ALLOWMULTISELECT Or ahtOFN_EXPLORER
'
'          Dim result As Variant
'
'50        result = ahtCommonFileOpenSave(InitialDir:="C:\", _
'              Filter:=strFilter, FilterIndex:=3, Flags:=lngFlags, _
'              DialogTitle:="Hello! Open Me!")
'
'60        If lngFlags And ahtOFN_ALLOWMULTISELECT Then
'70            If IsArray(result) Then
'                  Dim i As Integer
'80                For i = 0 To UBound(result)
'90                    MsgBox result(i)
'100               Next i
'110           Else
'120               MsgBox result
'130           End If
'140       Else
'150           MsgBox result
'160       End If
'
'          ' Since you passed in a variable for lngFlags,
'          ' the function places the output flags value in the variable.
'170       Debug.Print Hex(lngFlags)
'End Function

''---------------------------------------------------------------------------------------
'' FileOpenDialogAccess
''---------------------------------------------------------------------------------------
'
'Function FileOpenDialogAccess( _
'    Optional strDirectory As Variant, _
'    Optional strDirectoryForDialog As Variant) As String
'
'          Dim strFilter As String
'          Dim lngFlags As Long
'          Dim strFilepath As Variant
'
'          ' Specify that the chosen file must already exist,
'          ' Don't bother displaying the read-only box. It'll only confuse people.
'
'10    On Error GoTo Err_label
'
'20        lngFlags = ahtOFN_FILEMUSTEXIST Or ahtOFN_HIDEREADONLY
'
'30        If IsMissing(strDirectory) Then
'40                strDirectory = Rep_Documents()
'50        Else
'60            If Nz(strDirectory) = "" Then
'70                strDirectory = Rep_Documents()
'80            End If
'90        End If
'
'100       If IsMissing(strDirectoryForDialog) Then
'110           strDirectoryForDialog = "File Open"
'120       End If
'
'          ' Define the filter string and allocate space in the "c"
'          ' string Duplicate this line with changes as necessary for
'          ' more file templates.
'
'130       strFilter = ahtAddFilterItem(strFilter, _
'                      "Access (*.accdb)", "*.accdb")
'
'          ' Now actually call to get the file name.
'
'140       strFilepath = ahtCommonFileOpenSave( _
'                          OpenFile:=True, _
'                          InitialDir:=strDirectory, _
'                          Filter:=strFilter, _
'                          Flags:=lngFlags, _
'                          DialogTitle:=strDirectoryForDialog)
'
'150       FileOpenDialogAccess = TrimNull(strFilepath)
'
'      'DD Error Handler Start
'Exit_label:
'160        Exit Function
'Err_label:
'170        Select Case Err.Number
'           Case Else
'180             Call LogError("basCommonDialogControl", "FileOpenDialogAccess")
'190        End Select
'200        Resume Exit_label
'      'DD Error Handler End
'End Function
