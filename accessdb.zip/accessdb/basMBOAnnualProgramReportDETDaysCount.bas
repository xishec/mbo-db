'---------------------------------------------------------------------------------------
' Module: basMBOAnnualProgramReportDETDaysCount
' Author: David Davey
'---------------------------------------------------------------------------------------

Option Compare Database
Option Explicit

'---------------------------------------------------------------------------------------
' MBOAnnualProgramReportDETDaysCount
'---------------------------------------------------------------------------------------

Public Sub MBOAnnualProgramReportDETDaysCount( _
    ByVal intYear As Integer, _
    ByVal strLocation As String, _
    ByVal strSeason As String, _
    ByRef oExcel As Excel.Application, _
    ByRef oBook As Excel.Workbook)
          
          Dim row As Long
          Dim col As Long
          Dim Y As Integer

          Dim intYearFirst As Integer

10       On Error GoTo Err_label

20    intYearFirst = 2005

      Dim rowColumnHeaders As Long
      Dim rowDataFirst As Long
      Dim rowDataLast As Long

30    rowColumnHeaders = 2

      Dim colSpecies As Long
      Dim colSpeciesEnglish As Long
      Dim colAOS As Long
      Dim colYearFirst As Long
      Dim colYearLast As Long

40    colSpecies = 1
50    colSpeciesEnglish = 2
60    colAOS = 3
70    colYearFirst = 4
80    colYearLast = colYearFirst + intYear - intYearFirst

      ' Excel
       
      Dim oSheet As Excel.Worksheet
90    Set oSheet = InsertSheet(oBook, strSeason)
100   oSheet.Name = strSeason & "DETDays Count"
110   With oSheet

      ' Column Headers

120   row = rowColumnHeaders
130   .Cells(row, 2) = "Species"
140   For Y = intYearFirst To intYear
150       .Cells(row, colYearFirst + Y - intYearFirst) = Y
160   Next

170   row = row + 1
180   rowDataFirst = row
          
      ' qryMBOProgramReport_DETDaysCount_A
      ' -------------------------------------
      ' tblDETSpecies x tblPrograms x tblSpecies
      ' Location = [argLocation]
      ' MonitoringProgramSeason = [argSeason]
      ' YearEx
      ' DateEx
      ' Species
      ' DETDaysCount: IIf([DET]>0,1,0)
      ' SpeciesEnglish: SpeciesDescriptionMBO
      ' AOUOrder
      ' Report DateEx, YearEx, Species,SpeciesEnglish,AOUOrder, DETDaysCount
          
      ' qryMBOProgramReport_DETDaysCount_B
      ' -------------------------------------
      ' qryMBOProgramReport_DETDaysCount_A
      '
      ' GROUP BY YearEx
      ' GROUP BY Species
      ' SUM DETDaysCount: IIf([DET]>0,1,0)
      ' GROUP BY SpeciesEnglish: SpeciesDescriptionMBO
      ' GROUP BY AOUOrder
      ' Report YearEx, Species,SpeciesEnglish,AOUOrder, DETDaysCount
          
190   SysCmd acSysCmdSetStatus, strSeason & " DETDays Count"
        
      ' L1 Control Break Processing
      ' ---------------------------
      'L1  = -99
      'get   ( L1 =... ) --  rst = CurrentDb.OpenRecordset(...)
      'if ! eof
      '        ' process 1st record
      '        HR , H1, D
      '        get ( L1 =... )  -- rst.MoveNext
      '        Do While Not rst.EOF
      '              ' process 2nd, ... records
      '                    if L1 <> L1'
      '                           F1 , H1
      '                D
      '                get ( L1 =... L2 =... )  -- rst.MoveNext
      '            Loop
      '            F1 , FR
        
      Dim strSpecies As String
      Dim strSpecies_previous As String
      Dim strSpeciesEnglish As String
      Dim intAOS As Integer
      Dim intYearEx As Integer
      Dim intDETDaysCount As Integer
       
      Dim qdf As QueryDef
200   Set qdf = CurrentDb.QueryDefs("qryMBOProgramReport_DETDaysCount_B")
210   qdf.Parameters("argSeason").value = strSeason
220   qdf.Parameters("argLocation").value = strLocation

      Dim rst As DAO.Recordset
230   Set rst = qdf.OpenRecordset

240   If Not rst.EOF Then

          ' Process 1st record
          
250       strSpecies = Nz(rst("Species"))
260       strSpeciesEnglish = Nz(rst("SpeciesEnglish"))
270       intAOS = Nz(rst("AOUOrder"))
280       intYearEx = Nz(rst("YearEx"))
290       intDETDaysCount = Nz(rst("SumOfDETDaysCount"))
          
          ' HR
          ' H1
          
300       .Cells(row, colSpecies) = strSpecies
310       .Cells(row, colSpeciesEnglish) = strSpeciesEnglish
320       .Cells(row, colAOS) = intAOS
          
          ' D
        
330       .Cells(row, colYearFirst + intYearEx - intYearFirst) = intDETDaysCount
              
340       rst.MoveNext
350       Do While Not rst.EOF
              
              ' Process 2nd, ... records
              
360           strSpecies_previous = strSpecies
              
370           strSpecies = Nz(rst("Species"))
380           strSpeciesEnglish = Nz(rst("SpeciesEnglish"))
390           intAOS = Nz(rst("AOUOrder"))
400           intYearEx = Nz(rst("YearEx"))
410           intDETDaysCount = Nz(rst("SumOfDETDaysCount"))
              
420           If (strSpecies <> strSpecies_previous) Then
                  
                  ' F1
                  ' H1
                  
430               row = row + 1
440               .Cells(row, colSpecies) = strSpecies
450               .Cells(row, colSpeciesEnglish) = strSpeciesEnglish
460               .Cells(row, colAOS) = intAOS
                 

470           End If
              
              ' D
              
480           .Cells(row, colYearFirst + intYearEx - intYearFirst) = intDETDaysCount

490           rst.MoveNext
500       Loop

          ' F1
          ' FR
          
510   End If

520   rst.Close
530   Set rst = Nothing


540   rowDataLast = row

      ' Sort by current year

          Dim rangeData As Excel.range
          Dim rangeKey1 As Excel.range
          Dim rangeKey2 As Excel.range
          
550       Set rangeData = .range(.Cells(rowColumnHeaders, colSpecies), .Cells(rowDataLast, colYearLast))
560       Set rangeKey1 = .range(.Cells(rowColumnHeaders, colYearLast), .Cells(rowDataLast, colYearLast))
570       Set rangeKey2 = .range(.Cells(rowColumnHeaders, colAOS), .Cells(rowDataLast, colAOS))
580       rangeData.Sort key1:=rangeKey1, Order1:=xlAscending, key2:=rangeKey2, Order2:=xlAscending, Header:=xlYes

590   For row = rowDataFirst To rowDataLast
600       Select Case .Cells(row, colSpecies)
          Case "TRFL", "ALFL", "WIFL"
610         .range(.Cells(row, colSpecies), .Cells(row, colYearLast)).Interior.Color = vbYellow
620       Case "WPWA", "YPWA", "PAWA"
630         .range(.Cells(row, colSpecies), .Cells(row, colYearLast)).Interior.Color = RGB(194, 227, 236)
640       Case "SNGO", "GSGO", "LSGO"
650         .range(.Cells(row, colSpecies), .Cells(row, colYearLast)).Interior.Color = vbGreen
660       End Select
670   Next

      Dim intCount As Integer

680   For col = colYearFirst To colYearLast
690       intCount = 0
700       For row = rowDataFirst To rowDataLast
710           If .Cells(row, col) = 1 Then
720               intCount = intCount + 1
730           End If
740       Next
750       .Cells(rowDataLast + 1, col) = intCount
760   Next
770   .range(.Cells(rowDataLast + 1, 1), .Cells(rowDataLast + 1, colYearLast)).Font.Bold = True

780   .Cells(rowDataLast + 1, 1) = "Count pseudo-species DET > 0"

790   .range(.columns(1), .columns(colYearLast)).AutoFit
800   .range(.columns(colAOS), .columns(colAOS)).Hidden = True

810   .range("D3").Select
820   oExcel.ActiveWindow.FreezePanes = True

830   .Cells(1, 1) = strSeason & " - " & "Number of days for which there were any observations of a pseudo-species (DET > 0) - Special cases (TRFL, PAWA, SNGO) are highlighted"

840   End With

          'DD Error Handler Start
Exit_label:
850       Exit Sub
Err_label:
860       Select Case Err.Number
          Case Else
870      Call LogError("basMBOAnnualProgramReportDETDaysCount", "MBOAnnualProgramReportDETDaysCount")
880       End Select
890       Resume Exit_label
          ' DD Error Handler End

End Sub
