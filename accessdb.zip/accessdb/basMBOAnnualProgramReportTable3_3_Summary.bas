'---------------------------------------------------------------------------------------
' Module    : basMBOAnnualProgramReportTable3_3_Summary
' Author    : David Davey
'---------------------------------------------------------------------------------------

Option Compare Database
Option Explicit

' Seasons

Const conNonSeason As Integer = -1
Const conWinter  As Integer = 0
Const conSpring  As Integer = 1
Const conSummer  As Integer = 2
Const conFall    As Integer = 3
Const conOwling  As Integer = 4
Const conRTHU    As Integer = 5
Const conNestbox As Integer = 6
Const conSummerNestbox As Integer = 7

Const conDETSeasonFirst As Integer = -1
Const conDETSeasonLast  As Integer = 3

Const intSeasonFirst As Integer = -1
Const intSeasonLast  As Integer = 7

Private rowBanded As Integer
Private rowReturns As Integer
Private rowRepeats As Integer
Private rowDET As Integer
Private rowNetHours As Integer
Private rowBirdsPer100NetHours As Integer
Private rowDETDays As Integer
Private rowCaptureDays As Integer
Private rowDaysWithFullNetCoverage As Integer
Private rowDataFirst As Integer
Private rowDataLast As Integer
Private rowLast As Integer

Private colLabel As Integer
Private colDataFirst As Integer
Private colDataLast As Integer
Private colAverage As Integer
Private colSeason As Integer
Private colLast As Integer

' Season x Year x Period statistics
' ---------------------------------

' Public dblStatSeasonYearPeriod()  ' (intStatFirst To intStatLast, intSeasonFirst To intSeasonLastEx, _
                                    '  intYearFirst To intYearLastEx, 1 To intPeriodLastEx)
                                    
' The following are for Spring and Fall only
                                    
Private intCountPeriods As Integer
Private intCountPeriodsInTable(1 To 2) As Integer

'---------------------------------------------------------------------------------------
' MBOAnnualProgramReportTable_Summary
'---------------------------------------------------------------------------------------
' Summary
' Winter, Spring, Summer, Netbox, Fall, Owling

Public Sub MBOAnnualProgramReportTable_Summary( _
    ByVal intYear As Integer, _
    ByVal strLocation As String, _
    ByVal strProgram As String, _
    ByVal strSeason As String, _
    ByRef wd As Word.Application, _
    ByRef doc As Word.Document, _
    ByRef oExcel As Excel.Application, _
    ByRef oBook As Excel.Workbook, _
    ByVal strTableCaptionHeading As String)

10       On Error GoTo Err_label

20    On Error GoTo Err_label

30    SysCmd acSysCmdSetStatus, strSeason & " Summary"

      Dim intSeason As Integer
40    intSeason = toIntSeasonFromStrSeason(strSeason)

50    Select Case strSeason
      Case "Spring", "Fall"

60        intCountPeriods = intPeriodLast_SeasonYear(intSeason, intYear)
70        intCountPeriodsInTable(1) = Int(intCountPeriods / 2) + 1
80        intCountPeriodsInTable(2) = intCountPeriods - intCountPeriodsInTable(1)
90        colAverage = 1 + intCountPeriodsInTable(2) + 1
100       colSeason = colAverage + 1
         
110       rowBanded = 2
120       rowReturns = 3
130       rowRepeats = 4
140       rowDET = 5
150       rowNetHours = 6
160       rowBirdsPer100NetHours = 7
170       rowDETDays = 8
180       rowCaptureDays = 9
190       rowDaysWithFullNetCoverage = 10
200       rowDataFirst = 2
210       rowDataLast = 10
220       rowLast = 10
          
230       colLabel = 1

240   Case "Winter"
250       rowBanded = 2
260       rowReturns = 3
270       rowRepeats = 4
280       rowDET = 5
290       rowNetHours = 6
300       rowBirdsPer100NetHours = 7
310       rowDETDays = 8
320       rowCaptureDays = 9
330       rowDataFirst = 2
340       rowDataLast = 9
350       rowLast = 9
          
360       colLabel = 1
370       colDataFirst = 2
380       colDataLast = 6
      '    colAverage = 7
390       colSeason = 7
400       colLast = 7
410   Case "Summer"
420       rowBanded = 2
430       rowReturns = 3
440       rowRepeats = 4
450       rowDET = 5
460       rowNetHours = 6
470       rowBirdsPer100NetHours = 7
480       rowDETDays = 8
490       rowCaptureDays = 9
500       rowDataFirst = 2
510       rowDataLast = 9
520       rowLast = 9
          
530       colLabel = 1
540       colDataFirst = 2
550       colDataLast = 3
      '    colAverage = 4
560       colSeason = 4
570       colLast = 4

580   Case "Owling"
590   Case "Nestbox"
600       rowBanded = 2
610       rowReturns = 3
620       rowRepeats = 4
630       rowCaptureDays = 5
640       rowDataFirst = 2
650       rowDataLast = 5
660       rowLast = 5
          
670       colLabel = 1
680       colDataFirst = 2
690       colDataLast = 3
      '    colAverage = 4
700       colSeason = 4
710       colLast = 4


720   End Select

      '20    fValid = True

      'Dim intSeason As Integer
      Dim intPeriodsCount As Integer
      Dim datStartDatePeriodFirst As Date
      Dim datLastCaptureRecord As Date


      Dim range As Word.range
      Dim strWinterPeriod As String
      Dim strTableCaptionBody As String
      Dim strTableCaptionTC As String
      Dim table As Word.table
      Dim intPeriod As Integer
      Dim col As Integer
      Dim dblNetHours As Double
      Dim dblNetHoursSubtotal As Double
      Dim dblNetHoursTotal As Double
      Dim intTable As Integer

730   Select Case strSeason
      Case "Spring"

740       Set range = doc.Characters.Last
750       range.InsertParagraphAfter

         ' Append the caption for spring summary

760       strTableCaptionBody = "Summary results of the " & intYear & " SMMP, by week"
770       Call WordGenerateCaption(wd, doc, "Table", strTableCaptionHeading, strTableCaptionBody)
          
780       Set range = MoveInsertionPointToEndOfDocument(wd, doc)
790       Call WordGenerateTableSummary_SpringFall(wd, doc, range, strSeason)
          
800   Case "Fall"

810       Set range = doc.Characters.Last
820       range.InsertParagraphAfter

         ' Append the caption for fall summary

830       strTableCaptionBody = "Summary results of the " & intYear & " FMMP, by week"
840       Call WordGenerateCaption(wd, doc, "Table", strTableCaptionHeading, strTableCaptionBody)
          
850       Set range = MoveInsertionPointToEndOfDocument(wd, doc)
860       Call WordGenerateTableSummary_SpringFall(wd, doc, range, strSeason)

870   Case "Winter"
          
880       strWinterPeriod = intYear - 1 & "-" & intYear
          
890       Set range = doc.Characters.Last
900       range.InsertParagraphAfter
          
          ' Append the caption for winter summary
          
910       strTableCaptionBody = "Summary results of the " & strWinterPeriod & " winter population monitoring program, by month"
920       Call WordGenerateCaption(wd, doc, "Table", strTableCaptionHeading, strTableCaptionBody)
          
          ' Append Table 3-3
          
930       Set range = MoveInsertionPointToEndOfDocument(wd, doc)
940       Call WordGenerateTableSummary_Winter(doc, range, intYear)
          
950   Case "Summer"

960       Set range = doc.Characters.Last
970       range.InsertParagraphAfter

         ' Append the caption for summer summary

980       strTableCaptionBody = "Summary results of the " & intYear & " MAPS Monitoring Program, by month"
990       Call WordGenerateCaption(wd, doc, "Table", strTableCaptionHeading, strTableCaptionBody)

1000      Set range = MoveInsertionPointToEndOfDocument(wd, doc)
1010       Call WordGenerateTableSummary_Summer(doc, range)

1020  Case "Nestbox"

1030      Set range = doc.Characters.Last
1040      range.InsertParagraphAfter

         ' Append the caption for Nestbox Summary

1050      strTableCaptionBody = "Summary results of the " & intYear & " Nestlings Monitoring Program, by month"
1060      Call WordGenerateCaption(wd, doc, "Table", strTableCaptionHeading, strTableCaptionBody)

1070      Set range = MoveInsertionPointToEndOfDocument(wd, doc)
1080       Call WordGenerateTableSummary_Nestbox(doc, range)
          
1090  Case "Owling"

          Dim strTableType As String ' "6 periods", "8 periods"

         ' Append the caption for owling summary

1100      strTableCaptionBody = "Summary results of the " & intYear & " Northern Saw-whet Owl Monitoring Program, by week."
1110      strTableCaptionTC = "Summary results of the " & intYear & " Northern Saw-whet Owl Monitoring Program, by week"
          
1120      Call InsertTableCaptionXX(wd, doc, "Table", _
        strTableCaptionHeading, _
        strTableCaptionBody, _
        strTableCaptionTC)
        
1130    If intPeriodLast_SeasonYear(conOwling, intYear) <= 6 Then
        
          ' Generate a table with 6 periods
          ' Col 1 = Row labels
          ' Cols 2 to 7 =  periods1 to 6
          ' Col 7 = Average
          ' Col 8 = Total over periods 1 to 6
          
1140      strTableType = "6 periods"
          
1150     ElseIf intPeriodLast_SeasonYear(conOwling, intYear) <= 8 Then
        
          ' At this point we generate a table with 6 standard periods and 2 extra periods
          ' Col 1 = Row labels
          ' Cols 2 to 7 = standard periods, namely 1 to 6
          ' Col 8 = Subtotal over periods 1 to 6
          ' Cols 9 to 10 = extra periods, namely 7 and 8
          ' Col 9 = Grand totals over periods 1 to 8
          
1160      strTableType = "8 periods"
        
1170     Else
         
           ' Abort if there are more than 8 periods
         
1180          Set range = doc.Characters.Last '   MoveInsertionPointToEndOfDocument(wd, doc)
1190          range.InsertAfter "Table 7.2 not generated since there are more than 8 owling periods"
1200          range.InsertParagraphAfter
1210          GoTo Exit_label
1220      End If

1230      Call WordGenerateTableSummary_Owling(wd, doc, strTableType)

1240  End Select

1250  Select Case strSeason
      Case "Winter", "Summer", "Nestbox", "Spring", "Fall"

      '    Set range = MoveInsertionPointToEndOfDocument(wd, doc)
          
          Dim dblStat As Double

1260      For intPeriod = 1 To intPeriodLast_SeasonYear(intSeason, intYear)
          
1270          Select Case strSeason
              Case "Winter", "Summer", "Nestbox"
1280              intTable = 1
1290              col = 1 + intPeriod
1300          Case "Spring", "Fall"
1310              If intPeriod <= intCountPeriodsInTable(1) Then
1320                  intTable = 1
1330                  col = 1 + intPeriod
1340              Else
1350                  intTable = 2
1360                  col = 1 + (intPeriod - intCountPeriodsInTable(1))
1370              End If
1380          End Select
              
1390          Set table = range.Tables(intTable)
1400          With table
              
              ' Banded
              
1410          If dblStatSeasonYearPeriod(conStatBNDBirds, intSeason, intYear, intPeriod) > 0 Then
1420              .Cell(rowBanded, col).range.Text = _
                      dblStatSeasonYearPeriod(conStatBNDBirds, intSeason, intYear, intPeriod) & _
                      " (" & dblStatSeasonYearPeriod(conStatBNDSpecies, intSeason, intYear, intPeriod) & ")"
1430          Else
1440              If dblStatSeasonYearPeriod(conStatCaptureDays, intSeason, intYear, intPeriod) > 0 Then
1450                  .Cell(rowBanded, col).range.Text = "0"
1460              Else
1470                  .Cell(rowBanded, col).range.Text = "n/a"
1480                  .Cell(rowBanded, col).range.Style = "ddSummaryNA"
1490              End If
1500          End If
        
              ' Returns
              
1510          If dblStatSeasonYearPeriod(conStatRETBirds, intSeason, intYear, intPeriod) > 0 Then
1520              .Cell(rowReturns, col).range.Text = _
                      dblStatSeasonYearPeriod(conStatRETBirds, intSeason, intYear, intPeriod) & _
                      " (" & dblStatSeasonYearPeriod(conStatRETSpecies, intSeason, intYear, intPeriod) & ")"
1530          Else
1540              If dblStatSeasonYearPeriod(conStatCaptureDays, intSeason, intYear, intPeriod) > 0 Then
1550                  .Cell(rowReturns, col).range.Text = "0"
1560              Else
1570                  .Cell(rowReturns, col).range.Text = "n/a"
1580                  .Cell(rowReturns, col).range.Style = "ddSummaryNA"
1590              End If
1600          End If
              
              ' Repeats
              
1610          If dblStatSeasonYearPeriod(conStatREPBirds, intSeason, intYear, intPeriod) > 0 Then
1620              .Cell(rowRepeats, col).range.Text = _
                      dblStatSeasonYearPeriod(conStatREPBirds, intSeason, intYear, intPeriod) & _
                      " (" & dblStatSeasonYearPeriod(conStatREPSpecies, intSeason, intYear, intPeriod) & ")"
1630          Else
1640              If dblStatSeasonYearPeriod(conStatCaptureDays, intSeason, intYear, intPeriod) > 0 Then
1650                  .Cell(rowRepeats, col).range.Text = "0"
1660              Else
1670                  .Cell(rowRepeats, col).range.Text = "n/a"
1680                  .Cell(rowRepeats, col).range.Style = "ddSummaryNA"
1690              End If
1700          End If
              
              ' DET
              
1710          If strSeason <> "Nestbox" Then
1720              If dblStatSeasonYearPeriod(conStatDETSpecies, intSeason, intYear, intPeriod) > 0 Then
1730                  .Cell(rowDET, col).range.Text = dblStatSeasonYearPeriod(conStatDETSpecies, intSeason, intYear, intPeriod)
1740              Else
1750                  If dblStatSeasonYearPeriod(conStatDETDays, intSeason, intYear, intPeriod) > 0 Then
1760                      .Cell(rowDET, col).range.Text = "0"
1770                  Else
1780                      .Cell(rowDET, col).range.Text = "n/a"
1790                      .Cell(rowDET, col).range.Style = "ddSummaryNA"
1800                  End If
1810              End If
1820          End If
                      
              ' Net Hours
              
1830          If strSeason <> "Nestbox" Then
1840              dblStat = dblStatSeasonYearPeriod(conStatNetHours, intSeason, intYear, intPeriod)
1850              If dblStat > 0 Then
1860                  .Cell(rowNetHours, col).range.Text = FormatNumberEnglish(dblStat, 1)
1870              Else
1880                  If dblStatSeasonYearPeriod(conStatCaptureDays, intSeason, intYear, intPeriod) > 0 Then
1890                      .Cell(rowNetHours, col).range.Text = "0"
1900                  Else
1910                      .Cell(rowNetHours, col).range.Text = "n/a"
1920                      .Cell(rowNetHours, col).range.Style = "ddSummaryNA"
1930                  End If
1940              End If
1950          End If
                      
              ' Birds banded per 100 net hours
                       
1960          If strSeason <> "Nestbox" Then
1970              dblStat = dblStatSeasonYearPeriod(conStatBirdsPer100NetHours, intSeason, intYear, intPeriod)
1980              If dblStat > 0 Then
1990                  .Cell(rowBirdsPer100NetHours, col).range.Text = FormatNumberEnglish(dblStat, 1)
2000              Else
2010                  If dblStatSeasonYearPeriod(conStatCaptureDays, intSeason, intYear, intPeriod) > 0 Then
2020                      .Cell(rowBirdsPer100NetHours, col).range.Text = "0"
2030                  Else
2040                      .Cell(rowBirdsPer100NetHours, col).range.Text = "n/a"
2050                      .Cell(rowBirdsPer100NetHours, col).range.Style = "ddSummaryNA"
2060                  End If
2070              End If
2080          End If
                      
              ' DET Days
              
2090          If strSeason <> "Nestbox" Then
2100              .Cell(rowDETDays, col).range.Text = dblStatSeasonYearPeriod(conStatDETDays, intSeason, intYear, intPeriod)
2110          End If
                      
              ' Capture Days
              
2120          dblStat = dblStatSeasonYearPeriod(conStatCaptureDays, intSeason, intYear, intPeriod)
2130          If dblStat > 0 Then
2140                .Cell(rowCaptureDays, col).range.Text = dblStat
2150          Else
2160                .Cell(rowCaptureDays, col).range.Text = "n/a"
2170                .Cell(rowCaptureDays, col).range.Style = "ddSummaryNA"
2180          End If
              
              ' Days With Full Net Coverage
              
2190          If strSeason = "Spring" Or strSeason = "Fall" Then
2200              dblStat = dblStatSeasonYearPeriod(conStatFullNetCoverageDays, intSeason, intYear, intPeriod)
2210              If dblStat > 0 Then
2220                .Cell(rowDaysWithFullNetCoverage, col).range.Text = dblStat
2230              ElseIf dblStatSeasonYearPeriod(conStatNetDays, intSeason, intYear, intPeriod) > 0 Then
2240                .Cell(rowDaysWithFullNetCoverage, col).range.Text = "0"
2250              Else
2260                .Cell(rowDaysWithFullNetCoverage, col).range.Text = "n/a"
2270                .Cell(rowDaysWithFullNetCoverage, col).range.Style = "ddSummaryNA"
2280              End If
2290          End If
              
2300          End With
              
2310      Next intPeriod
          
2320      Select Case strSeason
          Case "Winter", "Summer", "Nestbox"
2330          intTable = 1
2340      Case "Spring", "Fall"
2350          intTable = 2
2360      End Select
2370      Set table = range.Tables(intTable)
2380      With table
          
          ' ------------------------
          ' Average over all periods
          ' ------------------------
          
2390  If strSeason = "Spring" Or strSeason = "Fall" Then
          
          Dim dblMeanBirds As Double
          Dim dblMeanSpecies As Double
              
          ' Banded
          
2400      dblMeanBirds = dblStatSeasonYearPeriod(conStatBNDBirds, intSeason, intYear, intPeriodMean)
2410      dblMeanSpecies = dblStatSeasonYearPeriod(conStatBNDSpecies, intSeason, intYear, intPeriodMean)
          
2420      If dblMeanBirds > 0 Then
2430          .Cell(rowBanded, colAverage).range.Text = _
                  FormatNumberEnglish(dblMeanBirds, 0) & _
                  " (" & FormatNumberEnglish(dblMeanSpecies, 0) & ")"
2440      Else
2450          If dblStatSeasonYearPeriod(conStatCaptureDays, intSeason, intYear, intPeriodTotal) > 0 Then
2460              .Cell(rowBanded, colAverage).range.Text = "0"
2470          Else
2480              .Cell(rowBanded, colAverage).range.Text = "n/a"
2490              .Cell(rowBanded, colAverage).range.Style = "ddSummaryNA"
2500          End If
2510      End If
          
          ' Returns
          
2520      dblMeanBirds = dblStatSeasonYearPeriod(conStatRETBirds, intSeason, intYear, intPeriodMean)
2530      dblMeanSpecies = dblStatSeasonYearPeriod(conStatRETSpecies, intSeason, intYear, intPeriodMean)
          
2540      If dblMeanBirds > 0 Then
2550          .Cell(rowReturns, colAverage).range.Text = _
                  FormatNumberEnglish(dblMeanBirds, 0) & _
                  " (" & FormatNumberEnglish(dblMeanSpecies, 0) & ")"
2560      Else
2570          If dblStatSeasonYearPeriod(conStatCaptureDays, intSeason, intYear, intPeriodTotal) > 0 Then
2580              .Cell(rowReturns, colAverage).range.Text = "0"
2590          Else
2600              .Cell(rowReturns, colAverage).range.Text = "n/a"
2610              .Cell(rowReturns, colAverage).range.Style = "ddSummaryNA"
2620          End If
2630      End If

      '    Repeats

2640      dblMeanBirds = dblStatSeasonYearPeriod(conStatREPBirds, intSeason, intYear, intPeriodMean)
2650      dblMeanSpecies = dblStatSeasonYearPeriod(conStatREPSpecies, intSeason, intYear, intPeriodMean)
          
2660      If dblMeanBirds > 0 Then
2670          .Cell(rowRepeats, colAverage).range.Text = _
                  FormatNumberEnglish(dblMeanBirds, 0) & _
                  " (" & FormatNumberEnglish(dblMeanSpecies, 0) & ")"
2680      Else
2690          If dblStatSeasonYearPeriod(conStatCaptureDays, intSeason, intYear, intPeriodTotal) > 0 Then
2700              .Cell(rowRepeats, colAverage).range.Text = "0"
2710          Else
2720              .Cell(rowRepeats, colAverage).range.Text = "n/a"
2730              .Cell(rowRepeats, colAverage).range.Style = "ddSummaryNA"
2740          End If
2750      End If

          ' DET
          
2760      If strSeason <> "Nestbox" Then
2770          dblMeanSpecies = dblStatSeasonYearPeriod(conStatDETSpecies, intSeason, intYear, intPeriodMean)
              
2780          If dblMeanSpecies > 0 Then
2790              .Cell(rowDET, colAverage).range.Text = _
                      FormatNumberEnglish(dblMeanSpecies, 0)
2800          Else
2810              If dblStatSeasonYearPeriod(conStatDETDays, intSeason, intYear, intPeriodTotal) > 0 Then
2820                  .Cell(rowDET, colAverage).range.Text = "0"
2830              Else
2840                  .Cell(rowDET, colAverage).range.Text = "n/a"
2850                  .Cell(rowDET, colAverage).range.Style = "ddSummaryNA"
2860              End If
2870          End If
2880      End If
         
       ' Net Hours
       
2890      If strSeason <> "Nestbox" Then
2900          intCountPeriods = dblStatSeasonYearPeriod(conStatCapturePeriods, intSeason, intYear, intPeriodTotal)
2910          If intCountPeriods > 0 Then
2920              dblStat = dblStatSeasonYearPeriod(conStatNetHours, intSeason, intYear, intPeriodMean)
2930              .Cell(rowNetHours, colAverage).range.Text = FormatNumberEnglish(dblStat, 1)
2940          Else
2950              .Cell(rowNetHours, colAverage).range.Text = "n/a"
2960              .Cell(rowNetHours, colAverage).range.Style = "ddSummaryNA"
2970          End If
2980     End If
         
          ' Birds banded per 100 net hours
          
2990      If strSeason <> "Nestbox" Then
3000          intCountPeriods = dblStatSeasonYearPeriod(conStatCapturePeriods, intSeason, intYear, intPeriodTotal)
3010          If intCountPeriods > 0 Then
3020              dblStat = dblStatSeasonYearPeriod(conStatBirdsPer100NetHours, intSeason, intYear, intPeriodMean)
3030              .Cell(rowBirdsPer100NetHours, colAverage).range.Text = FormatNumberEnglish(dblStat, 1)
3040          Else
3050              .Cell(rowBirdsPer100NetHours, colAverage).range.Text = "n/a"
3060              .Cell(rowBirdsPer100NetHours, colAverage).range.Style = "ddSummaryNA"
3070          End If
3080      End If

      '   DET Days

3090      If strSeason <> "Nestbox" Then
3100          intCountPeriods = dblStatSeasonYearPeriod(conStatDETPeriods, intSeason, intYear, intPeriodTotal)
3110          If intCountPeriods > 0 Then
3120              .Cell(rowDETDays, colAverage).range.Text = _
                      FormatNumberEnglish(dblStatSeasonYearPeriod(conStatDETDays, intSeason, intYear, intPeriodMean), 1)
3130          Else
3140              .Cell(rowDETDays, colAverage).range.Text = "n/a"
3150              .Cell(rowDETDays, colAverage).range.Style = "ddSummaryNA"
3160          End If
3170      End If

      '   Capture Days

3180      intCountPeriods = dblStatSeasonYearPeriod(conStatCapturePeriods, intSeason, intYear, intPeriodTotal)
3190      If intCountPeriods > 0 Then
3200          .Cell(rowCaptureDays, colAverage).range.Text = _
                  FormatNumberEnglish(dblStatSeasonYearPeriod(conStatCaptureDays, intSeason, intYear, intPeriodTotal) / intCountPeriods, 1)
3210      Else
3220          .Cell(rowCaptureDays, colAverage).range.Text = "n/a"
3230          .Cell(rowCaptureDays, colAverage).range.Style = "ddSummaryNA"
3240      End If
          
          ' Days with full net coverage
          
3250      If strSeason = "Spring" Or strSeason = "Fall" Then
3260           intCountPeriods = dblStatSeasonYearPeriod(conStatCapturePeriods, intSeason, intYear, intPeriodTotal)
3270          If intCountPeriods > 0 Then
3280              .Cell(rowDaysWithFullNetCoverage, colAverage).range.Text = _
                      FormatNumberEnglish(dblStatSeasonYearPeriod(conStatFullNetCoverageDays, intSeason, intYear, intPeriodTotal) / intCountPeriods, 1)
3290          Else
3300              .Cell(rowDaysWithFullNetCoverage, colAverage).range.Text = "n/a"
3310              .Cell(rowDaysWithFullNetCoverage, colAverage).range.Style = "ddSummaryNA"
3320          End If
3330      End If

3340  End If
                   
          ' ----------------------
          ' Total over all periods
          ' ----------------------
              
          ' Banded
          
3350      If dblStatSeasonYearPeriod(conStatBNDBirds, intSeason, intYear, intPeriodSeason) > 0 Then
3360          .Cell(rowBanded, colSeason).range.Text = _
                  dblStatSeasonYearPeriod(conStatBNDBirds, intSeason, intYear, intPeriodSeason) & _
                  " (" & dblStatSeasonYearPeriod(conStatBNDSpecies, intSeason, intYear, intPeriodSeason) & ")"
3370      Else
3380          If dblStatSeasonYearPeriod(conStatCaptureDays, intSeason, intYear, intPeriodTotal) > 0 Then
3390              .Cell(rowBanded, colSeason).range.Text = "0"
3400          Else
3410              .Cell(rowBanded, colSeason).range.Text = "n/a"
3420              .Cell(rowBanded, colSeason).range.Style = "ddSummaryNA"
3430          End If
3440      End If
          
          ' Returns

3450      If dblStatSeasonYearPeriod(conStatRETBirds, intSeason, intYear, intPeriodSeason) > 0 Then
3460          .Cell(rowReturns, colSeason).range.Text = _
                  dblStatSeasonYearPeriod(conStatRETBirds, intSeason, intYear, intPeriodSeason) & _
                  " (" & dblStatSeasonYearPeriod(conStatRETSpecies, intSeason, intYear, intPeriodSeason) & ")"
3470            Else
3480          If dblStatSeasonYearPeriod(conStatCaptureDays, intSeason, intYear, intPeriodTotal) > 0 Then
3490              .Cell(rowReturns, colSeason).range.Text = "0"
3500          Else
3510              .Cell(rowReturns, colSeason).range.Text = "n/a"
3520              .Cell(rowReturns, colSeason).range.Style = "ddSummaryNA"
3530          End If
3540      End If
          
          ' Repeats

3550      If dblStatSeasonYearPeriod(conStatREPBirds, intSeason, intYear, intPeriodSeason) > 0 Then
3560          .Cell(rowRepeats, colSeason).range.Text = _
                  dblStatSeasonYearPeriod(conStatREPBirds, intSeason, intYear, intPeriodSeason) & _
                  " (" & dblStatSeasonYearPeriod(conStatREPSpecies, intSeason, intYear, intPeriodSeason) & ")"
3570      Else
3580          If dblStatSeasonYearPeriod(conStatCaptureDays, intSeason, intYear, intPeriodTotal) > 0 Then
3590              .Cell(rowRepeats, colSeason).range.Text = "0"
3600          Else
3610              .Cell(rowRepeats, colSeason).range.Text = "n/a"
3620              .Cell(rowRepeats, colSeason).range.Style = "ddSummaryNA"
3630          End If
3640      End If
          
          ' DET
          
3650      If strSeason <> "Nestbox" Then
3660          If dblStatSeasonYearPeriod(conStatDETSpecies, intSeason, intYear, intPeriodSeason) > 0 Then
3670              .Cell(rowDET, colSeason).range.Text = dblStatSeasonYearPeriod(conStatDETSpecies, intSeason, intYear, intPeriodSeason)
3680          Else
3690              If dblStatSeasonYearPeriod(conStatDETDays, intSeason, intYear, intPeriodTotal) > 0 Then
3700                  .Cell(rowDET, colSeason).range.Text = "0"
3710              Else
3720                  .Cell(rowDET, colSeason).range.Text = "n/a"
3730                  .Cell(rowDET, colSeason).range.Style = "ddSummaryNA"
3740              End If
3750          End If
3760      End If
       
       ' Net Hours
       
3770      If strSeason <> "Nestbox" Then
3780          dblStat = dblStatSeasonYearPeriod(conStatNetHours, intSeason, intYear, intPeriodSeason)
3790          If dblStat > 0 Then
3800              .Cell(rowNetHours, colSeason).range.Text = FormatNumberEnglish(dblStat, 1)
3810          Else
3820              If dblStatSeasonYearPeriod(conStatCaptureDays, intSeason, intYear, intPeriodTotal) > 0 Then
3830                  .Cell(rowNetHours, colSeason).range.Text = "0"
3840              Else
3850                  .Cell(rowNetHours, colSeason).range.Text = "n/a"
3860                  .Cell(rowNetHours, colSeason).range.Style = "ddSummaryNA"
3870              End If
3880          End If
3890      End If
       
          ' Birds banded per 100 net hours
          
3900      If strSeason <> "Nestbox" Then
3910          dblStat = dblStatSeasonYearPeriod(conStatBirdsPer100NetHours, intSeason, intYear, intPeriodSeason)
3920          If dblStat > 0 Then
3930              .Cell(rowBirdsPer100NetHours, colSeason).range.Text = FormatNumberEnglish(dblStat, 1)
3940          Else
3950              If dblStatSeasonYearPeriod(conStatCaptureDays, intSeason, intYear, intPeriodTotal) > 0 Then
3960                  .Cell(rowBirdsPer100NetHours, colSeason).range.Text = "0"
3970              Else
3980                  .Cell(rowBirdsPer100NetHours, colSeason).range.Text = "n/a"
3990                  .Cell(rowBirdsPer100NetHours, colSeason).range.Style = "ddSummaryNA"
4000              End If
4010          End If
4020      End If
          
          ' DET Days
          
4030      If strSeason <> "Nestbox" Then
4040          intCountPeriods = dblStatSeasonYearPeriod(conStatDETPeriods, intSeason, intYear, intPeriodTotal)
4050          If intCountPeriods > 0 Then
4060              .Cell(rowDETDays, colSeason).range.Text = dblStatSeasonYearPeriod(conStatDETDays, intSeason, intYear, intPeriodTotal)
4070          Else
4080              .Cell(rowDETDays, colSeason).range.Text = "n/a"
4090              .Cell(rowDETDays, colSeason).range.Style = "ddSummaryNA"
4100          End If
4110      End If
          
          ' Capture days

4120      intCountPeriods = dblStatSeasonYearPeriod(conStatCapturePeriods, intSeason, intYear, intPeriodTotal)
4130      If intCountPeriods > 0 Then
4140         .Cell(rowCaptureDays, colSeason).range.Text = dblStatSeasonYearPeriod(conStatCaptureDays, intSeason, intYear, intPeriodTotal)
4150      Else
4160          .Cell(rowCaptureDays, colSeason).range.Text = "n/a"
4170          .Cell(rowCaptureDays, colSeason).range.Style = "ddSummaryNA"
4180      End If

       ' Days with full net coverage
                 
4190      If strSeason = "Spring" Or strSeason = "Fall" Then
4200          intCountPeriods = dblStatSeasonYearPeriod(conStatCapturePeriods, intSeason, intYear, intPeriodTotal)
4210          If intCountPeriods > 0 Then
4220          .Cell(rowDaysWithFullNetCoverage, colSeason).range.Text = dblStatSeasonYearPeriod(conStatFullNetCoverageDays, intSeason, intYear, intPeriodTotal)
4230          Else
4240              .Cell(rowDaysWithFullNetCoverage, colSeason).range.Text = "n/a"
4250              .Cell(rowDaysWithFullNetCoverage, colSeason).range.Style = "ddSummaryNA"
4260          End If
4270      End If
             
4280      End With

4290  Case "Owling"
         
4300      Set range = MoveInsertionPointToEndOfDocument(wd, doc)
4310      Set table = range.Tables(1)
4320      With table
          
4330      Select Case strTableType
          Case "6 Periods"
          
4340          For intPeriod = 1 To 6
4350                  col = intPeriod + 1
                  
4360              If intPeriod <= intPeriodLast_SeasonYear(intSeason, intYear) Then
4370                  If dblStatSeasonYearPeriod(conStatCaptureDays, intSeason, intYear, intPeriod) > 0 Then
4380                      .Cell(2, col).range.Text = FormatNumberEnglish(dblStatSeasonYearPeriod(conStatBNDBirds, intSeason, intYear, intPeriod), 0)
4390                      .Cell(3, col).range.Text = FormatNumberEnglish(dblStatSeasonYearPeriod(conStatRETBirds, intSeason, intYear, intPeriod), 0)
4400                      .Cell(4, col).range.Text = FormatNumberEnglish(dblStatSeasonYearPeriod(conStatREPBirds, intSeason, intYear, intPeriod), 0)
4410                      .Cell(5, col).range.Text = FormatNumberEnglish(dblStatSeasonYearPeriod(conStatAlienBirds, intSeason, intYear, intPeriod), 0)
4420                      .Cell(6, col).range.Text = FormatNumberEnglish(dblStatSeasonYearPeriod(conStatNetHours, intSeason, intYear, intPeriod), 1)
4430                      .Cell(7, col).range.Text = FormatNumberEnglish(dblStatSeasonYearPeriod(conStatBirdsPer100NetHours, intSeason, intYear, intPeriod), 1)
4440                      .Cell(8, col).range.Text = dblStatSeasonYearPeriod(conStatCaptureDays, intSeason, intYear, intPeriod)

4450                  Else
4460                      .Cell(2, col).range.Text = "n/a"
4470                      .Cell(3, col).range.Text = "n/a"
4480                      .Cell(4, col).range.Text = "n/a"
4490                      .Cell(5, col).range.Text = "n/a"
4500                      .Cell(6, col).range.Text = "n/a"
4510                      .Cell(7, col).range.Text = "n/a"
4520                      .Cell(2, col).range.Style = "ddSummaryNA"
4530                      .Cell(3, col).range.Style = "ddSummaryNA"
4540                      .Cell(4, col).range.Style = "ddSummaryNA"
4550                      .Cell(5, col).range.Style = "ddSummaryNA"
4560                      .Cell(6, col).range.Style = "ddSummaryNA"
4570                      .Cell(7, col).range.Style = "ddSummaryNA"
4580                      .Cell(8, col).range.Style = "ddSummaryNA"
4590                  End If
          
4600              Else
4610                      .Cell(2, col).range.Text = "n/a"
4620                      .Cell(3, col).range.Text = "n/a"
4630                      .Cell(4, col).range.Text = "n/a"
4640                      .Cell(5, col).range.Text = "n/a"
4650                      .Cell(6, col).range.Text = "n/a"
4660                      .Cell(7, col).range.Text = "n/a"
4670                      .Cell(2, col).range.Style = "ddSummaryNA"
4680                      .Cell(3, col).range.Style = "ddSummaryNA"
4690                      .Cell(4, col).range.Style = "ddSummaryNA"
4700                      .Cell(5, col).range.Style = "ddSummaryNA"
4710                      .Cell(6, col).range.Style = "ddSummaryNA"
4720                      .Cell(7, col).range.Style = "ddSummaryNA"
4730                      .Cell(8, col).range.Style = "ddSummaryNA"
4740              End If
          
4750          Next
              
               ' Fill in the Average column (8)
          
4760          col = 8
              
4770          If dblStatSeasonYearPeriod(conStatCaptureDays, intSeason, intYear, intPeriodTotal) > 0 Then
4780              .Cell(2, col).range.Text = FormatNumberEnglish(dblStatSeasonYearPeriod(conStatBNDBirds, intSeason, intYear, intPeriodMean), 1)
4790              .Cell(3, col).range.Text = FormatNumberEnglish(dblStatSeasonYearPeriod(conStatRETBirds, intSeason, intYear, intPeriodMean), 1)
4800              .Cell(4, col).range.Text = FormatNumberEnglish(dblStatSeasonYearPeriod(conStatREPBirds, intSeason, intYear, intPeriodMean), 1)
4810              .Cell(5, col).range.Text = FormatNumberEnglish(dblStatSeasonYearPeriod(conStatAlienBirds, intSeason, intYear, intPeriodMean), 1)
4820              .Cell(6, col).range.Text = FormatNumberEnglish(dblStatSeasonYearPeriod(conStatNetHours, intSeason, intYear, intPeriodMean), 1)
4830              .Cell(7, col).range.Text = FormatNumberEnglish(dblStatSeasonYearPeriod(conStatBirdsPer100NetHours, intSeason, intYear, intPeriodMean), 1)
4840              .Cell(8, col).range.Text = FormatNumberEnglish(dblStatSeasonYearPeriod(conStatCaptureDays, intSeason, intYear, intPeriodMean), 1)
4850          Else
4860              .Cell(2, col).range.Text = "n/a"
4870              .Cell(3, col).range.Text = "n/a"
4880              .Cell(4, col).range.Text = "n/a"
4890              .Cell(5, col).range.Text = "n/a"
4900              .Cell(6, col).range.Text = "n/a"
4910              .Cell(7, col).range.Text = "n/a"
4920              .Cell(8, col).range.Text = "n/a"
4930              .Cell(2, col).range.Style = "ddSummaryNA"
4940              .Cell(3, col).range.Style = "ddSummaryNA"
4950              .Cell(4, col).range.Style = "ddSummaryNA"
4960              .Cell(5, col).range.Style = "ddSummaryNA"
4970              .Cell(6, col).range.Style = "ddSummaryNA"
4980              .Cell(7, col).range.Style = "ddSummaryNA"
4990              .Cell(8, col).range.Style = "ddSummaryNA"
5000          End If
             
              ' Fill in the TOTAL column (9)
          
5010          col = 9
              
5020          If dblStatSeasonYearPeriod(conStatCaptureDays, intSeason, intYear, intPeriodTotal) > 0 Then
5030              .Cell(2, col).range.Text = dblStatSeasonYearPeriod(conStatBNDBirds, intSeason, intYear, intPeriodSeason)
5040              .Cell(3, col).range.Text = dblStatSeasonYearPeriod(conStatRETBirds, intSeason, intYear, intPeriodSeason)
5050              .Cell(4, col).range.Text = dblStatSeasonYearPeriod(conStatREPBirds, intSeason, intYear, intPeriodSeason)
5060              .Cell(5, col).range.Text = dblStatSeasonYearPeriod(conStatAlienBirds, intSeason, intYear, intPeriodSeason)
5070              .Cell(6, col).range.Text = FormatNumberEnglish(dblStatSeasonYearPeriod(conStatNetHours, intSeason, intYear, intPeriodSeason), 1)
5080              .Cell(7, col).range.Text = FormatNumberEnglish(dblStatSeasonYearPeriod(conStatBirdsPer100NetHours, intSeason, intYear, intPeriodSeason), 1)
5090              .Cell(8, col).range.Text = dblStatSeasonYearPeriod(conStatCaptureDays, intSeason, intYear, intPeriodSeason)
5100          Else
5110              .Cell(2, col).range.Text = "n/a"
5120              .Cell(3, col).range.Text = "n/a"
5130              .Cell(4, col).range.Text = "n/a"
5140              .Cell(5, col).range.Text = "n/a"
5150              .Cell(6, col).range.Text = "n/a"
5160              .Cell(7, col).range.Text = "n/a"
5170              .Cell(8, col).range.Text = "n/a"
5180              .Cell(2, col).range.Style = "ddSummaryNA"
5190              .Cell(3, col).range.Style = "ddSummaryNA"
5200              .Cell(4, col).range.Style = "ddSummaryNA"
5210              .Cell(5, col).range.Style = "ddSummaryNA"
5220              .Cell(6, col).range.Style = "ddSummaryNA"
5230              .Cell(7, col).range.Style = "ddSummaryNA"
5240              .Cell(8, col).range.Style = "ddSummaryNA"
5250          End If
              
5260      Case "8 periods"

5270          For intPeriod = 1 To 8
5280              If intPeriod <= 6 Then
5290                  col = intPeriod + 1
5300              Else
5310                  col = intPeriod + 2
5320              End If
                  
5330              If intPeriod <= intPeriodLast_SeasonYear(intSeason, intYear) Then
5340                  If dblStatSeasonYearPeriod(conStatCaptureDays, intSeason, intYear, intPeriod) > 0 Then
5350                      .Cell(2, col).range.Text = dblStatSeasonYearPeriod(conStatBNDBirds, intSeason, intYear, intPeriod)
5360                      .Cell(3, col).range.Text = dblStatSeasonYearPeriod(conStatRETBirds, intSeason, intYear, intPeriod)
5370                      .Cell(4, col).range.Text = dblStatSeasonYearPeriod(conStatREPBirds, intSeason, intYear, intPeriod)
5380                      .Cell(5, col).range.Text = dblStatSeasonYearPeriod(conStatAlienBirds, intSeason, intYear, intPeriod)
5390                      .Cell(6, col).range.Text = FormatNumberEnglish(dblStatSeasonYearPeriod(conStatNetHours, intSeason, intYear, intPeriod), 1)
5400                      .Cell(7, col).range.Text = FormatNumberEnglish(dblStatSeasonYearPeriod(conStatBirdsPer100NetHours, intSeason, intYear, intPeriod), 1)
5410                      .Cell(8, col).range.Text = dblStatSeasonYearPeriod(conStatCaptureDays, intSeason, intYear, intPeriod)
5420                  Else
5430                      .Cell(2, col).range.Text = "n/a"
5440                      .Cell(3, col).range.Text = "n/a"
5450                      .Cell(4, col).range.Text = "n/a"
5460                      .Cell(5, col).range.Text = "n/a"
5470                      .Cell(6, col).range.Text = "n/a"
5480                      .Cell(7, col).range.Text = "n/a"
5490                      .Cell(8, col).range.Text = "n/a"
5500                      .Cell(2, col).range.Style = "ddSummaryNA"
5510                      .Cell(3, col).range.Style = "ddSummaryNA"
5520                      .Cell(4, col).range.Style = "ddSummaryNA"
5530                      .Cell(5, col).range.Style = "ddSummaryNA"
5540                      .Cell(6, col).range.Style = "ddSummaryNA"
5550                      .Cell(7, col).range.Style = "ddSummaryNA"
5560                      .Cell(8, col).range.Style = "ddSummaryNA"
5570                  End If
          
5580              Else
5590                      .Cell(2, col).range.Text = "n/a"
5600                      .Cell(3, col).range.Text = "n/a"
5610                      .Cell(4, col).range.Text = "n/a"
5620                      .Cell(5, col).range.Text = "n/a"
5630                      .Cell(6, col).range.Text = "n/a"
5640                      .Cell(7, col).range.Text = "n/a"
5650                      .Cell(8, col).range.Text = "n/a"
5660                      .Cell(2, col).range.Style = "ddSummaryNA"
5670                      .Cell(3, col).range.Style = "ddSummaryNA"
5680                      .Cell(4, col).range.Style = "ddSummaryNA"
5690                      .Cell(5, col).range.Style = "ddSummaryNA"
5700                      .Cell(6, col).range.Style = "ddSummaryNA"
5710                      .Cell(7, col).range.Style = "ddSummaryNA"
5720                      .Cell(8, col).range.Style = "ddSummaryNA"
5730              End If
          
5740          Next
              
              ' Fill in the STANDARD column (subtotal over 1 to 6)
              ' The subtotal is in period min(6,intPeriodLast_SeasonYear(intSeason, intYear))
              
              Dim intPeriodSubtotal As Integer
5750          If intPeriodLast_SeasonYear(intSeason, intYear) < 6 Then
5760              intPeriodSubtotal = intPeriodLast_SeasonYear(intSeason, intYear)
5770          Else
5780              intPeriodSubtotal = 6
5790          End If
          
5800          If dblStatSeasonYearPeriod(conStatCaptureDays, intSeason, intYear, intPeriodTotal) > 0 Then
5810              .Cell(2, 8).range.Text = dblStatSeasonYearPeriod(conStatBNDBirdsCumulative, intSeason, intYear, intPeriodSubtotal)
5820              .Cell(3, 8).range.Text = dblStatSeasonYearPeriod(conStatRETBirdsCumulative, intSeason, intYear, intPeriodSubtotal)
5830              .Cell(4, 8).range.Text = dblStatSeasonYearPeriod(conStatREPBirdsCumulative, intSeason, intYear, intPeriodSubtotal)
5840              .Cell(5, 8).range.Text = dblStatSeasonYearPeriod(conStatAlienBirdsCumulative, intSeason, intYear, intPeriodSubtotal)
5850              .Cell(6, 8).range.Text = FormatNumberEnglish(dblStatSeasonYearPeriod(conStatNetHoursCumulative, intSeason, intYear, intPeriodSubtotal), 1)
5860              .Cell(7, 8).range.Text = FormatNumberEnglish(dblStatSeasonYearPeriod(conStatBirdsPer100NetHoursCumulative, intSeason, intYear, intPeriodSubtotal), 1)
5870              .Cell(8, 8).range.Text = dblStatSeasonYearPeriod(conStatCaptureDaysCumulative, intSeason, intYear, intPeriodSubtotal)
5880          Else
5890              .Cell(2, 8).range.Text = "n/a"
5900              .Cell(3, 8).range.Text = "n/a"
5910              .Cell(4, 8).range.Text = "n/a"
5920              .Cell(5, 8).range.Text = "n/a"
5930              .Cell(6, 8).range.Text = "n/a"
5940              .Cell(7, 8).range.Text = "n/a"
5950              .Cell(8, 8).range.Text = "n/a"
5960              .Cell(2, 8).range.Style = "ddSummaryNA"
5970              .Cell(3, 8).range.Style = "ddSummaryNA"
5980              .Cell(4, 8).range.Style = "ddSummaryNA"
5990              .Cell(5, 8).range.Style = "ddSummaryNA"
6000              .Cell(6, 8).range.Style = "ddSummaryNA"
6010              .Cell(7, 8).range.Style = "ddSummaryNA"
6020              .Cell(8, 8).range.Style = "ddSummaryNA"
6030          End If
              
              ' Fill in the TOTAL column (11)
          
6040          col = 11
              
6050          If dblStatSeasonYearPeriod(conStatCaptureDays, intSeason, intYear, intPeriodTotal) > 0 Then
6060              .Cell(2, col).range.Text = dblStatSeasonYearPeriod(conStatBNDBirds, intSeason, intYear, intPeriodSeason)
6070              .Cell(3, col).range.Text = dblStatSeasonYearPeriod(conStatRETBirds, intSeason, intYear, intPeriodSeason)
6080              .Cell(4, col).range.Text = dblStatSeasonYearPeriod(conStatREPBirds, intSeason, intYear, intPeriodSeason)
6090              .Cell(5, col).range.Text = dblStatSeasonYearPeriod(conStatAlienBirds, intSeason, intYear, intPeriodSeason)
6100              .Cell(6, col).range.Text = FormatNumberEnglish(dblStatSeasonYearPeriod(conStatNetHours, intSeason, intYear, intPeriodSeason), 1)
6110              .Cell(7, col).range.Text = FormatNumberEnglish(dblStatSeasonYearPeriod(conStatBirdsPer100NetHours, intSeason, intYear, intPeriodSeason), 1)
6120              .Cell(8, col).range.Text = dblStatSeasonYearPeriod(conStatCaptureDays, intSeason, intYear, intPeriodSeason)
6130          Else
6140              .Cell(2, col).range.Text = "n/a"
6150              .Cell(3, col).range.Text = "n/a"
6160              .Cell(4, col).range.Text = "n/a"
6170              .Cell(5, col).range.Text = "n/a"
6180              .Cell(6, col).range.Text = "n/a"
6190              .Cell(7, col).range.Text = "n/a"
6200              .Cell(8, col).range.Text = "n/a"
6210              .Cell(2, col).range.Style = "ddSummaryNA"
6220              .Cell(3, col).range.Style = "ddSummaryNA"
6230              .Cell(4, col).range.Style = "ddSummaryNA"
6240              .Cell(5, col).range.Style = "ddSummaryNA"
6250              .Cell(6, col).range.Style = "ddSummaryNA"
6260              .Cell(7, col).range.Style = "ddSummaryNA"
6270              .Cell(8, col).range.Style = "ddSummaryNA"
6280          End If
              
6290      End Select
          
6300      End With
          
6310  End Select

6320  Set range = MoveInsertionPointToEndOfDocument(wd, doc)
6330  range.InsertParagraphAfter

6340  SysCmd acSysCmdClearStatus

    'DD Error Handler Start
Exit_label:
6350      Exit Sub
Err_label:
6360      Select Case Err.Number
    Case Else
6370     Call LogError("basMBOAnnualProgramReportTable3_3_Summary", "MBOAnnualProgramReportTable_Summary")
6380      End Select
6390      Resume Exit_label
    ' DD Error Handler End

End Sub


'---------------------------------------------------------------------------------------
' WordGenerateTableSummaryWinter
'---------------------------------------------------------------------------------------
' entry:  range = a collapsed range that is the insertion point for the table
' exit:   range = range that includes the table

Private Sub WordGenerateTableSummary_Winter( _
    ByRef doc As Word.Document, _
    ByRef range As Word.range, _
    ByVal intYearEx As Integer)

      Dim row As Integer
      Dim col As Integer
      Dim fLeapYear As Boolean

10    On Error GoTo Err_label

20    fLeapYear = isLeapYear(intYearEx)

30    doc.Tables.Add range:=range, NumRows:=rowLast, NumColumns:=colLast
          
40    range.Expand (wdTable)
50    With range.Tables(1)

60        .range.Style = "ddSummaryData"

70        .Rows.Alignment = wdAlignRowCenter
80        .Rows.WrapAroundText = False

90        .LeftPadding = doc.Application.InchesToPoints(0.02)
100       .RightPadding = doc.Application.InchesToPoints(0.02)
110       .TopPadding = doc.Application.InchesToPoints(0.02)
          
      ' 100       .Rows.HorizontalPosition = doc.Application.InchesToPoints(0.08)
          
120       .columns(1).Width = doc.Application.InchesToPoints(1.96)
130       .columns(2).Width = doc.Application.InchesToPoints(0.94)
140       .columns(3).Width = doc.Application.InchesToPoints((6.5 - 1.96 - 0.94) / 6)
150       .columns(4).Width = doc.Application.InchesToPoints((6.5 - 1.96 - 0.94) / 6)
160       .columns(5).Width = doc.Application.InchesToPoints((6.5 - 1.96 - 0.94) / 6)
170       .columns(6).Width = doc.Application.InchesToPoints((6.5 - 1.96 - 0.94) / 6)
      '    .Columns(colAverage).Width = doc.Application.InchesToPoints((6.5 - 1.96 - 0.94) / 6)
180       .columns(colSeason).Width = doc.Application.InchesToPoints((6.5 - 1.96 - 0.94) / 6)
190       .Cell(1, 2).range.Text = "Nov 7-30"
200       .Cell(1, 3).range.Text = "Dec 1-31"
210       .Cell(1, 4).range.Text = "Jan 1-31"
220       If fLeapYear Then
230     .Cell(1, 5).range.Text = "Feb 1-29"
240       Else
250     .Cell(1, 5).range.Text = "Feb 1-28"
260       End If
270       .Cell(1, 6).range.Text = "Mar 1-27"
      '    .Cell(1, colAverage).range.Text = "Average"
280       .Cell(1, colSeason).range.Text = "Season"
          
290       .Cell(rowBanded, 1).range.Text = "# individuals (species) banded"
300       .Cell(3, 1).range.Text = "# individuals (species) return"
310       .Cell(4, 1).range.Text = "# individuals (species) repeat"
320       .Cell(5, 1).range.Text = "# species observed"
330       .Cell(6, 1).range.Text = "# net hours"
340       .Cell(7, 1).range.Text = "# birds banded / 100 net hours"
350       .Cell(8, 1).range.Text = "# days operating"
360       .Cell(9, 1).range.Text = "# days banding"
          
          ' Format Labels Column
          
370       For row = 2 To 9
380         .Cell(row, 1).range.Style = "ddLabelsColumn"
390       Next
        
          ' Format Header Row
          
400       Call FormatWordTableRowAsHeader(.Rows(1))
          
          ' Summary columns background is light gray
          
410       For row = rowDataFirst To rowDataLast
      '        .Cell(row, colAverage).Shading.BackgroundPatternColor = RGB(217, 217, 217)
420           .Cell(row, colSeason).Shading.BackgroundPatternColor = RGB(217, 217, 217)
430       Next
          
          ' All cells are centred
          
      '    .range.ParagraphFormat.Alignment = wdAlignParagraphCenter
          
          ' Draw a line at the bottom of the table
          
440       .Rows(9).Borders(wdBorderBottom).LineStyle = wdLineStyleSingle

450   End With

      'DD Error Handler Start
Exit_label:
460        Exit Sub
Err_label:
470        Select Case Err.Number
           Case Else
480             Call LogError("basMBOAnnualProgramReportTable3_3_Summary", "WordGenerateTableSummaryWinter")
490        End Select
500        Resume Exit_label
      'DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' WordGenerateTableSummary_SpringFall
'---------------------------------------------------------------------------------------
' entry:  range = a collapsed range that is the insertion point for the table
' exit:   range = range that includes the table

Private Sub WordGenerateTableSummary_SpringFall( _
    ByRef wd As Word.Application, _
    ByRef doc As Word.Document, _
    ByRef range As Word.range, _
    ByRef strSeason As String)
          
10    On Error GoTo Err_label

      Dim row As Integer
      Dim col As Integer

      Dim dblColumnWidth As Double            ' width of data column in inches
      Dim dblColumnWidth_Average As Double
      Dim dblColumnWidth_Season As Double

20    Select Case strSeason
      Case "Spring"
30        dblColumnWidth = (6.5 - 1.96) / (intCountPeriodsInTable(2) + 2)
40        dblColumnWidth_Average = dblColumnWidth
50        dblColumnWidth_Season = dblColumnWidth
60    Case "Fall"
70        dblColumnWidth = (6.5 - 1.96 - 0.62) / (intCountPeriodsInTable(2) + 1)
80        dblColumnWidth = dblColumnWidth
90        dblColumnWidth_Season = 0.62
100   End Select

      ' Create two tables

      Dim lngStart As Long
      Dim lngEnd As Long
110   lngStart = range.End

120   doc.Tables.Add range:=range, NumRows:=rowLast, NumColumns:=intCountPeriodsInTable(1) + 1

130   Set range = MoveInsertionPointToEndOfDocument(wd, doc)

      Dim lngStartBetweenTables As Long
      Dim lngEndBetweenTables As Long
140   lngStartBetweenTables = range.End

150   range.InsertParagraphAfter
160   lngEndBetweenTables = range.End

170   doc.range(lngStartBetweenTables, lngEndBetweenTables).Style = "ddSummarySpacingBetweenTables"

180   Set range = MoveInsertionPointToEndOfDocument(wd, doc)
190   doc.Tables.Add range:=range, NumRows:=rowLast, NumColumns:=intCountPeriodsInTable(2) + 3
200   Set range = MoveInsertionPointToEndOfDocument(wd, doc)
210   range.InsertParagraphAfter

220   lngEnd = range.End
230   Set range = doc.range(lngStart, lngEnd)

      Dim intTable As Integer
240   For intTable = 1 To 2

250       With range.Tables(intTable)
          
260     .range.Style = "ddSummaryData"
          
270     .Rows.Alignment = wdAlignRowCenter
280     .Rows.WrapAroundText = False
          
290     .LeftPadding = doc.Application.InchesToPoints(0.02)
300     .RightPadding = doc.Application.InchesToPoints(0.02)
310     .TopPadding = doc.Application.InchesToPoints(0.02)
        
320     .Cell(rowBanded, 1).range.Text = "# individuals (species) banded"
330     .Cell(rowReturns, 1).range.Text = "# individuals (species) return"
340     .Cell(rowRepeats, 1).range.Text = "# individuals (species) repeat"
350     .Cell(rowDET, 1).range.Text = "# species observed"
360     .Cell(rowNetHours, 1).range.Text = "# net hours"
370     .Cell(rowBirdsPer100NetHours, 1).range.Text = "# birds banded / 100 net hours"
380     .Cell(rowDETDays, 1).range.Text = "# days operating"
390     .Cell(rowCaptureDays, 1).range.Text = "# days banding"
400     .Cell(rowDaysWithFullNetCoverage, 1).range.Text = "# days with full net coverage"
            
410     .columns(colLabel).Width = doc.Application.InchesToPoints(1.96)
        
        Dim intPeriod As Integer
        
420     For col = 2 To intCountPeriodsInTable(intTable) + 1
430         If intTable = 1 Then
440             intPeriod = col - 1
450         Else
460             intPeriod = col - 1 + intCountPeriodsInTable(1)
470         End If
480         .Cell(1, col).range.Text = Left(strSeason, 1) & intPeriod
490         .columns(col).Width = doc.Application.InchesToPoints(dblColumnWidth)
500     Next
        
        ' Format Labels Column
        
510     For row = rowDataFirst To rowDataLast
520       .Cell(row, 1).range.Style = "ddLabelsColumn"
530     Next

        ' Format Header Row
        
540     Call FormatWordTableRowAsHeader(.Rows(1))
        
        ' Draw a line at the bottom of the table
        
550     .Rows(rowLast).Borders(wdBorderBottom).LineStyle = wdLineStyleSingle
560       End With
570   Next

580   With range.Tables(2)
590       .Cell(1, colAverage).range.Text = "Average"
600       .Cell(1, colSeason).range.Text = "Season"
610       .columns(colAverage).Width = doc.Application.InchesToPoints(dblColumnWidth)
620       .columns(colSeason).Width = doc.Application.InchesToPoints(dblColumnWidth_Season)
          
          ' Summary columns background is light gray
          
630       For row = rowDataFirst To rowDataLast
640          .Cell(row, colAverage).Shading.BackgroundPatternColor = RGB(217, 217, 217)
650          .Cell(row, colSeason).Shading.BackgroundPatternColor = RGB(217, 217, 217)
660       Next
          
670   End With

      'DD Error Handler Start
Exit_label:
680        Exit Sub
Err_label:
690        Select Case Err.Number
           Case Else
700            Call LogError("basMBOAnnualProgramReportTable3_3_Summary", "WordGenerateTableSummary_SpringFall")
710        End Select
720        Resume Exit_label
      'DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' WordGenerateTableSummary_Summer
'---------------------------------------------------------------------------------------
' entry:  range = a collapsed range that is the insertion point for the table
' exit:   range = range that includes the table

Private Sub WordGenerateTableSummary_Summer( _
    ByRef doc As Word.Document, _
    ByRef range As Word.range)

      Dim row As Integer
      Dim col As Integer

10    On Error GoTo Err_label

20    doc.Tables.Add range:=range, NumRows:=rowLast, NumColumns:=colLast
          
30    range.Expand (wdTable)
40    With range.Tables(1)

50        .range.Style = "ddSummaryData"

60        .Rows.Alignment = wdAlignRowCenter
70        .Rows.WrapAroundText = False

80        .LeftPadding = doc.Application.InchesToPoints(0.02)
90        .RightPadding = doc.Application.InchesToPoints(0.02)
100       .TopPadding = doc.Application.InchesToPoints(0.02)
          
      ' 100       .Rows.HorizontalPosition = doc.Application.InchesToPoints(0.08)
          
110       .columns(1).Width = doc.Application.InchesToPoints(1.96)
120       .columns(2).Width = doc.Application.InchesToPoints((6.5 - 1.96 - 0.94) / 6)
130       .columns(3).Width = doc.Application.InchesToPoints((6.5 - 1.96 - 0.94) / 6)
      '    .Columns(colAverage).Width = doc.Application.InchesToPoints((6.5 - 1.96 - 0.94) / 6)
140       .columns(colSeason).Width = doc.Application.InchesToPoints((6.5 - 1.96 - 0.94) / 6)
150       .Cell(1, 2).range.Text = "Jun"
160       .Cell(1, 3).range.Text = "Jul"
      '    .Cell(1, colAverage).range.Text = "Average"
170       .Cell(1, colSeason).range.Text = "Season"
          
180       .Cell(rowBanded, 1).range.Text = "# individuals (species) banded"
190       .Cell(rowReturns, 1).range.Text = "# individuals (species) return"
200       .Cell(rowRepeats, 1).range.Text = "# individuals (species) repeat"
210       .Cell(rowDET, 1).range.Text = "# species observed"
220       .Cell(rowNetHours, 1).range.Text = "# net hours"
230       .Cell(rowBirdsPer100NetHours, 1).range.Text = "# birds banded / 100 net hours"
240       .Cell(rowDETDays, 1).range.Text = "# days operating"
250       .Cell(rowCaptureDays, 1).range.Text = "# days banding"
          
          ' Format Labels Column
          
260       For row = rowDataFirst To rowDataLast
270         .Cell(row, 1).range.Style = "ddLabelsColumn"
280       Next
        
          ' Format Header Row
          
290       Call FormatWordTableRowAsHeader(.Rows(1))
          
          ' Summary columns background is light gray
          
300       For row = rowDataFirst To rowDataLast
      '        .Cell(row, colAverage).Shading.BackgroundPatternColor = RGB(217, 217, 217)
310           .Cell(row, colSeason).Shading.BackgroundPatternColor = RGB(217, 217, 217)
320       Next
          
          ' All cells are centred
          
      '    .range.ParagraphFormat.Alignment = wdAlignParagraphCenter
          
          ' Draw a line at the bottom of the table
          
330       .Rows(rowLast).Borders(wdBorderBottom).LineStyle = wdLineStyleSingle

340   End With

      'DD Error Handler Start
Exit_label:
350        Exit Sub
Err_label:
360        Select Case Err.Number
           Case Else
370       Call LogError("basMBOAnnualProgramReportTable3_3_Summary", "WordGenerateTableSummary_Summer")
380        End Select
390        Resume Exit_label
      'DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' WordGenerateTableSummary_Summer
'---------------------------------------------------------------------------------------
' entry:  range = a collapsed range that is the insertion point for the table
' exit:   range = range that includes the table

Private Sub WordGenerateTableSummary_Nestbox( _
    ByRef doc As Word.Document, _
    ByRef range As Word.range)

      Dim row As Integer
      Dim col As Integer

10    On Error GoTo Err_label

30    doc.Tables.Add range:=range, NumRows:=rowLast, NumColumns:=colLast
          
40    range.Expand (wdTable)
50    With range.Tables(1)

60        .range.Style = "ddSummaryData"

70        .Rows.Alignment = wdAlignRowCenter
80        .Rows.WrapAroundText = False

90        .LeftPadding = doc.Application.InchesToPoints(0.02)
100       .RightPadding = doc.Application.InchesToPoints(0.02)
110       .TopPadding = doc.Application.InchesToPoints(0.02)
          
      ' 100       .Rows.HorizontalPosition = doc.Application.InchesToPoints(0.08)
          
120       .columns(1).Width = doc.Application.InchesToPoints(1.96)
130       .columns(2).Width = doc.Application.InchesToPoints((6.5 - 1.96 - 0.94) / 6)
140       .columns(3).Width = doc.Application.InchesToPoints((6.5 - 1.96 - 0.94) / 6)
' 140       .Columns(colAverage).Width = doc.Application.InchesToPoints((6.5 - 1.96 - 0.94) / 6)
150       .columns(colSeason).Width = doc.Application.InchesToPoints((6.5 - 1.96 - 0.94) / 6)
160       .Cell(1, 2).range.Text = "Jun"
170       .Cell(1, 3).range.Text = "Jul"
      '    .Cell(1, colAverage).range.Text = "Average"
180       .Cell(1, colSeason).range.Text = "Season"
          
190       .Cell(rowBanded, 1).range.Text = "# individuals (species) banded"
200       .Cell(rowReturns, 1).range.Text = "# individuals (species) return"
210       .Cell(rowRepeats, 1).range.Text = "# individuals (species) repeat"
220       .Cell(rowCaptureDays, 1).range.Text = "# days banding"
          
          ' Format Labels Column
          
230       For row = rowDataFirst To rowDataLast
240         .Cell(row, 1).range.Style = "ddLabelsColumn"
250       Next
        
          ' Format Header Row
          
260       Call FormatWordTableRowAsHeader(.Rows(1))
          
          ' Summary columns background is light gray
          
270       For row = rowDataFirst To rowDataLast
      '        .Cell(row, colAverage).Shading.BackgroundPatternColor = RGB(217, 217, 217)
280           .Cell(row, colSeason).Shading.BackgroundPatternColor = RGB(217, 217, 217)
290       Next
          
          ' All cells are centred
          
      '    .range.ParagraphFormat.Alignment = wdAlignParagraphCenter
          
          ' Draw a line at the bottom of the table
          
300       .Rows(rowLast).Borders(wdBorderBottom).LineStyle = wdLineStyleSingle

310   End With


'DD Error Handler Start
Exit_label:
320        Exit Sub
Err_label:
330        Select Case Err.Number
     Case Else
340       Call LogError("basMBOAnnualProgramReportTable3_3_Summary", "WordGenerateTableSummary_Nestbox")
350        End Select
360        Resume Exit_label
'DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' WordGenerateTableSummaryOwling
'---------------------------------------------------------------------------------------
' entry:  range = a collapsed range that is the insertion point for the table
' exit:   range = range that includes the table
'
' strTableType = "6 periods" or "8 periods"

Private Sub WordGenerateTableSummary_Owling( _
    ByRef wd As Word.Application, _
    ByRef doc As Word.Document, _
    ByVal strTableType As String)
          
10    On Error GoTo Err_label

      Dim range As Word.range
      Dim row As Integer
      Dim col As Integer

20    Set range = MoveInsertionPointToEndOfDocument(wd, doc)

30    Select Case strTableType
      Case "6 periods"

40        doc.Tables.Add range:=range, NumRows:=8, NumColumns:=9
              
50        range.Expand (wdTable)
60        With range.Tables(1)
          
70            .range.Style = "ddSummaryData"
          
80            .Rows.Alignment = wdAlignRowCenter
90            .Rows.WrapAroundText = False
          
100           .LeftPadding = doc.Application.InchesToPoints(0.02)
110           .RightPadding = doc.Application.InchesToPoints(0.02)
120           .TopPadding = doc.Application.InchesToPoints(0.02)
              
130           .columns(1).Width = doc.Application.InchesToPoints(1.81)
140           .columns(2).Width = doc.Application.InchesToPoints(0.43)
150           .columns(3).Width = doc.Application.InchesToPoints(0.43)
160           .columns(4).Width = doc.Application.InchesToPoints(0.43)
170           .columns(5).Width = doc.Application.InchesToPoints(0.43)
180           .columns(6).Width = doc.Application.InchesToPoints(0.43)
190           .columns(7).Width = doc.Application.InchesToPoints(0.43)
200           .columns(8).Width = doc.Application.InchesToPoints(0.72)
210           .columns(9).Width = doc.Application.InchesToPoints(0.72)

          
220           .Cell(1, 2).range.Text = "9"
230           .Cell(1, 3).range.Text = "10"
240           .Cell(1, 4).range.Text = "11"
250           .Cell(1, 5).range.Text = "12"
260           .Cell(1, 6).range.Text = "13"
270           .Cell(1, 7).range.Text = "14"
280           .Cell(1, 8).range.Text = "Average"
290           .Cell(1, 9).range.Text = "Season"

              
300           .Cell(2, 1).range.Text = "# owls banded"
310           .Cell(3, 1).range.Text = "# owls return"
320           .Cell(4, 1).range.Text = "# owls repeat"
330           .Cell(5, 1).range.Text = "# owls foreign"
340           .Cell(6, 1).range.Text = "# net hours"
350           .Cell(7, 1).range.Text = "# owls banded / 100 net hours"
360           .Cell(8, 1).range.Text = "# nights banding"
          
              ' Format Labels Column
              
370           For row = 2 To 8
380             .Cell(row, 1).range.Style = "ddLabelsColumn"
390           Next
            
              ' Format Header Row
              
400           Call FormatWordTableRowAsHeader(.Rows(1))
              
              ' Total column background is light gray
              
410           For row = 2 To 8
420               .Cell(row, 8).Shading.BackgroundPatternColor = RGB(217, 217, 217)
430               .Cell(row, 9).Shading.BackgroundPatternColor = RGB(217, 217, 217)
440           Next
                        
              ' Draw a line at the bottom of the table
              
450           .Rows(8).Borders(wdBorderBottom).LineStyle = wdLineStyleSingle
          
460       End With


470   Case "8 periods"

480   doc.Tables.Add range:=range, NumRows:=7, NumColumns:=11
          
490   range.Expand (wdTable)
500   With range.Tables(1)

510       .range.Style = "ddSummaryData"

520       .Rows.Alignment = wdAlignRowCenter
530       .Rows.WrapAroundText = False

540       .LeftPadding = doc.Application.InchesToPoints(0.02)
550       .RightPadding = doc.Application.InchesToPoints(0.02)
560       .TopPadding = doc.Application.InchesToPoints(0.02)
          
570       .columns(1).Width = doc.Application.InchesToPoints(1.81)
580       .columns(2).Width = doc.Application.InchesToPoints(0.43)
590       .columns(3).Width = doc.Application.InchesToPoints(0.43)
600       .columns(4).Width = doc.Application.InchesToPoints(0.43)
610       .columns(5).Width = doc.Application.InchesToPoints(0.43)
620       .columns(6).Width = doc.Application.InchesToPoints(0.43)
630       .columns(7).Width = doc.Application.InchesToPoints(0.43)
640       .columns(8).Width = doc.Application.InchesToPoints(0.72)
650       .columns(9).Width = doc.Application.InchesToPoints(0.43)
660       .columns(10).Width = doc.Application.InchesToPoints(0.43)
670       .columns(11).Width = doc.Application.InchesToPoints(0.5)

680       .Cell(1, 2).range.Text = "9"
690       .Cell(1, 3).range.Text = "10"
700       .Cell(1, 4).range.Text = "11"
710       .Cell(1, 5).range.Text = "12"
720       .Cell(1, 6).range.Text = "13"
730       .Cell(1, 7).range.Text = "14"
740       .Cell(1, 8).range.Text = "STANDARD"
750       .Cell(1, 9).range.Text = "15"
760       .Cell(1, 10).range.Text = "16"
770       .Cell(1, 11).range.Text = "TOTAL"
          
780       .Cell(2, 1).range.Text = "# owls banded"
790       .Cell(3, 1).range.Text = "# owls return"
800       .Cell(4, 1).range.Text = "# owls repeat"
810       .Cell(5, 1).range.Text = "# owls foreign"
820       .Cell(6, 1).range.Text = "# net hours"
830       .Cell(7, 1).range.Text = "# owls banded / 100 net hours"
840      .Cell(7, 1).range.Text = "# nights banding"

          ' Format Labels Column
          
850       For row = 2 To 8
860         .Cell(row, 1).range.Style = "ddLabelsColumn"
870       Next
        
          ' Format Header Row
          
880       Call FormatWordTableRowAsHeader(.Rows(1))
          
          ' Standard and Total columns backgrounds are light gray
          
890       For row = 2 To 8
900           .Cell(row, 8).Shading.BackgroundPatternColor = RGB(217, 217, 217)
910           .Cell(row, 11).Shading.BackgroundPatternColor = RGB(217, 217, 217)
920       Next
                    
          ' Draw a line at the bottom of the table
          
930       .Rows(8).Borders(wdBorderBottom).LineStyle = wdLineStyleSingle

940   End With

950   End Select

      'DD Error Handler Start
Exit_label:
960        Exit Sub
Err_label:
970        Select Case Err.Number
           Case Else
980             Call LogError("basMBOAnnualProgramReportTable3_3_Summary", "WordGenerateTableSummaryOwling")
990        End Select
1000       Resume Exit_label
      'DD Error Handler End

End Sub
