Option Compare Database
Option Explicit

Public Function GenerateIndexSQL(tableName As String) As String
      ' This code was originally written by
      ' Doug Steele, MVP  AccessMVPHelp@gmail.com
      ' Modifications suggested by
      ' George Hepworth, MVP   ghepworth@gpcdata.com
      '
      ' You are free to use it in any application,
      ' provided the copyright notice is left unchanged.
      '
      ' Description: Linked Tables should have an index __uniqueindex.
      '              This function looks for that index in a given
      '              table and creates an SQL statement which can
      '              recreate that index.
      '              (There appears to be no other way to do this!)
      '              If no such index exists, the function returns an
      '              empty string ("").
      '
      ' Inputs:   TableDefObject: Reference to a Table (TableDef object)
      '
      ' Returns:  An SQL string (or an empty string)
      '

10    On Error GoTo Err_GenerateIndexSQL

      Dim dbCurr As DAO.Database
      Dim idxCurr As DAO.Index
      Dim fldCurr As DAO.Field
      Dim strSQL As String
      Dim tdfCurr As DAO.TableDef

20      Set dbCurr = CurrentDb()
30      Set tdfCurr = dbCurr.TableDefs(tableName)

40      If tdfCurr.Indexes.count > 0 Then

      ' Ensure that there's actually an index named
      ' "__UnigueIndex" in the table

50        On Error Resume Next
60        Set idxCurr = tdfCurr.Indexes("__uniqueindex")
70        If Err.Number = 0 Then
80          On Error GoTo Err_GenerateIndexSQL

      ' Loop through all of the fields in the index,
      ' adding them to the SQL statement

90          If idxCurr.Fields.count > 0 Then
100           strSQL = "CREATE INDEX __UniqueIndex ON [" & tableName & "] ("
110           For Each fldCurr In idxCurr.Fields
120             strSQL = strSQL & "[" & fldCurr.Name & "], "
130           Next

      ' Remove the trailing comma and space

140           strSQL = Left$(strSQL, Len(strSQL) - 2) & ")"
150         End If
160       End If
170     End If

End_GenerateIndexSQL:
180     Set fldCurr = Nothing
190     Set tdfCurr = Nothing
200     Set dbCurr = Nothing
210     GenerateIndexSQL = strSQL
220     Exit Function

Err_GenerateIndexSQL:
      ' Error number 3265 is "Not found in this collection
      ' (in other words, either the tablename is invalid, or
      ' it doesn't have an index named __uniqueindex)
230     If Err.Number <> 3265 Then
240       MsgBox Err.Description & " (" & Err.Number & ") encountered", _
            vbOKOnly + vbCritical, "Generate Index SQL"
250     End If
260     Resume End_GenerateIndexSQL

End Function
