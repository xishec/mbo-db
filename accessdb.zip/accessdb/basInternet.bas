'---------------------------------------------------------------------------------------
' Module: basInternet
' Author: David Davey
'---------------------------------------------------------------------------------------

Option Compare Database
Option Explicit

#If VBA7 Then
    Private Declare PtrSafe Function InternetGetConnectedState _
            Lib "wininet.dll" (lpdwFlags As LongPtr, _
                               ByVal dwReserved As Long) As Boolean
#Else
    Private Declare Function InternetGetConnectedState _
            Lib "wininet.dll" (lpdwFlags As Long, _
                               ByVal dwReserved As Long) As Boolean
#End If
Private Const INTERNET_CONNECTION_MODEM As Long = &H1
Private Const INTERNET_CONNECTION_LAN As Long = &H2
Private Const INTERNET_CONNECTION_PROXY As Long = &H4
Private Const INTERNET_CONNECTION_OFFLINE As Long = &H20

'---------------------------------------------------------------------------------------
' IsInternetConnected
'---------------------------------------------------------------------------------------

Function IsInternetConnected() As Boolean

          Dim L As Long
          Dim R As Long
          
10       On Error GoTo Err_label

20        R = InternetGetConnectedState(0, 0&)
30        If R = 0 Then
40            IsInternetConnected = False
50        Else
60            If R <= 4 Then
70                IsInternetConnected = True
80            Else
90                IsInternetConnected = False
100           End If
110       End If

          'DD Error Handler Start
Exit_label:
120       Exit Function
Err_label:
130       Select Case Err.Number
          Case Else
140            Call LogError("Module1", "IsInternetConnected")
150       End Select
160       Resume Exit_label
          ' DD Error Handler End
End Function

Sub InternetConnectedState_Test()
    Debug.Print InternetGetConnectedState(0, 0)
End Sub
