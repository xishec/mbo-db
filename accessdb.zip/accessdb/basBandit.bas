'---------------------------------------------------------------------------------------
' Module    : basBandit
' Author    : David Davey
'---------------------------------------------------------------------------------------

Option Compare Database
Option Explicit

'---------------------------------------------------------------------------------------
' IsImportedRecordBlank
'
' Is the Bandit record blank?

' A record with a blank BandPrefix is considered to be a blank record.
'      A record used to list field names or field name abbreviations
' A record whose fields are all blank, except the BandPrefix and BandSuffix.
'      Bandit exports unused band records that are blank except for
'      the BandPrefix and BandSuffix fields
'---------------------------------------------------------------------------------------
 
Public Function IsImportedRecordBlank(ByRef v As CapturesType) As Boolean
10    On Error GoTo Err_label

      '   If the BandPrefix is blank, then the record is "blank"

20    If Nz(v.BandPrefix, "") = "" Then
30        IsImportedRecordBlank = True
40        GoTo Exit_label
50    End If

      '   If all fields except BandPrefix and BandSuffix are blank,
      '   then the record is "blank"

60    IsImportedRecordBlank = False
70    If Trim(Nz(v.Disposition, "")) = "" Then
80      If Trim(Nz(v.WingChord, "")) = "" Then
90        If Trim(Nz(v.Age, "")) = "" Then
100   If Trim(Nz(v.HowAged, "")) = "" Then
110     If Trim(Nz(v.Sex, "")) = "" Then
120       If Trim(Nz(v.HowSexed, "")) = "" Then
130         If Trim(Nz(v.Fat, "")) = "" Then
140           If Trim(Nz(v.Weight, "")) = "" Then
150             If Trim(Nz(v.CaptureDate, "")) = "" Then
160               If Trim(Nz(v.WeightTime, "")) = "" Then
170                 If Trim(Nz(v.Bander, "")) = "" Then
180                   If Trim(Nz(v.Scribe, "")) = "" Then
190                     If Trim(Nz(v.Net, "")) = "" Then
200                       If Trim(Nz(v.ProbableAge, "")) = "" Then
210                         If Trim(Nz(v.ProbableSex, "")) = "" Then
220                           If Trim(Nz(v.BirdStatus, "")) = "" Then
230                             If Trim(Nz(v.Location, "")) = "" Then
240                               If Trim(Nz(v.NotesForMBO, "")) = "" Then
250                                 IsImportedRecordBlank = True
260                               End If
270                             End If
280                           End If
290                         End If
300                       End If
310                     End If
320                   End If
330                 End If
340               End If
350             End If
360           End If
370         End If
380       End If
390     End If
400   End If
410       End If
420     End If
430   End If

      '   Are the data fields Fn blank ?

440   If IsImportedRecordBlank Then
          Dim i As Integer
450       For i = 1 To conMaxUserField
460           If Trim(Nz(v.F(i), "")) <> "" Then
470               IsImportedRecordBlank = False
480               GoTo Exit_label
490           End If
500       Next i
510   End If
       
      'DD Error Handler Start
Exit_label:
520        Exit Function
Err_label:
530        Select Case Err.Number
           Case Else
540             Call LogError("basBandit", "IsImportedRecordBlank")
550        End Select
560        Resume Exit_label
      'DD Error Handler End
End Function
