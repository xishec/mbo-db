'---------------------------------------------------------------------------------------
' Module    : basMBO10YearReportOtherStats
' Author    : David Davey
'---------------------------------------------------------------------------------------

Option Compare Database
Option Explicit

Const conNonSeason As Integer = -1
Const conWinter  As Integer = 0
Const conSpring  As Integer = 1
Const conSummer  As Integer = 2
Const conFall    As Integer = 3
Const conOwling  As Integer = 4
Const conNestbox As Integer = 5

Const conObserved As Integer = 0
Const conCensus As Integer = 1
Const conBanded As Integer = 2
Const conReturns As Integer = 3
Const conRepeats As Integer = 4
Const conAlien As Integer = 5
Const conReplacement As Integer = 6
Const conDET As Integer = 7

'---------------------------------------------------------------------------------------
' MBO10YearProgramReportOtherStats
'---------------------------------------------------------------------------------------
 
Public Sub MBO10YearProgramReportOtherStats( _
    ByVal intYearFirst As Integer, _
    ByVal intYearLast As Integer, _
    ByVal strLocation As String, _
    ByRef wd As Word.Application, _
    ByRef doc As Word.Document, _
    ByRef oExcel As Excel.Application, _
    ByRef oBook As Excel.Workbook, _
    ByVal fDebug As Boolean)

10    On Error GoTo Err_label

      Dim lngBanded As Long
      Dim lngReturns As Long
      Dim lngRepeats As Long
      Dim lngAlien As Long
      Dim lngReplacement As Long
      Dim lngDET As Long
      Dim dicSpecies(conObserved To conDET) As Scripting.Dictionary
      Dim lngCountBirds(conObserved To conDET) As Long
      Dim strSpecies As String

      Dim stat As Integer ' conObserved To conReplacement

20    For stat = conObserved To conDET
30        lngCountBirds(stat) = 0
40        Set dicSpecies(stat) = New Scripting.Dictionary
50    Next

      Dim oSheet As Excel.Worksheet
60    Set oSheet = InsertSheet(oBook, "Global")
70    oSheet.Name = "Other Stats"

80    With oSheet

90    .Cells(1, 1) = intYearFirst & " to " & intYearLast
100   .Cells(2, 1) = "OBS"
110   .Cells(3, 1) = "Census"
120   .Cells(4, 1) = "Banded"
130   .Cells(5, 1) = "Repeats"
140   .Cells(6, 1) = "Returns"
150   .Cells(7, 1) = "Alien"
160   .Cells(8, 1) = "Replacement"
170   .Cells(9, 1) = "DET"
180   .Cells(10, 1) = "DET every year"
190   .Cells(11, 1) = "Banded every year"
200   .Cells(1, 2) = "Birds"
210   .Cells(1, 3) = "Species"
          
      'Global individuals banded, returns, repeats, alien, replacement

      Dim qdf As QueryDef
220   Set qdf = CurrentDb.QueryDefs("qryMBO10YearProgramReport_BirdsSummary")
230   qdf.Parameters("argLocation").value = strLocation
240   qdf.Parameters("argYearFirst").value = intYearFirst
250   qdf.Parameters("argYearLast").value = intYearLast

      Dim rst As DAO.Recordset
260   Set rst = qdf.OpenRecordset

270   If Not rst.EOF Then
280       lngBanded = Nz(rst("Banded"))
290       lngReturns = Nz(rst("Returns"))
300       lngRepeats = Nz(rst("Repeats"))
310       lngAlien = Nz(rst("Alien"))
320       lngReplacement = Nz(rst("Replacement"))
          
330       .Cells(4, 2) = lngBanded
340       .Cells(5, 2) = lngRepeats
350       .Cells(6, 2) = lngReturns
360       .Cells(7, 2) = lngAlien
370       .Cells(8, 2) = lngReplacement

          
380   End If
390   rst.Close
400   Set rst = Nothing

      'Global species observations, census, banded, returns, repeats, alien, replacement, DET


410   Set qdf = CurrentDb.QueryDefs("qryMBO10YearProgramReport_SpeciesSummary")
420   qdf.Parameters("argLocation").value = strLocation
430   qdf.Parameters("argYearFirst").value = intYearFirst
440   qdf.Parameters("argYearLast").value = intYearLast

      'Dim rst As DAO.Recordset
450   Set rst = qdf.OpenRecordset

460   Do While Not rst.EOF
470       strSpecies = Nz(rst("Species"))
480       lngCountBirds(conObserved) = Nz(rst("Observed"))
490       lngCountBirds(conCensus) = Nz(rst("Census"))
500       lngCountBirds(conBanded) = Nz(rst("Banded"))
510       lngCountBirds(conReturns) = Nz(rst("Returns"))
520       lngCountBirds(conRepeats) = Nz(rst("Repeats"))
530       lngCountBirds(conAlien) = Nz(rst("Alien"))
540       lngCountBirds(conReplacement) = Nz(rst("Replacement"))
550       lngCountBirds(conDET) = Nz(rst("DET"))
          
560       For stat = conObserved To conDET
570           If lngCountBirds(stat) > 0 Then
580               If Not dicSpecies(stat).Exists(strSpecies) Then
590                   Call dicSpecies(stat).Add(strSpecies, strSpecies)
600               End If
610           End If
620       Next
630       rst.MoveNext
640   Loop
650   rst.Close
660   Set rst = Nothing

      Dim row As Long
670   For stat = conObserved To conDET
680       row = stat + 2
690       .Cells(row, 3) = CountSpeciesInDictionary(dicSpecies(stat))
700   Next

      ' How many species were DETed every year

      Dim lngCountYears As Long
710   dicSpecies(conDET).RemoveAll

720   Set qdf = CurrentDb.QueryDefs("qryMBO10YearProgramReport_DETSpeciesEveryYear_A")
730   qdf.Parameters("argLocation").value = strLocation
740   qdf.Parameters("argYearFirst").value = intYearFirst
750   qdf.Parameters("argYearLast").value = intYearLast
760   Set rst = qdf.OpenRecordset

770   Do While Not rst.EOF
780       strSpecies = Nz(rst("Species"))
790       lngCountYears = Nz(rst("CountYears"))
800       If lngCountYears = intYearLast - intYearFirst + 1 Then
810           If Not dicSpecies(conDET).Exists(strSpecies) Then
820               Call dicSpecies(conDET).Add(strSpecies, strSpecies)
830           End If
840       End If

850       rst.MoveNext
860   Loop
870   rst.Close
880   Set rst = Nothing

890   .Cells(10, 3) = CountSpeciesInDictionary(dicSpecies(conBanded))
900   .Cells(10, 4) = .Cells(10, 3) / .Cells(9, 3)

      ' How many species were banded every year


910   dicSpecies(conBanded).RemoveAll

920   Set qdf = CurrentDb.QueryDefs("qryMBO10YearProgramReport_BandedSpeciesEveryYear_A")
930   qdf.Parameters("argLocation").value = strLocation
940   qdf.Parameters("argYearFirst").value = intYearFirst
950   qdf.Parameters("argYearLast").value = intYearLast
960   Set rst = qdf.OpenRecordset

970   Do While Not rst.EOF
980       strSpecies = Nz(rst("Species"))
990       lngCountYears = Nz(rst("CountYears"))
1000      If lngCountYears = intYearLast - intYearFirst + 1 Then
1010          If Not dicSpecies(conBanded).Exists(strSpecies) Then
1020              Call dicSpecies(conBanded).Add(strSpecies, strSpecies)
1030          End If
1040      End If

1050      rst.MoveNext
1060  Loop
1070  rst.Close
1080  Set rst = Nothing

1090  .Cells(11, 3) = CountSpeciesInDictionary(dicSpecies(conBanded))
1100  .Cells(11, 4) = .Cells(11, 3) / .Cells(4, 3)

1110  .range(.Cells(10, 4), .Cells(11, 4)).NumberFormat = "0%"


      ' Birds banded by season


1120  .Cells(13, 2) = "Birds banded by Season"
1130  row = 14

1140  Set qdf = CurrentDb.QueryDefs("qryMBO10YearProgramReport_BandedBirdsBySeason")
1150  qdf.Parameters("argLocation").value = strLocation
1160  qdf.Parameters("argYearFirst").value = intYearFirst
1170  qdf.Parameters("argYearLast").value = intYearLast

      'Dim rst As DAO.Recordset
1180  Set rst = qdf.OpenRecordset

1190  Do While Not rst.EOF
1200      .Cells(row, 1) = Nz(rst("Season"))
1210      .Cells(row, 2) = Nz(rst("Banded"))
1220      row = row + 1
1230      rst.MoveNext
1240  Loop
1250  rst.Close
1260  Set rst = Nothing

1270  .range(.columns(1), .columns(3)).AutoFit

1280  End With

      'DD Error Handler Start
Exit_label:
1290       Exit Sub
Err_label:
1300       Select Case Err.Number
           Case Else
1310      Call LogError("basMBO10YearReportOtherStats", "MBO10YearProgramReportOtherStats")
1320       End Select
1330       Resume Exit_label
      'DD Error Handler End
End Sub
