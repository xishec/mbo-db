'---------------------------------------------------------------------------------------
' Module    : basMBOAnnualProgramReportTable4_1F
' Author    : David Davey
'---------------------------------------------------------------------------------------

Option Compare Database
Option Explicit

'Public Declare Sub Sleep Lib "kernel32" (ByVal dwMilliseconds As Long) => basSleep

'Private intYear As Integer
'Private strLocation As String
'Private strProgram As String
'Private strSeason As String

'---------------------------------------------------------------------------------------
' MBOAnnualProgramReportTable4_1F
'---------------------------------------------------------------------------------------
' Banded Individuals + Species

Public Sub MBOAnnualProgramReportFigureBirds( _
    ByVal intYear As Integer, _
    ByVal strSeason As String, _
    ByRef wd As Word.Application, _
    ByRef doc As Word.Document)

10    On Error GoTo Err_label

20    SysCmd acSysCmdSetStatus, strSeason & " Figures"

      ' Word captions

      Dim range As Word.range

30    Set range = MoveInsertionPointToEndOfDocument(wd, doc)
40    range.InsertParagraphAfter

50    If strSeason = "Spring" Then
60        Call InsertTableCaptionXX(wd, doc, "Figure", _
            "4.1", _
            "Daily and running 7-day mean of individuals banded per day throughout spring " & intYear & ".", _
            "Daily and running 7-day mean of individuals banded per day throughout spring " & intYear)
70    Else
80        Call InsertTableCaptionXX(wd, doc, "Figure", _
            "6.1", _
            "Daily and running 7-day mean of individuals banded per day throughout fall " & intYear & ".", _
            "Daily and running 7-day mean of individuals banded per day throughout fall " & intYear)
90    End If



      'DD Error Handler Start
Exit_label:
100        Exit Sub
Err_label:
110        Select Case Err.Number
           Case Else
120             Call LogError("basMBOAnnualProgramReportTable4_1F", "MBOAnnualProgramReportTable4_1F")
130        End Select
140        Resume Exit_label
      'DD Error Handler End
End Sub
