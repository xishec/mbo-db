Option Compare Database
Option Explicit

Const conNonSeason As Integer = -1
Const conWinter  As Integer = 0
Const conSpring  As Integer = 1
Const conSummer  As Integer = 2
Const conFall    As Integer = 3
Const conOwling  As Integer = 4
Const conRTHU    As Integer = 5
Const conNestbox As Integer = 6
Const conSummerNestbox As Integer = 7

Const intSeasonFirst As Integer = -1
Const intSeasonLast  As Integer = 7

'---------------------------------------------------------------------------------------
' MBOProgramReport_Repeats
'---------------------------------------------------------------------------------------
 
Public Sub MBOProgramReport_Repeats( _
    ByVal intYearFirst As Integer, _
    ByVal intYearLast As Integer, _
    ByVal strLocation As String, _
    ByRef oBook As Excel.Workbook)
          
      Dim intSeason As Integer
      Dim strSeason As String
      Dim intYear As Integer
      Dim strSpecies As String
      Dim strSpeciesEnglish As String
      Dim oSheet As Excel.Worksheet
      Dim lngCountBirds As Long
      Dim lngCountRepeats As Long
      Dim row As Long

      Const colSeason As Integer = 1
      Const colYear As Integer = 2
      Const colSpecies As Integer = 3
      Const colSpeciesEnglish As Integer = 4
      Const colCountRepeats As Integer = 5
      Const colCountBirds As Integer = 6

10    On Error GoTo Err_label

20    For intSeason = intSeasonFirst To intSeasonLast
30        strSeason = toStrSeasonFromIntSeason(intSeason)

40        SysCmd acSysCmdSetStatus, strSeason & " Repeats"
          
50        Set oSheet = InsertSheet(oBook, strSeason)
60        oSheet.Name = strSeason & " Repeats"
70        With oSheet

          Dim qdf As QueryDef
80        Set qdf = CurrentDb.QueryDefs("qryMBOProgramReport_Repeats_B")
90        qdf.Parameters("argLocation").value = strLocation
100       qdf.Parameters("argSeason").value = strSeason
110       qdf.Parameters("argYearFirst").value = intYearFirst
120       qdf.Parameters("argYearLast").value = intYearLast
          
          Dim rst As DAO.Recordset
130       Set rst = qdf.OpenRecordset
          
140       row = 1
150       .Cells(row, colSeason) = "Season"
160       .Cells(row, colYear) = "Year"
170       .Cells(row, colSpecies) = "Species"
180       .Cells(row, colSpeciesEnglish) = "English"
190       .Cells(row, colCountRepeats) = "# Repeats"
200       .Cells(row, colCountBirds) = "# Birds"
210       row = row + 1
          
220       Do While Not rst.EOF
          
230       lngCountBirds = Nz(rst("CountBirds"))
240       strSpecies = Nz(rst("Species"))
250       intYear = Nz(rst("YearEx"))
260       strSpecies = Nz(rst("CountBirds"))
270       lngCountRepeats = Nz(rst("Countrepeats"))
280       strSpeciesEnglish = Nz(rst("SpeciesEnglish"))
            
290       .Cells(row, colSeason) = strSeason
300       .Cells(row, colYear) = intYear
310       .Cells(row, colSpecies) = strSpecies
320       .Cells(row, colSpeciesEnglish) = strSpeciesEnglish
330       .Cells(row, colCountRepeats) = lngCountRepeats
340       .Cells(row, colCountBirds) = lngCountBirds
350       row = row + 1
        
360       rst.MoveNext
370       Loop
380       rst.Close
390       Set rst = Nothing
          
400       If row <> 2 Then
          
          ' Pivot Table

          Dim rngData As Excel.range
          Dim pvt As Excel.PivotTable
          Dim pvtfld As Excel.PivotField
          
410       Set rngData = .range(.Cells(1, 1), .Cells(row - 1, colCountBirds))
          
420       oBook.PivotCaches.Create(SourceType:=xlDatabase, SourceData:=rngData, _
          Version:=xlPivotTableVersion12).CreatePivotTable TableDestination:=.range("H1"), tableName:="PivotTable1", DefaultVersion:=xlPivotTableVersion12
          
430       Set pvt = .PivotTables("PivotTable1")
      '    pvt.ManualUpdate = True

440       With pvt.PivotFields("English")
450       .Orientation = xlRowField
460       .Position = 1
470       End With

480       With pvt.PivotFields("Year")
490       .Orientation = xlColumnField
500       .Position = 1
510       End With

520       With pvt.PivotFields("# Repeats")
530       .Orientation = xlColumnField
540       .Position = 2
550       End With

560       With pvt.PivotFields("# Birds")
570       .Orientation = xlDataField
580       .Function = xlSum
590       .NumberFormat = "#"
600       End With

610       pvt.TableRange1.Cells.Copy
          
          Dim rowTarget As Long
          Dim lngRows As Long
          Dim lngColumns As Long
          
620       lngRows = pvt.TableRange1.Rows.count
630       lngColumns = pvt.TableRange1.columns.count
640       rowTarget = pvt.TableRange1.Rows.count + 4
          
          ' Sort .cells(rowTarget+3,8) .cells(rowTarget+3+lngRows-3,8+lngColumns)   sort column is 7+lngColumns
          
          Dim rangeData As Excel.range
650       Set rangeData = .range(.Cells(rowTarget + 3, 8), .Cells(rowTarget + 3 + lngRows - 3, 8 + lngColumns))

          Dim rangeKey As Excel.range
660       Set rangeKey = .range(.Cells(rowTarget + 3, 7 + lngColumns), .Cells(rowTarget + 3 + lngRows - 3, 7 + lngColumns))
        
          
670       .Cells(rowTarget, 8).PasteSpecial xlPasteValues
          
          
680       rangeData.Sort key1:=rangeKey, Order1:=xlDescending
          
      '    pvt.ManualUpdate = False
          
690       End If
          
700       .range("h4").Select
710       oBook.Application.ActiveWindow.FreezePanes = True

          
720       End With
730   Next

740   SysCmd acSysCmdClearStatus

      'DD Error Handler Start
Exit_label:
750        Exit Sub
Err_label:
760        Select Case Err.Number
           Case Else
770       Call LogError("basMBOProgramReport_Repeats", "MBOProgramReport_Repeats")
780        End Select
790        Resume Exit_label
      'DD Error Handler End
End Sub
