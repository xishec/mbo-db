Option Compare Database
Option Explicit

Const conWinter As Integer = 1
Const conSpring As Integer = 2
Const conSummer As Integer = 3
Const conNestbox As Integer = 4
Const conFall As Integer = 5
Const conOwling As Integer = 6
Const conSNBU As Integer = 7
Const conNichoir As Integer = 8

'---------------------------------------------------------------------------------------
'DisplayImageForProgram
'---------------------------------------------------------------------------------------
'
' Assign a monitoring program related picture to an image control
' The pictures are stored in the images subfolder
' tblImages contains the filenames of the pictures

Public Sub DisplayImageForProgram(ByVal strProgram As String, ByRef imgProgram As Image)

      Dim strSeason   As String
      Dim strFilename As String
      Dim strFilepath As String
      Dim intImageID  As Integer

10    On Error GoTo Err_label

20    If strProgram <> "" Then

30        If strProgram = "Nichoir" Then
40            intImageID = conNichoir
50        ElseIf Left(strProgram, 4) = "SNBU" Then
60            intImageID = conSNBU
70        Else
80            strSeason = Nz(DLookup("MonitoringProgramSeason", "tblPrograms", "[Program] = '" & strProgram & "'"))
90            Select Case strSeason
              Case "Winter"
100           intImageID = conWinter
110           Case "Spring"
120               intImageID = conSpring
130           Case "Summer"
140               intImageID = conSummer
150           Case "Fall"
160               intImageID = conFall
170           Case "Owling"
180               intImageID = conOwling
190           Case "nestbox"
200               intImageID = conNestbox
210           Case Else
220               intImageID = 0
230           End Select
240       End If
          
250       If intImageID <> 0 Then
260           strFilename = Nz(DLookup("Filename", "tblImages", "[ID] = " & intImageID))
270           If strFilename <> "" Then
280               strFilepath = CurrentProject.path & "\images\" & strFilename
290               If FileExists(strFilepath) Then
300                   imgProgram.Visible = True
310                   imgProgram.Picture = strFilepath
320               Else
330                   imgProgram.Visible = False
340               End If
350           Else
360               imgProgram.Visible = False
370           End If
380       Else
390           imgProgram.Visible = False
400       End If
410   Else
420       imgProgram.Visible = False
430   End If

      'DD Error Handler Start
Exit_label:
440        Exit Sub
Err_label:
450        Select Case Err.Number
           Case Else
460       Call LogError("basImage", "DisplayImageForProgram")
470        End Select
480        Resume Exit_label
      'DD Error Handler End

End Sub
