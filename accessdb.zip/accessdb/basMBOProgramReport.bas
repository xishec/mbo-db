'---------------------------------------------------------------------------------------
' Module    : basMBOProgramReport
' Author    : David Davey
'---------------------------------------------------------------------------------------

Option Compare Database
Option Explicit

' DET
' ---
' A DET day is a day on which either a non zero DET value is recorded for at least one species, OR is a capture day.
' Exception: The Nestling and Owling programs do not have DET days. (Even if there happen to be DET values recorded in the database)
' The synthetic  "Summer+Nestbox" program has the same DET days as the summer program.
'
' I only need to process Winter, Spring, Summer, and Fall.  SummerNestling = Summer.

' Captures
' --------
' Captures include all processed birds captured in nets, in birdboxes, wandering into the banding station, ducks in molt, anything ...
' Hummingbirds are excluded, since they are not processed.
' A capture day is any day in which any processed bird is captured OR on which the nets were opened
' So, if the only bird captured was a duck in molt, its a capture day.
' If the nets were openend and no birds were captured, its a capture day.
' All seasons can have capture days. The "Non-season" season can have capture days.  Synthetic seasons such as "Summer+Nestligs" can have capture days.

Const conNonSeason As Integer = -1
Const conWinter  As Integer = 0
Const conSpring  As Integer = 1
Const conSummer  As Integer = 2
Const conFall    As Integer = 3
Const conOwling  As Integer = 4
Const conRTHU    As Integer = 5
Const conNestbox As Integer = 6
Const conSummerNestbox As Integer = 7

Const conDETSeasonFirst As Integer = -1
Const conDETSeasonLast  As Integer = 3

Const conCaptureSeasonFirst As Integer = -1
Const conCaptureSeasonLast As Integer = 7
Const conCaptureRealSeasonLast As Integer = 6 ' SummerNestbox is a synthetic season

Const intSeasonFirst As Integer = -1
Const intSeasonLast As Integer = 7

'Public strProgram(conCaptureSeasonFirst To conCaptureSeasonLast, intYearFirst to intYearLast)                   As String        ' strProgram(...) = "" iff program does not exist
'Public datProgramOfficialStartDate_SeasonYear(conCaptureSeasonFirst To conCaptureSeasonLast, intYearFirst to intYearLast)  As Date
'Public datProgramDateFirst_SeasonYear(conCaptureSeasonFirst To conCaptureSeasonLast, intYearFirst to intYearLast)          As Date
'Public datProgramDateLast_SeasonYear(conCaptureSeasonFirst To conCaptureSeasonLast, intYearFirst to intYearLast)           As Date

Public strProgram()                              As String   ' Redim and loaded in MBOProgramReportPeriodsCount ' Program ID
Public datProgramOfficialStartDate_SeasonYear()  As Date     ' Redim and loaded in MBOProgramReportPeriodsCount ' Official Start Date of a program -- Spring, Fall, Owling only
Public datProgramDateFirst_SeasonYear()          As Date     ' Redim and loaded in MBOProgramReportPeriodsCount ' Date of the first DET sheet for a season x year
Public datProgramDateLast_SeasonYear()           As Date     ' Redim and loaded in MBOProgramReportPeriodsCount ' Date of the last DET sheet for a season x year

' The above array

' The following dates use the standard year 2000 (exception datProgramDateFirst_SeasonYear_Season(conWinter) uses 1999)
Public datProgramDateFirst_Season(intSeasonFirst To intSeasonLast) As Date           ' Date of the first DET sheet for a season
Public datProgramDateLast_Season(intSeasonFirst To intSeasonLast)  As Date           ' Date of the last DET sheet for a season

' Number of periods in a season x year
' Maximum number of periods in a season (max. over all years for a given season)
' Maximum number of periods (max for all years and seaons)

Public intPeriodLast_Season(conCaptureSeasonFirst To conCaptureSeasonLast) As Integer ' Loaded in MBOProgramReportPeriodsCount
Public intPeriodLast_SeasonYear() As Integer    ' Redim and loaded in MBOProgramReportPeriodsCount ' (conCaptureSeasonFirst To conCaptureSeasonLast, intYearFirst To intYearLast)
Public intPeriodLast As Integer                 ' Loaded in MBOProgramReportPeriodsCount ' The highest number period over all years and all seasons (14)

Public intCapturePeriodFirst_SeasonYear() As Integer     ' (conSeasonFirst To conSeasonLast, intYearFirst To intYearLast)
Public intCapturePeriodLast_SeasonYear() As Integer      ' (conSeasonFirst To conSeasonLast, intYearFirst To intYearLast)

' Days

' The First Day is always 0
Public intDayLast_SeasonYear() ' intSeasonFirst to intSeasonLast, intYearFirst to intYearLast

' *** The number of day less 1 between the global season first date and the global season last date ***
Public intDayLast_Season(intSeasonFirst To intSeasonLast)     ' intSeasonFirst to intSeasonLast

Public intDayLast As Integer ' Max of intDayLast_Season(intSeasonFirst To intSeasonLast)  -- use this as a dimension for days

' --------
' DET Days
' --------

' intDETDaysCountSeasonYearPeriod( conDETSeasonFirst to conDETSeasonLast, intYearFirst to intYearLast, 1 to intPeriodLast)
' # DET Days in given Season x Year x Period
' OBSOLETRE

' intDETDaysCountSeasonYear( conDETSeasonFirst To conDETSeasonLast, intYearFirst To intYearLast)
' # DET Days in given Season x Year

' intDETDaysCountSeasonPeriod( conDETSeasonFirst To conDETSeasonLast, 1 To intPeriodLast)
' # DET-Days in given Season x Period

' intDETDaysCountSeason( conDETSeasonFirst To conDETSeasonLast)
' # DET-Days in given Season

' ---------
' DET Years
' ---------

' intDETYearsCountSeasonPeriod( conDETSeasonFirst To conDETSeasonLast, 1 To intPeriodLast)
' # DET-Years in given Season x Period
' For a given season x period, count the years for which intDETDaysCountSeasonYearPeriod( season, year, period ) > 0

' intDETYearsCountSeason( conDETSeasonFirst To conDETSeasonLast)
' # DET-Years in given Season
' For a given season, count the years for which intDETDaysCountSeasonYear( season, year ) > 0

' Public intDETDaysCountSeasonYearPeriod() As Integer OBSOLETE
' Public intDETDaysCountSeasonYear() As Integer OBSOLETE
' Public intDETDaysCountSeasonPeriod() As Integer OBSOLETE
' Public intDETDaysCountSeason() As Integer OBSOLETE
' Public intDETYearsCountSeasonPeriod() As Integer
' Public intDETYearsCountSeason() As Integer


Private oSheetGlobalEnd As Excel.Worksheet
Private oSheetNonSeasonEnd As Excel.Worksheet
Private oSheetWinterEnd As Excel.Worksheet
Private oSheetSpringEnd As Excel.Worksheet
Private oSheetSummerEnd As Excel.Worksheet
Private oSheetNestboxEnd As Excel.Worksheet
Private oSheetSummerNestboxEnd As Excel.Worksheet
Private oSheetFallEnd As Excel.Worksheet
Private oSheetOwlingEnd As Excel.Worksheet
Private oSheetRTHUEnd As Excel.Worksheet
'
' During initialisation, I create worksheets to mark the end of each section of the Excel workbook
' Call Public Function InsertSheet(ByRef oBook As Excel.Workbook, ByVal strSeason As String) As Excel.Worksheet to create a new sheet
' The sections are: "Global", "Non-Season", "Winter", "Spring", "Summer", "Nestbox", "Fall", "Owling", "Summer+Nestbox", and there is a final section for anything else
' During finalisation, I delete the worksheets that  mark the end of each section of the Excel workbook
'

'---------------------------------------------------------------------------------------
' getPeriodLast_Season
'---------------------------------------------------------------------------------------

Public Function getPeriodLast_Season(ByVal strSeason As String) As Integer
10       On Error GoTo Err_label

20        Select Case strSeason
          Case "Winter"
30            getPeriodLast_Season = intPeriodLast_Season(conWinter)
40        Case "Spring"
50            getPeriodLast_Season = intPeriodLast_Season(conSpring)
60        Case "Summer"
70            getPeriodLast_Season = intPeriodLast_Season(conSummer)
80        Case "Fall"
90            getPeriodLast_Season = intPeriodLast_Season(conFall)
100       Case "Owling"
110           getPeriodLast_Season = intPeriodLast_Season(conOwling)
120       Case "RTHU"
130           getPeriodLast_Season = intPeriodLast_Season(conRTHU)
140       Case "Nestbox"
150           getPeriodLast_Season = intPeriodLast_Season(conNestbox)
160      Case "SummerNestBox"
170           getPeriodLast_Season = intPeriodLast_Season(conSummerNestbox)
180       End Select

          'DD Error Handler Start
Exit_label:
190       Exit Function
Err_label:
200       Select Case Err.Number
          Case Else
210            Call LogError("basMBOProgramReport", "getPeriodLast_Season")
220       End Select
230       Resume Exit_label
          ' DD Error Handler End
          
End Function

'---------------------------------------------------------------------------------------
' getPeriodLast_intSeason
'---------------------------------------------------------------------------------------

Public Function getPeriodLast_intSeason(ByVal intSeason As String) As Integer

10    On Error GoTo Err_label

20    getPeriodLast_intSeason = intPeriodLast_Season(intSeason)

    'DD Error Handler Start
Exit_label:
30        Exit Function
Err_label:
40        Select Case Err.Number
    Case Else
50       Call LogError("basMBOProgramReport", "getPeriodLast_intSeason")
60        End Select
70        Resume Exit_label
    ' DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' DeleteEndOfSeasonSheets
'---------------------------------------------------------------------------------------
 
Public Sub DeleteEndOfSeasonSheets(ByRef oExcel As Excel.Application, ByRef oBook As Excel.Workbook)
10    On Error GoTo Err_label

'20    oExcel.DisplayAlerts = False
20    oSheetGlobalEnd.Delete
30    oSheetNonSeasonEnd.Delete
40    oSheetWinterEnd.Delete
50    oSheetSpringEnd.Delete
60    oSheetSummerEnd.Delete
70    oSheetNestboxEnd.Delete
80    oSheetFallEnd.Delete
90    oSheetOwlingEnd.Delete
100   oSheetSummerNestboxEnd.Delete
110   oSheetRTHUEnd.Delete

120   Set oSheetGlobalEnd = Nothing
130   Set oSheetNonSeasonEnd = Nothing
140   Set oSheetWinterEnd = Nothing
150   Set oSheetSpringEnd = Nothing
160   Set oSheetSummerEnd = Nothing
170   Set oSheetNestboxEnd = Nothing
180   Set oSheetFallEnd = Nothing
190   Set oSheetOwlingEnd = Nothing
200   Set oSheetSummerNestboxEnd = Nothing
210   Set oSheetRTHUEnd = Nothing
'130   oExcel.DisplayAlerts = True

      'DD Error Handler Start
Exit_label:
220        Exit Sub
Err_label:
230        Select Case Err.Number
           Case Else
240             Call LogError("basMBOProgramReport", "DeleteEndOfSeasonSheets")
250        End Select
260        Resume Exit_label
      'DD Error Handler End
        
End Sub

'---------------------------------------------------------------------------------------
' InsertSheet
'---------------------------------------------------------------------------------------
 
Public Function InsertSheet(ByRef oBook As Excel.Workbook, ByVal strSeason As String) As Excel.Worksheet
      Dim oSheet As Excel.Worksheet
10    On Error GoTo Err_label

20    Select Case strSeason
      Case "Global"
30        Set InsertSheet = oBook.Worksheets.Add(Before:=oSheetGlobalEnd)
40    Case "Non-Season"
50        Set InsertSheet = oBook.Worksheets.Add(Before:=oSheetNonSeasonEnd)
60    Case "Winter"
70            Set InsertSheet = oBook.Worksheets.Add(Before:=oSheetWinterEnd)
80    Case "Spring"
90            Set InsertSheet = oBook.Worksheets.Add(Before:=oSheetSpringEnd)
100   Case "Summer"
110           Set InsertSheet = oBook.Worksheets.Add(Before:=oSheetSummerEnd)
120   Case "Nestbox"
130           Set InsertSheet = oBook.Worksheets.Add(Before:=oSheetNestboxEnd)
140   Case "Fall"
150           Set InsertSheet = oBook.Worksheets.Add(Before:=oSheetFallEnd)
160   Case "Owling"
170           Set InsertSheet = oBook.Worksheets.Add(Before:=oSheetOwlingEnd)
180   Case "RTHU"
190           Set InsertSheet = oBook.Worksheets.Add(Before:=oSheetRTHUEnd)
200   Case "Summer+Nestbox"
210           Set InsertSheet = oBook.Worksheets.Add(Before:=oSheetSummerNestboxEnd)
220   Case Else
230           Call LogError("basMBOProgramReport", "InsertSheet", "Unrecognized season " & strSeason)
240   End Select

      'DD Error Handler Start
Exit_label:
250        Exit Function
Err_label:
260        Select Case Err.Number
           Case Else
270             Call LogError("basMBOProgramReport", "InsertSheet")
280        End Select
290        Resume Exit_label
      'DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' MBOProgramReport_Initialise
'---------------------------------------------------------------------------------------
'Insert temporary worksheets to mark the end of sections in the Excel workbook
'
'Load the following arrays and variables
'
'strProgram(
'    conCaptureSeasonFirst To conCaptureSeasonLast,
'    intYearFirst to intYearLast)
'
'datProgramOfficialStartDate_SeasonYear(
'    conCaptureSeasonFirst To conCaptureSeasonLast,
'    intYearFirst to intYearLast)
'
'datProgramDateFirst_SeasonYear(
'    conCaptureSeasonFirst To conCaptureSeasonLast,
'    intYearFirst to intYearLast)
'
'datProgramDateLast_SeasonYear(
'    conCaptureSeasonFirst To conCaptureSeasonLast,
'    intYearFirst to intYearLast)
'
'intPeriodLast_Season(
'    conCaptureSeasonFirst To conCaptureSeasonLast)
'
'intCapturePeriodFirst_SeasonYear
'
'intCapturePeriodLast_SeasonYear
'
'intDayLast_SeasonYear(intSeasonFirst To intSeasonLast, intYearFirst To intYearLast)
'
'datProgramDateFirst_Season(intSeasonFirst To intSeasonLast)
'
'datProgramDateLast_Season(intSeasonFirst To intSeasonLast)
'
'intDayLast_Season(intSeasonFirst To intSeasonLast)
'
'intDayLast
'
'intPeriodLast_SeasonYear(
'    conCaptureSeasonFirst To conCaptureSeasonLast,
'    intYearFirst To intYearLast)
'
'intPeriodLast_Season(
'    intSeasonFirst to intSeasonLast)
'
'intCapturePeriodFirst_SeasonYear(
'    conSeasonFirst To conSeasonLast,
'    intYearFirst To intYearLast)
'
'intCapturePeriodLast_SeasonYear(
'    conSeasonFirst To conSeasonLast,
'    intYearFirst To intYearLast)
'
'Load tblMBOProgramReport_DETSpecies
'-------------------------------------------------------
'Same as tblDETSpecies + Period, YearEx, SpeciesEnglish, DateFrom, except
'   Only records BETWEEN argYearFirst AND argYearLast
'
'Call MBOProgramReport_SeasonYearPeriod_Part_A to load
'   CaptureDays, CapturePeriods, DETDays, DETPeriods, CensusDays, CensusPeriods into
'   dblStatSeasonYearPeriod(intStatFirst To intStatLast, intSeasonFirst To intSeasonLast, _
'                           intYearFirst To intYearLastEx, 1 To intPeriodLastEx) As Double
'(The later is declared in basMBOProgramReport_SeasonYearPeriod;

'The constants are declared in basMBOProgramReport)

 
Public Sub MBOProgramReport_Initialise( _
    ByVal intYearFirst As Integer, _
    ByVal intYearLast As Integer, _
    ByVal strLocation As String, _
    ByRef oBook As Excel.Workbook)
          
10    On Error GoTo Err_label

20    With oBook
30        Set oSheetGlobalEnd = .Worksheets.Add(After:=.Worksheets(.Worksheets.count))
40        Set oSheetWinterEnd = .Worksheets.Add(After:=.Worksheets(.Worksheets.count))
50        Set oSheetSpringEnd = .Worksheets.Add(After:=.Worksheets(.Worksheets.count))
60        Set oSheetSummerEnd = .Worksheets.Add(After:=.Worksheets(.Worksheets.count))
70        Set oSheetNestboxEnd = .Worksheets.Add(After:=.Worksheets(.Worksheets.count))
80        Set oSheetFallEnd = .Worksheets.Add(After:=.Worksheets(.Worksheets.count))
90        Set oSheetOwlingEnd = .Worksheets.Add(After:=.Worksheets(.Worksheets.count))
100       Set oSheetSummerNestboxEnd = .Worksheets.Add(After:=.Worksheets(.Worksheets.count))
105       Set oSheetRTHUEnd = .Worksheets.Add(After:=.Worksheets(.Worksheets.count))
110       Set oSheetNonSeasonEnd = .Worksheets.Add(After:=.Worksheets(.Worksheets.count))
120   End With

130   Call MBOProgramReportPeriodsCount(intYearFirst, intYearLast, strLocation)
140   Call MBOProgramReportPeriodsCount_Excel(intYearFirst, intYearLast, strLocation, oBook)

' 50    Call MBOProgramReportDaysCount(intYearFirst, intYearLast, strLocation, oBook)

150   On Error Resume Next
160   DoCmd.DeleteObject acTable, "tblMBOProgramReport_DETSpecies"
170   On Error GoTo Err_label

' qryMBOProgramReport_DETSpecies
' ------------------------------
' tblPrograms x tblDETDaily x tblDETSpecies x tblSpecies
' ------------------------------
' Season = MonitoringProgramSeason
' YearEx BETWEEN argYearFirst AND argYearLast
' Location = argLocation
' DateEx
' Program
' NetHours: SongbirdNets
' Observed
' Census
' Banded
' Repeats
' Returns
' DET
' Alien = Observed3
' Replacement = Observed4
' Species
' SpeciesEnglish
' Period = toPeriod([MonitoringProgramSeason],[tblDETDaily].[DateEx],[DateFrom])
' DateFrom


' qryMBOProgramReport_DETSpecies_MakeTable
' ----------------------------------------
' Load tblMBOProgramReport_DETSpecies from qryMBOProgramReport_DETSpecies

' tblMBOProgramReport_DETSpecies
' ------------------------------
' Same as tblDETSpecies + Period, YearEx, SpeciesEnglish, DateFrom
' Only records BETWEEN argYearFirst AND argYearLast


      Dim qdf As QueryDef
180   Set qdf = CurrentDb.QueryDefs("qryMBOProgramReport_DETSpecies_MakeTable")
190   qdf.Parameters("argLocation").value = strLocation
200   qdf.Parameters("argYearFirst").value = intYearFirst
210   qdf.Parameters("argYearLast").value = intYearLast
220   qdf.Execute

230   Call MBOProgramReport_SeasonYearPeriod_Part_A(intYearFirst, intYearLast, strLocation, oBook)

      'DD Error Handler Start
Exit_label:
240        Exit Sub
Err_label:
250        Select Case Err.Number
           Case Else
260             Call LogError("basMBOProgramReport", "MBOProgramReport_Initialise")
270        End Select
280        Resume Exit_label
      'DD Error Handler End
          
End Sub

'---------------------------------------------------------------------------------------
' toIntDaySeasonFromDate
'---------------------------------------------------------------------------------------

Public Function toIntDayFromDate(ByVal intSeason As Integer, ByVal datDate As Date) As Integer

      Dim datDateOfFirstDETSheet As Date

10    On Error GoTo Err_label

20    datDateOfFirstDETSheet = datProgramDateFirst_Season(intSeason)
30    If datDateOfFirstDETSheet > 0 Then
40        toIntDayFromDate = toDate2000(datDate, intSeason) - datDateOfFirstDETSheet
50    Else
60        toIntDayFromDate = -1
70    End If

      'DD Error Handler Start
Exit_label:
80         Exit Function
Err_label:
90         Select Case Err.Number
           Case Else
100             Call LogError("basMBOProgramReport", "toIntDayFromDate")
110        End Select
120        Resume Exit_label
      'DD Error Handler End

End Function

'---------------------------------------------------------------------------------------
' toDateFromIntDay
'---------------------------------------------------------------------------------------
 
Public Function toDateFromIntDay(ByVal intSeason As Integer, ByVal intDay As Integer) As Date

      Dim datDateOfFirstDETSheet As Date

10    On Error GoTo Err_label

20    datDateOfFirstDETSheet = datProgramDateFirst_Season(intSeason)
30    If datDateOfFirstDETSheet > 0 Then
40        toDateFromIntDay = datDateOfFirstDETSheet + intDay
50    Else
60        toDateFromIntDay = 0
70    End If

      'DD Error Handler Start
Exit_label:
80         Exit Function
Err_label:
90         Select Case Err.Number
           Case Else
100             Call LogError("basMBOProgramReport", "toDateFromIntDay")
110        End Select
120        Resume Exit_label
      'DD Error Handler End

End Function

'---------------------------------------------------------------------------------------
' fProgramOfficialStartDatesExist
'---------------------------------------------------------------------------------------
' Only for Spring, Fall, Owling

Public Function fProgramOfficialStartDatesExist(ByVal intYearFirst As Integer, ByVal intYearLast As Integer) As Boolean

10    On Error GoTo Err_label

      Dim intSeason As Integer
      Dim strSeason As String
      Dim intYear As Integer
      Dim strWhere As String
      Dim strMessage As String
      Dim datStartDate As Date

20    strMessage = ""

      ' For Spring, Fall, Owling
      '     For each year
      '        If there is a program for the year x season
      '            Validate that the program has a start date

30    For intSeason = intSeasonFirst To intSeasonLast
40        If intSeason = conSpring Or intSeason = conFall Or intSeason = conOwling Then
50            strSeason = toStrSeasonFromIntSeason(intSeason)
60            For intYear = intYearFirst To intYearLast
70                strWhere = "[MonitoringProgramSeason] = '" & strSeason & "' AND [YearEx] = " & intYear
80                If DCount("[DateFrom]", "tblPrograms", strWhere) > 0 Then
90                   datStartDate = Nz(DLookup("[DateFrom]", "tblPrograms", strWhere))
100                  If datStartDate = 0 Then
110                      strMessage = strMessage & "Missing start date for " & strSeason & " " & intYear & vbCrLf
120                  End If
130               End If
140           Next
150       End If
160   Next

170   If strMessage = "" Then
180       fProgramOfficialStartDatesExist = True
190   Else
200       fProgramOfficialStartDatesExist = False
210       MsgBox strMessage, vbCritical, "MBO Report"
220   End If

      'DD Error Handler Start
Exit_label:
230        Exit Function
Err_label:
240        Select Case Err.Number
           Case Else
250             Call LogError("basMBOProgramReport", "fProgramOfficialStartDatesExist")
260        End Select
270        Resume Exit_label
      'DD Error Handler End

End Function

'---------------------------------------------------------------------------------------
' toDate2000
'---------------------------------------------------------------------------------------
 
Private Function toDate2000(ByVal datDate As Date, ByVal intSeason As Integer) As Date
10    On Error GoTo Err_label

20    If datDate <> 0 Then
30        If intSeason = conWinter Then
40            If Month(datDate) <= 6 Then
50                toDate2000 = DateSerial(2000, Month(datDate), Day(datDate))
60            Else
70                toDate2000 = DateSerial(1999, Month(datDate), Day(datDate))
80            End If
90        Else
100           toDate2000 = DateSerial(2000, Month(datDate), Day(datDate))
110       End If
120   Else
130       toDate2000 = 0
140   End If

      'DD Error Handler Start
Exit_label:
150        Exit Function
Err_label:
160        Select Case Err.Number
           Case Else
170             Call LogError("basMBOProgramReport", "toDate2000")
180        End Select
190        Resume Exit_label
      'DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' MBOProgramReportCountPeriods
'---------------------------------------------------------------------------------------
 
Public Sub MBOProgramReportPeriodsCount_Excel( _
    ByVal intYearFirst As Integer, _
    ByVal intYearLast As Integer, _
    ByVal strLocation As String, _
    ByRef oBook As Excel.Workbook)

10    On Error GoTo Err_label

      Dim strSQL As String
      Dim qdf As DAO.QueryDef
      Dim rst As DAO.Recordset
      Dim intYear As Integer
      Dim intPeriod As Integer
      Dim fld As Integer
      Dim intSeason As Integer
      Dim strSeason As String

20    SysCmd acSysCmdSetStatus, "Periods"
        
      Dim rowBase As Long
30    rowBase = 1

      Dim row As Long
      Dim col As Long

      Dim oSheet As Excel.Worksheet
40    Set oSheet = InsertSheet(oBook, "Global")
50    oSheet.Name = "Periods"

60    With oSheet

      ' Periods

70    .Cells(rowBase, 1) = "Periods"

80    For intSeason = conCaptureSeasonFirst To conCaptureSeasonLast
90        col = 2 + intSeason - conCaptureSeasonFirst
100       .Cells(rowBase, col) = toStrSeasonFromIntSeason(intSeason)
110   Next

120   For intYear = intYearFirst To intYearLast
130       row = 1 + intYear - intYearFirst + rowBase
140       .Cells(row, 1) = intYear
150   Next

160   For intSeason = conCaptureSeasonFirst To conCaptureSeasonLast
170       col = 2 + intSeason - conCaptureSeasonFirst
180       For intYear = intYearFirst To intYearLast
190           row = 1 + intYear - intYearFirst + rowBase
200           If intPeriodLast_SeasonYear(intSeason, intYear) = 0 Then
210               .Cells(row, col) = ""
220           Else
230               .Cells(row, col) = intPeriodLast_SeasonYear(intSeason, intYear)
240           End If
250       Next
260   Next

270   rowBase = row + 2

      ' Program ID

280   .Cells(rowBase, 1) = "Program ID"

290   For intSeason = conCaptureSeasonFirst To conCaptureSeasonLast
300       col = 2 + intSeason - conCaptureSeasonFirst
310       .Cells(rowBase, col) = toStrSeasonFromIntSeason(intSeason)
320   Next

330   For intYear = intYearFirst To intYearLast
340       row = 1 + intYear - intYearFirst + rowBase
350       .Cells(row, 1) = intYear
360   Next

370   For intSeason = conCaptureSeasonFirst To conCaptureSeasonLast
380       col = 2 + intSeason - conCaptureSeasonFirst
390       For intYear = intYearFirst To intYearLast
400           row = 1 + intYear - intYearFirst + rowBase
410           .Cells(row, col) = strProgram(intSeason, intYear)
420       Next
430   Next

440   rowBase = row + 2

      ' Official First Day of Program

450   .Cells(rowBase, 1) = "Official Start Date"

460   For intSeason = conCaptureSeasonFirst To conCaptureSeasonLast
470       col = 2 + intSeason - conCaptureSeasonFirst
480       .Cells(rowBase, col) = toStrSeasonFromIntSeason(intSeason)
490   Next

500   For intYear = intYearFirst To intYearLast
510       row = 1 + intYear - intYearFirst + rowBase
520       .Cells(row, 1) = intYear
530   Next


540   For intSeason = conCaptureSeasonFirst To conCaptureSeasonLast
550       col = 2 + intSeason - conCaptureSeasonFirst
560       For intYear = intYearFirst To intYearLast
570           row = 1 + intYear - intYearFirst + rowBase
580           If datProgramDateFirst_SeasonYear(intSeason, intYear) = 0 Then
590               .Cells(row, col) = ""
600           Else
610               .Cells(row, col) = datProgramOfficialStartDate_SeasonYear(intSeason, intYear)
620           End If
630       Next
640   Next

650   .range(.Cells(rowBase, 2), .Cells(row, 2 + intYearLast - intYearFirst)).NumberFormat = "dd mmm yyyy"

660   rowBase = row + 2

      ' Date of first DET sheet

670   .Cells(rowBase, 1) = "Date of first DET sheet"

680   For intSeason = conCaptureSeasonFirst To conCaptureSeasonLast
690       col = 2 + intSeason - conCaptureSeasonFirst
700       .Cells(rowBase, col) = toStrSeasonFromIntSeason(intSeason)
710   Next

720   For intYear = intYearFirst To intYearLast
730       row = 1 + intYear - intYearFirst + rowBase
740       .Cells(row, 1) = intYear
750   Next
760   row = row + 1
770   .Cells(row, 1) = "All years"
780   .Cells(row, 1).Font.Color = RGB(0, 176, 80) ' green

790   For intSeason = conCaptureSeasonFirst To conCaptureSeasonLast
800       col = 2 + intSeason - conCaptureSeasonFirst
810       For intYear = intYearFirst To intYearLast
820           row = 1 + intYear - intYearFirst + rowBase
830           If datProgramDateFirst_SeasonYear(intSeason, intYear) = 0 Then
840               .Cells(row, col) = ""
850           Else
860               .Cells(row, col) = datProgramDateFirst_SeasonYear(intSeason, intYear)
870               If datProgramDateFirst_SeasonYear(intSeason, intYear) < datProgramOfficialStartDate_SeasonYear(intSeason, intYear) Then
880                   .Cells(row, col).Font.Color = vbRed
890               End If
900           End If
910       Next
920       row = row + 1
930       If datProgramDateFirst_Season(intSeason) > 0 Then
940           .Cells(row, col) = datProgramDateFirst_Season(intSeason)
950           .Cells(row, col).Font.Color = RGB(0, 176, 80) ' green
960       End If
970   Next

980   .range(.Cells(rowBase, 2), .Cells(row - 1, 2 + intYearLast - intYearFirst)).NumberFormat = "dd mmm yyyy"
990   .range(.Cells(row, 2), .Cells(row, 2 + intYearLast - intYearFirst)).NumberFormat = "dd mmm"

1000  rowBase = row + 2

      ' Date of last DET sheet

1010  .Cells(rowBase, 1) = "Date of last DET sheet"

1020  For intSeason = conCaptureSeasonFirst To conCaptureSeasonLast
1030      col = 2 + intSeason - conCaptureSeasonFirst
1040      .Cells(rowBase, col) = toStrSeasonFromIntSeason(intSeason)
1050  Next

1060  For intYear = intYearFirst To intYearLast
1070      row = 1 + intYear - intYearFirst + rowBase
1080      .Cells(row, 1) = intYear
1090  Next
1100  row = row + 1
1110  .Cells(row, 1) = "All years"
1120  .Cells(row, 1).Font.Color = RGB(0, 176, 80) ' green

1130  For intSeason = conCaptureSeasonFirst To conCaptureSeasonLast
1140      col = 2 + intSeason - conCaptureSeasonFirst
1150      For intYear = intYearFirst To intYearLast
1160          row = 1 + intYear - intYearFirst + rowBase
1170          If datProgramDateFirst_SeasonYear(intSeason, intYear) = 0 Then
1180              .Cells(row, col) = ""
1190          Else
1200              .Cells(row, col) = datProgramDateLast_SeasonYear(intSeason, intYear)
1210          End If
1220      Next
1230      row = row + 1
1240      If datProgramDateLast_Season(intSeason) > 0 Then
1250          .Cells(row, col) = datProgramDateLast_Season(intSeason)
1260          .Cells(row, col).Font.Color = RGB(0, 176, 80) ' green
1270      End If
1280  Next

1290  .range(.Cells(rowBase, 2), .Cells(row - 1, 1 + intYearLast - intYearFirst)).NumberFormat = "dd mmm yyyy"
1300  .range(.Cells(row, 2), .Cells(row, 1 + intYearLast - intYearFirst)).NumberFormat = "dd mmm"

1310  rowBase = row + 2

      ' Days between first and last DET sheets

1320  .Cells(rowBase, 1) = "Days between first and last DET sheets"

1330  For intSeason = conCaptureSeasonFirst To conCaptureSeasonLast
1340      col = 2 + intSeason - conCaptureSeasonFirst
1350      .Cells(rowBase, col) = toStrSeasonFromIntSeason(intSeason)
1360  Next
1370  col = 3 + conCaptureSeasonLast - conCaptureSeasonFirst
1380  .Cells(rowBase, col) = "All seasons"

1390  For intYear = intYearFirst To intYearLast
1400      row = 1 + intYear - intYearFirst + rowBase
1410      .Cells(row, 1) = intYear
1420  Next
1430  row = row + 1
1440  .Cells(row, 1) = "All years (info for David)"
1450  .Cells(row, 1).Font.Color = RGB(0, 176, 80) ' green
1460  .Cells(row, 3 + conCaptureSeasonLast - conCaptureSeasonFirst) = intDayLast + 1
1470  .Cells(row, 3 + conCaptureSeasonLast - conCaptureSeasonFirst).Font.Color = RGB(0, 176, 80)

1480  For intSeason = conCaptureSeasonFirst To conCaptureSeasonLast
1490      col = 2 + intSeason - conCaptureSeasonFirst
1500      For intYear = intYearFirst To intYearLast
1510          row = 1 + intYear - intYearFirst + rowBase
1520          If intDayLast_SeasonYear(intSeason, intYear) = 0 Then
1530              If datProgramDateFirst_SeasonYear(intSeason, intYear) = 0 Then
1540                  .Cells(row, col) = ""
1550              Else
1560                  .Cells(row, col) = 0
1570              End If
1580          Else
1590              .Cells(row, col) = intDayLast_SeasonYear(intSeason, intYear) + 1
1600          End If
1610      Next
1620      row = row + 1
1630      If intDayLast_Season(intSeason) > 0 Then
1640          .Cells(row, col) = intDayLast_Season(intSeason) + 1
1650          .Cells(row, col).Font.Color = RGB(0, 176, 80) ' green
1660      End If
1670  Next

1680  .range(.columns(1), .columns(3 + conCaptureSeasonLast - conCaptureSeasonFirst)).HorizontalAlignment = xlCenter
1690  .range(.columns(1), .columns(3 + conCaptureSeasonLast - conCaptureSeasonFirst)).AutoFit

1700  End With

      'DD Error Handler Start
Exit_label:
1710       Exit Sub
Err_label:
1720       Select Case Err.Number
           Case Else
1730      Call LogError("basMBOProgramReport", "MBOProgramReportPeriodsCount")
1740       End Select
1750       Resume Exit_label
      'DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' MBOProgramReportPeriodsCount
'---------------------------------------------------------------------------------------
 
Public Sub MBOProgramReportPeriodsCount( _
    ByVal intYearFirst As Integer, _
    ByVal intYearLast As Integer, _
    ByVal strLocation As String)

10    On Error GoTo Err_label

      Dim strSQL As String
      Dim qdf As DAO.QueryDef
      Dim rst As DAO.Recordset
      Dim intYear As Integer
      Dim intPeriod As Integer
      Dim fld As Integer
      Dim intSeason As Integer
      Dim strSeason As String

20    SysCmd acSysCmdSetStatus, "Periods"
        
      ' Load strProgram
      ' Load datProgramOfficialStartDate_SeasonYear
      ' Load datProgramDateFirst_SeasonYear
      ' Load datProgramDateLast_SeasonYear
      '
      ' Load intPeriodLast_SeasonYear
      ' Load intCapturePeriodFirst_SeasonYear and intCapturePeriodLast_SeasonYear

30    ReDim strProgram(intSeasonFirst To intSeasonLast, intYearFirst To intYearLast) As String       ' strProgram(...) = "" iff program does not exist
40    ReDim datProgramOfficialStartDate_SeasonYear(intSeasonFirst To intSeasonLast, intYearFirst To intYearLast) As Date
50    ReDim datProgramDateFirst_SeasonYear(intSeasonFirst To intSeasonLast, intYearFirst To intYearLast) As Date
60    ReDim datProgramDateLast_SeasonYear(intSeasonFirst To intSeasonLast, intYearFirst To intYearLast) As Date

70    ReDim intPeriodLast_SeasonYear(intSeasonFirst To intSeasonLast, intYearFirst To intYearLast) As Integer
80    ReDim intCapturePeriodFirst_SeasonYear(intSeasonFirst To intSeasonLast, intYearFirst To intYearLast) As Integer
90    ReDim intCapturePeriodLast_SeasonYear(intSeasonFirst To intSeasonLast, intYearFirst To intYearLast) As Integer

100   For intSeason = intSeasonFirst To intSeasonLast
110       For intYear = intYearFirst To intYearLast
120           intPeriodLast_SeasonYear(intSeason, intYear) = 1
130       Next
140   Next

      Dim datStartDate As Date
      Dim datFirstDate As Date
      Dim datLastDate As Date
      Dim strWhere As String

150   For intSeason = intSeasonFirst To intSeasonLast
160       strSeason = toStrSeasonFromIntSeason(intSeason)
170       For intYear = intYearFirst To intYearLast
             
180             strWhere = "[YearEx] = " & intYear & " AND [MonitoringProgramSeason] = '" & strSeason & "'"
190             datProgramOfficialStartDate_SeasonYear(intSeason, intYear) = Nz(DLookup("DateFrom", "tblPrograms", strWhere))

200             strProgram(intSeason, intYear) = Nz(DLookup("Program", "tblPrograms", strWhere))
210             If strProgram(intSeason, intYear) = "" Then
220                 GoTo Next_SeasonYear_Label
230             End If

240             strWhere = "[Program] = '" & strProgram(intSeason, intYear) & "' AND [Location] = '" & strLocation & "'"
250             datProgramDateFirst_SeasonYear(intSeason, intYear) = Nz(DMin("DateEx", "tblDETDaily", strWhere))
260             datProgramDateLast_SeasonYear(intSeason, intYear) = Nz(DMax("DateEx", "tblDETDaily", strWhere))
                        
Next_SeasonYear_Label:
270       Next
280   Next

      ' Load intDayLast_SeasonYear(intSeasonFirst To intSeasonLast, intYearFirst To intYearLast)

290   ReDim intDayLast_SeasonYear(intSeasonFirst To intSeasonLast, intYearFirst To intYearLast)

      Dim datDateFirst As Date
      Dim datDateLast As Date

300   For intSeason = intSeasonFirst To intSeasonLast
310       For intYear = intYearFirst To intYearLast
320           datDateFirst = datProgramDateFirst_SeasonYear(intSeason, intYear)
330           datDateLast = datProgramDateLast_SeasonYear(intSeason, intYear)
340           If datDateFirst > 0 And datDateLast > 0 Then
350               intDayLast_SeasonYear(intSeason, intYear) = datDateLast - datDateFirst
360           End If
370       Next
380   Next

      ' Load datProgramDateFirst_Season(intSeasonFirst To intSeasonLast)

      Dim datMin As Date
      Dim datDate As Date

390   For intSeason = intSeasonFirst To intSeasonLast
400       datMin = DateSerial(2001, 1, 1)
410       For intYear = intYearFirst To intYearLast
420           datDate = datProgramDateFirst_SeasonYear(intSeason, intYear)
430           If datDate <> 0 Then
440               datDate = toDate2000(datDate, intSeason)
450               If datDate < datMin Then
460                   datMin = datDate
470               End If
480           End If
490           If Year(datMin) = 2001 Then
500               datProgramDateFirst_Season(intSeason) = 0
510           Else
520               datProgramDateFirst_Season(intSeason) = datMin
530           End If
540       Next
550   Next

      ' Load datProgramDateLast_Season(intSeasonFirst To intSeasonLast)

      Dim datMax As Date

560   For intSeason = intSeasonFirst To intSeasonLast
570       datMax = 0
580       For intYear = intYearFirst To intYearLast
590           datDate = datProgramDateLast_SeasonYear(intSeason, intYear)
600           If datDate <> 0 Then
610               datDate = toDate2000(datDate, intSeason)
620               If datDate > datMax Then
630                   datMax = datDate
640               End If
650           End If
660           If datMax = 0 Then
670               datProgramDateLast_Season(intSeason) = 0
680           Else
690               datProgramDateLast_Season(intSeason) = datMax
700           End If
710       Next
720   Next

      ' Load intDayLast_Season(intSeasonFirst To intSeasonLast)

      Dim datFirst As Date
      Dim datLast As Date

730   For intSeason = intSeasonFirst To intSeasonLast
740       datFirst = datProgramDateFirst_Season(intSeason)
750       datLast = datProgramDateLast_Season(intSeason)
760       If datFirst > 0 And datLast > 0 Then
770           intDayLast_Season(intSeason) = datLast - datFirst
780       End If
790   Next

      ' Load intDayLast

      Dim intMax As Integer
      Dim intDay As Integer

800   intMax = 0
810   For intSeason = intSeasonFirst To intSeasonLast
820       intDay = intDayLast_Season(intSeason)
830       If intDay > intMax Then
840           intMax = intDay
850       End If
860   Next
870   intDayLast = intMax


      ' Number of periods

880   For intSeason = intSeasonFirst To intSeasonLast
890       strSeason = toStrSeasonFromIntSeason(intSeason)
900       For intYear = intYearFirst To intYearLast
                       
910           Select Case intSeason
              Case conNonSeason
920               intPeriodLast_SeasonYear(intSeason, intYear) = 1
930           Case conWinter
940               intPeriodLast_SeasonYear(intSeason, intYear) = 5
950           Case conSpring, conFall, conOwling
960               If datProgramDateLast_SeasonYear(intSeason, intYear) <> 0 And _
                     datProgramOfficialStartDate_SeasonYear(intSeason, intYear) <> 0 And _
                     datProgramDateLast_SeasonYear(intSeason, intYear) >= datProgramOfficialStartDate_SeasonYear(intSeason, intYear) Then
970                   intPeriodLast_SeasonYear(intSeason, intYear) = Int((datProgramDateLast_SeasonYear(intSeason, intYear) - datProgramOfficialStartDate_SeasonYear(intSeason, intYear)) / 7) + 1
980             End If
981           Case conRTHU
982               intPeriodLast_SeasonYear(intSeason, intYear) = 1
990           Case conSummer, conNestbox, conSummerNestbox
1000              intPeriodLast_SeasonYear(intSeason, intYear) = 2
1010          End Select

1020      Next
1030  Next

1040  For intSeason = conCaptureSeasonFirst To conCaptureSeasonLast
1050      intPeriodLast_Season(intSeason) = 0
1060      For intYear = intYearFirst To intYearLast
1070          If intPeriodLast_Season(intSeason) < intPeriodLast_SeasonYear(intSeason, intYear) Then
1080              intPeriodLast_Season(intSeason) = intPeriodLast_SeasonYear(intSeason, intYear)
1090          End If
1100      Next
1110  Next

1120  intPeriodLast = 0
1130  For intSeason = conCaptureSeasonFirst To conCaptureSeasonLast
1140      For intYear = intYearFirst To intYearLast
1150          If intPeriodLast < intPeriodLast_SeasonYear(intSeason, intYear) Then
1160                intPeriodLast = intPeriodLast_SeasonYear(intSeason, intYear)
1170          End If
1180      Next
1190  Next

      ' Load intCapturePeriodFirst_SeasonYear(conSeasonFirst To conSeasonLast, intYearFirst To intYearLast) As Integer
      ' Load intCapturePeriodLast_SeasonYear(conSeasonFirst To conSeasonLast, intYearFirst To intYearLast) As Integer

1200  For intSeason = intSeasonFirst To intSeasonLast
1210      For intYear = intYearFirst To intYearLast
1220          If intSeason = conSpring Then
1230              If intYear <= 2006 Then
1240                  intCapturePeriodFirst_SeasonYear(intSeason, intYear) = 2
1250              Else
1260                  intCapturePeriodFirst_SeasonYear(intSeason, intYear) = 4
1270              End If
1280          Else
1290              intCapturePeriodFirst_SeasonYear(intSeason, intYear) = 1
1300          End If
1310          intCapturePeriodLast_SeasonYear(intSeason, intYear) = intPeriodLast_SeasonYear(intSeason, intYear)
1320      Next
1330  Next


      'DD Error Handler Start
Exit_label:
1340       Exit Sub
Err_label:
1350       Select Case Err.Number
           Case Else
1360      Call LogError("basMBOProgramReport", "MBOProgramReportPeriodsCount")
1370       End Select
1380       Resume Exit_label
      'DD Error Handler End
End Sub
'---------------------------------------------------------------------------------------
' FullNetCoverage
'

'---------------------------------------------------------------------------------------
 
'---------------------------------------------------------------------------------------
' FullNetCoverageDays
'---------------------------------------------------------------------------------------
' Called explicitly by the query: qryMBOProgramReport_SeasonYearPeriod_FullNetCoverage
'        implicitly by the query: qryMBOProgramReport_SeasonYearPeriod_FullNetCoverage_B
'
' Returns 1 if the day has full net coverage ( N.B. Full Net Coverage is only defined for Spring, Fall )
'
' Always returns 0 for Non-Season, Winter, Summer, Owling, RTHU

Public Function FullNetCoverageDays(ByVal strSeason As String, ByVal intYear As Integer, ByVal varNetHours As Variant) As Integer

10    On Error Resume Next

      Dim dblNetHours As Double
20    dblNetHours = Nz(varNetHours)

30    Select Case strSeason
      Case "Spring"
40        Select Case intYear
          Case 2005, 2006
50                FullNetCoverageDays = IIf(dblNetHours >= 60, 1, 0)      ' 13 nets
60        Case 2007
70            FullNetCoverageDays = IIf(dblNetHours >= 70, 1, 0)          ' 15 nets
80        Case Else
90            FullNetCoverageDays = IIf(dblNetHours >= 75, 1, 0)          ' 16 nets
100       End Select
110   Case "Fall"
120       Select Case intYear
          Case 2005
130           FullNetCoverageDays = IIf(dblNetHours >= 65, 1, 0)          ' 14 nets
140       Case 2006, 2007
150           FullNetCoverageDays = IIf(dblNetHours >= 70, 1, 0)          ' 15 nets
160       Case Else
170           FullNetCoverageDays = IIf(dblNetHours >= 75, 1, 0)          ' 16 nets
180       End Select
190   Case Else
200       FullNetCoverageDays = 0
210   End Select
          
End Function

'---------------------------------------------------------------------------------------
' toPeriod
'---------------------------------------------------------------------------------------

Public Function toPeriod(ByVal strSeason As Variant, ByVal datDateEx As Variant, ByVal datFrom As Variant) As Integer

10    On Error Resume Next

      Dim datDay   As Date
      Dim intYear  As Integer
      Dim intSeason As Integer
      
20    toPeriod = 1

30    intYear = Year(datDateEx)
40    intSeason = toIntSeasonFromStrSeason(strSeason)

50    Select Case strSeason
      Case "Winter"
60        Select Case Month(datDateEx)
          Case 7 To 11                          ' Jul - Nov
70            toPeriod = 1
80        Case 12
90            toPeriod = 2                      ' Dec
100       Case 1 To 3
110           toPeriod = 2 + Month(datDateEx)   ' Jan, Feb, Mar
120       Case Else
130           toPeriod = 5                      ' Apr - Jun
140       End Select
150   Case "Spring", "Fall", "Owling", "RTHU_Spring", "RTHU_Fall"
160       If datDateEx < datFrom Then
170           toPeriod = 1
180       Else
190           toPeriod = Int((datDateEx - datFrom) / 7) + 1
200       End If
210   Case "Summer", "Nestbox", "SummerNestbox"
220       Select Case Month(datDateEx)
          Case 1 To 6
230           toPeriod = 1
240       Case 7 To 12
250           toPeriod = 2
260       End Select
270   Case Else           ' includes "NonSeason"
280       toPeriod = 1
290   End Select

End Function

'---------------------------------------------------------------------------------------
' toIntSeasonFromStrSeason
'---------------------------------------------------------------------------------------
 
Public Function toIntSeasonFromStrSeason(ByVal strSeason As String) As Integer
10    On Error GoTo Err_label

20            Select Case strSeason
              Case "Winter"
30                toIntSeasonFromStrSeason = conWinter
40            Case "Spring"
50                toIntSeasonFromStrSeason = conSpring
60            Case "Summer"
70                 toIntSeasonFromStrSeason = conSummer
80            Case "Nestbox"
90                 toIntSeasonFromStrSeason = conNestbox
100           Case "Summer+Nestbox"
110                toIntSeasonFromStrSeason = conSummerNestbox
120           Case "Fall"
130                toIntSeasonFromStrSeason = conFall
140           Case "Owling"
150                toIntSeasonFromStrSeason = conOwling
160           Case "RTHU"
170                toIntSeasonFromStrSeason = conRTHU
180           Case Else
190                toIntSeasonFromStrSeason = conNonSeason
200           End Select

      'DD Error Handler Start
Exit_label:
210        Exit Function
Err_label:
220        Select Case Err.Number
           Case Else
230             Call LogError("basMBO10YearProgramReport", "toIntSeasonFromStrSeason")
240        End Select
250        Resume Exit_label
      'DD Error Handler End
End Function


'---------------------------------------------------------------------------------------
' toStrSeasonFromIntSeason
'---------------------------------------------------------------------------------------
 
Public Function toStrSeasonFromIntSeason(ByVal intSeason As String) As String
10    On Error GoTo Err_label

20            Select Case intSeason
              Case conWinter
30                toStrSeasonFromIntSeason = "Winter"
40            Case conSpring
50                toStrSeasonFromIntSeason = "Spring"
60            Case conSummer
70                 toStrSeasonFromIntSeason = "Summer"
80            Case conNestbox
90                 toStrSeasonFromIntSeason = "Nestbox"
100           Case conSummerNestbox
110                 toStrSeasonFromIntSeason = "Summer+Nestbox"
120           Case conFall
130                toStrSeasonFromIntSeason = "Fall"
140           Case conOwling
150                toStrSeasonFromIntSeason = "Owling"
160           Case conRTHU
170                toStrSeasonFromIntSeason = "RTHU"
180           Case Else
190                toStrSeasonFromIntSeason = "Non-Season"
200           End Select

      'DD Error Handler Start
Exit_label:
210        Exit Function
Err_label:
220        Select Case Err.Number
           Case Else
230             Call LogError("basMBO10YearProgramReport", "toStrSeasonFromIntSeason")
240        End Select
250        Resume Exit_label
      'DD Error Handler End
End Function

''---------------------------------------------------------------------------------------
'' ReportYear
''---------------------------------------------------------------------------------------
'
'Public Function ReportYear(ByVal YearEx As Integer, ByVal MonthEx As Integer, ByVal dayEx As Integer) As Integer
'      Dim intReportYear As Integer
'10       On Error GoTo Err_label
'
'20    intReportYear = YearEx
'30    If MonthEx = 10 Then
'40        If intReportYear < 2014 Then
'50            If dayEx = 31 Then
'60                ReportYear = intReportYear + 1
'70            End If
'80        End If
'90    ElseIf MonthEx = 11 Then
'100       If intReportYear < 2014 Then
'110           ReportYear = intReportYear + 1
'120       Else
'130           If dayEx >= 7 Then
'140               ReportYear = intReportYear + 1
'150           End If
'160       End If
'170   End If
'180   ReportYear = intReportYear
'
'          'DD Error Handler Start
'Exit_label:
'190       Exit Function
'Err_label:
'200       Select Case Err.Number
'          Case Else
'210            Call LogError("basMBOProgramReport", "ReportYear")
'220       End Select
'230       Resume Exit_label
'          ' DD Error Handler End
'
'End Function

'---------------------------------------------------------------------------------------
' ReportYear_EndDate
'---------------------------------------------------------------------------------------

Public Function ReportYear_EndDate(ByVal intReportYear As Integer) As Date
   On Error GoTo Err_label

If intReportYear <= 2014 Then
    ReportYear_EndDate = DateSerial(intReportYear, 10, 30)
Else
    ReportYear_EndDate = DateSerial(intReportYear, 11, 6)
End If

    'DD Error Handler Start
Exit_label:
    Exit Function
Err_label:
    Select Case Err.Number
    Case Else
         Call LogError("basMBOProgramReport", "ReportYear_EndDate")
    End Select
    Resume Exit_label
    ' DD Error Handler End
End Function
