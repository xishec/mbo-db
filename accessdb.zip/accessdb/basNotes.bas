Option Compare Database
Option Explicit

'---------------------------------------------------------------------------------------
' AnalyseNotes
'
' Scan Notes for <key>=<value> specifications
' Store the corresponding User Fields
' Display all User Fields in the read-only F textbox
'---------------------------------------------------------------------------------------
 
Public Sub AnalyseNotes(rst As DAO.Recordset)

10    On Error GoTo Err_label

      Dim uf As Integer

      Dim Notes As String
      Dim Species As String

20    Notes = Nz(rst("NotesForMBO"))
30    Species = Nz(rst("Species"))
         
40    If Notes = "" Then
50        Exit Sub
60    End If

      ' Delete spaces before "="

      Dim Notes2 As String
70    Do While True
80        Notes2 = Replace(Notes, " =", "=")
90        If Notes2 = Notes Then Exit Do
100       Notes = Notes2
110   Loop

      ' Delete spaces after "="

120   Do While True
130       Notes2 = Replace(Notes, "= ", "=")
140       If Notes2 = Notes Then Exit Do
150       Notes = Notes2
160   Loop

170   Notes = Replace(Notes, ",", " ")

180   rst.Edit

      Dim arr As Variant
190   arr = Split(Notes, " ")
      Dim n As Long
200   For n = LBound(arr) To UBound(arr)
          Dim posLeft As Long
          Dim posRight As Long
210       posLeft = InStr(arr(n), "=")
220       posRight = InStrRev(arr(n), "=")
          
230       If Not (posLeft > 0 And posRight > 0 And posLeft = posRight) Then GoTo Continue_label
          
          Dim key As String
240       key = Left(arr(n), posLeft - 1)
          Dim val As String
250       val = Mid(arr(n), posLeft + 1)
          
260       If Not (Len(key) > 0 And Len(val) > 0) Then GoTo Continue_label
              
          Dim UserFieldID As Long
          
270       UserFieldID = GetUserFieldIDFromAbbreviation(key)
280       If UserFieldID = 0 Then GoTo Continue_label
          
          Dim UserFieldAbbreviation As String
290       UserFieldAbbreviation = Nz(DLookup("UserFieldAbbreviation", "tblUserFields", "UserFieldID = " & UserFieldID))
300       If UserFieldAbbreviation = "" Then GoTo Continue_label
              
310       Call TranslateUserFieldAlternateValueToStandardValue(val, Species)
320       Call ConvertUserFieldValueToUppercaseUnlessSuppressed(val, UserFieldID, Species)
          
330       rst("F" & UserFieldID) = val

Continue_label:
340   Next n

      ' Update F

      Dim strF As String
350   strF = ""

360   For uf = 1 To conMaxUserField
370       UserFieldAbbreviation = _
              Nz(DLookup("UserFieldAbbreviation", _
                  "tblUserFields", _
                  "UserFieldID = " & uf))
380       val = Nz(rst("F" & uf))
390       If UserFieldAbbreviation <> "" And val <> "" Then
400           strF = strF & UserFieldAbbreviation & "=" & val & " "
410       End If
420   Next uf
430   rst("F") = strF

440   rst.Update

      'DD Error Handler Start
Exit_label:
450        Exit Sub
Err_label:
460        Select Case Err.Number
           Case Else
470             Call LogError("basNotes", "AnalyseNotes")
480        End Select
490        Resume Exit_label
      'DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' AnalyseNotes_CapturesEditOrDelete
'
' Scan Notes for <key>=<value> specifications
' Fill in the User Fields
' Fill in F
'---------------------------------------------------------------------------------------
 
Public Sub AnalyseNotes_CapturesEditOrDelete(ByRef frm As Form)

10    On Error GoTo Err_label

20    On Error GoTo Err_label

      Dim uf As Integer

      Dim Notes As String
      Dim Species As String

30    Notes = Nz(frm.Controls("NotesForMBO"))
40    Species = Nz(frm.Controls("Species"))
         
50    If Notes = "" Then
60        Exit Sub
70    End If

      ' Delete spaces before "="

      Dim Notes2 As String
80    Do While True
90        Notes2 = Replace(Notes, " =", "=")
100       If Notes2 = Notes Then Exit Do
110       Notes = Notes2
120   Loop

      ' Delete spaces after "="

130   Do While True
140       Notes2 = Replace(Notes, "= ", "=")
150       If Notes2 = Notes Then Exit Do
160       Notes = Notes2
170   Loop

180   Notes = Replace(Notes, ",", " ")

      Dim arr As Variant
190   arr = Split(Notes, " ")
      Dim n As Long
200   For n = LBound(arr) To UBound(arr)
          Dim posLeft As Long
          Dim posRight As Long
210       posLeft = InStr(arr(n), "=")
220       posRight = InStrRev(arr(n), "=")
          
230       If Not (posLeft > 0 And posRight > 0 And posLeft = posRight) Then GoTo Continue_label
          
          Dim key As String
240       key = Left(arr(n), posLeft - 1)
          Dim val As String
250       val = Mid(arr(n), posLeft + 1)
          
260       If Not (Len(key) > 0 And Len(val) > 0) Then GoTo Continue_label
              
          Dim UserFieldID As Long
          
270       UserFieldID = GetUserFieldIDFromAbbreviation(key)
280       If UserFieldID = 0 Then GoTo Continue_label
          
          Dim UserFieldAbbreviation As String
290       UserFieldAbbreviation = Nz(DLookup("UserFieldAbbreviation", "tblUserFields", "UserFieldID = " & UserFieldID))
300       If UserFieldAbbreviation = "" Then GoTo Continue_label
              
310       Call TranslateUserFieldAlternateValueToStandardValue(val, Species)
320       Call ConvertUserFieldValueToUppercaseUnlessSuppressed(val, UserFieldID, Species)
          
330       frm.Controls("F" & UserFieldID) = val

Continue_label:
340   Next n

      ' Update F

      Dim strF As String
350   strF = ""

360   For uf = 1 To conMaxUserField
370       UserFieldAbbreviation = _
              Nz(DLookup("UserFieldAbbreviation", _
                  "tblUserFields", _
                  "UserFieldID = " & uf))
380       val = Nz(frm.Controls("F" & uf))
390       If UserFieldAbbreviation <> "" And val <> "" Then
400           strF = strF & UserFieldAbbreviation & "=" & val & " "
410       End If
420   Next uf
430   frm.Controls("F") = strF

'DD Error Handler Start
Exit_label:
440        Exit Sub
Err_label:
450        Select Case Err.Number
     Case Else
460       Call LogError("basNotes", "AnalyseNotes_CapturesEditOrDelete")
470        End Select
480        Resume Exit_label
'DD Error Handler End


End Sub
