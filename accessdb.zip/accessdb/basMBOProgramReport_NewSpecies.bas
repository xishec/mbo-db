'---------------------------------------------------------------------------------------
' Module    : basMBOProgramReport_NewSpecies
' Author    : David Davey
'---------------------------------------------------------------------------------------

Option Compare Database
Option Explicit

Const conNonSeason As Integer = -1
Const conWinter  As Integer = 0
Const conSpring  As Integer = 1
Const conSummer  As Integer = 2
Const conFall    As Integer = 3
Const conOwling  As Integer = 4
Const conRTHU    As Integer = 5
Const conNestbox As Integer = 6
Const conSummerNestbox As Integer = 7

Const conSeasonFirst As Integer = -1
Const conSeasonLast As Integer = 6

'---------------------------------------------------------------------------------------
' MBOProgramReport_NewSpecies
'---------------------------------------------------------------------------------------
 
Public Sub MBOProgramReport_NewSpecies( _
    ByVal intYear As Integer, _
    ByVal strLocation As String, _
    ByRef oBook As Excel.Workbook)

10    On Error GoTo Err_label

      Dim oSheet As Excel.Worksheet
      Dim strSeason As String

20    Set oSheet = InsertSheet(oBook, "Global")
30    oSheet.Name = "New Species"

      Dim colBase As Long
40    colBase = 1

50          Call MBOProgramReport_NewSpecies_Statistic(intYear, strLocation, oBook, oSheet, "BND", colBase)
60          Call MBOProgramReport_NewSpecies_Statistic(intYear, strLocation, oBook, oSheet, "DET", colBase)
70          Call MBOProgramReport_NewSpecies_Statistic(intYear, strLocation, oBook, oSheet, "CAP", colBase)
80          Call MBOProgramReport_NewSpecies_Statistic(intYear, strLocation, oBook, oSheet, "DETCAP", colBase)

90          oSheet.Cells(1, 1) = "Please add 1 to New Banded and New Captured for ALFL"
100         oSheet.range(oSheet.Cells(1, 1), oSheet.Cells(1, 1)).HorizontalAlignment = xlLeft

      'Set oSheet = InsertSheet(oBook, "Global")
      'oSheet.Name = "New Species for season"

      Dim rowBase As Long
      Dim rowBaseStart As Long
      Dim rowBaseEnd As Long

110   rowBase = 3

      '      ' All Seasons
      '
      '140   rowBaseStart = rowBase
      '150   colBase = 1
      '160   Call MBOProgramReport_NewSpeciesForSeason(intYear, strLocation, oBook, oSheet, "BND", rowBase, colBase, "All Seasons")
      '170   rowBaseEnd = rowBase
      '
      '180   rowBase = rowBaseStart
      '190   colBase = 8
      '200   Call MBOProgramReport_NewSpeciesForSeason(intYear, strLocation, oBook, oSheet, "CAP", rowBase, colBase, "All Seasons")
      '210   If rowBase < rowBaseEnd Then rowBase = rowBaseEnd
      '
      '220   rowBaseStart = rowBase
      '230   colBase = 1
      '240   Call MBOProgramReport_NewSpeciesForSeason(intYear, strLocation, oBook, oSheet, "DET", rowBase, colBase, "All Seasons")
      '250   rowBaseEnd = rowBase
      '
      '260   rowBase = rowBaseStart
      '270   colBase = 8
      '280   Call MBOProgramReport_NewSpeciesForSeason(intYear, strLocation, oBook, oSheet, "DETCAP", rowBase, colBase, "All Seasons")
      '290   If rowBase < rowBaseEnd Then rowBase = rowBaseEnd

      ' Each season

      Dim intSeason As Integer
120   For intSeason = conSeasonFirst To conSeasonLast
130       strSeason = toStrSeasonFromIntSeason(intSeason)

140       Set oSheet = InsertSheet(oBook, strSeason)
150       oSheet.Name = strSeason & " New Species"
          
160       rowBase = 3
170       colBase = 1
180       Call MBOProgramReport_NewSpeciesForSeason(intYear, strLocation, oBook, oSheet, "BND", rowBase, colBase, strSeason)
'190       rowBaseEnd = rowBase
          
190       rowBase = 3
200       colBase = 8
210       Call MBOProgramReport_NewSpeciesForSeason(intYear, strLocation, oBook, oSheet, "DET", rowBase, colBase, strSeason)
'230       rowBaseEnd = rowBase
          
220       rowBase = 3
230       colBase = 15
240       Call MBOProgramReport_NewSpeciesForSeason(intYear, strLocation, oBook, oSheet, "CAP", rowBase, colBase, strSeason)
'270       If rowBase < rowBaseEnd Then rowBase = rowBaseEnd

250       rowBase = 3
260       colBase = 22
270       Call MBOProgramReport_NewSpeciesForSeason(intYear, strLocation, oBook, oSheet, "DETCAP", rowBase, colBase, strSeason)
'310       If rowBase < rowBaseEnd Then rowBase = rowBaseEnd

280       oSheet.Cells(1, 1) = "Please add, where required, 1 to New Banded and New Captured for ALFL"
290       oSheet.range(oSheet.Cells(1, 1), oSheet.Cells(1, 1)).HorizontalAlignment = xlLeft

300   Next

310   oSheet.Cells(1, 1) = "Please add, where required, 1 to New Banded and New Captured for ALFL"
320   oSheet.range(oSheet.Cells(1, 1), oSheet.Cells(1, 1)).HorizontalAlignment = xlLeft

330   SysCmd acSysCmdClearStatus

      'DD Error Handler Start
Exit_label:
340        Exit Sub
Err_label:
350        Select Case Err.Number
           Case Else
360       Call LogError("basMBOProgramReport_NewSpecies", "MBOProgramReport_NewSpecies")
370        End Select
380        Resume Exit_label
      'DD Error Handler End

End Sub

Public Sub MBOProgramReport_NewSpeciesForSeason( _
    ByVal intYearReport As Integer, _
    ByVal strLocation As String, _
    ByRef oBook As Excel.Workbook, _
    ByRef oSheet As Excel.Worksheet, _
    ByVal strStat As String, _
    ByRef rowBase As Long, _
    ByRef colBase As Long, _
    ByVal strSeasonReport As String)

10    On Error GoTo Err_label

      Dim row As Long
      Dim col As Long
      Dim dic As Scripting.Dictionary
      Dim strSpecies As String
      Dim lngCountSpecies As Long
      Dim lngCountSpecies_previous As Long
      Dim rst As DAO.Recordset
      Dim intYear As Integer
      Dim strSeason As String
      Dim strSpeciesEnglish As String
      Dim datDate As Date

20    Select Case strStat
      Case "BND"
30        SysCmd acSysCmdSetStatus, "New Species: " & strSeasonReport & " Banded"
40    Case "CAP"
50        SysCmd acSysCmdSetStatus, "New Species: " & strSeasonReport & " Captured"
60    Case "DET"
70        SysCmd acSysCmdSetStatus, "New Species: " & strSeasonReport & " DET"
80    Case "DETCAP"
90        SysCmd acSysCmdSetStatus, "New Species: " & strSeasonReport & " DET+Captured"
100   End Select

110   CurrentDb.Execute "DELETE * FROM tblMBOProgramReport_NewSpecies"


      Dim strSQL As String

120   If strSeasonReport = "All Seasons" Then
130       Select Case strStat
          Case "BND"
140           strSQL = "qryMBOProgramReport_NewSpecies_Banded_Append"
150       Case "CAP"
160           strSQL = "qryMBOProgramReport_NewSpecies_Captured_Append"
170       Case "DET"
180           strSQL = "qryMBOProgramReport_NewSpecies_DET_Append"
190       Case "DETCAP"
200           strSQL = "qryMBOProgramReport_NewSpecies_DETCAP_Append"
210       End Select
          
          Dim qdf As DAO.QueryDef
220       Set qdf = CurrentDb.QueryDefs(strSQL)
230       qdf.Parameters("argLocation").value = strLocation
240       qdf.Execute
250   Else
260       Select Case strStat
          Case "BND"
270           strSQL = "qryMBOProgramReport_NewSpecies_Banded_Season_Append"
280       Case "CAP"
290           strSQL = "qryMBOProgramReport_NewSpecies_Captured_Season_Append"
300       Case "DET"
310           strSQL = "qryMBOProgramReport_NewSpecies_DET_Season_Append"
320       Case "DETCAP"
330           strSQL = "qryMBOProgramReport_NewSpecies_DETCAP_Season_Append"
340       End Select
          

350       Set qdf = CurrentDb.QueryDefs(strSQL)
360       qdf.Parameters("argLocation").value = strLocation
370       qdf.Parameters("argSeason").value = strSeasonReport
380       qdf.Execute

390   End If

400   lngCountSpecies_previous = 0

410   Set dic = New Scripting.Dictionary

420   Set rst = CurrentDb.OpenRecordset("SELECT * FROM tblMBOProgramReport_NewSpecies ORDER BY DateEx", dbOpenDynaset)

430   Do While Not rst.EOF

440       strSpecies = Nz(rst("Species"))
          
450       If Not dic.Exists(strSpecies) Then
460           dic.Add strSpecies, strSpecies
470       End If
480       lngCountSpecies = CountSpeciesInDictionary(dic)

490       If lngCountSpecies <> lngCountSpecies_previous Then
500           rst.Edit
510           rst("CountSpecies") = lngCountSpecies
520           rst.Update
530       End If

540       lngCountSpecies_previous = lngCountSpecies
550       rst.MoveNext
560   Loop
570   rst.Close
580   Set rst = Nothing

      ' 600   Set rst = CurrentDb.OpenRecordset("SELECT * FROM tblMBOProgramReport_NewSpecies WHERE YearEx = " & intYearReport & " ORDER BY DateEx DESC, CountSpecies DESC", dbOpenDynaset)
590    Set rst = CurrentDb.OpenRecordset("SELECT * FROM tblMBOProgramReport_NewSpecies  ORDER BY DateEx DESC, CountSpecies DESC", dbOpenDynaset)

600   row = rowBase

610   With oSheet

      '630   .Cells(row, colBase) = strSeasonReport
620   .Cells(row, colBase + 0) = "Date"
630   .Cells(row, colBase + 1) = "Year"
640   .Cells(row, colBase + 2) = "Season"
650   .Cells(row, colBase + 3) = "Species"
660   .Cells(row, colBase + 4) = "English"
670   Select Case strStat
      Case "BND"
680       .Cells(row, colBase + 5) = "New Banded"
690   Case "CAP"
700       .Cells(row, colBase + 5) = "New Captured"
710   Case "DET"
720       .Cells(row, colBase + 5) = "New DET"
730   Case "DETCAP"
740       .Cells(row, colBase + 5) = "New DET or Captured"
750   End Select
760   row = row + 1

770   Do While Not rst.EOF
780       datDate = Nz(rst("DateEx"))
790       intYear = Nz(rst("YearEx"))
800       strSeason = Nz(rst("Season"))
810       strSpecies = Nz(rst("Species"))
820       strSpeciesEnglish = Nz(rst("SpeciesEnglish"))
830       lngCountSpecies = Nz(rst("CountSpecies"))
          
840       .Cells(row, colBase + 0) = datDate
850       If strSeason = "Winter" Then
860           .Cells(row, colBase + 1) = intYear - 1 & "-" & Right(intYear, 2)
870       Else
880           .Cells(row, colBase + 1) = intYear
890       End If
900       .Cells(row, colBase + 2) = strSeason
910       .Cells(row, colBase + 3) = strSpecies
920       .Cells(row, colBase + 4) = strSpeciesEnglish
930       If lngCountSpecies > 0 Then
940           .Cells(row, colBase + 5) = lngCountSpecies
950       End If
960       If intYear = intYearReport Then
970           .range(.Cells(row, colBase), .Cells(row, colBase + 5)).Interior.Color = RGB(215, 228, 188)
980       End If
990       row = row + 1

1000      rst.MoveNext
1010  Loop
1020  rst.Close
1030  Set rst = Nothing

1040  .range(.Cells(rowBase, colBase), .Cells(rowBase, colBase + 5)).Font.Bold = True
1050  .range(.columns(colBase + 0), .columns(colBase + 0)).NumberFormat = "dd mmm yyyy"
1060  .range(.columns(colBase + 1), .columns(colBase + 5)).HorizontalAlignment = xlCenter
1070  .range(.columns(colBase), .columns(colBase + 5)).AutoFit
1080  For col = colBase To colBase + 5
1090      .columns(col).ColumnWidth = .columns(col).ColumnWidth + 2
1100  Next

1110  .columns(colBase + 6).ColumnWidth = 3
1120  .range(.Cells(3, colBase + 6), .Cells(row - 1, colBase + 6)).Interior.Color = RGB(141, 180, 227) ' light blue

1130  rowBase = row + 1

      '1090  oSheet.Cells(1, 1) = "Please add, where required, 1 to New Banded and New Captured for ALFL"

1140  End With

      'DD Error Handler Start
Exit_label:
1150       Exit Sub
Err_label:
1160       Select Case Err.Number
           Case Else
1170      Call LogError("basMBOProgramReport_NewSpecies", "MBOProgramReport_NewSpeciesForSeason")
1180       End Select
1190       Resume Exit_label
      'DD Error Handler End

End Sub

Public Sub MBOProgramReport_NewSpecies_Statistic( _
    ByVal intYearReport As Integer, _
    ByVal strLocation As String, _
    ByRef oBook As Excel.Workbook, _
    ByRef oSheet As Excel.Worksheet, _
    ByVal strStat As String, _
    ByRef colBase As Long)

10    On Error GoTo Err_label

      Dim row As Long
      Dim col As Long
      Dim dic As Scripting.Dictionary
      Dim strSpecies As String
      Dim lngCountSpecies As Long
      Dim lngCountSpecies_previous As Long
      Dim rst As DAO.Recordset
      Dim intYear As Integer
      Dim strSeason As String
      Dim strSpeciesEnglish As String
      Dim datDate As Date

20    Select Case strStat
      Case "BND"
30        SysCmd acSysCmdSetStatus, "New Species: Banded"
40    Case "CAP"
50        SysCmd acSysCmdSetStatus, "New Species: Captured"
60    Case "DET"
70        SysCmd acSysCmdSetStatus, "New Species: DET"
80    Case "DETCAP"
90        SysCmd acSysCmdSetStatus, "New Species: DET+Captured"
100   End Select

110   CurrentDb.Execute "DELETE * FROM tblMBOProgramReport_NewSpecies"

      Dim strSQL As String
120   Select Case strStat
      Case "BND"
130       strSQL = "qryMBOProgramReport_NewSpecies_Banded_Append"
140   Case "CAP"
150       strSQL = "qryMBOProgramReport_NewSpecies_Captured_Append"
160   Case "DET"
170       strSQL = "qryMBOProgramReport_NewSpecies_DET_Append"
180   Case "DETCAP"
190       strSQL = "qryMBOProgramReport_NewSpecies_DETCAP_Append"
200   End Select

      Dim qdf As DAO.QueryDef
210   Set qdf = CurrentDb.QueryDefs(strSQL)
220   qdf.Parameters("argLocation").value = strLocation
230   qdf.Execute

240   lngCountSpecies_previous = 0

250   Set dic = New Scripting.Dictionary

260   Set rst = CurrentDb.OpenRecordset("SELECT * FROM tblMBOProgramReport_NewSpecies ORDER BY DateEx", dbOpenDynaset)

270   Do While Not rst.EOF

280       strSpecies = Nz(rst("Species"))
          
290       If Not dic.Exists(strSpecies) Then
300           dic.Add strSpecies, strSpecies
310       End If
320       lngCountSpecies = CountSpeciesInDictionary(dic)

330       If lngCountSpecies <> lngCountSpecies_previous Then
340           rst.Edit
350           rst("CountSpecies") = lngCountSpecies
360           rst.Update
370       End If

380       lngCountSpecies_previous = lngCountSpecies
390       rst.MoveNext
400   Loop
410   rst.Close
420   Set rst = Nothing

430   Set rst = CurrentDb.OpenRecordset("SELECT * FROM tblMBOProgramReport_NewSpecies ORDER BY DateEx DESC, CountSpecies DESC", dbOpenDynaset)

440   row = 3

450   With oSheet

460   .Cells(row, colBase) = "Date"
470   .Cells(row, colBase + 1) = "Year"
480   .Cells(row, colBase + 2) = "Season"
490   .Cells(row, colBase + 3) = "Species"
500   .Cells(row, colBase + 4) = "English"
510   Select Case strStat
      Case "BND"
520       .Cells(row, colBase + 5) = "New Banded"
530   Case "CAP"
540       .Cells(row, colBase + 5) = "New Captured"
550   Case "DET"
560       .Cells(row, colBase + 5) = "New DET"
570   Case "DETCAP"
580       .Cells(row, colBase + 5) = "New DET or Captured"
590   End Select
600   row = row + 1

610   Do While Not rst.EOF
620       datDate = Nz(rst("DateEx"))
630       intYear = Nz(rst("YearEx"))
640       strSeason = Nz(rst("Season"))
650       strSpecies = Nz(rst("Species"))
660       strSpeciesEnglish = Nz(rst("SpeciesEnglish"))
670       lngCountSpecies = Nz(rst("CountSpecies"))
          
680       .Cells(row, colBase) = datDate
690       .Cells(row, colBase + 1) = intYear
700       If intYear = intYearReport Then
710     .range(.Cells(row, colBase), .Cells(row, colBase + 5)).Interior.Color = RGB(215, 228, 188)
720       End If
730       .Cells(row, colBase + 2) = strSeason
740       .Cells(row, colBase + 3) = strSpecies
750       .Cells(row, colBase + 4) = strSpeciesEnglish
760       If lngCountSpecies > 0 Then
770     .Cells(row, colBase + 5) = lngCountSpecies
780       End If
790       row = row + 1

800       rst.MoveNext
810   Loop
820   rst.Close
830   Set rst = Nothing

840   .range(.Cells(3, colBase), .Cells(3, colBase + 5)).Font.Bold = True
850   .range(.columns(colBase), .columns(colBase)).NumberFormat = "dd mmm yyyy"
860   .range(.columns(colBase), .columns(colBase + 5)).HorizontalAlignment = xlCenter
870   .range(.columns(colBase), .columns(colBase + 5)).AutoFit
880   For col = colBase To colBase + 5
890       .columns(col).ColumnWidth = .columns(col).ColumnWidth + 2
900   Next

      ' Separate the statistics by a coloured column

910   If colBase > 1 Then
920       .range(.Cells(3, colBase - 1), .Cells(row - 1, colBase - 1)).Interior.Color = RGB(141, 180, 227) ' light blue
930   End If
940   .columns(colBase + 6).ColumnWidth = 3
950   .range(.Cells(3, colBase + 6), .Cells(row - 1, colBase + 6)).Interior.Color = RGB(141, 180, 227) ' light blue


960   colBase = colBase + 7

970   End With

      'DD Error Handler Start
Exit_label:
980        Exit Sub
Err_label:
990        Select Case Err.Number
           Case Else
1000      Call LogError("basMBOProgramReport_NewSpecies", "MBOProgramReport_NewSpecies_Statistic")
1010       End Select
1020       Resume Exit_label
      'DD Error Handler End

End Sub
