Option Compare Database
Option Explicit


'---------------------------------------------------------------------------------------
' Rep_Documents
'---------------------------------------------------------------------------------------

Public Function Rep_Documents() As String
10    On Error GoTo Err_label
      Dim WshShell As Variant
20    Set WshShell = CreateObject("WScript.Shell")
30    Rep_Documents = WshShell.SpecialFolders("MyDocuments")

          'DD Error Handler Start
Exit_label:
40        Exit Function
Err_label:
50        Select Case Err.Number
          Case Else
60             Call LogError("basRep_Documents", "Rep_Documents_2")
70        End Select
80        Resume Exit_label
          ' DD Error Handler End
End Function

Public Function Rep_Documents_Test()
Debug.Print Rep_Documents
End Function






' This document entitled � VBA/VB6 - My Documents + Environment Variables
' � from Kioskea (en.kioskea.net) is made available under the Creative Commons license.
' You can copy, modify copies of this page, under the conditions stipulated
' by the license, as this note appears clearly.


'Private Type SHITEMID
'    cb As Long
'    abID As Byte
'End Type
'Private Type ITEMIDLIST
'    mkid As SHITEMID
'End Type
'Private Const CSIDL_PERSONAL As Long = &H5
'Private Declare Function SHGetSpecialFolderLocation Lib "Shell32.dll" _
'                        (ByVal hWndOwner As Long, ByVal nFolder As Long, _
'                         pidl As ITEMIDLIST) As Long
'Private Declare Function SHGetPathFromIDList Lib "Shell32.dll" Alias "SHGetPathFromIDListA" _
'                        (ByVal pidl As Long, ByVal pszPath As String) As Long

'Private Const CSIDL_PERSONAL As Long = &H5
'#If VBA7 Then
'    Private Type SHITEMID
'        cb As LongPtr
'        abID As Byte
'    End Type
'    Private Declare PtrSafe Function SHGetSpecialFolderLocation Lib _
'            "shell32.dll" (ByVal hwndOwner As LongPtr, ByVal nFolder As Long, _
'                           pidl As ITEMIDLIST) As LongPtr
'    Private Declare PtrSafe Function SHGetPathFromIDList Lib "shell32.dll" Alias "SHGetPathFromIDListA" _
'        (ByVal pidl As LongPtr, ByVal pszPath As String) As Boolean
'
'#Else
'    Private Type SHITEMID
'        cb As Long
'        abID As Byte
'    End Type
'    Private Declare Function SHGetSpecialFolderLocation Lib _
'        "shell32.dll" (ByVal hwndOwner As Long, ByVal nFolder As Long, _
'                       pidl As ITEMIDLIST) As Long
'    Private Declare Function SHGetPathFromIDList Lib "shell32.dll" Alias "SHGetPathFromIDListA" _
'                                             (ByVal pidl As Long, ByVal pszPath As String) As Boolean
'
'#End If
'Private Type ITEMIDLIST
'    mkid As SHITEMID
'End Type
'
'
'
''---------------------------------------------------------------------------------------
'' Rep_Documents
''---------------------------------------------------------------------------------------
'
'Public Function Rep_Documents() As String
'          Dim lRet As Long, IDL As ITEMIDLIST, sPath As String
'10    On Error GoTo Err_label
'
'20        lRet = SHGetSpecialFolderLocation(100&, CSIDL_PERSONAL, IDL)
'30        If lRet = 0 Then
'40            sPath = String$(512, chr$(0))
'50            lRet = SHGetPathFromIDList(ByVal IDL.mkid.cb, ByVal sPath)
'60            Rep_Documents = Left$(sPath, InStr(sPath, chr$(0)) - 1)
'70        Else
'80            Rep_Documents = vbNullString
'90        End If
'
'      'DD Error Handler Start
'Exit_label:
'100        Exit Function
'Err_label:
'110        Select Case Err.Number
'           Case Else
'120       Call LogError("basRep_Documents", "Rep_Documents")
'130        End Select
'140        Resume Exit_label
'      'DD Error Handler End
'End Function
'
