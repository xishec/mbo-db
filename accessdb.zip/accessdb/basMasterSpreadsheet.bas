'---------------------------------------------------------------------------------------
' Module    : basMasterSpreadsheet
' Author    : David Davey
'---------------------------------------------------------------------------------------

Option Compare Database
Option Explicit

Const conDebug As Boolean = False

Const conRecorded As Integer = 0    ' if DET > 0, then Recorded = DET, otherwise Recorded = Captured
Const conDET As Integer = 1
Const conBND As Integer = 2
Const conRET As Integer = 3
Const conREP As Integer = 4
Const conAlien As Integer = 5
Const conReplacement As Integer = 6
Const conStatFirst As Integer = 0
Const conStatLast As Integer = 5

Const conCountBirds As Integer = 1
Const conCountSpecies As Integer = 2
Const conNewSeasonSpecies As Integer = 3
Const conCumulativeSeasonBirds As Integer = 4
Const conCumulativeSeasonSpecies As Integer = 5
Const conNewYearSpecies As Integer = 6
Const conCumulativeYearBirds As Integer = 7
Const conCumulativeYearSpecies As Integer = 8
Const conCumulativeSiteBirds As Integer = 9
Const conNewSiteSpecies As Integer = 10
Const conCumulativeSiteSpecies As Integer = 11
Const conCumulativeSeasonNetHours As Integer = 12
Const conCumulativeYearNetHours As Integer = 13
Const conCumulativeSiteNetHours As Integer = 14

Const conDaily As Integer = 1
Const conSeason As Integer = 2
Const conYear As Integer = 3
Const conSite As Integer = 4

Const colReportYear As Integer = 1
Const colYear As Integer = 2
Const colMonth As Integer = 3
Const colDay As Integer = 4
Const colProgram As Integer = 5
Const colSeason As Integer = 6
Const colPeriod As Integer = 7

Private colFLD(conStatLast - conStatFirst + 1, 20) As Integer
Private colNetHours(conStatLast - conStatFirst + 1) As Integer
Private colBirdsPer100NetHours(conStatLast - conStatFirst + 1) As Integer

Private intFirstYearInReport As Integer
Private strSeasonText As String
Private CountBirds(conStatFirst To conStatLast) As Long
Private CumulativeBirds(conStatFirst To conStatLast, conDaily To conSite) As Long
Private CumulativeSpecies(conStatFirst To conStatLast, conDaily To conSite) As Long
Private CumulativeNetHours(conDaily To conSite) As Double
Private dicCumulativeSpecies(conStatFirst To conStatLast, conDaily To conSite) As Scripting.Dictionary
Private CumulativeBirdsBandedInNets(conDaily To conSite) As Long

Private CountSpecies As Long
Private CumulativeSpeciesPrevious(conStatFirst To conStatLast, conDaily To conSite) As Long
Private NewSpecies(conStatFirst To conStatLast, conDaily To conSite) As Long

''---------------------------------------------------------------------------------------
'' MasterSpreadsheet_v2
''---------------------------------------------------------------------------------------
'
'Public Sub MasterSpreadsheet_v2(ByVal strLocation As String)
'10    On Error GoTo Err_label
'
'20    Call MasterSpreadsheet_v2_GenerateData(strLocation)
'30    Call MasterSpreadsheet_v2_Export(strLocation)
'
'      'DD Error Handler Start
'Exit_label:
'40         Exit Sub
'Err_label:
'50         Select Case Err.Number
'           Case Else
'60              Call LogError("basMasterSpreadsheet", "MasterSpreadsheet_v2")
'70         End Select
'80         Resume Exit_label
'      'DD Error Handler End
'End Sub

'---------------------------------------------------------------------------------------
' Load_tblDETSpecies_Recorded_Temp
'
' tblDETSpecies_Recorded_Temp is identical to tblDETSpecies, but with an extra Recorded column
'---------------------------------------------------------------------------------------

Private Sub Load_tblDETSpecies_Recorded_Temp()

      Dim strSQL As String
      Dim qdf As DAO.QueryDef

10       On Error GoTo Err_label

20    strSQL = "DELETE * FROM tblDETSpecies_Recorded_Temp"
30    CurrentDb.Execute strSQL

40    Set qdf = CurrentDb.QueryDefs("qryDETSpecies_Recorded_Append")
50    qdf.Execute

          'DD Error Handler Start
Exit_label:
60        Exit Sub
Err_label:
70        Select Case Err.Number
          Case Else
80             Call LogError("basMasterSpreadsheet", "Load_tblDETSpecies_Recorded_Temp")
90        End Select
100       Resume Exit_label
          ' DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' MasterSpreadsheet_v2_GenerateData
'---------------------------------------------------------------------------------------
 
Public Sub MasterSpreadsheet_v2_GenerateData(ByVal strLocation As String)

10    On Error GoTo Err_label

          Dim strSQL As String
          Dim qdf As QueryDef
          Dim rstDaily As DAO.Recordset
          Dim rstSpecies As DAO.Recordset
          Dim strWhere As String
          Dim fld As Integer
          Dim level As Integer
          Dim strSpecies As String
          Dim lngBirds As Long
           
20    SysCmd acSysCmdSetStatus, "Generate the recorded data"
                    
30    Call Load_tblDETSpecies_Recorded_Temp

40    SysCmd acSysCmdClearStatus

      ' Allocate the dictionaries

50    For fld = conStatFirst To conStatLast
60        For level = conDaily To conSite
70            Set dicCumulativeSpecies(fld, level) = New Scripting.Dictionary
80        Next
90    Next

      ' tblMasterSpreadsheet_Daily - a temporary table
      ' ==============================================
      ' DateEx                      Primary Key
      ' SeasonNr  0=Winter, ...     Primary Key
      ' Season    Winter, ...
      ' Program
      ' Period
      ' NetHours
      ' Row_Season              Row in the By Season worksheet
      ' Row_Year                Row in the By Year and Site worksheet
      ' Row_Season_ReportYear   Row in the By Season x Report Year worksheet
      ' ReportYear
      ' TotalSeasonNetHours
      ' TotalYearNetHours
      ' TotalSiteNetHours
      ' BirdsBandedInNets
      ' TotalSeasonBirdsBandedInNets
      ' TotalYearBirdsBandedInNets
      ' TotalSiteBirdsBandedInNets

      ' tblMasterSpreadsheet_Level - a temporary table
      ' ==============================================
      ' DateEx                                                  Primary Key
      ' Program
      ' FLD                                                     Primary Key
      ' SeasonNr                                                Primary Key
      ' Birds     Count birds this day+season+FLD
      ' Species   Count species this day+season+FLD
      ' TotalSeasonBirds
      ' SeasonNewSpecies
      ' TotalSeasonNewSpecies
      ' TotalYearBirds
      ' YearNewSpecies
      ' TotalYearNewSpecies
      ' TotalSiteBirds
      ' SiteNewSpecies
      ' TotalNewSpecies
      ' Row_Year
      ' Row_Season
      ' Row_Season_ReportYear
      ' ReportYear

      ' ZAP tblMasterSpreadsheet_Daily and tblMasterSpreadsheet_Level

100   strSQL = "DELETE * FROM tblMasterSpreadsheet_Daily"
110   CurrentDb.Execute strSQL
120   strSQL = "DELETE * FROM tblMasterSpreadsheet_Level"
130   CurrentDb.Execute strSQL

      Dim rstMaster As DAO.Recordset
140   Set rstMaster = CurrentDb.OpenRecordset("tblMasterSpreadsheet_Daily", dbOpenDynaset)

      Dim rstLevel As DAO.Recordset
150   Set rstLevel = CurrentDb.OpenRecordset("tblMasterSpreadsheet_Level", dbOpenDynaset)

      ' qryMasterSpreadsheetDaily_v2
      ' ----------------------------
      ' tblDETDaily x tblPrograms
      ' DateEx
      ' Program
      ' YearEx
      ' Season = MonitoringProgram
      ' DateFrom
      ' SongBirdNets
      ' Location = [argLocation]

160   Set qdf = CurrentDb.QueryDefs("qryMasterSpreadsheetDaily_v2")
170   qdf.Parameters("argLocation").value = strLocation
180   Set rstDaily = qdf.OpenRecordset

190   rstDaily.MoveLast
200   SysCmd acSysCmdInitMeter, "Generate Daily", rstDaily.RecordCount
210   rstDaily.MoveFirst

      Dim datDateEx
      Dim intReportYear As Integer
      Dim strSeason As String
      Dim dblNetHours As Double
      Dim strProgram As String
      Dim intYear As Integer
      Dim intMonth As Integer
      Dim intDay As Integer
      Dim datDateStartOfSeason As Date
      Dim intPeriod As Integer
      Dim intSeason As Integer

      Dim n As Long

      ' loop over each day

220   n = 1
230   Do While Not rstDaily.EOF

240     If conDebug And n = 500 Then Exit Do
        
          ' Update the progress bar every 100 records
          
250       If CLng(n / 100) * 100 = n Then
260           SysCmd acSysCmdUpdateMeter, n
270       DoEvents
280       End If

290       n = n + 1
          
300       datDateEx = Nz(rstDaily("DateEx"))
310       intReportYear = Nz(rstDaily("YearEx"))
320       strSeason = Nz(rstDaily("Season"))
330       dblNetHours = Nz(rstDaily("SongBirdNets"))
340       strProgram = Nz(rstDaily("Program"))
350       datDateStartOfSeason = Nz(rstDaily("DateFrom"))
360       strProgram = Nz(rstDaily("Program"))
          
370       intYear = Year(datDateEx)
380       intMonth = Month(datDateEx)
390       intDay = Day(datDateEx)
          
400       Select Case strSeason
          Case "Winter"
410           intSeason = 0
420       Case "Spring2004"
430           intSeason = 1
440       Case "Spring"
450           intSeason = 2
460       Case "Summer"
470           intSeason = 3
480       Case "Nestbox"
490           intSeason = 4
500       Case "Fall2004"
510           intSeason = 5
520       Case "Fall"
530           intSeason = 6
540       Case "Owling"
550           intSeason = 7
560       Case Else
570           intSeason = 8
580       End Select

590       Select Case strSeason
          Case "Winter"
600           intPeriod = IIf(intYear = intReportYear, 2, 1)
610       Case "Summer", "Owling"
620           intPeriod = 1
630       Case "Spring", "Fall"
640           intPeriod = Int((datDateEx - datDateStartOfSeason) / 7) + 1
650       Case Else
660           intPeriod = 1
670       End Select

          ' Reset the daily sets of pseudo-species
          
680       For fld = conStatFirst To conStatLast
690           dicCumulativeSpecies(fld, conDaily).RemoveAll
700       Next

          ' For each statistic, count the birds and the species
            
          Dim lngStat(conStatFirst To conStatLast) As Long    ' Statistics for a pseudospecies for one day
          
710       For fld = conStatFirst To conStatLast
720           CountBirds(fld) = 0                     ' Statistics for one day
730       Next
              
740       strSQL = "SELECT * FROM tblDETSpecies_Recorded_Temp  WHERE " & _
              " [DateEx] = #" & Format(datDateEx, "mm/dd/yyyy") & "# AND " & _
              " [Location] = '" & strLocation & "' AND " & _
              " [Program] = '" & strProgram & "'"
750       Set rstSpecies = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)

          ' Loop over the psuedospecies for one day
          
760       Do While Not rstSpecies.EOF
          
770           strSpecies = Nz(rstSpecies("Species"))
          
780           For fld = conStatFirst To conStatLast
       
790               lngStat(fld) = Nz(rstSpecies(toFieldnameFLD(fld)))

800           Next
              
810           For fld = conStatFirst To conStatLast
820               If lngStat(fld) > 0 Then
830                   CountBirds(fld) = CountBirds(fld) + lngStat(fld)
840                   If Not dicCumulativeSpecies(fld, conDaily).Exists(strSpecies) Then
850                       Call dicCumulativeSpecies(fld, conDaily).Add(strSpecies, strSpecies)
860                   End If
870               End If
880           Next

890           rstSpecies.MoveNext
900       Loop
910       rstSpecies.Close
920       Set rstSpecies = Nothing

          ' Add a record to tblMasterSpreadsheet_Daily
                   
930       rstMaster.AddNew
940       rstMaster("DateEx") = datDateEx
950       rstMaster("SeasonNr") = intSeason
960       rstMaster("Season") = strSeason
970       rstMaster("Period") = intPeriod
980       rstMaster("NetHours") = dblNetHours
990       rstMaster("Program") = strProgram
          
1000      If strSeason = "Winter" Then
1010        If Month(datDateEx) <= 6 Then
1020            rstMaster("ReportYear") = Year(datDateEx)
1030        Else
1040            rstMaster("ReportYear") = Year(datDateEx) + 1
1050        End If
1060      Else
1070        rstMaster("ReportYear") = Year(datDateEx)
1080      End If
1090      rstMaster.Update
          
          ' For each field, add a record to tblMasterSpreadsheet_Level
          
1100      For fld = conStatFirst To conStatLast
          
1110          rstLevel.AddNew
1120          rstLevel("DateEx") = datDateEx
1130          rstLevel("SeasonNr") = intSeason
1140          rstLevel("Program") = strProgram
1150          rstLevel("FLD") = fld
             
1160          If strSeason = "Winter" Then
1170              If Month(datDateEx) <= 6 Then
1180                  rstLevel("ReportYear") = Year(datDateEx)
1190              Else
1200              rstLevel("ReportYear") = Year(datDateEx) + 1
1210              End If
1220          Else
1230              rstLevel("ReportYear") = Year(datDateEx)
1240          End If

1250          rstLevel("Birds") = CountBirds(fld)

              ' How many true species are in each dictionary ?
                  
1260          CumulativeSpecies(fld, conDaily) = _
                  CountSpeciesInDictionary(dicCumulativeSpecies(fld, conDaily))
                                
1270          If CumulativeSpecies(fld, conDaily) <> 0 Then
1280              rstLevel("Species") = CumulativeSpecies(fld, conDaily)
1290          End If
                  
1300          rstLevel.Update
                  
label_next_FLD:
1310          Next
          
      ' 1180      End If

1320      rstDaily.MoveNext
1330  Loop
1340  rstDaily.Close
1350  Set rstDaily = Nothing

1360  rstMaster.Close
1370  Set rstMaster = Nothing
1380  rstLevel.Close
1390  Set rstLevel = Nothing

      'Remove the progress bar

1400  SysCmd acSysCmdRemoveMeter

      ' Copy Birds Banded from Level to Daily, excluding Nestbox (SeasonNr = 4)

      ' qryMasterSpreadsheet_Copy_Banded
      ' --------------------------------
      ' tblMasterSpreadsheet_Daily x tblMasterSpreadsheet_Level
      ' WHERE SeasonNr <> 4
      ' WHERE FLD = 2
      ' UPDATE tblMasterSpreadsheet_Daily.BirdsBandedInNets = tblMasterSpreadsheet_Level.Birds

1410  Set qdf = CurrentDb.QueryDefs("qryMasterSpreadsheet_Copy_Banded")
1420  qdf.Execute

      ' --------------------------
      ' Add the Year and Site data
      ' --------------------------

      Dim row As Long
1430  row = 3

      '   Process Net Hours
      '   -----------------
      '   In tblMasterSpreadsheet_Daily
      '   Fill in the cumulative net hours for calendar year
      '   Fill in the cumulative net hours for the site
      '   Fill in the row year column. The row years are numbered consecutively starting from 3
      '   Fill in the cumulative birds banded in nets for calendar year
      '   Fill in the cumulative birds banded in nets for the site

1440  CumulativeNetHours(conYear) = 0
1450  CumulativeNetHours(conSite) = 0
1460  CumulativeBirdsBandedInNets(conYear) = 0
1470  CumulativeBirdsBandedInNets(conSite) = 0

1480  strSQL = _
          "SELECT * FROM tblMasterSpreadsheet_Daily " & _
          "ORDER BY DateEx, SeasonNr"
1490  Set rstMaster = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)

1500  rstMaster.MoveLast
1510  SysCmd acSysCmdInitMeter, "Generate Year and Site - Net Hours", rstMaster.RecordCount
1520  rstMaster.MoveFirst

      Dim intYearPrevious  As Integer
1530  intYearPrevious = -1

1540  n = 0
1550  Do While Not rstMaster.EOF

          ' Update the progress bar every 100 records
          
1560      n = n + 1
1570      If CLng(n / 100) * 100 = n Then
1580          SysCmd acSysCmdUpdateMeter, n
1590          DoEvents
1600      End If
          
1610      datDateEx = Nz(rstMaster("DateEx"))
1620      intYear = Year(datDateEx)

1630      If intYear <> intYearPrevious Then
1640          CumulativeNetHours(conYear) = 0
1650          CumulativeBirdsBandedInNets(conYear) = 0
1660          intYearPrevious = intYear
1670      End If

          Dim lngBirdsBandedInNets As Long

1680      dblNetHours = Nz(rstMaster("NetHours"))
1690      lngBirdsBandedInNets = Nz(rstMaster("BirdsBandedInNets"))
1700      CumulativeNetHours(conYear) = CumulativeNetHours(conYear) + dblNetHours
1710      CumulativeNetHours(conSite) = CumulativeNetHours(conSite) + dblNetHours
1720      CumulativeBirdsBandedInNets(conYear) = CumulativeBirdsBandedInNets(conYear) + lngBirdsBandedInNets
1730      CumulativeBirdsBandedInNets(conSite) = CumulativeBirdsBandedInNets(conSite) + lngBirdsBandedInNets
          
1740      rstMaster.Edit
1750      rstMaster("Row_Year") = row
1760      row = row + 1
1770      rstMaster("TotalYearNetHours") = CumulativeNetHours(conYear)
1780      rstMaster("TotalSiteNetHours") = CumulativeNetHours(conSite)
1790      rstMaster("TotalYearBirdsBandedInNets") = CumulativeBirdsBandedInNets(conYear)
1800      rstMaster("TotalSiteBirdsBandedInNets") = CumulativeBirdsBandedInNets(conSite)
1810      rstMaster.Update

1820      rstMaster.MoveNext
1830  Loop
1840  rstMaster.Close
1850  Set rstMaster = Nothing

      ' Process Birds and Species
      ' -------------------------
      ' In tblMasterSpreadsheet_Level
      '    TotalYearBirds
      '    TotalSiteBirds
      '    YearNewSpecies
      '    SiteNewSpecies
      '    TotalYearNewSpecies
      '    TotalSiteNewSpecies
      '
1860  For fld = conStatFirst To conStatLast
1870      CumulativeBirds(fld, conSite) = 0
1880      CumulativeSpecies(fld, conSite) = 0
1890      dicCumulativeSpecies(fld, conSite).RemoveAll
1900      CumulativeSpeciesPrevious(fld, conSite) = 0
1910  Next

1920  strSQL = _
          "SELECT * FROM tblMasterSpreadsheet_Level " & _
          "ORDER BY DateEx, SeasonNr, FLD"
1930  Set rstLevel = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)

1940  rstLevel.MoveLast
1950  SysCmd acSysCmdInitMeter, "Generate Year and Site - Birds and Species", rstLevel.RecordCount
1960  rstLevel.MoveFirst

      Dim datDateExPrevious As Date
      Dim intSeasonPrevious As Integer

1970  intYearPrevious = -1
1980  datDateExPrevious = DateSerial(1900, 1, 1)
1990  intSeasonPrevious = -1

      ' Dim row As Long

2000  n = 0
2010  Do While Not rstLevel.EOF
2020      n = n + 1
          
          ' Update the progress bar every 100 records
          
2030      If CLng(n / 100) * 100 = n Then
2040          SysCmd acSysCmdUpdateMeter, n
2050          DoEvents
2060      End If
          
2070      datDateEx = Nz(rstLevel("DateEx"))
2080      intYear = Year(datDateEx)
2090      intSeason = Nz(rstLevel("SeasonNr"))
2100      strProgram = Nz(rstLevel("Program"))
              
2110      If intYear <> intYearPrevious Then
          
              ' Year control break
          
2120          For fld = conStatFirst To conStatLast
2130              CumulativeBirds(fld, conYear) = 0
2140              CumulativeSpecies(fld, conYear) = 0
2150              dicCumulativeSpecies(fld, conYear).RemoveAll
2160              CumulativeSpeciesPrevious(fld, conYear) = 0
2170          Next
              
2180          intYearPrevious = intYear
              
2190      End If
          
2200      fld = Nz(rstLevel("FLD"))
2210      lngBirds = Nz(rstLevel("Birds"))

          ' Process birds
          
2220      lngBirds = Nz(rstLevel("Birds"))
2230      CumulativeBirds(fld, conYear) = CumulativeBirds(fld, conYear) + lngBirds
2240      CumulativeBirds(fld, conSite) = CumulativeBirds(fld, conSite) + lngBirds

          ' Process species
          
      '    Dim strSpecies As String
      '    Dim strSQL As String
      '    Dim rstSpecies As DAO.Recordset

2250      strSQL = "SELECT * FROM tblDETSpecies_Recorded_Temp WHERE " & _
              "[DateEx] = #" & Format(datDateEx, "mm/dd/yyyy") & "# AND " & _
              "[Location] = '" & strLocation & "' AND " & _
              "[Program] = '" & strProgram & "' AND " & _
              "[" & toFieldnameFLD(fld) & "] > 0"

2260      Set rstSpecies = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)
          
2270      Do While Not rstSpecies.EOF
2280          strSpecies = rstSpecies("Species")
                     
2290          For level = conYear To conSite
2300              If Not dicCumulativeSpecies(fld, level).Exists(strSpecies) Then
2310                  Call dicCumulativeSpecies(fld, level).Add(strSpecies, strSpecies)
2320              End If
2330          Next

2340          rstSpecies.MoveNext
2350      Loop
2360      rstSpecies.Close
2370      Set rstSpecies = Nothing
                
      '   How many true species are in each dictionary ?

2380      For level = conYear To conSite
2390          CumulativeSpecies(fld, level) = _
                  CountSpeciesInDictionary(dicCumulativeSpecies(fld, level))
2400      Next
          
2410      For level = conYear To conSite
2420          NewSpecies(fld, level) = _
                  CumulativeSpecies(fld, level) - CumulativeSpeciesPrevious(fld, level)
2430          CumulativeSpeciesPrevious(fld, level) = CumulativeSpecies(fld, level)
2440      Next
          
2450      rstLevel.Edit
2460      rstLevel("TotalYearBirds") = CumulativeBirds(fld, conYear)
2470      rstLevel("TotalSiteBirds") = CumulativeBirds(fld, conSite)
2480      rstLevel("YearNewSpecies") = NewSpecies(fld, conYear)
2490      rstLevel("SiteNewSpecies") = NewSpecies(fld, conSite)
2500      rstLevel("TotalYearNewSpecies") = CumulativeSpecies(fld, conYear)
2510      rstLevel("TotalSiteNewSpecies") = CumulativeSpecies(fld, conSite)
2520      rstLevel.Update
       
2530      rstLevel.MoveNext
2540  Loop
2550  rstLevel.Close
2560  Set rstLevel = Nothing

      ' --------------------------
      ' Add the Season data
      ' --------------------------

      ' Dim row As Long
2570  row = 3

      '   Process Net Hours

2580  CumulativeNetHours(conSeason) = 0
2590  CumulativeBirdsBandedInNets(conSeason) = 0

2600  strSQL = _
          "SELECT * FROM tblMasterSpreadsheet_Daily " & _
          "ORDER BY ReportYear, SeasonNr, DateEx"
2610  Set rstMaster = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)

2620  rstMaster.MoveLast
2630  SysCmd acSysCmdInitMeter, "Generate Season - Net Hours", rstMaster.RecordCount
2640  rstMaster.MoveFirst

      Dim intReportYearPrevious  As Integer
2650  intReportYearPrevious = -1
      ' Dim intSeasonPrevious As Integer
2660  intSeasonPrevious = -1

2670  n = 0
2680  Do While Not rstMaster.EOF

          ' Update the progress bar every 100 records
          
2690      n = n + 1
2700      If CLng(n / 100) * 100 = n Then
2710          SysCmd acSysCmdUpdateMeter, n
2720          DoEvents
2730      End If
          
2740      datDateEx = Nz(rstMaster("DateEx"))
2750      intReportYear = Nz(rstMaster("ReportYear"))
2760      intSeason = Nz(rstMaster("SeasonNr"))

2770      If intReportYear <> intReportYearPrevious Or intSeason <> intSeasonPrevious Then
2780          CumulativeNetHours(conSeason) = 0
2790          CumulativeBirdsBandedInNets(conSeason) = 0
2800          intReportYearPrevious = intReportYear
2810          intSeasonPrevious = intSeason
2820      End If

2830      dblNetHours = Nz(rstMaster("NetHours"))
2840      lngBirdsBandedInNets = Nz(rstMaster("BirdsBandedInNets"))
2850      CumulativeNetHours(conSeason) = CumulativeNetHours(conSeason) + dblNetHours
2860      CumulativeBirdsBandedInNets(conSeason) = CumulativeBirdsBandedInNets(conSeason) + lngBirdsBandedInNets
          

2870      rstMaster.Edit
2880      rstMaster("Row_Season") = row
2890      row = row + 1
2900      rstMaster("TotalSeasonNetHours") = CumulativeNetHours(conSeason)
2910      rstMaster("TotalSeasonBirdsBandedInNets") = CumulativeBirdsBandedInNets(conSeason)
2920      rstMaster.Update

2930      rstMaster.MoveNext
2940  Loop
2950  rstMaster.Close
2960  Set rstMaster = Nothing

      ' Process Birds and Species
            
2970  For fld = conStatFirst To conStatLast
2980      CumulativeBirds(fld, conSeason) = 0
2990      CumulativeSpecies(fld, conSeason) = 0
3000      dicCumulativeSpecies(fld, conSeason).RemoveAll
3010      CumulativeSpeciesPrevious(fld, conSeason) = 0
3020  Next

3030  strSQL = _
          "SELECT * FROM tblMasterSpreadsheet_Level " & _
          "ORDER BY ReportYear, SeasonNr, DateEx"
3040  Set rstLevel = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)

3050  rstLevel.MoveLast
3060  SysCmd acSysCmdInitMeter, "Generate Season - Birds and Species", rstLevel.RecordCount
3070  rstLevel.MoveFirst

3080  intReportYearPrevious = -1
3090  intSeasonPrevious = -1

      ' Dim row As Long

3100  n = 0
3110  Do While Not rstLevel.EOF
3120      n = n + 1
          
          ' Update the progress bar every 100 records
          
3130      If CLng(n / 100) * 100 = n Then
3140          SysCmd acSysCmdUpdateMeter, n
3150          DoEvents
3160      End If
          
3170      datDateEx = Nz(rstLevel("DateEx"))
3180      intReportYear = Nz(rstLevel("ReportYear"))
3190      intSeason = Nz(rstLevel("SeasonNr"))
3200      strProgram = Nz(rstLevel("Program"))
              
3210      If intReportYear <> intReportYearPrevious Or intSeason <> intSeasonPrevious Then
          
3220          For fld = conStatFirst To conStatLast
3230              CumulativeBirds(fld, conSeason) = 0
3240              CumulativeSpecies(fld, conSeason) = 0
3250              dicCumulativeSpecies(fld, conSeason).RemoveAll
3260              CumulativeSpeciesPrevious(fld, conSeason) = 0
3270          Next
3280          intReportYearPrevious = intReportYear
3290          intSeasonPrevious = intSeason
              
3300      End If
          
3310      fld = Nz(rstLevel("FLD"))

          ' Process birds
          
3320      lngBirds = Nz(rstLevel("Birds"))
3330      CumulativeBirds(fld, conSeason) = CumulativeBirds(fld, conSeason) + lngBirds

          ' Process species
          
      '    Dim strSpecies As String
      '    Dim strSQL As String
      '    Dim rstSpecies As DAO.Recordset

3340      strSQL = "SELECT * FROM tblDETSpecies_Recorded_Temp WHERE " & _
              "[DateEx] = #" & Format(datDateEx, "mm/dd/yyyy") & "# AND " & _
              "[Location] = '" & strLocation & "' AND " & _
              "[Program] = '" & strProgram & "' AND " & _
              "[" & toFieldnameFLD(fld) & "] > 0"
3350      Set rstSpecies = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)
          
3360      Do While Not rstSpecies.EOF
3370          strSpecies = rstSpecies("Species")
                     
3380          If Not dicCumulativeSpecies(fld, conSeason).Exists(strSpecies) Then
3390              Call dicCumulativeSpecies(fld, conSeason).Add(strSpecies, strSpecies)
3400          End If

3410          rstSpecies.MoveNext
3420      Loop
3430      rstSpecies.Close
3440      Set rstSpecies = Nothing
                
      '   How many true species are in each dictionary ?

3450      CumulativeSpecies(fld, conSeason) = _
                CountSpeciesInDictionary(dicCumulativeSpecies(fld, conSeason))

3460      NewSpecies(fld, conSeason) = _
                CumulativeSpecies(fld, conSeason) - CumulativeSpeciesPrevious(fld, conSeason)
3470      CumulativeSpeciesPrevious(fld, conSeason) = CumulativeSpecies(fld, conSeason)

          
3480      rstLevel.Edit
3490      rstLevel("TotalSeasonBirds") = CumulativeBirds(fld, conSeason)
3500       rstLevel("SeasonNewSpecies") = NewSpecies(fld, conSeason)
3510      rstLevel("TotalSeasonNewSpecies") = CumulativeSpecies(fld, conSeason)
3520      rstLevel.Update
       
3530      rstLevel.MoveNext
3540  Loop
3550  rstLevel.Close
3560  Set rstLevel = Nothing

      'Remove the progress bar
3570  SysCmd acSysCmdRemoveMeter

      ' Fill in row numbers for Season x Report Year

3580  strSQL = _
          "SELECT * FROM tblMasterSpreadsheet_Daily " & _
          "ORDER BY SeasonNr, DateEx"
3590  Set rstMaster = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)

3600  rstMaster.MoveLast
3610  SysCmd acSysCmdInitMeter, "Generate row numbers for the Season x Report Year worksheet", rstMaster.RecordCount
3620  rstMaster.MoveFirst
3630  row = 3
3640  n = 0
3650  Do While Not rstMaster.EOF
3660      n = n + 1
          
          ' Update the progress bar every 100 records
          
3670      If CLng(n / 100) * 100 = n Then
3680          SysCmd acSysCmdUpdateMeter, n
3690          DoEvents
3700      End If

3710      rstMaster.Edit
3720      rstMaster("Row_Season_ReportYear") = row
3730      rstMaster.Update
3740      row = row + 1

3750      rstMaster.MoveNext
3760  Loop
3770  rstMaster.Close
3780  Set rstMaster = Nothing

      'Remove the progress bar
3790  SysCmd acSysCmdRemoveMeter

      ' Copy Row_Year, Row_Season and Row_Season_ReportYear columns from tblMasterSpreadsheet_Daily to tblMasterSpreadsheet_Level

3800  Set qdf = CurrentDb.QueryDefs("qryMasterSpreadsheet_Copy_Rows")
3810  qdf.Execute

      'DD Error Handler Start
Exit_label:
3820       Exit Sub
Err_label:
3830       Select Case Err.Number
           Case Else
3840      Call LogError("basMasterSpreadsheet", "MasterSpreadsheet_v2_GenerateData")
3850       End Select
3860       Resume Exit_label
      'DD Error Handler End

End Sub


'---------------------------------------------------------------------------------------
' MasterSpreadsheet_v2_Export_SeasonSheet
'---------------------------------------------------------------------------------------
 
Public Sub MasterSpreadsheet_v2_Export_SeasonSheet( _
    ByVal strLocation As String, _
    ByRef oExcel As Excel.Application, _
    ByRef oBook As Excel.Workbook)
          
      Dim oSheet As Excel.Worksheet
      Dim colEnd As Integer
      Dim fld As Integer
      Dim strSQL As String

10    On Error GoTo Err_label

20    Set oSheet = oBook.Worksheets.Add(After:=oBook.Worksheets(oBook.Worksheets.count))
30    oSheet.Name = "Master by Season"
40    With oSheet

50    Call InitialiseColumns
60    colEnd = colBirdsPer100NetHours(conSite)

70    With .Cells.Font
80        .Name = "Arial"
90        .Size = 8
100   End With

110   .Cells.HorizontalAlignment = xlCenter

      ' Write the header row #1

120   .Cells(1, colFLD(conRecorded, conCountSpecies)) = "RECORDED (DET if DET>0; Captures if DET=0)"
130   .Cells(1, colFLD(conDET, conCountSpecies)) = "DET"
140   .Cells(1, colFLD(conBND, conCountBirds)) = "BANDED"
150   .Cells(1, colFLD(conRET, conCountBirds)) = "RETURN"
160   .Cells(1, colFLD(conREP, conCountBirds)) = "REPEAT"
170   .Cells(1, colFLD(conAlien, conCountBirds)) = "ALIEN"
180   .Cells(1, colNetHours(conDaily)) = "TOTAL NET HOURS"
190   .Cells(1, colBirdsPer100NetHours(conDaily)) = "BIRDS BND per 100 NET HRS"

200   .range(.Cells(1, colFLD(conRecorded, conCountSpecies)), .Cells(1, colFLD(conRecorded, conCumulativeSiteSpecies))).Merge
210   .range(.Cells(1, colFLD(conDET, conCountSpecies)), .Cells(1, colFLD(conDET, conCumulativeSiteSpecies))).Merge
220   .range(.Cells(1, colFLD(conBND, conCountBirds)), .Cells(1, colFLD(conBND, conCumulativeSiteSpecies))).Merge
230   .range(.Cells(1, colFLD(conRET, conCountBirds)), .Cells(1, colFLD(conRET, conCumulativeSiteSpecies))).Merge
240   .range(.Cells(1, colFLD(conREP, conCountBirds)), .Cells(1, colFLD(conREP, conCumulativeSiteSpecies))).Merge
250   .range(.Cells(1, colFLD(conAlien, conCountBirds)), .Cells(1, colFLD(conAlien, conCumulativeSiteSpecies))).Merge
260   .range(.Cells(1, colNetHours(conDaily)), .Cells(1, colNetHours(conSite))).Merge
270   .range(.Cells(1, colBirdsPer100NetHours(conDaily)), .Cells(1, colBirdsPer100NetHours(conSite))).Merge

280   With .range(.Cells(1, 1), .Cells(1, colEnd)).Borders(xlEdgeBottom)
290       .LineStyle = xlContinuous
300       .Weight = xlThin
310   End With

320   For fld = conStatFirst To conStatLast
330       With .Cells(1, colFLD(fld, conCumulativeSiteSpecies)).Borders(xlEdgeRight)
340           .LineStyle = xlContinuous
350           .Weight = xlThin
360       End With
370   Next

380   With .Cells(1, colNetHours(conSite)).Borders(xlEdgeRight)
390       .LineStyle = xlContinuous
400       .Weight = xlThin
410   End With

420   With .Cells(1, colBirdsPer100NetHours(conSite)).Borders(xlEdgeRight)
430       .LineStyle = xlContinuous
440       .Weight = xlThin
450   End With

      ' Write the header row #2

460   .Cells(2, colReportYear) = "Report" & vbCrLf & "Year"
470   .Cells(2, colYear) = "Year"
480   .Cells(2, colMonth) = "Month"
490   .Cells(2, colDay) = "Day"
500   .Cells(2, colProgram) = "Program"
510   .Cells(2, colSeason) = "Season"
520   .Cells(2, colPeriod) = "Week"

530   For fld = conStatFirst To conStatLast
540       .Cells(2, colFLD(fld, conCountBirds)) = "# individuals"
550       .Cells(2, colFLD(fld, conCumulativeSeasonBirds)) = "TOTAL" & vbLf & "SEASON" & vbLf & "IND"
560       .Cells(2, colFLD(fld, conCumulativeYearBirds)) = "TOTAL" & vbLf & "YEAR" & vbLf & "IND"
570       .Cells(2, colFLD(fld, conCumulativeSiteBirds)) = "TOTAL" & vbLf & "SITE" & vbLf & "IND"
580   Next
590   For fld = conStatFirst To conStatLast
600       .Cells(2, colFLD(fld, conCountSpecies)) = "# species"
610       .Cells(2, colFLD(fld, conNewSeasonSpecies)) = "NEW" & vbLf & "SEASON" & vbLf & "SPP"
620       .Cells(2, colFLD(fld, conCumulativeSeasonSpecies)) = "TOTAL" & vbLf & "SEASON" & vbLf & "SPP"
630       .Cells(2, colFLD(fld, conNewYearSpecies)) = "NEW" & vbLf & "YEAR" & vbLf & "SPP"
640       .Cells(2, colFLD(fld, conCumulativeYearSpecies)) = "TOTAL" & vbLf & "YEAR" & vbLf & "SPP"
650       .Cells(2, colFLD(fld, conNewSiteSpecies)) = "NEW" & vbLf & "SITE" & vbLf & "SPP"
660       .Cells(2, colFLD(fld, conCumulativeSiteSpecies)) = "TOTAL" & vbLf & "SITE" & vbLf & "SPP"
670   Next

680   .Cells(2, colNetHours(conDaily)) = "DAILY"
690   .Cells(2, colNetHours(conSeason)) = "SEASON"
700   .Cells(2, colNetHours(conYear)) = "YEAR"
710   .Cells(2, colNetHours(conSite)) = "SITE"
720   .Cells(2, colBirdsPer100NetHours(conDaily)) = "DAILY"
730   .Cells(2, colBirdsPer100NetHours(conSeason)) = "SEASON"
740   .Cells(2, colBirdsPer100NetHours(conYear)) = "YEAR"
750   .Cells(2, colBirdsPer100NetHours(conSite)) = "SITE"

760   .range(.Cells(2, 1), .Cells(1, colFLD(conAlien, conCumulativeSiteSpecies))).WrapText = True

770   With .range(.Cells(2, 1), .Cells(2, colEnd)).Borders(xlEdgeBottom)
780       .LineStyle = xlContinuous
790       .Weight = xlThin
800   End With
          
      ' initialise

      Dim rowStart As Long
      Dim row As Long
810   rowStart = 3
820   row = rowStart

      Dim rstMaster As DAO.Recordset

830   strSQL = "SELECT * FROM tblMasterSpreadsheet_Daily ORDER BY ReportYear, SeasonNr, DateEx"
840   Set rstMaster = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)

850   rstMaster.MoveLast
860   SysCmd acSysCmdInitMeter, "Export Season - Net Hours", rstMaster.RecordCount
870   rstMaster.MoveFirst

      Dim datDateEx
      Dim intReportYear As Integer
      Dim strSeason As String
      Dim intSeasonNr As Integer
      Dim dblNetHours As Double
      Dim strProgram As String
      Dim intYear As Integer
      Dim intMonth As Integer
      Dim intDay As Integer
      Dim datStartOfSeason As Date
      Dim intPeriod As Integer

      Dim intSeasonNrPrevious As Integer
      Dim strSeasonPrevious As String
      Dim intPeriodPrevious As Integer

      Dim lngBirds As Long
      Dim lngSpecies As Long
      Dim lngTotalSeasonBirds As Long
      Dim lngSeasonNewSpecies As Long
      Dim lngTotalSeasonNewSpecies As Long
      Dim lngTotalYearBirds As Long
      Dim lngYearNewSpecies As Long
      Dim lngTotalYearNewSpecies As Long
      Dim lngTotalSiteBirds As Long
      Dim lngSiteNewSpecies As Long
      Dim lngTotalSiteNewSpecies As Long
      Dim lngRow_Year As Long

      Dim rowEnd As Long
880   rowEnd = -1

890   intSeasonNrPrevious = -1
900   intPeriodPrevious = -1

      Dim n As Long
910   n = 1
920   Do While Not rstMaster.EOF
          
          ' Update the progress bar every 100 records
          
930       If CLng(n / 100) * 100 = n Then
940           SysCmd acSysCmdUpdateMeter, n
950       DoEvents
960       End If
970       n = n + 1
          
980       datDateEx = Nz(rstMaster("DateEx"))
990       strSeason = Nz(rstMaster("Season"))
1000      intPeriod = Nz(rstMaster("Period"))
1010      strProgram = Nz(rstMaster("Program"))
1020      intSeasonNr = Nz(rstMaster("SeasonNr"))
1030      intReportYear = Nz(rstMaster("ReportYear"))

1040      intYear = Year(datDateEx)
1050      intMonth = Month(datDateEx)
1060      intDay = Day(datDateEx)
          
1070      row = Nz(rstMaster("Row_Season"))
1080      If row > rowEnd Then rowEnd = row
          
      ' Period control break

1090      If (intPeriodPrevious <> intPeriod) Or (intSeasonNrPrevious <> intSeasonNr) Then
1100          With .range(.Cells(row, 1), .Cells(row, colEnd)).Borders(xlEdgeTop)
1110              .LineStyle = xlContinuous
1120              .Weight = xlThin
1130          End With
1140          intPeriodPrevious = intPeriod
1150      End If

      ' Season control break

1160      If (intSeasonNrPrevious <> intSeasonNr) And row <> 3 Then
1170          With .range(.Cells(row, 1), .Cells(row, colEnd)).Borders(xlEdgeTop)
1180              .LineStyle = xlContinuous
1190              .Weight = xlMedium
1200              .Color = vbRed
1210          End With
1220      End If
1230      intSeasonNrPrevious = intSeasonNr

1240      .Cells(row, colReportYear) = intReportYear
1250      .Cells(row, colYear) = intYear
1260      .Cells(row, colMonth) = intMonth
1270      .Cells(row, colDay) = intDay
1280      .Cells(row, colProgram) = strProgram
1290      .Cells(row, colSeason) = strSeason
          
1300      If strSeason = "Spring" Or strSeason = "Fall" Then
1310          .Cells(row, colPeriod) = intPeriod
1320      End If
          
1330      Call ProcessNetHours(oSheet, row, rstMaster, datDateEx, strProgram)
          
1340      rstMaster.MoveNext
1350  Loop
1360  rstMaster.Close
1370  Set rstMaster = Nothing

      Dim rstLevel As DAO.Recordset
1380  Set rstLevel = CurrentDb.OpenRecordset("tblMasterSpreadsheet_Level", dbOpenDynaset)

1390  rstLevel.MoveLast
1400  SysCmd acSysCmdInitMeter, "Export Year and Site - Birds and Species", rstLevel.RecordCount
1410  rstLevel.MoveFirst

1420  Do While Not rstLevel.EOF
1430      row = Nz(rstLevel("Row_Season"))
1440      fld = Nz(rstLevel("FLD"))

1450          lngBirds = Nz(rstLevel("Birds"))
1460          lngSpecies = Nz(rstLevel("Species"))
1470          lngTotalSeasonBirds = Nz(rstLevel("TotalSeasonBirds"))
1480          lngSeasonNewSpecies = Nz(rstLevel("SeasonNewSpecies"))
1490          lngTotalSeasonNewSpecies = Nz(rstLevel("TotalSeasonNewSpecies"))
1500          lngTotalYearBirds = Nz(rstLevel("TotalYearBirds"))
1510          lngYearNewSpecies = Nz(rstLevel("YearNewSpecies"))
1520          lngTotalYearNewSpecies = Nz(rstLevel("TotalYearNewSpecies"))
1530          lngTotalSiteBirds = Nz(rstLevel("TotalSiteBirds"))
1540          lngSiteNewSpecies = Nz(rstLevel("SiteNewSpecies"))
1550          lngTotalSiteNewSpecies = Nz(rstLevel("TotalSiteNewSpecies"))
                      
1560          If lngBirds <> 0 Then
1570              .Cells(row, colFLD(fld, conCountBirds)) = lngBirds
1580          End If
              
1590          If lngSpecies <> 0 Then
1600              .Cells(row, colFLD(fld, conCountSpecies)) = lngSpecies
1610          End If
              
1620          .Cells(row, colFLD(fld, conCumulativeSeasonBirds)) = lngTotalSeasonBirds
              
1630          If lngSeasonNewSpecies <> 0 Then
1640              .Cells(row, colFLD(fld, conNewSeasonSpecies)) = lngSeasonNewSpecies
1650          End If
              
1660          .Cells(row, colFLD(fld, conCumulativeSeasonSpecies)) = lngTotalSeasonNewSpecies
          
1670          .Cells(row, colFLD(fld, conCumulativeYearBirds)) = lngTotalYearBirds
              
1680          If lngYearNewSpecies <> 0 Then
1690              .Cells(row, colFLD(fld, conNewYearSpecies)) = lngYearNewSpecies
1700          End If
              
1710          .Cells(row, colFLD(fld, conCumulativeYearSpecies)) = lngTotalYearNewSpecies
          
1720          .Cells(row, colFLD(fld, conCumulativeSiteBirds)) = lngTotalSiteBirds
              
1730          If lngSiteNewSpecies <> 0 Then
1740              .Cells(row, colFLD(fld, conNewSiteSpecies)) = lngSiteNewSpecies
1750          End If
              
1760          .Cells(row, colFLD(fld, conCumulativeSiteSpecies)) = lngTotalSiteNewSpecies
       
1770      rstLevel.MoveNext
1780  Loop
1790  rstLevel.Close
1800  Set rstLevel = Nothing

1810  SysCmd acSysCmdRemoveMeter

      ' finalise

1820  With .range(.Cells(rowEnd, 1), .Cells(rowEnd, colEnd)).Borders(xlEdgeBottom)
1830      .LineStyle = xlContinuous
1840  .Weight = xlMedium
1850  End With

1860  .range(.Cells(1, 1), .Cells(1, colEnd)).Font.Bold = True

1870  .range(.Cells(1, colFLD(conRecorded, conCountBirds)), .Cells(rowEnd, colFLD(conRecorded, conCumulativeSiteSpecies))).Interior.Color = RGB(255, 200, 200)
1880  .range(.Cells(1, colFLD(conDET, conCountBirds)), .Cells(rowEnd, colFLD(conDET, conCumulativeSiteSpecies))).Interior.Color = RGB(153, 204, 255)
1890  .range(.Cells(1, colFLD(conBND, conCountBirds)), .Cells(rowEnd, colFLD(conBND, conCumulativeSiteSpecies))).Interior.Color = RGB(204, 255, 204)
1900  .range(.Cells(1, colFLD(conRET, conCountBirds)), .Cells(rowEnd, colFLD(conRET, conCumulativeSiteSpecies))).Interior.Color = RGB(255, 255, 153)
1910  .range(.Cells(1, colFLD(conREP, conCountBirds)), .Cells(rowEnd, colFLD(conREP, conCumulativeSiteSpecies))).Interior.Color = RGB(255, 204, 153)
1920  .range(.Cells(1, colFLD(conAlien, conCountBirds)), .Cells(rowEnd, colFLD(conAlien, conCumulativeSiteSpecies))).Interior.Color = RGB(229, 224, 236)

      ' 1860  .range(.Cells(1, colSeason), .Cells(rowEnd, colSeason)).Font.Bold = True

      Dim lngColor As Long

1930  For fld = conStatFirst To conStatLast

1940      Select Case fld
          Case conRecorded
1950          lngColor = RGB(255, 128, 128)
1960      Case conDET
1970          lngColor = RGB(129, 192, 255)
1980      Case conBND
1990          lngColor = RGB(151, 255, 151)
2000      Case conRET
2010          lngColor = RGB(255, 255, 71)
2020      Case conREP
2030          lngColor = RGB(255, 190, 125)
2040      Case conAlien
2050          lngColor = RGB(201, 191, 215)
2060      End Select

2070      .range(.Cells(2, colFLD(fld, conCumulativeSeasonSpecies)), _
                 .Cells(rowEnd, colFLD(fld, conCumulativeSeasonSpecies))).Font.Bold = True
2080      .range(.Cells(2, colFLD(fld, conCumulativeSeasonSpecies)), _
                 .Cells(rowEnd, colFLD(fld, conCumulativeSeasonSpecies))).Interior.Color = lngColor
                 
2090      .range(.Cells(2, colFLD(fld, conCumulativeYearSpecies)), _
                 .Cells(rowEnd, colFLD(fld, conCumulativeYearSpecies))).Font.Bold = True
2100      .range(.Cells(2, colFLD(fld, conCumulativeYearSpecies)), _
                 .Cells(rowEnd, colFLD(fld, conCumulativeYearSpecies))).Interior.Color = lngColor
                 
2110      .range(.Cells(2, colFLD(fld, conCumulativeSiteSpecies)), _
                 .Cells(rowEnd, colFLD(fld, conCumulativeSiteSpecies))).Font.Bold = True
2120      .range(.Cells(2, colFLD(fld, conCumulativeSiteSpecies)), _
                 .Cells(rowEnd, colFLD(fld, conCumulativeSiteSpecies))).Interior.Color = lngColor
                 
2130      .range(.Cells(2, colFLD(fld, conCumulativeSeasonBirds)), _
                 .Cells(rowEnd, colFLD(fld, conCumulativeSeasonBirds))).Font.Bold = True
2140      .range(.Cells(2, colFLD(fld, conCumulativeSeasonBirds)), _
                 .Cells(rowEnd, colFLD(fld, conCumulativeSeasonBirds))).Interior.Color = lngColor
                 
2150      .range(.Cells(2, colFLD(fld, conCumulativeYearBirds)), _
                 .Cells(rowEnd, colFLD(fld, conCumulativeYearBirds))).Font.Bold = True
2160      .range(.Cells(2, colFLD(fld, conCumulativeYearBirds)), _
                 .Cells(rowEnd, colFLD(fld, conCumulativeYearBirds))).Interior.Color = lngColor
                 
2170      .range(.Cells(2, colFLD(fld, conCumulativeSiteBirds)), _
                 .Cells(rowEnd, colFLD(fld, conCumulativeSiteBirds))).Font.Bold = True
2180      .range(.Cells(2, colFLD(fld, conCumulativeSiteBirds)), _
                 .Cells(rowEnd, colFLD(fld, conCumulativeSiteBirds))).Interior.Color = lngColor
2190  Next

      Dim col As Integer
2200  For col = 1 To colEnd
2210      With .range(.Cells(2, col), .Cells(rowEnd, col)).Borders(xlEdgeRight)
2220          .LineStyle = xlContinuous
2230          .Weight = xlThin
2240      End With
2250  Next

2260  With .range(.Cells(3, colNetHours(conDaily)), .Cells(row, colBirdsPer100NetHours(conSite)))
2270     .NumberFormat = "#0.0;-#0.0;#"
2280  End With

      ' Replace the contents of empty cells in the totals columns
      '
      'For fld = conDET To conAlien
      '
      '    col = colFLD(fld, conCumulativeSeasonBirds)
      '    For row = 4 To rowEnd
      '        If .Cells(row, col) = "" Then
      '            If .Cells(row, colSeason) = .Cells(row - 1, colSeason) Then
      '                .Cells(row, col) = .Cells(row - 1, col)
      '            Else
      '                .Cells(row, col) = 0
      '            End If
      '        End If
      '    Next
      '
      '    col = colFLD(fld, conCumulativeSeasonSpecies)
      '    For row = 4 To rowEnd
      '        If .Cells(row, col) = "" Then
      '            If .Cells(row, colSeason) = .Cells(row - 1, colSeason) Then
      '                .Cells(row, col) = .Cells(row - 1, col)
      '            Else
      '                .Cells(row, col) = 0
      '            End If
      '        End If
      '    Next
      '
      'Next

2290  .range("G3").Select
2300  oExcel.ActiveWindow.FreezePanes = True

2310  .range(.columns(1), .columns(colEnd)).AutoFit

2320  End With
2330  Set oSheet = Nothing

      'DD Error Handler Start
Exit_label:
2340       Exit Sub
Err_label:
2350       Select Case Err.Number
           Case Else
2360      Call LogError("basMasterSpreadsheet", "MasterSpreadsheet_v2_Export_SeasonSheet")
2370       End Select
2380       Resume Exit_label
      'DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' MasterSpreadsheet_Export_Season_ReportYear_Sheet
'---------------------------------------------------------------------------------------
 
Public Sub MasterSpreadsheet_Export_Season_ReportYear_Sheet( _
    ByVal strLocation As String, _
    ByRef oExcel As Excel.Application, _
    ByRef oBook As Excel.Workbook)
          
      Dim oSheet As Excel.Worksheet
      Dim colEnd As Integer
      Dim fld As Integer
      Dim strSQL As String

10    On Error GoTo Err_label

20    Set oSheet = oBook.Worksheets.Add(After:=oBook.Worksheets(oBook.Worksheets.count))
30    oSheet.Name = "Season x Report Year"
40    With oSheet

50    Call InitialiseColumns
60    colEnd = colBirdsPer100NetHours(conSite)

70    With .Cells.Font
80        .Name = "Arial"
90        .Size = 8
100   End With

110   .Cells.HorizontalAlignment = xlCenter

      ' Write the header row #1
      
120   .Cells(1, colFLD(conRecorded, conCountSpecies)) = "RECORDED (DET if DET>0; Captures if DET=0)"
130   .Cells(1, colFLD(conDET, conCountSpecies)) = "DET"
140   .Cells(1, colFLD(conBND, conCountBirds)) = "BANDED"
150   .Cells(1, colFLD(conRET, conCountBirds)) = "RETURN"
160   .Cells(1, colFLD(conREP, conCountBirds)) = "REPEAT"
170   .Cells(1, colFLD(conAlien, conCountBirds)) = "ALIEN"
180   .Cells(1, colNetHours(conDaily)) = "TOTAL NET HOURS"
190   .Cells(1, colBirdsPer100NetHours(conDaily)) = "BIRDS BND per 100 NET HRS"

200   .range(.Cells(1, colFLD(conRecorded, conCountSpecies)), .Cells(1, colFLD(conRecorded, conCumulativeSiteSpecies))).Merge
210   .range(.Cells(1, colFLD(conDET, conCountSpecies)), .Cells(1, colFLD(conDET, conCumulativeSiteSpecies))).Merge
220   .range(.Cells(1, colFLD(conBND, conCountBirds)), .Cells(1, colFLD(conBND, conCumulativeSiteSpecies))).Merge
230   .range(.Cells(1, colFLD(conRET, conCountBirds)), .Cells(1, colFLD(conRET, conCumulativeSiteSpecies))).Merge
240   .range(.Cells(1, colFLD(conREP, conCountBirds)), .Cells(1, colFLD(conREP, conCumulativeSiteSpecies))).Merge
250   .range(.Cells(1, colFLD(conAlien, conCountBirds)), .Cells(1, colFLD(conAlien, conCumulativeSiteSpecies))).Merge
260   .range(.Cells(1, colNetHours(conDaily)), .Cells(1, colNetHours(conSite))).Merge
270   .range(.Cells(1, colBirdsPer100NetHours(conDaily)), .Cells(1, colBirdsPer100NetHours(conSite))).Merge

280   With .range(.Cells(1, 1), .Cells(1, colEnd)).Borders(xlEdgeBottom)
290       .LineStyle = xlContinuous
300       .Weight = xlThin
310   End With

320   For fld = conStatFirst To conStatLast
330       With .Cells(1, colFLD(fld, conCumulativeSiteSpecies)).Borders(xlEdgeRight)
340           .LineStyle = xlContinuous
350           .Weight = xlThin
360       End With
370   Next

380   With .Cells(1, colNetHours(conSite)).Borders(xlEdgeRight)
390       .LineStyle = xlContinuous
400       .Weight = xlThin
410   End With

420   With .Cells(1, colBirdsPer100NetHours(conSite)).Borders(xlEdgeRight)
430       .LineStyle = xlContinuous
440       .Weight = xlThin
450   End With

      ' Write the header row #2

460   .Cells(2, colReportYear) = "Report" & vbCrLf & "Year"
470   .Cells(2, colYear) = "Year"
480   .Cells(2, colMonth) = "Month"
490   .Cells(2, colDay) = "Day"
500   .Cells(2, colProgram) = "Program"
510   .Cells(2, colSeason) = "Season"
520   .Cells(2, colPeriod) = "Week"

530   For fld = conStatFirst To conStatLast
540       .Cells(2, colFLD(fld, conCountBirds)) = "# individuals"
550       .Cells(2, colFLD(fld, conCumulativeSeasonBirds)) = "TOTAL" & vbLf & "SEASON" & vbLf & "IND"
560       .Cells(2, colFLD(fld, conCumulativeYearBirds)) = "TOTAL" & vbLf & "YEAR" & vbLf & "IND"
570       .Cells(2, colFLD(fld, conCumulativeSiteBirds)) = "TOTAL" & vbLf & "SITE" & vbLf & "IND"
580   Next
590   For fld = conStatFirst To conStatLast
600       .Cells(2, colFLD(fld, conCountSpecies)) = "# species"
610       .Cells(2, colFLD(fld, conNewSeasonSpecies)) = "NEW" & vbLf & "SEASON" & vbLf & "SPP"
620       .Cells(2, colFLD(fld, conCumulativeSeasonSpecies)) = "TOTAL" & vbLf & "SEASON" & vbLf & "SPP"
630       .Cells(2, colFLD(fld, conNewYearSpecies)) = "NEW" & vbLf & "YEAR" & vbLf & "SPP"
640       .Cells(2, colFLD(fld, conCumulativeYearSpecies)) = "TOTAL" & vbLf & "YEAR" & vbLf & "SPP"
650       .Cells(2, colFLD(fld, conNewSiteSpecies)) = "NEW" & vbLf & "SITE" & vbLf & "SPP"
660       .Cells(2, colFLD(fld, conCumulativeSiteSpecies)) = "TOTAL" & vbLf & "SITE" & vbLf & "SPP"
670   Next

680   .Cells(2, colNetHours(conDaily)) = "DAILY"
690   .Cells(2, colNetHours(conSeason)) = "SEASON"
700   .Cells(2, colNetHours(conYear)) = "YEAR"
710   .Cells(2, colNetHours(conSite)) = "SITE"
720   .Cells(2, colBirdsPer100NetHours(conDaily)) = "DAILY"
730   .Cells(2, colBirdsPer100NetHours(conSeason)) = "SEASON"
740   .Cells(2, colBirdsPer100NetHours(conYear)) = "YEAR"
750   .Cells(2, colBirdsPer100NetHours(conSite)) = "SITE"

760   .range(.Cells(2, 1), .Cells(1, colFLD(conAlien, conCumulativeSiteSpecies))).WrapText = True

770   With .range(.Cells(2, 1), .Cells(2, colEnd)).Borders(xlEdgeBottom)
780       .LineStyle = xlContinuous
790       .Weight = xlThin
800   End With
          
      ' initialise

      Dim rowStart As Long
      Dim row As Long
810   rowStart = 3
820   row = rowStart

      Dim rstMaster As DAO.Recordset

830   strSQL = "SELECT * FROM tblMasterSpreadsheet_Daily ORDER BY SeasonNr, DateEx"
840   Set rstMaster = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)

850   rstMaster.MoveLast
860   SysCmd acSysCmdInitMeter, "Export Season x Report Year - Net Hours", rstMaster.RecordCount
870   rstMaster.MoveFirst

      Dim datDateEx
      Dim intReportYear As Integer
      Dim strSeason As String
      Dim intSeasonNr As Integer
      Dim dblNetHours As Double
      Dim strProgram As String
      Dim intYear As Integer
      Dim intMonth As Integer
      Dim intDay As Integer
      Dim datStartOfSeason As Date
      Dim intPeriod As Integer

      Dim intSeasonNrPrevious As Integer
      Dim strSeasonPrevious As String
      Dim intPeriodPrevious As Integer
      Dim intReportYearPrevious As Integer

      Dim lngBirds As Long
      Dim lngSpecies As Long
      Dim lngTotalSeasonBirds As Long
      Dim lngSeasonNewSpecies As Long
      Dim lngTotalSeasonNewSpecies As Long
      Dim lngTotalYearBirds As Long
      Dim lngYearNewSpecies As Long
      Dim lngTotalYearNewSpecies As Long
      Dim lngTotalSiteBirds As Long
      Dim lngSiteNewSpecies As Long
      Dim lngTotalSiteNewSpecies As Long
      Dim lngRow_Year As Long

      Dim rowEnd As Long
880   rowEnd = -1

890   intSeasonNrPrevious = -1
900   intPeriodPrevious = -1
910   intReportYearPrevious = -1

      Dim n As Long
920   n = 1
930   Do While Not rstMaster.EOF
          
          ' Update the progress bar every 100 records
          
940       If CLng(n / 100) * 100 = n Then
950           SysCmd acSysCmdUpdateMeter, n
960       DoEvents
970       End If
980       n = n + 1
          
990       datDateEx = Nz(rstMaster("DateEx"))
1000      strSeason = Nz(rstMaster("Season"))
1010      intPeriod = Nz(rstMaster("Period"))
1020      strProgram = Nz(rstMaster("Program"))
1030      intSeasonNr = Nz(rstMaster("SeasonNr"))
1040      intReportYear = Nz(rstMaster("ReportYear"))

1050      intYear = Year(datDateEx)
1060      intMonth = Month(datDateEx)
1070      intDay = Day(datDateEx)
          
1080      row = Nz(rstMaster("Row_Season_ReportYear"))
1090      If row > rowEnd Then rowEnd = row
          
      ' Period control break

1100      If (intPeriodPrevious <> intPeriod) Then
1110          With .range(.Cells(row, 1), .Cells(row, colEnd)).Borders(xlEdgeTop)
1120              .LineStyle = xlContinuous
1130              .Weight = xlThin
1140          End With
1150          intPeriodPrevious = intPeriod
1160      End If

      ' Report Year control break

1170      If (intReportYearPrevious <> intReportYear) And row <> 3 Then
1180          With .range(.Cells(row, 1), .Cells(row, colEnd)).Borders(xlEdgeTop)
1190              .LineStyle = xlContinuous
1200              .Weight = xlMedium
1210              .Color = vbRed
1220          End With
1230      End If
1240      intReportYearPrevious = intReportYear

      ' Season control break

1250      If (intSeasonNrPrevious <> intSeasonNr) And row <> 3 Then
1260          With .range(.Cells(row, 1), .Cells(row, colEnd)).Borders(xlEdgeTop)
1270              .LineStyle = xlContinuous
1280              .Weight = xlThick
1290              .Color = vbRed
1300          End With
1310      End If
1320      intSeasonNrPrevious = intSeasonNr
          
1330      .Cells(row, colReportYear) = intReportYear
1340      .Cells(row, colYear) = intYear
1350      .Cells(row, colMonth) = intMonth
1360      .Cells(row, colDay) = intDay
1370      .Cells(row, colProgram) = strProgram
1380      .Cells(row, colSeason) = strSeason
          
1390      If strSeason = "Spring" Or strSeason = "Fall" Then
1400          .Cells(row, colPeriod) = intPeriod
1410      End If
          
1420      Call ProcessNetHours(oSheet, row, rstMaster, datDateEx, strProgram)
          
1430      rstMaster.MoveNext
1440  Loop
1450  rstMaster.Close
1460  Set rstMaster = Nothing

      Dim rstLevel As DAO.Recordset
1470  Set rstLevel = CurrentDb.OpenRecordset("tblMasterSpreadsheet_Level", dbOpenDynaset)

1480  rstLevel.MoveLast
1490  SysCmd acSysCmdInitMeter, "Export Year and Site - Birds and Species", rstLevel.RecordCount
1500  rstLevel.MoveFirst

1510  Do While Not rstLevel.EOF
1520      row = Nz(rstLevel("Row_Season_ReportYear"))
1530      fld = Nz(rstLevel("FLD"))

1540          lngBirds = Nz(rstLevel("Birds"))
1550          lngSpecies = Nz(rstLevel("Species"))
1560          lngTotalSeasonBirds = Nz(rstLevel("TotalSeasonBirds"))
1570          lngSeasonNewSpecies = Nz(rstLevel("SeasonNewSpecies"))
1580          lngTotalSeasonNewSpecies = Nz(rstLevel("TotalSeasonNewSpecies"))
1590          lngTotalYearBirds = Nz(rstLevel("TotalYearBirds"))
1600          lngYearNewSpecies = Nz(rstLevel("YearNewSpecies"))
1610          lngTotalYearNewSpecies = Nz(rstLevel("TotalYearNewSpecies"))
1620          lngTotalSiteBirds = Nz(rstLevel("TotalSiteBirds"))
1630          lngSiteNewSpecies = Nz(rstLevel("SiteNewSpecies"))
1640          lngTotalSiteNewSpecies = Nz(rstLevel("TotalSiteNewSpecies"))
                      
1650          If lngBirds <> 0 Then
1660              .Cells(row, colFLD(fld, conCountBirds)) = lngBirds
1670          End If
              
1680          If lngSpecies <> 0 Then
1690              .Cells(row, colFLD(fld, conCountSpecies)) = lngSpecies
1700          End If
              
1710          .Cells(row, colFLD(fld, conCumulativeSeasonBirds)) = lngTotalSeasonBirds
              
1720          If lngSeasonNewSpecies <> 0 Then
1730              .Cells(row, colFLD(fld, conNewSeasonSpecies)) = lngSeasonNewSpecies
1740          End If
              
1750          .Cells(row, colFLD(fld, conCumulativeSeasonSpecies)) = lngTotalSeasonNewSpecies
          
1760          .Cells(row, colFLD(fld, conCumulativeYearBirds)) = lngTotalYearBirds
              
1770          If lngYearNewSpecies <> 0 Then
1780              .Cells(row, colFLD(fld, conNewYearSpecies)) = lngYearNewSpecies
1790          End If
              
1800          .Cells(row, colFLD(fld, conCumulativeYearSpecies)) = lngTotalYearNewSpecies
          
1810          .Cells(row, colFLD(fld, conCumulativeSiteBirds)) = lngTotalSiteBirds
              
1820          If lngSiteNewSpecies <> 0 Then
1830              .Cells(row, colFLD(fld, conNewSiteSpecies)) = lngSiteNewSpecies
1840          End If
              
1850          .Cells(row, colFLD(fld, conCumulativeSiteSpecies)) = lngTotalSiteNewSpecies
       
1860      rstLevel.MoveNext
1870  Loop
1880  rstLevel.Close
1890  Set rstLevel = Nothing

      ' finalise

1900  With .range(.Cells(rowEnd, 1), .Cells(rowEnd, colEnd)).Borders(xlEdgeBottom)
1910      .LineStyle = xlContinuous
1920  .Weight = xlMedium
1930  End With

1940  .range(.Cells(1, 1), .Cells(1, colEnd)).Font.Bold = True

1950  .range(.Cells(1, colFLD(conRecorded, conCountBirds)), .Cells(rowEnd, colFLD(conRecorded, conCumulativeSiteSpecies))).Interior.Color = RGB(255, 200, 200)
1960  .range(.Cells(1, colFLD(conDET, conCountBirds)), .Cells(rowEnd, colFLD(conDET, conCumulativeSiteSpecies))).Interior.Color = RGB(153, 204, 255)
1970  .range(.Cells(1, colFLD(conBND, conCountBirds)), .Cells(rowEnd, colFLD(conBND, conCumulativeSiteSpecies))).Interior.Color = RGB(204, 255, 204)
1980  .range(.Cells(1, colFLD(conRET, conCountBirds)), .Cells(rowEnd, colFLD(conRET, conCumulativeSiteSpecies))).Interior.Color = RGB(255, 255, 153)
1990  .range(.Cells(1, colFLD(conREP, conCountBirds)), .Cells(rowEnd, colFLD(conREP, conCumulativeSiteSpecies))).Interior.Color = RGB(255, 204, 153)
2000  .range(.Cells(1, colFLD(conAlien, conCountBirds)), .Cells(rowEnd, colFLD(conAlien, conCumulativeSiteSpecies))).Interior.Color = RGB(229, 224, 236)

      ' 1870  .range(.Cells(1, colSeason), .Cells(rowEnd, colSeason)).Font.Bold = True

      Dim lngColor As Long

2010  For fld = conStatFirst To conStatLast

2020      Select Case fld
          Case conRecorded
2030          lngColor = RGB(255, 128, 128)
2040      Case conDET
2050          lngColor = RGB(129, 192, 255)
2060      Case conBND
2070          lngColor = RGB(151, 255, 151)
2080      Case conRET
2090          lngColor = RGB(255, 255, 71)
2100      Case conREP
2110          lngColor = RGB(255, 190, 125)
2120      Case conAlien
2130          lngColor = RGB(201, 191, 215)
2140      End Select

2150      .range(.Cells(2, colFLD(fld, conCumulativeSeasonSpecies)), _
                 .Cells(rowEnd, colFLD(fld, conCumulativeSeasonSpecies))).Font.Bold = True
2160      .range(.Cells(2, colFLD(fld, conCumulativeSeasonSpecies)), _
                 .Cells(rowEnd, colFLD(fld, conCumulativeSeasonSpecies))).Interior.Color = lngColor
                 
2170      .range(.Cells(2, colFLD(fld, conCumulativeYearSpecies)), _
                 .Cells(rowEnd, colFLD(fld, conCumulativeYearSpecies))).Font.Bold = True
2180      .range(.Cells(2, colFLD(fld, conCumulativeYearSpecies)), _
                 .Cells(rowEnd, colFLD(fld, conCumulativeYearSpecies))).Interior.Color = lngColor
                 
2190      .range(.Cells(2, colFLD(fld, conCumulativeSiteSpecies)), _
                 .Cells(rowEnd, colFLD(fld, conCumulativeSiteSpecies))).Font.Bold = True
2200      .range(.Cells(2, colFLD(fld, conCumulativeSiteSpecies)), _
                 .Cells(rowEnd, colFLD(fld, conCumulativeSiteSpecies))).Interior.Color = lngColor
                 
2210      .range(.Cells(2, colFLD(fld, conCumulativeSeasonBirds)), _
                 .Cells(rowEnd, colFLD(fld, conCumulativeSeasonBirds))).Font.Bold = True
2220      .range(.Cells(2, colFLD(fld, conCumulativeSeasonBirds)), _
                 .Cells(rowEnd, colFLD(fld, conCumulativeSeasonBirds))).Interior.Color = lngColor
                 
2230      .range(.Cells(2, colFLD(fld, conCumulativeYearBirds)), _
                 .Cells(rowEnd, colFLD(fld, conCumulativeYearBirds))).Font.Bold = True
2240      .range(.Cells(2, colFLD(fld, conCumulativeYearBirds)), _
                 .Cells(rowEnd, colFLD(fld, conCumulativeYearBirds))).Interior.Color = lngColor
                 
2250      .range(.Cells(2, colFLD(fld, conCumulativeSiteBirds)), _
                 .Cells(rowEnd, colFLD(fld, conCumulativeSiteBirds))).Font.Bold = True
2260      .range(.Cells(2, colFLD(fld, conCumulativeSiteBirds)), _
                 .Cells(rowEnd, colFLD(fld, conCumulativeSiteBirds))).Interior.Color = lngColor
2270  Next

      Dim col As Integer
2280  For col = 1 To colEnd
2290      With .range(.Cells(2, col), .Cells(rowEnd, col)).Borders(xlEdgeRight)
2300          .LineStyle = xlContinuous
2310          .Weight = xlThin
2320      End With
2330  Next

2340  With .range(.Cells(3, colNetHours(conDaily)), .Cells(rowEnd, colBirdsPer100NetHours(conSite)))
2350     .NumberFormat = "#0.0;-#0.0;#"
2360  End With

2370  SysCmd acSysCmdRemoveMeter

      ' Group/Summary by Report Year

2380  .range(.Cells(2, 1), .Cells(rowEnd, colBirdsPer100NetHours(conSite))).Subtotal _
      GroupBy:=1, Replace:=True, PageBreaks:=False, SummaryBelowData:=True

      Dim lngMaxRecordedSpecies As Long
      Dim lngMaxDETSpecies As Long
      Dim lngMaxBandedBirds As Long
      Dim rowStartProgram As Long

2390  lngMaxRecordedSpecies = 0
2400  lngMaxDETSpecies = 0
2410  lngMaxBandedBirds = 0
2420  rowStartProgram = 3

      ' loop until .cells(row,1) = "Grand Total"

2430  row = 3
2440  Do While .Cells(row, 1) <> "Grand Total"
          
2450      If Right(.Cells(row, 1), 5) = "Total" Then
          
              ' Process total row
              
2460          .Cells(row, colProgram) = .Cells(row - 1, colProgram)
2470          .Cells(row, colSeason) = .Cells(row - 1, colSeason)
2480          For fld = conStatFirst To conStatLast
2490              .Cells(row, colFLD(fld, conCumulativeSeasonBirds)) = .Cells(row - 1, colFLD(fld, conCumulativeSeasonBirds))
2500              .Cells(row, colFLD(fld, conCumulativeSeasonSpecies)) = .Cells(row - 1, colFLD(fld, conCumulativeSeasonSpecies))
2510          Next
2520          .Cells(row, colNetHours(2)) = .Cells(row - 1, colNetHours(2))
2530          If .Cells(row, colNetHours(2)) > 0 Then
2540              .Cells(row, colBirdsPer100NetHours(2)) = 100 * .Cells(row, colFLD(conBND, conCumulativeSeasonBirds)) / .Cells(row, colNetHours(2))
2550          End If
2560          .Cells(row, colBirdsPer100NetHours(conSite)).ClearContents
              
              ' Highlight max Recorded count species
              
              Dim rowSeason As Long

2570          If lngMaxRecordedSpecies > 0 Then
2580              For rowSeason = rowStartProgram To row - 1
2590                  If lngMaxRecordedSpecies = .Cells(rowSeason, colFLD(conRecorded, conCountSpecies)) Then
2600                      .Cells(rowSeason, colFLD(conRecorded, conCountSpecies)).Interior.Color = vbYellow
2610                  End If
2620              Next
2630              lngMaxRecordedSpecies = 0
2640          End If
              
              ' Highlight max DET count species
              
2650          If lngMaxDETSpecies > 0 Then
2660              For rowSeason = rowStartProgram To row - 1
2670                  If lngMaxDETSpecies = .Cells(rowSeason, colFLD(conDET, conCountSpecies)) Then
2680                      .Cells(rowSeason, colFLD(conDET, conCountSpecies)).Interior.Color = vbYellow
2690                  End If
2700              Next
2710              lngMaxDETSpecies = 0
2720          End If
              
              ' Highlight max BND count birds
              
2730          If lngMaxBandedBirds > 0 Then
2740              For rowSeason = rowStartProgram To row - 1
2750                  If lngMaxBandedBirds = .Cells(rowSeason, colFLD(conBND, conCountBirds)) Then
2760                      .Cells(rowSeason, colFLD(conBND, conCountBirds)).Interior.Color = vbYellow
2770                  End If
2780              Next
2790              lngMaxBandedBirds = 0
2800          End If
              
2810          rowStartProgram = row + 1
2820      Else
2830          If lngMaxRecordedSpecies < .Cells(row, colFLD(conRecorded, conCountSpecies)) Then
2840              lngMaxRecordedSpecies = .Cells(row, colFLD(conRecorded, conCountSpecies))
2850          End If
2860          If lngMaxBandedBirds < .Cells(row, colFLD(conBND, conCountBirds)) Then
2870              lngMaxBandedBirds = .Cells(row, colFLD(conBND, conCountBirds))
2880          End If
2890          If lngMaxDETSpecies < .Cells(row, colFLD(conDET, conCountSpecies)) Then
2900              lngMaxDETSpecies = .Cells(row, colFLD(conDET, conCountSpecies))
2910          End If
2920      End If
          
2930      row = row + 1
2940  Loop

      ' null the grand total row
2950  .Cells(row, colBirdsPer100NetHours(4)).ClearContents

2960  .range("G3").Select
2970  oExcel.ActiveWindow.FreezePanes = True

2980  .range(.columns(1), .columns(colEnd)).AutoFit

2990  End With
3000  Set oSheet = Nothing

      'DD Error Handler Start
Exit_label:
3010       Exit Sub
Err_label:
3020       Select Case Err.Number
           Case Else
3030      Call LogError("basMasterSpreadsheet", "MasterSpreadsheet_Export_Season_ReportYear_Sheet")
3040       End Select
3050       Resume Exit_label
      'DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' MasterSpreadsheet_v2_Export_YearSheet
'---------------------------------------------------------------------------------------
 
Public Sub MasterSpreadsheet_v2_Export_YearSheet( _
    ByVal strLocation As String, _
    ByRef oExcel As Excel.Application, _
    ByRef oBook As Excel.Workbook)
          
      Dim oSheet As Excel.Worksheet
      Dim colEnd As Integer
      Dim fld As Integer
      Dim strSQL As String

10    On Error GoTo Err_label

20    Set oSheet = oBook.Worksheets.Add(After:=oBook.Worksheets(oBook.Worksheets.count))
30    oSheet.Name = "Master by Year and Site"
40    With oSheet

50    Call InitialiseColumns
60    colEnd = colBirdsPer100NetHours(conSite)

70    With .Cells.Font
80        .Name = "Arial"
90        .Size = 8
100   End With

110   .Cells.HorizontalAlignment = xlCenter

      ' Write the header row #1
      
120   .Cells(1, colFLD(conRecorded, conCountSpecies)) = "RECORDED (DET if DET>0; Captures if DET=0)"
130   .Cells(1, colFLD(conDET, conCountSpecies)) = "DET"
140   .Cells(1, colFLD(conBND, conCountBirds)) = "BANDED"
150   .Cells(1, colFLD(conRET, conCountBirds)) = "RETURN"
160   .Cells(1, colFLD(conREP, conCountBirds)) = "REPEAT"
170   .Cells(1, colFLD(conAlien, conCountBirds)) = "ALIEN"
180   .Cells(1, colNetHours(conDaily)) = "TOTAL NET HOURS"
190   .Cells(1, colBirdsPer100NetHours(conDaily)) = "BIRDS BND per 100 NET HRS"

200   .range(.Cells(1, colFLD(conRecorded, conCountSpecies)), .Cells(1, colFLD(conRecorded, conCumulativeSiteSpecies))).Merge
210   .range(.Cells(1, colFLD(conDET, conCountSpecies)), .Cells(1, colFLD(conDET, conCumulativeSiteSpecies))).Merge
220   .range(.Cells(1, colFLD(conBND, conCountBirds)), .Cells(1, colFLD(conBND, conCumulativeSiteSpecies))).Merge
230   .range(.Cells(1, colFLD(conRET, conCountBirds)), .Cells(1, colFLD(conRET, conCumulativeSiteSpecies))).Merge
240   .range(.Cells(1, colFLD(conREP, conCountBirds)), .Cells(1, colFLD(conREP, conCumulativeSiteSpecies))).Merge
250   .range(.Cells(1, colFLD(conAlien, conCountBirds)), .Cells(1, colFLD(conAlien, conCumulativeSiteSpecies))).Merge

260   .range(.Cells(1, colNetHours(conDaily)), .Cells(1, colNetHours(conSite))).Merge
270   .range(.Cells(1, colBirdsPer100NetHours(conDaily)), .Cells(1, colBirdsPer100NetHours(conSite))).Merge

280   With .range(.Cells(1, 1), .Cells(1, colEnd)).Borders(xlEdgeBottom)
290       .LineStyle = xlContinuous
300       .Weight = xlThin
310   End With

      'With .Cells(1, colDay).Borders(xlEdgeRight)
      '    .LineStyle = xlContinuous
      '    .Weight = xlThin
      'End With

320   For fld = conStatFirst To conStatLast
330       With .Cells(1, colFLD(fld, conCumulativeSiteSpecies)).Borders(xlEdgeRight)
340           .LineStyle = xlContinuous
350           .Weight = xlThin
360       End With
370   Next

380   With .Cells(1, colNetHours(conSite)).Borders(xlEdgeRight)
390       .LineStyle = xlContinuous
400       .Weight = xlThin
410   End With

420   With .Cells(1, colBirdsPer100NetHours(conSite)).Borders(xlEdgeRight)
430       .LineStyle = xlContinuous
440       .Weight = xlThin
450   End With

      ' Write the header row #2
      
460   .Cells(2, colReportYear) = "Report" & vbCrLf & "Year"
470   .Cells(2, colYear) = "Year"
480   .Cells(2, colMonth) = "Month"
490   .Cells(2, colDay) = "Day"
500   .Cells(2, colProgram) = "Program"
510   .Cells(2, colSeason) = "Season"
520   .Cells(2, colPeriod) = "Week"

530   For fld = conStatFirst To conStatLast
540       .Cells(2, colFLD(fld, conCountBirds)) = "# individuals"
550       .Cells(2, colFLD(fld, conCumulativeSeasonBirds)) = "TOTAL" & vbLf & "SEASON" & vbLf & "IND"
560       .Cells(2, colFLD(fld, conCumulativeYearBirds)) = "TOTAL" & vbLf & "YEAR" & vbLf & "IND"
570       .Cells(2, colFLD(fld, conCumulativeSiteBirds)) = "TOTAL" & vbLf & "SITE" & vbLf & "IND"
580   Next
590   For fld = conStatFirst To conStatLast
600       .Cells(2, colFLD(fld, conCountSpecies)) = "# species"
610       .Cells(2, colFLD(fld, conNewSeasonSpecies)) = "NEW" & vbLf & "SEASON" & vbLf & "SPP"
620       .Cells(2, colFLD(fld, conCumulativeSeasonSpecies)) = "TOTAL" & vbLf & "SEASON" & vbLf & "SPP"
630       .Cells(2, colFLD(fld, conNewYearSpecies)) = "NEW" & vbLf & "YEAR" & vbLf & "SPP"
640       .Cells(2, colFLD(fld, conCumulativeYearSpecies)) = "TOTAL" & vbLf & "YEAR" & vbLf & "SPP"
650       .Cells(2, colFLD(fld, conNewSiteSpecies)) = "NEW" & vbLf & "SITE" & vbLf & "SPP"
660       .Cells(2, colFLD(fld, conCumulativeSiteSpecies)) = "TOTAL" & vbLf & "SITE" & vbLf & "SPP"
670   Next

680   .Cells(2, colNetHours(conDaily)) = "DAILY"
690   .Cells(2, colNetHours(conSeason)) = "SEASON"
700   .Cells(2, colNetHours(conYear)) = "YEAR"
710   .Cells(2, colNetHours(conSite)) = "SITE"
720   .Cells(2, colBirdsPer100NetHours(conDaily)) = "DAILY"
730   .Cells(2, colBirdsPer100NetHours(conSeason)) = "SEASON"
740   .Cells(2, colBirdsPer100NetHours(conYear)) = "YEAR"
750   .Cells(2, colBirdsPer100NetHours(conSite)) = "SITE"

760   .range(.Cells(2, 1), .Cells(1, colFLD(conAlien, conCumulativeSiteSpecies))).WrapText = True

770   With .range(.Cells(2, 1), .Cells(2, colEnd)).Borders(xlEdgeBottom)
780       .LineStyle = xlContinuous
790       .Weight = xlThin
800   End With
          
      ' initialise

      Dim rowStart As Long
      Dim row As Long
810   rowStart = 3
820   row = rowStart

      Dim rstMaster As DAO.Recordset

830   strSQL = "SELECT * FROM tblMasterSpreadsheet_Daily ORDER BY DateEx, SeasonNr"
840   Set rstMaster = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)

850   rstMaster.MoveLast
860   SysCmd acSysCmdInitMeter, "Export Year and Site - Net Hours", rstMaster.RecordCount
870   rstMaster.MoveFirst

      Dim datDateEx
      Dim intReportYear As Integer
      Dim strSeason As String
      Dim dblNetHours As Double
      Dim strProgram As String
      Dim intYear As Integer
      Dim intMonth As Integer
      Dim intDay As Integer
      Dim datStartOfSeason As Date
      Dim intPeriod As Integer

      Dim intYearPrevious As Integer
      Dim strSeasonPrevious As String
      Dim intPeriodPrevious As Integer

      Dim lngBirds As Long
      Dim lngSpecies As Long
      Dim lngTotalSeasonBirds As Long
      Dim lngSeasonNewSpecies As Long
      Dim lngTotalSeasonNewSpecies As Long
      Dim lngTotalYearBirds As Long
      Dim lngYearNewSpecies As Long
      Dim lngTotalYearNewSpecies As Long
      Dim lngTotalSiteBirds As Long
      Dim lngSiteNewSpecies As Long
      Dim lngTotalSiteNewSpecies As Long
      Dim lngRow_Year As Long

      Dim rowEnd As Long
880   rowEnd = -1

890   intYearPrevious = 0

      Dim n As Long
900   n = 1
910   Do While Not rstMaster.EOF
          
          ' Update the progress bar every 100 records
          
920       If CLng(n / 100) * 100 = n Then
930           SysCmd acSysCmdUpdateMeter, n
940       DoEvents
950       End If
960       n = n + 1
          
970       datDateEx = Nz(rstMaster("DateEx"))
980       strSeason = Nz(rstMaster("Season"))
990       intPeriod = Nz(rstMaster("Period"))
1000      strProgram = Nz(rstMaster("Program"))
1010      intReportYear = Nz(rstMaster("ReportYear"))
          
1020      intYear = Year(datDateEx)
1030      intMonth = Month(datDateEx)
1040      intDay = Day(datDateEx)

1050      row = Nz(rstMaster("Row_Year"))
1060      If row > rowEnd Then rowEnd = row
          
      ' Year control break

1070      If intYearPrevious <> intYear Then
1080          With .range(.Cells(row, 1), .Cells(row, colEnd)).Borders(xlEdgeTop)
1090              .LineStyle = xlContinuous
1100              .Weight = xlMedium
1110          End With
1120          intYearPrevious = intYear
1130      End If

1140      .Cells(row, colReportYear) = intReportYear
1150      .Cells(row, colYear) = intYear
1160      .Cells(row, colMonth) = intMonth
1170      .Cells(row, colDay) = intDay
1180      .Cells(row, colProgram) = strProgram
1190      .Cells(row, colSeason) = strSeason
          
1200      If strSeason = "Spring" Or strSeason = "Fall" Then
1210          .Cells(row, colPeriod) = intPeriod
1220      End If

1230      Call ProcessNetHours(oSheet, row, rstMaster, datDateEx, strProgram)
          
1240      rstMaster.MoveNext
1250  Loop
1260  rstMaster.Close
1270  Set rstMaster = Nothing

      Dim rstLevel As DAO.Recordset
1280  Set rstLevel = CurrentDb.OpenRecordset("tblMasterSpreadsheet_Level", dbOpenDynaset)

1290  rstLevel.MoveLast
1300  SysCmd acSysCmdInitMeter, "Export Year and Site - Birds and Species", rstLevel.RecordCount
1310  rstLevel.MoveFirst

1320  Do While Not rstLevel.EOF

1330      row = Nz(rstLevel("Row_Year"))
1340      fld = Nz(rstLevel("FLD"))

1350      lngBirds = Nz(rstLevel("Birds"))
1360      lngSpecies = Nz(rstLevel("Species"))
1370      lngTotalSeasonBirds = Nz(rstLevel("TotalSeasonBirds"))
1380      lngSeasonNewSpecies = Nz(rstLevel("SeasonNewSpecies"))
1390      lngTotalSeasonNewSpecies = Nz(rstLevel("TotalSeasonNewSpecies"))
1400      lngTotalYearBirds = Nz(rstLevel("TotalYearBirds"))
1410      lngYearNewSpecies = Nz(rstLevel("YearNewSpecies"))
1420      lngTotalYearNewSpecies = Nz(rstLevel("TotalYearNewSpecies"))
1430      lngTotalSiteBirds = Nz(rstLevel("TotalSiteBirds"))
1440      lngSiteNewSpecies = Nz(rstLevel("SiteNewSpecies"))
1450      lngTotalSiteNewSpecies = Nz(rstLevel("TotalSiteNewSpecies"))

1460      If lngBirds <> 0 Then
1470          .Cells(row, colFLD(fld, conCountBirds)) = lngBirds
1480      End If
          
1490      If lngSpecies <> 0 Then
1500          .Cells(row, colFLD(fld, conCountSpecies)) = lngSpecies
1510      End If
          
1520      .Cells(row, colFLD(fld, conCumulativeSeasonBirds)) = lngTotalSeasonBirds
          
1530      If lngSeasonNewSpecies <> 0 Then
1540          .Cells(row, colFLD(fld, conNewSeasonSpecies)) = lngSeasonNewSpecies
1550      End If
          
1560      .Cells(row, colFLD(fld, conCumulativeSeasonSpecies)) = lngTotalSeasonNewSpecies

1570      .Cells(row, colFLD(fld, conCumulativeYearBirds)) = lngTotalYearBirds
          
1580      If lngYearNewSpecies <> 0 Then
1590          .Cells(row, colFLD(fld, conNewYearSpecies)) = lngYearNewSpecies
1600      End If
          
1610      .Cells(row, colFLD(fld, conCumulativeYearSpecies)) = lngTotalYearNewSpecies

1620      .Cells(row, colFLD(fld, conCumulativeSiteBirds)) = lngTotalSiteBirds
          
1630      If lngSiteNewSpecies <> 0 Then
1640          .Cells(row, colFLD(fld, conNewSiteSpecies)) = lngSiteNewSpecies
1650      End If
          
1660      .Cells(row, colFLD(fld, conCumulativeSiteSpecies)) = lngTotalSiteNewSpecies
          
1670      rstLevel.MoveNext
1680  Loop
1690  rstLevel.Close
1700  Set rstLevel = Nothing

      ' finalise

1710  With .range(.Cells(rowEnd, 1), .Cells(rowEnd, colEnd)).Borders(xlEdgeBottom)
1720      .LineStyle = xlContinuous
1730  .Weight = xlMedium
1740  End With

1750  .range(.Cells(1, 1), .Cells(1, colEnd)).Font.Bold = True

1760  .range(.Cells(1, colFLD(conRecorded, conCountBirds)), .Cells(rowEnd, colFLD(conRecorded, conCumulativeSiteSpecies))).Interior.Color = RGB(255, 128, 128)
1770  .range(.Cells(1, colFLD(conDET, conCountBirds)), .Cells(rowEnd, colFLD(conDET, conCumulativeSiteSpecies))).Interior.Color = RGB(153, 204, 255)
1780  .range(.Cells(1, colFLD(conBND, conCountBirds)), .Cells(rowEnd, colFLD(conBND, conCumulativeSiteSpecies))).Interior.Color = RGB(204, 255, 204)
1790  .range(.Cells(1, colFLD(conRET, conCountBirds)), .Cells(rowEnd, colFLD(conRET, conCumulativeSiteSpecies))).Interior.Color = RGB(255, 255, 153)
1800  .range(.Cells(1, colFLD(conREP, conCountBirds)), .Cells(rowEnd, colFLD(conREP, conCumulativeSiteSpecies))).Interior.Color = RGB(255, 204, 153)
1810  .range(.Cells(1, colFLD(conAlien, conCountBirds)), .Cells(rowEnd, colFLD(conAlien, conCumulativeSiteSpecies))).Interior.Color = RGB(229, 224, 236)

' 1760  .range(.Cells(1, colSeason), .Cells(rowEnd, colSeason)).Font.Bold = True

1820  For fld = conStatFirst To conStatLast
1830      .range(.Cells(2, colFLD(fld, conCumulativeSeasonSpecies)), _
                 .Cells(rowEnd, colFLD(fld, conCumulativeSeasonSpecies))).Font.Bold = True
1840      .range(.Cells(2, colFLD(fld, conCumulativeYearSpecies)), _
                 .Cells(rowEnd, colFLD(fld, conCumulativeYearSpecies))).Font.Bold = True
1850      .range(.Cells(2, colFLD(fld, conCumulativeSiteSpecies)), _
                 .Cells(rowEnd, colFLD(fld, conCumulativeSiteSpecies))).Font.Bold = True
1860  Next

1870  For fld = conStatFirst To conStatLast
1880      .range(.Cells(2, colFLD(fld, conCumulativeSeasonBirds)), _
                 .Cells(rowEnd, colFLD(fld, conCumulativeSeasonBirds))).Font.Bold = True
1890      .range(.Cells(2, colFLD(fld, conCumulativeYearBirds)), _
                 .Cells(rowEnd, colFLD(fld, conCumulativeYearBirds))).Font.Bold = True
1900      .range(.Cells(2, colFLD(fld, conCumulativeSiteBirds)), _
                 .Cells(rowEnd, colFLD(fld, conCumulativeSiteBirds))).Font.Bold = True
1910  Next

      Dim col As Integer
1920  For col = 1 To colEnd
1930      With .range(.Cells(2, col), .Cells(rowEnd, col)).Borders(xlEdgeRight)
1940          .LineStyle = xlContinuous
1950          .Weight = xlThin
1960      End With
1970  Next

1980  With .range(.Cells(3, colNetHours(conDaily)), .Cells(row, colBirdsPer100NetHours(conSite)))
1990     .NumberFormat = "#0.0;-#0.0;#"
2000  End With

Dim lngColor As Long

2010  For fld = conStatFirst To conStatLast

2020      Select Case fld
          Case conRecorded
2030        lngColor = RGB(255, 128, 128)
2040      Case conDET
2050        lngColor = RGB(129, 192, 255)
2060      Case conBND
2070        lngColor = RGB(151, 255, 151)
2080      Case conRET
2090        lngColor = RGB(255, 255, 71)
2100      Case conREP
2110        lngColor = RGB(255, 190, 125)
2120      Case conAlien
2130        lngColor = RGB(201, 191, 215)
2140      End Select

2150      .range(.Cells(2, colFLD(fld, conCumulativeSeasonSpecies)), _
           .Cells(rowEnd, colFLD(fld, conCumulativeSeasonSpecies))).Font.Bold = True
2160      .range(.Cells(2, colFLD(fld, conCumulativeSeasonSpecies)), _
           .Cells(rowEnd, colFLD(fld, conCumulativeSeasonSpecies))).Interior.Color = lngColor
           
2170      .range(.Cells(2, colFLD(fld, conCumulativeYearSpecies)), _
           .Cells(rowEnd, colFLD(fld, conCumulativeYearSpecies))).Font.Bold = True
2180      .range(.Cells(2, colFLD(fld, conCumulativeYearSpecies)), _
           .Cells(rowEnd, colFLD(fld, conCumulativeYearSpecies))).Interior.Color = lngColor
           
2190      .range(.Cells(2, colFLD(fld, conCumulativeSiteSpecies)), _
           .Cells(rowEnd, colFLD(fld, conCumulativeSiteSpecies))).Font.Bold = True
2200      .range(.Cells(2, colFLD(fld, conCumulativeSiteSpecies)), _
           .Cells(rowEnd, colFLD(fld, conCumulativeSiteSpecies))).Interior.Color = lngColor
           
2210      .range(.Cells(2, colFLD(fld, conCumulativeSeasonBirds)), _
           .Cells(rowEnd, colFLD(fld, conCumulativeSeasonBirds))).Font.Bold = True
2220      .range(.Cells(2, colFLD(fld, conCumulativeSeasonBirds)), _
           .Cells(rowEnd, colFLD(fld, conCumulativeSeasonBirds))).Interior.Color = lngColor
           
2230      .range(.Cells(2, colFLD(fld, conCumulativeYearBirds)), _
           .Cells(rowEnd, colFLD(fld, conCumulativeYearBirds))).Font.Bold = True
2240      .range(.Cells(2, colFLD(fld, conCumulativeYearBirds)), _
           .Cells(rowEnd, colFLD(fld, conCumulativeYearBirds))).Interior.Color = lngColor
           
2250      .range(.Cells(2, colFLD(fld, conCumulativeSiteBirds)), _
           .Cells(rowEnd, colFLD(fld, conCumulativeSiteBirds))).Font.Bold = True
2260      .range(.Cells(2, colFLD(fld, conCumulativeSiteBirds)), _
           .Cells(rowEnd, colFLD(fld, conCumulativeSiteBirds))).Interior.Color = lngColor
2270  Next

2280  .range("G3").Select
2290  oExcel.ActiveWindow.FreezePanes = True

2300  .range(.columns(1), .columns(colEnd)).AutoFit

2310  End With
2320  Set oSheet = Nothing

      'DD Error Handler Start
Exit_label:
2330       Exit Sub
Err_label:
2340       Select Case Err.Number
           Case Else
2350      Call LogError("basMasterSpreadsheet", "MasterSpreadsheet_v2_Export_YearSheet")
2360       End Select
2370       Resume Exit_label
      'DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' ProcessNetHours
'---------------------------------------------------------------------------------------
 
Sub ProcessNetHours( _
    ByRef oSheet As Excel.Worksheet, _
    ByVal row As Long, _
    ByRef rstMaster As DAO.Recordset, _
    ByVal datDateEx As Date, _
    ByVal strProgram As String)

10    On Error GoTo Err_label

      Dim strSQL As String
      Dim level As Integer
      Dim dblTotalBirds(conDaily To conSite) As Double
      Dim dblNetHours(conDaily To conSite) As Double

20    dblTotalBirds(conDaily) = Nz(rstMaster("BirdsBandedInNets"))
30    dblTotalBirds(conSeason) = Nz(rstMaster("TotalSeasonBirdsBandedInNets"))
40    dblTotalBirds(conYear) = Nz(rstMaster("TotalYearBirdsBandedInNets"))
50    dblTotalBirds(conSite) = Nz(rstMaster("TotalSiteBirdsBandedInNets"))

60    dblNetHours(conDaily) = Nz(rstMaster("NetHours"))
70    dblNetHours(conSeason) = Nz(rstMaster("TotalSeasonNetHours"))
80    dblNetHours(conYear) = Nz(rstMaster("TotalYearNetHours"))
90    dblNetHours(conSite) = Nz(rstMaster("TotalSiteNetHours"))

100   With oSheet

110       For level = conDaily To conSite
120           If dblNetHours(level) > 0 Then
130           .Cells(row, colNetHours(level)) = dblNetHours(level)
140           .Cells(row, colBirdsPer100NetHours(level)) = _
                  100 * dblTotalBirds(level) / dblNetHours(level)
150           End If
160       Next

170   End With
          
      'DD Error Handler Start
Exit_label:
180        Exit Sub
Err_label:
190        Select Case Err.Number
           Case Else
200             Call LogError("basMasterSpreadsheet", "ProcessNetHours")
210        End Select
220        Resume Exit_label
      'DD Error Handler End
End Sub


'---------------------------------------------------------------------------------------
' toTextFLD
'---------------------------------------------------------------------------------------
 
Private Function toTextFLD(ByVal fld As Integer) As String
10    On Error GoTo Err_label

20    Select Case fld
      Case 1
30        toTextFLD = "DET"
40    Case 2
50        toTextFLD = "BND"
60    Case 3
70        toTextFLD = "RET"
80    Case 4
90        toTextFLD = "REP"
100   End Select

      'DD Error Handler Start
Exit_label:
110        Exit Function
Err_label:
120        Select Case Err.Number
           Case Else
130             Call LogError("basMasterSpreadsheet", "toTextFLD")
140        End Select
150        Resume Exit_label
      'DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' toFieldnameFLD
'---------------------------------------------------------------------------------------
 
Private Function toFieldnameFLD(ByVal fld As Integer) As String
10    On Error GoTo Err_label

20        Select Case fld
          Case 0
30             toFieldnameFLD = "Recorded"
40        Case 1
50            toFieldnameFLD = "DET"
60        Case 2
70            toFieldnameFLD = "Banded"
80        Case 3
90            toFieldnameFLD = "Returns"
100       Case 4
110           toFieldnameFLD = "Repeats"
120       Case 5
130           toFieldnameFLD = "Observed3"
140       Case 6
150           toFieldnameFLD = "Observed4"
160       End Select

      'DD Error Handler Start
Exit_label:
170        Exit Function
Err_label:
180        Select Case Err.Number
           Case Else
190             Call LogError("basMasterSpreadsheet", "toFieldnameFLD")
200        End Select
210        Resume Exit_label
      'DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' toTextLevel
'---------------------------------------------------------------------------------------
 
Private Function toTextLevel(ByVal level As Integer) As String
10    On Error GoTo Err_label

20        Select Case level
          Case 1
30            toTextLevel = "Daily"
40        Case 2
50            toTextLevel = "Season"
60        Case 3
70            toTextLevel = "Year"
80        Case 4
90            toTextLevel = "Site"
100       End Select

      'DD Error Handler Start
Exit_label:
110        Exit Function
Err_label:
120        Select Case Err.Number
           Case Else
130             Call LogError("basMasterSpreadsheet", "toTextLevel")
140        End Select
150        Resume Exit_label
      'DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' InitialiseColumns_YearSheet
'
'  1 = ReportYear
'  2 = Year
'  3 = Month
'  4 = Day
'  5 = Program
'  6 = Season
'  7 = Period

'  8 to 18 Recorded
'  ----------------
'  8 = # Birds
'  9 = # Species
' 10 = New Species Season
' 11 = Total Birds Season
' 12 = Total Species Season
' 13 = New Species Year
' 14 = Total Birds Year
' 15 = Total Species Year
' 16 = New Species Site
' 17 = Total Birds Site
' 18 = Total Species Site
' 19 to 29 DET
' 30 to 40 Banded
' 41 to 51 Returns
' 52 to 62 Repeats
' 63 to 73 Alien
' 74 = Total Net Hours Daily
' 75 = Total Net Hours Season
' 76 = Total Net Hours Year
' 77 = Total Net Hours Site
' 78 = Birds per 100 Net Hours Daily
' 79 = Birds per 100 Net Hours Season
' 80 = Birds per 100 Net Hours Yearly
' 81 = Birds per 100 Net Hours Site

'---------------------------------------------------------------------------------------
 
Private Sub InitialiseColumns()
10    On Error GoTo Err_label
         
          Dim colNext As Integer
          Dim fld As Integer
          Dim level As Integer
          Dim stat As Integer
          
      '    Const colReportYear As Integer = 1
      '    Const colYear As Integer = 2
      '    Const colMonth As Integer = 3
      '    Const colDay As Integer = 4
      '    Const colProgram As Integer = 5
      '    Const colSeason As Integer = 6
      '    Const colPeriod As Integer = 7

20        colNext = 8
          
          ' Recorded, DET, Banded, Returns, Repeats, Alien

30        For fld = conStatFirst To conStatLast
40            For stat = conCountBirds To conCumulativeSiteSpecies
50                colFLD(fld, stat) = colNext
60                colNext = colNext + 1
70            Next
80        Next
90        For level = conDaily To conSite
100           colNetHours(level) = colNext
110           colNext = colNext + 1
120       Next
130       For level = conDaily To conSite
140           colBirdsPer100NetHours(level) = colNext
150           colNext = colNext + 1
160       Next

      'DD Error Handler Start
Exit_label:
170        Exit Sub
Err_label:
180        Select Case Err.Number
           Case Else
190             Call LogError("basMasterSpreadsheet", "InitialiseColumns_YearSheet")
200        End Select
210        Resume Exit_label
      'DD Error Handler End
End Sub
