'---------------------------------------------------------------------------------------
' Module    : basMBO10YearProgramReportTop10
' Author    : David Davey
'---------------------------------------------------------------------------------------

Option Compare Database
Option Explicit

' Statistics

Const conDET As Integer = 0
Const conBND As Integer = 1
Const conRET As Integer = 2
Const conREP As Integer = 3
Const conCNS As Integer = 4

Const conDETSummary As Integer = 5
Const conBNDSummary As Integer = 6

Private intYearFirst As Integer
Private intYearLast As Integer
Private strLocation As String
Private strSeason As String
Private wd As Word.Application
Private doc As Word.Document
Private fDebug As Boolean

Private dintDETDaysCountblStat() As Double
Private dblStatAllYears() As Double
Private intDETDaysCount() As Integer

' tblMBO10YearProgramReport_Top10
' -------------------------------
' DETorBanded           Text                        "Banded", "DET"
' Period                Number(Long Integer)        99 = Summary over all periods
' YearEx                Number(Long Integer)
' Rank                  Number(Long Integer)        1, 2, ...
' Species               Text
' SpeciesEnglish        Text
' CountBirds            Number(Long Integer)
' SpeciesCategoryName   Text
' BackgroundColour      Number(Long Integer)        Each Species Category uses a different background colour
' row                   Number(Long Integer)        1, 2, ...
' Season                String                      "Spring","Fall", "Winter", "Summer"
'
' For each DETorBanded x Period x YearEx there are nominally 10 records that are ranked 1 to 10 and will appear on rows 1 to 10
' If there are less than 10 records, then the last row corresponds to the last record
' If n records have the same rank m, then the next rank is n+m
' There can be more than 10 records if the last records have the same rank.

'---------------------------------------------------------------------------------------
' MBO10YearProgramReportTop10
'---------------------------------------------------------------------------------------
' Called from MBO10YearProgramReport to output the Spring and Fall Top 10 tables
 
Public Sub MBO10YearProgramReportTop10_C( _
    ByRef fValid As Boolean, _
    ByVal argYearFirst As Integer, _
    ByVal argYearLast As Integer, _
    ByVal argLocation As String, _
    ByVal argSeason As String, _
    ByRef arg_wd As Word.Application, _
    ByRef arg_doc As Word.Document, _
    ByVal arg_debug As Boolean)
           
      ' Save parameters

10    On Error GoTo Err_label

20    intYearFirst = argYearFirst
30    intYearLast = argYearLast
40    strLocation = argLocation
50    strSeason = argSeason
60    Set wd = arg_wd
70    Set doc = arg_doc
80    fDebug = arg_debug

      Dim intPeriod As Integer
90    For intPeriod = 1 To getPeriodLast_Season(strSeason)
100       Call OutputData(conBND, strSeason, intPeriod)
110       Call OutputData(conDET, strSeason, intPeriod)
120   Next

130   Call OutputData(conBNDSummary, strSeason, intPeriod)
140   Call OutputData(conDETSummary, strSeason, intPeriod)

      'DD Error Handler Start
Exit_label:
150        Exit Sub
Err_label:
160        Select Case Err.Number
           Case Else
170       Call LogError("basMBO10YearProgramReportTop10", "MBO10YearProgramReportTop10")
180        End Select
190        Resume Exit_label
      'DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' Export_tblMBO10YearProgramReport_Top10
'---------------------------------------------------------------------------------------
 
Public Sub Export_tblMBO10YearProgramReport_Top10( _
    ByRef oExcel As Excel.Application, _
    ByRef oBook As Excel.Workbook)
           
      ' Save parameters

10    On Error GoTo Err_label

      Dim oSheet As Excel.Worksheet
      Dim strSeason As String
      Dim strDETOrBanded As String
      Dim intPeriod As Integer
      Dim intYearEx As Integer
      Dim intRank As Integer
      Dim strSpecies As String
      Dim strSpeciesEnglish As String
      Dim dblCountBirds As Long
      Dim strSpeciesCategoryName As String
      Dim lngBackgroundColour As Long
      Dim intRow As Integer
      Dim row As Long

20    Set oSheet = InsertSheet(oBook, "Global")
30    oSheet.Name = "Top 10"
40    With oSheet
50    .Cells(1, 1) = "Season"
60    .Cells(1, 2) = "Banded or DET"
70    .Cells(1, 3) = "Period"
80    .Cells(1, 4) = "Year"
90    .Cells(1, 5) = "Rank"
100   .Cells(1, 6) = "Species"
110   .Cells(1, 7) = "Species Name"
120   .Cells(1, 8) = "DET:#Birds/Day or Banded:#Birds"
130   .Cells(1, 9) = "Group"
140   .Cells(1, 10) = "Background Colour"
150   .Cells(1, 11) = "Row"

160   row = 2

      Dim rst As DAO.Recordset
170   Set rst = CurrentDb.OpenRecordset("tblMBO10YearProgramReport_Top10", dbOpenDynaset)
180   Do While Not rst.EOF
190       strSeason = Nz(rst("Season"))
200       strDETOrBanded = Nz(rst("DETOrBanded"))
210       intPeriod = Nz(rst("Period"))
220       intYearEx = Nz(rst("YearEx"))
230       intRank = Nz(rst("Rank"))
240       strSpecies = Nz(rst("Species"))
250       strSpeciesEnglish = Nz(rst("SpeciesEnglish"))
260       dblCountBirds = Nz(rst("CountBirds"))
270       strSpeciesCategoryName = Nz(rst("SpeciesCategoryName"))
280       lngBackgroundColour = Nz(rst("BackgroundColour"))
290       intRow = Nz(rst("row"))
          
300       .Cells(row, 1) = strSeason
310       .Cells(row, 2) = strDETOrBanded
320       .Cells(row, 3) = intPeriod
330       .Cells(row, 4) = intYearEx
340       .Cells(row, 5) = intRank
350       .Cells(row, 6) = strSpecies
360       .Cells(row, 7) = strSpeciesEnglish
370       .Cells(row, 8) = dblCountBirds
380       .Cells(row, 9) = strSpeciesCategoryName
390       .Cells(row, 10) = lngBackgroundColour
400       .Cells(row, 11) = intRow

410       .range(.Cells(row, 7), .Cells(row, 9)).Interior.Color = lngBackgroundColour
420       .range(.Cells(row, 9), .Cells(row, 9)).Font.Bold = True
430       row = row + 1
440       rst.MoveNext
450   Loop
460   rst.Close
470   Set rst = Nothing

480   .range(.Cells(1, 1), .Cells(1, 11)).Font.Bold = True
490   .range(.columns(1), .columns(11)).AutoFit

500   End With

510   Set oSheet = Nothing

      'DD Error Handler Start
Exit_label:
520        Exit Sub
Err_label:
530        Select Case Err.Number
           Case Else
540             Call LogError("basMBO10YearProgramReportTop10", "Export_tblMBO10YearProgramReport_Top10")
550        End Select
560        Resume Exit_label
      'DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' Append_tblMBO10YearProgramReport_Top10
'---------------------------------------------------------------------------------------
 
Public Sub Append_tblMBO10YearProgramReport_Top10(ByVal strSeason As String)

10    On Error GoTo Err_label

Dim strSQL As String
Dim intSeason As Integer

Dim local_intPeriodFirst_Season As Integer
Dim local_intPeriodLast_Season As Integer

20    intSeason = toIntSeasonFromStrSeason(strSeason)
30    local_intPeriodFirst_Season = 1
40    local_intPeriodLast_Season = intPeriodLast_Season(intSeason)

      Dim intPeriod As Integer
      
50    For intPeriod = local_intPeriodFirst_Season To local_intPeriodLast_Season
60        Call Append_tblMBO10YearProgramReport_Top10_FLDxSeasonxPeriod(conBND, strSeason, intPeriod)
70        Call Append_tblMBO10YearProgramReport_Top10_FLDxSeasonxPeriod(conDET, strSeason, intPeriod)
80    Next

90    Call Append_tblMBO10YearProgramReport_Top10_FLDxSeasonxPeriod(conBNDSummary, strSeason, intPeriod)
100   Call Append_tblMBO10YearProgramReport_Top10_FLDxSeasonxPeriod(conDETSummary, strSeason, intPeriod)

      'DD Error Handler Start
Exit_label:
110        Exit Sub
Err_label:
120        Select Case Err.Number
           Case Else
130             Call LogError("basMBO10YearProgramReportTop10", "Append_tblMBO10YearProgramReport_Top10")
140        End Select
150        Resume Exit_label
      'DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' Append_tblMBO10YearProgramReport_Top10_FLDxSeasonxPeriod
'
' Appends data to tblMBO10YearProgramReport_Top10 for given FLD, Season, Period
'---------------------------------------------------------------------------------------
 
Private Sub Append_tblMBO10YearProgramReport_Top10_FLDxSeasonxPeriod( _
    ByVal intFld As Integer, _
    ByVal strSeason As String, _
    ByVal intPeriod As Integer)
          
10    On Error GoTo Err_label
         
      Dim qdf As QueryDef
      Dim rst As DAO.Recordset
      Dim strSQL As String
      Dim intYear As Integer
      Dim intYear_1 As Integer
      Dim lngCountBirds As Double
      Dim lngCountBirds_1 As Double
      Dim strSpecies As String
      Dim count As Integer
      Dim Rank As Integer
      Dim strSpeciesEnglish As String
      Dim strSpeciesGroup As String
      Dim lngBackgroundColour As Long
      Dim strFLD As String                 ' "Bandings" or "Observations"

      Dim intSeason As Integer
20    intSeason = toIntSeasonFromStrSeason(strSeason)

      Dim rstTop10 As DAO.Recordset
30    Set rstTop10 = CurrentDb.OpenRecordset("tblMBO10YearProgramReport_Top10", dbOpenDynaset)

40    Select Case intFld
      Case conBND

          ' ======
          ' Banded
          ' ======
                  
          ' qryMBO10YearProgramReportTopTen_Captures_A
          ' ------------------------------------------
          ' tblMBO10YearProgramReportSpecies x tblSpecies x tblMBO10YearProgramReport_SpeciesGroups
          ' Season = [argSeason]
          ' Period = [argPeriod]
          ' AOU = AOUOrder
          ' SpeciesEnglish, SpeciesEnglishShort
          ' SpeciesGroup
          ' BackgroundColour
          ' Group by YearEx, Species
          ' CountBirds = sum Banded
          ' HAVING CountBirds > 0
          ' Sort By CountBirds DESC, AOU
          ' Report YearEx, Species, SpeciesEnglish, SpeciesEnglishShort, CountBirds, AOU, SpeciesGroup, BackgroundColour

50        strSQL = "qryMBO10YearProgramReportTopTen_Captures_A"
60        strFLD = "Bandings"

70    Case conDET

          ' ===
          ' DET
          ' ===
                    
          ' qryMBO10YearProgramReportTopTen_DET_A
          ' -------------------------------------
          ' tblMBO10YearProgramReportSpecies
          '      x tblSpecies
          '      x tblMBO10YearProgramReport_SpeciesGroups
          ' Season =[argSeason]
          ' Period = [argPeriod]
          ' Species
          ' SpeciesEnglish = SpeciesDescriptionMBO
          ' SpeciesEnglishShort
          ' AOU = AOUOrder
          ' SpeciesGroup
          ' BackgroundColour
          ' DET > 0
          ' Group by YearEx, Period, Species
          ' Order by CountBirds DESC, AOU
          ' CountBirds = sum DET
                    '
          ' We can sort on CountBirds since CountDays is the same for all species
          ' within each YearEx x Period.

80        strSQL = "qryMBO10YearProgramReportTopTen_DET_A"
90        strFLD = "Observations"

100   Case conBNDSummary

      ' ==============
      ' Banded Summary
      ' =============

      ' qryMBO10YearProgramReportTopTen_Banded_Annual_A
      ' -----------------------------------------------
      ' tblMBO10YearProgramReportSpecies
      '     x tblSpecies
      '     x tblMBO10YearProgramReport_SpeciesGroups
      ' Season = [argSeason]
      ' Species
      ' SpeciesEnglish = SpeciesDescriptionMBO
      ' SpeciesEnglishShort
      ' AOU
      ' SpeciesGroup
      ' BackgroundColour
      ' Group by YearEx, Species
      ' Having CountBirds = Sum Banded > 0
      ' Sort on YearEx, CountBirds DESC, AOU

110   strSQL = "qryMBO10YearProgramReportTopTen_Banded_Annual_A"
120   strFLD = "Bandings"

130   Case conDETSummary

      ' ===========
      ' DET Summary
      ' ===========

      ' qryMBO10YearProgramReportTopTen_DET_Annual_A
      ' --------------------------------------------
      ' tblMBO10YearProgramReportSpecies
      '     x tblSpecies
      '     x tblMBO10YearProgramReport_SpeciesGroups
      ' Season = [argSeason]
      ' Species
      ' SpeciesEnglish = SpeciesDescriptionMBO
      ' SpececiesEnglishShort
      ' AOU = AOUOrder
      ' SpeciesGroup
      ' BackgroundColour
      ' Group by YearEx, Species
      ' Having CountBirds = Sum DET > 0
      ' Sort on YearEx, CountBirds DESC, AOU
      '
      ' We can sort on CountBirds since CountDays is the same for all species
      ' within each YearEx

140   strSQL = "qryMBO10YearProgramReportTopTen_DET_Annual_A"
150   strFLD = "Observations"

160   End Select
          
170   Set qdf = CurrentDb.QueryDefs(strSQL)
180   qdf.Parameters("argSeason").value = strSeason
190   If intFld = conBND Or intFld = conDET Then
200       qdf.Parameters("argPeriod").value = intPeriod
210   End If
220   Set rst = qdf.OpenRecordset

      ' ReDim intRowsRequiredForEachYear(intYearFirst To intYearLast)

      'For intYear = intYearFirst To intYearLast
      '    intRowsRequiredForEachYear(intYear) = 0
      'Next
          
      ' Rank the pseudo-species

      Dim row As Integer

230   If Not rst.EOF Then

240       intYear_1 = Nz(rst("YearEx"))
250       lngCountBirds_1 = Nz(rst("CountBirds"))
260       count = 1
270       Rank = 1
280       row = 1

290   End If

      Dim lngStat As Long ' #Birds for Banded OR Mean for DET

300   Do While Not rst.EOF

310       intYear = Nz(rst("YearEx"))
320       lngCountBirds = Nz(rst("CountBirds"))   ' using CountBirds for ranking
330       Select Case intFld
          Case conBND, conBNDSummary
340           lngStat = Nz(rst("CountBirds"))
350       Case conDET
360           If getDETDays_SeasonYearPeriod(intSeason, intYear, intPeriod) <> 0 Then
370               lngStat = Nz(rst("CountBirds")) / getDETDays_SeasonYearPeriod(intSeason, intYear, intPeriod)
380           Else
390               lngStat = 0
400           End If
410       Case conDETSummary
420           If getDETDays_SeasonYear(intSeason, intYear) <> 0 Then
430               lngStat = Nz(rst("CountBirds")) / getDETDays_SeasonYear(intSeason, intYear)
440           Else
450               lngStat = 0
460           End If

470       End Select
480       strSpecies = Nz(rst("Species"))
490       strSpeciesEnglish = Nz(rst("SpeciesEnglishShort"))
500       If strSpeciesEnglish = "" Then
510           strSpeciesEnglish = Nz(rst("SpeciesEnglish"))
520       End If
530       strSpeciesGroup = Nz(rst("SpeciesGroup"))
540       lngBackgroundColour = Nz(rst("BackgroundColour"))

550       If (intYear <> intYear_1) Then
560           lngCountBirds_1 = -1
570           count = 1
580           Rank = 1
590           row = 1
600       End If
          
610       If Rank <= 10 Then
620         If lngCountBirds <> lngCountBirds_1 Then
630             Rank = count
640         End If
650         If Rank <= 10 Then
            
660             rstTop10.AddNew
            
670             Select Case intFld
                Case conBND, conBNDSummary
680                 rstTop10("DETorBanded") = "Banded"
690             Case conDET, conDETSummary
700                 rstTop10("DETorBanded") = "DET"
710             End Select
          
720             If intFld = conBND Or intFld = conDET Then
730                 rstTop10("Period") = intPeriod
740             Else
750                 rstTop10("Period") = 99
760             End If
                         
770             rstTop10("YearEx") = intYear
780             rstTop10("Rank") = Rank
790             rstTop10("Species") = strSpecies
800             rstTop10("SpeciesEnglish") = strSpeciesEnglish
810             rstTop10("CountBirds") = lngStat
820             rstTop10("SpeciesCategoryName") = strSpeciesGroup
830             rstTop10("BackgroundColour") = lngBackgroundColour
840             rstTop10("row") = row
850             rstTop10("Season") = strSeason
860             rstTop10.Update
                
870             row = row + 1
                
880         End If
890         count = count + 1
900         intYear_1 = intYear
910         lngCountBirds_1 = lngCountBirds
920       End If
930       rst.MoveNext
940   Loop
950   rst.Close
960   Set rst = Nothing

970   rstTop10.Close
980   Set rstTop10 = Nothing

          ' Last place ties that increase the list beyond 10
          ' are only included if 4 or more individuals are banded

990   strSQL = _
          "SELECT * " & _
          "FROM tblMBO10YearProgramReport_Top10 " & _
          "WHERE [Row] > 10 AND [CountBirds] < 4"
1000  Set rstTop10 = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)
1010  Do While Not rstTop10.EOF
1020      lngStat = Nz(rstTop10("CountBirds"))
1030      intYear = Nz(rstTop10("YearEx"))
1040      intPeriod = Nz(rstTop10("Period"))

1050      strSQL = _
              "DELETE * " & _
              "FROM tblMBO10YearProgramReport_Top10 " & _
              "WHERE [CountBirds] = " & lngStat & " AND " & _
                    "[YearEx] = " & intYear & " AND " & _
                    "[Period] = " & intPeriod
1060      CurrentDb.Execute strSQL

1070      rstTop10.MoveNext
1080  Loop
1090  rstTop10.Close
1100  Set rstTop10 = Nothing
        
      'DD Error Handler Start
Exit_label:
1110       Exit Sub
Err_label:
1120       Select Case Err.Number
           Case Else
1130      Call LogError("basMBO10YearProgramReportTop10", "Append_tblMBO10YearProgramReport_Top10_FLDxSeasonxPeriod")
1140       End Select
1150       Resume Exit_label
      'DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' OutputData
'---------------------------------------------------------------------------------------
 
Private Sub OutputData( _
    ByVal intFld As Integer, _
    ByVal strSeason As String, _
    ByVal intPeriod As Integer)

          
10    On Error GoTo Err_label
          
      Dim qdf As QueryDef
      Dim rst As DAO.Recordset
      Dim strSQL As String
      Dim intYear As Integer
      Dim intYear_1 As Integer
      Dim lngCountBirds As Double
      Dim lngCountBirds_1 As Double
      Dim strSpecies As String
      Dim count As Integer
      Dim Rank As Integer
      Dim strSpeciesEnglish As String
      Dim strSpeciesGroup As String
      Dim lngBackgroundColour As Long
      Dim strFLD As String                 ' "Bandings" or "Observations"


      Dim intSeason As Integer
20    intSeason = toIntSeasonFromStrSeason(strSeason)

      ' 60    With oSheet

30    Select Case intFld
      Case conBND

          ' ======
          ' Banded
          ' ======
                  
          ' qryMBO10YearProgramReportTopTen_Captures_A
          ' ------------------------------------------
          ' tblMBO10YearProgramReportSpecies x tblSpecies x tblMBO10YearProgramReport_SpeciesGroups
          ' Season = [argSeason]
          ' Period = [argPeriod]
          ' AOU = AOUOrder
          ' SpeciesEnglish, SpeciesEnglishShort
          ' SpeciesGroup
          ' BackgroundColour
          ' Group by YearEx, Species
          ' CountBirds = sum Banded
          ' HAVING CountBirds > 0
          ' Sort By CountBirds DESC, AOU
          ' Report YearEx, Species, SpeciesEnglish, SpeciesEnglishShort, CountBirds, AOU, SpeciesGroup, BackgroundColour

40        strSQL = "qryMBO10YearProgramReportTopTen_Captures_A"
50        strFLD = "Bandings"

60    Case conDET

          ' ===
          ' DET
          ' ===
                    
          ' qryMBO10YearProgramReportTopTen_DET_A
          ' -------------------------------------
          ' tblMBO10YearProgramReportSpecies
          '      x tblSpecies
          '      x tblMBO10YearProgramReport_SpeciesGroups
          ' Season =[argSeason]
          ' Period = [argPeriod]
          ' Species
          ' SpeciesEnglish = SpeciesDescriptionMBO
          ' SpeciesEnglishShort
          ' AOU = AOUOrder
          ' SpeciesGroup
          ' BackgroundColour
          ' DET > 0
          ' Group by YearEx, Period, Species
          ' Order by CountBirds DESC, AOU
          ' CountBirds = sum DET
                    '
          ' We can sort on CountBirds since CountDays is the same for all species
          ' within each YearEx x Period.

70        strSQL = "qryMBO10YearProgramReportTopTen_DET_A"
80        strFLD = "Observations"

90    Case conBNDSummary

      ' ==============
      ' Banded Summary
      ' =============

      ' qryMBO10YearProgramReportTopTen_Banded_Annual_A
      ' -----------------------------------------------
      ' tblMBO10YearProgramReportSpecies
      '     x tblSpecies
      '     x tblMBO10YearProgramReport_SpeciesGroups
      ' Season = [argSeason]
      ' Species
      ' SpeciesEnglish = SpeciesDescriptionMBO
      ' SpeciesEnglishShort
      ' AOU
      ' SpeciesGroup
      ' BackgroundColour
      ' Group by YearEx, Species
      ' Having CountBirds = Sum Banded > 0
      ' Sort on YearEx, CountBirds DESC, AOU

100   strSQL = "qryMBO10YearProgramReportTopTen_Banded_Annual_A"
110   strFLD = "Bandings"

120   Case conDETSummary

      ' ===========
      ' DET Summary
      ' ===========

      ' qryMBO10YearProgramReportTopTen_DET_Annual_A
      ' --------------------------------------------
      ' tblMBO10YearProgramReportSpecies
      '     x tblSpecies
      '     x tblMBO10YearProgramReport_SpeciesGroups
      ' Season = [argSeason]
      ' Species
      ' SpeciesEnglish = SpeciesDescriptionMBO
      ' SpececiesEnglishShort
      ' AOU = AOUOrder
      ' SpeciesGroup
      ' BackgroundColour
      ' Group by YearEx, Species
      ' Having CountBirds = Sum DET > 0
      ' Sort on YearEx, CountBirds DESC, AOU
      '
      ' We can sort on CountBirds since CountDays is the same for all species
      ' within each YearEx

130   strSQL = "qryMBO10YearProgramReportTopTen_DET_Annual_A"
140   strFLD = "Observations"

150   End Select
          
160   Set qdf = CurrentDb.QueryDefs(strSQL)
170   qdf.Parameters("argSeason").value = strSeason
180   If intFld = conBND Or intFld = conDET Then
190       qdf.Parameters("argPeriod").value = intPeriod
200   End If
210   Set rst = qdf.OpenRecordset

220   ReDim intRowsRequiredForEachYear(intYearFirst To intYearLast)

230   For intYear = intYearFirst To intYearLast
240       intRowsRequiredForEachYear(intYear) = 0
250   Next
          
      ' Rank the pseudo-species

260   If Not rst.EOF Then

270       intYear_1 = Nz(rst("YearEx"))
280       lngCountBirds_1 = Nz(rst("CountBirds"))
290       count = 1
300       Rank = 1

310   End If

      Dim lngStat As Long ' #Birds for Banded OR Mean for DET

320   Do While Not rst.EOF

330       intYear = Nz(rst("YearEx"))
340       lngCountBirds = Nz(rst("CountBirds"))   ' using CountBirds for ranking
350       Select Case intFld
          Case conBND, conBNDSummary
360           lngStat = Nz(rst("CountBirds"))
370       Case conDET
380           If getDETDays_SeasonYearPeriod(intSeason, intYear, intPeriod) <> 0 Then
390               lngStat = Nz(rst("CountBirds")) / getDETDays_SeasonYearPeriod(intSeason, intYear, intPeriod)
400           Else
410               lngStat = 0
420           End If
430       Case conDETSummary
440           If getDETDays_SeasonYear(intSeason, intYear) <> 0 Then
450               lngStat = Nz(rst("CountBirds")) / getDETDays_SeasonYear(intSeason, intYear)
460           Else
470               lngStat = 0
480           End If

490       End Select
500       strSpecies = Nz(rst("Species"))
510       strSpeciesEnglish = Nz(rst("SpeciesEnglishShort"))
520       If strSpeciesEnglish = "" Then
530           strSpeciesEnglish = Nz(rst("SpeciesEnglish"))
540       End If
550       strSpeciesGroup = Nz(rst("SpeciesGroup"))
560       lngBackgroundColour = Nz(rst("BackgroundColour"))

570       If (intYear <> intYear_1) Then
580           lngCountBirds_1 = -1
590           count = 1
600           Rank = 1
610       End If
          
620       If Rank <= 10 Then
630         If lngCountBirds <> lngCountBirds_1 Then
640             Rank = count
650         End If
660         If Rank <= 10 Then
           
                ' Last place ties that increase the list beyond 10
                ' are only included if 4 or more individuals are banded
                
670             If count > 10 And lngCountBirds < 4 And (intFld = conBND Or intFld = conBNDSummary) Then
680                 intRowsRequiredForEachYear(intYear) = Rank - 1
690             Else
700                 intRowsRequiredForEachYear(intYear) = intRowsRequiredForEachYear(intYear) + 1
710             End If
                
      '1090            row = row + 1
720         End If
730         count = count + 1
740         intYear_1 = intYear
750         lngCountBirds_1 = lngCountBirds
760       End If
770       rst.MoveNext
780   Loop
790   rst.Close
800   Set rst = Nothing

      '1190  row = row + 1
          
      Dim rangeTemplate As Word.range
      Dim range As Word.range
      Dim lngStart As Long
      Dim lngEnd As Long
      Dim lngStartFirstTable As Long

      ' Output the title

810   Set range = MoveInsertionPointToEndOfDocument(wd, doc)
820   If intFld = conBND Or intFld = conDET Then
830       range.InsertAfter strFLD & ", " & toPeriodTitle(strSeason, intPeriod) & ":"
840   Else
850       If strSeason = "Spring" Then
860           range.InsertAfter strFLD & ", Spring Season (March 28 - June 5):"
870       Else
880           range.InsertAfter strFLD & ", Fall Season (2005-2014: August 1 - November 6 (October 30, for 2005-2014):"
890       End If
900   End If
910   range.InsertParagraphAfter
920   range.Style = "ddTop10Title"

      Dim intNumberOfTables As Integer
930   intNumberOfTables = Fix((intYearLast - intYearFirst) / 5) + 1

940   lngStartFirstTable = doc.range.End

      Dim intIndexTable As Integer
950   For intIndexTable = 1 To intNumberOfTables
          
960       Set range = MoveInsertionPointToEndOfDocument(wd, doc)
970       Call WordGenerateTableTop10(doc, range)
980       Set range = MoveInsertionPointToEndOfDocument(wd, doc)
990       range.InsertParagraphAfter
1000      range.Style = "ddBody"
1010      Set range = MoveInsertionPointToEndOfDocument(wd, doc)

1020  Next

1030  ReDim intRowsRequiredForEachTable(1 To intNumberOfTables)
1040  For intIndexTable = 1 To intNumberOfTables
1050      intRowsRequiredForEachTable(intIndexTable) = 0
1060  Next

1070  For intYear = intYearFirst To intYearLast
1080      intIndexTable = Fix((intYear - intYearFirst) / 5) + 1
1090      If intRowsRequiredForEachYear(intYear) > intRowsRequiredForEachTable(intIndexTable) Then
1100          intRowsRequiredForEachTable(intIndexTable) = intRowsRequiredForEachYear(intYear)
1110      End If
1120  Next

1130  lngEnd = range.End
          
1140  Set range = doc.range(lngStartFirstTable, lngEnd)

      ' Append rows to the tables

      Dim rowTable As Integer

1150  For intIndexTable = 1 To intNumberOfTables
1160      For rowTable = 2 To intRowsRequiredForEachTable(intIndexTable)
1170    range.Tables(intIndexTable).Rows.Add
1180      Next
1190  Next

      ' Remove any extra columns in the last table

      Dim table As Word.table
      Dim i As Integer
      Dim intColumn As Integer

1200  Set table = range.Tables(intNumberOfTables)
1210  For i = 1 To 5 * intNumberOfTables - (intYearLast - intYearFirst + 1)
1220      table.columns(table.columns.count).Delete
1230  Next

      ' Fill in the column headers

1240  For intYear = intYearFirst To intYearLast
1250      intIndexTable = Fix((intYear - intYearFirst) / 5) + 1
1260      intColumn = 1 + (intYear - intYearFirst) Mod 5
1270      range.Tables(intIndexTable).Cell(1, intColumn).range.Text = intYear
1280  Next

1290  For intIndexTable = 1 To intNumberOfTables
1300      range.Tables(intIndexTable).Rows(1).range.Style = "ddMultiYearTop10ColumnHeader"
      '1310        .Name = "Calibri"
      '1320        .Size = 10
      '      '           .Color = vbWhite
      '      '           .Bold = True
      '      '           .Italic = False
      '1330      End With
1310  Next

      ' Fill in the "No xxx during this period" entries

1320  For intYear = intYearFirst To intYearLast
1330      intIndexTable = Fix((intYear - intYearFirst) / 5) + 1
1340      intColumn = 1 + (intYear - intYearFirst) Mod 5
1350      If intRowsRequiredForEachYear(intYear) = 0 Then
1360          range.Tables(intIndexTable).Cell(2, intColumn).range.Select
1370           With doc.ActiveWindow.Selection
1380              .TypeText "No " & IIf(intFld = conBND, "bandings", "observations")
1390              .TypeParagraph
1400              .TypeText "during"
1410              .TypeParagraph
1420              .TypeText "this period"
1430          End With
1440          range.Tables(intIndexTable).Cell(2, intColumn).range.Style = "ddMultiYearTop10NoXXXDuringPeriod"
1450          range.Tables(intIndexTable).Cell(2, intColumn).VerticalAlignment = wdCellAlignVerticalCenter
1460      End If
1470  Next

      ' Fill in the data

1480  Select Case intFld
      Case conBND
1490      strSQL = "qryMBO10YearProgramReportTopTen_Captures_A"
1500  Case conDET
1510      strSQL = "qryMBO10YearProgramReportTopTen_DET_A"
1520  Case conBNDSummary
1530      strSQL = "qryMBO10YearProgramReportTopTen_Banded_Annual_A"
1540  Case conDETSummary
1550      strSQL = "qryMBO10YearProgramReportTopTen_DET_Annual_A"
          
1560  End Select

1570  Set qdf = CurrentDb.QueryDefs(strSQL)
1580  qdf.Parameters("argSeason").value = strSeason
1590  If intFld = conBND Or intFld = conDET Then
1600      qdf.Parameters("argPeriod").value = intPeriod
1610  End If
1620  Set rst = qdf.OpenRecordset

      Dim rowWordTable As Integer

1630  If Not rst.EOF Then

1640      intYear_1 = Nz(rst("YearEx"))
1650      count = 1

1660  End If

1670  Do While Not rst.EOF

1680      intYear = Nz(rst("YearEx"))
1690      Select Case intFld
          Case conBND, conBNDSummary
1700          lngStat = Nz(rst("CountBirds"))
1710      Case conDET
1720          If getDETDays_SeasonYearPeriod(intSeason, intYear, intPeriod) <> 0 Then
1730              lngStat = Nz(rst("CountBirds")) / getDETDays_SeasonYearPeriod(intSeason, intYear, intPeriod)
1740          Else
1750              lngStat = 0
1760          End If
1770      Case conDETSummary
1780          If getDETDays_SeasonYear(intSeason, intYear) <> 0 Then
1790              lngStat = Nz(rst("CountBirds")) / getDETDays_SeasonYear(intSeason, intYear)
1800          Else
1810              lngStat = 0
1820          End If
1830      End Select
             
      '    lngCountBirds = Nz(rst("CountBirds"))

1840      strSpecies = Nz(rst("Species"))

1850      strSpeciesEnglish = Nz(rst("SpeciesEnglishShort"))
1860      If strSpeciesEnglish = "" Then
1870          strSpeciesEnglish = Nz(rst("SpeciesEnglish"))
1880      End If
1890      lngBackgroundColour = Nz(rst("BackgroundColour"))
          
1900      If (intYear <> intYear_1) Then
1910          count = 1
1920      End If

1930      If count <= intRowsRequiredForEachYear(intYear) Then
1940          intIndexTable = Fix((intYear - intYearFirst) / 5) + 1
1950          intColumn = 1 + (intYear - intYearFirst) Mod 5
1960          range.Tables(intIndexTable).Cell(count + 1, intColumn).range.Text = _
                  strSpeciesEnglish & " (" & lngStat & ")"
1970          range.Tables(intIndexTable).Cell(count + 1, intColumn).Shading.BackgroundPatternColor = _
                  lngBackgroundColour
1980          With range.Tables(intIndexTable).Cell(count + 1, intColumn).range
      '            .Name = "Calibri"
1990              If strSpecies = "MYWA" Then
2000                  .Style = "ddMultiYearTop10DataMYWA"
           '           .Size = 8
2010              Else
2020                  .Style = "ddMultiYearTop10Data"
             '         .Size = 9
2030              End If
      '            .color = vbBlack
      '            .Bold = False
      '            .Italic = False
2040          End With

2050          count = count + 1
2060      End If
2070      intYear_1 = intYear

2080      rst.MoveNext
2090  Loop
2100  rst.Close
2110  Set rst = Nothing

      ' Merge unwanted cells

2120  For intYear = intYearFirst To intYearLast
2130      intIndexTable = Fix((intYear - intYearFirst) / 5) + 1
2140      intColumn = 1 + (intYear - intYearFirst) Mod 5
          
2150      If intRowsRequiredForEachYear(intYear) = 0 And _
        intRowsRequiredForEachTable(intIndexTable) >= 2 Then
2160    range.Tables(intIndexTable).Cell(2, intColumn).Merge _
            range.Tables(intIndexTable).Cell(intRowsRequiredForEachTable(intIndexTable) + 1, intColumn)
2170      End If
          
2180      If intRowsRequiredForEachYear(intYear) > 0 Then
2190    If intRowsRequiredForEachYear(intYear) + 1 < intRowsRequiredForEachTable(intIndexTable) Then
2200        If intRowsRequiredForEachTable(intIndexTable) >= 2 Then
2210            range.Tables(intIndexTable).Cell(intRowsRequiredForEachYear(intYear) + 2, intColumn).Merge _
                    range.Tables(intIndexTable).Cell(intRowsRequiredForEachTable(intIndexTable) + 1, intColumn)
2220        End If
2230    End If
2240      End If
        
2250  Next

      ' 2810  End With

      'DD Error Handler Start
Exit_label:
2260       Exit Sub
Err_label:
2270       Select Case Err.Number
           Case Else
2280      Call LogError("basMBO10YearProgramReportTop10", "OutputData")
2290       End Select
2300       Resume Exit_label
      'DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' toRowFromPeriod
'---------------------------------------------------------------------------------------

Private Function toRowFromPeriod(ByVal intPeriod As Integer) As Integer
10       On Error GoTo Err_label

20        toRowFromPeriod = 1 + intPeriod

    'DD Error Handler Start
Exit_label:
30        Exit Function
Err_label:
40        Select Case Err.Number
    Case Else
50       Call LogError("basMBO10YearProgramReportTop10", "toRowFromPeriod")
60        End Select
70        Resume Exit_label
    ' DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' toColFromYear
'---------------------------------------------------------------------------------------

Private Function toColFromYear(ByVal intYear As Integer) As Integer
10       On Error GoTo Err_label

20        toColFromYear = 2 + intYear - intYearFirst

    'DD Error Handler Start
Exit_label:
30        Exit Function
Err_label:
40        Select Case Err.Number
    Case Else
50       Call LogError("basMBO10YearProgramReportTop10", "toColFromYear")
60        End Select
70        Resume Exit_label
    ' DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' WordGenerateTableTop10
'---------------------------------------------------------------------------------------

Private Sub WordGenerateTableTop10( _
    ByRef doc As Word.Document, _
    ByRef range As Word.range)

10    On Error GoTo Err_label

      Dim intCountYears As Integer
20    intCountYears = (intYearLast - intYearFirst + 1)

      Dim col As Integer

30    doc.Tables.Add range:=range, NumRows:=2, NumColumns:=5
          
40    range.Expand (wdTable)
50    With range.Tables(1)

60        .Borders.InsideLineStyle = wdLineStyleSingle
70        .Borders.OutsideLineStyle = wdLineStyleSingle

80        .LeftPadding = doc.Application.CentimetersToPoints(0.05)
90        .RightPadding = doc.Application.CentimetersToPoints(0.05)
100       .TopPadding = doc.Application.CentimetersToPoints(0#)
110       .BottomPadding = doc.Application.CentimetersToPoints(0#)
          
          ' Center the table
          
120       .Rows.Alignment = wdAlignRowCenter

          Dim dblTableWidth As Double
          Dim dblColumnWidth As Double
          
130       dblTableWidth = doc.Application.InchesToPoints(8.5 - 0.75 - 0.75)
140       dblColumnWidth = dblTableWidth / 5
              
150       For col = 1 To 5
160           .columns(col).Width = dblColumnWidth
170       Next

          ' Format Header Row
          
180       Call FormatWordTableRowAsHeader(.Rows(1), "ddTop10HeaderRow")
190       .Rows(1).range.ParagraphFormat.Alignment = wdAlignParagraphCenter

200   .Rows(2).range.Style = "ddTop10Data"
                    
          ' Repeat heading row at the top of subsequent pages

210       .Rows.WrapAroundText = False
          
220   End With

          'DD Error Handler Start
Exit_label:
230       Exit Sub
Err_label:
240       Select Case Err.Number
          Case Else
250            Call LogError("basMBO10YearProgramReportTop10", "WordGenerateTableTop10")
260       End Select
270       Resume Exit_label
          ' DD Error Handler End

End Sub
