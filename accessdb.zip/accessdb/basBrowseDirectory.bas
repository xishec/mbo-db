Option Compare Database
Option Explicit
'
''Private Type BROWSEINFO
''    hwndOwner As Long
''    pidlRoot As Long
''    sDisplayName As String
''    sTitle As String
''    ulFlags As Long
''    lpfn As Long
''    lParam As Long
''    iImage As Long
''End Type
''
''Private Declare Function SHBrowseForFolder Lib "shell32.dll" (bBrowse As BROWSEINFO) As Long
''Private Declare Function SHGetPathFromIDList Lib "shell32.dll" (ByVal lItem As Long, ByVal sDir As String) As Long
'
'#If VBA7 Then
'    Private Type BROWSEINFO
'        hOwner As LongPtr
'        pidlRoot As LongPtr
'        pszDisplayName As String
'        lpszTitle As String
'        ulFlags As Long
'        lpfn As LongPtr
'        lParam As LongPtr
'        iImage As Long
'    End Type
'
'    Private Declare PtrSafe Function SHBrowseForFolder Lib "shell32.dll" _
'        (lpBrowseInfo As BROWSEINFO) As LongPtr
'    Private Declare PtrSafe Function SHGetPathFromIDList Lib "shell32.dll" _
'        (ByVal pidl As LongPtr, ByVal pszPath As String) As Boolean
'
''    Private Declare PtrSafe Function SHBrowseForFolder Lib "shell32.dll" Alias "SHBrowseForFolderA" _
''        (lpBrowseInfo As BROWSEINFO) As LongPtr
''    Private Declare PtrSafe Function SHGetPathFromIDList Lib "shell32.dll" Alias "SHGetPathFromIDListA" _
''        (ByVal pidl As LongPtr, ByVal pszPath As String) As Boolean
'
'#Else
'    Private Type BROWSEINFO
'        hwndOwner As Long
'        pidlRoot As Long
'        sDisplayName As String
'        sTitle As String
'        ulFlags As Long
'        lpfn As Long
'        lParam As Long
'        iImage As Long
'    End Type
'
'    Private Declare Function SHBrowseForFolder Lib "shell32.dll" (bBrowse As BROWSEINFO) As Long
'    Private Declare Function SHGetPathFromIDList Lib "shell32.dll" (ByVal lItem As Long, ByVal sDir As String) As Long
'
' #End If
'
'' Let the user browse for a directory. Return the
'' selected directory. Return an empty string if
'' the user cancels.
'Public Function BrowseForDirectory() As String
'      Dim browse_info As BROWSEINFO
'      Dim item As Long
'      Dim dir_name As String
'
'
'         'modified for MS Access/VBA
'10       With browse_info
'20           .hwndOwner = Application.hWndAccessApp
'30           .pidlRoot = 0
'40           .sDisplayName = Space$(260)
'50           .sTitle = "Select Directory"
'60           .ulFlags = 1 ' Return directory name.
'70           .lpfn = 0
'80           .lParam = 0
'90           .iImage = 0
'100      End With
'
'110      item = SHBrowseForFolder(browse_info)
'120      If item Then
'130          dir_name = Space$(260)
'140          If SHGetPathFromIDList(item, dir_name) Then
'150              BrowseForDirectory = Left(dir_name, _
'                                      InStr(dir_name, chr$(0)) - 1)
'160          Else
'170              BrowseForDirectory = ""
'180          End If
'190      End If
'End Function
'
'
'
