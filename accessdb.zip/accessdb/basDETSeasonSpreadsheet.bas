'---------------------------------------------------------------------------------------
' Module: basDETSeasonSpreadsheet
' Author: David Davey
'---------------------------------------------------------------------------------------

Option Compare Database
Option Explicit

Const strDETSeasonSpeciesTable As String = "tblDETSeasonSpecies_temp"

Const rowYear As Long = 1                         ' report year
Const rowPeriod As Long = 2
Const rowMonth As Long = 3
Const rowDay As Long = 4
Const rowSp As Long = 5
Const rowInd As Long = 6
Const rowFirst As Long = 7
Const colYearCopyFirst = 2                        ' report year
Private colYearCopyTotalFirst As Long
Private colYearCopyMeanFirst As Long

' the "By Period" worksheets

Const rowPeriod_P As Long = 1
Const rowYear_P As Long = 2
Const rowHeader_P As Long = 3
Const rowSp_P As Long = 4
Const rowInd_P As Long = 5
Const rowFirst_P As Long = 6
Private rowLast_P As Long

Private lngBackgroundColourPeriod As Long
Private lngBackgroundColourYear As Long
Private lngBackgroundColourPeriodTotal As Long
Private lngBackgroundColourYearTotal As Long
Private lngBackgroundColourAllYearTotal As Long
Private lngBackgroundColourPeriodCount As Long

Private lngBackgroundColourByPeriodYearCount As Long      ' light blue        Period>Year: Year Count
Private lngBackgroundColourByPeriodYearTotal As Long      ' light green       Period>Year: Year Total
Private lngBackgroundColourByPeriodYearMean As Long       ' light orange      Period>Year: Year Mean
Private lngBackgroundColourByPeriodPeriodCount As Long    ' medium blue       Period>Year: Period Count
Private lngBackgroundColourByPeriodPeriodMean As Long     ' medium orange     Period>Year: Period Mean
Private lngBackgroundColourByPeriodPeriodTotal As Long    ' medium green      Year>Period: Period Total
Private lngBackgroundColourByPeriodAllCount As Long       ' dark blue       Period>Year: Period Count
Private lngBackgroundColourByPeriodAllMean As Long        ' dark orange     Period>Year: Period Mean
Private lngBackgroundColourByPeriodAllTotal As Long       ' dark green      Year>Period: Period Total


Const strNumberFormatPeriod As String = "#0.00;-0[red];;@"
Const strNumberFormatYear As String = "#0.00;-0[red];;@"
Const strNumberFormatYearAll As String = "#0.00;-0[red];;@"
Const strNumberFormatInd = "#0.00;-0[red];;@"
Const strNumberFormatYearAllSp = "#0;-0[red];;@"
Const strNumberFormatYearAllInd = "#0;-0[red];;@"
Const strNumberFormatYearAllData = "#0;-0[red];;@"
Const strNumberFormatYearSp = "#0;-0[red];;@"
Const strNumberFormatYearInd = "#0;-0[red];;@"
Const strNumberFormatCount = "#0;-0[red];;@"
Const strNumberFormatTotal = "#0;-0[red];;@"
Const strNumberFormatMean = "#0.00;-0[red];;@"

Private intYearFrom As Integer
Private intYearTo As Integer
Private strLocation As String
Private oExcel As Excel.Application
Private oBook As Excel.Workbook

Private intPeriodDimension As Integer
Private intPeriodTo As Integer
Private colCount() As Long    ' colCount(intYearFrom TO intYearTo, 1 TO intPeriodDimension)
Private colTotal() As Long    ' colTotal(intYearFrom TO intYearTo, 1 TO intPeriodDimension)
Private colMean() As Long     ' colMean(intYearFrom TO intYearTo, 1 TO intPeriodDimension)

Private rowLast As Long
Private row As Long
Private col As Long
Private colPeriodFirst As Long
Private colPeriodLast As Long
Private strSeasonSum As String
Private strSeasonCount As String
Private strYearAllSum As String
Private strYearAllCount As String
Private colYearAll                             ' column for the all years info.
Private colFirst As Long                       ' column for the first day

Private oSheet As Excel.Worksheet

Private rst As DAO.Recordset
Private datDateEx As Date
Private intStat As Integer
Private intYearEx As Integer
Private intPeriod As Integer

Private intYearEx_previous As Integer
Private intPeriod_previous As Integer
Private datDateEx_previous As Date

Dim strStatFieldname As String

'---------------------------------------------------------------------------------------
' DETSeasonSpreadsheet
'---------------------------------------------------------------------------------------

Public Sub DETSeasonSpreadsheet( _
    ByVal argYearFrom As Integer, ByVal argYearTo As Integer, ByVal argLocation As String, _
    ByRef argExcel As Excel.Application, ByRef argBook As Excel.Workbook)
10        On Error GoTo Err_label
          
20    intYearFrom = argYearFrom
30    intYearTo = argYearTo
40    strLocation = argLocation
50    Set oExcel = argExcel
60    Set oBook = argBook

70    lngBackgroundColourPeriodCount = RGB(219, 238, 243)   ' light blue        Year>Period: Period Count, Year Count
80    lngBackgroundColourPeriodTotal = RGB(194, 214, 154)   ' light green       Year>Period: Period Total
90    lngBackgroundColourPeriod = RGB(250, 192, 144)        ' light orange      Year>Period: Period Mean
100   lngBackgroundColourYear = RGB(228, 109, 10)           ' medium orange     Year>Period: Year Mean
110   lngBackgroundColourYearTotal = RGB(146, 208, 80)      ' medium green      Year>Period: Year Total
120   lngBackgroundColourAllYearTotal = RGB(79, 98, 40)

130   lngBackgroundColourByPeriodYearCount = RGB(219, 238, 243)   ' light blue        Period>Year: Year Count
140   lngBackgroundColourByPeriodYearTotal = RGB(194, 214, 154)   ' light green       Period>Year: Year Total
150   lngBackgroundColourByPeriodYearMean = RGB(250, 192, 144)    ' light orange      Period>Year: Year Mean
160   lngBackgroundColourByPeriodPeriodCount = RGB(147, 205, 221) ' medium blue       Period>Year: Period Count
170   lngBackgroundColourByPeriodPeriodMean = RGB(228, 109, 10)   ' medium orange     Period>Year: Period Mean
180   lngBackgroundColourByPeriodPeriodTotal = RGB(146, 208, 80)  ' medium green      Period>Year: Period Total
190   lngBackgroundColourByPeriodAllCount = RGB(51, 139, 163)     ' dark blue         Period>Year: All Count
200   lngBackgroundColourByPeriodAllMean = RGB(161, 77, 7)        ' dark orange       Period>Year: All Mean
210   lngBackgroundColourByPeriodAllTotal = RGB(86, 132, 36)      ' dark green        Period>Year: All Total

'   oExcel.Visible = True
             
' tblMBO10YearProgramReportSpecies
' --------------------------------
' same as tblDETSpecies, except
' SNGO GSGO LSGO merged into SNGO
' TRFL ALFL WIFL merged into TRFL
' -------------------------------
' WHERE YearEx BETWEEN intYearFrom AND intYearTo
' WHERE Location = strLocation
'
' Season
' YearEx
' Period
' DateEx
' Species
' Banded
' Returns
' Repeats
' DET
            
220   Call load_tbl10YearProgramReportSpecies_Classic(intYearFrom, intYearTo)

' Dimension for Period

230   intPeriodDimension = DMax("Period", "tblMBO10YearProgramReportSpecies", "True")

' Allocate (more than enough) space for  colCount(), colTotal(), colMean() As Long

240   ReDim colCount(intYearFrom To intYearTo, 1 To intPeriodDimension)
250   ReDim colTotal(intYearFrom To intYearTo, 1 To intPeriodDimension)
260   ReDim colMean(intYearFrom To intYearTo, 1 To intPeriodDimension)
             
      ' Winter
       
      Dim strSeason1 As String
      Dim strSeason2 As String
      Dim strSheetNameSeason As String

      Dim strSheetNameStat As String

270   strSeason1 = "Winter"
280   strSeason2 = ""
290   strSheetNameSeason = Trim(strSeason1 & " " & strSeason2)
300   strStatFieldname = "DET"
310   strSheetNameStat = "DET"
320   Call DETSeasonSpreadsheet_Season(strSeason1, strSeason2, strSheetNameSeason, strSheetNameStat, strStatFieldname)

330   strSeason1 = "Winter"
340   strSeason2 = ""
350   strSheetNameSeason = Trim(strSeason1 & " " & strSeason2)
360   strStatFieldname = "Banded"
370   strSheetNameStat = "Banded"
380   Call DETSeasonSpreadsheet_Season(strSeason1, strSeason2, strSheetNameSeason, strSheetNameStat, strStatFieldname)

390   strSeason1 = "Winter"
400   strSeason2 = ""
410   strSheetNameSeason = Trim(strSeason1 & " " & strSeason2)
420   strStatFieldname = "Returns"
430   strSheetNameStat = "Returns"
440   Call DETSeasonSpreadsheet_Season(strSeason1, strSeason2, strSheetNameSeason, strSheetNameStat, strStatFieldname)

450   strSeason1 = "Winter"
460   strSeason2 = ""
470   strSheetNameSeason = Trim(strSeason1 & " " & strSeason2)
480   strStatFieldname = "Repeats"
490   strSheetNameStat = "Repeats"
500   Call DETSeasonSpreadsheet_Season(strSeason1, strSeason2, strSheetNameSeason, strSheetNameStat, strStatFieldname)

510   strSeason1 = "Summer"
520   strSeason2 = "Nestbox"
530   strSheetNameSeason = Trim(strSeason1 & " " & strSeason2)
540   strStatFieldname = "DET"
550   strSheetNameStat = "DET"
560   Call DETSeasonSpreadsheet_Season(strSeason1, strSeason2, strSheetNameSeason, strSheetNameStat, strStatFieldname)

570   strSeason1 = "Summer"
580   strSeason2 = "NestBox"
590   strSheetNameSeason = Trim(strSeason1 & " " & strSeason2)
600   strStatFieldname = "Banded"
610   strSheetNameStat = "Banded"
620   Call DETSeasonSpreadsheet_Season(strSeason1, strSeason2, strSheetNameSeason, strSheetNameStat, strStatFieldname)

630   strSeason1 = "Summer"
640   strSeason2 = "NestBox"
650   strSheetNameSeason = Trim(strSeason1 & " " & strSeason2)
660   strStatFieldname = "Returns"
670   strSheetNameStat = "Returns"
680   Call DETSeasonSpreadsheet_Season(strSeason1, strSeason2, strSheetNameSeason, strSheetNameStat, strStatFieldname)

690   strSeason1 = "Summer"
700   strSeason2 = "NestBox"
710   strSheetNameSeason = Trim(strSeason1 & " " & strSeason2)
720   strStatFieldname = "Repeats"
730   strSheetNameStat = "Repeats"
740   Call DETSeasonSpreadsheet_Season(strSeason1, strSeason2, strSheetNameSeason, strSheetNameStat, strStatFieldname)

750   strSeason1 = "Summer"
760   strSeason2 = ""
770   strSheetNameSeason = Trim(strSeason1 & " " & strSeason2)
780   strStatFieldname = "DET"
790   strSheetNameStat = "DET"
800   Call DETSeasonSpreadsheet_Season(strSeason1, strSeason2, strSheetNameSeason, strSheetNameStat, strStatFieldname)

810   strSeason1 = "Summer"
820   strSeason2 = ""
830   strSheetNameSeason = Trim(strSeason1 & " " & strSeason2)
840   strStatFieldname = "Banded"
850   strSheetNameStat = "Banded"
860   Call DETSeasonSpreadsheet_Season(strSeason1, strSeason2, strSheetNameSeason, strSheetNameStat, strStatFieldname)

870   strSeason1 = "Summer"
880   strSeason2 = ""
890   strSheetNameSeason = Trim(strSeason1 & " " & strSeason2)
900   strStatFieldname = "Returns"
910   strSheetNameStat = "Returns"
920   Call DETSeasonSpreadsheet_Season(strSeason1, strSeason2, strSheetNameSeason, strSheetNameStat, strStatFieldname)

930   strSeason1 = "Summer"
940   strSeason2 = ""
950   strSheetNameSeason = Trim(strSeason1 & " " & strSeason2)
960   strStatFieldname = "Repeats"
970   strSheetNameStat = "Repeats"
980   Call DETSeasonSpreadsheet_Season(strSeason1, strSeason2, strSheetNameSeason, strSheetNameStat, strStatFieldname)

990   strSeason1 = "Nestbox"
1000  strSeason2 = ""
1010  strSheetNameSeason = Trim(strSeason1 & " " & strSeason2)
1020  strStatFieldname = "DET"
1030  strSheetNameStat = "DET"
1040  Call DETSeasonSpreadsheet_Season(strSeason1, strSeason2, strSheetNameSeason, strSheetNameStat, strStatFieldname)

1050  strSeason1 = "Nestbox"
1060  strSeason2 = ""
1070  strSheetNameSeason = Trim(strSeason1 & " " & strSeason2)
1080  strStatFieldname = "Banded"
1090  strSheetNameStat = "Banded"
1100  Call DETSeasonSpreadsheet_Season(strSeason1, strSeason2, strSheetNameSeason, strSheetNameStat, strStatFieldname)

1110  strSeason1 = "Nestbox"
1120  strSeason2 = ""
1130  strSheetNameSeason = Trim(strSeason1 & " " & strSeason2)
1140  strStatFieldname = "Returns"
1150  strSheetNameStat = "Returns"
1160  Call DETSeasonSpreadsheet_Season(strSeason1, strSeason2, strSheetNameSeason, strSheetNameStat, strStatFieldname)

1170  strSeason1 = "Nestbox"
1180  strSeason2 = ""
1190  strSheetNameSeason = Trim(strSeason1 & " " & strSeason2)
1200  strStatFieldname = "Repeats"
1210  strSheetNameStat = "Repeats"
1220  Call DETSeasonSpreadsheet_Season(strSeason1, strSeason2, strSheetNameSeason, strSheetNameStat, strStatFieldname)

'1240  On Error Resume Next
'1250  Call ExcelDeleteAllButFirstWorksheet(oBook)
'1260  On Error GoTo Err_label

1270  With oBook.Worksheets(1)
1280      .Name = "Notes"
1290      .Cells(1, 1) = "SNGO, LSGO, GSGO have been merged into SNGO"
1300      .Cells(2, 1) = "TRFL, WIFL, ALFL have been merged into TRFL"
1310      .Cells(3, 1) = "The spreadsheet counts pseudospecies, not species"
1320      .Cells(4, 1) = "The DET sheets have hidden columns for COUNTs and MEANs"

1330  End With

          
       'DD Error Handler Start
Exit_label:
1340       Exit Sub
Err_label:
1350       Select Case Err.Number
           Case Else
1360            Call LogError("Form_basDETSeasonSpreadsheet", "DETSeasonSpreadsheet_Season")
1370       End Select
1380       Resume Exit_label
      'DD Error Handler End

End Sub

Public Sub DETSeasonSpreadsheet_Season( _
    ByVal strSeason1 As String, ByVal strSeason2 As String, ByVal strSheetNameSeason As String, ByVal strSheetNameStat, ByVal strStatFieldname As String)

      Dim strSQL As String
      Dim strSpecies As String
      Dim rstSpecies As DAO.Recordset

      Dim colFirstPeriod As Long
      Dim colFirstYear As Long
      Dim intYear As Integer

10       On Error GoTo Err_label

20        For intPeriod = 1 To intPeriodDimension
30            For intYear = intYearFrom To intYearTo
40                colMean(intYear, intPeriod) = 0
50                colTotal(intYear, intPeriod) = 0
60                colMean(intYear, intPeriod) = 0
70            Next
80        Next

      ' tblDETSeasonSpecies_temp
      ' ------------------------
      ' given an interval of years, given a statistic (e.g. DET), given some seasons
      ' list of the species that have a non-zero value for the statistic for the seasons in any of the years
      ' the list is ordered by AOU
      ' ------------------------
      ' Species = subspecies code
      ' Row     = corresponding row in the generated spreadsheet
          

      ' Zap tblDETSeasonSpecies_temp

90        CurrentDb.Execute "DELETE * FROM tblDETSeasonSpecies_temp"

      ' Load tblDETSeasonSpecies_temp

      Dim qdf As DAO.QueryDef

100   Select Case strStatFieldname
      Case "DET"
110   Set qdf = CurrentDb.QueryDefs("qryDETSeasonSpecies_DET_Append")
120   Case "Banded"
130   Set qdf = CurrentDb.QueryDefs("qryDETSeasonSpecies_Banded_Append")
140   Case "Returns"
150   Set qdf = CurrentDb.QueryDefs("qryDETSeasonSpecies_Returns_Append")
160   Case "Repeats"
170     Set qdf = CurrentDb.QueryDefs("qryDETSeasonSpecies_Repeats_Append")
180   End Select
190   qdf.Parameters("argSeason1").value = strSeason1
200   qdf.Parameters("argSeason2").value = strSeason2

210   qdf.Execute

      ' Fill in the row column in the temp. species table

220   Set rstSpecies = CurrentDb.OpenRecordset("SELECT * FROM tblDETSeasonSpecies_temp ORDER BY AOU", dbOpenDynaset)
230   row = rowFirst
240   Do While Not rstSpecies.EOF
250       rstSpecies.Edit
260       rstSpecies("row") = row
270       row = row + 1
280       rstSpecies.Update
290       rstSpecies.MoveNext
300   Loop
310   rstSpecies.Close
320   Set rstSpecies = Nothing

330   rowLast = row - 1

      ' Generate the species column

340   Set oSheet = oBook.Worksheets.Add(After:=oBook.Worksheets(oBook.Worksheets.count))
350   oSheet.Name = strSheetNameSeason & " " & strSheetNameStat
360   With oSheet

370   If rowFirst <= rowLast Then

380       .Cells(rowSp, 1) = "#sp"
390       .Cells(rowInd, 1) = "#ind"
          
400       Set rstSpecies = CurrentDb.OpenRecordset("SELECT * FROM tblDETSeasonSpecies_temp ORDER BY AOU", dbOpenDynaset)
410       row = rowFirst
420       Do While Not rstSpecies.EOF
430           strSpecies = Nz(rstSpecies("Species"))
440           .Cells(row, 1) = strSpecies
450           row = row + 1
460           rstSpecies.MoveNext
470       Loop
480       rstSpecies.Close
490       Set rstSpecies = Nothing
          
          ' Reserve the year TOTAL copy columns
          
500       colYearCopyTotalFirst = colYearCopyFirst
510       col = colYearCopyTotalFirst
520       For intYear = intYearFrom To intYearTo
530           .Cells(rowYear, col) = intYear
540           col = col + 1
550       Next
          
          ' Reserve the year MEAN copy columns for DET
          
560       If strStatFieldname = "DET" Then
570           colYearCopyMeanFirst = col
580           For intYear = intYearFrom To intYearTo
590         .Cells(rowYear, col) = intYear
600         col = col + 1
610           Next
620       End If
          
630       colYearAll = col
640       .Cells(1, colYearAll) = intYearFrom & "-" & Right(CStr(intYearTo), 2)
650       col = col + 1
          
660       colFirst = col
          
670       colFirstPeriod = colFirst
680       colFirstYear = colFirst
          
          ' the following query:
          ' given an interval of years, given a statistic (e.g. DET), given some seasons
          ' list of the species that have a non-zero value for the statistic for the seasons in any of the years
          ' the list is ordered by AOU
          ' -------------------
          ' tblMBO10YearProgramReportSpecies x tblDETSeasonSpecies_temp
          ' WHERE Season IN strSeasonList
          ' WHERE statistic > 0
          ' report: Species, Statistic, DateEx, YearEx, Period, Row
          
          
          ' Dim qdf As DAO.QueryDef
          
690       Select Case strStatFieldname
          Case "DET"
700           Set qdf = CurrentDb.QueryDefs("qryDETSeason_DET")
710       Case "Banded"
720           Set qdf = CurrentDb.QueryDefs("qryDETSeason_Banded")
730       Case "Repeats"
740           Set qdf = CurrentDb.QueryDefs("qryDETSeason_Repeats")
750       Case "Returns"
760           Set qdf = CurrentDb.QueryDefs("qryDETSeason_Returns")
770       End Select
780       qdf.Parameters("argSeason1").value = strSeason1
790       qdf.Parameters("argSeason2").value = strSeason2
          
800       intPeriodTo = 0
          
810       Set rst = qdf.OpenRecordset
820       If Not rst.EOF Then
              ' process first record
830           Call DETSEasonSpreadsheet_Season_get
840           Call DETSeasonSpreadsheet_Season_HR
850           Call DETSeasonSpreadsheet_Season_H1
860           Call DETSeasonSpreadsheet_Season_H2
870           Call DETSeasonSpreadsheet_Season_H3
880           Call DETSeasonSpreadsheet_Season_D
890           datDateEx_previous = datDateEx
900           intPeriod_previous = intPeriod
910           intYearEx_previous = intYearEx
920           rst.MoveNext
930           Do While Not rst.EOF
              ' process second, third, ... records
940               Call DETSEasonSpreadsheet_Season_get
950               If intYearEx_previous <> intYearEx Or intPeriod_previous <> intPeriod Or datDateEx_previous <> datDateEx Then
960                   Call DETSeasonSpreadsheet_Season_F3
970                   If intYearEx_previous <> intYearEx Or intPeriod_previous <> intPeriod Then
980                       Call DETSeasonSpreadsheet_Season_F2
990                       If intYearEx_previous <> intYearEx Then
1000                          SysCmd acSysCmdSetStatus, strSeason1 & " " & strSeason2 & " " & strStatFieldname & " " & intYearEx
1010                          Call DETSeasonSpreadsheet_Season_F1
1020                          Call DETSeasonSpreadsheet_Season_H1
1030                      End If
1040                      Call DETSeasonSpreadsheet_Season_H2
1050                  End If
1060                  Call DETSeasonSpreadsheet_Season_H3
1070              End If
1080              Call DETSeasonSpreadsheet_Season_D
1090              datDateEx_previous = datDateEx
1100              intPeriod_previous = intPeriod
1110              intYearEx_previous = intYearEx
1120              rst.MoveNext
1130          Loop
1140          Call DETSeasonSpreadsheet_Season_F3
1150          Call DETSeasonSpreadsheet_Season_F2
1160          Call DETSeasonSpreadsheet_Season_F1
1170          Call DETSeasonSpreadsheet_Season_FR
1180      End If
1190      rst.Close
1200      Set rst = Nothing
          
          Dim colLast As Long
1210      colLast = col - 1
                    
1220      .range(.Cells(rowYear, 1), .Cells(rowYear, colLast)).Interior.Color = vbBlack
1230      .range(.Cells(rowYear, 1), .Cells(rowYear, colLast)).Font.Color = vbWhite
1240      .range(.Cells(rowPeriod, 1), .Cells(rowPeriod, colLast)).Interior.Color = vbBlack
1250      .range(.Cells(rowPeriod, 1), .Cells(rowPeriod, colLast)).Font.Color = vbWhite
1260      .range(.Cells(rowMonth, 1), .Cells(rowMonth, colLast)).Interior.Color = RGB(128, 128, 128)
1270      .range(.Cells(rowMonth, 1), .Cells(rowMonth, colLast)).Font.Color = vbWhite
1280      .range(.Cells(rowDay, 1), .Cells(rowDay, colLast)).Interior.Color = RGB(128, 128, 128)
1290      .range(.Cells(rowDay, 1), .Cells(rowDay, colLast)).Font.Color = vbWhite
1300      .range(.columns(1), .columns(col)).HorizontalAlignment = xlCenter
          
1310      .range(.Cells(1, 1), .Cells(1, colLast)).SpecialCells(xlCellTypeVisible).EntireColumn.AutoFit
          
          ' For DET, hide any empty copy-Mean columns
          ' For Banded, Returns, Repeats, hide any empty copy-Total columns
          
          Dim colStat As Long
          
1320      Select Case strStatFieldname
          Case "DET"
1330          For colStat = colYearCopyTotalFirst To colYearCopyTotalFirst + (intYearTo - intYearFrom)
1340            If .Cells(rowSp, colStat) = "" Then
1350               .columns(colStat).Hidden = True
1360            End If
1370          Next
1380      Case Else
1390          For colStat = colYearCopyMeanFirst To colYearCopyMeanFirst + (intYearTo - intYearFrom)
1400            If .Cells(rowSp, colStat) = "" Then
1410             .columns(colStat).Hidden = True
1420            End If
1430          Next
1440      End Select
1450      .range(.Cells(rowSp, colFirst), .Cells(rowSp, colFirst)).Select
1460      oExcel.ActiveWindow.FreezePanes = True

1470  Else
1480      .Cells(1, 1) = "No data"
1490  End If

1500  End With

      ' Generate the "By Period" spreadsheet
      ' row 1 = Period
      ' row 2 = Year
      ' row 3 = "COUNT", "TOTAL", "MEAN"   for "DET"            "TOTAL" for "Banded","Returns","Repeats"
      ' row 4 = #sp
      ' row 5 = #ind
      ' row 6 = first row of species data

      ' There are at least 2 periods in Summer and Nestbox; there are at least 5 periods in Winter

      ' col 1 = species codes
      '
      ' for DET
      ' col 2 to 2 + number of periods - 1 = copy of period MEANs for DET
      ' colPeriodDECFEBCount - GRAND COUNT DEC-FEB for DET
      ' colPeriodDECFEBMean  - GRAND MEAN DEC-FEB for DET
      ' colPeriodDECFEBTotal - GRAND TOTAL DEC-FEB for DET
      ' colPeriodGrandCount  - GRAND COUNT for DET
      ' colPeriodGrandMean   - GRAND MEAN for DET
      ' colPeriodGrandTotal  - GRAND TOTAL for DET
           '
      ' for Banded, Returns, Repeats
      ' col 2 to 2 + number of periods - 1 = copy of period TOTALs
      ' colGrandDECFEBTotal_P - GRAND TOTAL DEC-FEB for DET
      ' colGrandTotal_P - GRAND TOTAL for DET
      '
      ' colFirst_P ...

          Dim colPeriodGrandCount As Long
          Dim colPeriodGrandTotal As Long
          Dim colPeriodGrandMean As Long
          Dim colPeriodDECFEBCount As Long
          Dim colPeriodDECFEBMean  As Long
          Dim colPeriodDECFEBTotal As Long
          
          Dim strPeriodDECFEBCount As String   ' list of DEC-FEB Count columns
          Dim strPeriodDECFEBTotal As String   ' list of DEC-FEB Total columns
          Dim strPeriodGrandCount As String    ' list of all the Count columns
          Dim strPeriodGrandTotal As String    ' list of all the Total columns
          
          Dim colDataFirst_P As Long ' col# of the empty column preceeding the period x year data
          
1510  Select Case strSeason1
      Case "Summer", "Nestbox"
1520    If intPeriodTo < 2 Then
1530        intPeriodTo = 2
1540    End If
1550  Case "Winter"
1560    If intPeriodTo < 5 Then
1570        intPeriodTo = 5
1580    End If
1590  End Select

1600  rowLast_P = rowFirst_P + (rowLast - rowFirst)

1610  SysCmd acSysCmdSetStatus, "Generate the By Period spreadsheet " & strSheetNameSeason & " " & strSheetNameStat & " P"

      Dim oSheetPeriod As Excel.Worksheet
1620  Set oSheetPeriod = oBook.Worksheets.Add(After:=oBook.Worksheets(oBook.Worksheets.count))
1630  oSheetPeriod.Name = strSheetNameSeason & " " & strSheetNameStat & " P"
1640  With oSheetPeriod

1650  If rowFirst_P <= rowLast_P Then

          ' fill in the row labels (column 1)
          
1660      col = 1
1670      .Cells(rowSp_P, col) = "#sp"
1680      .Cells(rowInd_P, col) = "#ind"
1690      For row = rowFirst To rowLast
1700          .Cells(row - rowFirst + rowFirst_P, col) = oSheet.Cells(row, 1)
1710      Next row
1720      col = col + 1

         ' reserve <number of periods> columns

1730      col = col + intPeriodTo

          ' reserve columns for DEC-FEB Count, Total, Mean, Grand Count, Total, Mean  ( For "DET", only reserve for the 2 Totals )
          
1740      strPeriodDECFEBCount = ""
1750      strPeriodDECFEBTotal = ""
1760      strPeriodGrandCount = ""
1770      strPeriodGrandTotal = ""
          
          
1780      If strStatFieldname = "DET" And strSeason1 = "WINTER" Then
1790          colPeriodDECFEBCount = col
1800          col = col + 1
1810          colPeriodDECFEBMean = col
1820          col = col + 1
1830      End If
1840      If strStatFieldname = "DET" Then
1850          colPeriodGrandCount = col
1860          col = col + 1
1870          colPeriodGrandMean = col
1880          col = col + 1
1890      End If
1900      If strSeason1 = "WINTER" Then
1910          colPeriodDECFEBTotal = col
1920          col = col + 1
1930      End If
1940      colPeriodGrandTotal = col
1950      col = col + 1
          
          Dim strCount As String
          Dim strTotal As String
          
          Dim colSheet1 As Integer
          
          Dim colPeriodStartPeriod As Long
          
1960      colDataFirst_P = col
          
1970      For intPeriod = 1 To intPeriodTo
          
            ' Create a thin empty column
          
1980        .columns(col).ColumnWidth = 0.5
1990        col = col + 1
              
2000          strCount = ""
2010          strTotal = ""
              
2020          colPeriodStartPeriod = col
                
2030          For intYear = intYearFrom To intYearTo
                  
              Dim strYear As String
            
2040              If strSeason1 = "Winter" And intPeriod <= 2 Then
2050                  strYear = CStr(intYear - 1) & "-" & Right(CStr(intYear), 2)
2060              Else
2070                  strYear = CStr(intYear)
2080              End If
          
                  ' Count for a Year
                  
2090              If strStatFieldname = "DET" Then
                  
2100                  .Cells(rowYear_P, col) = strYear
2110                  .Cells(rowHeader_P, col) = "COUNT"
              
2120                  colSheet1 = colCount(intYear, intPeriod)
2130                  If colSheet1 > 0 Then
2140                        For row = rowFirst - 2 To rowLast
2150                            .Cells(row - rowFirst + rowFirst_P, col) = oSheet.Cells(row, colSheet1)
2160                        Next row
                            
2170                       .range(.Cells(rowFirst_P, col), .Cells(rowLast_P, col)).NumberFormat = strNumberFormatCount
2180                       .range(.Cells(rowSp_P, col), .Cells(rowLast_P, col)).Interior.Color = lngBackgroundColourByPeriodYearCount
                           
2190                        If strCount <> "" Then
2200                            strCount = strCount & ","
2210                        End If
2220                        strCount = strCount & .Cells(rowFirst_P, col).Address(columnAbsolute:=False, rowAbsolute:=False)
                  
2230                        If intPeriod >= 2 And intPeriod <= 4 Then
2240                          If strPeriodDECFEBCount <> "" Then
2250                              strPeriodDECFEBCount = strPeriodDECFEBCount & ","
2260                          End If
2270                          strPeriodDECFEBCount = strPeriodDECFEBCount & .Cells(rowFirst_P, col).Address(columnAbsolute:=False, rowAbsolute:=False)
2280                        End If
                            
2290                        If strPeriodGrandCount <> "" Then
2300                            strPeriodGrandCount = strPeriodGrandCount & ","
2310                        End If
2320                        strPeriodGrandCount = strPeriodGrandCount & .Cells(rowFirst_P, col).Address(columnAbsolute:=False, rowAbsolute:=False)
       
2330                  End If
              
2340                  Select Case strStatFieldname
                      Case "DET"
2350                    .columns(col).Hidden = True
2360                  Case "Banded", "Returns", "Repeats"
2370                    .columns(col).Hidden = True
2380                  End Select
2390                  col = col + 1
                  
2400              End If
                  
                  ' Total for a Year
                  
2410              .Cells(rowYear_P, col) = strYear
2420              .Cells(rowHeader_P, col) = "TOTAL"
                  
2430              colSheet1 = colTotal(intYear, intPeriod)
2440              If colSheet1 > 0 Then
2450                   For row = rowFirst - 2 To rowLast
2460                       .Cells(row - rowFirst + rowFirst_P, col) = oSheet.Cells(row, colSheet1)
2470                   Next row
                  
2480                  .range(.Cells(rowSp_P, col), .Cells(rowSp_P, col)).NumberFormat = strNumberFormatCount
2490                  .range(.Cells(rowInd_P, col), .Cells(rowInd_P, col)).NumberFormat = strNumberFormatTotal
2500                  .range(.Cells(rowFirst_P, col), .Cells(rowLast_P, col)).NumberFormat = strNumberFormatTotal
          
2510                  .range(.Cells(rowSp_P, col), .Cells(rowLast_P, col)).Interior.Color = lngBackgroundColourByPeriodYearTotal
                  
2520                   If strTotal <> "" Then
2530                       strTotal = strTotal & ","
2540                   End If
2550                   strTotal = strTotal & .Cells(rowFirst_P, col).Address(columnAbsolute:=False, rowAbsolute:=False)
                  
2560                   If intPeriod >= 2 And intPeriod <= 4 Then
2570                      If strPeriodDECFEBTotal <> "" Then
2580                          strPeriodDECFEBTotal = strPeriodDECFEBTotal & ","
2590                      End If
2600                      strPeriodDECFEBTotal = strPeriodDECFEBTotal & .Cells(rowFirst_P, col).Address(columnAbsolute:=False, rowAbsolute:=False)
2610                   End If
                       
2620                   If strPeriodGrandTotal <> "" Then
2630                       strPeriodGrandTotal = strPeriodGrandTotal & ","
2640                   End If
2650                   strPeriodGrandTotal = strPeriodGrandTotal & .Cells(rowFirst_P, col).Address(columnAbsolute:=False, rowAbsolute:=False)
2660              End If
                  
2670              Select Case strStatFieldname
                  Case "DET"
2680                .columns(col).Hidden = True
2690              Case "Banded", "Returns", "Repeats"
2700              End Select
2710              col = col + 1
                  
                  ' Mean for a Year
                  
2720              If strStatFieldname = "DET" Then
                  
2730                  .Cells(rowYear_P, col) = strYear
2740                  .Cells(rowHeader_P, col) = "MEAN"
              
2750                  colSheet1 = colMean(intYear, intPeriod)
2760                  If colSheet1 > 0 Then
2770                      For row = rowFirst - 2 To rowLast
2780                          .Cells(row - rowFirst + rowFirst_P, col) = oSheet.Cells(row, colSheet1)
2790                      Next row
2800                      .range(.Cells(rowSp_P, col), .Cells(rowSp_P, col)).NumberFormat = strNumberFormatCount
2810                      .range(.Cells(rowInd_P, col), .Cells(rowInd_P, col)).NumberFormat = strNumberFormatMean
2820                     .range(.Cells(rowFirst_P, col), .Cells(rowLast_P, col)).NumberFormat = strNumberFormatMean
2830                     .range(.Cells(rowSp_P, col), .Cells(rowLast_P, col)).Interior.Color = lngBackgroundColourByPeriodYearMean
2840                  End If
                      
2850                  Select Case strStatFieldname
                      Case "DET"
2860                  Case "Banded", "Returns", "Repeats"
2870                    .columns(col).Hidden = True
2880                  End Select
2890                  col = col + 1
          
2900              End If
          
2910          Next intYear
          
              ' Count for Period
              
2920          If strStatFieldname = "DET" Then
              
2930              .Cells(rowYear_P, col) = "PERIOD"
2940              .Cells(rowHeader_P, col) = "COUNT"
                  
2950              If strCount <> "" And rowFirst_P <= rowLast_P Then
2960                  .Cells(rowFirst_P, col) = "=sum(" & strCount & ")"
2970                  .range(.Cells(rowFirst_P, col), .Cells(rowLast_P, col)).FormulaR1C1 = .range(.Cells(rowFirst_P, col), .Cells(rowFirst_P, col)).FormulaR1C1
2980                  .range(.Cells(rowFirst_P, col), .Cells(rowLast_P, col)).NumberFormat = strNumberFormatCount
2990                  .range(.Cells(rowSp_P, col), .Cells(rowLast_P, col)).Interior.Color = lngBackgroundColourByPeriodPeriodCount
3000              End If
                  
3010              Select Case strStatFieldname
                  Case "DET"
3020                .columns(col).Hidden = True
3030              Case "Banded", "Returns", "Repeats"
3040                .columns(col).Hidden = True
3050              End Select
3060              col = col + 1
              
3070          End If
              
              ' Total for Period
          
3080          .Cells(rowYear_P, col) = "PERIOD"
3090          .Cells(rowHeader_P, col) = "TOTAL"
3100          .Cells(rowSp_P, col) = "=countif(" & .Cells(rowFirst_P, col).Address(columnAbsolute:=False, rowAbsolute:=False) & ":" & .Cells(rowLast_P, col).Address(columnAbsolute:=False, rowAbsolute:=False) & ","">0"")"
3110          .range(.Cells(rowSp_P, col), .Cells(rowSp_P, col)).NumberFormat = strNumberFormatCount
3120          .Cells(rowInd_P, col) = "=sum(" & .Cells(rowFirst_P, col).Address(columnAbsolute:=False, rowAbsolute:=False) & ":" & .Cells(rowLast_P, col).Address(columnAbsolute:=False, rowAbsolute:=False) & ")"
3130          .range(.Cells(rowInd_P, col), .Cells(rowInd_P, col)).NumberFormat = strNumberFormatTotal
              
3140          If strTotal <> "" And rowFirst_P <= rowLast_P Then
3150              .Cells(rowFirst_P, col) = "=sum(" & strTotal & ")"
3160              .range(.Cells(rowFirst_P, col), .Cells(rowLast_P, col)).FormulaR1C1 = .range(.Cells(rowFirst_P, col), .Cells(rowFirst_P, col)).FormulaR1C1
3170              .range(.Cells(rowFirst_P, col), .Cells(rowLast_P, col)).NumberFormat = strNumberFormatTotal
3180              .range(.Cells(rowSp_P, col), .Cells(rowLast_P, col)).Interior.Color = lngBackgroundColourByPeriodPeriodTotal
3190          End If
          
3200          Select Case strStatFieldname
              Case "DET"
3210              .columns(col).Hidden = True
3220          Case "Banded", "Returns", "Repeats"
3230          End Select

              ' For Banded, Returns, Returns: copy to column 1 + intPeriod
              
3240          If strStatFieldname <> "DET" Then
              
                  Dim colCopy_P As Long
3250              colCopy_P = 1 + intPeriod

3260               Select Case strSeason1
                   Case "Spring", "Fall"
3270                   .Cells(rowPeriod_P, colCopy_P) = "Week " & intPeriod
3280               Case "Winter"
3290                   Select Case intPeriod
                       Case 1
3300                       .Cells(rowPeriod_P, colCopy_P) = "+NOV"
3310                   Case 2
3320                        .Cells(rowPeriod_P, colCopy_P) = "DEC"
3330                   Case 3
3340                       .Cells(rowPeriod_P, colCopy_P) = "JAN"
3350                   Case 4
3360                        .Cells(rowPeriod_P, colCopy_P) = "FEB"
3370                   Case 5
3380                        .Cells(rowPeriod_P, colCopy_P) = "MAR+"
3390                   End Select
3400               Case "Summer", "NestBox"
3410                   Select Case intPeriod
                       Case 1
3420                       .Cells(rowPeriod_P, colCopy_P) = "+JUN"
3430                   Case 2
3440                        .Cells(rowPeriod_P, colCopy_P) = "JUL+"
3450                   End Select
3460               End Select
3470              .Cells(rowPeriod_P, colCopy_P).HorizontalAlignment = xlCenter
3480              .Cells(rowPeriod_P, colCopy_P).Interior.Color = vbBlack
3490              .Cells(rowPeriod_P, colCopy_P).Font.Color = vbWhite

3500              For row = rowHeader_P To rowLast_P
3510                  .Cells(row, colCopy_P) = "=" & .Cells(row, col).Address(columnAbsolute:=False, rowAbsolute:=False)
3520                  .Cells(row, colCopy_P).Interior.Color = .Cells(row, col).Interior.Color
3530                  .Cells(row, colCopy_P).Font.Color = .Cells(row, col).Font.Color
3540              Next

3550              .Cells(rowHeader_P, colCopy_P).Interior.Color = RGB(128, 128, 128)
3560              .Cells(rowHeader_P, colCopy_P).Font.Color = vbWhite

3570          End If

3580          col = col + 1
          
              ' Mean for Period
              
3590          If strStatFieldname = "DET" Then
3600              .Cells(rowYear_P, col) = "PERIOD"
3610              .Cells(rowHeader_P, col) = "MEAN"
3620              .Cells(rowSp_P, col) = "=countif(" & .Cells(rowFirst_P, col).Address(columnAbsolute:=False, rowAbsolute:=False) & ":" & .Cells(rowLast_P, col).Address(columnAbsolute:=False, rowAbsolute:=False) & ","">0"")"
3630              .range(.Cells(rowSp_P, col), .Cells(rowSp_P, col)).NumberFormat = strNumberFormatCount
3640              .Cells(rowInd_P, col) = "=sum(" & .Cells(rowFirst_P, col).Address(columnAbsolute:=False, rowAbsolute:=False) & ":" & .Cells(rowLast_P, col).Address(columnAbsolute:=False, rowAbsolute:=False) & ")"
3650              .range(.Cells(rowInd_P, col), .Cells(rowInd_P, col)).NumberFormat = strNumberFormatMean
              
3660              If strCount <> "" And rowFirst_P <= rowLast_P Then
3670                  .Cells(rowFirst_P, col) = "=if(" & "sum(" & strCount & ")" & "=0,""""," & "sum(" & strTotal & ")" & "/" & "sum(" & strCount & ")" & ")"
3680                  .range(.Cells(rowFirst_P, col), .Cells(rowLast_P, col)).FormulaR1C1 = .range(.Cells(rowFirst_P, col), .Cells(rowFirst_P, col)).FormulaR1C1
3690                  .range(.Cells(rowFirst_P, col), .Cells(rowLast_P, col)).NumberFormat = strNumberFormatMean
3700                  .range(.Cells(rowSp_P, col), .Cells(rowLast_P, col)).Interior.Color = lngBackgroundColourByPeriodPeriodMean
3710              End If
                  
3720              Select Case strStatFieldname
                  Case "DET"
3730              Case "Banded", "Returns", "Repeats"
3740                  .columns(col).Hidden = True
3750              End Select
                  
                  ' For DET: copy to column 1 + intPeriod
                  
3760              If strStatFieldname = "DET" Then
3770                  colCopy_P = 1 + intPeriod

3780                  Select Case strSeason1
                       Case "Spring", "Fall"
3790                       .Cells(rowPeriod_P, colCopy_P) = "Week " & intPeriod
3800                   Case "Winter"
3810                       Select Case intPeriod
                           Case 1
3820                           .Cells(rowPeriod_P, colCopy_P) = "+NOV"
3830                       Case 2
3840                            .Cells(rowPeriod_P, colCopy_P) = "DEC"
3850                       Case 3
3860                           .Cells(rowPeriod_P, colCopy_P) = "JAN"
3870                       Case 4
3880                            .Cells(rowPeriod_P, colCopy_P) = "FEB"
3890                       Case 5
3900                            .Cells(rowPeriod_P, colCopy_P) = "MAR+"
3910                       End Select
3920                   Case "Summer", "NestBox"
3930                       Select Case intPeriod
                           Case 1
3940                           .Cells(rowPeriod_P, colCopy_P) = "+JUN"
3950                       Case 2
3960                            .Cells(rowPeriod_P, colCopy_P) = "JUL+"
3970                       End Select
3980                   End Select
3990                  .Cells(rowPeriod_P, colCopy_P).HorizontalAlignment = xlCenter
4000                  .Cells(rowPeriod_P, colCopy_P).Interior.Color = vbBlack
4010                  .Cells(rowPeriod_P, colCopy_P).Font.Color = vbWhite


4020                  For row = rowHeader_P To rowLast_P
4030                      .Cells(row, colCopy_P) = "=" & .Cells(row, col).Address(columnAbsolute:=False, rowAbsolute:=False)
4040                      .Cells(row, colCopy_P).Interior.Color = .Cells(row, col).Interior.Color
4050                      .Cells(row, colCopy_P).Font.Color = .Cells(row, col).Font.Color
4060                  Next

4070                  .Cells(rowHeader_P, colCopy_P).Interior.Color = RGB(128, 128, 128)
4080                  .Cells(rowHeader_P, colCopy_P).Font.Color = vbWhite

4090              End If
                  
4100              col = col + 1
4110          End If
            
4120          .range(.Cells(rowPeriod_P, colPeriodStartPeriod), .Cells(rowPeriod_P, col - 1)).Merge
4130          .range(.Cells(rowPeriod_P, colPeriodStartPeriod), .Cells(rowYear_P, col - 1)).Interior.Color = vbBlack
4140          .range(.Cells(rowPeriod_P, colPeriodStartPeriod), .Cells(rowYear_P, col - 1)).Font.Color = vbWhite
4150          .range(.Cells(rowHeader_P, colPeriodStartPeriod), .Cells(rowHeader_P, col - 1)).Interior.Color = RGB(128, 128, 128)
4160          .range(.Cells(rowHeader_P, colPeriodStartPeriod), .Cells(rowHeader_P, col - 1)).Font.Color = vbWhite
          
4170           Select Case strSeason1
               Case "Spring", "Fall"
4180               .Cells(rowPeriod_P, colPeriodStartPeriod) = "Week " & intPeriod
4190           Case "Winter"
4200               Select Case intPeriod
                   Case 1
4210                   .Cells(rowPeriod_P, colPeriodStartPeriod) = "+NOVEMBER"
4220               Case 2
4230                    .Cells(rowPeriod_P, colPeriodStartPeriod) = "DECEMBER"
4240               Case 3
4250                   .Cells(rowPeriod_P, colPeriodStartPeriod) = "JANUARY"
4260               Case 4
4270                    .Cells(rowPeriod_P, colPeriodStartPeriod) = "FEBRUARY"
4280               Case 5
4290                    .Cells(rowPeriod_P, colPeriodStartPeriod) = "MARCH+"
4300               End Select
4310           Case "Summer", "NestBox"
4320               Select Case intPeriod
                   Case 1
4330                   .Cells(rowPeriod_P, colPeriodStartPeriod) = "+JUNE"
4340               Case 2
4350                    .Cells(rowPeriod_P, colPeriodStartPeriod) = "JULY+"
4360               End Select
4370           End Select
4380          .Cells(rowPeriod_P, colPeriodStartPeriod).HorizontalAlignment = xlCenter
              
4390      Next
          
          Dim colPeriodLast As Long
4400      colPeriodLast = col - 1
          
          ' Grand Count
          
4410      If strStatFieldname = "DET" Then
          
4420          If strSeason1 = "WINTER" Then
4430              col = colPeriodDECFEBCount
                  
4440              .Cells(rowPeriod_P, col) = "DEC-FEB"
4450              .Cells(rowHeader_P, col) = "COUNT"
4460              .range(.Cells(rowPeriod_P, col), .Cells(rowYear_P, col)).Interior.Color = vbBlack
4470              .range(.Cells(rowPeriod_P, col), .Cells(rowYear_P, col)).Font.Color = vbWhite
4480              .range(.Cells(rowHeader_P, col), .Cells(rowHeader_P, col)).Interior.Color = RGB(128, 128, 128)
4490              .range(.Cells(rowHeader_P, col), .Cells(rowHeader_P, col)).Font.Color = vbWhite
                  
4500              If strPeriodDECFEBCount <> "" Then
4510                  .Cells(rowFirst_P, col) = "=sum(" & strPeriodDECFEBCount & ")"
4520                  .range(.Cells(rowFirst_P, col), .Cells(rowLast_P, col)).FormulaR1C1 = .range(.Cells(rowFirst_P, col), .Cells(rowFirst_P, col)).FormulaR1C1
4530                  .range(.Cells(rowFirst_P - 2, col), .Cells(rowLast_P, col)).NumberFormat = strNumberFormatCount
4540              End If
4550              .range(.Cells(rowFirst_P - 2, col), .Cells(rowLast_P, col)).Font.Color = vbWhite
4560              .range(.Cells(rowFirst_P - 2, col), .Cells(rowLast_P, col)).Interior.Color = lngBackgroundColourByPeriodAllCount
                  
4570              Select Case strStatFieldname
                  Case "DET"
4580                  .columns(col).Hidden = True
4590              Case "Banded", "Returns", "Repeats"
4600                  .columns(col).Hidden = True
4610              End Select
4620          End If
4630          col = colPeriodGrandCount
              
4640          .Cells(rowPeriod_P, col) = "GRAND"
4650          .Cells(rowHeader_P, col) = "COUNT"
4660          .range(.Cells(rowPeriod_P, col), .Cells(rowYear_P, col)).Interior.Color = vbBlack
4670          .range(.Cells(rowPeriod_P, col), .Cells(rowYear_P, col)).Font.Color = vbWhite
4680          .range(.Cells(rowHeader_P, col), .Cells(rowHeader_P, col)).Interior.Color = RGB(128, 128, 128)
4690          .range(.Cells(rowHeader_P, col), .Cells(rowHeader_P, col)).Font.Color = vbWhite
              
4700          If strPeriodGrandCount <> "" Then
4710              .Cells(rowFirst_P, col) = "=sum(" & strPeriodGrandCount & ")"
4720              .range(.Cells(rowFirst_P, col), .Cells(rowLast_P, col)).FormulaR1C1 = .range(.Cells(rowFirst_P, col), .Cells(rowFirst_P, col)).FormulaR1C1
4730              .range(.Cells(rowFirst_P - 2, col), .Cells(rowLast_P, col)).NumberFormat = strNumberFormatCount
4740          End If
4750          .range(.Cells(rowFirst_P - 2, col), .Cells(rowLast_P, col)).Font.Color = vbWhite
4760          .range(.Cells(rowFirst_P - 2, col), .Cells(rowLast_P, col)).Interior.Color = lngBackgroundColourByPeriodAllCount
              
4770          Select Case strStatFieldname
              Case "DET"
4780              .columns(col).Hidden = True
4790          Case "Banded", "Returns", "Repeats"
4800              .columns(col).Hidden = True
4810          End Select
              
4820      End If
          
          ' Grand Total
          
4830      If strSeason1 = "WINTER" Then
4840           col = colPeriodDECFEBTotal
          
4850          .Cells(rowPeriod_P, col) = "DEC-FEB"
4860          .Cells(rowHeader_P, col) = "TOTAL"
4870              .range(.Cells(rowPeriod_P, col), .Cells(rowYear_P, col)).Interior.Color = vbBlack
4880              .range(.Cells(rowPeriod_P, col), .Cells(rowYear_P, col)).Font.Color = vbWhite
4890              .range(.Cells(rowHeader_P, col), .Cells(rowHeader_P, col)).Interior.Color = RGB(128, 128, 128)
4900              .range(.Cells(rowHeader_P, col), .Cells(rowHeader_P, col)).Font.Color = vbWhite
          
4910          .Cells(rowSp_P, col) = "=countif(" & .Cells(rowFirst_P, col).Address(columnAbsolute:=False, rowAbsolute:=False) & ":" & .Cells(rowLast_P, col).Address(columnAbsolute:=False, rowAbsolute:=False) & ","">0"")"
4920          .range(.Cells(rowSp_P, col), .Cells(rowSp_P, col)).NumberFormat = strNumberFormatCount
4930          .Cells(rowInd_P, col) = "=sum(" & .Cells(rowFirst_P, col).Address(columnAbsolute:=False, rowAbsolute:=False) & ":" & .Cells(rowLast_P, col).Address(columnAbsolute:=False, rowAbsolute:=False) & ")"
4940          .range(.Cells(rowInd_P, col), .Cells(rowInd_P, col)).NumberFormat = strNumberFormatTotal
4950          If strPeriodDECFEBTotal <> "" Then
4960              .Cells(rowFirst_P, col) = "=sum(" & strPeriodDECFEBTotal & ")"
4970              .range(.Cells(rowFirst_P, col), .Cells(rowLast_P, col)).FormulaR1C1 = .range(.Cells(rowFirst_P, col), .Cells(rowFirst_P, col)).FormulaR1C1
4980              .range(.Cells(rowFirst_P - 2, col), .Cells(rowLast_P, col)).NumberFormat = strNumberFormatTotal
4990          End If
5000          .range(.Cells(rowFirst_P - 2, col), .Cells(rowLast_P, col)).Font.Color = vbWhite
5010          .range(.Cells(rowFirst_P - 2, col), .Cells(rowLast_P, col)).Interior.Color = lngBackgroundColourByPeriodAllTotal
                  
5020           Select Case strStatFieldname
               Case "DET"
5030           Case "Banded", "Returns", "Repeats"
5040           End Select
5050       End If
          
5060      col = colPeriodGrandTotal

5070      .Cells(rowPeriod_P, col) = "GRAND"
5080      .Cells(rowHeader_P, col) = "TOTAL"
5090          .range(.Cells(rowPeriod_P, col), .Cells(rowYear_P, col)).Interior.Color = vbBlack
5100          .range(.Cells(rowPeriod_P, col), .Cells(rowYear_P, col)).Font.Color = vbWhite
5110          .range(.Cells(rowHeader_P, col), .Cells(rowHeader_P, col)).Interior.Color = RGB(128, 128, 128)
5120          .range(.Cells(rowHeader_P, col), .Cells(rowHeader_P, col)).Font.Color = vbWhite

5130      .Cells(rowSp_P, col) = "=countif(" & .Cells(rowFirst_P, col).Address(columnAbsolute:=False, rowAbsolute:=False) & ":" & .Cells(rowLast_P, col).Address(columnAbsolute:=False, rowAbsolute:=False) & ","">0"")"
5140      .range(.Cells(rowSp_P, col), .Cells(rowSp_P, col)).NumberFormat = strNumberFormatCount
5150      .Cells(rowInd_P, col) = "=sum(" & .Cells(rowFirst_P, col).Address(columnAbsolute:=False, rowAbsolute:=False) & ":" & .Cells(rowLast_P, col).Address(columnAbsolute:=False, rowAbsolute:=False) & ")"
5160      .range(.Cells(rowInd_P, col), .Cells(rowInd_P, col)).NumberFormat = strNumberFormatTotal
          
5170      If strPeriodGrandTotal <> "" Then
5180          .Cells(rowFirst_P, col) = "=sum(" & strPeriodGrandTotal & ")"
5190          .range(.Cells(rowFirst_P, col), .Cells(rowLast_P, col)).FormulaR1C1 = .range(.Cells(rowFirst_P, col), .Cells(rowFirst_P, col)).FormulaR1C1
5200          .range(.Cells(rowFirst_P - 2, col), .Cells(rowLast_P, col)).NumberFormat = strNumberFormatTotal
5210      End If
5220      .range(.Cells(rowFirst_P - 2, col), .Cells(rowLast_P, col)).Font.Color = vbWhite
5230      .range(.Cells(rowFirst_P - 2, col), .Cells(rowLast_P, col)).Interior.Color = lngBackgroundColourByPeriodAllTotal
              
5240       Select Case strStatFieldname
           Case "DET"
5250       Case "Banded", "Returns", "Repeats"
5260       End Select
          
          ' Grand Mean
          
5270      If strStatFieldname = "DET" Then
                  
5280           If strSeason1 = "WINTER" Then
5290               col = colPeriodDECFEBMean
                  
5300              .Cells(rowPeriod_P, col) = "DEC-FEB"
5310              .Cells(rowHeader_P, col) = "MEAN"
5320              .range(.Cells(rowPeriod_P, col), .Cells(rowYear_P, col)).Interior.Color = vbBlack
5330              .range(.Cells(rowPeriod_P, col), .Cells(rowYear_P, col)).Font.Color = vbWhite
5340              .range(.Cells(rowHeader_P, col), .Cells(rowHeader_P, col)).Interior.Color = RGB(128, 128, 128)
5350              .range(.Cells(rowHeader_P, col), .Cells(rowHeader_P, col)).Font.Color = vbWhite
          
5360              .Cells(rowSp_P, col) = "=countif(" & .Cells(rowFirst_P, col).Address(columnAbsolute:=False, rowAbsolute:=False) & ":" & .Cells(rowLast_P, col).Address(columnAbsolute:=False, rowAbsolute:=False) & ","">0"")"
5370              .range(.Cells(rowSp_P, col), .Cells(rowSp_P, col)).NumberFormat = strNumberFormatCount
5380              .Cells(rowInd_P, col) = "=sum(" & .Cells(rowFirst_P, col).Address(columnAbsolute:=False, rowAbsolute:=False) & ":" & .Cells(rowLast_P, col).Address(columnAbsolute:=False, rowAbsolute:=False) & ")"
5390              .range(.Cells(rowInd_P, col), .Cells(rowInd_P, col)).NumberFormat = strNumberFormatMean
                  
5400              If strPeriodDECFEBCount <> "" And strPeriodDECFEBTotal <> "" Then
5410                  .Cells(rowFirst_P, col) = "=if(" & "sum(" & strPeriodDECFEBCount & ")" & "=0,""""," & "sum(" & strPeriodDECFEBTotal & ")" & "/" & "sum(" & strPeriodDECFEBCount & ")" & ")"
5420                  .range(.Cells(rowFirst_P, col), .Cells(rowLast_P, col)).FormulaR1C1 = .range(.Cells(rowFirst_P, col), .Cells(rowFirst_P, col)).FormulaR1C1
5430                  .range(.Cells(rowFirst_P, col), .Cells(rowLast_P, col)).NumberFormat = strNumberFormatMean
5440              End If
                  
5450              .range(.Cells(rowSp_P, col), .Cells(rowLast_P, col)).Font.Color = vbWhite
5460              .range(.Cells(rowSp_P, col), .Cells(rowLast_P, col)).Interior.Color = lngBackgroundColourByPeriodAllMean
                  
5470              Select Case strStatFieldname
                  Case "DET"
5480              Case "Banded", "Returns", "Repeats"
5490                 .columns(colPeriodGrandMean).Hidden = True
5500              End Select
5510          End If
              
5520          col = colPeriodGrandMean
              
5530          .Cells(rowPeriod_P, col) = "GRAND"
5540          .Cells(rowHeader_P, col) = "MEAN"
5550          .range(.Cells(rowPeriod_P, col), .Cells(rowYear_P, col)).Interior.Color = vbBlack
5560          .range(.Cells(rowPeriod_P, col), .Cells(rowYear_P, col)).Font.Color = vbWhite
5570          .range(.Cells(rowHeader_P, col), .Cells(rowHeader_P, col)).Interior.Color = RGB(128, 128, 128)
5580          .range(.Cells(rowHeader_P, col), .Cells(rowHeader_P, col)).Font.Color = vbWhite

5590          .Cells(rowSp_P, col) = "=countif(" & .Cells(rowFirst_P, col).Address(columnAbsolute:=False, rowAbsolute:=False) & ":" & .Cells(rowLast_P, col).Address(columnAbsolute:=False, rowAbsolute:=False) & ","">0"")"
5600          .range(.Cells(rowSp_P, col), .Cells(rowSp_P, col)).NumberFormat = strNumberFormatCount
5610          .Cells(rowInd_P, col) = "=sum(" & .Cells(rowFirst_P, col).Address(columnAbsolute:=False, rowAbsolute:=False) & ":" & .Cells(rowLast_P, col).Address(columnAbsolute:=False, rowAbsolute:=False) & ")"
5620          .range(.Cells(rowInd_P, col), .Cells(rowInd_P, col)).NumberFormat = strNumberFormatMean
              
5630          If strPeriodGrandCount <> "" And strPeriodGrandTotal <> "" Then
5640              .Cells(rowFirst_P, col) = "=if(" & "sum(" & strPeriodGrandCount & ")" & "=0,""""," & "sum(" & strPeriodGrandTotal & ")" & "/" & "sum(" & strPeriodGrandCount & ")" & ")"
5650              .range(.Cells(rowFirst_P, col), .Cells(rowLast_P, col)).FormulaR1C1 = .range(.Cells(rowFirst_P, col), .Cells(rowFirst_P, col)).FormulaR1C1
5660              .range(.Cells(rowFirst_P, col), .Cells(rowLast_P, col)).NumberFormat = strNumberFormatMean
5670          End If
              
5680          .range(.Cells(rowSp_P, col), .Cells(rowLast_P, col)).Font.Color = vbWhite
5690          .range(.Cells(rowSp_P, col), .Cells(rowLast_P, col)).Interior.Color = lngBackgroundColourByPeriodAllMean
              
5700          Select Case strStatFieldname
              Case "DET"
5710          Case "Banded", "Returns", "Repeats"
5720             .columns(colPeriodGrandMean).Hidden = True
5730          End Select
          
5740      End If
          
5750      .range(.Cells(1, 1), .Cells(3, colPeriodLast)).HorizontalAlignment = xlCenter
          
          ' Freeze rows and columns
          
5760      .range(.Cells(rowSp_P, colDataFirst_P), .Cells(rowSp_P, colDataFirst_P)).Select
5770      oExcel.ActiveWindow.FreezePanes = True

5780  Else
5790      .Cells(1, 1) = "No data"
5800  End If

5810  End With

      'DD Error Handler Start
Exit_label:
5820       Exit Sub
Err_label:
5830       Select Case Err.Number
           Case Else
5840      Call LogError("Form_basDETSeasonSpreadsheet", "DETSeasonSpreadsheet_Season")
5850       End Select
5860       Resume Exit_label
      'DD Error Handler End

    End Sub
    
Private Sub DETSEasonSpreadsheet_Season_get()
10       On Error GoTo Err_label

20        row = Nz(rst("Row"))
30        intStat = Nz(rst(strStatFieldname))  ' DET, Banded, Repeats, Returns
40        datDateEx = Nz(rst("DateEx"))
50        intYearEx = Nz(rst("YearEx"))
60        intPeriod = Nz(rst("Period"))

    'DD Error Handler Start
Exit_label:
70        Exit Sub
Err_label:
80        Select Case Err.Number
    Case Else
90       Call LogError("basDETSeasonSpreadsheet", "DETSEasonSpreadsheet_Season_get")
100       End Select
110       Resume Exit_label
    ' DD Error Handler End

End Sub
    
Private Sub DETSeasonSpreadsheet_Season_HR()
10    With oSheet
20        strYearAllSum = ""
30        strYearAllCount = ""
40    End With
End Sub

'---------------------------------------------------------------------------------------
' DETSeasonSpreadsheet_Season_H1                  Year
'---------------------------------------------------------------------------------------

Private Sub DETSeasonSpreadsheet_Season_H1() ' Year
10       On Error GoTo Err_label

20    With oSheet
30        strSeasonSum = ""
40        strSeasonCount = ""
50    End With

          'DD Error Handler Start
Exit_label:
60        Exit Sub
Err_label:
70        Select Case Err.Number
          Case Else
80             Call LogError("basDETSeasonSpreadsheet", "DETSeasonSpreadsheet_Season_H1")
90        End Select
100       Resume Exit_label
          ' DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' DETSeasonSpreadsheet_Season_H2                  Period
'---------------------------------------------------------------------------------------
'
' col is the first day of a period

Private Sub DETSeasonSpreadsheet_Season_H2() ' Period
10       On Error GoTo Err_label

20    colPeriodFirst = col

30    If intPeriod > intPeriodTo Then
40        intPeriodTo = intPeriod
50    End If

          'DD Error Handler Start
Exit_label:
60        Exit Sub
Err_label:
70        Select Case Err.Number
          Case Else
80             Call LogError("basDETSeasonSpreadsheet", "DETSeasonSpreadsheet_Season_H2")
90        End Select
100       Resume Exit_label
          ' DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' DETSeasonSpreadsheet_Season_H3                 Day
'---------------------------------------------------------------------------------------
'
' col = column of a date
' fill in the col's header rows

Private Sub DETSeasonSpreadsheet_Season_H3() ' Date
10       On Error GoTo Err_label

20    With oSheet

30        .Cells(rowMonth, col) = datDateEx
40        .Cells(rowMonth, col).NumberFormat = "mmm"
50        .Cells(rowDay, col) = datDateEx
60        .Cells(rowDay, col).NumberFormat = "d"

70        .Cells(rowSp, col) = "=count(" & .Cells(rowFirst, col).Address(columnAbsolute:=False, rowAbsolute:=False) & ":" & .Cells(rowLast, col).Address(columnAbsolute:=False, rowAbsolute:=False) & ")"
80        .Cells(rowInd, col) = "=sum(" & .Cells(rowFirst, col).Address(columnAbsolute:=False, rowAbsolute:=False) & ":" & .Cells(rowLast, col).Address(columnAbsolute:=False, rowAbsolute:=False) & ")"


90    End With

          'DD Error Handler Start
Exit_label:
100       Exit Sub
Err_label:
110       Select Case Err.Number
          Case Else
120            Call LogError("basDETSeasonSpreadsheet", "DETSeasonSpreadsheet_Season_H3")
130       End Select
140       Resume Exit_label
          ' DD Error Handler End
End Sub


'---------------------------------------------------------------------------------------
' DETSeasonSpreadsheet_Season_D
'---------------------------------------------------------------------------------------

Private Sub DETSeasonSpreadsheet_Season_D()

10       On Error GoTo Err_label

20    With oSheet
30        If intStat > 0 Then
40            .Cells(row, col) = intStat
50        End If
60    End With

          ' DD Error Handler End

    'DD Error Handler Start
Exit_label:
70        Exit Sub
Err_label:
80        Select Case Err.Number
    Case Else
90       Call LogError("basDETSeasonSpreadsheet", "DETSeasonSpreadsheet_Season_D")
100       End Select
110       Resume Exit_label
    ' DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' DETSeasonSpreadsheet_Season_F3                Day
'---------------------------------------------------------------------------------------
'
' col has been filled in for the day
' the next col could be a new day, a period summary, a year summary, or nothing at all
' col++


Private Sub DETSeasonSpreadsheet_Season_F3() ' Date
10       On Error GoTo Err_label

20    With oSheet
30        colPeriodLast = col
40        col = col + 1
50    End With

    'DD Error Handler Start
Exit_label:
60        Exit Sub
Err_label:
70        Select Case Err.Number
    Case Else
80       Call LogError("basDETSeasonSpreadsheet", "DETSeasonSpreadsheet_Season_F3")
90        End Select
100       Resume Exit_label
    ' DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' DETSeasonSpreadsheet_Season_F2             Period
'---------------------------------------------------------------------------------------
'
' col is the summary col for a period
' fill in the header rows
' fill in the first data row and copy it down

Private Sub DETSeasonSpreadsheet_Season_F2() ' Period

10       On Error GoTo Err_label

20    With oSheet

30        If Year(datDateEx_previous) = intYearEx_previous Then
40            .Cells(rowYear, colPeriodFirst) = intYearEx_previous
50        Else
60            .Cells(rowYear, colPeriodFirst) = Year(datDateEx_previous) & "-" & Right(intYearEx_previous, 2)
70        End If

80        .range(.Cells(rowYear, colPeriodFirst), .Cells(rowYear, col)).Merge
          
90        .Cells(rowPeriod, colPeriodFirst) = "Period " & intPeriod_previous
100       .range(.Cells(rowPeriod, colPeriodFirst), .Cells(rowPeriod, col)).Merge

          ' Count

110       If strStatFieldname = "DET" Then
120           .Cells(rowDay, col) = "COUNT"

130           .Cells(rowFirst, col) = _
                  "=count(" & .Cells(rowDay, colPeriodFirst).Address(columnAbsolute:=False, rowAbsolute:=True) & ":" & .Cells(rowDay, colPeriodLast).Address(columnAbsolute:=False, rowAbsolute:=True) & ")"
140           .range(.Cells(rowFirst, col), .Cells(rowLast, col)).FormulaR1C1 = .range(.Cells(rowFirst, col), .Cells(rowFirst, col)).FormulaR1C1
150           .range(.Cells(rowFirst, col), .Cells(rowLast, col)).NumberFormat = strNumberFormatCount
160           .range(.Cells(rowDay, col), .Cells(rowLast, col)).Interior.Color = lngBackgroundColourPeriodCount
170          .columns(col).Hidden = True

180           colCount(intYearEx_previous, intPeriod_previous) = col

190           col = col + 1
200       End If

          ' Total

210       .Cells(rowDay, col) = "TOTAL"
220       .Cells(rowSp, col) = "=countif(" & .Cells(rowFirst, col).Address(columnAbsolute:=False, rowAbsolute:=False) & ":" & .Cells(rowLast, col).Address(columnAbsolute:=False, rowAbsolute:=False) & ","">0"")"
230       .range(.Cells(rowSp, col), .Cells(rowSp, col)).NumberFormat = strNumberFormatCount
240       .Cells(rowInd, col) = "=sum(" & .Cells(rowFirst, col).Address(columnAbsolute:=False, rowAbsolute:=False) & ":" & .Cells(rowLast, col).Address(columnAbsolute:=False, rowAbsolute:=False) & ")"
250       .range(.Cells(rowInd, col), .Cells(rowInd, col)).NumberFormat = strNumberFormatTotal

260       .Cells(rowFirst, col) = _
              "=sum(" & .Cells(rowFirst, colPeriodFirst).Address(columnAbsolute:=False, rowAbsolute:=False) & ":" & .Cells(rowFirst, colPeriodLast).Address(columnAbsolute:=False, rowAbsolute:=False) & ")"
270       .range(.Cells(rowFirst, col), .Cells(rowLast, col)).FormulaR1C1 = .range(.Cells(rowFirst, col), .Cells(rowFirst, col)).FormulaR1C1
280       .range(.Cells(rowFirst, col), .Cells(rowLast, col)).NumberFormat = strNumberFormatCount
290       .range(.Cells(rowDay, col), .Cells(rowLast, col)).Interior.Color = lngBackgroundColourPeriodTotal

300       If strStatFieldname = "DET" Then
310           .columns(col).Hidden = True
320       End If

330       colTotal(intYearEx_previous, intPeriod_previous) = col

340       col = col + 1

          ' Mean

350       If strStatFieldname = "DET" Then
360           .Cells(rowDay, col) = "MEAN"
370           .Cells(rowSp, col) = "=countif(" & .Cells(rowFirst, col).Address(columnAbsolute:=False, rowAbsolute:=False) & ":" & .Cells(rowLast, col).Address(columnAbsolute:=False, rowAbsolute:=False) & ","">0"")"
380           .range(.Cells(rowSp, col), .Cells(rowLast, col)).Interior.Color = lngBackgroundColourPeriod
390           .range(.Cells(rowSp, col), .Cells(rowLast, col)).Font.Bold = True
400           .range(.Cells(rowSp, col), .Cells(rowSp, col)).NumberFormat = strNumberFormatCount
410           .Cells(rowInd, col) = "=sum(" & .Cells(rowFirst, col).Address(columnAbsolute:=False, rowAbsolute:=False) & ":" & .Cells(rowLast, col).Address(columnAbsolute:=False, rowAbsolute:=False) & ")"
420           .range(.Cells(rowInd, col), .Cells(rowInd, col)).NumberFormat = strNumberFormatMean
              
430           .Cells(rowFirst, col) = _
                  "=sum(" & .Cells(rowFirst, colPeriodFirst).Address(columnAbsolute:=False, rowAbsolute:=False) & ":" & .Cells(rowFirst, colPeriodLast).Address(columnAbsolute:=False, rowAbsolute:=False) & ")/" & _
                  "count(" & .Cells(rowDay, colPeriodFirst).Address(columnAbsolute:=False, rowAbsolute:=True) & ":" & .Cells(rowDay, colPeriodLast).Address(columnAbsolute:=False, rowAbsolute:=True) & ")"
440           .range(.Cells(rowFirst, col), .Cells(rowLast, col)).FormulaR1C1 = .range(.Cells(rowFirst, col), .Cells(rowFirst, col)).FormulaR1C1
450           .range(.Cells(rowFirst, col), .Cells(rowLast, col)).NumberFormat = strNumberFormatMean
              
460           If strStatFieldname <> "DET" Then
470               .columns(col).Hidden = True
480           End If
              
490           colMean(intYearEx_previous, intPeriod_previous) = col
              
500           col = col + 1
510       End If

520       If strSeasonSum <> "" Then
530           strSeasonSum = strSeasonSum & ","
540       End If
550       strSeasonSum = strSeasonSum & .Cells(rowFirst, colPeriodFirst).Address(columnAbsolute:=False, rowAbsolute:=False) & ":" & .Cells(rowFirst, colPeriodLast).Address(columnAbsolute:=False, rowAbsolute:=False)
560       If strSeasonCount <> "" Then
570           strSeasonCount = strSeasonCount & ","
580       End If
590       strSeasonCount = strSeasonCount & .Cells(rowDay, colPeriodFirst).Address(columnAbsolute:=False, rowAbsolute:=True) & ":" & .Cells(rowDay, colPeriodLast).Address(columnAbsolute:=False, rowAbsolute:=True)

600       If strYearAllSum <> "" Then
610           strYearAllSum = strYearAllSum & ","
620       End If
630       strYearAllSum = strYearAllSum & .Cells(rowFirst, colPeriodFirst).Address(columnAbsolute:=False, rowAbsolute:=False) & ":" & .Cells(rowFirst, colPeriodLast).Address(columnAbsolute:=False, rowAbsolute:=False)
640       If strYearAllCount <> "" Then
650           strYearAllCount = strYearAllCount & ","
660       End If
670       strYearAllCount = strYearAllCount & .Cells(rowDay, colPeriodFirst).Address(columnAbsolute:=False, rowAbsolute:=True) & ":" & .Cells(rowDay, colPeriodLast).Address(columnAbsolute:=False, rowAbsolute:=True)
        
680   End With

          'DD Error Handler Start
Exit_label:
690       Exit Sub
Err_label:
700       Select Case Err.Number
          Case Else
710      Call LogError("basDETSeasonSpreadsheet", "DETSeasonSpreadsheet_Season_F2")
720       End Select
730       Resume Exit_label
          ' DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' DETSeasonSpreadsheet_Season_F1                  Year
'---------------------------------------------------------------------------------------
'
' col is the summary col for a year
' fill in the header rows
' fill in the first data row and copy it down

Private Sub DETSeasonSpreadsheet_Season_F1() ' Year
10       On Error GoTo Err_label

      Dim colYearCopyMean As Long
      Dim colYearCopyTotal As Long

20    colYearCopyMean = toColYearCopyMean(intYearEx_previous)
30    colYearCopyTotal = toColYearCopyTotal(intYearEx_previous)

40    With oSheet

      ' Count
      
50        If strStatFieldname = "DET" Then
60            .Cells(rowMonth, col) = "SEASON"
70            .Cells(rowDay, col) = "COUNT"
80            .Cells(rowFirst, col) = "=count(" & strSeasonCount & ")"
90            .range(.Cells(rowFirst, col), .Cells(rowLast, col)).FormulaR1C1 = .range(.Cells(rowFirst, col), .Cells(rowFirst, col)).FormulaR1C1
100           .range(.Cells(rowDay, col), .Cells(rowLast, col)).Interior.Color = lngBackgroundColourPeriodCount
110           .columns(col).Hidden = True
120           col = col + 1
130       End If

      ' Total

140       .Cells(rowMonth, col) = "SEASON"
150       .Cells(rowDay, col) = "TOTAL"
160       .Cells(rowSp, col) = "=countif(" & .Cells(rowFirst, col).Address(columnAbsolute:=False, rowAbsolute:=False) & ":" & .Cells(rowLast, col).Address(columnAbsolute:=False, rowAbsolute:=False) & ","">0"")"
170       .range(.Cells(rowSp, col), .Cells(rowSp, col)).NumberFormat = strNumberFormatTotal
180       .Cells(rowInd, col) = "=sum(" & .Cells(rowFirst, col).Address(columnAbsolute:=False, rowAbsolute:=False) & ":" & .Cells(rowLast, col).Address(columnAbsolute:=False, rowAbsolute:=False) & ")"
190       .range(.Cells(rowInd, col), .Cells(rowInd, col)).NumberFormat = strNumberFormatTotal

200       .Cells(rowFirst, col) = "=sum(" & strSeasonSum & ")"

210       .range(.Cells(rowFirst, col), .Cells(rowLast, col)).FormulaR1C1 = .range(.Cells(rowFirst, col), .Cells(rowFirst, col)).FormulaR1C1
220       .range(.Cells(rowDay, col), .Cells(rowLast, col)).Interior.Color = lngBackgroundColourYearTotal
230       .range(.Cells(rowFirst, col), .Cells(rowLast, col)).NumberFormat = strNumberFormatTotal


240       If strStatFieldname = "DET" Then
250           .columns(col).Hidden = True
260       End If

      ' Fill in the year total copy columns

270       .Cells(rowSp, colYearCopyTotal) = "=" & .Cells(rowSp, col).Address(columnAbsolute:=False, rowAbsolute:=False)
280       .range(.Cells(rowSp, colYearCopyTotal), .Cells(rowLast, colYearCopyTotal)).FormulaR1C1 = .range(.Cells(rowSp, colYearCopyTotal), .Cells(rowSp, colYearCopyTotal)).FormulaR1C1

290       .range(.Cells(rowSp, colYearCopyTotal), .Cells(rowLast, colYearCopyTotal)).Interior.Color = lngBackgroundColourYearTotal
300       .range(.Cells(rowSp, colYearCopyTotal), .Cells(rowLast, colYearCopyTotal)).Font.Bold = False
310       .range(.Cells(rowSp, colYearCopyTotal), .Cells(rowLast, colYearCopyTotal)).NumberFormat = strNumberFormatTotal

320       If strStatFieldname = "DET" Then
330             .columns(colYearCopyTotal).Hidden = True
340       End If
350       col = col + 1

      ' Mean

360     If strStatFieldname = "DET" Then

370           .Cells(rowMonth, col) = "SEASON"
380           .Cells(rowDay, col) = "MEAN"
390           .Cells(rowSp, col) = "=countif(" & .Cells(rowFirst, col).Address(columnAbsolute:=False, rowAbsolute:=False) & ":" & .Cells(rowLast, col).Address(columnAbsolute:=False, rowAbsolute:=False) & ","">0"")"
400           .Cells(rowInd, col) = "=sum(" & .Cells(rowFirst, col).Address(columnAbsolute:=False, rowAbsolute:=False) & ":" & .Cells(rowLast, col).Address(columnAbsolute:=False, rowAbsolute:=False) & ")"
              
410           .Cells(rowFirst, col) = "=sum(" & strSeasonSum & ")/count(" & strSeasonCount & ")"
420           .range(.Cells(rowFirst, col), .Cells(rowLast, col)).FormulaR1C1 = .range(.Cells(rowFirst, col), .Cells(rowFirst, col)).FormulaR1C1
              
430           .range(.Cells(rowDay, col), .Cells(rowLast, col)).Interior.Color = lngBackgroundColourYear
440           .range(.Cells(rowFirst, col), .Cells(rowLast, col)).NumberFormat = strNumberFormatYear
450           .Cells(rowInd, col).NumberFormat = strNumberFormatMean
460           .range(.Cells(rowSp, col), .Cells(rowLast, col)).Font.Bold = True
    
470           If strStatFieldname <> "DET" Then
480               .columns(col).Hidden = True
490           End If

      ' Fill in the year mean copy columns

500           .Cells(rowSp, colYearCopyMean) = "=" & .Cells(rowSp, col).Address(columnAbsolute:=False, rowAbsolute:=False)
510           .range(.Cells(rowSp, colYearCopyMean), .Cells(rowLast, colYearCopyMean)).FormulaR1C1 = .range(.Cells(rowSp, colYearCopyMean), .Cells(rowSp, colYearCopyMean)).FormulaR1C1
    
520           .range(.Cells(rowSp, colYearCopyMean), .Cells(rowLast, colYearCopyMean)).Interior.Color = lngBackgroundColourYear
530           .range(.Cells(rowSp, colYearCopyMean), .Cells(rowLast, colYearCopyMean)).Font.Bold = False
    
540           .range(.Cells(rowFirst, colYearCopyMean), .Cells(rowLast, colYearCopyMean)).NumberFormat = strNumberFormatYear
550           .Cells(rowInd, colYearCopyMean).NumberFormat = strNumberFormatInd
              
560             If strStatFieldname <> "DET" Then
570                 .columns(colYearCopyMean).Hidden = True
580             End If
              
590           col = col + 1
600       End If

610   End With

          'DD Error Handler Start
Exit_label:
620       Exit Sub
Err_label:
630       Select Case Err.Number
          Case Else
640            Call LogError("basDETSeasonSpreadsheet", "DETSeasonSpreadsheet_Season_F1")
650       End Select
660       Resume Exit_label
          ' DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' DETSeasonSpreadsheet_Season_FR
'---------------------------------------------------------------------------------------
'
' fill in the All-Year column

Private Sub DETSeasonSpreadsheet_Season_FR()
10       On Error GoTo Err_label

20    With oSheet

30        .Cells(rowDay, colYearAll) = "TOTALS"
          
40        .Cells(rowSp, colYearAll) = "=countif(" & .Cells(rowFirst, colYearAll).Address(columnAbsolute:=False, rowAbsolute:=False) & ":" & .Cells(rowLast, colYearAll).Address(columnAbsolute:=False, rowAbsolute:=False) & ","">0"")"
50        .Cells(rowInd, colYearAll).NumberFormat = strNumberFormatYearAllSp
          
60        .Cells(rowInd, colYearAll) = "=sum(" & .Cells(rowFirst, colYearAll).Address(columnAbsolute:=False, rowAbsolute:=False) & ":" & .Cells(rowLast, colYearAll).Address(columnAbsolute:=False, rowAbsolute:=False) & ")"
70        .Cells(rowInd, colYearAll).NumberFormat = strNumberFormatYearAllInd

80        .Cells(rowFirst, colYearAll) = "=sum(" & strYearAllSum & ")"
          
90        .range(.Cells(rowFirst, colYearAll), .Cells(rowLast, colYearAll)).FormulaR1C1 = .range(.Cells(rowFirst, colYearAll), .Cells(rowFirst, colYearAll)).FormulaR1C1

100       .range(.Cells(rowFirst, colYearAll), .Cells(rowLast, colYearAll)).NumberFormat = strNumberFormatYearAllData
110       .range(.Cells(rowSp, colYearAll), .Cells(rowLast, colYearAll)).Interior.Color = lngBackgroundColourAllYearTotal
120       .range(.Cells(rowSp, colYearAll), .Cells(rowLast, colYearAll)).Font.Color = vbWhite


130   End With

          'DD Error Handler Start
Exit_label:
140       Exit Sub
Err_label:
150       Select Case Err.Number
          Case Else
160      Call LogError("basDETSeasonSpreadsheet", "DETSeasonSpreadsheet_Season_FR")
170       End Select
180       Resume Exit_label
          ' DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' MonthNameAbbreviation
' NOT USED
'---------------------------------------------------------------------------------------

Private Function MonthNameAbbreviation(ByVal datDateEx As Date) As String
10       On Error GoTo Err_label

20        Select Case Month(datDateEx)
          Case 1
30            MonthNameAbbreviation = "Jan"
40        Case 2
50            MonthNameAbbreviation = "Feb"
60        Case 3
70            MonthNameAbbreviation = "Mar"
80        Case 4
90            MonthNameAbbreviation = "Apr"
100       Case 5
110           MonthNameAbbreviation = "May"
120       Case 6
130           MonthNameAbbreviation = "Jun"
140       Case 7
150           MonthNameAbbreviation = "Jul"
160       Case 8
170           MonthNameAbbreviation = "Aug"
180       Case 9
190           MonthNameAbbreviation = "Sep"
200       Case 10
210           MonthNameAbbreviation = "Oct"
220       Case 11
230           MonthNameAbbreviation = "Nov"
240       Case 12
250           MonthNameAbbreviation = "Dec"
260       Case Else
270           MonthNameAbbreviation = ""
280       End Select

          'DD Error Handler Start
Exit_label:
290       Exit Function
Err_label:
300       Select Case Err.Number
          Case Else
310            Call LogError("basDETSeasonSpreadsheet", "MonthNameAbbreviation")
320       End Select
330       Resume Exit_label
          ' DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' toColYearCopyMean
'---------------------------------------------------------------------------------------

Private Function toColYearCopyMean(ByVal intYearEx As Integer) As Long
10       On Error GoTo Err_label

20    toColYearCopyMean = intYearEx - intYearFrom + colYearCopyMeanFirst

          'DD Error Handler Start
Exit_label:
30        Exit Function
Err_label:
40        Select Case Err.Number
          Case Else
50             Call LogError("basDETSeasonSpreadsheet", "toColYearCopyMean")
60        End Select
70        Resume Exit_label
          ' DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' toColYearCopyTotal
'---------------------------------------------------------------------------------------

Private Function toColYearCopyTotal(ByVal intYearEx As Integer) As Long
10       On Error GoTo Err_label

20    toColYearCopyTotal = intYearEx - intYearFrom + colYearCopyTotalFirst

          'DD Error Handler Start
Exit_label:
30        Exit Function
Err_label:
40        Select Case Err.Number
          Case Else
50             Call LogError("basDETSeasonSpreadsheet", "toColYearCopyTotal")
60        End Select
70        Resume Exit_label
          ' DD Error Handler End
End Function
