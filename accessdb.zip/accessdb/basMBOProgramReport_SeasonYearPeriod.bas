'---------------------------------------------------------------------------------------
' Module: basMBOProgramReport_SeasonYearPeriod
' Author: David Davey
'---------------------------------------------------------------------------------------

Option Compare Database
Option Explicit

' Seasons

Const conNonSeason As Integer = -1
Const conWinter  As Integer = 0
Const conSpring  As Integer = 1
Const conSummer  As Integer = 2
Const conFall    As Integer = 3
Const conOwling  As Integer = 4
Const conRTHU    As Integer = 5
Const conNestbox As Integer = 6
Const conSummerNestbox As Integer = 7

Const conDETSeasonFirst As Integer = -1
Const conDETSeasonLast  As Integer = 3

Const intSeasonFirst As Integer = -1
Const intSeasonLast  As Integer = 7

' Periods

' intPeriodLast is declared in basMBOProgramReport and loaded in basMBOProgramReport.MBOProgramReportPeriodsCount  It is the largest period in any season and any year (14)

' Number of periods in a season x year
' Maximum number of periods in a season (max. over all years for a given season)
' Maximum number of periods (max for all years and seaons)
'
' Public intPeriodLast_SeasonYear(conCaptureSeasonFirst To conCaptureSeasonLast, intYearFirst To intYearLast) As Integer
' Public intPeriodLast_Season(conCaptureSeasonFirst To conCaptureSeasonLast) As Integer
' Public intPeriodLast As Integer

' intPeriodTotal = intPeriodLast + 1
' intPeriodMean = intPeriodLast + 2
' intPeriodSeason = intPeriodLast + 3
' intPeriodLastEx = intPeriodLast + 3

' The intPeriodTotal statistic
'      is the sum of all the per-period statistics.
'      is never reported.
'      is used during the calculation of the intPeriodMean ststistic
'      For some statistics (e.g. # birds) it is copied to the intPeriodSeason statistic (which IS reported in the "All years" column)
'      For other statistics (e.g. # species) it is not copied to the intPeriodSeason statistic.

Public intPeriodTotal As Integer        ' Loaded in MBOProgramReport_SeasonYearPeriod_Part_A
Public intPeriodMean As Integer         ' Loaded in MBOProgramReport_SeasonYearPeriod_Part_A
Public intPeriodSeason As Integer       ' Loaded in MBOProgramReport_SeasonYearPeriod_Part_A
Public intPeriodLastEx As Integer       ' Loaded in MBOProgramReport_SeasonYearPeriod_Part_A

' Statistics

Public Const conStatCapturePeriods                 As Integer = 0
Public Const conStatDETDays                        As Integer = 1
Public Const conStatBNDBirds                       As Integer = 2
Public Const conStatBNDBirdsCumulative             As Integer = 3
Public Const conStatBNDSpecies                     As Integer = 4
Public Const conStatBNDSpeciesCumulative           As Integer = 5
Public Const conStatRETBirds                       As Integer = 6
Public Const conStatRETBirdsCumulative             As Integer = 7
Public Const conStatRETSpecies                     As Integer = 8
Public Const conStatRETSpeciesCumulative           As Integer = 9
Public Const conStatREPBirds                       As Integer = 10
Public Const conStatREPBirdsCumulative             As Integer = 11
Public Const conStatREPSpecies                     As Integer = 12
Public Const conStatREPSpeciesCumulative           As Integer = 13
Public Const conStatAlienBirds                     As Integer = 14
Public Const conStatAlienBirdsCumulative           As Integer = 15
Public Const conStatAlienSpecies                   As Integer = 16
Public Const conStatAlienSpeciesCumulative         As Integer = 17
Public Const conStatCensusSpecies                  As Integer = 18
Public Const conStatCensusSpeciesCumulative        As Integer = 19
Public Const conStatDETSpecies                     As Integer = 20
Public Const conStatDETSpeciesCumulative           As Integer = 21
Public Const conStatNetHours                       As Integer = 22
Public Const conStatNetHoursCumulative             As Integer = 23
Public Const conStatBirdsPer100NetHours            As Integer = 24
Public Const conStatBirdsPer100NetHoursCumulative       As Integer = 25
Public Const conStatFullNetCoverageDays                 As Integer = 26
Public Const conStatFullNetCoverageDaysCumulative       As Integer = 27
Public Const conStatCaptureDays                         As Integer = 28
Public Const conStatCaptureDaysCumulative               As Integer = 29
Public Const conStatDETDaysCumulative                   As Integer = 30
Public Const conStatDETorCaptureDays                    As Integer = 31
Public Const conStatDETorCaptureDaysCumulative          As Integer = 32
Public Const conStatPercentBandedHatchYear              As Integer = 33
Public Const conStatPercentBandedHatchYearCumulative    As Integer = 34
Public Const conStatDETBirds                            As Integer = 35
Public Const conStatDETBirdsCumulative                  As Integer = 36
Public Const conStatDETMeanBirds                        As Integer = 37
Public Const conStatDETMeanBirdsCumulative              As Integer = 38
Public Const conStatCensusDays                          As Integer = 39
Public Const conStatCensusDaysCumulative                As Integer = 40
Public Const conStatDETPeriods                          As Integer = 41
Public Const conStatCensusPeriods                       As Integer = 42
Public Const conStatNetDays                             As Integer = 43
Public Const conStatNetDaysCumulative                   As Integer = 44
Public Const conStatBirdsRETREPPer100NetHours           As Integer = 45
Public Const conStatBirdsRETREPPer100NetHoursCumulative As Integer = 46
Public Const conStatBandedTRES                          As Integer = 47       ' Nestling only
Public Const conStatBandedTRESHatchYear                 As Integer = 48       ' Nestling only
Public Const intStatFirst                               As Integer = 0
Public Const intStatLast                                As Integer = 48

' A statistics is a capture day statistic, a census day statistic, or a DET day statistic
' A capture day statistic is measured iff the day is a capture day, etc
'
' The following statistics are census statistics:
' conStatCensusDays, conStatCensusPeriods, conStatCensusSpecies
' conStatCensusDaysCumulative, conStatCensusPeriodsCumulative, conStatCensusSpeciesCumulative
'
' The following statistics are DET statistics:
' conStatDETDays, conStatDETPeriods, conStatDETSpecies, conStatDETBirds, conStatDETMeanBirds
' conStatDETDaysCumulative, conStatDETPeriodsCumulative, conStatDETSpeciesCumulative, conStatDETBirdsCumulative, conStatDETMeanBirdsCumulative
'
' All the other statistics are day statistics

' Public Function getStatDays(ByVal intStat As Integer) As Integer

' Season x Year x Period statistics
' ---------------------------------

Public dblStatSeasonYearPeriod() As Double      ' Redim in MBOProgramReport_SeasonYearPeriod_Part_A
'       (intStatFirst To intStatLast,
'        intSeasonFirst To intSeasonLastEx,
'        intYearFirst To intYearLastEx,
'        1 To intPeriodLastEx)

' intYearTotal = intYearLast + 1
' intYearMean = intYearLast + 2
' intYearMax = intYearLast + 3
' intYearMin = intYearLast + 4
' intYearSeason = intYearLast + 5
' intYearTotal_PreviousYears = intYearLast + 6
' intYearMean_PreviousYears = intYearLast + 7
' intYearTotal_MAPS_PreviousYears = intYearLast + 8
' intYearMean_MAPS_PreviousYears = intYearLast + 9
' intYearLastEx = intYearLast + 9

Public intYearTotal As Integer                      ' Assigned in MBOProgramReport_SeasonYearPeriod_Part_A
Public intYearMean As Integer                       ' Assigned in MBOProgramReport_SeasonYearPeriod_Part_A
Public intYearMax As Integer                        ' Assigned in MBOProgramReport_SeasonYearPeriod_Part_A
Public intYearMin As Integer                        ' Assigned in MBOProgramReport_SeasonYearPeriod_Part_A
Public intYearSeason As Integer                     ' Assigned in MBOProgramReport_SeasonYearPeriod_Part_A
Public intYearLastEx As Integer                     ' Assigned in MBOProgramReport_SeasonYearPeriod_Part_A
Public intYearTotal_PreviousYears As Integer        ' Assigned in MBOProgramReport_SeasonYearPeriod_Part_A
Public intYearMean_PreviousYears  As Integer        ' Assigned in MBOProgramReport_SeasonYearPeriod_Part_A
Public intYearTotal_MAPS_PreviousYears As Integer   ' Assigned in MBOProgramReport_SeasonYearPeriod_Part_A                Summer only  2009 - previous year
Public intYearMean_MAPS_PreviousYears As Integer    ' Assigned in MBOProgramReport_SeasonYearPeriod_Part_A                Summer only  2009 - previous year


' For a given season,
'     intCapturesYearsCountSeason(intSeason)                = the count of Capture Years over all years
'     intCapturesYears_PreviousYears_CountSeason(intSeason) = the count of Capture Years over previous years
'     intDETYearsCountSeason(intSeason)                     = the count of DET Years over all years
'     intDETYears_PreviousYears_CountSeason(intSeason)      = the count of DET Years over previous years
'     intCensusYearsCountSeason(intSeason)                  = the count of DET Years over all years
'     intCensusYears_PreviousYears_CountSeason(intSeason)   = the count of DET Years over previous years

' intCapturesYears_MAPS_PreviousYears_CountSeason           = the count of Capture Years over previous MAPS years
' intDETYears_MAPS_PreviousYears_CountSeason                = the count of DET Years over previous MAPS years
' intCensusYears_MAPS_PreviousYears_CountSeason             = the count of DET Years over previous MAPS years
'


Public intCapturesYearsCountSeason(intSeasonFirst To intSeasonLast)                         ' Loaded in  MBOProgramReport_SeasonYearPeriod_Part_A
Public intCapturesYears_PreviousYears_CountSeason(intSeasonFirst To intSeasonLast)          ' Loaded in  MBOProgramReport_SeasonYearPeriod_Part_A
Public intCapturesYears_MAPS_PreviousYears_Count                                            ' Loaded in  MBOProgramReport_SeasonYearPeriod_Part_A

Public intDETYearsCountSeason(intSeasonFirst To intSeasonLast) As Integer                   ' Loaded in  MBOProgramReport_SeasonYearPeriod_Part_A
Public intDETYears_PreviousYears_CountSeason(intSeasonFirst To intSeasonLast) As Integer    ' Loaded in  MBOProgramReport_SeasonYearPeriod_Part_A
Public intDETYears_MAPS_PreviousYears_Count                                                 ' Loaded in  MBOProgramReport_SeasonYearPeriod_Part_A

Public intCensusYearsCountSeason(intSeasonFirst To intSeasonLast) As Integer                ' Loaded in  MBOProgramReport_SeasonYearPeriod_Part_A
Public intCensusYears_PreviousYears_CountSeason(intSeasonFirst To intSeasonLast) As Integer ' Loaded in  MBOProgramReport_SeasonYearPeriod_Part_A
Public intCensusYears_MAPS_PreviousYears_Count                                              ' Loaded in  MBOProgramReport_SeasonYearPeriod_Part_A

' For a given season x year
'     intCapturesYearsCountSeasonYear(season, year) = 1 if the season x year had any capture days, 0 otherwise

Public intCapturesYearsCountSeasonYear()                                                       ' Allocated and loaded in  MBOProgramReport_SeasonYearPeriod_Part_A

'Public intDETYearsCountSeasonYear()                                                            ' Allocated and loaded in  MBOProgramReport_SeasonYearPeriod_Part_A
'Public intCensusYearsCountSeasonYear()                                                         ' Allocated and loaded in  MBOProgramReport_SeasonYearPeriod_Part_A


Const intYearFirst_MAPS = 2009


Public Function getCaptureDays_SeasonYearPeriod(intSeason, intYear, intPeriod) As Integer
10        getCaptureDays_SeasonYearPeriod = dblStatSeasonYearPeriod(conStatCaptureDays, intSeason, intYear, intPeriod)
End Function

Public Function getDETDays_SeasonYearPeriod(intSeason, intYear, intPeriod) As Integer
10        getDETDays_SeasonYearPeriod = dblStatSeasonYearPeriod(conStatDETDays, intSeason, intYear, intPeriod)
End Function


Public Function getCaptureDays_SeasonYear(intSeason, intYear) As Integer
10        getCaptureDays_SeasonYear = dblStatSeasonYearPeriod(conStatCaptureDays, intSeason, intYear, intPeriodTotal)
End Function

Public Function getDETDays_SeasonYear(intSeason, intYear) As Integer
10        getDETDays_SeasonYear = dblStatSeasonYearPeriod(conStatDETDays, intSeason, intYear, intPeriodTotal)
End Function

Public Function getCaptureDays_Season(intSeason) As Integer
10        getCaptureDays_Season = dblStatSeasonYearPeriod(conStatCaptureDays, intSeason, intYearTotal, intPeriodTotal)
End Function

Public Function getDETDays_Season(intSeason) As Integer
10        getDETDays_Season = dblStatSeasonYearPeriod(conStatDETDays, intSeason, intYearTotal, intPeriodTotal)
End Function

Public Function getDETDays_SeasonPeriod(intSeason, intPeriod) As Integer
10        getDETDays_SeasonPeriod = dblStatSeasonYearPeriod(conStatDETDays, intSeason, intYearTotal, intPeriod)
End Function

Public Function getDETPeriods_SeasonPeriod(intSeason, intPeriod) As Integer
10        getDETPeriods_SeasonPeriod = dblStatSeasonYearPeriod(conStatDETPeriods, intSeason, intYearTotal, intPeriod)
End Function

Public Function getCapturesYears_SeasonPeriod(intSeason, intPeriod) As Integer
10    getCapturesYears_SeasonPeriod = dblStatSeasonYearPeriod(conStatCapturePeriods, intSeason, intYearTotal, intPeriod)
End Function

'---------------------------------------------------------------------------------------
' IsCumulativeStat
'---------------------------------------------------------------------------------------
 
Private Function IsCumulativeStat(ByVal intStat As Integer) As Boolean

10    On Error GoTo Err_label

20    Select Case intStat
      Case conStatCaptureDaysCumulative, conStatDETDaysCumulative, conStatCensusDaysCumulative, _
           conStatBNDBirdsCumulative, conStatBNDSpeciesCumulative, _
           conStatRETBirdsCumulative, conStatRETSpeciesCumulative, _
           conStatREPBirdsCumulative, conStatREPSpeciesCumulative, _
           conStatAlienBirdsCumulative, conStatAlienSpeciesCumulative, _
           conStatCensusSpeciesCumulative, _
           conStatDETBirdsCumulative, conStatDETSpeciesCumulative, conStatDETMeanBirdsCumulative, _
           conStatNetHoursCumulative, _
           conStatFullNetCoverageDaysCumulative, _
           conStatBirdsPer100NetHoursCumulative, conStatBirdsRETREPPer100NetHoursCumulative, _
           conStatPercentBandedHatchYearCumulative, _
           conStatNetDaysCumulative
30       IsCumulativeStat = True
40    Case Else
50        IsCumulativeStat = False
60    End Select

'DD Error Handler Start
Exit_label:
70         Exit Function
Err_label:
80         Select Case Err.Number
     Case Else
90        Call LogError("basMBOProgramReport_SeasonYearPeriod", "IsCumulativeStat")
100        End Select
110        Resume Exit_label
'DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' DisplayPeriodTotal_Column
'
' Total for each season x year, aggregeted over periods
' The Period Total is a column
'---------------------------------------------------------------------------------------

Private Function DisplayPeriodTotal_Column(ByVal intStat As Integer) As Boolean
    
10    On Error GoTo Err_label

20    DisplayPeriodTotal_Column = Not IsCumulativeStat(intStat)

'20    Select Case intStat
'      Case conStatCapturePeriods, conStatCaptureDays, conStatDETDays, conStatDETPeriods, conStatCensusDays, conStatCensusPeriods, _
'           conStatBNDBirds, conStatBNDSpecies, _
'           conStatRETBirds, conStatRETSpecies, _
'           conStatREPBirds, conStatREPSpecies, _
'           conStatAlienBirds, conStatAlienSpecies, _
'           conStatCensusSpecies, conStatDETSpecies, _
'           conStatNetHours, conStatBirdsPer100NetHours, _
'           conStatBirdsRETREPPer100NetHours, _
'           conStatFullNetCoverageDays, conStatCaptureDays, _
'           conStatPercentBandedHatchYear, _
'           conStatDETBirds, conStatDETMeanBirds
'30       DisplayPeriodTotal_Column = True
'40    Case Else
'50        DisplayPeriodTotal_Column = False
'60    End Select

      'DD Error Handler Start
Exit_label:
30         Exit Function
Err_label:
40         Select Case Err.Number
           Case Else
50              Call LogError("basMBOProgramReport_SeasonYearPeriod", "DisplayPeriodMean_Column")
60         End Select
70         Resume Exit_label
      'DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' DisplayPeriodMean_Column
'
' Mean for each season x year, aggregeted over periods
' The Period Mean is a column
'---------------------------------------------------------------------------------------

Private Function DisplayPeriodMean_Column(ByVal intStat As Integer) As Boolean
10    On Error GoTo Err_label

20    DisplayPeriodMean_Column = Not IsCumulativeStat(intStat)

'20    Select Case intStat
'      Case conStatCapturePeriods, conStatCaptureDays, conStatDETPeriods, conStatDETDays, conStatDETorCaptureDays, _
'        conStatCensusDays, conStatCensusPeriods, _
'           conStatBNDBirds, conStatBNDSpecies, _
'           conStatRETBirds, conStatRETSpecies, _
'           conStatREPBirds, conStatREPSpecies, _
'           conStatAlienBirds, conStatAlienSpecies, _
'           conStatCensusSpecies, conStatDETSpecies, _
'           conStatNetHours, conStatBirdsPer100NetHours, _
'           conStatFullNetCoverageDays, conStatCaptureDays, _
'           conStatPercentBandedHatchYear, _
'           conStatDETBirds, conStatDETMeanBirds
'30       DisplayPeriodMean_Column = True
'40    Case Else
'50        DisplayPeriodMean_Column = False
'60    End Select

      'DD Error Handler Start
Exit_label:
30         Exit Function
Err_label:
40         Select Case Err.Number
           Case Else
50              Call LogError("basMBOProgramReport_SeasonYearPeriod", "DisplayPeriodMean_Column")
60         End Select
70         Resume Exit_label
      'DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' DisplayPeriodSeason_Column
'
' The PeriodSeason is a column
'---------------------------------------------------------------------------------------
 
Private Function DisplayPeriodSeason_Column(ByVal intStat As Integer) As Boolean
10    On Error GoTo Err_label

20    DisplayPeriodSeason_Column = Not IsCumulativeStat(intStat)

'20    Select Case intStat
'      Case conStatCaptureDaysCumulative, conStatDETDaysCumulative, conStatCensusDaysCumulative, _
'           conStatBNDBirdsCumulative, conStatBNDSpeciesCumulative, _
'           conStatRETBirdsCumulative, conStatRETSpeciesCumulative, _
'           conStatREPBirdsCumulative, conStatREPSpeciesCumulative, _
'           conStatAlienBirdsCumulative, conStatAlienSpeciesCumulative, _
'           conStatCensusSpeciesCumulative, _
'           conStatDETBirdsCumulative, conStatDETSpeciesCumulative, conStatDETMeanBirdsCumulative, _
'           conStatNetHoursCumulative, _
'           conStatFullNetCoverageDaysCumulative, _
'           conStatBirdsPer100NetHoursCumulative, conStatBirdsRETREPPer100NetHoursCumulative, _
'           conStatPercentBandedHatchYearCumulative
'
'30              DisplayPeriodSeason_Column = False
'40    Case Else
'50              DisplayPeriodSeason_Column = True
'60    End Select

      'DD Error Handler Start
Exit_label:
30         Exit Function
Err_label:
40         Select Case Err.Number
           Case Else
50              Call LogError("basMBOProgramReport_SeasonYearPeriod", "DisplayPeriodSeason_Column")
60         End Select
70         Resume Exit_label
      'DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' DisplayYearTotal_Row
'
' Mean for each season x period, aggregated over years
' the Year Total is a row
'---------------------------------------------------------------------------------------

Private Function DisplayYearTotal_Row(ByVal intStat As Integer) As Boolean
10    On Error GoTo Err_label

20    DisplayYearTotal_Row = Not IsCumulativeStat(intStat)

'20    Select Case intStat
'      Case conStatCapturePeriods, conStatCaptureDays, conStatDETPeriods, conStatDETDays, conStatDETorCaptureDays, _
'           conStatCensusDays, conStatCensusPeriods, _
'           conStatBNDBirds, conStatBNDSpecies, _
'           conStatRETBirds, conStatRETSpecies, _
'           conStatREPBirds, conStatREPSpecies, _
'           conStatAlienBirds, conStatAlienSpecies, _
'           conStatCensusSpecies, conStatDETSpecies, _
'           conStatNetHours, conStatBirdsPer100NetHours, conStatBirdsRETREPPer100NetHours, _
'           conStatFullNetCoverageDays, conStatCaptureDays, _
'           conStatPercentBandedHatchYear, _
'           conStatDETBirds, conStatDETMeanBirds
'30        DisplayYearTotal_Row = True
'40    Case Else
'50        DisplayYearTotal_Row = False
'60    End Select

      'DD Error Handler Start
Exit_label:
30         Exit Function
Err_label:
40         Select Case Err.Number
           Case Else
50              Call LogError("basMBOProgramReport_SeasonYearPeriod", "DisplayYearTotal_Row")
60         End Select
70         Resume Exit_label
      'DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' DisplayYearMean_Row
'
' Mean for each season x period, aggregated over years
' the Year Mean is a row
'---------------------------------------------------------------------------------------

Private Function DisplayYearMean_Row(ByVal intStat As Integer) As Boolean
10    On Error GoTo Err_label

20    DisplayYearMean_Row = Not IsCumulativeStat(intStat)

'20    Select Case intStat
'      Case conStatCapturePeriods, conStatCaptureDays, conStatDETPeriods, conStatDETDays, conStatDETorCaptureDays, _
'           conStatCensusDays, conStatCensusPeriods, _
'           conStatBNDBirds, conStatBNDSpecies, _
'           conStatRETBirds, conStatRETSpecies, _
'           conStatREPBirds, conStatREPSpecies, _
'           conStatAlienBirds, conStatAlienSpecies, _
'           conStatCensusSpecies, conStatDETSpecies, _
'           conStatNetHours, conStatBirdsPer100NetHours, conStatBirdsRETREPPer100NetHours, _
'           conStatFullNetCoverageDays, conStatCaptureDays, _
'           conStatPercentBandedHatchYear, _
'           conStatDETBirds, conStatDETMeanBirds
'30        DisplayYearMean_Row = True
'40    Case Else
'50        DisplayYearMean_Row = False
'60    End Select

      'DD Error Handler Start
Exit_label:
30         Exit Function
Err_label:
40         Select Case Err.Number
           Case Else
50              Call LogError("basMBOProgramReport_SeasonYearPeriod", "DisplayYearMean_Row")
60         End Select
70         Resume Exit_label
      'DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' DisplayYearSeason_Row
'
' The YearSeason is a row
'---------------------------------------------------------------------------------------
' A summary row, one value for each period

Private Function DisplayYearSeason_Row(ByVal intStat As Integer) As Boolean
10    On Error GoTo Err_label

20    DisplayYearSeason_Row = Not IsCumulativeStat(intStat)

'20    Select Case intStat
'      Case conStatCaptureDaysCumulative, conStatDETDaysCumulative, conStatCensusDaysCumulative, _
'           conStatBNDBirdsCumulative, conStatBNDSpeciesCumulative, _
'           conStatRETBirdsCumulative, conStatRETSpeciesCumulative, _
'           conStatREPBirdsCumulative, conStatREPSpeciesCumulative, _
'           conStatAlienBirdsCumulative, conStatAlienSpeciesCumulative, _
'           conStatCensusSpeciesCumulative, _
'           conStatDETBirdsCumulative, conStatDETSpeciesCumulative, conStatDETMeanBirdsCumulative, _
'           conStatNetHoursCumulative, _
'           conStatFullNetCoverageDaysCumulative, _
'           conStatBirdsPer100NetHoursCumulative, conStatBirdsRETREPPer100NetHoursCumulative, _
'           conStatPercentBandedHatchYearCumulative
'30              DisplayYearSeason_Row = False
'40    Case Else
'50              DisplayYearSeason_Row = True
'60    End Select

      'DD Error Handler Start
Exit_label:
30         Exit Function
Err_label:
40         Select Case Err.Number
           Case Else
50              Call LogError("basMBOProgramReport_SeasonYearPeriod", "DisplayYearSeason_Row")
60         End Select
70         Resume Exit_label
      'DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' MBOProgramReport_SeasonYearPeriod_Part_A
'---------------------------------------------------------------------------------------
 
Public Sub MBOProgramReport_SeasonYearPeriod_Part_A( _
    ByVal intYearFirst As Integer, _
    ByVal intYearLast As Integer, _
    ByVal strLocation As String, _
    ByRef oBook As Excel.Workbook)

10    On Error GoTo Err_label

      ' Initialise global variables

      'Public intYearTotal As Integer                      ' Assigned in MBOProgramReport_SeasonYearPeriod_Part_A
      'Public intYearMean As Integer                       ' Assigned in MBOProgramReport_SeasonYearPeriod_Part_A
      'Public intYearMax As Integer                        ' Assigned in MBOProgramReport_SeasonYearPeriod_Part_A
      'Public intYearMin As Integer                        ' Assigned in MBOProgramReport_SeasonYearPeriod_Part_A
      'Public intYearSeason As Integer                     ' Assigned in MBOProgramReport_SeasonYearPeriod_Part_A
      'Public intYearLastEx As Integer                     ' Assigned in MBOProgramReport_SeasonYearPeriod_Part_A
      'Public intYearTotal_PreviousYears As Integer        ' Assigned in MBOProgramReport_SeasonYearPeriod_Part_A
      'Public intYearMean_PreviousYears  As Integer        ' Assigned in MBOProgramReport_SeasonYearPeriod_Part_A
      'Public intYearTotal_MAPS_PreviousYears As Integer   ' Assigned in MBOProgramReport_SeasonYearPeriod_Part_A                Summer only  2009 - previous year
      'Public intYearMean_MAPS_PreviousYears As Integer    ' Assigned in MBOProgramReport_SeasonYearPeriod_Part_A                Summer only  2009 - previous year

20    intYearTotal = intYearLast + 1
30    intYearMean = intYearLast + 2
40    intYearMax = intYearLast + 3
50    intYearMin = intYearLast + 4
60    intYearSeason = intYearLast + 5
70    intYearTotal_PreviousYears = intYearLast + 6
80    intYearMean_PreviousYears = intYearLast + 7
90    intYearTotal_MAPS_PreviousYears = intYearLast + 8
100   intYearMean_MAPS_PreviousYears = intYearLast + 9
110   intYearLastEx = intYearLast + 9

      'Public intPeriodTotal As Integer        ' Loaded in MBOProgramReport_SeasonYearPeriod_Part_A
      'Public intPeriodMean As Integer         ' Loaded in MBOProgramReport_SeasonYearPeriod_Part_A
      'Public intPeriodSeason As Integer       ' Loaded in MBOProgramReport_SeasonYearPeriod_Part_A
      'Public intPeriodLastEx As Integer       ' Loaded in MBOProgramReport_SeasonYearPeriod_Part_A

120   intPeriodTotal = intPeriodLast + 1
130   intPeriodMean = intPeriodLast + 2
140   intPeriodSeason = intPeriodLast + 3
150   intPeriodLastEx = intPeriodLast + 3

      ' Allocate dblStatSeasonYearPeriod()

160   ReDim dblStatSeasonYearPeriod(intStatFirst To intStatLast, intSeasonFirst To intSeasonLast, _
                                    intYearFirst To intYearLastEx, 1 To intPeriodLastEx) As Double

      Dim intStat As Integer
      Dim intSeason As Integer
      Dim intYear As Integer
      Dim intPeriod As Integer

      ' Initialise ALL elements of dblStatSeasonYearPeriod to 0.0

170   For intStat = intStatFirst To intStatLast
180       For intSeason = intSeasonFirst To intSeasonLast
190           For intYear = intYearFirst To intYearLastEx
200               For intPeriod = 1 To intPeriodLastEx
210                   dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriod) = 0
220               Next
230           Next
240       Next
250   Next

260   Call MBOProgramReport_SeasonYearPeriod_CaptureDays(intYearFirst, intYearLast, strLocation)
270   Call MBOProgramReport_SeasonYearPeriod_CapturePeriods(intYearFirst, intYearLast, strLocation)
280   Call MBOProgramReport_SeasonYearPeriod_DETDays(intYearFirst, intYearLast, strLocation)
290   Call MBOProgramReport_SeasonYearPeriod_DETPeriods(intYearFirst, intYearLast, strLocation)
300   Call MBOProgramReport_SeasonYearPeriod_CensusDays(intYearFirst, intYearLast, strLocation)
310   Call MBOProgramReport_SeasonYearPeriod_CensusPeriods(intYearFirst, intYearLast, strLocation)


      ' Assumption
      ' ----------
      ' MBOProgramReport_SeasonYearPeriod_TotalMean(conStatCaptureDays, intYearFirst, intYearLast, strLocation) has been called.
      '     It fills in dblStatSeasonYearPeriod(conStatCaptureDays, intSeason, intYear, intPeriodTotal)
      ' MBOProgramReport_SeasonYearPeriod_TotalMean(conStatDETDays, intYearFirst, intYearLast, strLocation) has been called
      '     It fills in dblStatSeasonYearPeriod(conStatDETDays, intSeason, intYear, intPeriodTotal)
      ' MBOProgramReport_SeasonYearPeriod_TotalMean(conStatCensusDays, intYearFirst, intYearLast, strLocation) has been called
      '     It fills in dblStatSeasonYearPeriod(conStatCensusDays, intSeason, intYear, intPeriodTotal)


      ' For a given season,
      '     intCapturesYearsCountSeason(intSeason)                = the count of Capture Years over all years
      '     intCapturesYears_PreviousYears_CountSeason(intSeason) = the count of Capture Years over previous years
      '     intDETYearsCountSeason(intSeason)                     = the count of DET Years over all years
      '     intDETYears_PreviousYears_CountSeason(intSeason)      = the count of DET Years over previous years
      '     intCensusYearsCountSeason(intSeason)                  = the count of DET Years over all years
      '     intCensusYears_PreviousYears_CountSeason(intSeason)   = the count of DET Years over previous years

      ' intCapturesYears_MAPS_PreviousYears_CountSeason           = the count of Capture Years over previous MAPS years
      ' intDETYears_MAPS_PreviousYears_CountSeason                = the count of DET Years over previous MAPS years
      ' intCensusYears_MAPS_PreviousYears_CountSeason             = the count of DET Years over previous MAPS years
      '
      ' For a given season x year
      '     intCapturesYearsCountSeasonYear(season, year) = 1 if the season x year had any capture days, 0 otherwise

      ' Load intCapturesYearsCountSeason(intSeason)
      ' Load intCapturesYears_PreviousYears_CountSeason(intSeason)

      Dim intTotal As Integer

320   For intSeason = intSeasonFirst To intSeasonLast
330       intTotal = 0
340       For intYear = intYearFirst To intYearLast - 1
350           intTotal = intTotal + IIf(dblStatSeasonYearPeriod(conStatCaptureDays, intSeason, intYear, intPeriodTotal) > 0, 1, 0)
360       Next
370       intCapturesYears_PreviousYears_CountSeason(intSeason) = intTotal
380       intCapturesYearsCountSeason(intSeason) = intTotal + IIf(dblStatSeasonYearPeriod(conStatCaptureDays, intSeason, intYearLast, intPeriodTotal) > 0, 1, 0)
390   Next

      ' Load intDETYearsCountSeason(intSeason)
      ' Load intDETYears_PreviousYears_CountSeason(intSeason)

400   For intSeason = intSeasonFirst To intSeasonLast
410       intTotal = 0
420       For intYear = intYearFirst To intYearLast - 1
430           intTotal = intTotal + IIf(dblStatSeasonYearPeriod(conStatDETDays, intSeason, intYear, intPeriodTotal) > 0, 1, 0)
440       Next
450       intDETYears_PreviousYears_CountSeason(intSeason) = intTotal
460       intDETYearsCountSeason(intSeason) = intTotal + IIf(dblStatSeasonYearPeriod(conStatDETDays, intSeason, intYearLast, intPeriodTotal) > 0, 1, 0)
470   Next

      ' Load intCensusYearsCountSeason(intSeason)
      ' Load intCensusYears_PreviousYears_CountSeason(intSeason)

480   For intSeason = intSeasonFirst To intSeasonLast
490       intTotal = 0
500       For intYear = intYearFirst To intYearLast - 1
510           intTotal = intTotal + IIf(dblStatSeasonYearPeriod(conStatCensusDays, intSeason, intYear, intPeriodTotal) > 0, 1, 0)
520       Next
530       intCensusYears_PreviousYears_CountSeason(intSeason) = intTotal
540       intCensusYearsCountSeason(intSeason) = intTotal + IIf(dblStatSeasonYearPeriod(conStatCensusDays, intSeason, intYearLast, intPeriodTotal) > 0, 1, 0)
550   Next

      ' Load intCapturesYears_MAPS_PreviousYears_Count

560   intTotal = 0
570   For intYear = intYearFirst To intYearLast - 1
580       intTotal = intTotal + IIf(dblStatSeasonYearPeriod(conStatDETDays, conSummer, intYear, intPeriodTotal) > 0, 1, 0)
590   Next
600   intCapturesYears_MAPS_PreviousYears_Count = intTotal

      ' Load intDETYears_MAPS_PreviousYears_Count

610   intTotal = 0
620   For intYear = intYearFirst To intYearLast - 1
630       intTotal = intTotal + IIf(dblStatSeasonYearPeriod(conStatDETDays, conSummer, intYear, intPeriodTotal) > 0, 1, 0)
640   Next
650   intDETYears_MAPS_PreviousYears_Count = intTotal

      ' Load intCensusYears_MAPS_PreviousYears_Count

660   intTotal = 0
670   For intYear = intYearFirst To intYearLast - 1
680       intTotal = intTotal + IIf(dblStatSeasonYearPeriod(conStatCensusDays, conSummer, intYear, intPeriodTotal) > 0, 1, 0)
690   Next
700   intCensusYears_MAPS_PreviousYears_Count = intTotal

      ' Allocate and load intCapturesYearsCountSeasonYear(season,year)

710   ReDim intCapturesYearsCountSeasonYear(intSeasonFirst To intSeasonLast, intYearFirst To intYearLast)

720   For intSeason = intSeasonFirst To intSeasonLast
730       For intYear = intYearFirst To intYearLast
740           intCapturesYearsCountSeasonYear(intSeason, intYear) = IIf(dblStatSeasonYearPeriod(conStatCaptureDays, intSeason, intYear, intPeriodTotal) > 0, 1, 0)
750       Next
760   Next

      'DD Error Handler Start
Exit_label:
770        Exit Sub
Err_label:
780        Select Case Err.Number
           Case Else
790       Call LogError("basMBOProgramReport_SeasonYearPeriod", "MBOAnnualProgramReport_SeasonYearPeriod_Part_A")
800        End Select
810        Resume Exit_label
      'DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' MBOProgramReport_SeasonYearPeriod
'---------------------------------------------------------------------------------------
 
Public Sub MBOProgramReport_SeasonYearPeriod_Part_B( _
    ByVal intYearFirst As Integer, _
    ByVal intYearLast As Integer, _
    ByVal strLocation As String, _
    ByRef oBook As Excel.Workbook)

10    On Error GoTo Err_label

          ' Public variables, loaded in MBOProgramReport_SeasonYearPeriod_Part_A
          ' --------------------------------------------------------------------
          ' intYearTotal              Total over all years
          ' intYearMean               Mean over all years
          ' intYearMax
          ' intYearMin
          ' intYearSeason
          ' intYearTotal_PriorYears   Total over all previous years
          ' intYearMean_PriorYears    Mean over all previous years
          ' intYearLastEx
          '
          ' intPeriodTotal
          ' intPeriodMean
          ' intPeriodSeason
          ' intPeriodLastEx
          '
          ' dblStatSeasonYearPeriod(intStatFirst To intStatLast, intSeasonFirst To intSeasonLast, _
          '                                    intYearFirst To intYearLastEx, 1 To intPeriodLastEx)
          '
          
      Dim intStat As Integer
      Dim intSeason As Integer
      Dim intYear As Integer
      Dim intPeriod As Integer

20    Call MBOProgramReport_SeasonYearPeriod_Birds(intYearFirst, intYearLast, strLocation)
30    Call MBOProgramReport_SeasonYearPeriod_Species(intYearFirst, intYearLast, strLocation)
40    Call MBOProgramReport_SeasonYearPeriod_NetHours(intYearFirst, intYearLast, strLocation)
50    Call MBOProgramReport_SeasonYearPeriod_BirdsPer100NetHours(intYearFirst, intYearLast, strLocation)
60    Call MBOProgramReport_SeasonYearPeriod_FullNetCoverageDays(intYearFirst, intYearLast, strLocation)
70    Call MBOProgramReport_SeasonYearPeriod_PercentBandedHatchYear(intYearFirst, intYearLast, strLocation)
80    Call MBOProgramReport_SeasonYearPeriod_DETMeanBirds(intYearFirst, intYearLast, strLocation)
90    Call MBOProgramReport_SeasonYearPeriod_BirdsRETREPPer100NetHours(intYearFirst, intYearLast, strLocation)
100   Call MBOProgramReport_SeasonYearPeriod_BandedTRES(intYearFirst, intYearLast, strLocation)
110   Call MBOProgramReport_SeasonYearPeriod_BandedTRESHatchYear(intYearFirst, intYearLast, strLocation)

      ' Fill in the means in the season column

120   For intStat = intStatFirst To intStatLast
130       Call MBOProgramReport_Season_TotalMean(intStat, intYearFirst, intYearLast, strLocation)
140   Next

      ' => Excel

      Dim oSheet As Excel.Worksheet
      Dim strSeason As String

150   For intSeason = intSeasonFirst To intSeasonLast

160       If intSeason = conSummerNestbox Then
170          GoTo Continue_label                         ' Exclude Summer + Nestbox for the time being
180       End If

190       strSeason = toStrSeasonFromIntSeason(intSeason)
          
200       Set oSheet = InsertSheet(oBook, strSeason)
210       oSheet.Name = strSeason & " Year x Period"
          
220       With oSheet

          Dim rowBase As Long
          Dim colBase As Long
          Dim rowsUsed As Long
          Dim rowsUsedCumulative As Long
          Dim colsUsed  As Long
          
230       colsUsed = intPeriodLast + 5
          
          ' Capture Days
          
240       rowBase = 1
250       colBase = 1
260       Call MBOProgramReport_SeasonYearPeriod_Excel( _
              intYearFirst, intYearLast, strLocation, oBook, oSheet, rowBase, colBase, rowsUsed, conStatCaptureDays, "Capture days", intSeason)
270       colBase = colsUsed + 1
280       Call MBOProgramReport_SeasonYearPeriod_Excel( _
              intYearFirst, intYearLast, strLocation, oBook, oSheet, rowBase, colBase, rowsUsedCumulative, conStatCaptureDaysCumulative, "Capture days cumulative", intSeason)
              
      '    Capture Periods
      '
      '    rowBase = rowBase + rowsUsed + 1
      '    colBase = 1
      '    Call MBOProgramReport_SeasonYearPeriod_Excel( _
      '        intYearFirst, intYearLast, strLocation, oBook, oSheet, rowBase, colBase, rowsUsed, conStatCapturePeriods, "Capture periods", intSeason)
          
          ' Banded birds and species

290       rowBase = rowBase + rowsUsed + 1
300       colBase = 1
310       Call MBOProgramReport_SeasonYearPeriod_Excel( _
              intYearFirst, intYearLast, strLocation, oBook, oSheet, rowBase, colBase, rowsUsed, conStatBNDBirds, "# banded birds", intSeason)
320       colBase = colBase + colsUsed
330       Call MBOProgramReport_SeasonYearPeriod_Excel( _
              intYearFirst, intYearLast, strLocation, oBook, oSheet, rowBase, colBase, rowsUsedCumulative, conStatBNDBirdsCumulative, "# banded birds cumulative", intSeason)
340       rowBase = rowBase + rowsUsed + 1
350       colBase = 1
360       Call MBOProgramReport_SeasonYearPeriod_Excel( _
              intYearFirst, intYearLast, strLocation, oBook, oSheet, rowBase, colBase, rowsUsed, conStatBNDSpecies, "# banded species", intSeason)
370       colBase = colBase + colsUsed
380       Call MBOProgramReport_SeasonYearPeriod_Excel( _
              intYearFirst, intYearLast, strLocation, oBook, oSheet, rowBase, colBase, rowsUsedCumulative, conStatBNDSpeciesCumulative, "# banded species cumulative", intSeason)

          ' Returns birds and species

390       rowBase = rowBase + rowsUsed + 1
400       colBase = 1
410       Call MBOProgramReport_SeasonYearPeriod_Excel( _
              intYearFirst, intYearLast, strLocation, oBook, oSheet, rowBase, colBase, rowsUsed, conStatRETBirds, "# return birds", intSeason)
420       colBase = colBase + colsUsed
430       Call MBOProgramReport_SeasonYearPeriod_Excel( _
              intYearFirst, intYearLast, strLocation, oBook, oSheet, rowBase, colBase, rowsUsedCumulative, conStatRETBirdsCumulative, "# return birds cumulative", intSeason)
440       rowBase = rowBase + rowsUsed + 1
450       colBase = 1
460       Call MBOProgramReport_SeasonYearPeriod_Excel( _
              intYearFirst, intYearLast, strLocation, oBook, oSheet, rowBase, colBase, rowsUsed, conStatRETSpecies, "# return species", intSeason)
470       colBase = colBase + colsUsed
480       Call MBOProgramReport_SeasonYearPeriod_Excel( _
              intYearFirst, intYearLast, strLocation, oBook, oSheet, rowBase, colBase, rowsUsedCumulative, conStatRETSpeciesCumulative, "# return species cumulative", intSeason)

          ' Repeats birds and species

490       rowBase = rowBase + rowsUsed + 1
500       colBase = 1
510       Call MBOProgramReport_SeasonYearPeriod_Excel( _
              intYearFirst, intYearLast, strLocation, oBook, oSheet, rowBase, colBase, rowsUsed, conStatREPBirds, "# repeat birds", intSeason)
520       colBase = colBase + colsUsed
530       Call MBOProgramReport_SeasonYearPeriod_Excel( _
              intYearFirst, intYearLast, strLocation, oBook, oSheet, rowBase, colBase, rowsUsedCumulative, conStatREPBirdsCumulative, "# repeat birds cumulative", intSeason)
540       rowBase = rowBase + rowsUsed + 1
550       colBase = 1
560       Call MBOProgramReport_SeasonYearPeriod_Excel( _
              intYearFirst, intYearLast, strLocation, oBook, oSheet, rowBase, colBase, rowsUsed, conStatREPSpecies, "# repeat species", intSeason)
570       colBase = colBase + colsUsed
580       Call MBOProgramReport_SeasonYearPeriod_Excel( _
              intYearFirst, intYearLast, strLocation, oBook, oSheet, rowBase, colBase, rowsUsedCumulative, conStatREPSpeciesCumulative, "# repeat species cumulative", intSeason)

          ' Census Days
          
590       Select Case intSeason
          Case conNestbox, conOwling
600       Case Else
610           rowBase = rowBase + rowsUsed + 1
620           colBase = 1
630           Call MBOProgramReport_SeasonYearPeriod_Excel( _
                    intYearFirst, intYearLast, strLocation, oBook, oSheet, rowBase, colBase, rowsUsed, conStatCensusDays, "Census days", intSeason)
640           colBase = colBase + colsUsed
650           Call MBOProgramReport_SeasonYearPeriod_Excel( _
                    intYearFirst, intYearLast, strLocation, oBook, oSheet, rowBase, colBase, rowsUsedCumulative, conStatCensusDaysCumulative, "Census days cumulative", intSeason)
                    
      '  ' Census periods
      '
      '        rowBase = rowBase + rowsUsed + 1
      '        colBase = 1
      '        Call MBOProgramReport_SeasonYearPeriod_Excel( _
      '              intYearFirst, intYearLast, strLocation, oBook, oSheet, rowBase, colBase, rowsUsed, conStatCensusPeriods, "Census periods", intSeason)
                    
660       End Select
          
          ' Census species

670       Select Case intSeason
          Case conNestbox, conOwling
680       Case Else
690           rowBase = rowBase + rowsUsed + 1
700           colBase = 1
710           Call MBOProgramReport_SeasonYearPeriod_Excel( _
                  intYearFirst, intYearLast, strLocation, oBook, oSheet, rowBase, colBase, rowsUsed, conStatCensusSpecies, "# census species", intSeason)
720           colBase = colBase + colsUsed
730           Call MBOProgramReport_SeasonYearPeriod_Excel( _
                  intYearFirst, intYearLast, strLocation, oBook, oSheet, rowBase, colBase, rowsUsedCumulative, conStatCensusSpeciesCumulative, "# census species cumulative", intSeason)
740       End Select
          
          ' DET Days and periods

750       Select Case intSeason
          Case conNestbox, conOwling
760       Case Else
770           rowBase = rowBase + rowsUsed + 1
780           colBase = 1
790           Call MBOProgramReport_SeasonYearPeriod_Excel( _
                    intYearFirst, intYearLast, strLocation, oBook, oSheet, rowBase, colBase, rowsUsed, conStatDETDays, "DET days", intSeason)
800           colBase = colBase + colsUsed
810           Call MBOProgramReport_SeasonYearPeriod_Excel( _
                    intYearFirst, intYearLast, strLocation, oBook, oSheet, rowBase, colBase, rowsUsedCumulative, conStatDETDaysCumulative, "DET days cumulative", intSeason)
                    
      '    ' DET periods
      '
      '        rowBase = rowBase + rowsUsed + 1
      '        colBase = 1
      '        Call MBOProgramReport_SeasonYearPeriod_Excel( _
      '              intYearFirst, intYearLast, strLocation, oBook, oSheet, rowBase, colBase, rowsUsed, conStatDETPeriods, "DET periods", intSeason)
      '
820       End Select
          
          ' DET species

830       Select Case intSeason
          Case conNestbox, conOwling
840       Case Else
850           rowBase = rowBase + rowsUsed + 1
860           colBase = 1
870           Call MBOProgramReport_SeasonYearPeriod_Excel( _
                  intYearFirst, intYearLast, strLocation, oBook, oSheet, rowBase, colBase, rowsUsed, conStatDETSpecies, "# DET species", intSeason)
880           colBase = colBase + colsUsed
890           Call MBOProgramReport_SeasonYearPeriod_Excel( _
                  intYearFirst, intYearLast, strLocation, oBook, oSheet, rowBase, colBase, rowsUsedCumulative, conStatDETSpeciesCumulative, "# DET species cumulative", intSeason)
900       End Select

          ' Net Hours

910       Select Case intSeason
          Case conNestbox
920       Case Else
930           rowBase = rowBase + rowsUsed + 1
940           colBase = 1
950           Call MBOProgramReport_SeasonYearPeriod_Excel( _
                  intYearFirst, intYearLast, strLocation, oBook, oSheet, rowBase, colBase, rowsUsed, conStatNetHours, "# net hours", intSeason)
960            colBase = colBase + colsUsed
970           Call MBOProgramReport_SeasonYearPeriod_Excel( _
                  intYearFirst, intYearLast, strLocation, oBook, oSheet, rowBase, colBase, rowsUsedCumulative, conStatNetHoursCumulative, "# net hours cumulative", intSeason)
980       End Select
          

          ' Birds banded per 100 net hours
          
990       Select Case intSeason
          Case conNestbox
1000      Case Else
1010          rowBase = rowBase + rowsUsed + 1
1020          colBase = 1
1030          Call MBOProgramReport_SeasonYearPeriod_Excel( _
                  intYearFirst, intYearLast, strLocation, oBook, oSheet, rowBase, colBase, rowsUsed, conStatBirdsPer100NetHours, "# birds banded / 100 net hours", intSeason)
1040          colBase = colBase + colsUsed
1050          Call MBOProgramReport_SeasonYearPeriod_Excel( _
                  intYearFirst, intYearLast, strLocation, oBook, oSheet, rowBase, colBase, rowsUsedCumulative, conStatBirdsPer100NetHoursCumulative, "# birds banded / 100 net hours cumulative", intSeason)
1060      End Select

          ' Birds return or repeat per 100 net hours

1070      Select Case intSeason
          Case conNestbox
1080      Case Else
1090          rowBase = rowBase + rowsUsed + 1
1100          colBase = 1
1110          Call MBOProgramReport_SeasonYearPeriod_Excel( _
                  intYearFirst, intYearLast, strLocation, oBook, oSheet, rowBase, colBase, rowsUsed, conStatBirdsRETREPPer100NetHours, "# birds return or repeat / 100 net hours", intSeason)
1120          colBase = colBase + colsUsed
1130          Call MBOProgramReport_SeasonYearPeriod_Excel( _
                  intYearFirst, intYearLast, strLocation, oBook, oSheet, rowBase, colBase, rowsUsedCumulative, conStatBirdsRETREPPer100NetHoursCumulative, "# birds return or repeat / 100 net hours cumulative", intSeason)
1140      End Select
          
          ' Net days

1150      Select Case intSeason
          Case conNestbox
1160      Case Else
1170          rowBase = rowBase + rowsUsed + 1
1180          colBase = 1
1190          Call MBOProgramReport_SeasonYearPeriod_Excel( _
                  intYearFirst, intYearLast, strLocation, oBook, oSheet, rowBase, colBase, rowsUsed, conStatNetDays, "# Net days", intSeason)
1200          colBase = colBase + colsUsed
1210          Call MBOProgramReport_SeasonYearPeriod_Excel( _
                  intYearFirst, intYearLast, strLocation, oBook, oSheet, rowBase, colBase, rowsUsedCumulative, conStatNetDaysCumulative, "# Net days cumulative", intSeason)
1220      End Select
          
          ' Full net coverage days

1230      Select Case intSeason
          Case conNestbox
1240      Case Else
1250              rowBase = rowBase + rowsUsed + 1
1260              colBase = 1
1270              Call MBOProgramReport_SeasonYearPeriod_Excel( _
                      intYearFirst, intYearLast, strLocation, oBook, oSheet, rowBase, colBase, rowsUsed, conStatFullNetCoverageDays, "# full net coverage days", intSeason)
1280              colBase = colBase + colsUsed
1290              Call MBOProgramReport_SeasonYearPeriod_Excel( _
                      intYearFirst, intYearLast, strLocation, oBook, oSheet, rowBase, colBase, rowsUsedCumulative, conStatFullNetCoverageDaysCumulative, "# full net coverage days cumulative", intSeason)
1300      End Select
          
          ' Percent banded hatch year

1310      Select Case intSeason
          Case conSummer, conFall, conOwling, conNestbox
1320          rowBase = rowBase + rowsUsed + 1
1330          colBase = 1
1340          Call MBOProgramReport_SeasonYearPeriod_Excel( _
                  intYearFirst, intYearLast, strLocation, oBook, oSheet, rowBase, colBase, rowsUsed, conStatPercentBandedHatchYear, "% banded HY or Nestling", intSeason)
1350            colBase = colBase + colsUsed
1360          Call MBOProgramReport_SeasonYearPeriod_Excel( _
                  intYearFirst, intYearLast, strLocation, oBook, oSheet, rowBase, colBase, rowsUsedCumulative, conStatPercentBandedHatchYearCumulative, "% banded HY or Nestling cumulative", intSeason)
1370            End Select
          
          ' TRES banded - Nestbox only

1380      Select Case intSeason
          Case conNestbox
1390          rowBase = rowBase + rowsUsed + 1
1400          colBase = 1
1410          Call MBOProgramReport_SeasonYearPeriod_Excel( _
                  intYearFirst, intYearLast, strLocation, oBook, oSheet, rowBase, colBase, rowsUsed, conStatBandedTRES, "# TRES banded", intSeason)
1420          colBase = colBase + colsUsed
1430      Case Else
1440      End Select
             
        ' TRES Hatch year banded - Nestbox only

1450      Select Case intSeason
          Case conNestbox
1460          rowBase = rowBase + rowsUsed + 1
1470          colBase = 1
1480          Call MBOProgramReport_SeasonYearPeriod_Excel( _
                  intYearFirst, intYearLast, strLocation, oBook, oSheet, rowBase, colBase, rowsUsed, conStatBandedTRESHatchYear, "# TRES Hatch Year banded", intSeason)
1490          colBase = colBase + colsUsed
1500      Case Else
1510      End Select

          ' DET birds and mean birds

1520      Select Case intSeason
            Case conNonSeason, conWinter, conSpring, conSummer, conFall
1530              rowBase = rowBase + rowsUsed + 1
1540              colBase = 1
1550              Call MBOProgramReport_SeasonYearPeriod_Excel( _
                      intYearFirst, intYearLast, strLocation, oBook, oSheet, rowBase, colBase, rowsUsed, conStatDETBirds, "# DET birds", intSeason)
1560              colBase = colBase + colsUsed
1570              Call MBOProgramReport_SeasonYearPeriod_Excel( _
                      intYearFirst, intYearLast, strLocation, oBook, oSheet, rowBase, colBase, rowsUsedCumulative, conStatDETBirdsCumulative, "# DET birds cumulative", intSeason)
1580              rowBase = rowBase + rowsUsed + 1
1590              colBase = 1
1600              Call MBOProgramReport_SeasonYearPeriod_Excel( _
                      intYearFirst, intYearLast, strLocation, oBook, oSheet, rowBase, colBase, rowsUsed, conStatDETMeanBirds, "mean DET birds", intSeason)
1610              colBase = colBase + colsUsed
1620              Call MBOProgramReport_SeasonYearPeriod_Excel( _
                      intYearFirst, intYearLast, strLocation, oBook, oSheet, rowBase, colBase, rowsUsedCumulative, conStatDETMeanBirdsCumulative, "mean DET birds cumulative", intSeason)
1630              End Select
          
          ' Alien birds and species

1640      rowBase = rowBase + rowsUsed + 1
1650      colBase = 1
1660      Call MBOProgramReport_SeasonYearPeriod_Excel( _
              intYearFirst, intYearLast, strLocation, oBook, oSheet, rowBase, colBase, rowsUsed, conStatAlienBirds, "# alien birds", intSeason)
1670      colBase = colBase + colsUsed
1680      Call MBOProgramReport_SeasonYearPeriod_Excel( _
              intYearFirst, intYearLast, strLocation, oBook, oSheet, rowBase, colBase, rowsUsedCumulative, conStatAlienBirdsCumulative, "# alien birds cumulative", intSeason)
1690      rowBase = rowBase + rowsUsed + 1
1700      colBase = 1
1710      Call MBOProgramReport_SeasonYearPeriod_Excel( _
              intYearFirst, intYearLast, strLocation, oBook, oSheet, rowBase, colBase, rowsUsed, conStatAlienSpecies, "# alien species", intSeason)
1720      colBase = colBase + colsUsed
1730      Call MBOProgramReport_SeasonYearPeriod_Excel( _
              intYearFirst, intYearLast, strLocation, oBook, oSheet, rowBase, colBase, rowsUsedCumulative, conStatAlienSpeciesCumulative, "# alien species cumulative", intSeason)

          Dim colYear As Long
          Dim colPeriodFirst As Long
          Dim colPeriodLast As Long
          Dim colPeriodTotal As Long
          Dim colPeriodMean As Long
          Dim colPeriodSeason As Long
          
1740      colYear = 1
1750      colPeriodFirst = colYear + 1
1760      colPeriodLast = colPeriodFirst + intPeriodLast - 1
1770      colPeriodTotal = colPeriodLast + 1
1780      colPeriodMean = colPeriodLast + 2
1790      colPeriodSeason = colPeriodLast + 3

1800      .range(.columns(1), .columns(2 * (intPeriodLast + 6) + 1)).HorizontalAlignment = xlCenter
1810      .range(.columns(1), .columns(2 * (intPeriodLast + 6) + 1)).AutoFit
1820      .columns(colPeriodTotal).ColumnWidth = 0.8

1830      End With
          
Continue_label:

1840  Next

      'DD Error Handler Start
Exit_label:
1850       Exit Sub
Err_label:
1860       Select Case Err.Number
           Case Else
1870      Call LogError("basMBOProgramReport_SeasonYearPeriod", "MBOAnnualProgramReport_SeasonYearPeriod_Part_B")
1880       End Select
1890       Resume Exit_label
      'DD Error Handler End

End Sub


'---------------------------------------------------------------------------------------
' MBOProgramReport_SeasonYearPeriod_Species
'---------------------------------------------------------------------------------------
' Count the species for the statistics: conStatCensusSpecies, conStatBNDSpecies, conStatRETSpecies, conStatREPSpecies, conStatAlienSpecies, conStatDETSpecies and their corresponding cumulative statistics
' Fill in dblStatSeasonYearPeriod(stat, intSeason, intYear, intPeriod)             for every intSeason x intYear x intPeriod
'         dblStatSeasonYearPeriod(stat, intSeason, intYear, intPeriodSeason)       for every intSeason x intYear
'         dblStatSeasonYearPeriod(stat, intSeason, intYearSeason, intPeriod)       for every intSeason x intPeriod
'         dblStatSeasonYearPeriod(stat, intSeason, intYearSeason, intPeriodSeason) for every intSeason
'
' Fill in the corresponding mean columns and rows.

Private Sub MBOProgramReport_SeasonYearPeriod_Species( _
    ByVal intYearFirst As Integer, _
    ByVal intYearLast As Integer, _
    ByVal strLocation As String)

10    On Error GoTo Err_label
          
      Dim strSQL As String
      Dim qdf As DAO.QueryDef
      Dim rst As DAO.Recordset
      Dim intYear As Integer
      Dim intPeriod As Integer
      Dim intSeason As Integer
      Dim strSeason As String
      Dim strSpecies As String
      Dim stat As Integer            ' 0 to 5 (conStatCensusSpecies, conStatBNDSpecies, conStatRETSpecies, conStatREPSpecies, conStatAlienSpecies, conStatDETSpecies)
      Dim lngStat(0 To 5) As Long
      Dim dicStatSpecies(0 To 5) As Scripting.Dictionary
      Dim dicStatSpeciesCumulative(0 To 5) As Scripting.Dictionary
      Dim intSeason_Previous As Integer
      Dim intYear_previous As Integer
      Dim intPeriod_previous As Integer

20    SysCmd acSysCmdSetStatus, "Season x Year x Period : Species"

30    For stat = 0 To 5
40       Set dicStatSpecies(stat) = New Scripting.Dictionary
50       Set dicStatSpeciesCumulative(stat) = New Scripting.Dictionary
60    Next

      ' Season x Year x Period

70    intSeason_Previous = -99
80    intYear_previous = 0
90    intPeriod_previous = 0

      ' tblMBOProgramReport_DETSpecies
      ' ------------------------------
      ' Same as tblDETSpecies + Period, YearEx, SpeciesEnglish, DateFrom
      ' Only records BETWEEN argYearFirst AND argYearLast
      '
      ' Season, YearEx, Location, Dateex, Program, NetHours, Observed, Census, Banded, Repeates, Returns, DET, Alien, Replacement, Species, SpeciesEenglish, Period, DateFrom

      ' qryMBOProgramReport_SeasonYearPeriod_Species
      ' --------------------------------------------
      ' tblMBOProgramReport_DETSpecies
      '
      ' WHERE Location = [argLocation]
      ' WHERE YearEx BETWEEN  [argYearFirst] AND [argYearLast]
      ' GROUP BY Season
      ' GROUP BY YearEx
      ' GROUP BY Period
      ' GROUP BY Species
      ' SUM Census, Banded, Repeats, Returns, DET, Alien

100   strSQL = "qryMBOProgramReport_SeasonYearPeriod_Species"
          
110   Set qdf = CurrentDb.QueryDefs(strSQL)
120   qdf.Parameters("argLocation").value = strLocation
130   qdf.Parameters("argYearFirst").value = intYearFirst
140   qdf.Parameters("argYearLast").value = intYearLast
150   Set rst = qdf.OpenRecordset

      ' Fill in dblStatSeasonYearPeriod(stat, intSeason, intYear, intPeriod)
      '     for each stat in (conStatCensusSpecies, conStatBNDSpecies, conStatRETSpecies, conStatREPSpecies, conStatAlienSpecies, conStatDETSpecies)  and their cumulative conterparts
      '         x season x year x period

160   Do While Not rst.EOF
170       intSeason = toIntSeasonFromStrSeason(Nz(rst("Season")))
180       intYear = Nz(rst("YearEx"))
190       intPeriod = Nz(rst("Period"))
200       strSpecies = Nz(rst("Species"))
210       lngStat(0) = Nz(rst("Census"))
220       lngStat(1) = Nz(rst("Banded"))
230       lngStat(2) = Nz(rst("Returns"))
240       lngStat(3) = Nz(rst("Repeats"))
250       lngStat(4) = Nz(rst("Alien"))
260       lngStat(5) = Nz(rst("DET"))
          
270       If intSeason <> intSeason_Previous Or intYear <> intYear_previous Or intPeriod <> intPeriod_previous Then
280           If intSeason_Previous <> -99 Then
               
                  ' F3
                             
290               dblStatSeasonYearPeriod(conStatCensusSpecies, intSeason_Previous, intYear_previous, intPeriod_previous) = CountSpeciesInDictionary(dicStatSpecies(0))
300               dblStatSeasonYearPeriod(conStatBNDSpecies, intSeason_Previous, intYear_previous, intPeriod_previous) = CountSpeciesInDictionary(dicStatSpecies(1))
310               dblStatSeasonYearPeriod(conStatRETSpecies, intSeason_Previous, intYear_previous, intPeriod_previous) = CountSpeciesInDictionary(dicStatSpecies(2))
320               dblStatSeasonYearPeriod(conStatREPSpecies, intSeason_Previous, intYear_previous, intPeriod_previous) = CountSpeciesInDictionary(dicStatSpecies(3))
330               dblStatSeasonYearPeriod(conStatAlienSpecies, intSeason_Previous, intYear_previous, intPeriod_previous) = CountSpeciesInDictionary(dicStatSpecies(4))
340               dblStatSeasonYearPeriod(conStatDETSpecies, intSeason_Previous, intYear_previous, intPeriod_previous) = CountSpeciesInDictionary(dicStatSpecies(5))
                        
                  
                   ' For the cumulative statistic, fill in all remaining periods just in case there is no statistic
                  
                  Dim p As Integer
350               For p = intPeriod_previous To intPeriodLast_SeasonYear(intSeason_Previous, intYear_previous)
                  
360                   dblStatSeasonYearPeriod(conStatCensusSpeciesCumulative, intSeason_Previous, intYear_previous, p) = CountSpeciesInDictionary(dicStatSpeciesCumulative(0))
370                   dblStatSeasonYearPeriod(conStatBNDSpeciesCumulative, intSeason_Previous, intYear_previous, p) = CountSpeciesInDictionary(dicStatSpeciesCumulative(1))
380                   dblStatSeasonYearPeriod(conStatRETSpeciesCumulative, intSeason_Previous, intYear_previous, p) = CountSpeciesInDictionary(dicStatSpeciesCumulative(2))
390                   dblStatSeasonYearPeriod(conStatREPSpeciesCumulative, intSeason_Previous, intYear_previous, p) = CountSpeciesInDictionary(dicStatSpeciesCumulative(3))
400                   dblStatSeasonYearPeriod(conStatAlienSpeciesCumulative, intSeason_Previous, intYear_previous, p) = CountSpeciesInDictionary(dicStatSpeciesCumulative(4))
410                   dblStatSeasonYearPeriod(conStatDETSpeciesCumulative, intSeason_Previous, intYear_previous, p) = CountSpeciesInDictionary(dicStatSpeciesCumulative(5))
                            
420               Next
                  
430           End If
440           If intSeason <> intSeason_Previous Or intYear <> intYear_previous Then
450               If intSeason_Previous <> -99 Then
                   
                      ' F2
                      
                        
460               End If
470               If intSeason <> intSeason_Previous Then
480                   If intSeason_Previous <> -99 Then
                       
                          ' F1
                          
490                   End If
                      
                      ' H1
                      
500                   intSeason_Previous = intSeason
510               End If
                  
                  ' H2
                      
520               For stat = 0 To 5
530                   dicStatSpeciesCumulative(stat).RemoveAll
540               Next
              
550               intYear_previous = intYear
560           End If
              
              ' H3
              
570           For stat = 0 To 5
580               dicStatSpecies(stat).RemoveAll
590           Next
              
600           intPeriod_previous = intPeriod
610       End If
          
         ' Detail
                    
620       For stat = 0 To 5
630           If lngStat(stat) > 0 Then
640               If Not dicStatSpecies(stat).Exists(strSpecies) Then
650                   Call dicStatSpecies(stat).Add(strSpecies, strSpecies)
660               End If
670               If Not dicStatSpeciesCumulative(stat).Exists(strSpecies) Then
680                   Call dicStatSpeciesCumulative(stat).Add(strSpecies, strSpecies)
690               End If
700           End If
710       Next
          
720       intSeason_Previous = intSeason
730       intYear_previous = intYear
740       intPeriod_previous = intPeriod

750       rst.MoveNext
760   Loop

770   If intPeriod_previous <> 0 Then
          
          ' F3, F2, F1, FR
          
780       dblStatSeasonYearPeriod(conStatCensusSpecies, intSeason_Previous, intYear_previous, intPeriod_previous) = CountSpeciesInDictionary(dicStatSpecies(0))
790       dblStatSeasonYearPeriod(conStatBNDSpecies, intSeason_Previous, intYear_previous, intPeriod_previous) = CountSpeciesInDictionary(dicStatSpecies(1))
800       dblStatSeasonYearPeriod(conStatRETSpecies, intSeason_Previous, intYear_previous, intPeriod_previous) = CountSpeciesInDictionary(dicStatSpecies(2))
810       dblStatSeasonYearPeriod(conStatREPSpecies, intSeason_Previous, intYear_previous, intPeriod_previous) = CountSpeciesInDictionary(dicStatSpecies(3))
820       dblStatSeasonYearPeriod(conStatAlienSpecies, intSeason_Previous, intYear_previous, intPeriod_previous) = CountSpeciesInDictionary(dicStatSpecies(4))
830       dblStatSeasonYearPeriod(conStatDETSpecies, intSeason_Previous, intYear_previous, intPeriod_previous) = CountSpeciesInDictionary(dicStatSpecies(5))
          
                       ' For the cumulative statistic, fill in all remaining periods just in case there is no statistic
                  
      '    Dim p As Integer
840       For p = intPeriod_previous To intPeriodLast_SeasonYear(intSeason_Previous, intYear_previous)
          
850           dblStatSeasonYearPeriod(conStatCensusSpeciesCumulative, intSeason_Previous, intYear_previous, p) = CountSpeciesInDictionary(dicStatSpeciesCumulative(0))
860           dblStatSeasonYearPeriod(conStatBNDSpeciesCumulative, intSeason_Previous, intYear_previous, p) = CountSpeciesInDictionary(dicStatSpeciesCumulative(1))
870           dblStatSeasonYearPeriod(conStatRETSpeciesCumulative, intSeason_Previous, intYear_previous, p) = CountSpeciesInDictionary(dicStatSpeciesCumulative(2))
880           dblStatSeasonYearPeriod(conStatREPSpeciesCumulative, intSeason_Previous, intYear_previous, p) = CountSpeciesInDictionary(dicStatSpeciesCumulative(3))
890           dblStatSeasonYearPeriod(conStatAlienSpeciesCumulative, intSeason_Previous, intYear_previous, p) = CountSpeciesInDictionary(dicStatSpeciesCumulative(4))
900           dblStatSeasonYearPeriod(conStatDETSpeciesCumulative, intSeason_Previous, intYear_previous, p) = CountSpeciesInDictionary(dicStatSpeciesCumulative(5))
                    
910       Next
          

920   End If

930   rst.Close
940   Set rst = Nothing
        
      ' Season x Year
      ' -------------
      ' Fill in dblStatSeasonYearPeriod(stat, intSeason, intYear, intPeriodSeason)
      '     for each stat in (conStatCensusSpecies, conStatBNDSpecies, conStatRETSpecies, conStatREPSpecies, conStatAlienSpecies, conStatDETSpecies)  and their cumulative conterparts
      '         x season x year

950   SysCmd acSysCmdSetStatus, "Season x Year : Species"

960   intSeason_Previous = -99
970   intYear_previous = 0

980   strSQL = "qryMBOProgramReport_SeasonYear_Species"
          
990   Set qdf = CurrentDb.QueryDefs(strSQL)
1000  qdf.Parameters("argLocation").value = strLocation
1010  qdf.Parameters("argYearFirst").value = intYearFirst
1020  qdf.Parameters("argYearLast").value = intYearLast
1030  Set rst = qdf.OpenRecordset

1040  Do While Not rst.EOF
1050      intSeason = toIntSeasonFromStrSeason(Nz(rst("Season")))
1060      intYear = Nz(rst("YearEx"))
1070      strSpecies = Nz(rst("Species"))
1080      lngStat(0) = Nz(rst("Census"))
1090      lngStat(1) = Nz(rst("Banded"))
1100      lngStat(2) = Nz(rst("Returns"))
1110      lngStat(3) = Nz(rst("Repeats"))
1120      lngStat(4) = Nz(rst("Alien"))
1130      lngStat(5) = Nz(rst("DET"))

1140      If intSeason <> intSeason_Previous Or intYear <> intYear_previous Then
1150          If intSeason_Previous <> -99 Then
               
                  ' F2
                  
1160              dblStatSeasonYearPeriod(conStatCensusSpecies, intSeason_Previous, intYear_previous, intPeriodSeason) = CountSpeciesInDictionary(dicStatSpecies(0))
1170              dblStatSeasonYearPeriod(conStatBNDSpecies, intSeason_Previous, intYear_previous, intPeriodSeason) = CountSpeciesInDictionary(dicStatSpecies(1))
1180              dblStatSeasonYearPeriod(conStatRETSpecies, intSeason_Previous, intYear_previous, intPeriodSeason) = CountSpeciesInDictionary(dicStatSpecies(2))
1190              dblStatSeasonYearPeriod(conStatREPSpecies, intSeason_Previous, intYear_previous, intPeriodSeason) = CountSpeciesInDictionary(dicStatSpecies(3))
1200              dblStatSeasonYearPeriod(conStatAlienSpecies, intSeason_Previous, intYear_previous, intPeriodSeason) = CountSpeciesInDictionary(dicStatSpecies(4))
1210              dblStatSeasonYearPeriod(conStatDETSpecies, intSeason_Previous, intYear_previous, intPeriodSeason) = CountSpeciesInDictionary(dicStatSpecies(5))
1220          End If


1230          If intSeason <> intSeason_Previous Then
1240              If intSeason_Previous <> -99 Then
                   
                      ' F1
                      
1250              End If
                  
                  ' H1

1260              intSeason_Previous = intSeason
1270          End If
                  
              ' H2
              
1280          For stat = 0 To 5
1290              dicStatSpecies(stat).RemoveAll
1300          Next
1310          intYear_previous = intYear

1320      End If
             
         ' Detail
                    
1330      For stat = 0 To 5
1340          If lngStat(stat) > 0 Then
1350              If Not dicStatSpecies(stat).Exists(strSpecies) Then
1360                  Call dicStatSpecies(stat).Add(strSpecies, strSpecies)
1370              End If
1380          End If
1390      Next
          
1400      rst.MoveNext
1410  Loop

1420  If intSeason_Previous <> -99 Then
          
          ' F1, FR
          
1430      dblStatSeasonYearPeriod(conStatCensusSpecies, intSeason_Previous, intYear_previous, intPeriodSeason) = CountSpeciesInDictionary(dicStatSpecies(0))
1440      dblStatSeasonYearPeriod(conStatBNDSpecies, intSeason_Previous, intYear_previous, intPeriodSeason) = CountSpeciesInDictionary(dicStatSpecies(1))
1450      dblStatSeasonYearPeriod(conStatRETSpecies, intSeason_Previous, intYear_previous, intPeriodSeason) = CountSpeciesInDictionary(dicStatSpecies(2))
1460      dblStatSeasonYearPeriod(conStatREPSpecies, intSeason_Previous, intYear_previous, intPeriodSeason) = CountSpeciesInDictionary(dicStatSpecies(3))
1470      dblStatSeasonYearPeriod(conStatAlienSpecies, intSeason_Previous, intYear_previous, intPeriodSeason) = CountSpeciesInDictionary(dicStatSpecies(4))
1480      dblStatSeasonYearPeriod(conStatDETSpecies, intSeason_Previous, intYear_previous, intPeriodSeason) = CountSpeciesInDictionary(dicStatSpecies(5))

1490  End If

1500  rst.Close
1510  Set rst = Nothing


      ' Fill in the mean column and the mean rows
      ' Fill in the max and min fields for each period and for intPeriodSeason

1520  Call MBOProgramReport_SeasonYearPeriod_TotalMean(conStatCensusSpecies, intYearFirst, intYearLast, strLocation)
1530  Call MBOProgramReport_SeasonYearPeriod_MinMax(conStatCensusSpecies, intYearFirst, intYearLast, strLocation)
1540  Call MBOProgramReport_SeasonYearPeriod_TotalMean(conStatBNDSpecies, intYearFirst, intYearLast, strLocation)
1550  Call MBOProgramReport_SeasonYearPeriod_MinMax(conStatBNDSpecies, intYearFirst, intYearLast, strLocation)
1560  Call MBOProgramReport_SeasonYearPeriod_TotalMean(conStatRETSpecies, intYearFirst, intYearLast, strLocation)
1570  Call MBOProgramReport_SeasonYearPeriod_MinMax(conStatRETSpecies, intYearFirst, intYearLast, strLocation)
1580  Call MBOProgramReport_SeasonYearPeriod_TotalMean(conStatREPSpecies, intYearFirst, intYearLast, strLocation)
1590  Call MBOProgramReport_SeasonYearPeriod_MinMax(conStatREPSpecies, intYearFirst, intYearLast, strLocation)
1600  Call MBOProgramReport_SeasonYearPeriod_TotalMean(conStatDETSpecies, intYearFirst, intYearLast, strLocation)
1610  Call MBOProgramReport_SeasonYearPeriod_MinMax(conStatDETSpecies, intYearFirst, intYearLast, strLocation)
1620  Call MBOProgramReport_SeasonYearPeriod_TotalMean(conStatAlienSpecies, intYearFirst, intYearLast, strLocation)
1630  Call MBOProgramReport_SeasonYearPeriod_MinMax(conStatAlienSpecies, intYearFirst, intYearLast, strLocation)

      ' Season x Period
      ' ---------------
      ' Fill in dblStatSeasonYearPeriod(stat, intSeason, intYearSeason, intPeriod)
      '     for each stat in (conStatCensusSpecies, conStatBNDSpecies, conStatRETSpecies, conStatREPSpecies, conStatAlienSpecies, conStatDETSpecies)  and their cumulative conterparts
      '         x season x period

1640  SysCmd acSysCmdSetStatus, "Season x Period : Species"

1650  intSeason_Previous = -99
1660  intPeriod_previous = 0

1670  strSQL = "qryMBOProgramReport_SeasonPeriod_Species"
          
1680  Set qdf = CurrentDb.QueryDefs(strSQL)
1690  qdf.Parameters("argLocation").value = strLocation
1700  qdf.Parameters("argYearFirst").value = intYearFirst
1710  qdf.Parameters("argYearLast").value = intYearLast
1720  Set rst = qdf.OpenRecordset

1730  Do While Not rst.EOF
1740      intSeason = toIntSeasonFromStrSeason(Nz(rst("Season")))
1750      intPeriod = Nz(rst("Period"))
1760      strSpecies = Nz(rst("Species"))
1770      lngStat(0) = Nz(rst("Census"))
1780      lngStat(1) = Nz(rst("Banded"))
1790      lngStat(2) = Nz(rst("Returns"))
1800      lngStat(3) = Nz(rst("Repeats"))
1810      lngStat(4) = Nz(rst("Alien"))
1820      lngStat(5) = Nz(rst("DET"))
          
1830      If intSeason <> intSeason_Previous Or intYear <> intYear_previous Or intPeriod <> intPeriod_previous Then
1840          If intSeason_Previous <> -99 Then
               
                  ' F3
                  
1850              dblStatSeasonYearPeriod(conStatCensusSpecies, intSeason_Previous, intYearSeason, intPeriod_previous) = CountSpeciesInDictionary(dicStatSpecies(0))
1860              dblStatSeasonYearPeriod(conStatBNDSpecies, intSeason_Previous, intYearSeason, intPeriod_previous) = CountSpeciesInDictionary(dicStatSpecies(1))
1870              dblStatSeasonYearPeriod(conStatRETSpecies, intSeason_Previous, intYearSeason, intPeriod_previous) = CountSpeciesInDictionary(dicStatSpecies(2))
1880              dblStatSeasonYearPeriod(conStatREPSpecies, intSeason_Previous, intYearSeason, intPeriod_previous) = CountSpeciesInDictionary(dicStatSpecies(3))
1890              dblStatSeasonYearPeriod(conStatAlienSpecies, intSeason_Previous, intYearSeason, intPeriod_previous) = CountSpeciesInDictionary(dicStatSpecies(4))
1900              dblStatSeasonYearPeriod(conStatDETSpecies, intSeason_Previous, intYearSeason, intPeriod_previous) = CountSpeciesInDictionary(dicStatSpecies(5))

                  
1910          End If
1920          If intSeason <> intSeason_Previous Or intYear <> intYear_previous Then
1930              If intSeason_Previous <> -99 Then
                   
                      ' F2
                      
1940                 dblStatSeasonYearPeriod(conStatCensusSpeciesCumulative, intSeason_Previous, intYearSeason, intPeriod_previous) = CountSpeciesInDictionary(dicStatSpeciesCumulative(0))
1950                 dblStatSeasonYearPeriod(conStatBNDSpeciesCumulative, intSeason_Previous, intYearSeason, intPeriod_previous) = CountSpeciesInDictionary(dicStatSpeciesCumulative(1))
1960                 dblStatSeasonYearPeriod(conStatRETSpeciesCumulative, intSeason_Previous, intYearSeason, intPeriod_previous) = CountSpeciesInDictionary(dicStatSpeciesCumulative(2))
1970                 dblStatSeasonYearPeriod(conStatREPSpeciesCumulative, intSeason_Previous, intYearSeason, intPeriod_previous) = CountSpeciesInDictionary(dicStatSpeciesCumulative(3))
1980                 dblStatSeasonYearPeriod(conStatAlienSpeciesCumulative, intSeason_Previous, intYearSeason, intPeriod_previous) = CountSpeciesInDictionary(dicStatSpeciesCumulative(4))
1990                 dblStatSeasonYearPeriod(conStatDETSpeciesCumulative, intSeason_Previous, intYearSeason, intPeriod_previous) = CountSpeciesInDictionary(dicStatSpeciesCumulative(5))
          
                      
2000              End If
2010              If intSeason <> intSeason_Previous Then
2020                  If intSeason_Previous <> -99 Then
                       
                          ' F1
                          
2030                  End If
                      
                      ' H1
                      
2040                  intSeason_Previous = intSeason
2050              End If
                  
                  ' H2
                  
2060              For stat = 0 To 5
2070                  dicStatSpeciesCumulative(stat).RemoveAll
2080              Next
              
2090              intYear_previous = intYear
2100          End If
              
              ' H3
              
2110          For stat = 0 To 5
2120              dicStatSpecies(stat).RemoveAll
2130          Next
              
2140          intPeriod_previous = intPeriod
2150      End If
            
         ' Detail
                    
2160      For stat = 0 To 5
2170          If lngStat(stat) > 0 Then
2180              If Not dicStatSpecies(stat).Exists(strSpecies) Then
2190                  Call dicStatSpecies(stat).Add(strSpecies, strSpecies)
2200              End If
2210              If Not dicStatSpeciesCumulative(stat).Exists(strSpecies) Then
2220                  Call dicStatSpeciesCumulative(stat).Add(strSpecies, strSpecies)
2230              End If
2240          End If
2250      Next
          
2260      rst.MoveNext
2270  Loop

2280  If intSeason_Previous <> -99 Then
          
          ' F3, F2, F1, FR
          
2290      dblStatSeasonYearPeriod(conStatCensusSpecies, intSeason_Previous, intYearSeason, intPeriod_previous) = CountSpeciesInDictionary(dicStatSpecies(0))
2300      dblStatSeasonYearPeriod(conStatBNDSpecies, intSeason_Previous, intYearSeason, intPeriod_previous) = CountSpeciesInDictionary(dicStatSpecies(1))
2310      dblStatSeasonYearPeriod(conStatRETSpecies, intSeason_Previous, intYear_previous, intPeriod_previous) = CountSpeciesInDictionary(dicStatSpecies(2))
2320      dblStatSeasonYearPeriod(conStatREPSpecies, intSeason_Previous, intYearSeason, intPeriod_previous) = CountSpeciesInDictionary(dicStatSpecies(3))
2330      dblStatSeasonYearPeriod(conStatAlienSpecies, intSeason_Previous, intYearSeason, intPeriod_previous) = CountSpeciesInDictionary(dicStatSpecies(4))
2340      dblStatSeasonYearPeriod(conStatDETSpecies, intSeason_Previous, intYearSeason, intPeriod_previous) = CountSpeciesInDictionary(dicStatSpecies(5))
2350      dblStatSeasonYearPeriod(conStatCensusSpeciesCumulative, intSeason_Previous, intYearSeason, intPeriod_previous) = CountSpeciesInDictionary(dicStatSpeciesCumulative(0))
2360      dblStatSeasonYearPeriod(conStatBNDSpeciesCumulative, intSeason_Previous, intYearSeason, intPeriod_previous) = CountSpeciesInDictionary(dicStatSpeciesCumulative(1))
2370      dblStatSeasonYearPeriod(conStatRETSpeciesCumulative, intSeason_Previous, intYearSeason, intPeriod_previous) = CountSpeciesInDictionary(dicStatSpeciesCumulative(2))
2380      dblStatSeasonYearPeriod(conStatREPSpeciesCumulative, intSeason_Previous, intYearSeason, intPeriod_previous) = CountSpeciesInDictionary(dicStatSpeciesCumulative(3))
2390      dblStatSeasonYearPeriod(conStatAlienSpeciesCumulative, intSeason_Previous, intYearSeason, intPeriod_previous) = CountSpeciesInDictionary(dicStatSpeciesCumulative(4))
2400      dblStatSeasonYearPeriod(conStatDETSpeciesCumulative, intSeason_Previous, intYearSeason, intPeriod_previous) = CountSpeciesInDictionary(dicStatSpeciesCumulative(5))

2410  End If

2420  rst.Close
2430  Set rst = Nothing

      ' Season
      ' ------
      ' Fill in dblStatSeasonYearPeriod(stat, intSeason, intYearSeason, intPeriodSeason)
      '     for each stat in (conStatCensusSpecies, conStatBNDSpecies, conStatRETSpecies, conStatREPSpecies, conStatAlienSpecies, conStatDETSpecies)  and their cumulative conterparts
      '         x season

2440  SysCmd acSysCmdSetStatus, "Season : Species"

2450  intSeason_Previous = -99

2460  strSQL = "qryMBOProgramReport_Season_Species"
          
2470  Set qdf = CurrentDb.QueryDefs(strSQL)
2480  qdf.Parameters("argLocation").value = strLocation
2490  qdf.Parameters("argYearFirst").value = intYearFirst
2500  qdf.Parameters("argYearLast").value = intYearLast
2510  Set rst = qdf.OpenRecordset

2520  Do While Not rst.EOF
2530      intSeason = toIntSeasonFromStrSeason(Nz(rst("Season")))
2540      strSpecies = Nz(rst("Species"))
2550      lngStat(0) = Nz(rst("Census"))
2560      lngStat(1) = Nz(rst("Banded"))
2570      lngStat(2) = Nz(rst("Returns"))
2580      lngStat(3) = Nz(rst("Repeats"))
2590      lngStat(4) = Nz(rst("Alien"))
2600      lngStat(5) = Nz(rst("DET"))
          
2610      If intSeason <> intSeason_Previous Then
        
              ' L1 control break OR first record
        
2620          If intSeason_Previous <> -99 Then
                         
                  ' F1
                  
2630              dblStatSeasonYearPeriod(conStatCensusSpecies, intSeason_Previous, intYearSeason, intPeriodSeason) = CountSpeciesInDictionary(dicStatSpecies(0))
2640              dblStatSeasonYearPeriod(conStatBNDSpecies, intSeason_Previous, intYearSeason, intPeriodSeason) = CountSpeciesInDictionary(dicStatSpecies(1))
2650              dblStatSeasonYearPeriod(conStatRETSpecies, intSeason_Previous, intYearSeason, intPeriodSeason) = CountSpeciesInDictionary(dicStatSpecies(2))
2660              dblStatSeasonYearPeriod(conStatREPSpecies, intSeason_Previous, intYearSeason, intPeriodSeason) = CountSpeciesInDictionary(dicStatSpecies(3))
2670              dblStatSeasonYearPeriod(conStatAlienSpecies, intSeason_Previous, intYearSeason, intPeriodSeason) = CountSpeciesInDictionary(dicStatSpecies(4))
2680              dblStatSeasonYearPeriod(conStatDETSpecies, intSeason_Previous, intYearSeason, intPeriodSeason) = CountSpeciesInDictionary(dicStatSpecies(5))
           
2690          End If
                  
              ' H1
              
2700          For stat = 0 To 5
2710              dicStatSpecies(stat).RemoveAll
2720          Next
        
2730     End If
         
         ' Detail
                    
2740      For stat = 0 To 5
2750          If lngStat(stat) > 0 Then
2760              If Not dicStatSpecies(stat).Exists(strSpecies) Then
2770                  Call dicStatSpecies(stat).Add(strSpecies, strSpecies)
2780              End If
2790          End If
2800      Next
          
2810      intSeason_Previous = intSeason

2820      rst.MoveNext
2830  Loop

2840  If intSeason_Previous <> -99 Then
          
          ' F1
          
2850      dblStatSeasonYearPeriod(conStatCensusSpecies, intSeason_Previous, intYearSeason, intPeriodSeason) = CountSpeciesInDictionary(dicStatSpecies(0))
2860      dblStatSeasonYearPeriod(conStatBNDSpecies, intSeason_Previous, intYearSeason, intPeriodSeason) = CountSpeciesInDictionary(dicStatSpecies(1))
2870      dblStatSeasonYearPeriod(conStatRETSpecies, intSeason_Previous, intYearSeason, intPeriodSeason) = CountSpeciesInDictionary(dicStatSpecies(2))
2880      dblStatSeasonYearPeriod(conStatREPSpecies, intSeason_Previous, intYearSeason, intPeriodSeason) = CountSpeciesInDictionary(dicStatSpecies(3))
2890      dblStatSeasonYearPeriod(conStatAlienSpecies, intSeason_Previous, intYearSeason, intPeriodSeason) = CountSpeciesInDictionary(dicStatSpecies(4))
2900      dblStatSeasonYearPeriod(conStatDETSpecies, intSeason_Previous, intYearSeason, intPeriodSeason) = CountSpeciesInDictionary(dicStatSpecies(5))

2910  End If

2920  rst.Close
2930  Set rst = Nothing
          
          
2940  SysCmd acSysCmdClearStatus
          

      'DD Error Handler Start
Exit_label:
2950       Exit Sub
Err_label:
2960       Select Case Err.Number
           Case Else
2970            Call LogError("basMBOProgramReport_SeasonYearPeriod", "MBOProgramReport_SeasonYearPeriod_Species")
2980       End Select
2990       Resume Exit_label
      'DD Error Handler End
          
    End Sub


'---------------------------------------------------------------------------------------
' MBOProgramReport_SeasonYearPeriod_CensusPeriods
'---------------------------------------------------------------------------------------
 
Private Sub MBOProgramReport_SeasonYearPeriod_CensusPeriods( _
    ByVal intYearFirst As Integer, _
    ByVal intYearLast As Integer, _
    ByVal strLocation As String)
          
      Dim intSeason As Integer
      Dim intYear As Integer
      Dim intPeriod As Integer

10    On Error GoTo Err_label

20    For intSeason = intSeasonFirst To intSeasonLast
30        For intYear = intYearFirst To intYearLast
40            For intPeriod = 1 To intPeriodLast
50                If dblStatSeasonYearPeriod(conStatCensusDays, intSeason, intYear, intPeriod) > 0 Then
60                   dblStatSeasonYearPeriod(conStatCensusPeriods, intSeason, intYear, intPeriod) = 1
70                End If
80            Next
90        Next
100   Next
          
110   Call MBOProgramReport_SeasonYearPeriod_TotalMean(conStatCensusPeriods, intYearFirst, intYearLast, strLocation, fCopyToSeason:=True)
120   Call MBOProgramReport_SeasonYearPeriod_MinMax(conStatCensusPeriods, intYearFirst, intYearLast, strLocation)

      'DD Error Handler Start
Exit_label:
130        Exit Sub
Err_label:
140        Select Case Err.Number
           Case Else
150             Call LogError("basMBOProgramReport_SeasonYearPeriod", "MBOProgramReport_SeasonYearPeriod_CensusPeriods")
160        End Select
170        Resume Exit_label
      'DD Error Handler End
          
End Sub

'---------------------------------------------------------------------------------------
' MBOProgramReport_SeasonYearPeriod_DETPeriods
'---------------------------------------------------------------------------------------
 
Private Sub MBOProgramReport_SeasonYearPeriod_DETPeriods( _
    ByVal intYearFirst As Integer, _
    ByVal intYearLast As Integer, _
    ByVal strLocation As String)
          
      Dim intSeason As Integer
      Dim intYear As Integer
      Dim intPeriod As Integer

10    On Error GoTo Err_label

20    For intSeason = intSeasonFirst To intSeasonLast
30        For intYear = intYearFirst To intYearLast
40            For intPeriod = 1 To intPeriodLast
50                If dblStatSeasonYearPeriod(conStatDETDays, intSeason, intYear, intPeriod) > 0 Then
60                   dblStatSeasonYearPeriod(conStatDETPeriods, intSeason, intYear, intPeriod) = 1
70                End If
80            Next
90        Next
100   Next
          
110   Call MBOProgramReport_SeasonYearPeriod_TotalMean(conStatDETPeriods, intYearFirst, intYearLast, strLocation, fCopyToSeason:=True)
120   Call MBOProgramReport_SeasonYearPeriod_MinMax(conStatDETPeriods, intYearFirst, intYearLast, strLocation)

      'DD Error Handler Start
Exit_label:
130        Exit Sub
Err_label:
140        Select Case Err.Number
           Case Else
150             Call LogError("basMBOProgramReport_SeasonYearPeriod", "MBOProgramReport_SeasonYearPeriod_DETPeriods")
160        End Select
170        Resume Exit_label
      'DD Error Handler End
          
End Sub

'---------------------------------------------------------------------------------------
' MBOProgramReport_SeasonYearPeriod_CapturePeriods
'---------------------------------------------------------------------------------------

Private Sub MBOProgramReport_SeasonYearPeriod_CapturePeriods( _
    ByVal intYearFirst As Integer, _
    ByVal intYearLast As Integer, _
    ByVal strLocation As String)

      Dim strSQL As String
      Dim qdf As DAO.QueryDef
      Dim rst As DAO.Recordset
      Dim intYear As Integer
      Dim intPeriod As Integer
      Dim intSeason As Integer
      Dim strSeason As String

10    On Error GoTo Err_label

20    SysCmd acSysCmdSetStatus, "Capture Periods"

30    For intSeason = intSeasonFirst To intSeasonLast
40        For intYear = intYearFirst To intYearLast
50            For intPeriod = 1 To intPeriodLast
60                If dblStatSeasonYearPeriod(conStatCaptureDays, intSeason, intYear, intPeriod) > 0 Then
70                   dblStatSeasonYearPeriod(conStatCapturePeriods, intSeason, intYear, intPeriod) = 1
80                End If
90            Next
100       Next
110   Next

120   Call MBOProgramReport_SeasonYearPeriod_TotalMean(conStatCapturePeriods, intYearFirst, intYearLast, strLocation, fCopyToSeason:=True)
130   Call MBOProgramReport_SeasonYearPeriod_MinMax(conStatCapturePeriods, intYearFirst, intYearLast, strLocation)

140   SysCmd acSysCmdClearStatus

      'DD Error Handler Start
Exit_label:
150        Exit Sub
Err_label:
160        Select Case Err.Number
           Case Else
170       Call LogError("basMBOProgramReport_SeasonYearPeriod", "MBOProgramReport_SeasonYearPeriod_CapturePeriods")
180        End Select
190        Resume Exit_label
      'DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' MBOProgramReport_SeasonYearPeriod_FullNetCoverageDays
'---------------------------------------------------------------------------------------
' Full Net Coverage Days, and
' Net Days

Private Sub MBOProgramReport_SeasonYearPeriod_FullNetCoverageDays( _
    ByVal intYearFirst As Integer, _
    ByVal intYearLast As Integer, _
    ByVal strLocation As String)

Dim strSQL As String
Dim qdf As DAO.QueryDef
Dim rst As DAO.Recordset
Dim intYear As Integer
Dim intPeriod As Integer
Dim intSeason As Integer
Dim strSeason As String

10    On Error GoTo Err_label

20    SysCmd acSysCmdSetStatus, "Season x Year x Period : Full Net Coverage Days"

' Season x Year x Period

30    strSQL = "qryMBOProgramReport_SeasonYearPeriod_FullNetCoverage_B"
40    Set qdf = CurrentDb.QueryDefs(strSQL)
50    qdf("argLocation") = "MBO"          ' defensive
60    qdf("argYearFirst") = intYearFirst
70    qdf("argYearLast") = intYearLast
80    Set rst = qdf.OpenRecordset

90    Do While Not rst.EOF
100       intSeason = toIntSeasonFromStrSeason(Nz(rst("Season")))
110       intYear = Nz(rst("YearEx"))
120       intPeriod = Nz(rst("Period"))
130       dblStatSeasonYearPeriod(conStatFullNetCoverageDays, intSeason, intYear, intPeriod) = Nz(rst("FullNetCoverageDays"))
140       dblStatSeasonYearPeriod(conStatNetDays, intSeason, intYear, intPeriod) = Nz(rst("NetDays"))
150       rst.MoveNext
160   Loop
170   rst.Close
180   Set rst = Nothing

190   Call MBOProgramReport_SeasonYearPeriod_TotalMean(conStatFullNetCoverageDays, intYearFirst, intYearLast, strLocation, fCopyToSeason:=True)
200   Call MBOProgramReport_SeasonYearPeriod_MinMax(conStatFullNetCoverageDays, intYearFirst, intYearLast, strLocation)

210   Call MBOProgramReport_SeasonYearPeriod_Cumulative(conStatFullNetCoverageDays, conStatFullNetCoverageDaysCumulative, intYearFirst, intYearLast, strLocation)

220   Call MBOProgramReport_SeasonYearPeriod_TotalMean(conStatNetDays, intYearFirst, intYearLast, strLocation, fCopyToSeason:=True)
230   Call MBOProgramReport_SeasonYearPeriod_MinMax(conStatNetDays, intYearFirst, intYearLast, strLocation)

240   Call MBOProgramReport_SeasonYearPeriod_Cumulative(conStatNetDays, conStatNetDaysCumulative, intYearFirst, intYearLast, strLocation)


250   SysCmd acSysCmdClearStatus

'DD Error Handler Start
Exit_label:
260        Exit Sub
Err_label:
270        Select Case Err.Number
     Case Else
280       Call LogError("basMBOProgramReport_SeasonYearPeriod", "MBOProgramReport_SeasonYearPeriod_FullNetCoverageDays")
290        End Select
300        Resume Exit_label
'DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' MBOProgramReport_SeasonYearPeriod_DETorCaptureDays
'---------------------------------------------------------------------------------------

Private Sub MBOProgramReport_SeasonYearPeriod_DETorCaptureDays( _
    ByVal intYearFirst As Integer, _
    ByVal intYearLast As Integer, _
    ByVal strLocation As String)

      Dim strSQL As String
      Dim qdf As DAO.QueryDef
      Dim rst As DAO.Recordset
      Dim intYear As Integer
      Dim intPeriod As Integer
      Dim intSeason As Integer
      Dim strSeason As String

10    On Error GoTo Err_label

'20    SysCmd acSysCmdSetStatus, "Season x Year x Period : DET or Capture Days"
'
'      ' Season x Year x Period
'
'30    For intSeason = intSeasonFirst To intSeasonLast
'40        For intYear = intYearFirst To intYearLast
'50            For intPeriod = 1 To intPeriodLast_SeasonYear(intSeason, intYear)
'60                dblStatSeasonYearPeriod(conStatDETorCaptureDays, intSeason, intYear, intPeriod) = _
'                     dblStatSeasonYearPeriod(conStatDETDays, intSeason, intYear, intPeriod) + _
'                      dblStatSeasonYearPeriod(conStatCaptureDays, intSeason, intYear, intPeriod)
'70            Next
'80        Next
'90    Next
'
'100   Call MBOProgramReport_SeasonYearPeriod_TotalMean(conStatDETorCaptureDays, intYearFirst, intYearLast, strLocation, fCopyToSeason:=True)
'110   Call MBOProgramReport_SeasonYearPeriod_MinMax(conStatDETorCaptureDays, intYearFirst, intYearLast, strLocation)
'
'120   Call MBOProgramReport_SeasonYearPeriod_Cumulative(conStatDETorCaptureDays, conStatDETorCaptureDaysCumulative, intYearFirst, intYearLast, strLocation)
'
'130   SysCmd acSysCmdClearStatus

      'DD Error Handler Start
Exit_label:
20         Exit Sub
Err_label:
30         Select Case Err.Number
           Case Else
40        Call LogError("basMBOProgramReport_SeasonYearPeriod", "MBOProgramReport_SeasonYearPeriod_CaptureDays")
50         End Select
60         Resume Exit_label
      'DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' MBOProgramReport_SeasonYearPeriod_DETDays
'---------------------------------------------------------------------------------------

Private Sub MBOProgramReport_SeasonYearPeriod_DETDays( _
    ByVal intYearFirst As Integer, _
    ByVal intYearLast As Integer, _
    ByVal strLocation As String)

Dim strSQL As String
Dim qdf As DAO.QueryDef
Dim rst As DAO.Recordset
Dim intYear As Integer
Dim intPeriod As Integer
Dim intSeason As Integer
Dim strSeason As String

10    On Error GoTo Err_label

20    SysCmd acSysCmdSetStatus, "Season x Year x Period : DET Days"

' Season x Year x Period

30    strSQL = "qryMBOProgramReport_SeasonYearPeriod_DETDays_B"
40    Set qdf = CurrentDb.QueryDefs(strSQL)
50    qdf("argLocation") = "MBO"          ' defensive
60    qdf("argYearFirst") = intYearFirst
70    qdf("argYearLast") = intYearLast
80    Set rst = qdf.OpenRecordset

90    Do While Not rst.EOF
100       intSeason = toIntSeasonFromStrSeason(Nz(rst("Season")))
110       intYear = Nz(rst("YearEx"))
120       intPeriod = Nz(rst("Period"))
130       dblStatSeasonYearPeriod(conStatDETDays, intSeason, intYear, intPeriod) = Nz(rst("DETDays"))
140       rst.MoveNext
150   Loop
160   rst.Close
170   Set rst = Nothing

180   Call MBOProgramReport_SeasonYearPeriod_TotalMean(conStatDETDays, intYearFirst, intYearLast, strLocation, fCopyToSeason:=True)
190   Call MBOProgramReport_SeasonYearPeriod_MinMax(conStatDETDays, intYearFirst, intYearLast, strLocation)

200   Call MBOProgramReport_SeasonYearPeriod_Cumulative(conStatDETDays, conStatDETDaysCumulative, intYearFirst, intYearLast, strLocation)

210   SysCmd acSysCmdClearStatus

'DD Error Handler Start
Exit_label:
220        Exit Sub
Err_label:
230        Select Case Err.Number
     Case Else
240       Call LogError("basMBOProgramReport_SeasonYearPeriod", "MBOProgramReport_SeasonYearPeriod_CaptureDays")
250        End Select
260        Resume Exit_label
'DD Error Handler End

End Sub

Private Sub MBOProgramReport_SeasonYearPeriod_CensusDays( _
    ByVal intYearFirst As Integer, _
    ByVal intYearLast As Integer, _
    ByVal strLocation As String)

Dim strSQL As String
Dim qdf As DAO.QueryDef
Dim rst As DAO.Recordset
Dim intYear As Integer
Dim intPeriod As Integer
Dim intSeason As Integer
Dim strSeason As String

10    On Error GoTo Err_label

20    SysCmd acSysCmdSetStatus, "Season x Year x Period : Census Days"

' Season x Year x Period

30    strSQL = "qryMBOProgramReport_SeasonYearPeriod_CensusDays_B"
40    Set qdf = CurrentDb.QueryDefs(strSQL)
50    qdf("argLocation") = "MBO"          ' defensive
60    qdf("argYearFirst") = intYearFirst
70    qdf("argYearLast") = intYearLast
80    Set rst = qdf.OpenRecordset

90    Do While Not rst.EOF
100       intSeason = toIntSeasonFromStrSeason(Nz(rst("Season")))
110       intYear = Nz(rst("YearEx"))
120       intPeriod = Nz(rst("Period"))
130       dblStatSeasonYearPeriod(conStatCensusDays, intSeason, intYear, intPeriod) = Nz(rst("CensusDays"))
140       rst.MoveNext
150   Loop
160   rst.Close
170   Set rst = Nothing

180   Call MBOProgramReport_SeasonYearPeriod_TotalMean(conStatCensusDays, intYearFirst, intYearLast, strLocation, fCopyToSeason:=True)
190   Call MBOProgramReport_SeasonYearPeriod_MinMax(conStatCensusDays, intYearFirst, intYearLast, strLocation)

200   Call MBOProgramReport_SeasonYearPeriod_Cumulative(conStatCensusDays, conStatCensusDaysCumulative, intYearFirst, intYearLast, strLocation)

210   SysCmd acSysCmdClearStatus

'DD Error Handler Start
Exit_label:
220        Exit Sub
Err_label:
230        Select Case Err.Number
     Case Else
240       Call LogError("basMBOProgramReport_SeasonYearPeriod", "MBOProgramReport_SeasonYearPeriod_CensusDays")
250        End Select
260        Resume Exit_label
'DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' MBOProgramReport_SeasonYearPeriod_CaptureDays
'---------------------------------------------------------------------------------------

Private Sub MBOProgramReport_SeasonYearPeriod_CaptureDays( _
    ByVal intYearFirst As Integer, _
    ByVal intYearLast As Integer, _
    ByVal strLocation As String)

Dim strSQL As String
Dim qdf As DAO.QueryDef
Dim rst As DAO.Recordset
Dim intYear As Integer
Dim intPeriod As Integer
Dim intSeason As Integer
Dim strSeason As String

10    On Error GoTo Err_label

20    SysCmd acSysCmdSetStatus, "Season x Year x Period : Capture Days"

' tblMBOProgramReportDETSpecies
' -------------------------------------
' Essentially the same as tblDETSpecies
' WHERE location = ...
' WHERE YearEx BETWEEN ... AND ...
' SNGO records merged
' TRFL records merged
' -------------------------------------
' Season
' YearEx
' Location
' DateEx
' Program
' NetHours
' Observed
' Census
' Banded
' Repeats
' Returns
' DET
' Alien
' Replacement
' Species
' SpeciesEnglish
' Period
' DateFrom



' Season x Year x Period

' qryMBOProgramReport_SeasonYearPeriod_CaptureDays_AnyCaptures
' ------------------------------------------------------------
' List the days on which there were any captures
' ------------------------------------------------------------
' tblMBOProgramReport_DETSpecies
'
' GROUP BY YearEx
' GROUP BY Season
' GROUP BY Period
' GROUP BY DateEx
' Captures: SUM(Nz([Banded])+Nz([Returns])+Nz([Repeats])+Nz([Alien])+Nz([Replacement]))
' HAVING Captures > 0
' Report YearEx, Season, Period, DateEx

' qryMBOProgramReport_SeasonYearPeriod_CaptureDays_AnyNetHours
' ------------------------------------------------------------
' List the days on which Net Hours > 0
' ------------------------------------------------------------
' tblDETDaily x tblPrograms
'
' WHERE Location = [argLocation]
' WHERE YearEx BETWEEN [argYearFirst] AND [argYearLast]
' Season = MonitoringProgramSeason
' Period: toPeriod([MonitoringProgramSeason],[DateEx],[DateFrom])
' DateEx
' WHERE SongBirdNets > 0
' Report YearEx, Season, Period, DateEx

' qryMBOProgramReport_SeasonYearPeriod_CaptureDays_Union
' ------------------------------------------------------
' qryMBOProgramReport_SeasonYearPeriod_CaptureDays_AnyCaptures UNION
' qryMBOProgramReport_SeasonYearPeriod_CaptureDays_AnyNetHours
'
'
' Report YearEx, Season, Period, DateEx

' qryMBOProgramReport_SeasonYearPeriod_CaptureDays
' ------------------------------------------------
' qryMBOProgramReport_SeasonYearPeriod_CaptureDays_Union
' GROUP BY YearEx
' GROUP BY Season
' GROUP BY Period
' CaptureDays = COUNT DateEx
' Report YearEx, Season, Period, CaptureDays

' Compute dblStatSeasonYearPeriod(conStatCaptureDays, intSeason, intYear, intPeriod) for each season, year, period

30    strSQL = "qryMBOProgramReport_SeasonYearPeriod_CaptureDays"
40    Set qdf = CurrentDb.QueryDefs(strSQL)
50    qdf("argLocation") = strLocation
60    qdf("argYearFirst") = intYearFirst
70    qdf("argYearLast") = intYearLast
80    Set rst = qdf.OpenRecordset

90    Do While Not rst.EOF
100       intSeason = toIntSeasonFromStrSeason(Nz(rst("Season")))
110       intYear = Nz(rst("YearEx"))
120       intPeriod = Nz(rst("Period"))
130       dblStatSeasonYearPeriod(conStatCaptureDays, intSeason, intYear, intPeriod) = Nz(rst("CaptureDays"))
140       rst.MoveNext
150   Loop
160   rst.Close
170   Set rst = Nothing

180   Call MBOProgramReport_SeasonYearPeriod_TotalMean(conStatCaptureDays, intYearFirst, intYearLast, strLocation, fCopyToSeason:=True)
190   Call MBOProgramReport_SeasonYearPeriod_MinMax(conStatCaptureDays, intYearFirst, intYearLast, strLocation)

200   Call MBOProgramReport_SeasonYearPeriod_Cumulative(conStatCaptureDays, conStatCaptureDaysCumulative, intYearFirst, intYearLast, strLocation)

210   SysCmd acSysCmdClearStatus

'DD Error Handler Start
Exit_label:
220        Exit Sub
Err_label:
230        Select Case Err.Number
     Case Else
240       Call LogError("basMBOProgramReport_SeasonYearPeriod", "MBOProgramReport_SeasonYearPeriod_CaptureDays")
250        End Select
260        Resume Exit_label
'DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' MBOProgramReport_SeasonYearPeriod_NetHours
'---------------------------------------------------------------------------------------

Private Sub MBOProgramReport_SeasonYearPeriod_NetHours( _
    ByVal intYearFirst As Integer, _
    ByVal intYearLast As Integer, _
    ByVal strLocation As String)

Dim strSQL As String
Dim qdf As DAO.QueryDef
Dim rst As DAO.Recordset
Dim intYear As Integer
Dim intPeriod As Integer
Dim intSeason As Integer
Dim strSeason As String

10    On Error GoTo Err_label

20    SysCmd acSysCmdSetStatus, "Season x Year x Period : Net Hours"

' Season x Year x Period


30    strSQL = "qryMBOProgramReport_SeasonYearPeriod_NetHours_B"
40    Set qdf = CurrentDb.QueryDefs(strSQL)
50    qdf("argLocation") = "MBO"          ' defensive
60    qdf("argYearFirst") = intYearFirst
70    qdf("argYearLast") = intYearLast
80    Set rst = qdf.OpenRecordset

90    Do While Not rst.EOF
100       intSeason = toIntSeasonFromStrSeason(Nz(rst("Season")))
110       intYear = Nz(rst("YearEx"))
120       intPeriod = Nz(rst("Period"))
130       dblStatSeasonYearPeriod(conStatNetHours, intSeason, intYear, intPeriod) = Nz(rst("NetHours"))
140       rst.MoveNext
150   Loop
160   rst.Close
170   Set rst = Nothing

180   Call MBOProgramReport_SeasonYearPeriod_TotalMean(conStatNetHours, intYearFirst, intYearLast, strLocation, fCopyToSeason:=True)
190   Call MBOProgramReport_SeasonYearPeriod_MinMax(conStatNetHours, intYearFirst, intYearLast, strLocation)

200   Call MBOProgramReport_SeasonYearPeriod_Cumulative(conStatNetHours, conStatNetHoursCumulative, intYearFirst, intYearLast, strLocation)


210   SysCmd acSysCmdClearStatus

'DD Error Handler Start
Exit_label:
220        Exit Sub
Err_label:
230        Select Case Err.Number
     Case Else
240       Call LogError("basMBOProgramReport_SeasonYearPeriod", "MBOProgramReport_SeasonYearPeriod_NetHours")
250        End Select
260        Resume Exit_label
'DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' MBOProgramReport_SeasonYearPeriod_Birds
'---------------------------------------------------------------------------------------

Private Sub MBOProgramReport_SeasonYearPeriod_Birds( _
    ByVal intYearFirst As Integer, _
    ByVal intYearLast As Integer, _
    ByVal strLocation As String)

Dim strSQL As String
Dim qdf As DAO.QueryDef
Dim rst As DAO.Recordset
Dim intYear As Integer
Dim intPeriod As Integer
Dim intSeason As Integer
Dim strSeason As String

10    On Error GoTo Err_label

20    SysCmd acSysCmdSetStatus, "Season x Year x Period : Banded Birds"

' Season x Year x Period

30    strSQL = "qryMBOProgramReport_SeasonYearPeriod_Birds"
40    Set qdf = CurrentDb.QueryDefs(strSQL)
50    qdf("argLocation") = "MBO"          ' defensive
60    qdf("argYearFirst") = intYearFirst
70    qdf("argYearLast") = intYearLast
80    Set rst = qdf.OpenRecordset

90    Do While Not rst.EOF
100       intSeason = toIntSeasonFromStrSeason(Nz(rst("Season")))
110       intYear = Nz(rst("YearEx"))
120       intPeriod = Nz(rst("Period"))
130       dblStatSeasonYearPeriod(conStatBNDBirds, intSeason, intYear, intPeriod) = Nz(rst("Banded")) ' Loading zeros is harmless
140       dblStatSeasonYearPeriod(conStatRETBirds, intSeason, intYear, intPeriod) = Nz(rst("Returns"))
150       dblStatSeasonYearPeriod(conStatREPBirds, intSeason, intYear, intPeriod) = Nz(rst("Repeats"))
160       dblStatSeasonYearPeriod(conStatAlienBirds, intSeason, intYear, intPeriod) = Nz(rst("Alien"))
170       dblStatSeasonYearPeriod(conStatDETBirds, intSeason, intYear, intPeriod) = Nz(rst("DET"))
180       rst.MoveNext
190   Loop
200   rst.Close
210   Set rst = Nothing

220   Call MBOProgramReport_SeasonYearPeriod_TotalMean(conStatBNDBirds, intYearFirst, intYearLast, strLocation, fCopyToSeason:=True)
230   Call MBOProgramReport_SeasonYearPeriod_MinMax(conStatBNDBirds, intYearFirst, intYearLast, strLocation)
240   Call MBOProgramReport_SeasonYearPeriod_TotalMean(conStatRETBirds, intYearFirst, intYearLast, strLocation, fCopyToSeason:=True)
250   Call MBOProgramReport_SeasonYearPeriod_MinMax(conStatRETBirds, intYearFirst, intYearLast, strLocation)
260   Call MBOProgramReport_SeasonYearPeriod_TotalMean(conStatREPBirds, intYearFirst, intYearLast, strLocation, fCopyToSeason:=True)
270   Call MBOProgramReport_SeasonYearPeriod_MinMax(conStatREPBirds, intYearFirst, intYearLast, strLocation)
280   Call MBOProgramReport_SeasonYearPeriod_TotalMean(conStatAlienBirds, intYearFirst, intYearLast, strLocation, fCopyToSeason:=True)
290   Call MBOProgramReport_SeasonYearPeriod_MinMax(conStatAlienBirds, intYearFirst, intYearLast, strLocation)
300   Call MBOProgramReport_SeasonYearPeriod_TotalMean(conStatDETBirds, intYearFirst, intYearLast, strLocation, fCopyToSeason:=True)
310   Call MBOProgramReport_SeasonYearPeriod_MinMax(conStatDETBirds, intYearFirst, intYearLast, strLocation)

320   Call MBOProgramReport_SeasonYearPeriod_Cumulative(conStatBNDBirds, conStatBNDBirdsCumulative, intYearFirst, intYearLast, strLocation)
330   Call MBOProgramReport_SeasonYearPeriod_Cumulative(conStatRETBirds, conStatRETBirdsCumulative, intYearFirst, intYearLast, strLocation)
340   Call MBOProgramReport_SeasonYearPeriod_Cumulative(conStatREPBirds, conStatREPBirdsCumulative, intYearFirst, intYearLast, strLocation)
350   Call MBOProgramReport_SeasonYearPeriod_Cumulative(conStatAlienBirds, conStatAlienBirdsCumulative, intYearFirst, intYearLast, strLocation)
360   Call MBOProgramReport_SeasonYearPeriod_Cumulative(conStatDETBirds, conStatDETBirdsCumulative, intYearFirst, intYearLast, strLocation)

370   SysCmd acSysCmdClearStatus

'DD Error Handler Start
Exit_label:
380        Exit Sub
Err_label:
390        Select Case Err.Number
     Case Else
400       Call LogError("basMBOProgramReport_SeasonYearPeriod", "MBOProgramReport_SeasonYearPeriod_Birds")
410        End Select
420        Resume Exit_label
'DD Error Handler End

End Sub


'---------------------------------------------------------------------------------------
' MBOProgramReport_SeasonYearPeriod_BandedTRES
'---------------------------------------------------------------------------------------
' Nestbox only

Private Sub MBOProgramReport_SeasonYearPeriod_BandedTRES( _
    ByVal intYearFirst As Integer, _
    ByVal intYearLast As Integer, _
    ByVal strLocation As String)

Dim strSQL As String
Dim qdf As DAO.QueryDef
Dim rst As DAO.Recordset
Dim intYear As Integer
Dim intPeriod As Integer
Dim intSeason As Integer
Dim strSeason As String

10    On Error GoTo Err_label

20    SysCmd acSysCmdSetStatus, "Season x Year x Period : Banded TRES"

' Season x Year x Period

30    strSQL = "qryMBOProgramReport_SeasonYearPeriod_BandedTRES"
40    Set qdf = CurrentDb.QueryDefs(strSQL)
50    qdf("argLocation") = "MBO"          ' defensive
60    qdf("argYearFirst") = intYearFirst
70    qdf("argYearLast") = intYearLast
80    Set rst = qdf.OpenRecordset

90    intSeason = conNestbox

100   Do While Not rst.EOF
110       intYear = Nz(rst("YearEx"))
120       intPeriod = Nz(rst("Period"))
130       dblStatSeasonYearPeriod(conStatBandedTRES, intSeason, intYear, intPeriod) = Nz(rst("Banded")) ' Loading zeros is harmless
140       rst.MoveNext
150   Loop
160   rst.Close
170   Set rst = Nothing

180   Call MBOProgramReport_SeasonYearPeriod_TotalMean(conStatBandedTRES, intYearFirst, intYearLast, strLocation, fCopyToSeason:=True)
190   Call MBOProgramReport_SeasonYearPeriod_MinMax(conStatBandedTRES, intYearFirst, intYearLast, strLocation)

200   SysCmd acSysCmdClearStatus

'DD Error Handler Start
Exit_label:
210        Exit Sub
Err_label:
220        Select Case Err.Number
     Case Else
230       Call LogError("basMBOProgramReport_SeasonYearPeriod", "MBOProgramReport_SeasonYearPeriod_BandedTRES")
240        End Select
250        Resume Exit_label
'DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' MBOProgramReport_SeasonYearPeriod_BandedTRESHatchYear
'---------------------------------------------------------------------------------------
' Hatch year TRES banded in Nestbox
' Hatch Year = Age "2" or "4"
' --------------------------------------------------------------------------------------

Private Sub MBOProgramReport_SeasonYearPeriod_BandedTRESHatchYear( _
    ByVal intYearFirst As Integer, _
    ByVal intYearLast As Integer, _
    ByVal strLocation As String)

Dim strSQL As String
Dim qdf As DAO.QueryDef
Dim rst As DAO.Recordset
Dim intYear As Integer
Dim intPeriod As Integer
Dim intSeason As Integer
Dim strSeason As String

10    On Error GoTo Err_label

20    SysCmd acSysCmdSetStatus, "Season x Year x Period : Banded TRES"

' Season x Year x Period

30    strSQL = "qryMBOProgramReport_SeasonYearPeriod_BNDAge_TRESNestbox"
40    Set qdf = CurrentDb.QueryDefs(strSQL)
50    qdf("argLocation") = "MBO"          ' defensive
60    qdf("argYearFirst") = intYearFirst
70    qdf("argYearLast") = intYearLast
80    Set rst = qdf.OpenRecordset

90    intSeason = conNestbox

100   Do While Not rst.EOF
110       intYear = Nz(rst("YearEx"))
120       intPeriod = Nz(rst("Period"))
130       dblStatSeasonYearPeriod(conStatBandedTRESHatchYear, intSeason, intYear, intPeriod) = Nz(rst("CountBands")) ' Loading zeros is harmless
140       rst.MoveNext
150   Loop
160   rst.Close
170   Set rst = Nothing

180   Call MBOProgramReport_SeasonYearPeriod_TotalMean(conStatBandedTRESHatchYear, intYearFirst, intYearLast, strLocation, fCopyToSeason:=True)
190   Call MBOProgramReport_SeasonYearPeriod_MinMax(conStatBandedTRESHatchYear, intYearFirst, intYearLast, strLocation)

200   SysCmd acSysCmdClearStatus

'DD Error Handler Start
Exit_label:
210        Exit Sub
Err_label:
220        Select Case Err.Number
     Case Else
230       Call LogError("basMBOProgramReport_SeasonYearPeriod", "MBOProgramReport_SeasonYearPeriod_BandedTRESHatchYear")
240        End Select
250        Resume Exit_label
'DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' MBOProgramReport_SeasonYearPeriod_BirdsPer100NetHours
'---------------------------------------------------------------------------------------

Private Sub MBOProgramReport_SeasonYearPeriod_BirdsPer100NetHours( _
    ByVal intYearFirst As Integer, _
    ByVal intYearLast As Integer, _
    ByVal strLocation As String)
          
10    On Error GoTo Err_label

      Dim intSeason As Integer
      Dim intYear As Integer
      Dim intPeriod As Integer
      Dim dblNetHours As Double

      ' Season x Year x Period

20    For intSeason = intSeasonFirst To intSeasonLast
30        For intYear = intYearFirst To intYearLast
40            For intPeriod = 1 To intPeriodLast_SeasonYear(intSeason, intYear)
50                dblNetHours = dblStatSeasonYearPeriod(conStatNetHours, intSeason, intYear, intPeriod)
60                If dblNetHours > 0 Then
70                    dblStatSeasonYearPeriod(conStatBirdsPer100NetHours, intSeason, intYear, intPeriod) = _
                          Round(100 * dblStatSeasonYearPeriod(conStatBNDBirds, intSeason, intYear, intPeriod) / dblNetHours, 2)
80                End If
90            Next
100       Next
110   Next

120   Call MBOProgramReport_SeasonYearPeriod_TotalMean(conStatBirdsPer100NetHours, intYearFirst, intYearLast, strLocation)

      ' Season x Year

130   For intSeason = intSeasonFirst To intSeasonLast
140       For intYear = intYearFirst To intYearLast
150           dblNetHours = dblStatSeasonYearPeriod(conStatNetHours, intSeason, intYear, intPeriodTotal)
160           If dblNetHours > 0 Then
170               dblStatSeasonYearPeriod(conStatBirdsPer100NetHours, intSeason, intYear, intPeriodSeason) = _
                      Round(100 * dblStatSeasonYearPeriod(conStatBNDBirds, intSeason, intYear, intPeriodTotal) / dblNetHours, 2)
180           End If
190       Next
200   Next

210   Call MBOProgramReport_SeasonYearPeriod_MinMax(conStatBirdsPer100NetHours, intYearFirst, intYearLast, strLocation)

      ' Season x Period

220   For intSeason = intSeasonFirst To intSeasonLast
230       For intPeriod = 1 To intPeriodLast_Season(intSeason)
240           dblNetHours = dblStatSeasonYearPeriod(conStatNetHours, intSeason, intYearTotal, intPeriod)
250           If dblNetHours > 0 Then
260               dblStatSeasonYearPeriod(conStatBirdsPer100NetHours, intSeason, intYearSeason, intPeriod) = _
                      Round(100 * dblStatSeasonYearPeriod(conStatBNDBirds, intSeason, intYearTotal, intPeriod) / dblNetHours, 2)
270           End If
280       Next
290   Next

      ' Season

300   For intSeason = intSeasonFirst To intSeasonLast
310       dblNetHours = dblStatSeasonYearPeriod(conStatNetHours, intSeason, intYearTotal, intPeriodTotal)
320       If dblNetHours > 0 Then
330           dblStatSeasonYearPeriod(conStatBirdsPer100NetHours, intSeason, intYearSeason, intPeriodSeason) = _
                  Round(100 * dblStatSeasonYearPeriod(conStatBNDBirds, intSeason, intYearTotal, intPeriodTotal) / dblNetHours, 2)
340       End If
350   Next

      ' Cumulative Season x Year x Period

360   For intSeason = intSeasonFirst To intSeasonLast
370       For intYear = intYearFirst To intYearLast
380           For intPeriod = 1 To intPeriodLast_SeasonYear(intSeason, intYear)
390               dblNetHours = dblStatSeasonYearPeriod(conStatNetHoursCumulative, intSeason, intYear, intPeriod)
400               If dblNetHours > 0 Then
410                   dblStatSeasonYearPeriod(conStatBirdsPer100NetHoursCumulative, intSeason, intYear, intPeriod) = _
                          Round(100 * dblStatSeasonYearPeriod(conStatBNDBirdsCumulative, intSeason, intYear, intPeriod) / dblNetHours, 2)
420               End If
430           Next
440       Next
450   Next

      ' Cumulative Season x Period

460   For intSeason = intSeasonFirst To intSeasonLast
470       For intPeriod = 1 To intPeriodLast_Season(intSeason)
480           dblNetHours = dblStatSeasonYearPeriod(conStatNetHoursCumulative, intSeason, intYearTotal, intPeriod)
490           If dblNetHours > 0 Then
500               dblStatSeasonYearPeriod(conStatBirdsPer100NetHoursCumulative, intSeason, intYearSeason, intPeriod) = _
                      Round(100 * dblStatSeasonYearPeriod(conStatBNDBirdsCumulative, intSeason, intYearTotal, intPeriod) / dblNetHours, 2)
510           End If
520       Next
530   Next

      'DD Error Handler Start
Exit_label:
540        Exit Sub
Err_label:
550        Select Case Err.Number
           Case Else
560             Call LogError("basMBOProgramReport_SeasonYearPeriod", "MBOProgramReport_SeasonYearPeriod_BirdsPer100NetHours")
570        End Select
580        Resume Exit_label
      'DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' MBOProgramReport_SeasonYearPeriod_BirdsRETREPPer100NetHours
'---------------------------------------------------------------------------------------

Private Sub MBOProgramReport_SeasonYearPeriod_BirdsRETREPPer100NetHours( _
    ByVal intYearFirst As Integer, _
    ByVal intYearLast As Integer, _
    ByVal strLocation As String)

10    On Error GoTo Err_label

      Dim intSeason As Integer
      Dim intYear As Integer
      Dim intPeriod As Integer
      Dim dblNetHours As Double

      ' Season x Year x Period

20    For intSeason = intSeasonFirst To intSeasonLast
30        For intYear = intYearFirst To intYearLast
40            For intPeriod = 1 To intPeriodLast_SeasonYear(intSeason, intYear)
50                dblNetHours = dblStatSeasonYearPeriod(conStatNetHours, intSeason, intYear, intPeriod)
60                If dblNetHours > 0 Then
70                    dblStatSeasonYearPeriod(conStatBirdsRETREPPer100NetHours, intSeason, intYear, intPeriod) = _
                          Round(100 * (dblStatSeasonYearPeriod(conStatRETBirds, intSeason, intYear, intPeriod) + dblStatSeasonYearPeriod(conStatREPBirds, intSeason, intYear, intPeriod)) / dblNetHours, 2)
80                End If
90            Next
100       Next
110   Next

120   Call MBOProgramReport_SeasonYearPeriod_TotalMean(conStatBirdsRETREPPer100NetHours, intYearFirst, intYearLast, strLocation)

      ' Season x Year

130   For intSeason = intSeasonFirst To intSeasonLast
140       For intYear = intYearFirst To intYearLast
150           dblNetHours = dblStatSeasonYearPeriod(conStatNetHours, intSeason, intYear, intPeriodTotal)
160           If dblNetHours > 0 Then
170               dblStatSeasonYearPeriod(conStatBirdsRETREPPer100NetHours, intSeason, intYear, intPeriodSeason) = _
                      Round(100 * (dblStatSeasonYearPeriod(conStatRETBirds, intSeason, intYear, intPeriodTotal) + dblStatSeasonYearPeriod(conStatREPBirds, intSeason, intYear, intPeriodTotal)) / dblNetHours, 2)
180           End If
190       Next
200   Next

210   Call MBOProgramReport_SeasonYearPeriod_MinMax(conStatBirdsRETREPPer100NetHours, intYearFirst, intYearLast, strLocation)

      ' Season x Period

220   For intSeason = intSeasonFirst To intSeasonLast
230       For intPeriod = 1 To intPeriodLast_Season(intSeason)
240           dblNetHours = dblStatSeasonYearPeriod(conStatNetHours, intSeason, intYearTotal, intPeriod)
250           If dblNetHours > 0 Then
260               dblStatSeasonYearPeriod(conStatBirdsRETREPPer100NetHours, intSeason, intYearSeason, intPeriod) = _
                      Round(100 * (dblStatSeasonYearPeriod(conStatRETBirds, intSeason, intYearTotal, intPeriod) + dblStatSeasonYearPeriod(conStatREPBirds, intSeason, intYearTotal, intPeriod)) / dblNetHours, 2)
270           End If
280       Next
290   Next

      ' Season

300   For intSeason = intSeasonFirst To intSeasonLast
310       dblNetHours = dblStatSeasonYearPeriod(conStatNetHours, intSeason, intYearTotal, intPeriodTotal)
320       If dblNetHours > 0 Then
330           dblStatSeasonYearPeriod(conStatBirdsRETREPPer100NetHours, intSeason, intYearSeason, intPeriodSeason) = _
                  Round(100 * (dblStatSeasonYearPeriod(conStatRETBirds, intSeason, intYearTotal, intPeriodTotal) + dblStatSeasonYearPeriod(conStatREPBirds, intSeason, intYearTotal, intPeriodTotal)) / dblNetHours, 2)
340       End If
350   Next

      ' Cumulative Season x Year x Period

360   For intSeason = intSeasonFirst To intSeasonLast
370       For intYear = intYearFirst To intYearLast
380           For intPeriod = 1 To intPeriodLast_SeasonYear(intSeason, intYear)
390               dblNetHours = dblStatSeasonYearPeriod(conStatNetHoursCumulative, intSeason, intYear, intPeriod)
400               If dblNetHours > 0 Then
410                   dblStatSeasonYearPeriod(conStatBirdsRETREPPer100NetHoursCumulative, intSeason, intYear, intPeriod) = _
                          Round(100 * (dblStatSeasonYearPeriod(conStatRETBirdsCumulative, intSeason, intYear, intPeriod) + dblStatSeasonYearPeriod(conStatREPBirdsCumulative, intSeason, intYear, intPeriod)) / dblNetHours, 2)
420               End If
430           Next
440       Next
450   Next

      ' Cumulative Season x Period

460   For intSeason = intSeasonFirst To intSeasonLast
470       For intPeriod = 1 To intPeriodLast_Season(intSeason)
480           dblNetHours = dblStatSeasonYearPeriod(conStatNetHoursCumulative, intSeason, intYearTotal, intPeriod)
490           If dblNetHours > 0 Then
500               dblStatSeasonYearPeriod(conStatBirdsRETREPPer100NetHoursCumulative, intSeason, intYearSeason, intPeriod) = _
                      Round(100 * (dblStatSeasonYearPeriod(conStatRETBirdsCumulative, intSeason, intYearTotal, intPeriod) + dblStatSeasonYearPeriod(conStatREPBirdsCumulative, intSeason, intYearTotal, intPeriod)) / dblNetHours, 2)
510           End If
520       Next
530   Next

    'DD Error Handler Start
Exit_label:
540       Exit Sub
Err_label:
550       Select Case Err.Number
    Case Else
560      Call LogError("basMBOProgramReport_SeasonYearPeriod", "MBOProgramReport_SeasonYearPeriod_BirdsRETREPPer100NetHours")
570       End Select
580       Resume Exit_label
    ' DD Error Handler End
End Sub


Private Sub MBOProgramReport_SeasonYearPeriod_Cumulative( _
    ByVal intStat As Integer, _
    ByVal intStatCumulative As Integer, _
    ByVal intYearFirst As Integer, _
    ByVal intYearLast As Integer, _
    ByVal strLocation As String)
          
10    On Error GoTo Err_label

      Dim intSeason As Integer
      Dim intYear As Integer
      Dim intPeriod As Integer
      Dim dblValue As Double

20    For intSeason = intSeasonFirst To intSeasonLast
30        For intYear = intYearFirst To intYearLast
40            dblValue = 0
50            For intPeriod = 1 To intPeriodLast_SeasonYear(intSeason, intYear)
60                dblValue = dblValue + dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriod)
70            dblStatSeasonYearPeriod(intStatCumulative, intSeason, intYear, intPeriod) = dblValue
80            Next
90        Next
100   Next

110   Call MBOProgramReport_SeasonYearPeriod_MinMax(intStatCumulative, intYearFirst, intYearLast, strLocation)

      'DD Error Handler Start
Exit_label:
120        Exit Sub
Err_label:
130        Select Case Err.Number
           Case Else
140             Call LogError("basMBOProgramReport_SeasonYearPeriod", "MBOProgramReport_SeasonYearPeriod_Cumulative")
150        End Select
160        Resume Exit_label
      'DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' MBOProgramReport_SeasonYearPeriod_MinMax
'---------------------------------------------------------------------------------------
' Compute the minimums and maximums over years
'
' PRE: dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriod) must be initialised for the given intStat, all years, all periods in the season
' PRE: dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriodMean) must be initialised for the given intStat, all years
' PRE: dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriodSeason) must be initialised for the given intStat, all years

' This procedure does not use dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriodTotal)
'
' Fills in:
'    dblStatSeasonYearPeriod(intStat, intSeason, intYearMax, intPeriod)
'    dblStatSeasonYearPeriod(intStat, intSeason, intYearMax, intPeriodMean)
'    dblStatSeasonYearPeriod(intStat, intSeason, intYearMax, intPeriodSeason)

'    dblStatSeasonYearPeriod(intStat, intSeason, intYearMin, intPeriod)
'    dblStatSeasonYearPeriod(intStat, intSeason, intYearMin, intPeriodMean)
'    dblStatSeasonYearPeriod(intStat, intSeason, intYearMin, intPeriodSeason)

Private Sub MBOProgramReport_SeasonYearPeriod_MinMax( _
    ByVal intStat As Integer, _
    ByVal intYearFirst As Integer, _
    ByVal intYearLast As Integer, _
    ByVal strLocation As String)
          
10    On Error GoTo Err_label

      Dim intSeason As Integer
      Dim intYear As Integer
      Dim intPeriod As Integer
      Dim dblMax As Double
      Dim dblMin As Double

      ' Max for each period

20    For intSeason = intSeasonFirst To intSeasonLast
30        For intPeriod = 1 To intPeriodLast_Season(intSeason)
40            dblMax = 0
50            For intYear = intYearFirst To intYearLast
60                If dblMax < dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriod) Then
70                    dblMax = dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriod)
80                End If
90            Next
100           dblStatSeasonYearPeriod(intStat, intSeason, intYearMax, intPeriod) = dblMax
110       Next
120   Next

      ' Max for the "Mean" column

130   For intSeason = intSeasonFirst To intSeasonLast
140       dblMax = 0
150       For intYear = intYearFirst To intYearLast
160           If dblMax < dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriodMean) Then
170               dblMax = dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriodMean)
180           End If
190       Next
200       dblStatSeasonYearPeriod(intStat, intSeason, intYearMax, intPeriodMean) = dblMax
210   Next

      ' Max for the "All periods" column

220   For intSeason = intSeasonFirst To intSeasonLast
230       dblMax = 0
240       For intYear = intYearFirst To intYearLast
250           If dblMax < dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriodSeason) Then
260               dblMax = dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriodSeason)
270           End If
280       Next
290       dblStatSeasonYearPeriod(intStat, intSeason, intYearMax, intPeriodSeason) = dblMax
300   Next

      ' Min for each period

310   For intSeason = intSeasonFirst To intSeasonLast
320       For intPeriod = 1 To intPeriodLast_Season(intSeason)
330           dblMin = dblStatSeasonYearPeriod(intStat, intSeason, intYearMax, intPeriod)
340           For intYear = intYearFirst To intYearLast
350               If dblStatSeasonYearPeriod(getDaysStat(intStat), intSeason, intYear, intPeriod) > 0 Then
360                   If dblMin > dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriod) Then
370                       dblMin = dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriod)
380                   End If
390               End If
400           Next
410           dblStatSeasonYearPeriod(intStat, intSeason, intYearMin, intPeriod) = dblMin
420       Next
430   Next

      ' Min for the "Mean" column

440   For intSeason = intSeasonFirst To intSeasonLast
450       dblMin = dblStatSeasonYearPeriod(intStat, intSeason, intYearMax, intPeriodMean)
460       For intYear = intYearFirst To intYearLast
470           If dblStatSeasonYearPeriod(getDaysStat(intStat), intSeason, intYear, intPeriodMean) > 0 Then
480               If dblMin > dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriodMean) Then
490                   dblMin = dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriodMean)
500               End If
510           End If
520           dblStatSeasonYearPeriod(intStat, intSeason, intYearMin, intPeriodMean) = dblMin
530       Next
540   Next

      ' Min for the "All periods" column

550   For intSeason = intSeasonFirst To intSeasonLast
560       dblMin = dblStatSeasonYearPeriod(intStat, intSeason, intYearMax, intPeriodSeason)
570       For intYear = intYearFirst To intYearLast
580           If dblStatSeasonYearPeriod(getDaysStat(intStat), intSeason, intYear, intPeriodSeason) > 0 Then
590               If dblMin > dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriodSeason) Then
600                   dblMin = dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriodSeason)
610               End If
620           End If
630           dblStatSeasonYearPeriod(intStat, intSeason, intYearMin, intPeriodSeason) = dblMin
640       Next
650   Next

      'DD Error Handler Start
Exit_label:
660        Exit Sub
Err_label:
670        Select Case Err.Number
           Case Else
680             Call LogError("basMBOProgramReport_SeasonYearPeriod", "MBOProgramReport_SeasonYearPeriod_MinMax")
690        End Select
700        Resume Exit_label
      'DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' MBOProgramReport_SeasonYearPeriod_TotalMean
'---------------------------------------------------------------------------------------
' Compute the totals and means
'
' PRE: intPeriodLast_SeasonYear(intSeason, intYear) has been initialised
'
' We are going to fill in the following elements of dblStatSeasonYearPeriod(intStat, intSeason, intYearEXTRA, intPeriodEXTRA)
'                                                                                               ------------  --------------
'
'                                         intPeriodMean   intPeriodTotal   intPeriodSeason
'                                 +--+--+---------------+----------------+-----------------+
'                                 |  |  |     xx        |     xx         |      cc         |
'                                 +--+--+---------------+----------------+-----------------+
'                                 |  |  |     xx        |     xx         |      cc         |
'                                 +--+--+---------------+----------------+-----------------+
' intYearMean                     |xx|xx|     xx        |                |                 |
'                                 +--+--+---------------+----------------+-----------------+
' intYearTotal                    |xx|xx|               |     xx         |                 |
'                                 +--+--+---------------+----------------+-----------------+
' intYearSeason                   |cc|cc|               |                |      cc         |
'                                 +--+--+---------------+----------------+-----------------+
' intYearMean_PreviousYears       |xx|xx|     xx        |                |                 |
'                                 +--+--+---------------+----------------+-----------------+
' intYearTotal_PreviousYears      |xx|xx|               |     xx         |                 |
'                                 +--+--+---------------+----------------+-----------------+
' intYearMean_MAPS_PreviousYears  |xx|xx|     xx        |                |                 |
'                                 +--+--+---------------+----------------+-----------------+
' intYearTotal_MAPS_PreviousYears |xx|xx|               |     xx         |                 |
'                                 +--+--+---------------+----------------+-----------------+
'
' The cc values are filled in iff fCopyToSeason is True
'
' ----------------------------------------
' dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriodTotal)
' dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriodMean)
' dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriodSeason)                     if fCopyToSeason

' dblStatSeasonYearPeriod(intStat, intSeason, intYearTotal, intPeriod)
' dblStatSeasonYearPeriod(intStat, intSeason, intYearMean, intPeriod)
' dblStatSeasonYearPeriod(intStat, intSeason, intYearSeason, intPeriod)                     if fCopyToSeason

' dblStatSeasonYearPeriod(intStat, intSeason, intYearTotal, intPeriodTotal)
' dblStatSeasonYearPeriod(intStat, intSeason, intYearMean, intPeriodMean)
' dblStatSeasonYearPeriod(intStat, intSeason, intYearSeason, intPeriodSeason)                if fCopyToSeason

' dblStatSeasonYearPeriod(intStat, intSeason, intYearTotal_PreviousYears, intPeriod)
' dblStatSeasonYearPeriod(intStat, intSeason, intYearMean_PreviousYears, intPeriod)

' dblStatSeasonYearPeriod(intStat, intSeason, intYearTotal_PreviousYears, intPeriodTotal)
' dblStatSeasonYearPeriod(intStat, intSeason, intYearMean_PreviousYears, intPeriodMean)

' dblStatSeasonYearPeriod(intStat, intSeason, intYearTotal_MAPS_PreviousYears, intPeriod)     for MAPS only
' dblStatSeasonYearPeriod(intStat, intSeason, intYearMean_MAPS_PreviousYears, intPeriod)

' dblStatSeasonYearPeriod(intStat, intSeason, intYearTotal_MAPS_PreviousYears, intPeriodTotal)
' dblStatSeasonYearPeriod(intStat, intSeason, intYearMean_MAPS_PreviousYears, intPeriodMean)


Private Sub MBOProgramReport_SeasonYearPeriod_TotalMean( _
    ByVal intStat As Integer, _
    ByVal intYearFirst As Integer, _
    ByVal intYearLast As Integer, _
    ByVal strLocation As String, _
    Optional fCopyToSeason As Boolean = False)
          
10    On Error GoTo Err_label

      Dim intSeason As Integer
      Dim intYear As Integer
      Dim intPeriod As Integer
      Dim dblValue As Double
      Dim intCount As Integer

      ' There is special processing for Capture Days, Capture Periods, DET Days, DET Periods, Census Days, Census Periods

20    Select Case intStat
      Case conStatDETDays, conStatDETPeriods, conStatCaptureDays, conStatCapturePeriods, conStatCensusDays, conStatCensusPeriods

          ' Total and mean over periods
          ' ---------------------------
          ' For each statistic in (conStatDETDays, conStatDETPeriods, conStatCaptureDays, conStatCapturePeriods, conStatCensusDays, conStatCensusPeriods)
          '     for each intSeason x intYear
          '         dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriodTotal) = SUM over intPeriod of dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriod)
          '         dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriodMean) = AVERAGE over intPeriod of dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriod)
          '         if fCopyToSeason
          '             dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriodSeason) = dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriodTotal)
          '
          '
          '                                        intPeriodMean   intPeriodTotal   intPeriodSeason
          '                                +--+--+---------------+----------------+-----------------+
          '                                |  |  |      xx       |       xx       |      xx         |
          '                                +--+--+---------------+----------------+-----------------+
          '                                |  |  |      xx       |       xx       |      xx         |
          '                                +--+--+---------------+----------------+-----------------+
          ' intYearMean                    |  |  |               |                |                 |
          '                                +--+--+---------------+----------------+-----------------+
          ' intYearTotal                   |  |  |               |                |                 |
          '                                +--+--+---------------+----------------+-----------------+
          ' intYearSeason                  |  |  |               |                |                 |
          '                                +--+--+---------------+----------------+-----------------+
          ' intYearMean_PreviousYears      |  |  |               |                |                 |
          '                                +--+--+---------------+----------------+-----------------+
          ' intYearMean_MAPS_previousYears |  |  |               |                |                 |
          '                                +--+--+---------------+----------------+-----------------+
          
          
30        For intSeason = intSeasonFirst To intSeasonLast
40            For intYear = intYearFirst To intYearLast
50                dblValue = 0
60                intCount = 0
70                For intPeriod = 1 To intPeriodLast_SeasonYear(intSeason, intYear)
80                    dblValue = dblValue + dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriod)
90                    If dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriod) > 0 Then intCount = intCount + 1
100               Next
110               dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriodTotal) = dblValue
120               If fCopyToSeason Then
130                   dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriodSeason) = dblValue
140               End If
150               If intCount > 0 Then
160                   dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriodMean) = dblValue / intCount
170               End If
180           Next
190       Next
          
          ' Total and mean over years
          ' -------------------------
          ' For each statistic in (conStatDETDays, conStatDETPeriods, conStatCaptureDays, conStatCapturePeriods, conStatCensusDays, conStatCensusPeriods)
          '   For each season
          '     For each period
          '       Total = dblStatSeasonYearPeriod(intStat, intSeason, intYearTotal, intPeriod) = Sum over years of dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriod)
          '       Count = dblStatSeasonYearPeriod(intStat, intSeason, intYearMean, intPeriod) = Number of years where dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriod) > 0
          '       dblStatSeasonYearPeriod(intStat, intSeason, intYearMean, intPeriod) = Total / Count
          '       If fCopyToSeason
          '           dblStatSeasonYearPeriod(intStat, intSeason, intYearSeason, intPeriod) = Total
          '
          '                                        intPeriodMean   intPeriodTotal   intPeriodSeason
          '                                +--+--+---------------+----------------+-----------------+
          '                                |  |  |               |                |                 |
          '                                +--+--+---------------+----------------+-----------------+
          '                                |  |  |               |                |                 |
          '                                +--+--+---------------+----------------+-----------------+
          ' intYearMean                    |xx|xx|               |                |                 |
          '                                +--+--+---------------+----------------+-----------------+
          ' intYearTotal                   |xx|xx|               |                |                 |
          '                                +--+--+---------------+----------------+-----------------+
          ' intYearSeason                  |xx|xx|               |                |                 |
          '                                +--+--+---------------+----------------+-----------------+
          ' intYearMean_PreviousYears      |  |  |               |                |                 |
          '                                +--+--+---------------+----------------+-----------------+
          ' intYearMean_MAPS_previousYears |  |  |               |                |                 |
          '                                +--+--+---------------+----------------+-----------------+
          
200       For intSeason = intSeasonFirst To intSeasonLast
210           For intPeriod = 1 To intPeriodLast_Season(intSeason)
220               dblValue = 0
230               intCount = 0
240               For intYear = intYearFirst To intYearLast
250                   dblValue = dblValue + dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriod)
260                   If dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriod) > 0 Then intCount = intCount + 1
270               Next
280               dblStatSeasonYearPeriod(intStat, intSeason, intYearTotal, intPeriod) = dblValue
290               If fCopyToSeason Then
300                   dblStatSeasonYearPeriod(intStat, intSeason, intYearSeason, intPeriod) = dblValue
310               End If
320               If intCount > 0 Then
330                   dblStatSeasonYearPeriod(intStat, intSeason, intYearMean, intPeriod) = dblValue / intCount
340               End If
350           Next
360       Next
          
          ' Total and mean over year x period
          ' ---------------------------------
          ' For each statistic in (conStatDETDays, conStatDETPeriods, conStatCaptureDays, conStatCapturePeriods, conStatCensusDays, conStatCensusPeriods)
          '   For each season
          '     Total = dblStatSeasonYearPeriod(intStat, intSeason, intYearTotal, intPeriodTotal) = Sum over years and periods of dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriod)
          '     Count = Count the year x periods where dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriod) > 0
          '     Mean = dblStatSeasonYearPeriod(intStat, intSeason, intYearMean, intPeriodMean) = Total / Count
          '     If fCopyToSeason
          '         dblStatSeasonYearPeriod(intStat, intSeason, intYearSeason, intPeriodSeason) = Total
          '
          '                                        intPeriodMean   intPeriodTotal   intPeriodSeason
          '                                +--+--+---------------+----------------+-----------------+
          '                                |  |  |               |                |                 |
          '                                +--+--+---------------+----------------+-----------------+
          '                                |  |  |               |                |                 |
          '                                +--+--+---------------+----------------+-----------------+
          ' intYearMean                    |  |  |     xx        |                |                 |
          '                                +--+--+---------------+----------------+-----------------+
          ' intYearTotal                   |  |  |               |      xx        |                 |
          '                                +--+--+---------------+----------------+-----------------+
          ' intYearSeason                  |  |  |               |                |       xx        |
          '                                +--+--+---------------+----------------+-----------------+
          ' intYearMean_PreviousYears      |  |  |               |                |                 |
          '                                +--+--+---------------+----------------+-----------------+
          ' intYearMean_MAPS_previousYears |  |  |               |                |                 |
          '                                +--+--+---------------+----------------+-----------------+
           
370       For intSeason = intSeasonFirst To intSeasonLast
380           dblValue = 0
390           intCount = 0
400           For intYear = intYearFirst To intYearLast
410               For intPeriod = 1 To intPeriodLast_SeasonYear(intSeason, intYear)
420                   dblValue = dblValue + dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriod)
430                   If dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriod) > 0 Then intCount = intCount + 1
440               Next
450           Next
460           dblStatSeasonYearPeriod(intStat, intSeason, intYearTotal, intPeriodTotal) = dblValue
470           If fCopyToSeason Then
480               dblStatSeasonYearPeriod(intStat, intSeason, intYearSeason, intPeriodSeason) = dblValue
490           End If
500           If intCount > 0 Then
510               dblStatSeasonYearPeriod(intStat, intSeason, intYearMean, intPeriodMean) = dblValue / intCount
520           End If
530       Next
          
          ' Total and mean of year x period statistic for a given period over previous years
          ' --------------------------------------------------------------------------------
          ' For each statistic in (conStatDETDays, conStatDETPeriods, conStatCaptureDays, conStatCapturePeriods, conStatCensusDays, conStatCensusPeriods)
          '   For each season
          '     For each period
          '       Total = dblStatSeasonYearPeriod(intStat, intSeason, intYearTotal_PreviousYears, intPeriod = Sum over previous years of dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriod)
          '       Count = Number of previous years where dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriod) > 0
          '       dblStatSeasonYearPeriod(intStat, intSeason, intYearMean_PreviousYears, intPeriod) = Total / Count
          '
          '                                         intPeriodMean   intPeriodTotal   intPeriodSeason
          '                                 +--+--+---------------+----------------+-----------------+
          '                                 |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          '                                 |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearMean                     |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearTotal                    |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearSeason                   |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearMean_PreviousYears       |xx|xx|               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearTotal_PreviousYears      |xx|xx|               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearMean_MAPS_PreviousYears  |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearTotal_MAPS_PreviousYears |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          
          
540       If intYearLast > intYearFirst Then
550           For intSeason = intSeasonFirst To intSeasonLast
560               For intPeriod = 1 To intPeriodLast_Season(intSeason)
570                   dblValue = 0
580                   intCount = 0
590                   For intYear = intYearFirst To intYearLast - 1
600                       dblValue = dblValue + dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriod)
610                       If dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriod) > 0 Then intCount = intCount + 1
620                   Next
630                   dblStatSeasonYearPeriod(intStat, intSeason, intYearTotal_PreviousYears, intPeriod) = dblValue
640                   If intCount > 0 Then
650                       dblStatSeasonYearPeriod(intStat, intSeason, intYearMean_PreviousYears, intPeriod) = dblValue / intCount
660                   End If
670               Next
680           Next
690       End If
          
          ' Summer only ---
          ' Total and mean of year x period statistic for a given period over MAPS previous years
          ' -------------------------------------------------------------------------------------
          ' For each statistic in (conStatDETDays, conStatDETPeriods, conStatCaptureDays, conStatCapturePeriods, conStatCensusDays, conStatCensusPeriods)
          '   For intSeasion = conSummer
          '     For each period
          '       Total = dblStatSeasonYearPeriod(intStat, intSeason, intYearTotal_MAPS_PreviousYears, intPeriod = Sum over MAPS previous years of dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriod)
          '       Count = Number of MAPS previous years where dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriod) > 0
          '       dblStatSeasonYearPeriod(intStat, intSeason, intYearMean_MAPS_PreviousYears, intPeriod) = Total / Count
          '
          '                                         intPeriodMean   intPeriodTotal   intPeriodSeason
          '                                 +--+--+---------------+----------------+-----------------+
          '                                 |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          '                                 |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearMean                     |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearTotal                    |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearSeason                   |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearMean_PreviousYears       |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearTotal_PreviousYears      |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearMean_MAPS_PreviousYears  |xx|xx|               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearTotal_MAPS_PreviousYears |xx|xx|               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+

          
700       If intYearLast > intYearFirst_MAPS Then
710               intSeason = conSummer
720               For intPeriod = 1 To intPeriodLast_Season(intSeason)
730                   dblValue = 0
740                   intCount = 0
750                   For intYear = intYearFirst_MAPS To intYearLast - 1
760                       dblValue = dblValue + dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriod)
770                       If dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriod) > 0 Then intCount = intCount + 1
780                   Next
790                   dblStatSeasonYearPeriod(intStat, intSeason, intYearTotal_MAPS_PreviousYears, intPeriod) = dblValue
800                   If intCount > 0 Then
810                       dblStatSeasonYearPeriod(intStat, intSeason, intYearMean_MAPS_PreviousYears, intPeriod) = dblValue / intCount
820                   End If
830               Next

840       End If
          
          
          ' Total and mean of year x period statistic over all previous years and periods
          ' -----------------------------------------------------------------------------
          ' For each statistic in (conStatDETDays, conStatDETPeriods, conStatCaptureDays, conStatCapturePeriods, conStatCensusDays, conStatCensusPeriods)
          '   For each season
          '     Total = dblStatSeasonYearPeriod(intStat, intSeason, intYearTotal_PreviousYears, intPeriodTotal) = Sum over previous years and periods of dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriod)
          '     Count = Count the previous year x periods where dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriod) > 0
          '     Mean = dblStatSeasonYearPeriod(intStat, intSeason, intYearMean_PreviousYears, intPeriodMean) = Total / Count
          '
          '                                         intPeriodMean   intPeriodTotal   intPeriodSeason
          '                                 +--+--+---------------+----------------+-----------------+
          '                                 |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          '                                 |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearMean                     |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearTotal                    |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearSeason                   |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearMean_PreviousYears       |  |  |      xx       |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearTotal_PreviousYears      |  |  |               |       xx       |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearMean_MAPS_PreviousYears  |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearTotal_MAPS_PreviousYears |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+

          
850       If intYearLast > intYearFirst Then
860           For intSeason = intSeasonFirst To intSeasonLast
870               dblValue = 0
880               intCount = 0
890               For intYear = intYearFirst To intYearLast - 1
900                   For intPeriod = 1 To intPeriodLast_SeasonYear(intSeason, intYear)
910                       dblValue = dblValue + dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriod)
920                       If dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriod) > 0 Then intCount = intCount + 1
930                   Next
940               Next
950               dblStatSeasonYearPeriod(intStat, intSeason, intYearTotal_PreviousYears, intPeriodTotal) = dblValue
              '    If fCopyToSeason Then
              '        dblStatSeasonYearPeriod(intStat, intSeason, intYearSeason, intPeriodSeason) = dblValue
              '    End If
960               If intCount > 0 Then
970                   dblStatSeasonYearPeriod(intStat, intSeason, intYearMean_PreviousYears, intPeriodMean) = dblValue / intCount
980               End If
990           Next
1000      End If
          
          ' Summer only ---
          ' Total and mean of year x period statistic over all previous MAPS years and periods
          ' ----------------------------------------------------------------------------------
          ' For each statistic in (conStatDETDays, conStatDETPeriods, conStatCaptureDays, conStatCapturePeriods, conStatCensusDays, conStatCensusPeriods)
          '   For each season = conSummer
          '     Total = dblStatSeasonYearPeriod(intStat, intSeason, intYearTotal_MAPS_PreviousYears, intPeriodTotal) = Sum over previous MAPS years and periods of dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriod)
          '     Count = Count the previous MAPS year x periods where dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriod) > 0
          '     Mean = dblStatSeasonYearPeriod(intStat, intSeason, intYearMean_PreviousYears, intPeriodMean) = Total / Count
          
          ' Total and mean of year x period statistic over all previous years and periods
          ' -----------------------------------------------------------------------------
          ' For each statistic in (conStatDETDays, conStatDETPeriods, conStatCaptureDays, conStatCapturePeriods, conStatCensusDays, conStatCensusPeriods)
          '   For each season
          '     Total = dblStatSeasonYearPeriod(intStat, intSeason, intYearTotal_PreviousYears, intPeriodTotal) = Sum over previous years and periods of dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriod)
          '     Count = Count the previous year x periods where dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriod) > 0
          '     Mean = dblStatSeasonYearPeriod(intStat, intSeason, intYearMean_PreviousYears, intPeriodMean) = Total / Count
          '
          '                                         intPeriodMean   intPeriodTotal   intPeriodSeason
          '                                 +--+--+---------------+----------------+-----------------+
          '                                 |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          '                                 |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearMean                     |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearTotal                    |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearSeason                   |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearMean_PreviousYears       |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearTotal_PreviousYears      |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearMean_MAPS_PreviousYears  |  |  |     xx        |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearTotal_MAPS_PreviousYears |  |  |               |      xx        |                 |
          '                                 +--+--+---------------+----------------+-----------------+

          
1010      If intYearLast > intYearFirst_MAPS Then
1020              intSeason = conSummer
1030              dblValue = 0
1040              intCount = 0
1050              For intYear = intYearFirst_MAPS To intYearLast - 1
1060                  For intPeriod = 1 To intPeriodLast_SeasonYear(intSeason, intYear)
1070                      dblValue = dblValue + dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriod)
1080                      If dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriod) > 0 Then intCount = intCount + 1
1090                  Next
1100              Next
1110              dblStatSeasonYearPeriod(intStat, intSeason, intYearTotal_MAPS_PreviousYears, intPeriodTotal) = dblValue
1120              If intCount > 0 Then
1130                  dblStatSeasonYearPeriod(intStat, intSeason, intYearMean_MAPS_PreviousYears, intPeriodMean) = dblValue / intCount
1140              End If
1150      End If

1160  Case Else

          ' Total and mean over periods
          ' ---------------------------
          '                                         intPeriodMean   intPeriodTotal   intPeriodSeason
          '                                 +--+--+---------------+----------------+-----------------+
          '                                 |  |  |      xx       |     xx         |      xx         |
          '                                 +--+--+---------------+----------------+-----------------+
          '                                 |  |  |      xx       |     xx         |      xx         |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearMean                     |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearTotal                    |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearSeason                   |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearMean_PreviousYears       |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearTotal_PreviousYears      |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearMean_MAPS_PreviousYears  |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearTotal_MAPS_PreviousYears |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+

          
1170      For intSeason = intSeasonFirst To intSeasonLast
1180          For intYear = intYearFirst To intYearLast
1190              dblValue = 0
1200              For intPeriod = 1 To intPeriodLast_SeasonYear(intSeason, intYear)
1210                  dblValue = dblValue + dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriod)
1220              Next
1230              dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriodTotal) = dblValue
1240              If fCopyToSeason Then
1250                  dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriodSeason) = dblValue
1260              End If
1270              Select Case intStat
                  Case conStatDETSpecies, conStatDETBirds, conStatDETMeanBirds
1280                  intCount = dblStatSeasonYearPeriod(conStatDETPeriods, intSeason, intYear, intPeriodTotal)
1290              Case conStatCensusSpecies
1300                  intCount = dblStatSeasonYearPeriod(conStatCensusPeriods, intSeason, intYear, intPeriodTotal)
1310              Case Else
1320                  intCount = dblStatSeasonYearPeriod(conStatCapturePeriods, intSeason, intYear, intPeriodTotal)
1330              End Select
1340              If intCount > 0 Then
1350                  dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriodMean) = dblValue / intCount
1360              End If
1370          Next
1380      Next
          
          ' Total and mean over years
          ' -------------------------
          ' For each statistic NOT in (conStatDETDays, conStatDETPeriods, conStatCaptureDays, conStatCapturePeriods, conStatCensusDays, conStatCensusPeriods)
          '   For each season
          '     For each period of the season
          '       Sum the stats for season x period x year over all years
          '       Store the sum in dblStatSeasonYearPeriod(intStat, intSeason, intYearTotal, intPeriod)
          '       Compute the mean
          '         For DET statistics divide the sum by the number of years where DET was recorded
          '         For Census statistics divide the sum by the number of years where census took place
          '         Otherwise divide the sum by the number of years where captures took place
          
          ' Total and mean over periods
          ' ---------------------------
          '                                         intPeriodMean   intPeriodTotal   intPeriodSeason
          '                                 +--+--+---------------+----------------+-----------------+
          '                                 |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          '                                 |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearMean                     |xx|xx|               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearTotal                    |xx|xx|               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearSeason                   |xx|xx|               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearMean_PreviousYears       |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearTotal_PreviousYears      |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearMean_MAPS_PreviousYears  |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearTotal_MAPS_PreviousYears |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+

          
1390      For intSeason = intSeasonFirst To intSeasonLast
1400          For intPeriod = 1 To intPeriodLast_Season(intSeason)
1410              dblValue = 0
1420              For intYear = intYearFirst To intYearLast
1430                  dblValue = dblValue + dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriod)
1440              Next
1450              dblStatSeasonYearPeriod(intStat, intSeason, intYearTotal, intPeriod) = dblValue
1460              If fCopyToSeason Then
1470                  dblStatSeasonYearPeriod(intStat, intSeason, intYearSeason, intPeriod) = dblValue
1480              End If
1490              Select Case intStat
                  Case conStatDETSpecies, conStatDETBirds, conStatDETMeanBirds
1500                  intCount = dblStatSeasonYearPeriod(conStatDETPeriods, intSeason, intYearTotal, intPeriod)
1510              Case conStatCensusSpecies
1520                  intCount = dblStatSeasonYearPeriod(conStatCensusPeriods, intSeason, intYearTotal, intPeriod)
1530              Case Else
1540                  intCount = dblStatSeasonYearPeriod(conStatCapturePeriods, intSeason, intYearTotal, intPeriod)
1550              End Select
1560              If intCount > 0 Then
1570                  dblStatSeasonYearPeriod(intStat, intSeason, intYearMean, intPeriod) = dblValue / intCount
1580              End If
1590          Next
1600      Next
          
          ' Total and mean over year x period
          ' ---------------------------------
          ' For each statistic NOT in (conStatDETDays, conStatDETPeriods, conStatCaptureDays, conStatCapturePeriods, conStatCensusDays, conStatCensusPeriods)
          '   For each season
          '     Sum = dblStatSeasonYearPeriod(intStat, intSeason, intYearTotal, intPeriodTotal) = sum the stat for season x period x year over all years and periods
          '     Count = dblStatSeasonYearPeriod(conStatDETPeriods, intSeason, intYearTotal, intPeriodTotal for DET statistics
          '           = dblStatSeasonYearPeriod(conStatCensusPeriods, intSeason, intYearTotal, intPeriodTotal) for Census statistics
          '           = dblStatSeasonYearPeriod(conStatCapturePeriods, intSeason, intYearTotal, intPeriodTotal) for Capture statistics
          '     Mean = dblStatSeasonYearPeriod(intStat, intSeason, intYearMean, intPeriodMean) = Sum / Count
          '
          '                                         intPeriodMean   intPeriodTotal   intPeriodSeason
          '                                 +--+--+---------------+----------------+-----------------+
          '                                 |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          '                                 |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearMean                     |  |  |     xx        |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearTotal                    |  |  |               |      xx        |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearSeason                   |  |  |               |                |       xx        |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearMean_PreviousYears       |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearTotal_PreviousYears      |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearMean_MAPS_PreviousYears  |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearTotal_MAPS_PreviousYears |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+

          
1610      For intSeason = intSeasonFirst To intSeasonLast
1620          dblValue = 0
1630          For intYear = intYearFirst To intYearLast
1640            For intPeriod = 1 To intPeriodLast_SeasonYear(intSeason, intYear)
1650                dblValue = dblValue + dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriod)
1660            Next
1670          Next
1680          dblStatSeasonYearPeriod(intStat, intSeason, intYearTotal, intPeriodTotal) = dblValue
1690          If fCopyToSeason Then
1700              dblStatSeasonYearPeriod(intStat, intSeason, intYearSeason, intPeriodSeason) = dblValue
1710          End If
1720          Select Case intStat
              Case conStatDETBirds, conStatDETSpecies, conStatDETMeanBirds
1730              intCount = dblStatSeasonYearPeriod(conStatDETPeriods, intSeason, intYearTotal, intPeriodTotal)
1740          Case conStatCensusSpecies
1750              intCount = dblStatSeasonYearPeriod(conStatCensusPeriods, intSeason, intYearTotal, intPeriodTotal)
1760          Case Else
1770              intCount = dblStatSeasonYearPeriod(conStatCapturePeriods, intSeason, intYearTotal, intPeriodTotal)
1780          End Select
1790          If intCount > 0 Then
1800              dblStatSeasonYearPeriod(intStat, intSeason, intYearMean, intPeriodMean) = dblValue / intCount
1810          End If
1820      Next
          
          ' Total and mean over previous years
          ' ----------------------------------
          ' For each statistic NOT in (conStatDETDays, conStatDETPeriods, conStatCaptureDays, conStatCapturePeriods, conStatCensusDays, conStatCensusPeriods)
          '   For each season
          '     For each period of the season
          '       Sum the stats for season x period x year over all previous years
          '       Store the sum in dblStatSeasonYearPeriod(intStat, intSeason, intYearTotal_PreviousYears, intPeriod)
          '       Compute the mean
          '         For DET statistics divide the sum by the number of years where DET was recorded
          '         For Census statistics divide the sum by the number of years where census took place
          '         Otherwise divide the sum by the number of years where captures took place
          '
          '                                         intPeriodMean   intPeriodTotal   intPeriodSeason
          '                                 +--+--+---------------+----------------+-----------------+
          '                                 |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          '                                 |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearMean                     |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearTotal                    |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearSeason                   |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearMean_PreviousYears       |xx|xx|               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearTotal_PreviousYears      |xx|xx|               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearMean_MAPS_PreviousYears  |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearTotal_MAPS_PreviousYears |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+

          
1830      If intYearLast > intYearFirst Then
1840          For intSeason = intSeasonFirst To intSeasonLast
1850              For intPeriod = 1 To intPeriodLast_Season(intSeason)
1860                  dblValue = 0
1870                  For intYear = intYearFirst To intYearLast - 1
1880                      dblValue = dblValue + dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriod)
1890                  Next
1900                  dblStatSeasonYearPeriod(intStat, intSeason, intYearTotal_PreviousYears, intPeriod) = dblValue
          '            If fCopyToSeason Then
          '                dblStatSeasonYearPeriod(intStat, intSeason, intYearSeason, intPeriod) = dblValue
          '            End If
1910                  Select Case intStat
                      Case conStatDETSpecies, conStatDETBirds, conStatDETMeanBirds
1920                      intCount = dblStatSeasonYearPeriod(conStatDETPeriods, intSeason, intYearTotal_PreviousYears, intPeriod)
1930                  Case conStatCensusSpecies
1940                      intCount = dblStatSeasonYearPeriod(conStatCensusPeriods, intSeason, intYearTotal_PreviousYears, intPeriod)
1950                  Case Else
1960                      intCount = dblStatSeasonYearPeriod(conStatCapturePeriods, intSeason, intYearTotal_PreviousYears, intPeriod)
1970                  End Select
1980                  If intCount > 0 Then
1990                      dblStatSeasonYearPeriod(intStat, intSeason, intYearMean_PreviousYears, intPeriod) = dblValue / intCount
2000                  End If
2010              Next
2020          Next
2030      End If
          
          ' Summer only ---
          ' Total and mean over previous MAPS years
          ' ----------------------------------
          ' For each statistic NOT in (conStatDETDays, conStatDETPeriods, conStatCaptureDays, conStatCapturePeriods, conStatCensusDays, conStatCensusPeriods)
          '   For Summer
          '     For each period of the season
          '       Sum the stats for season x period x year over all previous MAPS years
          '       Store the sum in dblStatSeasonYearPeriod(intStat, intSeason, intYearTotal_MAPS_PreviousYears, intPeriod)
          '       Compute the mean
          '         For DET statistics divide the sum by the number of MAPS years where DET was recorded
          '         For Census statistics divide the sum by the number of MAPS years where census took place
          '         Otherwise divide the sum by the number of MAPS years where captures took place
          '
          '                                         intPeriodMean   intPeriodTotal   intPeriodSeason
          '                                 +--+--+---------------+----------------+-----------------+
          '                                 |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          '                                 |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearMean                     |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearTotal                    |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearSeason                   |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearMean_PreviousYears       |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearTotal_PreviousYears      |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearMean_MAPS_PreviousYears  |xx|xx|               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearTotal_MAPS_PreviousYears |xx|xx|               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+

          
2040      If intYearLast > intYearFirst_MAPS Then
2050              intSeason = conSummer
2060              For intPeriod = 1 To intPeriodLast_Season(intSeason)
2070                  dblValue = 0
2080                  For intYear = intYearFirst_MAPS To intYearLast - 1
2090                      dblValue = dblValue + dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriod)
2100                  Next
2110                  dblStatSeasonYearPeriod(intStat, intSeason, intYearTotal_MAPS_PreviousYears, intPeriod) = dblValue
2120                  Select Case intStat
                      Case conStatDETSpecies, conStatDETBirds, conStatDETMeanBirds
2130                      intCount = dblStatSeasonYearPeriod(conStatDETPeriods, intSeason, intYearTotal_MAPS_PreviousYears, intPeriod)
2140                  Case conStatCensusSpecies
2150                      intCount = dblStatSeasonYearPeriod(conStatCensusPeriods, intSeason, intYearTotal_MAPS_PreviousYears, intPeriod)
2160                  Case Else
2170                      intCount = dblStatSeasonYearPeriod(conStatCapturePeriods, intSeason, intYearTotal_MAPS_PreviousYears, intPeriod)
2180                  End Select
2190                  If intCount > 0 Then
2200                      dblStatSeasonYearPeriod(intStat, intSeason, intYearMean_MAPS_PreviousYears, intPeriod) = dblValue / intCount
2210                  End If
2220              Next
2230      End If
          
          
          ' Total and mean over previous year x period
          ' ------------------------------------------
          ' For each statistic NOT in (conStatDETDays, conStatDETPeriods, conStatCaptureDays, conStatCapturePeriods, conStatCensusDays, conStatCensusPeriods)
          '   For each season
          '     Sum = dblStatSeasonYearPeriod(intStat, intSeason, intYearTotal_PreviousYears, intPeriodTotal) = sum the stat for season x period x year over all years and periods
          '     Count = dblStatSeasonYearPeriod(conStatDETPeriods, intSeason, intYearTotal_PreviousYears, intPeriodTotal for DET statistics
          '           = dblStatSeasonYearPeriod(conStatCensusPeriods, intSeason, intYearTotal_PreviousYears, intPeriodTotal) for Census statistics
          '           = dblStatSeasonYearPeriod(conStatCapturePeriods, intSeason, intYearTotal_PreviousYears, intPeriodTotal) for Capture statistics
          '     Mean = dblStatSeasonYearPeriod(intStat, intSeason, intYearMean_PreviousYears, intPeriodMean) = Sum / Count
          '
          '                                         intPeriodMean   intPeriodTotal   intPeriodSeason
          '                                 +--+--+---------------+----------------+-----------------+
          '                                 |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          '                                 |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearMean                     |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearTotal                    |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearSeason                   |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearMean_PreviousYears       |  |  |      xx       |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearTotal_PreviousYears      |  |  |               |      xx        |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearMean_MAPS_PreviousYears  |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearTotal_MAPS_PreviousYears |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+

          
2240      If intYearLast > intYearFirst Then
2250          For intSeason = intSeasonFirst To intSeasonLast
2260              dblValue = 0
2270              For intYear = intYearFirst To intYearLast - 1
2280                For intPeriod = 1 To intPeriodLast_SeasonYear(intSeason, intYear)
2290                    dblValue = dblValue + dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriod)
2300                Next
2310              Next
2320              dblStatSeasonYearPeriod(intStat, intSeason, intYearTotal_PreviousYears, intPeriodTotal) = dblValue
          '        If fCopyToSeason Then
          '            dblStatSeasonYearPeriod(intStat, intSeason, intYearSeason, intPeriodSeason) = dblValue
          '        End If
2330              Select Case intStat
                  Case conStatDETBirds, conStatDETSpecies, conStatDETMeanBirds
2340                  intCount = dblStatSeasonYearPeriod(conStatDETPeriods, intSeason, intYearTotal_PreviousYears, intPeriodTotal)
2350              Case conStatCensusSpecies
2360                  intCount = dblStatSeasonYearPeriod(conStatCensusPeriods, intSeason, intYearTotal_PreviousYears, intPeriodTotal)
2370              Case Else
2380                  intCount = dblStatSeasonYearPeriod(conStatCapturePeriods, intSeason, intYearTotal_PreviousYears, intPeriodTotal)
2390              End Select
2400              If intCount > 0 Then
2410                  dblStatSeasonYearPeriod(intStat, intSeason, intYearMean_PreviousYears, intPeriodMean) = dblValue / intCount
2420              End If
2430          Next
2440      End If
          
          ' Summer only ---
          ' Total and mean over previous MAPS year x period
          ' ------------------------------------------
          ' For each statistic NOT in (conStatDETDays, conStatDETPeriods, conStatCaptureDays, conStatCapturePeriods, conStatCensusDays, conStatCensusPeriods)
          '   For each season
          '     Sum = dblStatSeasonYearPeriod(intStat, intSeason, intYearTotal_PreviousYears, intPeriodTotal) = sum the stat for season x period x year over all years and periods
          '     Count = dblStatSeasonYearPeriod(conStatDETPeriods, intSeason, intYearTotal_PreviousYears, intPeriodTotal for DET statistics
          '           = dblStatSeasonYearPeriod(conStatCensusPeriods, intSeason, intYearTotal_PreviousYears, intPeriodTotal) for Census statistics
          '           = dblStatSeasonYearPeriod(conStatCapturePeriods, intSeason, intYearTotal_PreviousYears, intPeriodTotal) for Capture statistics
          '     Mean = dblStatSeasonYearPeriod(intStat, intSeason, intYearMean_PreviousYears, intPeriodMean) = Sum / Count
          '
          '                                         intPeriodMean   intPeriodTotal   intPeriodSeason
          '                                 +--+--+---------------+----------------+-----------------+
          '                                 |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          '                                 |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearMean                     |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearTotal                    |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearSeason                   |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearMean_PreviousYears       |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearTotal_PreviousYears      |  |  |               |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearMean_MAPS_PreviousYears  |  |  |     xx        |                |                 |
          '                                 +--+--+---------------+----------------+-----------------+
          ' intYearTotal_MAPS_PreviousYears |  |  |               |        xx      |                 |
          '                                 +--+--+---------------+----------------+-----------------+

          
2450      If intYearLast > intYearFirst_MAPS Then
2460              intSeason = conSummer
2470              dblValue = 0
2480              For intYear = intYearFirst_MAPS To intYearLast - 1
2490                For intPeriod = 1 To intPeriodLast_SeasonYear(intSeason, intYear)
2500                    dblValue = dblValue + dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriod)
2510                Next
2520              Next
2530              dblStatSeasonYearPeriod(intStat, intSeason, intYearTotal_MAPS_PreviousYears, intPeriodTotal) = dblValue
2540              Select Case intStat
                  Case conStatDETBirds, conStatDETSpecies, conStatDETMeanBirds
2550                  intCount = dblStatSeasonYearPeriod(conStatDETPeriods, intSeason, intYearTotal_MAPS_PreviousYears, intPeriodTotal)
2560              Case conStatCensusSpecies
2570                  intCount = dblStatSeasonYearPeriod(conStatCensusPeriods, intSeason, intYearTotal_MAPS_PreviousYears, intPeriodTotal)
2580              Case Else
2590                  intCount = dblStatSeasonYearPeriod(conStatCapturePeriods, intSeason, intYearTotal_MAPS_PreviousYears, intPeriodTotal)
2600              End Select
2610              If intCount > 0 Then
2620                  dblStatSeasonYearPeriod(intStat, intSeason, intYearMean_MAPS_PreviousYears, intPeriodMean) = dblValue / intCount
2630              End If
2640      End If

2650   End Select

      'DD Error Handler Start
Exit_label:
2660       Exit Sub
Err_label:
2670       Select Case Err.Number
           Case Else
2680      Call LogError("basMBOProgramReport_SeasonYearPeriod", "MBOProgramReport_SeasonYearPeriod_TotalMean")
2690       End Select
2700       Resume Exit_label
      'DD Error Handler End
End Sub


'' ------------------------------------------------------
'' MBOProgramReport_Season_Count_Capture_DET_Census_Years
'' ------------------------------------------------------
'' For each season
'' Count the CaptureYears, DETYears, CensusYears
'' over all years, all previous years, all previous MAPS years
''
'' A season year is a CaptureYear if it it had any capture days
'' Similarly for DETYear and CensusYear
''
'' Store the count in dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriodSeason)
'' where intStat = intStatCaptureYears, intStatDETYears, intStatCensusYears
'' where intYear = intYearTotal, intYearTotal_Previous_Years, intYearTotal_MAPS_PreviousYears
''
'' PRE: dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriod) must already be filled in for each intSeason x intYear x intPeriod, stat in (conCaptureDays, conDETDays, conCensusDays)
''
'
'Private Sub MBOProgramReport_Season_Count(ByVal intYearFirst As Integer, ByVal intYearLast As Integer)
'
'
'arrStatYears = Array(conCaptureYears, conDETYears, conCensusYears)
'arrStatDays = Array(conCaptureDays, conDETDays, conCensusDays)
'
'For i = 0 To 2
'
'    For intSeason = intSeasonFirst To intSeasonLast
'        count = 0
'        For intYear = intYearFirst To intYearLast
'            increment = 0
'            For intPeriod = 1 To intPeriodLast_SeasonYear(intSeason, intYear)
'                If dblStatSeasonYearPeriod(arrStatDays(i), intSeason, intYear, intPeriod) > 0 Then
'                    increment = 1
'                    Exit For
'                End If
'            Next
'            count = count + increment
'        Next
'        dblStatSeasonYearPeriod(arrStatYears(i), intSeason, intYearTotal, intPeriodSeason) = count
'    Next
'
'    For intSeason = intSeasonFirst To intSeasonLast - 1
'        count = 0
'        For intYear = intYearFirst To intYearLast
'            increment = 0
'            For intPeriod = 1 To intPeriodLast_SeasonYear(intSeason, intYear)
'                If dblStatSeasonYearPeriod(arrStatDays(i), intSeason, intYear, intPeriod) > 0 Then
'                    increment = 1
'                    Exit For
'                End If
'            Next
'            count = count + increment
'        Next
'        dblStatSeasonYearPeriod(arrStatYears(i), intSeason, intYearTotal_PreviousYears, intPeriodSeason) = count
'    Next
'
'    intSeason = conSummer
'    count = 0
'    For intYear = intYearFirst_MAPS To intYearLast - 1
'        increment = 0
'        For intPeriod = 1 To intPeriodLast_SeasonYear(intSeason, intYear)
'            If dblStatSeasonYearPeriod(arrStatDays(i), intSeason, intYear, intPeriod) > 0 Then
'                increment = 1
'                Exit For
'            End If
'        Next
'        count = count + increment
'    Next
'    dblStatSeasonYearPeriod(arrStatYears(i), intSeason, intYearTotal_MAPS_PreviousYears, intPeriodSeason) = count
'
'End Sub
'

'---------------------------------------------------------------------------------------
' MBOProgramReport_Season_TotalMean
'---------------------------------------------------------------------------------------
' Compute the totals and means for the intPeriodSeason column
'
' PRE dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriodSeason) have been filled in
'
' We are going to fill in the following elements of dblStatSeasonYearPeriod(intStat, intSeason, intYearEXTRA, intPeriodSeason)
'                                                                                               ------------
'
'                                         intPeriodMean   intPeriodTotal   intPeriodSeason
'                                 +--+--+---------------+----------------+-----------------+
'                                 |  |  |               |                |                 |
'                                 +--+--+---------------+----------------+-----------------+
'                                 |  |  |               |                |                 |
'                                 +--+--+---------------+----------------+-----------------+
' intYearMean                     |  |  |               |                |      xx         |
'                                 +--+--+---------------+----------------+-----------------+
' intYearTotal                    |  |  |               |                |      xx         |
'                                 +--+--+---------------+----------------+-----------------+
' intYearSeason                   |  |  |               |                |                 |
'                                 +--+--+---------------+----------------+-----------------+
' intYearMean_PreviousYears       |  |  |               |                |      xx         |
'                                 +--+--+---------------+----------------+-----------------+
' intYearTotal_PreviousYears      |  |  |               |                |      xx         |
'                                 +--+--+---------------+----------------+-----------------+
' intYearMean_MAPS_PreviousYears  |  |  |               |                |      xx         |
'                                 +--+--+---------------+----------------+-----------------+
' intYearTotal_MAPS_PreviousYears |  |  |               |                |      xx         |
'                                 +--+--+---------------+----------------+-----------------+
'
' dblStatSeasonYearPeriod(intStat, intSeason, intYearMean, intPeriodSeason)
' dblStatSeasonYearPeriod(intStat, intSeason, intYearTotal, intPeriodSeason)

' dblStatSeasonYearPeriod(intStat, intSeason, intYearMean_PreviousYears, intPeriodSeason)
' dblStatSeasonYearPeriod(intStat, intSeason, intYearTotal_PreviousYears, intPeriodSeason)

' dblStatSeasonYearPeriod(intStat, conSummer, intYearMean_MAPS_PreviousYears, intPeriodSeason)      for MAPS only
' dblStatSeasonYearPeriod(intStat, conSummer, intYearTotal_MAPS_PreviousYears, intPeriodSeason)     for MAPS only

Private Sub MBOProgramReport_Season_TotalMean( _
    ByVal intStat As Integer, _
    ByVal intYearFirst As Integer, _
    ByVal intYearLast As Integer, _
    ByVal strLocation As String)
          
10    On Error GoTo Err_label

      Dim intSeason As Integer
      Dim intYear As Integer
      Dim intPeriod As Integer
      Dim dblValue As Double
      Dim intCount As Integer

      ' For a given season, consider the conBandedBirds statistic for each year.  When I calculate the mean over all years
      ' I will divide the sum of the conBandedBirds statistics for each year by the number of years in which any birds were banded.
      ' If we have already filled in all the "All Periods" columns (for the years), then we already know how many Capture periods were in each year
      ' So the divisor is the count of non-zero conCapturePeriods

      ' Similarly for the conDETSpecies statistic, I will divide the sum of the annual conDETSpecies statistics by the number of years that had any DET days

      ' For each season, I need the following divisors
      '     the number of years with any capture days
      '     the number of years with any DET days
      '     the number of years with any Census days

      ' The following is already available
      ' ----------------------------------
      ' For a given season,
      '     intCapturesYearsCountSeason(intSeason)                = the count of Capture Years over all years
      '     intCapturesYears_PreviousYears_CountSeason(intSeason) = the count of Capture Years over previous years
      '     intDETYearsCountSeason(intSeason)                     = the count of DET Years over all years
      '     intDETYears_PreviousYears_CountSeason(intSeason)      = the count of DET Years over previous years
      '     intCensusYearsCountSeason(intSeason)                  = the count of DET Years over all years
      '     intCensusYears_PreviousYears_CountSeason(intSeason)   = the count of DET Years over previous years

      ' intCapturesYears_MAPS_PreviousYears_Count          = the count of Capture Years over previous MAPS years
      ' intDETYears_MAPS_PreviousYears_Count              = the count of DET Years over previous MAPS years
      ' intCensusYears_MAPS_PreviousYears_Count             = the count of DET Years over previous MAPS years


      'Select Case intStat
      'Case conStatDETDays, conStatDETPeriods, conStatCaptureDays, conStatCapturePeriods, conStatCensusDays, conStatCensusPeriods
      '
      '
      '    For intSeason = intSeasonFirst To intSeasonLast
      '
      '        dblValue = 0
      '        intCount = 0
      '        For intYear = intYearFirst To intYearLast
      '            dblValue = dblValue + dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriodSeason)
      '            If dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriodSeason) > 0 Then intCount = intCount + 1
      '        Next
      '        dblStatSeasonYearPeriod(intStat, intSeason, intYearTotal, intPeriodSeason) = dblValue
      '        If intCount > 0 Then
      '            dblStatSeasonYearPeriod(intStat, intSeason, intYearMean, intPeriodSeason) = dblValue / intCount
      '        End If
      '
      '        dblValue = 0
      '        intCount = 0
      '        For intYear = intYearFirst To intYearLast - 1
      '            dblValue = dblValue + dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriodSeason)
      '            If dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriodSeason) > 0 Then intCount = intCount + 1
      '        Next
      '        dblStatSeasonYearPeriod(intStat, intSeason, intYearTotal_PreviousYears, intPeriodSeason) = dblValue
      '        If intCount > 0 Then
      '            dblStatSeasonYearPeriod(intStat, intSeason, intYearMean_PreviousYears, intPeriodSeason) = dblValue / intCount
      '        End If
      '
      '    Next
      '
      '    ' Summer only ---
      '
      '    If intYearLast > intYearFirst_MAPS Then
      '        dblValue = 0
      '        intCount = 0
      '        For intYear = intYearFirst_MAPS To intYearLast - 1
      '            dblValue = dblValue + dblStatSeasonYearPeriod(intStat, conSummer, intYear, intPeriod)
      '            If dblStatSeasonYearPeriod(intStat, conSummer, intYear, intPeriod) > 0 Then intCount = intCount + 1
      '        Next
      '        dblStatSeasonYearPeriod(intStat, conSummer, intYearTotal_MAPS_PreviousYears, intPeriod) = dblValue
      '        If intCount > 0 Then
      '            dblStatSeasonYearPeriod(intStat, conSummer, intYearMean_MAPS_PreviousYears, intPeriod) = dblValue / intCount
      '        End If
      '
      '    End If
      '
      'Case Else
          
20        If intYearLast >= intYearFirst Then
30            For intSeason = intSeasonFirst To intSeasonLast
                      
40                dblValue = 0
50                For intYear = intYearFirst To intYearLast
60                    dblValue = dblValue + dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriodSeason)
70                Next
80                dblStatSeasonYearPeriod(intStat, intSeason, intYearTotal, intPeriodSeason) = dblValue
90                Select Case intStat
                  Case conStatDETDays, conStatDETPeriods, conStatDETSpecies, conStatDETBirds, conStatDETMeanBirds
100                   intCount = intDETYearsCountSeason(intSeason)
110               Case conStatCensusSpecies, conStatCensusPeriods, conStatCensusDays
120                   intCount = intCensusYearsCountSeason(intSeason)
130               Case Else
140                   intCount = intCapturesYearsCountSeason(intSeason)
150               End Select
160               If intCount > 0 Then
170                   dblStatSeasonYearPeriod(intStat, intSeason, intYearMean, intPeriodSeason) = dblValue / intCount
180               End If
190           Next
200       End If
          
210       If intYearLast > intYearFirst Then
220           For intSeason = intSeasonFirst To intSeasonLast
                  
230               dblValue = 0
240               For intYear = intYearFirst To intYearLast - 1
250                   dblValue = dblValue + dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriodSeason)
260               Next
270               dblStatSeasonYearPeriod(intStat, intSeason, intYearTotal_PreviousYears, intPeriodSeason) = dblValue
280               Select Case intStat
                  Case conStatDETDays, conStatDETPeriods, conStatDETSpecies, conStatDETBirds, conStatDETMeanBirds
290                   intCount = intDETYears_PreviousYears_CountSeason(intSeason)
300               Case conStatCensusSpecies, conStatCensusPeriods, conStatCensusDays
310                   intCount = intCensusYears_PreviousYears_CountSeason(intSeason)
320               Case Else
330                   intCount = intCapturesYears_PreviousYears_CountSeason(intSeason)
340               End Select
350               If intCount > 0 Then
360                   dblStatSeasonYearPeriod(intStat, intSeason, intYearMean_PreviousYears, intPeriodSeason) = dblValue / intCount
370               End If

380           Next
390       End If
          
          ' Summer only ---
          
400       If intYearLast > intYearFirst_MAPS Then
410           dblValue = 0
420           For intYear = intYearFirst_MAPS To intYearLast - 1
430               dblValue = dblValue + dblStatSeasonYearPeriod(intStat, conSummer, intYear, intPeriodSeason)
440           Next
450           dblStatSeasonYearPeriod(intStat, conSummer, intYearTotal_MAPS_PreviousYears, intPeriodSeason) = dblValue
460           Select Case intStat
              Case conStatDETDays, conStatDETPeriods, conStatDETSpecies, conStatDETBirds, conStatDETMeanBirds
470               intCount = intDETYears_MAPS_PreviousYears_Count
480           Case conStatCensusSpecies, conStatCensusPeriods, conStatCensusDays
490               intCount = intCensusYears_MAPS_PreviousYears_Count
500           Case Else
510               intCount = intCapturesYears_MAPS_PreviousYears_Count
520           End Select
530           If intCount > 0 Then
540               dblStatSeasonYearPeriod(intStat, conSummer, intYearMean_MAPS_PreviousYears, intPeriodSeason) = dblValue / intCount
550           End If
560       End If
          

      ' End Select

      'DD Error Handler Start
Exit_label:
570        Exit Sub
Err_label:
580        Select Case Err.Number
           Case Else
590       Call LogError("basMBOProgramReport_SeasonYearPeriod", "MBOProgramReport_SeasonYearPeriod_TotalMean")
600        End Select
610        Resume Exit_label
      'DD Error Handler End
End Sub




'---------------------------------------------------------------------------------------
' MBOAnnualProgramReport_SeasonYearPeriod_Excel
'---------------------------------------------------------------------------------------
' "year" always refers to monitoring program season within a report year
'
' cell(year, period) reports stat[year, period] = the statistic for a given year x period.

' cell(year, "All periods") reports stat[year = the statistic for a given year, measured over all periods
' cell("All Years", period) reports stat[period] = the statistic for a given period, measured over all years
' cell("All Years", "All Periods") reports stat[] = the statistic, measured over all periods and all years

' cell(year, "Mean") = reports mean_over_periods[year] = for a given year, the mean, over all periods of stat[year, period]
' cell("Mean over previous years", period) reports mean_over_previous_years[period] = for a given period, the mean over all previous years of stat[year,period]
' cell("Mean over all years", period) reports mean_over_all_years[period] = for a given period, the mean over all years of stat[year,period]

' cell("Mean over previous years", "All Periods"] reports mean_over_previous_years[] = the mean over all previous years of stat[year]
' cell("Mean over all years", "All Periods"] reports mean_over_all_years[] = the mean over all years of stat[year]
' cell("All Years", "Mean"] reports mean_over_all_periods[] = the mean over all periods of stat[period]


Private Sub MBOProgramReport_SeasonYearPeriod_Excel( _
ByVal intYearFirst As Integer, _
ByVal intYearLast As Integer, _
ByVal strLocation As String, _
ByRef oBook As Excel.Workbook, _
ByRef oSheet As Excel.Worksheet, _
ByVal rowBase As Long, _
ByVal colBase As Long, _
ByRef rowsUsed As Long, _
ByVal intStat As Integer, ByVal strStat As String, _
ByVal intSeason As Integer)

Dim strSQL As String
Dim qdf As DAO.QueryDef
Dim rst As DAO.Recordset
Dim intYear As Integer
Dim intPeriod As Integer
Dim fld As Integer
Dim strSeason As String

Dim colYear As Long
Dim colPeriodFirst As Long
Dim colPeriodLast As Long
Dim colPeriodTotal As Long
Dim colPeriodMean As Long
Dim colPeriodSeason As Long

Dim fCumulativeStatistic As Boolean
fCumulativeStatistic = IsCumulativeStat(intStat)

' Do not generate cumulative statistics for Summer or Nestbox

If fCumulativeStatistic Then
    Select Case intSeason
    Case conWinter, conSpring, conFall, conOwling
    Case Else
      rowsUsed = 0
      GoTo Exit_label
    End Select
    End If

Dim lngNAColour As Long
lngNAColour = RGB(246, 222, 246)

On Error GoTo Err_label

colYear = colBase
colPeriodFirst = colYear + 1
colPeriodLast = colPeriodFirst + intPeriodLast - 1
colPeriodTotal = colPeriodLast + 1
colPeriodMean = colPeriodLast + 2
colPeriodSeason = colPeriodLast + 3

SysCmd acSysCmdSetStatus, "Season x Year x Period : " & toStrSeasonFromIntSeason(intSeason) & " => Excel"

Dim row As Long
Dim col As Long

With oSheet

row = rowBase

' Title row

If fCumulativeStatistic Then
    .Cells(row, colYear) = strStat
    .range(.Cells(row, colYear), .Cells(row, colPeriodFirst)).Interior.Color = vbYellow
     .range(.Cells(row + 1, colYear), .Cells(row + 1, colPeriodLast)).Interior.Color = RGB(240, 240, 240)
    .range(.Cells(row, colYear), .Cells(row, colPeriodFirst)).Font.Size = 9
    .range(.Cells(row, colYear), .Cells(row, colPeriodLast)).Merge
Else
    .Cells(row, colYear) = toStrSeasonFromIntSeason(intSeason) & " - " & strStat
    .range(.Cells(row, colYear), .Cells(row, colPeriodSeason)).Interior.Color = vbYellow
    .range(.Cells(row + 1, colYear), .Cells(row + 1, colPeriodSeason)).Interior.Color = RGB(240, 240, 240)
    .range(.Cells(row, colYear), .Cells(row, colPeriodFirst)).Font.Size = 9
    .range(.Cells(row, colYear), .Cells(row, colPeriodSeason)).Merge
End If
row = row + 1

' Period headings

For intPeriod = 1 To intPeriodLast
    col = colPeriodFirst + intPeriod - 1
    If intPeriod <= intPeriodLast_Season(intSeason) Then
        .Cells(row, col) = intPeriod
    Else
        .Cells(row, col) = " "
    End If
Next

' If DisplayPeriodTotal_Column(intStat) Then .Cells(row, colPeriodTotal) = "Total"
If DisplayPeriodMean_Column(intStat) Then .Cells(row, colPeriodMean) = "Mean"
If DisplayPeriodSeason_Column(intStat) Then .Cells(row, colPeriodSeason) = "All Periods"

row = row + 1

For intYear = intYearFirst To intYearLast
    .Cells(row, colYear) = intYear
    row = row + 1
Next
    
'End If

If DisplayYearMean_Row(intStat) And intYearLast > intYearFirst Then
    .Cells(row, colYear) = "Mean " & intYearFirst & "-" & intYearLast - 1
    row = row + 1
End If


If intSeason = conSummer Then
    If DisplayYearMean_Row(intStat) And intYearLast > intYearFirst_MAPS Then
        .Cells(row, colYear) = "Mean " & intYearFirst_MAPS & "-" & intYearLast - 1
        row = row + 1
    End If
End If

If DisplayYearMean_Row(intStat) Then
    .Cells(row, colYear) = "Mean " & intYearFirst & "-" & intYearLast
    row = row + 1
End If

If DisplayYearSeason_Row(intStat) Then
    .Cells(row, colYear) = "All Years"
    row = row + 1
End If

row = rowBase + 2

If IsCumulativeStat(intStat) Then

    ' If the stat is a cumulative stat, we only report stat[year,period]
    ' We do NOT report any stat measured over all years or all periods
    ' We do NOT report any means

    ' Season x Year x Period
    
    For intYear = intYearFirst To intYearLast
        For intPeriod = 1 To intPeriodLast_SeasonYear(intSeason, intYear)
            col = colPeriodFirst + intPeriod - 1
            .Cells(row, col) = dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriod)
            If dblStatSeasonYearPeriod(intStat, intSeason, intYearMin, intPeriod) <> dblStatSeasonYearPeriod(intStat, intSeason, intYearMax, intPeriod) Then
                If dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriod) = dblStatSeasonYearPeriod(intStat, intSeason, intYearMax, intPeriod) Then
                    .Cells(row, col).Font.Color = vbRed
                ElseIf dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriod) = dblStatSeasonYearPeriod(intStat, intSeason, intYearMin, intPeriod) Then
                    .Cells(row, col).Font.Color = vbBlue
                End If
            End If
            If dblStatSeasonYearPeriod(getDaysStat(intStat), intSeason, intYear, intPeriod) = 0 Then .Cells(row, col).Interior.Color = lngNAColour
        Next
        row = row + 1
    Next
    
    ' format the data columns
    
    Select Case intStat
    Case conStatDETMeanBirdsCumulative, _
         conStatNetHoursCumulative, _
         conStatBirdsPer100NetHoursCumulative, conStatBirdsRETREPPer100NetHoursCumulative
        .range(.Cells(rowBase + 2, colPeriodFirst), .Cells(row - 1, colPeriodLast)).NumberFormat = "#0.0"
    Case conStatPercentBandedHatchYear, conStatPercentBandedHatchYearCumulative
        .range(.Cells(rowBase + 2, colPeriodFirst), .Cells(row - 1, colPeriodLast)).NumberFormat = "#0%"
    Case Else
        .range(.Cells(rowBase + 2, colPeriodFirst), .Cells(row - 1, colPeriodLast)).NumberFormat = "#0"
    End Select

Else

    ' cell(year, period) reports stat[year, period] = the statistic for a given year x period.

    For intYear = intYearFirst To intYearLast
            For intPeriod = 1 To intPeriodLast_SeasonYear(intSeason, intYear)
                col = colPeriodFirst + intPeriod - 1
                If dblStatSeasonYearPeriod(getDaysStat(intStat), intSeason, intYear, intPeriod) > 0 Then
                    .Cells(row, col) = dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriod)
                    If dblStatSeasonYearPeriod(intStat, intSeason, intYearMin, intPeriod) <> dblStatSeasonYearPeriod(intStat, intSeason, intYearMax, intPeriod) Then
                        If dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriod) = dblStatSeasonYearPeriod(intStat, intSeason, intYearMax, intPeriod) Then
                            .Cells(row, col).Font.Color = vbRed
                        ElseIf dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriod) = dblStatSeasonYearPeriod(intStat, intSeason, intYearMin, intPeriod) Then
                            .Cells(row, col).Font.Color = vbBlue
                        End If
                    End If
                Else
                    .Cells(row, col).Interior.Color = lngNAColour
                End If
            Next

        ' The "Mean" column
        ' cell(year, "Mean") = reports mean_over_periods[year] = for a given year, the mean, over all periods of stat[year, period]

        If DisplayPeriodMean_Column(intStat) Then
            col = colPeriodMean
            If dblStatSeasonYearPeriod(getDaysStat(intStat), intSeason, intYear, intPeriodMean) > 0 Then
                .Cells(row, col) = dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriodMean)
                If dblStatSeasonYearPeriod(intStat, intSeason, intYearMin, intPeriodMean) <> dblStatSeasonYearPeriod(intStat, intSeason, intYearMax, intPeriodMean) Then
                    If dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriodMean) = dblStatSeasonYearPeriod(intStat, intSeason, intYearMax, intPeriodMean) Then
                        .Cells(row, col).Font.Color = vbRed
                    ElseIf dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriodMean) = dblStatSeasonYearPeriod(intStat, intSeason, intYearMin, intPeriodMean) Then
                        .Cells(row, col).Font.Color = vbBlue
                    End If
                End If
            Else
                .Cells(row, col).Interior.Color = lngNAColour
            End If
        End If

        ' The "All Periods" column
        ' cell(year, "All periods") reports stat[year = the statistic for a given year, measured over all periods

        If DisplayPeriodSeason_Column(intStat) Then
            col = colPeriodSeason
            If dblStatSeasonYearPeriod(getDaysStat(intStat), intSeason, intYear, intPeriodSeason) > 0 Then
                .Cells(row, col) = dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriodSeason)
                If dblStatSeasonYearPeriod(intStat, intSeason, intYearMin, intPeriodSeason) <> dblStatSeasonYearPeriod(intStat, intSeason, intYearMax, intPeriodSeason) Then
                    If dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriodSeason) = dblStatSeasonYearPeriod(intStat, intSeason, intYearMax, intPeriodSeason) Then
                        .Cells(row, col).Font.Color = vbRed
                    ElseIf dblStatSeasonYearPeriod(intStat, intSeason, intYear, intPeriodSeason) = dblStatSeasonYearPeriod(intStat, intSeason, intYearMin, intPeriodSeason) Then
                        .Cells(row, col).Font.Color = vbBlue
                    End If
                End If
            Else
                .Cells(row, col).Interior.Color = lngNAColour
            End If
        End If

        row = row + 1
    Next

    ' format the data columns
    
    Select Case intStat
    Case conStatDETMeanBirds, conStatDETMeanBirdsCumulative, _
         conStatNetHours, conStatNetHoursCumulative, _
         conStatBirdsPer100NetHours, conStatBirdsPer100NetHoursCumulative, _
         conStatBirdsRETREPPer100NetHours, conStatBirdsRETREPPer100NetHoursCumulative
        .range(.Cells(rowBase + 1, colPeriodFirst), .Cells(row - 1, colPeriodLast)).NumberFormat = "#0.0"
    Case conStatPercentBandedHatchYear, conStatPercentBandedHatchYearCumulative
        .range(.Cells(rowBase + 1, colPeriodFirst), .Cells(row - 1, colPeriodLast)).NumberFormat = "#0%"
    Case Else
        .range(.Cells(rowBase + 1, colPeriodFirst), .Cells(row - 1, colPeriodLast)).NumberFormat = "#0"
    End Select
    
    ' format the mean column
    
    Select Case intStat
    Case conStatCaptureDays, conStatCapturePeriods, _
        conStatDETDays, conStatDETPeriods, _
        conStatCensusDays, conStatCensusPeriods, _
        conStatDETorCaptureDays
        .range(.Cells(rowBase + 1, colPeriodMean), .Cells(row - 1, colPeriodMean)).NumberFormat = "#0.00"
    Case conStatPercentBandedHatchYear, conStatPercentBandedHatchYearCumulative
        .range(.Cells(rowBase + 1, colPeriodMean), .Cells(row - 1, colPeriodMean)).NumberFormat = "#0%"
    Case Else
        .range(.Cells(rowBase + 1, colPeriodMean), .Cells(row - 1, colPeriodMean)).NumberFormat = "#0.0"
    End Select
    
    ' format the season column
       
    Select Case intStat
    Case conStatDETMeanBirds, conStatDETMeanBirdsCumulative, _
         conStatNetHours, conStatNetHoursCumulative, _
         conStatBirdsPer100NetHours, conStatBirdsPer100NetHoursCumulative, conStatBirdsRETREPPer100NetHours, conStatBirdsRETREPPer100NetHoursCumulative
        .range(.Cells(rowBase + 1, colPeriodSeason), .Cells(row - 1, colPeriodSeason)).NumberFormat = "#0.0"
    Case conStatPercentBandedHatchYear, conStatPercentBandedHatchYearCumulative
        .range(.Cells(rowBase + 1, colPeriodSeason), .Cells(row - 1, colPeriodSeason)).NumberFormat = "#0%"
    Case Else
        .range(.Cells(rowBase + 1, colPeriodSeason), .Cells(row - 1, colPeriodSeason)).NumberFormat = "#0"
    End Select
              
'     Mean 2005-previous year row
'     cell("Mean over previous years", period) reports mean_over_previous_years[period] = for a given period, the mean over all previous years of stat[year,period]

    If DisplayYearMean_Row(intStat) And intYearLast > intYearFirst Then
        For intPeriod = 1 To intPeriodLast_Season(intSeason)
            col = colPeriodFirst + intPeriod - 1
            If dblStatSeasonYearPeriod(getDaysStat(intStat), intSeason, intYearMean_PreviousYears, intPeriod) > 0 Then
                .Cells(row, col) = dblStatSeasonYearPeriod(intStat, intSeason, intYearMean_PreviousYears, intPeriod)
            Else
                .Cells(row, col).Interior.Color = lngNAColour
                Select Case intStat
                Case conStatCaptureDays, conStatCapturePeriods, _
                     conStatDETDays, conStatDETPeriods, _
                     conStatCensusDays, conStatCensusPeriods
                       .Cells(row, col) = 0
                End Select
            End If
        Next

        ' Mean 2005-previous year row for "All Periods" (season) cell

        If DisplayPeriodSeason_Column(intStat) Then
            col = colPeriodSeason
            
            If dblStatSeasonYearPeriod(getDaysStat(intStat), intSeason, intYearMean_PreviousYears, intPeriodSeason) > 0 Then
                .Cells(row, col) = dblStatSeasonYearPeriod(intStat, intSeason, intYearMean_PreviousYears, intPeriodSeason)
            Else
                .Cells(row, col).Interior.Color = lngNAColour
                Select Case intStat
                Case conStatCaptureDays, conStatCapturePeriods, _
                     conStatDETDays, conStatDETPeriods, _
                     conStatCensusDays, conStatCensusPeriods
                       .Cells(row, col) = 0
                End Select
            End If
        End If


'        col = colPeriodMean
'        If dblStatSeasonYearPeriod(getDaysStat(intStat), intSeason, intYearMean_PreviousYears, intPeriodMean) > 0 Then
'            .Cells(row, col) = dblStatSeasonYearPeriod(intStat, intSeason, intYearMean_PreviousYears, intPeriodMean)
'        Else
'            .Cells(row, col).Interior.Color = lngNAColour
'            Select Case intStat
'            Case conStatCaptureDays, conStatCapturePeriods, _
'                 conStatDETDays, conStatDETPeriods, _
'                 conStatCensusDays, conStatCensusPeriods
'                   .Cells(row, col) = 0
'            End Select
'        End If

        ' Format the mean of previous years row

        Select Case intStat
        Case conStatCaptureDays, conStatCapturePeriods, _
             conStatDETDays, conStatDETPeriods, _
             conStatCensusDays, conStatCensusPeriods, _
             conStatDETorCaptureDays
                .range(.Cells(row, colPeriodFirst), .Cells(row, colPeriodMean)).NumberFormat = "#0.00"
        Case conStatDETMeanBirds, conStatDETMeanBirdsCumulative
            .range(.Cells(row, colPeriodFirst), .Cells(row, colPeriodMean)).NumberFormat = "#0.0"
        Case conStatPercentBandedHatchYear, conStatPercentBandedHatchYearCumulative
            .range(.Cells(row, colPeriodFirst), .Cells(row, colPeriodMean)).NumberFormat = "#0%"
        Case Else
            .range(.Cells(row, colPeriodFirst), .Cells(row, colPeriodMean)).NumberFormat = "#0.0"
        End Select

        ' Format the mean of previous years x "All Periods" cell

        Select Case intStat
        Case conStatCaptureDays, conStatCapturePeriods, _
             conStatDETDays, conStatDETPeriods, _
             conStatCensusDays, conStatCensusPeriods, _
             conStatDETorCaptureDays
                .range(.Cells(row, colPeriodSeason), .Cells(row, colPeriodSeason)).NumberFormat = "#0.0"
        Case conStatDETMeanBirds, conStatDETMeanBirdsCumulative
            .range(.Cells(row, colPeriodSeason), .Cells(row, colPeriodSeason)).NumberFormat = "#0.0"
        Case conStatPercentBandedHatchYear, conStatPercentBandedHatchYearCumulative
            .range(.Cells(row, colPeriodSeason), .Cells(row, colPeriodSeason)).NumberFormat = "#0%"
        Case Else
            .range(.Cells(row, colPeriodSeason), .Cells(row, colPeriodSeason)).NumberFormat = "#0.0"
        End Select
        
        .range(.Cells(row, colYear), .Cells(row, colPeriodSeason)).Font.Italic = True

    End If

    row = row + 1
  
     ' Summer only ---
     ' Season x Period : Mean of previous MAPS years
    
    If intSeason = conSummer Then
        If DisplayYearMean_Row(intStat) And intYearLast > intYearFirst_MAPS Then
            For intPeriod = 1 To intPeriodLast_Season(intSeason)
                col = colPeriodFirst + intPeriod - 1
                If dblStatSeasonYearPeriod(getDaysStat(intStat), intSeason, intYearMean_MAPS_PreviousYears, intPeriod) > 0 Then
                    .Cells(row, col) = dblStatSeasonYearPeriod(intStat, intSeason, intYearMean_MAPS_PreviousYears, intPeriod)
                Else
                    .Cells(row, col).Interior.Color = lngNAColour
                    Select Case intStat
                    Case conStatCaptureDays, conStatCapturePeriods, _
                         conStatDETDays, conStatDETPeriods, _
                         conStatCensusDays, conStatCensusPeriods
                           .Cells(row, col) = 0
                    End Select
                End If
            Next
            
            
            If DisplayPeriodSeason_Column(intStat) Then
                col = colPeriodSeason
                
                If dblStatSeasonYearPeriod(getDaysStat(intStat), intSeason, intYearMean_MAPS_PreviousYears, intPeriodSeason) > 0 Then
                    .Cells(row, col) = dblStatSeasonYearPeriod(intStat, intSeason, intYearMean_MAPS_PreviousYears, intPeriodSeason)
                Else
                    .Cells(row, col).Interior.Color = lngNAColour
                    Select Case intStat
                    Case conStatCaptureDays, conStatCapturePeriods, _
                         conStatDETDays, conStatDETPeriods, _
                         conStatCensusDays, conStatCensusPeriods
                           .Cells(row, col) = 0
                    End Select
                End If
            End If

'            col = colPeriodMean
'            If dblStatSeasonYearPeriod(getDaysStat(intStat), intSeason, intYearMean_MAPS_PreviousYears, intPeriodMean) > 0 Then
'                .Cells(row, col) = dblStatSeasonYearPeriod(intStat, intSeason, intYearMean_MAPS_PreviousYears, intPeriodMean)
'            Else
'                .Cells(row, col).Interior.Color = lngNAColour
'                Select Case intStat
'                Case conStatCaptureDays, conStatCapturePeriods, _
'                     conStatDETDays, conStatDETPeriods, _
'                     conStatCensusDays, conStatCensusPeriods
'                       .Cells(row, col) = 0
'                End Select
'            End If

            ' Format the mean of previous years row

            Select Case intStat
            Case conStatCaptureDays, conStatCapturePeriods, _
                 conStatDETDays, conStatDETPeriods, _
                 conStatCensusDays, conStatCensusPeriods, _
                 conStatDETorCaptureDays
                    .range(.Cells(row, colPeriodFirst), .Cells(row, colPeriodMean)).NumberFormat = "#0.00"
            Case conStatDETMeanBirds, conStatDETMeanBirdsCumulative
                .range(.Cells(row, colPeriodFirst), .Cells(row, colPeriodMean)).NumberFormat = "#0.0"
            Case conStatPercentBandedHatchYear, conStatPercentBandedHatchYearCumulative
                .range(.Cells(row, colPeriodFirst), .Cells(row, colPeriodMean)).NumberFormat = "#0%"
            Case Else
                .range(.Cells(row, colPeriodFirst), .Cells(row, colPeriodMean)).NumberFormat = "#0.0"
            End Select
            
                        
            ' Format the mean of previous years x "All Periods" cell

            Select Case intStat
            Case conStatCaptureDays, conStatCapturePeriods, _
                 conStatDETDays, conStatDETPeriods, _
                 conStatCensusDays, conStatCensusPeriods, _
                 conStatDETorCaptureDays
                    .range(.Cells(row, colPeriodSeason), .Cells(row, colPeriodSeason)).NumberFormat = "#0.0"
            Case conStatDETMeanBirds, conStatDETMeanBirdsCumulative
                .range(.Cells(row, colPeriodSeason), .Cells(row, colPeriodSeason)).NumberFormat = "#0.0"
            Case conStatPercentBandedHatchYear, conStatPercentBandedHatchYearCumulative
                .range(.Cells(row, colPeriodSeason), .Cells(row, colPeriodSeason)).NumberFormat = "#0%"
            Case Else
                .range(.Cells(row, colPeriodSeason), .Cells(row, colPeriodSeason)).NumberFormat = "#0.0"
            End Select
            
            .range(.Cells(row, colYear), .Cells(row, colPeriodSeason)).Font.Italic = True

        End If

        row = row + 1
    End If


    ' Mean 2005-Current year row
    ' cell("Mean over all years", period) reports mean_over_all_years[period] = for a given period, the mean over all years of stat[year,period]
    
    If DisplayYearMean_Row(intStat) Then
        For intPeriod = 1 To intPeriodLast_Season(intSeason)
            col = colPeriodFirst + intPeriod - 1
            If dblStatSeasonYearPeriod(getDaysStat(intStat), intSeason, intYearMean, intPeriod) > 0 Then
                .Cells(row, col) = dblStatSeasonYearPeriod(intStat, intSeason, intYearMean, intPeriod)
            Else
                .Cells(row, col).Interior.Color = lngNAColour
                Select Case intStat
                Case conStatCaptureDays, conStatCapturePeriods, _
                     conStatDETDays, conStatDETPeriods, _
                     conStatCensusDays, conStatCensusPeriods
                       .Cells(row, col) = 0
                End Select
            End If
        Next

        
        If DisplayPeriodSeason_Column(intStat) Then
            col = colPeriodSeason
            
            If dblStatSeasonYearPeriod(getDaysStat(intStat), intSeason, intYearMean, intPeriodSeason) > 0 Then
                .Cells(row, col) = dblStatSeasonYearPeriod(intStat, intSeason, intYearMean, intPeriodSeason)
            Else
                .Cells(row, col).Interior.Color = lngNAColour
                Select Case intStat
                Case conStatCaptureDays, conStatCapturePeriods, _
                     conStatDETDays, conStatDETPeriods, _
                     conStatCensusDays, conStatCensusPeriods
                       .Cells(row, col) = 0
                End Select
            End If
        End If
        
        


'        col = colPeriodMean
'        If dblStatSeasonYearPeriod(getDaysStat(intStat), intSeason, intYearMean, intPeriodMean) > 0 Then
'            .Cells(row, col) = dblStatSeasonYearPeriod(intStat, intSeason, intYearMean, intPeriodMean)
'        Else
'            .Cells(row, col).Interior.Color = lngNAColour
'            Select Case intStat
'            Case conStatCaptureDays, conStatCapturePeriods, _
'                 conStatDETDays, conStatDETPeriods, _
'                 conStatCensusDays, conStatCensusPeriods
'                   .Cells(row, col) = 0
'            End Select
'        End If

'         Format the mean row

        Select Case intStat
        Case conStatCaptureDays, conStatCapturePeriods, _
             conStatDETDays, conStatDETPeriods, _
             conStatCensusDays, conStatCensusPeriods, _
             conStatDETorCaptureDays
                .range(.Cells(row, colPeriodFirst), .Cells(row, colPeriodMean)).NumberFormat = "#0.00"
        Case conStatDETMeanBirds, conStatDETMeanBirdsCumulative
            .range(.Cells(row, colPeriodFirst), .Cells(row, colPeriodMean)).NumberFormat = "#0.0"
        Case conStatPercentBandedHatchYear, conStatPercentBandedHatchYearCumulative
            .range(.Cells(row, colPeriodFirst), .Cells(row, colPeriodMean)).NumberFormat = "#0%"
        Case Else
            .range(.Cells(row, colPeriodFirst), .Cells(row, colPeriodMean)).NumberFormat = "#0.0"
        End Select
        
        
        
        ' Format the mean of all years x "All Periods" cell

        Select Case intStat
        Case conStatCaptureDays, conStatCapturePeriods, _
             conStatDETDays, conStatDETPeriods, _
             conStatCensusDays, conStatCensusPeriods, _
             conStatDETorCaptureDays
                .range(.Cells(row, colPeriodSeason), .Cells(row, colPeriodSeason)).NumberFormat = "#0.0"
        Case conStatDETMeanBirds, conStatDETMeanBirdsCumulative
            .range(.Cells(row, colPeriodFirst), .Cells(row, colPeriodSeason)).NumberFormat = "#0.0"
        Case conStatPercentBandedHatchYear, conStatPercentBandedHatchYearCumulative
            .range(.Cells(row, colPeriodSeason), .Cells(row, colPeriodSeason)).NumberFormat = "#0%"
        Case Else
            .range(.Cells(row, colPeriodSeason), .Cells(row, colPeriodSeason)).NumberFormat = "#0.0"
        End Select
        
        .range(.Cells(row, colYear), .Cells(row, colPeriodSeason)).Font.Italic = True

    End If
    row = row + 1
    
    ' "All Years" row
    ' cell("All Years", period) reports stat[period] = the statistic for a given period, measured over all years
    
    If DisplayYearSeason_Row(intStat) Then
        For intPeriod = 1 To intPeriodLast_Season(intSeason)
            col = colPeriodFirst + intPeriod - 1
            If dblStatSeasonYearPeriod(getDaysStat(intStat), intSeason, intYearSeason, intPeriod) > 0 Then
                .Cells(row, col) = dblStatSeasonYearPeriod(intStat, intSeason, intYearSeason, intPeriod)
            Else
                .Cells(row, col).Interior.Color = lngNAColour
                Select Case intStat
                Case conStatCaptureDays, conStatCapturePeriods, _
                     conStatDETDays, conStatDETPeriods, _
                     conStatCensusDays, conStatCensusPeriods, _
                     conStatDETorCaptureDays
                       .Cells(row, col) = 0
                End Select
            End If
        Next

        col = colPeriodSeason
        If dblStatSeasonYearPeriod(getDaysStat(intStat), intSeason, intYearSeason, intPeriodSeason) > 0 Then
            .Cells(row, col) = dblStatSeasonYearPeriod(intStat, intSeason, intYearSeason, intPeriodSeason)
        Else
            .Cells(row, col).Interior.Color = lngNAColour
            Select Case intStat
            Case conStatCaptureDays, conStatCapturePeriods, _
                 conStatDETDays, conStatDETPeriods, _
                 conStatCensusDays, conStatCensusPeriods, _
                 conStatDETorCaptureDays
                   .Cells(row, col) = 0
            End Select
        End If

    End If

    ' format the season row

    Select Case intStat
    Case conStatDETMeanBirds, conStatDETMeanBirdsCumulative, _
         conStatNetHours, conStatNetHoursCumulative, _
         conStatBirdsPer100NetHours, conStatBirdsPer100NetHoursCumulative
          .range(.Cells(row, colPeriodFirst), .Cells(row, colPeriodSeason)).NumberFormat = "#0.0"
    Case conStatPercentBandedHatchYear, conStatPercentBandedHatchYearCumulative
          .range(.Cells(row, colPeriodFirst), .Cells(row, colPeriodSeason)).NumberFormat = "#0%"
    Case Else
          .range(.Cells(row, colPeriodFirst), .Cells(row, colPeriodSeason)).NumberFormat = "#0"
    End Select

    row = row + 1

End If

rowsUsed = row - rowBase

End With

SysCmd acSysCmdClearStatus



'DD Error Handler Start
Exit_label:
     Exit Sub
Err_label:
     Select Case Err.Number
     Case Else
    Call LogError("basMBOProgramReport_SeasonYearPeriod", "MBOProgramReport_SeasonYearPeriod_Excel")
     End Select
     Resume Exit_label
'DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' MBOProgramReport_SeasonYearPeriod_PercentBandedHatchYear
'---------------------------------------------------------------------------------------
' Percentage of hatch year birds banded in Summer, Fall, Owling
' Hatch Year = Age "2" or "4"
' Not Hatch Year = Age "1", "5", "6", "7" or "8"
' Excluded age "0", Null or anything else
' --------------------------------------------------------------------------------------
 
Private Sub MBOProgramReport_SeasonYearPeriod_PercentBandedHatchYear( _
    ByVal intYearFirst As Integer, _
    ByVal intYearLast As Integer, _
    ByVal strLocation As String)

10    On Error GoTo Err_label
          
      Dim strSQL As String
      Dim qdf As DAO.QueryDef
      Dim rst As DAO.Recordset
      Dim intYear As Integer
      Dim intPeriod As Integer
      Dim intSeason As Integer
      Dim strSeason As String
      Dim strSpecies As String
      Dim strAge As String
      Dim lngCountHatchlings As Long
      Dim lngCountAdults As Long
      Dim lngCountHatchlingsCumulative As Long
      Dim lngCountAdultsCumulative As Long
      Dim lngCountBands As Long

      Dim intSeason_Previous As Integer
      Dim intYear_previous As Integer
      Dim intPeriod_previous As Integer

      ' Season x Year x Period

20    SysCmd acSysCmdSetStatus, "Season x Year x Period : Percent Hatch Year + Nestling Banded"

30    intSeason_Previous = -99
40    intYear_previous = 0
50    intPeriod_previous = 0

60    strSQL = "qryMBOProgramReport_SeasonYearPeriod_BNDAge"
          
70    Set qdf = CurrentDb.QueryDefs(strSQL)
80    qdf.Parameters("argLocation").value = strLocation
90    qdf.Parameters("argYearFirst").value = intYearFirst
100   qdf.Parameters("argYearLast").value = intYearLast
110   Set rst = qdf.OpenRecordset

120   Do While Not rst.EOF
130       intSeason = toIntSeasonFromStrSeason(Nz(rst("Season")))
140       intYear = Nz(rst("YearEx"))
150       intPeriod = Nz(rst("Period"))
160       strAge = Nz(rst("Age"))
170       lngCountBands = Nz(rst("CountBands"))

180       If intSeason <> intSeason_Previous Or intYear <> intYear_previous Then
        
              ' L1 control break OR first record
        
190           If intSeason_Previous <> -99 Then
                         
                  ' F2 then F1
200               If (lngCountHatchlings + lngCountAdults) > 0 Then
210                   dblStatSeasonYearPeriod(conStatPercentBandedHatchYear, intSeason_Previous, intYear_previous, intPeriod_previous) = _
                          lngCountHatchlings / (lngCountHatchlings + lngCountAdults)
220               End If
230               If (lngCountHatchlingsCumulative + lngCountAdultsCumulative) > 0 Then
240                   dblStatSeasonYearPeriod(conStatPercentBandedHatchYearCumulative, intSeason_Previous, intYear_previous, intPeriod_previous) = _
                          lngCountHatchlingsCumulative / (lngCountHatchlingsCumulative + lngCountAdultsCumulative)
250               End If
260           End If
                  
              ' H2 then H1
              
270           lngCountHatchlings = 0
280           lngCountAdults = 0
290           lngCountHatchlingsCumulative = 0
300           lngCountAdultsCumulative = 0
              
              
310      ElseIf intPeriod <> intPeriod_previous Then
         
              ' L2 control break
              
              ' F2
              
320           If (lngCountHatchlings + lngCountAdults) > 0 Then
330               dblStatSeasonYearPeriod(conStatPercentBandedHatchYear, intSeason_Previous, intYear_previous, intPeriod_previous) = _
                      lngCountHatchlings / (lngCountHatchlings + lngCountAdults)
340           End If
              
350           If (lngCountHatchlingsCumulative + lngCountAdultsCumulative) > 0 Then
360               dblStatSeasonYearPeriod(conStatPercentBandedHatchYearCumulative, intSeason_Previous, intYear_previous, intPeriod_previous) = _
                      lngCountHatchlingsCumulative / (lngCountHatchlingsCumulative + lngCountAdultsCumulative)
370           End If
              
              ' H2
              
380           lngCountHatchlings = 0
390           lngCountAdults = 0

400      End If
         
         ' Detail
                    
410       Select Case strAge
          Case "2", "4"
420           lngCountHatchlings = lngCountHatchlings + lngCountBands
430           lngCountHatchlingsCumulative = lngCountHatchlingsCumulative + lngCountBands
440       Case "1", "5", "6", "7", "8"
450           lngCountAdults = lngCountAdults + lngCountBands
460           lngCountAdultsCumulative = lngCountAdultsCumulative + lngCountBands
470       End Select
          
480       intSeason_Previous = intSeason
490       intYear_previous = intYear
500       intPeriod_previous = intPeriod

510       rst.MoveNext
520   Loop

530   If intSeason_Previous <> -99 Then
          
          ' F2 then F1
          
540       If (lngCountHatchlings + lngCountAdults) > 0 Then
550           dblStatSeasonYearPeriod(conStatPercentBandedHatchYear, intSeason_Previous, intYear_previous, intPeriod_previous) = _
                  lngCountHatchlings / (lngCountHatchlings + lngCountAdults)
560       End If
          
570       If (lngCountHatchlingsCumulative + lngCountAdultsCumulative) > 0 Then
580           dblStatSeasonYearPeriod(conStatPercentBandedHatchYearCumulative, intSeason_Previous, intYear_previous, intPeriod_previous) = _
                  lngCountHatchlingsCumulative / (lngCountHatchlingsCumulative + lngCountAdultsCumulative)
590       End If
          
600   End If

610   rst.Close
620   Set rst = Nothing
        
      ' Season x Year

630   SysCmd acSysCmdSetStatus, "Season x Year : Percent Nestling + Hatch Year Banded"

640   intSeason_Previous = -99
650   intYear_previous = 0

660   strSQL = "qryMBOProgramReport_SeasonYear_BNDAge"
          
670   Set qdf = CurrentDb.QueryDefs(strSQL)
680   qdf.Parameters("argLocation").value = strLocation
690   qdf.Parameters("argYearFirst").value = intYearFirst
700   qdf.Parameters("argYearLast").value = intYearLast
710   Set rst = qdf.OpenRecordset

720   Do While Not rst.EOF
730       intSeason = toIntSeasonFromStrSeason(Nz(rst("Season")))
740       intYear = Nz(rst("YearEx"))
750       strAge = Nz(rst("Age"))
760       lngCountBands = Nz(rst("CountBands"))
       
770       If intSeason <> intSeason_Previous Or intYear <> intYear_previous Then
        
              ' L1 control break OR first record
        
780           If intSeason_Previous <> -99 Then
                         
                  ' F1
790               If (lngCountHatchlings + lngCountAdults) > 0 Then
800                   dblStatSeasonYearPeriod(conStatPercentBandedHatchYear, intSeason_Previous, intYear_previous, intPeriodSeason) = _
                          lngCountHatchlings / (lngCountHatchlings + lngCountAdults)
810               End If
820           End If
                  
              ' H1
              
830           lngCountHatchlings = 0
840           lngCountAdults = 0
        
850      End If
         
         ' Detail
                    
860       Select Case strAge
          Case "2", "4"
870           lngCountHatchlings = lngCountHatchlings + lngCountBands
      '        lngCountHatchlingsCumulative = lngCountHatchlingsCumulative + lngCountBands
880       Case "1", "5", "6", "7", "8"
890           lngCountAdults = lngCountAdults + lngCountBands
      '        lngCountAdultsCumulative = lngCountAdultsCumulative + lngCountBands
900       End Select
          
910       intSeason_Previous = intSeason
920       intYear_previous = intYear

930       rst.MoveNext
940   Loop

950   If intSeason_Previous <> -99 Then
          
          ' F1
960       If (lngCountHatchlings + lngCountAdults) > 0 Then
970           dblStatSeasonYearPeriod(conStatPercentBandedHatchYear, intSeason_Previous, intYear_previous, intPeriodSeason) = _
                  lngCountHatchlings / (lngCountHatchlings + lngCountAdults)
980       End If
          
990   End If

1000  rst.Close
1010  Set rst = Nothing

      'Call MBOProgramReport_SeasonYearPeriod_TotalMean(conStatPercentBandedHatchYear, intYearFirst, intYearLast, strLocation)
      'Call MBOProgramReport_SeasonYearPeriod_MinMax(conStatPercentBandedHatchYear, intYearFirst, intYearLast, strLocation)
      'Call MBOProgramReport_SeasonYearPeriod_MinMax(conStatPercentBandedHatchYearCumulative, intYearFirst, intYearLast, strLocation)

      ' Season x Period

1020  SysCmd acSysCmdSetStatus, "Season x Period : Percent Nestling + Hatch Year Banded"

1030  intSeason_Previous = -99
1040  intPeriod_previous = 0

1050  strSQL = "qryMBOProgramReport_SeasonPeriod_BNDAge"
          
1060  Set qdf = CurrentDb.QueryDefs(strSQL)
1070  qdf.Parameters("argLocation").value = strLocation
1080  qdf.Parameters("argYearFirst").value = intYearFirst
1090  qdf.Parameters("argYearLast").value = intYearLast
1100  Set rst = qdf.OpenRecordset

1110  Do While Not rst.EOF
1120      intSeason = toIntSeasonFromStrSeason(Nz(rst("Season")))
1130      intPeriod = Nz(rst("Period"))
1140      strAge = Nz(rst("Age"))
1150      lngCountBands = Nz(rst("CountBands"))
          
1160      If intSeason <> intSeason_Previous Or intPeriod <> intPeriod_previous Then
        
              ' L1 control break OR first record
        
1170          If intSeason_Previous <> -99 Then
                         
                  ' F1
1180               If (lngCountHatchlings + lngCountAdults) > 0 Then
1190                  dblStatSeasonYearPeriod(conStatPercentBandedHatchYear, intSeason_Previous, intYearSeason, intPeriod_previous) = _
                          lngCountHatchlings / (lngCountHatchlings + lngCountAdults)
1200               End If
      '             dblStatSeasonYearPeriod(conStatPercentBandedHatchYearCumulative, intSeason_previous, intYearSeason, intPeriod_previous) = _
      '                lngCountHatchlingsCumulative / (lngCountHatchlingsCumulative + lngCountAdultsCumulative)
                  
1210         Else
             
1220              lngCountHatchlings = 0
1230              lngCountAdults = 0

1240          End If
                  
              ' H1
              
1250          lngCountHatchlings = 0
1260          lngCountAdults = 0
      '        lngCountHatchlingsCumulative = 0
      '        lngCountAdultsCumulative = 0
              
1270     End If
         
         ' Detail
                    
1280      Select Case strAge
          Case "2", "4"
1290          lngCountHatchlings = lngCountHatchlings + lngCountBands
      '        lngCountHatchlingsCumulative = lngCountHatchlingsCumulative + lngCountBands
1300      Case "1", "5", "6", "7", "8"
1310          lngCountAdults = lngCountAdults + lngCountBands
       '       lngCountAdultsCumulative = lngCountAdultsCumulative + lngCountBands
1320      End Select
          
1330      intSeason_Previous = intSeason
1340      intYear_previous = intYear
1350      intPeriod_previous = intPeriod

1360      rst.MoveNext
1370  Loop

1380  If intSeason_Previous <> -99 Then
          
          ' F1
1390      If (lngCountHatchlings + lngCountAdults) > 0 Then
1400          dblStatSeasonYearPeriod(conStatPercentBandedHatchYear, intSeason_Previous, intYearSeason, intPeriod_previous) = _
                  lngCountHatchlings / (lngCountHatchlings + lngCountAdults)
1410      End If
          
      '    dblStatSeasonYearPeriod(conStatPercentBandedHatchYearCumulative, intSeason_previous, intYearSeason, intPeriod_previous) = _
      '        lngCountHatchlingsCumulative / (lngCountHatchlingsCumulative + lngCountAdultsCumulative)
          
1420  End If

1430  rst.Close
1440  Set rst = Nothing

      ' Season

1450  SysCmd acSysCmdSetStatus, "Season : Percent Nestling + Hatch Year Banded"

1460  intSeason_Previous = -99

1470  strSQL = "qryMBOProgramReport_Season_BNDAge"
          
1480  Set qdf = CurrentDb.QueryDefs(strSQL)
1490  qdf.Parameters("argLocation").value = strLocation
1500  qdf.Parameters("argYearFirst").value = intYearFirst
1510  qdf.Parameters("argYearLast").value = intYearLast
1520  Set rst = qdf.OpenRecordset

1530  Do While Not rst.EOF
1540      intSeason = toIntSeasonFromStrSeason(Nz(rst("Season")))
1550      strAge = Nz(rst("Age"))
1560      lngCountBands = Nz(rst("CountBands"))
          
1570      If intSeason <> intSeason_Previous Then
        
              ' L1 control break OR first record
        
1580          If intSeason_Previous <> -99 Then
                         
                  ' F1
                  
1590                 dblStatSeasonYearPeriod(conStatPercentBandedHatchYear, intSeason_Previous, intYearSeason, intPeriodSeason) = lngCountHatchlings / (lngCountHatchlings + lngCountAdults)

1600          End If
                  
              ' H1
              
1610          lngCountHatchlings = 0
1620          lngCountAdults = 0
        
1630     End If
         
         ' Detail
                    
1640      Select Case strAge
          Case "2", "4"
1650          lngCountHatchlings = lngCountHatchlings + lngCountBands
      '        lngCountHatchlingsCumulative = lngCountHatchlingsCumulative + lngCountBands
1660      Case "1", "5", "6", "7", "8"
1670          lngCountAdults = lngCountAdults + lngCountBands
      '        lngCountAdultsCumulative = lngCountAdultsCumulative + lngCountBands
1680      End Select
          
1690      intSeason_Previous = intSeason

1700      rst.MoveNext
1710  Loop

1720  If intSeason_Previous <> -99 Then
          
          ' F1
          
1730      If (lngCountHatchlings + lngCountAdults) > 0 Then
1740          dblStatSeasonYearPeriod(conStatPercentBandedHatchYear, intSeason_Previous, intYearSeason, intPeriodSeason) = _
                  lngCountHatchlings / (lngCountHatchlings + lngCountAdults)
1750      End If

1760  End If

1770  rst.Close
1780  Set rst = Nothing
          
1790  SysCmd acSysCmdClearStatus
          
      'DD Error Handler Start
Exit_label:
1800       Exit Sub
Err_label:
1810       Select Case Err.Number
           Case Else
1820      Call LogError("basMBOProgramReport_SeasonYearPeriod", "MBOProgramReport_SeasonYearPeriod_PercentBandedHatchYear")
1830       End Select
1840       Resume Exit_label
      'DD Error Handler End
          
    End Sub



'---------------------------------------------------------------------------------------
' MBOProgramReport_SeasonYearPeriod_DETMeanBirds
'---------------------------------------------------------------------------------------
' DETBirds / DETDays

Private Sub MBOProgramReport_SeasonYearPeriod_DETMeanBirds( _
    ByVal intYearFirst As Integer, _
    ByVal intYearLast As Integer, _
    ByVal strLocation As String)

10    On Error GoTo Err_label

      Dim intSeason As Integer
      Dim intYear As Integer
      Dim intPeriod As Integer
      Dim dblDETDays As Double

      ' season x year x period

      ' mean DET birds = DET birds / DET days
      ' cumulative mean DET birds = cumulative DET birds / cumulative DET days

      ' At this point
      ' dblStatSeasonYearPeriod(conStatDETDays, intSeason, intYear, intPeriod) contains the number of DET days  in a given season x year x period
      ' dblStatSeasonYearPeriod(conStatDETDays, intSeason, intYear, intPeriodTotal) contains the number of DET days counted over all periods a given season x year
      ' dblStatSeasonYearPeriod(conStatDETDays, intSeason, intYearTotal, intPeriod) contains the number of DET days counted over all years in a given season x period
      ' dblStatSeasonYearPeriod(conStatDETDays, intSeason, intYearTotal, intPeriodTotal) contains the number of DET days counted over all periods and all years in a given season

      ' At this point
      ' dblStatSeasonYearPeriod(conStatDETBirds, intSeason, intYear, intPeriod) contains the number of birds DETed  in a given season x year x period
      ' dblStatSeasonYearPeriod(conStatDETBirds, intSeason, intYear, intPeriodTotal) contains the number of birds DETed counted over all periods a given season x year
      ' dblStatSeasonYearPeriod(conStatDETBirds, intSeason, intYearTotal, intPeriod) contains the number of DETed birds counted over all years in a given season x period
      ' dblStatSeasonYearPeriod(conStatDETBirds, intSeason, intYearTotal, intPeriodTotal) contains the number of DETed birds days counted over all periods and all years in a given season


      ' season x year x period
      ' For each season x year x period, DET mean birds = DET birds / DET days  (0, if DET days = 0)

20    For intSeason = intSeasonFirst To intSeasonLast
30        For intYear = intYearFirst To intYearLast
40            For intPeriod = 1 To intPeriodLast
50                dblDETDays = dblStatSeasonYearPeriod(conStatDETDays, intSeason, intYear, intPeriod)
60                If dblDETDays > 0 Then
70                    dblStatSeasonYearPeriod(conStatDETMeanBirds, intSeason, intYear, intPeriod) = _
                          dblStatSeasonYearPeriod(conStatDETBirds, intSeason, intYear, intPeriod) / dblDETDays
80                End If
90            Next
100       Next
110   Next

      ' season x year
      ' For each season x year, DET mean birds = DET birds counted over all periods in the season x year / DET days couted over all periods in the season x year (0, if DET days = 0)

120   For intSeason = intSeasonFirst To intSeasonLast
130       For intYear = intYearFirst To intYearLast
140           dblDETDays = dblStatSeasonYearPeriod(conStatDETDays, intSeason, intYear, intPeriodTotal)
150           If dblDETDays > 0 Then
160               dblStatSeasonYearPeriod(conStatDETMeanBirds, intSeason, intYear, intPeriodSeason) = _
                      dblStatSeasonYearPeriod(conStatDETBirds, intSeason, intYear, intPeriodTotal) / dblDETDays
170           End If
180       Next
190   Next

      ' season x period
      ' For each season x perid, DET mean birds = DET birds counted over all years in the season x period / DET days couted over all periods in the season x period (0, if DET days = 0)

200   For intSeason = intSeasonFirst To intSeasonLast
210       For intPeriod = 1 To intPeriodLast
220           dblDETDays = dblStatSeasonYearPeriod(conStatDETDays, intSeason, intYearTotal, intPeriod)
230           If dblDETDays > 0 Then
240               dblStatSeasonYearPeriod(conStatDETMeanBirds, intSeason, intYearSeason, intPeriod) = _
                      dblStatSeasonYearPeriod(conStatDETBirds, intSeason, intYearTotal, intPeriod) / dblDETDays
250           End If
260       Next
270   Next

      ' season

      ' mean DET birds = Grand total DET birds / Grand total DET days
      ' For each season, DET mean birds = DET birds counted over all periods and years in the season  / DET days couted over all periods and years in the season (0, if DET days = 0)

280   For intSeason = intSeasonFirst To intSeasonLast
290       dblDETDays = dblStatSeasonYearPeriod(conStatDETDays, intSeason, intYearTotal, intPeriodTotal)
300       If dblDETDays > 0 Then
310           dblStatSeasonYearPeriod(conStatDETMeanBirds, intSeason, intYearSeason, intPeriodSeason) = _
                  dblStatSeasonYearPeriod(conStatDETBirds, intSeason, intYearTotal, intPeriodTotal) / dblDETDays
320       End If
330   Next

340   Call MBOProgramReport_SeasonYearPeriod_TotalMean(conStatDETMeanBirds, intYearFirst, intYearLast, strLocation, fCopyToSeason:=False)
350   Call MBOProgramReport_SeasonYearPeriod_MinMax(conStatDETMeanBirds, intYearFirst, intYearLast, strLocation)
360   Call MBOProgramReport_SeasonYearPeriod_Cumulative(conStatDETMeanBirds, conStatDETMeanBirdsCumulative, intYearFirst, intYearLast, strLocation)

      'DD Error Handler Start
Exit_label:
370        Exit Sub
Err_label:
380        Select Case Err.Number
           Case Else
390             Call LogError("basMBOProgramReport_SeasonYearPeriod", "MBOProgramReport_SeasonYearPeriod_DETMeanBirds")
400        End Select
410        Resume Exit_label
      'DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' getDaysStat
'
' Given a statistic, return the corresponding Days statistic
'
' Returns conStatCapturesDays for capture statistics
'         conStatDETDays      for DET statistics
'         conStatCensusDays   for Census statistics
'---------------------------------------------------------------------------------------
' Used to shade an interval to indicate a statistic was not measured
 
Public Function getDaysStat(ByVal intStat As Integer) As Integer
10    On Error GoTo Err_label

20    Select Case intStat
      Case conStatDETPeriods, conStatDETDays, conStatDETDaysCumulative, _
          conStatDETBirds, conStatDETBirdsCumulative, _
          conStatDETSpecies, conStatDETSpeciesCumulative, _
          conStatDETMeanBirds, conStatDETMeanBirdsCumulative
30            getDaysStat = conStatDETDays
40    Case conStatCensusPeriods, conStatCensusDays, conStatCensusDaysCumulative, _
           conStatCensusSpecies, conStatCensusSpeciesCumulative
50            getDaysStat = conStatCensusDays
60    Case Else
70        getDaysStat = conStatCaptureDays
80    End Select

      'DD Error Handler Start
Exit_label:
90         Exit Function
Err_label:
100        Select Case Err.Number
           Case Else
110             Call LogError("basMBOProgramReport_SeasonYearPeriod", "getStatDays")
120        End Select
130        Resume Exit_label
      'DD Error Handler End

End Function
