'---------------------------------------------------------------------------------------
' Module    : basDET
' Author    : David Davey
'---------------------------------------------------------------------------------------

Option Compare Database
Option Explicit

Public Const conAbundanceUnknown As Integer = 0
Public Const conAbundanceVeryRare As Integer = 1
Public Const conAbundanceRare As Integer = 2
Public Const conAbundanceUncommon As Integer = 3
Public Const conAbundanceFairlyCommon As Integer = 4
Public Const conAbundanceCommon As Integer = 5
Public Const conAbundanceAbundant As Integer = 6

' Const intExclusionPeriodInDays As Integer = 90

'---------------------------------------------------------------------------------------
' load_tbl10YearProgramReportSpecies_Classic
'---------------------------------------------------------------------------------------
' This is the "classic" load of tbl10YearProgramReportSpecies
' Null DET values from Owling, Nestbox, RTHU_Spring, RTHU_Fall remain Null
' Seasons are not merged.
'
' tblMBO10YearProgramReportSpecies
' --------------------------------
' same as tblDETSpecies, except
' SNGO GSGO LSGO merged into SNGO
' TRFL ALFL WIFL merged into TRFL
' The records for ("UNSG","UNAC","UNEM","UNGU","UNSC","PAWA","UNPW") are excluded
' -------------------------------
' WHERE YearEx BETWEEN intYearFrom AND intYearTo
' WHERE Location = "MBO"
'
' Season
' YearEx
' Period            filled in using Period: toPeriod([MonitoringProgramSeason],[DateEx],[DateFrom])
' DateEx
' Species
' Banded
' Returns
' Repeats
' DET


Public Sub load_tbl10YearProgramReportSpecies_Classic(ByVal intYearFirst As Integer, ByVal intYearLast As Integer)

10    On Error GoTo Err_label

Dim strLocation As String
Dim qdf As DAO.QueryDef
strLocation = "MBO"
             
20    CurrentDb.Execute "DELETE * FROM tblMBO10YearProgramReportSpecies"

30    Set qdf = CurrentDb.QueryDefs("qryMBO10YearProgramReportSpecies_Append")
40    qdf.Parameters("argLocation").value = strLocation
50    qdf.Parameters("argYearFirst").value = intYearFirst
60    qdf.Parameters("argYearLast").value = intYearLast
70    qdf.Execute
80    Set qdf = CurrentDb.QueryDefs("qryMBO10YearProgramReportSpecies_Append_TRFL")
90    qdf.Parameters("argLocation").value = strLocation
100   qdf.Parameters("argYearFirst").value = intYearFirst
110   qdf.Parameters("argYearLast").value = intYearLast
120   qdf.Execute
130   Set qdf = CurrentDb.QueryDefs("qryMBO10YearProgramReportSpecies_Append_SNGO")
140   qdf.Parameters("argLocation").value = strLocation
150   qdf.Parameters("argYearFirst").value = intYearFirst
160   qdf.Parameters("argYearLast").value = intYearLast
170   qdf.Execute

    'DD Error Handler Start
Exit_label:
180       Exit Sub
Err_label:
190       Select Case Err.Number
    Case Else
200      Call LogError("basDET", "load_tbl10YearProgramReportSpecies_Classic")
210       End Select
220       Resume Exit_label
    ' DD Error Handler End

End Sub


'---------------------------------------------------------------------------------------
' getReportDate
'
' The Report Date = Capture Date for day programs (Winter, Spring, Summer, Fall)
' The Report Date = Capture Date     for Owling if between noon and midnight (12:00 to 23:50 inclusive)
'                   Capture Date - 1 for Owling if between midnight and noon (0:00 to 11:59 inclusive)
'                   Capture Date     for Owling if Weight Time is Null
'
' Caveat: Weight Time = 0  =>  the day before.  So Weight Time = 0 is very different to Weight Time is null
'
'---------------------------------------------------------------------------------------
 
Public Function getReportDate(ByVal CaptureDate As Date, ByVal Season As String, ByVal WeightTime As Variant) As Date
10       On Error GoTo Err_label

20        If Season <> "Owling" Then
30            getReportDate = CaptureDate
40        Else
50            If IsNull(WeightTime) Then
60                getReportDate = CaptureDate
70            Else
                  Dim dblTime As Double
              
80                dblTime = Nz(WeightTime) - Int(WeightTime)
90                If dblTime < 0.5 Then
100                   getReportDate = CaptureDate - 1
110               Else
120                   getReportDate = CaptureDate
130               End If
140           End If
150       End If

    'DD Error Handler Start
Exit_label:
160       Exit Function
Err_label:
170       Select Case Err.Number
    Case Else
180      Call LogError("basDET", "getReportDate")
190       End Select
200       Resume Exit_label
    ' DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' getAgeSex
'---------------------------------------------------------------------------------------
' Convert Age and Sex codes to a combined string
' e.g. Age=1 Sex=4 => "AHY-M"

Public Function getAgeSex(ByVal Age As String, ByVal Sex As String)

10    On Error GoTo Err_label

20    getAgeSex = ""
30    Select Case Left(Age, 1)
      Case "0"
40        getAgeSex = "U"
50    Case "1"
60        getAgeSex = "AHY"
70    Case "2"
80        getAgeSex = "HY"
90    Case "4"
100       getAgeSex = "L"
110   Case "5"
120       getAgeSex = "SY"
130   Case "6"
140       getAgeSex = "ASY"
150   Case "7"
160       getAgeSex = "TY"
170   Case "8"
180       getAgeSex = "ATY"
190   Case Else
200       getAgeSex = ""
210   End Select
220   Select Case Left(Sex, 1)
      Case "0"
230       getAgeSex = getAgeSex & "-U"
240   Case "4", "6"
250       getAgeSex = getAgeSex & "-M"
260   Case "5", "7"
270       getAgeSex = getAgeSex & "-F"
300   End Select

    'DD Error Handler Start
Exit_label:
310       Exit Function
Err_label:
320       Select Case Err.Number
    Case Else
330      Call LogError("basDET", "getAgeSex")
340       End Select
350       Resume Exit_label
    ' DD Error Handler End
          
End Function

'---------------------------------------------------------------------------------------
' getYear
'
' Get the reporting year from the date and season
'---------------------------------------------------------------------------------------
 
Public Function getYear(ByVal datDateFrom As Variant, ByVal strSeason As Variant) As Integer

10    On Error GoTo Err_label

20    getYear = 0

30    If Not (IsNull(datDateFrom) Or IsNull(strSeason)) Then
40        Select Case strSeason
          Case "Spring", "Summer", "Fall", "Owling"
50            getYear = Year(datDateFrom)
60        Case "Winter"
70            getYear = Year(datDateFrom) + 1
80        Case "Non season"
90            If Nz(datDateFrom) <> 0 Then
100               getYear = Year(datDateFrom)
110           End If
120       End Select
130   End If

      'DD Error Handler Start
Exit_label:
140        Exit Function
Err_label:
150        Select Case Err.Number
           Case Else
160             Call LogError("basDET", "getYear")
170        End Select
180        Resume Exit_label
      'DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' getStartDatePeriod
'---------------------------------------------------------------------------------------
 
Public Function getStartDatePeriod(ByVal datDateEx As Variant, _
    ByVal datDateFrom As Variant, _
    ByVal strSeason As Variant) As Date
    
10    On Error GoTo Err_label

20        getStartDatePeriod = 0
30        Select Case strSeason
          Case "Spring", "Fall", "Summer", "Owling"
40            getStartDatePeriod = Fix((datDateEx - datDateFrom) / 7) * 7 + datDateFrom
50        Case "Winter"
          Dim intMonth As Integer
          Dim intYear As Integer
60            intMonth = Month(datDateEx)
70            intYear = Year(datDateEx)
80            Select Case intMonth
              Case 1, 2, 3, 12
90                getStartDatePeriod = DateSerial(intYear, intMonth, 1)
100           Case 10, 11
110               getStartDatePeriod = datDateFrom
120           End Select
130       End Select

'DD Error Handler Start
Exit_label:
140        Exit Function
Err_label:
150        Select Case Err.Number
     Case Else
160       Call LogError("basDET", "getStartDatePeriod")
170        End Select
180        Resume Exit_label
'DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' getLastDatePeriod
'---------------------------------------------------------------------------------------
 
Public Function getLastDatePeriod(ByVal datDateEx As Variant, _
    ByVal datDateFrom As Variant, _
    ByVal strSeason As Variant) As Date
          
10    On Error GoTo Err_label

20        getLastDatePeriod = 0
30        Select Case strSeason
          Case "Spring", "Fall", "Summer", "Owling"
40            getLastDatePeriod = Fix((datDateEx - datDateFrom) / 7) * 7 + datDateFrom + 6
50        Case "Winter"
          Dim intMonth As Integer
          Dim intYear As Integer
60            intMonth = Month(datDateEx)
70            intYear = Year(datDateEx)
80            Select Case intMonth
              Case 1, 2, 3
90                getLastDatePeriod = DateSerial(intYear, intMonth + 1, 1) - 1
100           Case 10, 11
110               getLastDatePeriod = DateSerial(intYear, 12, 1) - 1
120           Case 12
130               getLastDatePeriod = DateSerial(intYear + 1, 1, 1) - 1
140           End Select
150       End Select

      'DD Error Handler Start
Exit_label:
160        Exit Function
Err_label:
170        Select Case Err.Number
           Case Else
180       Call LogError("basDET", "getStartDatePeriod")
190        End Select
200        Resume Exit_label
      'DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' getPeriod
'
' Called from qryDETGeneralDailyXSpecies
'
'---------------------------------------------------------------------------------------
 
Public Function getPeriod(ByVal datDateEx As Variant, _
    ByVal datDateFrom As Variant, _
    ByVal strSeason As Variant) As Integer
    
10    On Error GoTo Err_label

20    getPeriod = 1
30    If Nz(datDateFrom) = 0 Then GoTo Exit_label
40    If Nz(datDateEx) = 0 Then GoTo Exit_label

50    Select Case strSeason
      Case "Spring", "Fall", "Summer"
60        getPeriod = Fix((datDateEx - datDateFrom) / 7) + 1
70    Case "Winter"
          Dim intMonth As Integer
80        intMonth = Month(datDateEx)
90        Select Case intMonth
          Case 1, 2, 3
100           getPeriod = 2 + intMonth
110       Case 10, 11
120           getPeriod = 1
130       Case 12
140           getPeriod = 2
150       End Select
160   End Select

      'DD Error Handler Start
Exit_label:
170        Exit Function
Err_label:
180        Select Case Err.Number
           Case Else
190             Call LogError("basDET", "getPeriod")
200        End Select
210        Resume Exit_label
      'DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' getSeasonOrder
'---------------------------------------------------------------------------------------
 
Public Function getSeasonOrder(ByVal strSeason As Variant) As Integer
10       On Error GoTo Err_label

20        Select Case strSeason
          Case "Winter"
30            getSeasonOrder = 0
40        Case "Spring"
50            getSeasonOrder = 1
60        Case "Summer"
70            getSeasonOrder = 2
80        Case "Fall"
90            getSeasonOrder = 3
100       Case "Owling"
110           getSeasonOrder = 4
120       Case Else
130           getSeasonOrder = 5
140       End Select

    'DD Error Handler Start
Exit_label:
150       Exit Function
Err_label:
160       Select Case Err.Number
    Case Else
170      Call LogError("basDET", "getSeasonOrder")
180       End Select
190       Resume Exit_label
    ' DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' cmdBndRepRetReport_Click
'---------------------------------------------------------------------------------------
 
Public Sub Report_BandedRepeatReturn( _
    ByVal strProgram As String, _
    ByVal strLocation As String, _
    ByVal datFrom As Date, ByVal datTo As Date)

10    On Error GoTo Err_label

      '       Dim strSQL As String

      Dim strSQL As String

20    strSQL = "DELETE * FROM tblErrorMessage"
30    CurrentDb.Execute strSQL

      ' Regenerate D18 and D20

      Dim rstDETNoCategory As DAO.Recordset
40    Set rstDETNoCategory = CurrentDb.OpenRecordset("tblErrorMessage", dbOpenDynaset)
50    Call UpdateDETCategory(strProgram, strLocation, datFrom, datTo, rstDETNoCategory)

      ' Generate tblDET3

      Dim cntRecords As Long
60    Call Create_tblDET3(cntRecords, strProgram, strLocation, "Create", datFrom, datTo)

      ' qryDET4
      '     Based on tblDET3
      '     For each CaptureDate and Species, calculates
      '     the number of species banded, repeat and return (1 or 0)
      '     For each CaptureDate and Species adds SpeciesDescriptionMBO
      '     and DETOrder from tblSpecies
      '
      '     tblDET3.Program
      '     tblDET3.Location
      '     tblDET3.DateEx
      '     tblDET3.Species
      '     tblDET3.Banded
      '     tblDET3.Repeat
      '     tblDET3.Alien
      '     tblDET3.Replacement
      '     tblDET3.Unknown
      '     SpeciesBanded: IIf([Banded]>0,1,0)
      '     SpeciesRepeat: IIf([Repeat]>0,1,0)
      '     SpeciesReturn: IIf([Return]>0,1,0)
      '     SpeciesAlien: IIf([Alien]>0,1,0)
      '     SpeciesReplacement: IIf([Replacement]>0,1,0)
      '     SpeciesUnknown: IIf([Unknown]>0,1,0)
      '     tblSpecies.SpeciesDescriptionMBO
      '     tblSpecies.DETOrder - Sort Ascending

      ' rptDET
      '     Based on qryDET4
      '     Group on CaptureDate, Sort by DETOrder
      '     CaptureDate Header
      '         CaptureDate by Day
      '     Detail
      '         SpeciesDescriptionMBO
      '         Banded
      '         Repeat
      '         Return
      '         Alien
      '         Replacement
      '         Unknown
      '     CaptureDate Footer
      '         =Sum(Nz([Banded]))
      '         =Sum(Nz([Repeat]))
      '         =Sum(Nz([Return]))
      '         =Sum([speciesBanded])
      '         =Sum([SpeciesRepeat])
      '         =Sum([SpeciesReturn])

70    If cntRecords > 0 Then
80        DoCmd.OpenReport "rptDET", acViewReport, "", "", acNormal
90    Else
100       MsgBox "There are no capture records between " & _
              Format(datFrom, "dd mmm yyyy") & " and " & Format(datTo, "dd mmm yyyy")
110   End If

      'DD Error Handler Start
Exit_label:
120        Exit Sub
Err_label:
130        Select Case Err.Number
           Case Else
140             Call LogError("basDET", "cmdBndRepRetReport_Click")
150        End Select
160        Resume Exit_label
      'DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' UpdateDETProgram
'
' if fRegenerateDETCategory
'    Recalculates D18 (DETCategory) and D20 (Days since most recent prior capture) for each
'       capture record
'
' if fCreate_tblDET3 then
'    Recalculate all DET capture values => tblDET3
'
' Fills in the Banded, Returns, Repeats, Alien, Replacement columns of the DET sheets
'     for the given Program, Location, between the From and To dates inclusive
'---------------------------------------------------------------------------------------
' Null the data from the Banded, Returns, Repeats, Alien, Replacement columns of the DET sheets
' Fill in the data from the Banded, Returns, Repeats, Alien, Replacement columns of the DET sheets
'    Edit existing DETSpecies records, Add new DETSpecies records
' Delete DETSpecies records with no non-key data
' Fixup referential integrity (create or delete DETDaily records)
' Do I need to fill in any Effort fields?
 
Public Function UpdateDETProgram( _
    ByVal fRegenerateDETCategory As Boolean, _
    ByVal fCreate_tblDET3 As Boolean, _
    ByVal strProgram As String, _
    ByVal strLocation As String, _
    Optional ByVal datFrom As Date = #1/1/1900#, _
    Optional ByVal datTo As Date = #1/1/3000#) As Boolean

10    On Error GoTo Err_label

20    UpdateDETProgram = True

      ' Clear all Bnd, Rep, Ret, A, 5 data from tblDETSpecies for the Program, Location
      ' between datFrom and datTo inclusive

      Dim strSQL As String
30    strSQL = "UPDATE tblDETSpecies " & _
          "SET Banded = Null, Repeats = Null, Returns = Null, Observed3 = Null, Observed4 = Null " & _
          "WHERE ([Program]='" & strProgram & "') AND " & _
          "      ([Location]='" & strLocation & "') AND " & _
          "      ([DateEx] BETWEEN #" & Format(datFrom, "mm/dd/yyyy") & "# AND " & _
          "                        #" & Format(datTo, "mm/dd/yyyy") & "#)"
          
40    CurrentDb.Execute strSQL
       
          
      'Dim fOK As Boolean
      'fOK = False
      '
      'Dim try As Integer
      'For try = 1 To 3
      '
      '    On Error Resume Next
      '    CurrentDb.Execute strSQL
      '    If Err.Number = 0 Then
      '        fOK = True
      '        Exit For
      '    End If
      '    Err.Clear
      'Next try
      'On Error GoTo Err_label

60    If fRegenerateDETCategory Then
          Dim rstDETNoCategory As DAO.Recordset
70        Set rstDETNoCategory = CurrentDb.OpenRecordset("tblErrorMessage", dbOpenDynaset)
80        Call UpdateDETCategory(strProgram, strLocation, datFrom, datTo, rstDETNoCategory)
90    End If

100   If fCreate_tblDET3 Then
110       SysCmd acSysCmdSetStatus, "Get capture data"
120       DoEvents
          Dim cntRecords As Long
130       Call Create_tblDET3(cntRecords, strProgram, strLocation, "Create", datFrom, datTo)
140   End If

      ' ---------------------------------------------------------------
      ' Fill in the DETSpecies records
      ' (I'll clean up and fix referential integrity afterwards)
      ' ---------------------------------------------------------------

      Dim rstSource As DAO.Recordset
      Dim rstDETSpecies As DAO.Recordset

150   Set rstSource = CurrentDb.OpenRecordset("select * from tblDET3 order by [DateEx]", dbOpenDynaset)
160   Set rstDETSpecies = CurrentDb.OpenRecordset("tblDETSpecies", dbOpenDynaset)

170   Do While Not rstSource.EOF

          Dim strSpecies As String
          Dim datDate As Date
          Dim lngBanded As Long
          Dim lngRepeats As Long
          Dim lngReturns As Long
          Dim lngAlien As Long
          Dim lngReplacement As Long
          
      ' Get data from tblDET3
              
180       strSpecies = Nz(rstSource.Fields("Species"))
190       datDate = Nz(rstSource.Fields("DateEx"))

200       SysCmd acSysCmdSetStatus, "Update DET " & strProgram & " at " & strLocation & " on " & Format(datDate, "d mmm yyyy")
210       DoEvents

      '   On Error Resume Next

220       lngBanded = Nz(rstSource.Fields("Banded"))
230       lngRepeats = Nz(rstSource.Fields("Repeat"))
240       lngReturns = Nz(rstSource.Fields("Return"))
250       lngAlien = Nz(rstSource.Fields("Alien"))
260       lngReplacement = Nz(rstSource.Fields("Replacement"))

      ' Update tblDETSpecies

          Dim strCriterionDET As String
          Dim strCriterionDETSpecies As String
          Dim strClauseProgram As String
          Dim strClauseLocation As String
          Dim strClauseDateEX As String
          Dim strClauseSpecies As String
          
270       strClauseProgram = "Program = '" & strProgram & "'"
280       strClauseLocation = "Location = '" & strLocation & "'"
290       strClauseDateEX = "DateEx = #" & Format(datDate, "mm/dd/yyyy") & "#"
300       strClauseSpecies = "Species = '" & strSpecies & "'"
          
310       strCriterionDET = _
              strClauseProgram & " AND " & _
              strClauseLocation & " AND " & _
              strClauseDateEX

320       strCriterionDETSpecies = _
              strClauseProgram & " AND " & _
              strClauseLocation & " AND " & _
              strClauseDateEX & " AND " & _
              strClauseSpecies
          
      ' If there is no corresponding DETSpecies record, add one
      ' Else update it
          
330       rstDETSpecies.FindFirst strCriterionDETSpecies
340       If rstDETSpecies.NoMatch Then
350           rstDETSpecies.AddNew
360           rstDETSpecies.Fields("Program") = strProgram
370           rstDETSpecies.Fields("Location") = strLocation
380           rstDETSpecies.Fields("DateEx") = DateSerial(Year(datDate), Month(datDate), Day(datDate))
390           rstDETSpecies.Fields("Species") = strSpecies
400           rstDETSpecies.Fields("Banded") = IIf(lngBanded = 0, Null, lngBanded)
410           rstDETSpecies.Fields("Returns") = IIf(lngReturns = 0, Null, lngReturns)
420           rstDETSpecies.Fields("Repeats") = IIf(lngRepeats = 0, Null, lngRepeats)
430           rstDETSpecies("Observed3") = IIf(lngAlien = 0, Null, lngAlien)
440           rstDETSpecies("Observed4") = IIf(lngReplacement = 0, Null, lngReplacement)
450           rstDETSpecies.Update
460       Else
470           rstDETSpecies.Edit
480           rstDETSpecies.Fields("Program") = strProgram
490           rstDETSpecies.Fields("Location") = strLocation
500           rstDETSpecies.Fields("DateEx") = DateSerial(Year(datDate), Month(datDate), Day(datDate))
510           rstDETSpecies.Fields("Species") = strSpecies
520           rstDETSpecies.Fields("Banded") = IIf(lngBanded = 0, Null, lngBanded)
530           rstDETSpecies.Fields("Returns") = IIf(lngReturns = 0, Null, lngReturns)
540           rstDETSpecies.Fields("Repeats") = IIf(lngRepeats = 0, Null, lngRepeats)
550           rstDETSpecies("Observed3") = IIf(lngAlien = 0, Null, lngAlien)
560           rstDETSpecies("Observed4") = IIf(lngReplacement = 0, Null, lngReplacement)
570           rstDETSpecies.Update
580       End If
          
Next_record_label:
590       rstSource.MoveNext
600   Loop

610   rstDETSpecies.Close
620   rstSource.Close

    ' Delete all tblDETNetHours records that have no non-key data
    ' Get Daily records with no non-key data and no related Species records
    '     if there any no related tblDETNetHours records, delete the tblDaily record
    ' Create a tdbDETDaily record if there are there any tblDETSpecies records with no corresponding parent tblDETDaily record
    ' Create a tdbDETDaily record if there are there any tblDETNetHours records with no corresponding tblDETDaily record

630   Call DETCleanGivenProgramLocationFromTo(strProgram, strLocation, datFrom, datTo)

640   SysCmd acSysCmdClearStatus
650   DoEvents

      'DD Error Handler Start
Exit_label:
660        Exit Function
Err_label:
670        Select Case Err.Number
           Case Else
680       Call LogError("basDET", "UpdateDETProgram")
690        End Select
700        Resume Exit_label
      'DD Error Handler End

End Function
  
'---------------------------------------------------------------------------------------
'DETCleanGivenProgramLocationDETDateSpecies
'---------------------------------------------------------------------------------------
' strSource is the Source field for Log_DETDaily()

Public Sub DETCleanGivenProgramLocationDETDateSpecies( _
    ByVal strProgram As String, _
    ByVal strLocation As String, _
    ByVal datDETDate As Date, _
    ByVal strSpecies As String, _
    ByVal fLog As Boolean, _
    ByVal strSource As String)
          
      Dim strWhere As String
      Dim qdf As DAO.QueryDef
      Dim rstDaily As DAO.Recordset

10    On Error GoTo Err_label

' I'm not going to delete the DETSpecies record when the DET > 0
' because otherwise when editing a capture record I'M losing DET info.
' The down side is that I can end up with DETSpecies records with DET > 0 but all the other fields are Null ...


20    strWhere = "[Program] = '" & strProgram & "' AND [Location] = '" & strLocation & "' AND [DateEx] = #" & Format(datDETDate, "mm/dd/yyyy") & "# AND [Species] = '" & strSpecies & "' AND " & _
      "Nz([Observed]) = 0 AND Nz([Census]) = 0 AND Nz([Banded]) = 0 AND nz([Repeats]) = 0 AND Nz([Returns]) = 0 AND " & _
      "Nz([PKS]) = 0 AND Nz([VisibleEx]) = 0 AND Nz([Casual]) = 0 AND Nz([Observed3]) = 0 AND Nz([Observed4]) = 0 AND " & _
      "Nz([NonStandardBanded]) = 0 AND Nz([NonStandardRecaps]) = 0 AND Nz([DailySpeciesTotal]) = 0 AND Nz([DET]) = 0"

30    If DCount("*", "tblDETSpecies", strWhere) > 0 Then
40        CurrentDb.Execute "DELETE * FROM tblDETSpecies WHERE " & strWhere
50        log ("Delete DET Species record " & strProgram & " " & Format(datDETDate, "d-mmm-yyyy") & " " & strSpecies)
       
          ' qryDETCleanGivenProgramLocationDETDate_DETDaily
          ' -----------------------------------------------
          ' tblDETDaily
          
          ' tblDETDaily.Program = argProgram
          ' tblDETDaily.Location = argLocation
          ' tblDETDaily.DateEx = argDateEx
          ' WHERE Nz(Observers) = 0 AND
          '       Nz(SongBirdNets) = 0 AND
          '       Nz(NonSongBirdNets) = 0 AND
          '       Nz(JTrap) = 0 AND
          '       Nz(OtherTrap) = 0 AND
          '       Nz(Heliogoland) = 0 AND
          '       Nz(VisibleMigration) = 0 AND
          '       Nz(CoverageCode) = 0 AND

          Dim fDelete As Boolean
          Dim strWHERE_AnyNonZeroEffortFields As String

60        strWhere = _
              "[Program] = '" & strProgram & "' AND " & _
              "[Location] = '" & strLocation & "' AND " & _
              "[DateEx] = #" & Format(datDETDate, "mm/dd/yyyy") & "#"
              
70        strWHERE_AnyNonZeroEffortFields = _
              " Nz([Observers]) > 0 OR" & _
              " Nz([SongBirdNets]) > 0 OR" & _
              " Nz([NonSongBirdNets]) > 0 OR" & _
              " Nz([JTrap]) > 0 OR" & _
              " Nz([OtherTrap]) > 0 OR" & _
              " Nz([Heliogoland]) > 0 OR" & _
              " Nz([VisibleMigration]) > 0 OR" & _
              " Nz([CoverageCode]) > 0"
              
          ' If there is no daily record then do not delete it
          ' ElseIf the daily record has at least one non-zero effort field then do not dlete it
          ' Elseif there any related tblDETSpecies records, do not delete the tblDaily record
          ' Elseif there any related tblDETNetHours records, do not delete the tblDaily record
          
80        If DCount("*", "tblDETDaily", strWhere) = 0 Then
90            fDelete = False
100       ElseIf DCount("*", "tblDETDaily", strWHERE_AnyNonZeroEffortFields) > 0 Then
110           fDelete = False
120       ElseIf DCount("*", "tblDETSpecies", strWhere) > 0 Then
130               fDelete = False
140       ElseIf DCount("*", "tblDETNetHours", strWhere) > 0 Then
150               fDelete = False
160       Else
170           fDelete = True
180       End If
              
190       If fDelete Then
200           CurrentDb.Execute "DELETE * FROM tblDETDaily WHERE " & strWhere

              ' Log
              
              Dim recDaily As DETDailyType
210           recDaily.Program = strProgram
220           recDaily.Location = strLocation
230           recDaily.DateEx = datDETDate
240           recDaily.Timestamp = Now()
250           recDaily.Command = "Delete"
260           recDaily.Source = strSource
270           Call Log_DETDaily(recDaily)

280           log ("Delete DET sheet " & strProgram & " " & Format(datDETDate, "d-mmm-yyyy"))
              
              Dim rec As DETDailyType
290           rec.Program = strProgram
300           rec.Location = strLocation
310           rec.DateEx = datDETDate
320           rec.Observers = Null
330           rec.SongbirdNets = Null
340           rec.NonSongbirdNets = Null
350           rec.JTrap = Null
360           rec.OtherTrap = Null
370           rec.Heliogoland = Null
380           rec.VisibleMigration = Null
390           rec.CoverageCode = Null
400           rec.Timestamp = Format(Now, "yyyy-mm-dd hh\hmm")
410           rec.Command = "Delete"
420           rec.Source = "DETCleanGivenProgramLocationDETDateSpecies"
430           Call Log_DETDaily(rec)
              
              
              
440       End If

450   End If
       
      'DD Error Handler Start
Exit_label:
460        Exit Sub
Err_label:
470        Select Case Err.Number
           Case Else
480             Call LogError("basDET", "DETCleanGivenProgramLocationDETDateSpecies")
490        End Select
500        Resume Exit_label
      'DD Error Handler End

          
End Sub

'---------------------------------------------------------------------------------------
' DETCleanGivenProgramLocationDETDate
' Buggy *** Do NOT call it.
'---------------------------------------------------------------------------------------
'
' This procedure only uses data from the arguments and the table records (no data from any form)
'
' There are two reasons to call this procedure
' [1] Enforce referential integrity, after some operations that could disrupted it.
' [2] Detect, report and repair referential integrity errors.
'
' If the key is valid
'   Delete all DETSpecies records with only null/0 non-key fields
'   Delete all DETNetHours records with only null/0 non-key fields
'
' Get the Daily record with no non-key data if there is one
    ' if there are no related tblDETSpecies records AND there are no related tblDETNetHours records then
    '   Delete the Daily record
'
' Are there any tblDETSpecies records with no corresponding tblDETDaily record.  If so add the parent.
' Are any tblDETNetHours records with no corresponding tblDETDaily record.  If so add the parent.
'
'   If there is at least one NetHours record (there must now also be a DETDaily record)
'      Replace Net Hours with the sum of the individual net hours
'
'Public Sub DETCleanGivenProgramLocationDETDate( _
'    ByVal strProgram As String, _
'    ByVal strLocation As String, _
'    ByVal datDateEx As Date, _
'    Optional ByVal fReportRerentialIntegrityErrors As Boolean = False)
'
'10    On Error GoTo Err_label
'
'      ' Verify the key is valid
'
'20    If Nz(strProgram, "") = "" Or Nz(strLocation, "") = "" Or Nz(datDateEx, 0) = 0 Then GoTo Exit_label
'
'      Dim qdf As QueryDef
'      Dim strWhere As String
'      Dim strSQL As String
'      Dim rst As DAO.Recordset
'      Dim rstDaily As DAO.Recordset
'
'      ' qryDETCleanGivenProgramLocationDETDate_DETSpecies
'      ' -------------------------------------------------
'      ' tblDETSpecies
'
'      ' DELETE query
'      ' Progam = [argProgram]
'      ' Location = [argLocation]
'      ' DateEx = [argDateEx]
'      ' WHERE Nz([Observed]) = 0 AND
'      '       Nz([Census]) = 0 AND
'      '       Nz([Banded]) = 0 AND
'      '       Nz([Repeats]) = 0 AND
'      '       Nz([Returns]) = 0 AND
'      '       Nz([PKS]) = 0 AND
'      '       Nz([VisibleEx]) = 0 AND
'      '       Nz([Casual]) = 0 AND
'      '       Nz([Observed3]) = 0 AND
'      '       Nz([Observed4]) = 0 AND
'      '       Nz([NonStandardBanded]) = 0 AND
'      '       Nz([NonStandardRecaps]) = 0 AND
'      '       Nz([DailySpeciesTotal]) = 0
'
'      ' Delete all tblDETSpecies records that have no non-key data
'
'30    Set qdf = CurrentDb.QueryDefs("qryDETCleanGivenProgramLocationDETDate_DETSpecies")
'40    qdf.Parameters("argProgram").value = strProgram
'50    qdf.Parameters("argLocation").value = strLocation
'60    qdf.Parameters("argDateEx").value = datDateEx
'70    qdf.Execute
'
'      ' qryDETCleanGivenProgramLocationDETDate_DETNetHours
'      ' --------------------------------------------------
'      ' tblDETNetHours
'      '
'      ' DELETE query
'      ' WHERE Program = argProgram
'      ' WHERE Location = argLocation
'      ' WHERE DateEx = argDateEx
'      ' WHERE Nz([NetHours]) = 0
'
'      ' Delete all tblDETNetHours records that have no non-key data
'
'80    Set qdf = CurrentDb.QueryDefs("qryDETCleanGivenProgramLocationDETDate_DETNetHours")
'90    qdf.Parameters("argProgram").value = strProgram
'100   qdf.Parameters("argLocation").value = strLocation
'110   qdf.Parameters("argDateEx").value = datDateEx
'120   qdf.Execute
'
'
'      ' qryDETCleanGivenProgramLocationDETDate_DETDaily
'      ' -----------------------------------------------
'      ' tblDETDaily
'
'      ' tblDETDaily.Program = argProgram
'      ' tblDETDaily.Location = argLocation
'      ' tblDETDaily.DateEx = argDateEx
'      ' WHERE Nz(Observed) = 0 AND
'      '       Nz(SongBirdNets) = 0 AND
'      '       Nz(NonSongBirdNets) = 0 AND
'      '       Nz(JTrap) = 0 AND
'      '       Nz(OtherTrap) = 0 AND
'      '       Nz(Heliogoland) = 0 AND
'      '       Nz(VisibleMigration) = 0 AND
'      '       Nz(CoverageCode) = 0 AND
'
'
'
'130   strWhere = _
'          "[Program] = '" & strProgram & "' AND " & _
'          "[Location] = '" & strLocation & "' AND " & _
'          "[DateEx] = #" & Format(datDateEx, "mm/dd/yyyy") & "#"
'
'      Dim fDelete As Boolean
'140   fDelete = False
'
'      ' Get the Daily record with no non-key data if there is one
'
'150   Set qdf = CurrentDb.QueryDefs("qryDETCleanGivenProgramLocationDETDate_DETDaily")
'160   qdf.Parameters("argProgram").value = strProgram
'170   qdf.Parameters("argLocation").value = strLocation
'180   qdf.Parameters("argDateEx").value = datDateEx
'190   Set rstDaily = qdf.OpenRecordset
'200   fDelete = Not rstDaily.EOF
'210   rstDaily.Close
'
'220   If fDelete Then
'
'          ' if there any related tblDETSpecies records, do not delete the tblDaily record
'
'230       If DCount("*", "tblDETSpecies", strWhere) > 0 Then
'240           fDelete = False
'250       End If
'
'          ' if there any related tblDETNetHours records, do not delete the tblDaily record
'
'260       If DCount("*", "tblDETNetHours", strWhere) > 0 Then
'270           fDelete = False
'280       End If
'
'290       If fDelete Then
'300           CurrentDb.Execute "DELETE * FROM tblDETDaily WHERE " & strWhere
'
'              Dim recDaily As DETDailyType
'310           recDaily.Program = Parent.Program
'320           recDaily.Location = Parent.Location
'330           recDaily.DateEx = Parent.DateEx
'340           recDaily.Command = "Delete"
'350           recDaily.Source = "DET Clean Given Program Location DateEx"
'360           Call Log_DETDaily(recDaily)
'
'370           log ("Delete DET sheet " & strProgram & " " & Format(datDateEx, "d-mmm-yyyy"))
'
'380           If fReportRerentialIntegrityErrors Then
'390               Call LogError("basDET", "DETCleanGivenProgramLocationDETDate", "Referential integrity error - Delete tblDETDaily " & strProgram & " " & strLocation & " " & datDateEx, Silent:=True, DeveloperErrNumber:=1)
'400           End If
'
'410           GoTo Exit_label
'420       End If
'
'430   End If
'
'      ' Are there any tblDETSpecies records with no corresponding tblDETDaily record.  If so add the parent.
'      ' Are any tblDETNetHours records with no corresponding tblDETDaily record.  If so add the parent.
'
'440   If DCount("*", "tblDETDaily", strWhere) = 0 Then
'450       If DCount("*", "tblDETSpecies", strWhere) > 0 Or DCount("*", "tblDETNetHours", strWhere) > 0 Then
'
'              ' Create a DETDaily record
'
'460           strSQL = _
'                 "INSERT INTO tblDETDaily( Program, Location, DateEx ) " & _
'                 "VALUES( '" & strProgram & "', " & _
'                 "        '" & strLocation & "', " & _
'                 "        #" & Format(datDateEx, "mm/dd/yyyy") & "#)"
'470           CurrentDb.Execute strSQL
'
'480           recDaily.Program = Parent.Program
'490           recDaily.Location = Parent.Location
'500           recDaily.DateEx = Parent.DateEx
'510           recDaily.Command = "Add"
'520           recDaily.Source = "DET Clean Given Program Location DateEx"
'530           Call Log_DETDaily(recDaily)
'
'540           If fReportRerentialIntegrityErrors Then
'550               Call LogError("basDET", "DETCleanGivenProgramLocationDETDate", "Referential integrity error - Add tblDETDaily " & strProgram & " " & strLocation & " " & datDateEx, Silent:=True, DeveloperErrNumber:=2)
'560           End If
'
'570       End If
'580   End If
'
'      '   If there is at least one NetHours record (there must now also be a DETDaily record)
'      '      Replace Net Hours with the sum of the individual net hours
'
'      Dim dblTotalPerNetNetHours As Double
'      Dim dblSongbirdnets As Double
'
'590   If DCount("*", "tblDETNetHours", strWhere) > 0 Then
'600       dblTotalPerNetNetHours = Nz(DSum("[NetHours]", "tblDETNetHours", strWhere))
'610       dblSongbirdnets = Nz(DLookup("[SongBirdNets]", "tblDETDaily", strWhere))
'620       If CLng(100 * dblTotalPerNetNetHours) <> CLng(100 * dblSongbirdnets) Then
'630           If fReportRerentialIntegrityErrors Then
'640               Call LogError("basDET", "DETCleanGivenProgramLocationDETDate", "Referential integrity error - Net Hours " & strProgram & " " & strLocation & " " & datDateEx & " SongBirdNets=" & dblSongbirdnets & " Total Per-net Net Hours=" & dblTotalPerNetNetHours, Silent:=True, DeveloperErrNumber:=3)
'650           End If
'660           strSQL = _
'                  " UPDATE tblDETDaily " & _
'                  " SET SongBirdNets = " & dblTotalPerNetNetHours & _
'                  " WHERE " & strWhere
'670           CurrentDb.Execute strSQL
'
'680           recDaily.Program = strProgram
'690           recDaily.Location = strLocation
'700           recDaily.DateEx = datDateEx
'710           recDaily.SongbirdNets = IIf(dblTotalPerNetNetHours > 0, dblTotalPerNetNetHours, Null)
'720           recDaily.Command = "Update Net Hours"
'730           recDaily.Source = "DET Clean Given Program Location DateEx"
'740           Call Log_DETDaily(recDaily)
'
'750       End If
'
'760   End If
'
'      'DD Error Handler Start
'Exit_label:
'770        Exit Sub
'Err_label:
'780        Select Case Err.Number
'           Case Else
'790       Call LogError("basDET", "DETCleanGivenProgramLocationDETDate")
'800        End Select
'810        Resume Exit_label
'      'DD Error Handler End
'End Sub

'---------------------------------------------------------------------------------------
' DETCleanGivenProgramLocationFromTo
'
' For the given Program, Location and between the given From and To DET dates
'     delete DETSpecies and DETNetHours records with no non-key data
'     fixup referential integrity (add/delete DETDaily records)
'
'---------------------------------------------------------------------------------------
' Called from UpdateDETProgram
'
' Delete all tblDETSpecies records that have no non-key data
' Delete all tblDETNetHours records that have no non-key data
' Get Daily records with no non-key data and no related Species records
'     if there any no related tblDETNetHours records, delete the tblDaily record
' Create a tdbDETDaily record if there are there any tblDETSpecies records with no corresponding parent tblDETDaily record
' Create a tdbDETDaily record if there are there any tblDETNetHours records with no corresponding tblDETDaily record

Private Sub DETCleanGivenProgramLocationFromTo( _
    ByVal strProgram As String, _
    ByVal strLocation As String, _
    ByVal datDETFrom As Date, _
    ByVal datDETTo As Date)

10    On Error GoTo Err_label

      Dim qdf As QueryDef
      Dim strWhere As String
      Dim rst As DAO.Recordset
      Dim rstDaily As DAO.Recordset

      ' Delete all tblDETSpecies records that have no non-key data

      ' qryDETCleanGivenProgramLocationFromTo_DETSpecies
      ' ------------------------------------------------
      ' DELETE query - tblDETSpecies
      ' WHERE Nz(Observed) = 0, AND
      ' WHERE Nz(Census) = 0
      ' WHERE Nz(Banded) = 0
      ' WHERE Nz(Reprats) = 0
      ' WHERE Nz(Returns) = 0
      ' WHERE Nz(PKS) = 0
      ' WHERE Nz(DET) = 0
      ' WHERE Nz(VisibleEx) = 0
      ' WHERE Nz(Casual) = 0
      ' WHERE Nz(Observed3) = 0
      ' WHERE Nz(Observed4) = 0
      ' WHERE Nz(NonStandardBanded) = 0
      ' WHERE Nz(NonStandardrecaps) = 0
      ' WHERE Nz(DailySpeciesTotal) = 0
      ' WHERE Program = argProgram
      ' WHERE Location = argLocation
      ' WHERE DateEX BETWEEN argFrom AND argTo

20    Set qdf = CurrentDb.QueryDefs("qryDETCleanGivenProgramLocationFromTo_DETSpecies")
30    qdf.Parameters("argProgram").value = strProgram
40    qdf.Parameters("argLocation").value = strLocation
50    qdf.Parameters("argFrom").value = datDETFrom
60    qdf.Parameters("argTo").value = datDETTo
70    qdf.Execute

      ' Delete all tblDETNetHours records that have no non-key data

      ' qryDETCleanGivenProgramLocationFromTo_DETNetHours
      ' -----------------------------------------------------
      ' DELETE query - tblDETNetHours
      ' WHERE Nz(NetHours) = 0
      ' WHERE Program = argProgram
      ' WHERE Location = argLocation
      ' WHERE DateEX BETWEEN argFrom AND argTo

80    Set qdf = CurrentDb.QueryDefs("qryDETCleanGivenProgramLocationFromTo_DETNetHours")
90    qdf.Parameters("argProgram").value = strProgram
100   qdf.Parameters("argLocation").value = strLocation
110   qdf.Parameters("argFrom").value = datDETFrom
120   qdf.Parameters("argTo").value = datDETTo
130   qdf.Execute

      ' Get Daily records with no non-key data and no related Species records

      ' qryDETCleanGivenProgramLocationFromTo_DETDaily
      ' -----------------------------------------------
      ' tblDETDaily LEFT JOIN tblDETSpecies
      ' WHERE tblDETSpecies.Program Is Null, AND
      ' WHERE Nz(Observers) = 0
      ' WHERE Nz(SongBirdNets) = 0
      ' WHERE Nz(NonSongBidNets) = 0
      ' WHERE Nz(JTrap) = 0
      ' WHERE Nz(OtherTrap) = 0
      ' WHERE Nz(Heliogoland) = 0
      ' WHERE Nz(CoverageCode) = 0
      ' WHERE Program = argProgram
      ' WHERE Location = argLocation
      ' WHERE DateEX BETWEEN argFrom AND argTo
      ' Report Program, Location, DateEx

140   Set qdf = CurrentDb.QueryDefs("qryDETCleanGivenProgramLocationFromTo_DETDaily")
150   qdf.Parameters("argProgram").value = strProgram
160   qdf.Parameters("argLocation").value = strLocation
170   qdf.Parameters("argFrom").value = datDETFrom
180   qdf.Parameters("argTo").value = datDETTo
190   Set rstDaily = qdf.OpenRecordset
200   If Not rstDaily.EOF Then
          
          ' if there any no related tblDETNetHours records, delete the tblDaily record
          
          Dim datDateEx As Date
          
210       datDateEx = Nz(rstDaily("DateEx"))
          
220       strWhere = _
              "[Program] = '" & strProgram & "' AND " & _
              "[Location] = '" & strLocation & "' AND " & _
              "[DateEx] = #" & Format(datDateEx, "mm/dd/yyyy") & "#"
          
230       If 0 = DCount("*", "tblDETNetHours", strWhere) Then
240           rstDaily.Delete
250       End If

260   End If
270   rstDaily.Close

      ' Are there any tblDETSpecies records with no corresponding parent tblDETDaily record

      ' qryDETMissingDailyGivenProgramLocationFromTo_DETSpecies
      ' ----------------------------------------------------
      ' tblDETSpecies LEFT JOIN tblDETDaily
      ' WHERE tblDETDaily.Program Is Null
      ' WHERE Program = argProgram
      ' WHERE Location = argLocation
      ' WHERE DateEX BETWEEN argFrom AND argTo
      ' UNIQUE VALUES Report Program, Location, DateEx
      '
      ' qryDETMissingDailyGivenProgramLocationFromTo_DETSpecies_Append
      ' -----------------------------------------------------------
      ' qryDETMissingDailyGivenProgramLocationFromTo_DETSpecies
      ' append to tblDETDaily

280   Set qdf = CurrentDb.QueryDefs("qryDETMissingDailyGivenProgramLocationFromTo_DETSpecies_Append")
290   qdf.Parameters("argProgram").value = strProgram
300   qdf.Parameters("argLocation").value = strLocation
310   qdf.Parameters("argFrom").value = datDETFrom
320   qdf.Parameters("argTo").value = datDETTo
330   qdf.Execute

      ' Are there any tblDETNetHours records with no corresponding tblDETDaily record

      ' qryDETMissingDailyGivenProgramLocationFromTo_NetHours
      ' -----------------------------------------------------
      ' tblDETNetHours LEFT JOIN tblDETDaily
      ' WHERE tblDETDaily.Program Is Null
      ' WHERE Program = argProgram
      ' WHERE Location = argLocation
      ' WHERE DateEX BETWEEN argFrom AND argTo
      ' UNIQUE VALUES Report Program, Location, DateEx
      '
      ' qryDETMissingDailyGivenProgramLocationFromTo_NetHours_Append
      ' ------------------------------------------------------------
      ' qryDETMissingDailyGivenProgramLocationFromTo_NetHours
      ' append to tblDETDaily

340   Set qdf = CurrentDb.QueryDefs("qryDETMissingDailyGivenProgramLocationFromTo_NetHours_Append")
350   qdf.Parameters("argProgram").value = strProgram
360   qdf.Parameters("argLocation").value = strLocation
370   qdf.Parameters("argFrom").value = datDETFrom
380   qdf.Parameters("argTo").value = datDETTo
390   qdf.Execute


      'DD Error Handler Start
Exit_label:
400        Exit Sub
Err_label:
410        Select Case Err.Number
           Case Else
420       Call LogError("basDET", "DETCleanGivenProgramLocationFromTo")
430        End Select
440        Resume Exit_label
      'DD Error Handler End
End Sub

''---------------------------------------------------------------------------------------
'' DETCategoryBand
''
'' Recalcalculate the DET Category (D18) for every capture record of the given band
''---------------------------------------------------------------------------------------
'
'Public Sub DETCategoryBand(ByVal strPrefix As String, ByVal strSuffix As String)
'
'10    On Error GoTo Err_label
'
'      Dim strSQL As String
'      Dim rst As DAO.Recordset
'      Dim IDBand As Long
'      Dim strCategory As String
'      Dim strReasonDETCategoryUnknown As String
'      Dim lngDaysSinceMostRecentPriorCapture As Long
'      Dim datCaptureDate As Date
'      Dim varWeightTime As Variant
'      Dim strProgram As String
'      Dim datDETDate As Date
'      Dim fLog As Boolean
'
'20    fLog = True
'
'30    strSQL = _
'          "SELECT * FROM tblCaptures " & _
'          "WHERE [BandPrefix] = '" & strPrefix & "' AND [BandSuffix] = '" & strSuffix & "'"
'40    Set rst = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)
'50    Do While Not rst.EOF
'60        IDBand = Nz(rst("IDBand"))
'70        datCaptureDate = Nz(rst("CaptureDate"))
'80        varWeightTime = rst("WeightTime")
'90        strProgram = Nz(rst("Program"))
'
'100       Call DETCategory(IDBand, strCategory, strReasonDETCategoryUnknown, lngDaysSinceMostRecentPriorCapture)
'110       datDETDate = getDETDate(datCaptureDate, varWeightTime, strProgram)
'
'120       Call Update_D18_D20_D21(rst, strCategory, lngDaysSinceMostRecentPriorCapture, datDETDate, fLog, "Update capture DET")
'
'      '    rst.Edit
'      '    rst("D18") = strCategory
'      '    If strCategory = "Return" Or strCategory = "Repeat" Then
'      '        rst("D20") = lngDaysSinceMostRecentPriorCapture
'      '    Else
'      '        rst("D20") = Null
'      '    End If
'      '    rst.Update
'
'130       rst.MoveNext
'140   Loop
'150   rst.Close
'160   Set rst = Nothing
'
'      'DD Error Handler Start
'Exit_label:
'170        Exit Sub
'Err_label:
'180        Select Case Err.Number
'           Case Else
'190             Call LogError("basDET", "DETCategoryBand")
'200        End Select
'210        Resume Exit_label
'      'DD Error Handler End
' End Sub
  
'---------------------------------------------------------------------------------------
' DETCategory

' Determine the DET Category of a capture record

' *** This procedure is read-only ***

' The only valid sequences of capture Dispositions are:
' 1 .... R .... R ....
' 5 .... R .... R ....
' F .... F .... F ....
'
' The above sequences are independent of program and location

' PRE: IDBand is valid

' if fDETCategoryOverride = False, then ignore DET Category Override (D2)

' if the band is a BALO or BADE, or of disposition 4 or 8, return DETCategory = "None"

' Return DETCategory = "Unknown", if
'     this capture record's disposition is unknown, or
'     this capture record's disposition is "R" or "F" and there is at least one capture record for this band with an
'          unknown disposition OR with no capture date OR with an unknown location, or
'     there are same day captures for this band

' DETCategory
' -----------
' Banded
' Return
' Repeat
' Alien
' Replacement
' Unknown
' None
'---------------------------------------------------------------------------------------

Public Sub DETCategory(ByVal IDBand As Long, _
    ByRef strDETCategory As String, _
    ByRef strReasonDETCategoryUnknown As String, _
    ByRef lngDaysSinceMostRecentPriorCapture As Long, _
    Optional ByVal fDETCategoryOverride As Boolean = True)
  
    Dim strBandPrefix As String
    Dim strBandSuffix As String
    Dim datCaptureDate As Date
    Dim strSpecies As String
    Dim strLocation As String
   
On Error GoTo Err_label

Dim strSQL As String
Dim rstCaptures As DAO.Recordset

Dim strDisposition As String
Dim strDETCategoryOverride As String

strSQL = "SELECT * FROM tblCaptures WHERE [IDBand] = " & IDBand
Set rstCaptures = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)

strDETCategory = "None"
strReasonDETCategoryUnknown = ""
lngDaysSinceMostRecentPriorCapture = 0

If rstCaptures.EOF Then
    strDETCategory = "Unknown"
    strReasonDETCategoryUnknown = _
        "IDBand=" & IDBand & " - No capture record"
    GoTo Return_label
End If

' Read values from tblCaptures

strBandPrefix = Nz(rstCaptures("BandPrefix"))
strBandSuffix = Nz(rstCaptures("BandSuffix"))
strDisposition = Nz(rstCaptures("Disposition"))
datCaptureDate = CDate(Nz(rstCaptures("CaptureDate")))
strSpecies = Nz(rstCaptures("Species"))
strDETCategoryOverride = Nz(rstCaptures("D2"), "")
strLocation = Nz(rstCaptures("Location"), "")

' Skip tblCapture records with Disposition 4, 8 - the DET Category is "None"

If strDisposition = "4" Or strDisposition = "8" Then
    strDETCategory = "None"
    GoTo Return_label
End If

' Skip tblCapture records with Species BADE or BALO - the DET Category is "None"

If strSpecies = "BADE" Or strSpecies = "BALO" Then
    strDETCategory = "None"
    GoTo Return_label
End If

' If the capture record has an explicit DET Category Override value
' then simply use that value.

If fDETCategoryOverride Then
    If strDETCategoryOverride <> "" Then
        strDETCategory = strDETCategoryOverride
        GoTo Return_label
    End If
End If


        
Dim strCriterionLocation As String
Dim strCriterionBand As String
Dim strCriterionDisposition_1_5_F_R As String
Dim strCriterion  As String
Dim strCriterionPriorCaptureDate As String
Dim strCriterionNotIDBand As String
Dim strCriterionSameCaptureDate As String

' If there are any same-day captures at any location or in any program
' give up, and set the DET Category to "Unknown"

strCriterionNotIDBand = "([IDBand] <> " & IDBand & ")"
strCriterionBand = "(BandPrefix = '" & strBandPrefix & "' AND " & _
     "BandSuffix  = '" & strBandSuffix & "')"
strCriterionDisposition_1_5_F_R = _
    "((Disposition  = '1') or (Disposition = '5')  or (Disposition = 'F') or (Disposition = 'R'))"
strCriterionSameCaptureDate = "(CaptureDate = " & _
        "#" & Format(datCaptureDate, "mm/dd/yyyy") & "#)"
    
strCriterion = _
    strCriterionNotIDBand & " AND " & _
    strCriterionBand & " AND " & _
    strCriterionDisposition_1_5_F_R & " AND " & _
    strCriterionSameCaptureDate

If DCount("*", "tblCaptures", strCriterion) > 1 Then
    strDETCategory = "Unknown"
    strReasonDETCategoryUnknown = _
        "IDBand=" & IDBand & " " & _
        strBandPrefix & strBandSuffix & " " & strSpecies & " " & _
        Format(datCaptureDate, "dd mmm yyyy") & " - Multiple same day captures"
    GoTo Return_label
End If
  
Select Case strDisposition

Case "1"

    strDETCategory = "Banded"
  
Case "5"

    strDETCategory = "Replacement"
   
Case "R", "F"

    Dim fIsFirstCaptureAtThisLocation As Boolean
    Dim fReturn As Boolean
    Dim strDisposition_x As String
    Dim strLocation_x As String
    Dim datCaptureDate_x As Date
        
    Dim rst As DAO.Recordset
    Set rst = CurrentDb.OpenRecordset("SELECT * FROM tblCaptures WHERE " & strCriterionBand)
    Do While Not rst.EOF
        strDisposition_x = rst("Disposition")
        strLocation_x = rst("Location")
        datCaptureDate_x = rst("CaptureDate")
        
        Select Case strDisposition
            Case "1", "5", "F", "R", "4", "8"
            Case Else
                strDETCategory = "Unknown"
                strReasonDETCategoryUnknown = _
                    strBandPrefix & strBandSuffix & "  There is at least one capture record with an unknown disposition"
                GoTo Return_label
           End Select
    
        If Trim(strLocation) = "" Then
                strDETCategory = "Unknown"
                strReasonDETCategoryUnknown = _
                    strBandPrefix & strBandSuffix & "  There is at least one capture record with an unknown location"
                GoTo Return_label
        End If
    
        If datCaptureDate = 0 Then
                strDETCategory = "Unknown"
                strReasonDETCategoryUnknown = _
                    strBandPrefix & strBandSuffix & "  There is at least one capture record with an unknown capture date"
                GoTo Return_label
        End If
    
        rst.MoveNext
    Loop
    rst.Close
    Set rst = Nothing

    
    ' Was this capture the first capture at this location ?

    strCriterionLocation = "(Location = '" & strLocation & "')"
    strCriterionPriorCaptureDate = "(CaptureDate < " & _
        "#" & Format(datCaptureDate, "mm/dd/yyyy") & "#)"

    strCriterion = _
        strCriterionNotIDBand & " AND " & _
        strCriterionBand & " AND " & _
        strCriterionDisposition_1_5_F_R & " AND " & _
        strCriterionPriorCaptureDate & " AND " & _
        strCriterionLocation
    
    fIsFirstCaptureAtThisLocation = (DCount("*", "tblCaptures", strCriterion) = 0)
    
    If fIsFirstCaptureAtThisLocation Then

        ' disposition = "R" or "F"
        ' this is the first capture at this location
        
            strDETCategory = "Alien"
    Else
    
        ' disposition = "R" or "F"
        ' this is not the first capture at this location
        
        ' Distinguish between Repeat and Return
        ' A Return" is any band recaptured within 90
        ' days of its previous capture at this location
        
        Dim datCaptureDatePrior As Date
        Dim strWhere As String
        
        strWhere = _
            "[BandPrefix] = '" & strBandPrefix & "' AND " & _
            "[BandSuffix] = '" & strBandSuffix & "' AND " & _
            "[CaptureDate] < #" & Format(datCaptureDate, "mm/dd/yyyy") & "# AND " & _
            "[Location] = '" & strLocation & "' AND " & _
            "[Disposition] IN ('1','5','F','R')"
            
        datCaptureDatePrior = Nz(DMax("CaptureDate", "tblCaptures", strWhere))
        
        If datCaptureDatePrior <> 0 Then
            lngDaysSinceMostRecentPriorCapture = datCaptureDate - datCaptureDatePrior
            fReturn = (lngDaysSinceMostRecentPriorCapture > 90)
        Else
            strDETCategory = "Unknown"
            strReasonDETCategoryUnknown = _
                "IDBand=" & IDBand & " " & _
                strBandPrefix & strBandSuffix & " " & strSpecies & " " & _
                Format(datCaptureDate, "dd mmm yyyy") & " - Internal error"
                GoTo Return_label
        End If
        
        strDETCategory = IIf(fReturn, "Return", "Repeat")

    End If
    
Case Else

    strDETCategory = "Unknown"
    strReasonDETCategoryUnknown = _
        "IDBand=" & IDBand & " " & _
            strBandPrefix & strBandSuffix & " " & strSpecies & " " & _
            Format(datCaptureDate, "dd mmm yyyy") & " - Unknown disposition"
            
End Select
             
Return_label:

 rstCaptures.Close
 Set rstCaptures = Nothing

'DD Error Handler Start
Exit_label:
     Exit Sub
Err_label:
     Select Case Err.Number
     Case Else
          Call LogError("basDET", "DETCategory")
     End Select
     Resume Exit_label
'DD Error Handler End

End Sub
 
'---------------------------------------------------------------------------------------
' UpdateDETCategory
'
' Recalculates D18 (DETCategory) and D20 (Days since most recent prior capture) for each
'     capture record
'
' For all capture records in given Program, Location, and between two dates
'
' The only valid capture sequences are:
' 1 .... R .... R ....
' 5 .... R .... R ....
' F .... F .... F ....
'---------------------------------------------------------------------------------------

Public Sub UpdateDETCategory( _
    ByVal strProgram As String, ByVal strLocation As String, _
    ByVal datFrom As Date, ByVal datTo As Date, _
    ByRef rstDETNoCategory As DAO.Recordset)

10    On Error GoTo Err_label

'      Dim strBandPrefix As String
'      Dim strBandSuffix As String
'      Dim datCaptureDate As Date
'      Dim strSpecies As String

      Dim lngDaysSinceMostRecentPriorCapture As Long

      ' Get capture records for the given program AND location AND
      ' capture date is between datFrom and datTo inclusive

      Dim strSQL As String
20    strSQL = "SELECT * FROM tblCaptures " & _
         "WHERE [Program] = '" & strProgram & "' AND " & _
         "      [Location] = '" & strLocation & "' AND " & _
         "      [CaptureDate] BETWEEN #" & Format(datFrom, "mm/dd/yyyy") & "#" & _
                                " AND #" & Format(datTo, "mm/dd/yyyy") & "#"
                                
      Dim rstCaptures As DAO.Recordset

30    Set rstCaptures = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)

      Dim strCategory As String
      Dim strReasonDETCategoryUnknown As String

40    Do While Not rstCaptures.EOF

          Dim IDBand As Long
50        IDBand = Nz(rstCaptures("IDBand"))
          
60        Call DETCategory(IDBand, strCategory, strReasonDETCategoryUnknown, lngDaysSinceMostRecentPriorCapture)
          
70        If strCategory = "Unknown" Then
80            rstDETNoCategory.AddNew
90            rstDETNoCategory("Description") = strReasonDETCategoryUnknown
100           rstDETNoCategory.Update
110       End If

120       rstCaptures.Edit
130       rstCaptures("D18") = strCategory
140       If strCategory = "Return" Or strCategory = "Repeat" Then
150           rstCaptures("D20") = lngDaysSinceMostRecentPriorCapture
160       Else
170           rstCaptures("D20") = Null
180       End If
190       rstCaptures.Update
              
200       rstCaptures.MoveNext
210    Loop
       
220    rstCaptures.Close

      'DD Error Handler Start
Exit_label:
230        Exit Sub
Err_label:
240        Select Case Err.Number
           Case Else
250             Call LogError("basDET", "UpdateDETCategory")
260        End Select
270        Resume Exit_label
      'DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' Create_tblDET3
'
' PRE: D18 (DETCategory) and D20 (Days since most recent prior capture) for each capture record are correct
'
' This procedure was coded before capture records had a D21 (DET Date) field.  To be on the
' safe side, I will continue to not use D21 in this procedure.
'
' tblDET3 is a temporary table used during the generation of the
' pseudo-species Banded, Repeats, Returns, Alien and Replacement report from banding records and
' to fill in the DET Banded, Repeats, Returns, Aliens and Replaced columns from capture records
'
' The report date (= DET date) is the same as the capture date, except for
' Owling programs. For captures before midnight, the DET date = capture date; for captures after
' midnight report date = capture date - 1.
'
' tblDET3 has one record per Capture Date. It contains
'       ID (autonumber)
'       Program     will be the same for all records
'       Location    will be the same for all records
'       DateEx      DET date
'       Species     pseudo-species
'       Banded      count of disposition 1 records
'       Return
'       Repeat
'       Alien
'       Replacement
'       Unknown
'
' cntRecords = number of records in tblDET3
'
' Caveat: The datFrom and datTo dates are capture dates (not DET dates)
' They differ from DET dates for Owling programs (only)
' ---------------------------------------------------------
 
Public Sub Create_tblDET3( _
    ByRef cntRecords As Long, _
    ByVal strProgram As String, _
    ByVal strLocation As String, _
    ByVal strCreateOrAppend As String, _
    Optional ByVal datFrom As Date = #1/1/1900#, _
    Optional ByVal datTo As Date = #1/1/3000#)
    
    
On Error GoTo Err_label

' qryDET3
' ------------------------------------------------------
' Ignore capture records with DETCategory "None" or NULL
' Calculate the ReportDate (= DET Date)
' ------------------------------------------------------
' tblCapture x tblPrograms
'
' Location = argLocation
' Program = argProgram
' Capture Date BETWEEN argDateFrom AND argDateTo
' DETCategory = D18 IN ("Banded","Repeat","Return","Alien","Replacement","Unknown")
' ReportDate = getReportDate(CaptureDate,MonitoringProgramSeason,WeightTime)
' Report BandPrefix, BndSuffix, ReportDate, Species, DETCategory
     
' qryDET3_crosstab
' ----------------
' Crosstab query based on qryDET3
'
' ReportDate:  Group By, Row Heading
' Species:     Group By Row Heading
' Category:    Group By Column Heading
' Expr3:       Sum(1) - Expression - Value
' Column Headings: Banded, Repeat, Return, Alien, Replacement, Unknown
' Report ReportDate, Species,  Banded, Repeat, Return, Alien, Replacement, Unknown


' qryDET3_appendtable
' -------------------
' qryDET3_crosstab
' appends records to tblDET3, obvious correspondance of fields


' tblDET3
' -------
' Program
' Location
' DateEx              the report date (= DET date)
' Species
' Banded
' Return
' Repeat
' Alien
' Replacement
' Unknown

If strCreateOrAppend = "Create" Then

    ' ZAP tblDET3

    CurrentDb.Execute "DELETE * FROM tblDET3"

End If
'
'Dim rstDET As DAO.Recordset
'Dim rstDET3 As DAO.Recordset

Dim qdf As QueryDef
Set qdf = CurrentDb.QueryDefs("qryDET3_appendtable")
qdf.Parameters("argProgram").value = strProgram
qdf.Parameters("argLocation").value = strLocation
qdf.Parameters("argDateFrom").value = datFrom
qdf.Parameters("argDateTo").value = datTo
qdf.Execute


'Set rstDET = qdf.OpenRecordset
'
'Set rstDET3 = CurrentDb.OpenRecordset("tblDET3", dbOpenDynaset)
'
'cntRecords = 0
'
'Dim fBanded      As Boolean
'Dim fReturn      As Boolean
'Dim fRepeat      As Boolean
'Dim fAlien       As Boolean
'Dim fReplacement As Boolean
'Dim fUnknown     As Boolean
'
'Dim lngStat As Long
'
'If Not rstDET.EOF Then
'
'    Err.Clear
'    On Error Resume Next
'    lngStat = Nz(rstDET.Fields("Banded"), 0)
'    fBanded = (Err.Number = 0)
'
'    Err.Clear
'    On Error Resume Next
'    lngStat = Nz(rstDET.Fields("Return"), 0)
'    fReturn = (Err.Number = 0)
'
'    Err.Clear
'    On Error Resume Next
'    lngStat = Nz(rstDET.Fields("Repeat"), 0)
'    fRepeat = (Err.Number = 0)
'
'    Err.Clear
'    On Error Resume Next
'    lngStat = Nz(rstDET.Fields("Alien"), 0)
'    fAlien = (Err.Number = 0)
'
'    Err.Clear
'    On Error Resume Next
'    lngStat = Nz(rstDET.Fields("Replacement"), 0)
'    fReplacement = (Err.Number = 0)
'
'    Err.Clear
'    On Error Resume Next
'    lngStat = Nz(rstDET.Fields("Unknown"), 0)
'    fUnknown = (Err.Number = 0)
'
'    Err.Clear
'End If
'
'Do While Not rstDET.EOF
'    rstDET3.AddNew
'    cntRecords = cntRecords + 1
'    rstDET3.Fields("Program") = strProgram
'    rstDET3.Fields("Location") = strLocation
'    rstDET3.Fields("DateEx") = rstDET.Fields("ReportDate")
'    rstDET3.Fields("Species") = rstDET.Fields("Species")
'
'    If fBanded Then
'        rstDET3("Banded") = Nz(rstDET.Fields("Banded"), 0)
'    Else
'        rstDET3("Banded") = 0
'    End If
'
'    If fReturn Then
'        rstDET3("Return") = Nz(rstDET.Fields("Return"), 0)
'    Else
'        rstDET3("Return") = 0
'    End If
'
'    If fRepeat Then
'        rstDET3("Repeat") = Nz(rstDET.Fields("Repeat"), 0)
'    Else
'        rstDET3("Repeat") = 0
'    End If
'
'    If fAlien Then
'        rstDET3("Alien") = Nz(rstDET.Fields("Alien"), 0)
'    Else
'        rstDET3("Alien") = 0
'    End If
'
'    If fReplacement Then
'        rstDET3("Replacement") = Nz(rstDET.Fields("Replacement"), 0)
'    Else
'        rstDET3("Replacement") = 0
'    End If
'
'    If fUnknown Then
'        rstDET3("Unknown") = Nz(rstDET.Fields("Unknown"), 0)
'    Else
'        rstDET3("Unknown") = 0
'    End If
'
'    rstDET3.Update
'    rstDET.MoveNext
'Loop
'
'rstDET3.Close
'rstDET.Close
'
'


'DD Error Handler Start
Exit_label:
     Exit Sub
Err_label:
     Select Case Err.Number
     Case Else
    Call LogError("basDET", "Create_tblDET3")
     End Select
     Resume Exit_label
'DD Error Handler End

End Sub

''---------------------------------------------------------------------------------------
'' Form_Open
''
'' Called from frmDeleteSheet
''---------------------------------------------------------------------------------------
'
'Public Sub Form_Open(frm As Form, Cancel As Integer)
'
'10    On Error GoTo Err_label
'
'30        frm.txtProgram = argDET_Program
'40        frm.txtLocation = argDET_Location
'50        frm.txtDate = argDET_DateEx
'60        If Nz(frm.txtProgram) <> "" Then
'70            If DLookup("Locked", "tblPrograms", "Program = '" & frm.txtProgram & "'") Then
'80                MsgBox "Unlock the Monitoring Program before moving the DET sheet", , "Move DET sheet"
'90                Cancel = True
'100           ElseIf Nz(frm.txtLocation) <> "" And Nz(frm.txtDate) <> "" Then
'110           Else
'120               MsgBox "Monitoring Program, Location and Date are required"
'130               Cancel = True
'140           End If
'150       End If
'
'      'DD Error Handler Start
'Exit_label:
'200        Exit Sub
'Err_label:
'210        Select Case Err.Number
'           Case Else
'220             Call LogError("basDET", "Form_Open")
'230        End Select
'240        Resume Exit_label
'      'DD Error Handler End
'End Sub

'---------------------------------------------------------------------------------------
' DETCMMNDETExcelSpreadsheetExport
'
' Export DET Daily and Species records into a CMMN DET Spreadsheet compatible .xlsm file
'---------------------------------------------------------------------------------------
'
' Replace CANG with CAGO

Public Sub DETCMMNDETExcelSpreadsheetExport( _
    ByVal strProgram As String, ByVal strLocation As String)
          
10    On Error GoTo Err_label

      Dim strSQL As String

      ' Delete tblDETDailyExportExcel

20    DoCmd.SetWarnings False
30    On Error Resume Next
40    DoCmd.DeleteObject acTable, "tblDETDailyExportExcel"
50    On Error GoTo Err_label
60    DoCmd.SetWarnings True

      ' Delete tblDETSpeciesExportExcel

70    DoCmd.SetWarnings False
80    On Error Resume Next
90    DoCmd.DeleteObject acTable, "tblDETSpeciesExportExcel"
100   On Error GoTo Err_label
110   DoCmd.SetWarnings True

      ' Get the CMMN Site Code

      Dim strCMMNSiteCode As String
120   strCMMNSiteCode = GetCMMNSiteCode()

      ' Phase 2 - Copy records from tblDETDaily to tblDETDailyExportExcel
      '           Copy records from tblDETSpecies to tblDETSpeciesExportExcel

      Dim strClauseProgram As String
      Dim strClauseLocation As String
      Dim strClauseDateEX As String

130   strClauseProgram = "( Program = '" & strProgram & "')"
140   strClauseLocation = "(Location = '" & strLocation & "')"
150   strClauseDateEX = "True"

      '140   strClauseDateEX = "(DateEx Between #" & Format(datFrom, "mm/dd/yyyy") & "# " & _
                       " And #" & Format(datTo, "mm/dd/yyyy") & "#)"
                       
      Dim strFieldname As String
      Dim strEffortName As String
      Dim strEffortDefinition As String
      Dim strEffortUnits As String

      Dim rstEffort As DAO.Recordset
160   strSQL = "SELECT * FROM tblDETDesignEffort WHERE EffortExportedToCMMNDETSpreadsheet"
170   Set rstEffort = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)
      Dim i As Integer
180   i = 0
190   Do While Not rstEffort.EOF
200       i = i + 1
          
210       strFieldname = Nz(rstEffort("Fieldname"), "")
220       strEffortName = "Effort" & Nz(rstEffort("EffortNumber"), 0)
230       strEffortDefinition = Nz(rstEffort("EffortDefinition"), "")
240       strEffortUnits = Nz(rstEffort("EffortUnits"), "")
          
250       If i = 1 Then
          
          ' Create the tblDETDailyExportExcel table
          
260           strSQL = _
                  "SELECT " & _
                      "DateEx as [date], " & _
                      "'" & strCMMNSiteCode & "' as area,  " & _
                      "'" & strEffortName & "' as field, " & _
                      "'" & strEffortDefinition & "' as description, " & _
                      strFieldname & " as [value], " & _
                      "'" & strEffortUnits & "' as units, " & _
                      "Null as start, Null as end " & _
                  "INTO tblDETDailyExportExcel " & _
                  "FROM tblDETDaily " & _
                  "WHERE " & _
                      strClauseProgram & " AND " & _
                      strClauseLocation & " AND " & _
                      strClauseDateEX
270           CurrentDb.Execute strSQL
          
280       Else
          
          ' Append to the tblDETDailyExportExcel table
          
290            strSQL = _
                  "INSERT INTO tblDETDailyExportExcel " & _
                  "SELECT " & _
                      "DateEx as [date], " & _
                      "'" & strCMMNSiteCode & "' as area,  " & _
                      "'" & strEffortName & "' as field, " & _
                      "'" & strEffortDefinition & "' as description, " & _
                      strFieldname & " as [value], " & _
                      "'" & strEffortUnits & "' as units, " & _
                      "Null as start, Null as end " & _
                  "FROM tblDETDaily " & _
                  "WHERE " & _
                      strClauseProgram & " AND " & _
                      strClauseLocation & " AND " & _
                      strClauseDateEX
300           CurrentDb.Execute strSQL
          
310       End If

320       rstEffort.MoveNext
330   Loop
340   rstEffort.Close
                       
350   strSQL = _
        "SELECT " & _
        "DateEX as [date], " & _
        "'" & strCMMNSiteCode & "' as area,  " & _
        "tblDETSpecies.Species as spcd, " & _
        "SpeciesDescriptionCMMN as spname, " & _
        "Banded as band, " & _
        "Returns as recap, " & _
        "Repeats as repeat, " & _
        "census, " & _
        "VisibleEx as visible, Observed as obs, " & _
        "Null as obs1, Casual as obs2, " & _
        "Null as obs3, Null as obs4, pks, " & _
        "NonStandardBanded as nsband, " & _
        "NonStandardRecaps as nsrec, " & _
        "DET as et, " & _
        "'Program=" & strProgram & "' as comments " & _
        "INTO tblDETSpeciesExportExcel " & _
        "FROM tblDETSpecies INNER JOIN tblSpecies ON tblDETSpecies.Species = tblSpecies.Species " & _
        "WHERE " & _
        strClauseProgram & " AND " & _
        strClauseLocation & " AND " & _
        strClauseDateEX & " " & _
        "ORDER BY DateEx, DETOrder;"
360   CurrentDb.Execute strSQL

      ' Special Case CANG => CAGO

370   strSQL = _
          "UPDATE tblDETSpeciesExportExcel SET spcd = 'CAGO' WHERE spcd = 'CANG'"
380   CurrentDb.Execute strSQL

      ' Open recordsets to tblDETDaily and tblDETSpecies

      Dim rstDaily As DAO.Recordset
      Dim rstSpecies As DAO.Recordset
390   strSQL = "SELECT * FROM tblDETDailyExportExcel ORDER BY [Date], Field"
400   Set rstDaily = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)
410   Set rstSpecies = CurrentDb.OpenRecordset("tblDETSpeciesExportExcel", dbOpenDynaset)

      ' Phase 3 - Export to Excel

      Dim oExcel As Excel.Application
      Dim oBook As Excel.Workbook
      Dim oSheetDaily As Excel.Worksheet
      Dim oSheetSpecies As Excel.Worksheet

420   Set oExcel = New Excel.Application
430   Set oBook = oExcel.Workbooks.Add
435   Call ExcelDeleteAllButFirstWorksheet(oBook)

440   Set oSheetDaily = oBook.Worksheets(1)
450   oSheetDaily.Name = "effort_data"
490   Set oSheetSpecies = oBook.Sheets.Add
500   oSheetSpecies.Name = "det_data"

      ' Add header rows

520   oSheetDaily.range("A1:H1").value = _
          Array("DATE", "AREA", "FIELD", "DESCRIPTION", "VALUE", "UNITS", _
          "START", "END")
530   oSheetSpecies.range("A1:V1").value = _
          Array("DATE", "AREA", "SPECIES", "SPNAME", "", "", _
          "", "", "", "", "", _
          "", "", "", "", "", _
          "", "ET", "COMMENTS", "OBSERVER", "INVALID")

540   oSheetDaily.range("A2").CopyFromRecordset rstDaily
550   oSheetSpecies.range("A2").CopyFromRecordset rstSpecies

560   rstDaily.Close
570   rstSpecies.Close

580   oSheetDaily.columns("A:A").NumberFormat = "dd-mmm-yy"
590   oSheetSpecies.columns("A:A").NumberFormat = "dd-mmm-yy"

600   oSheetDaily.columns("A:B").ColumnWidth = 10
610   oSheetDaily.columns("C:C").ColumnWidth = 13.71
620   oSheetDaily.columns("D:H").ColumnWidth = 24.14
630   oSheetSpecies.columns("A:B").ColumnWidth = 10
640   oSheetSpecies.columns("C:R").ColumnWidth = 8.43
650   oSheetSpecies.columns("S:S").ColumnWidth = 47.29
660   oSheetSpecies.columns("T:T").ColumnWidth = 10.71
670   oSheetSpecies.columns("U:U").ColumnWidth = 8.43

680   oSheetDaily.Rows("1:1").RowHeight = 45.75
690   oSheetSpecies.Rows("1:1").RowHeight = 45

700   oSheetDaily.Select
710   oSheetDaily.range("A2").Select
720   oExcel.ActiveWindow.FreezePanes = True
730   oSheetSpecies.Select
740   oSheetSpecies.range("D2").Select
750   oExcel.ActiveWindow.FreezePanes = True

760   oSheetDaily.range("A1:H1").Interior.Color = RGB(221, 217, 195)
770   oSheetSpecies.range("A1:V1").Interior.Color = RGB(221, 217, 195)

      ' Fill in the Data Field headings

          Dim rstDETViewDesignSpecies As DAO.Recordset
          Dim intCMMNDataFieldNumber As Integer
          Dim strCMMNDataFieldLabel As String
          
780       strSQL = "SELECT * FROM tblDETViewDesignSpecies"
790       Set rstDETViewDesignSpecies = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)
          
800       Do While Not rstDETViewDesignSpecies.EOF
          
810           intCMMNDataFieldNumber = Nz(rstDETViewDesignSpecies("CMMNDataFieldNumber"), 0)
820           strCMMNDataFieldLabel = Nz(rstDETViewDesignSpecies("CMMNDataFieldLabel"), "")
              
830           If intCMMNDataFieldNumber >= 1 And intCMMNDataFieldNumber <= 13 Then
840               oSheetSpecies.Cells(1, 4 + intCMMNDataFieldNumber) = strCMMNDataFieldLabel
850          End If
              
860           rstDETViewDesignSpecies.MoveNext
870       Loop
880       rstDETViewDesignSpecies.Close

      ' Copy the "setup" worksheet from "cmmn template.xlms"

      Dim CopyFromBook As Workbook
      Dim SheetToCopy As Worksheet
      Dim CopyFromBookPath As String
      Dim strMsg As String
          
890   CopyFromBookPath = CurrentProject.path & "\cmmn_template.xlsm"

900   If Not FileExists(CopyFromBookPath) Then
910       strMsg = "The cmmn_template.xlsm file is missing" & vbCrLf & CopyFromBookPath
920       If Not FolderExists(CurrentProject.path) Then
930     strMsg = strMsg & vbCrLf & vbCrLf & "The folder is missing" & vbCrLf & CurrentProject.path
940       End If
950       strMsg = strMsg & vbCrLf & vbCrLf & "Export cancelled"
960       MsgBox strMsg, , "Export cmmn_det"
970       GoTo Err_label
980   End If

      '     oExcel.Visible = True

990   On Error Resume Next
1000  Set CopyFromBook = oExcel.Workbooks.Open(CopyFromBookPath)
1010  If Err.Number <> 0 Then
1020      MsgBox "Failed to open cmmn_template.xlsm" & vbCrLf & _
                 "Export cancelled" & vbCrLf & vbCrLf & _
                 Err.Description
1030      oBook.Close saveChanges:=False
1040      oExcel.Quit
1050      Exit Sub
1060  Else
1070      Set SheetToCopy = CopyFromBook.Worksheets("setup")
1080      SheetToCopy.Copy Before:=oBook.Worksheets(1)
1090      CopyFromBook.Close saveChanges:=False
          
          Dim oSheetSetup As Excel.Worksheet
1100      Set oSheetSetup = oBook.Worksheets("setup")
1110      oSheetSetup.UnProtect
          
          ' Fill in the CMMN Site Code
          
1120      oSheetSetup.Cells(11, 2).value = strCMMNSiteCode
          
          ' Fill in the Effort Fields
          
          Dim rstDETDesignEffort As DAO.Recordset
          Dim intEffortNumber As Integer
      '   Dim strEffortDefinition As String
      '   Dim strEffortUnits As String
          Dim fEffortCarryOver As Boolean
          
1130      strSQL = "SELECT * FROM tblDETDesignEffort WHERE EffortInUse"
1140      Set rstDETDesignEffort = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)

1150      Do While Not rstDETDesignEffort.EOF
              
1160          intEffortNumber = Nz(rstDETDesignEffort("EffortNumber"), 0)
1170          strEffortDefinition = Nz(rstDETDesignEffort("EffortDefinition"), "")
1180          strEffortUnits = Nz(rstDETDesignEffort("EffortUnits"), "")
1190          fEffortCarryOver = Nz(rstDETDesignEffort("EffortCarryOver"), 0)
1200          If intEffortNumber >= 1 And intEffortNumber <= 10 Then
1210              oSheetSetup.Cells(49 + intEffortNumber, 2) = strEffortDefinition
1220              oSheetSetup.Cells(49 + intEffortNumber, 3) = strEffortUnits
1230              oSheetSetup.Cells(49 + intEffortNumber, 5) = IIf(fEffortCarryOver, "Yes", "No")
1240          End If
           
1250          rstDETDesignEffort.MoveNext
1260      Loop
1270      rstDETDesignEffort.Close
          
          ' Fill in the Data Fields
          
          ' Dim rstDETViewDesignSpecies As DAO.Recordset
          ' Dim intCMMNDataFieldNumber As Integer
          Dim strCMMNDataFieldDescription As String
          Dim strCMMNDataFieldUnits As String
          Dim intCMMNDataFieldInclude As Integer
          Dim fCMMNDataFieldInUse As Boolean
          Dim fCMMNDataFieldNatureCounts As Boolean
          
1280      strSQL = "SELECT * FROM tblDETViewDesignSpecies"
1290      Set rstDETViewDesignSpecies = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)
          
1300      Do While Not rstDETViewDesignSpecies.EOF
          
1310          intCMMNDataFieldNumber = Nz(rstDETViewDesignSpecies("CMMNDataFieldNumber"), 0)
1320          strCMMNDataFieldDescription = Nz(rstDETViewDesignSpecies("CMMNDataFieldDescription"), "")
1330          strCMMNDataFieldUnits = Nz(rstDETViewDesignSpecies("CMMNDataFieldUnits"), "")
1340          intCMMNDataFieldInclude = Nz(rstDETViewDesignSpecies("CMMNDataFieldInclude"), 0)
1350          fCMMNDataFieldInUse = Nz(rstDETViewDesignSpecies("CMMNDataFieldInUse"), 0)
1360          fCMMNDataFieldNatureCounts = Nz(rstDETViewDesignSpecies("CMMNDataFieldNatureCounts"), 0)
              
1370          If intCMMNDataFieldNumber >= 1 And intCMMNDataFieldNumber <= 13 Then
1380              oSheetSetup.Cells(28 + intCMMNDataFieldNumber, 2) = strCMMNDataFieldDescription
1390              oSheetSetup.Cells(28 + intCMMNDataFieldNumber, 3) = strCMMNDataFieldUnits
1400              oSheetSetup.Cells(28 + intCMMNDataFieldNumber, 5) = intCMMNDataFieldInclude
1410              oSheetSetup.Cells(28 + intCMMNDataFieldNumber, 6) = IIf(fCMMNDataFieldInUse, "Yes", "No")
1420              oSheetSetup.Cells(28 + intCMMNDataFieldNumber, 7) = IIf(fCMMNDataFieldNatureCounts, "Yes", "No")
1430          End If
              
1440          rstDETViewDesignSpecies.MoveNext
1450      Loop
1460      rstDETViewDesignSpecies.Close
          
1470      oSheetSetup.Protect

1480  End If

1490  Set oSheetDaily = Nothing
1500  Set oSheetSpecies = Nothing
1510  Set oSheetSetup = Nothing

       ' Save the Excel Workbook

      Dim strBaseFilename As String
1520  strBaseFilename = _
          "McGill " & _
          strProgram & " " & strLocation & " " & _
          "CMMN DET Spreadsheet "
          
      Dim strSaveFilepath As String
      Dim fUserCancelled As Boolean
1530  Call SaveAndCloseExcelWorkbookEx(oExcel, oBook, strBaseFilename, strSaveFilepath, fUserCancelled)

1540  Set oBook = Nothing
1550  oExcel.Quit
1560  Set oExcel = Nothing

1570  Call OpenExcelWorkbook(strSaveFilepath)

      'DD Error Handler Start
Exit_label:
1580       Exit Sub
Err_label:
1590       Select Case Err.Number
           Case Else
1600      Call LogError("basDET", "DETCMMNDETExcelSpreadsheetExport", strSQL)
1610       End Select
1620       Resume Exit_label
      'DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' ValidateDETCaptureFields_Program_Location
'
' Summary information is appended to oSheetSummary starting at row lngSheetSummaryRow
' Add a new sheet if there are any errors
'---------------------------------------------------------------------------------------
 
Public Sub ValidateDETCaptureFields_Program_Location( _
    ByVal fRegenerateDETCategory As Boolean, _
    ByVal fCreate_tblDET3 As Boolean, _
    ByVal strProgram As String, _
    ByVal strLocation As String, _
    ByRef oExcel As Excel.Application, _
    ByRef oBook As Excel.Workbook, _
    ByVal fDebug As Boolean, _
    ByRef fSuccess As Boolean, _
    ByRef oSheetSummary As Excel.Worksheet, _
    ByRef lngSheetSummaryRow As Long)
          
10    On Error GoTo Err_label

      Const colErrorType As Integer = 1
      Const colProgram As Integer = 2
      Const colLocation As Integer = 3
      Const colDateEx As Integer = 4
      Const colSpecies As Integer = 5
      Const colBanded_Captures As Integer = 6
      Const colReturn_Captures As Integer = 7
      Const colRepeat_Captures As Integer = 8
      Const colAlien_Captures As Integer = 9
      Const colReplacement_Captures As Integer = 10
      Const colBanded_DET As Integer = 11
      Const colReturn_DET As Integer = 12
      Const colRepeat_DET As Integer = 13
      Const colAlien_DET As Integer = 14
      Const colReplacement_DET As Integer = 15
      Const colLast As Integer = 15

      Dim datFrom As Date
      Dim datTo As Date

20    datFrom = DateSerial(1900, 1, 1)
30    datTo = DateSerial(3000, 1, 1)

40    fSuccess = True

      Dim oSheet As Excel.Worksheet
50    Set oSheet = oBook.Worksheets.Add(After:=oBook.Worksheets(oBook.Worksheets.count))
60    oSheet.Name = strProgram & "-" & strLocation

70    With oSheet

80    .Cells(1, colProgram) = "Program"
90    .Cells(1, colLocation) = "Location"
100   .Cells(1, colDateEx) = "Date"
110   .Cells(1, colSpecies) = "Species"
120   .Cells(1, colBanded_Captures) = "BND Captures"
130   .Cells(1, colReturn_Captures) = "RET Captures"
140   .Cells(1, colRepeat_Captures) = "REP Captures"
150   .Cells(1, colAlien_Captures) = "A Captures"
160   .Cells(1, colReplacement_Captures) = "5 Captures"
170   .Cells(1, colBanded_DET) = "BND DET"
180   .Cells(1, colReturn_DET) = "RET DET"
190   .Cells(1, colRepeat_DET) = "REP DET"
200   .Cells(1, colAlien_DET) = "A DET"
210   .Cells(1, colReplacement_DET) = "5 DET"

      Dim row As Long

220   row = 2
        
230   If fCreate_tblDET3 Then
        
          ' if fRegenerateDETCategory,
          ' recalculate D18 (DETCategory) and D20 (Days since most recent prior capture) for each
          '     capture record
          
          ' Create tblDET3 - one record per Capture Date. i.e. the data needed for the DET
          ' columns that are filled in from the capture records
          ' -------------------------------------------------------------------------------
          '       ID (autonumber)
          '       Program     will be the same for all records
          '       Location    will be the same for all records
          '       DateEx      report date
          '       Species     pseudo-species
          '       Banded      count of disposition 1 records
          '       Return
          '       Repeat
          '       Alien
          '       Replacement
          '       Unknown
          
240       If fRegenerateDETCategory Then
              Dim rstDETNoCategory As DAO.Recordset
250           Set rstDETNoCategory = CurrentDb.OpenRecordset("tblErrorMessage", dbOpenDynaset)
260           Call UpdateDETCategory(strProgram, strLocation, datFrom, datTo, rstDETNoCategory)
270       End If

             
          Dim cntRecords As Long
280       Call Create_tblDET3(cntRecords, strProgram, strLocation, "Create", datFrom, datTo)

290   End If

      Dim datDateEx As Date
      Dim strSpecies As String
      Dim lngBanded_DET As Long
      Dim lngReturn_DET As Long
      Dim lngRepeat_DET As Long
      Dim lngAlien_DET As Long
      Dim lngReplacement_DET As Long
      Dim lngBanded_Captures As Long
      Dim lngReturn_Captures As Long
      Dim lngRepeat_Captures As Long
      Dim lngAlien_Captures As Long
      Dim lngReplacement_Captures As Long

      ' Are there any records in tblDET3 that are missing from the DET

      ' qryCombinedWeeklyReportsValidateProgram_Missing_DET
      ' ---------------------------------------------------
      ' tblDET3 x qryCombinedWeeklyReportsValidateProgram_DET
      ' LEFT OUTER JOIN
      ' qryCombinedWeeklyReportsValidateProgram_DET.Program = NULL

      Dim rst As DAO.Recordset
300   Set rst = CurrentDb.OpenRecordset("qryDETCombinedWeeklyReportsValidateProgram_Missing_DET", dbOpenDynaset)
310   If rst.EOF Then
320       oSheetSummary.Cells(lngSheetSummaryRow, 1) = "All the capture data for " & strProgram & " at " & strLocation & " is in the DET sheets"
330   Else
340       fSuccess = False
350       oSheetSummary.Cells(lngSheetSummaryRow, 1) = "There is capture data  for " & strProgram & " at " & strLocation & _
                " that is missing from the DET sheets"
360       oSheetSummary.range(oSheetSummary.Cells(lngSheetSummaryRow, 1), oSheetSummary.Cells(lngSheetSummaryRow, 1)).Font.Color = vbRed
370       Do While Not rst.EOF

380           datDateEx = Nz(rst("DateEx"))
390           strSpecies = Nz(rst("Species"))
400           lngBanded_Captures = Nz(rst("Banded"))
410           lngReturn_Captures = Nz(rst("Return"))
420           lngRepeat_Captures = Nz(rst("Repeat"))
430           lngAlien_Captures = Nz(rst("Alien"))
440           lngReplacement_Captures = Nz(rst("Replacement"))
              
450           .Cells(row, colErrorType) = "Missing from DET"
460           .Cells(row, colProgram) = strProgram
470           .Cells(row, colLocation) = strLocation
480           .Cells(row, colDateEx) = datDateEx
490           .Cells(row, colSpecies) = strSpecies
500           .Cells(row, colBanded_Captures) = lngBanded_Captures
510           .Cells(row, colReturn_Captures) = lngReturn_Captures
520           .Cells(row, colRepeat_Captures) = lngRepeat_Captures
530           .Cells(row, colAlien_Captures) = lngAlien_Captures
540           .Cells(row, colReplacement_Captures) = lngReplacement_Captures
550           row = row + 1
              
560           rst.MoveNext
570       Loop
580   End If
590   lngSheetSummaryRow = lngSheetSummaryRow + 1
600   rst.Close
610   Set rst = Nothing

      ' Are there any records (for the given Program and Location) in the DET that are missing from tblDET3

      Dim qdf As DAO.QueryDef
640   Set qdf = CurrentDb.QueryDefs("qryDETCombinedWeeklyReportValidateProgram_Missing_Capture")
650   qdf.Parameters("argProgram").value = strProgram
660   qdf.Parameters("argLocation").value = strLocation
670   qdf.Parameters("argFrom").value = datFrom
680   qdf.Parameters("argTo").value = datTo

690   Set rst = qdf.OpenRecordset
700   If rst.EOF Then
710       oSheetSummary.Cells(lngSheetSummaryRow, 1) = "No non-existant capture data for " & strProgram & " at " & strLocation & " is in the DET sheets"
720   Else
730       fSuccess = False
740       oSheetSummary.Cells(lngSheetSummaryRow, 1) = "There is DET data  for " & strProgram & " at " & strLocation & _
                " that does not correspond to any captures"
750       oSheetSummary.range(oSheetSummary.Cells(lngSheetSummaryRow, 1), oSheetSummary.Cells(lngSheetSummaryRow, 1)).Font.Color = vbRed
760       Do While Not rst.EOF
        
770             datDateEx = Nz(rst("DateEx"))
780             strSpecies = Nz(rst("Species"))
790             lngBanded_DET = Nz(rst("Banded"))
800             lngReturn_DET = Nz(rst("Returns"))
810             lngRepeat_DET = Nz(rst("Repeats"))
820             lngAlien_DET = Nz(rst("Alien"))
830             lngReplacement_DET = Nz(rst("Replacement"))
              
840             .Cells(row, colErrorType) = "No corresponding capture"
850             .Cells(row, colProgram) = strProgram
860             .Cells(row, colLocation) = strLocation
870             .Cells(row, colDateEx) = datDateEx
880             .Cells(row, colSpecies) = strSpecies
890             .Cells(row, colBanded_DET) = lngBanded_DET
900             .Cells(row, colReturn_DET) = lngReturn_DET
910             .Cells(row, colRepeat_DET) = lngRepeat_DET
920             .Cells(row, colAlien_DET) = lngAlien_DET
930             .Cells(row, colReplacement_DET) = lngReplacement_DET
940             row = row + 1
              
950             rst.MoveNext
960       Loop
970   End If
980   lngSheetSummaryRow = lngSheetSummaryRow + 1
990   rst.Close
1000  Set rst = Nothing

      ' Are there any contradictory records (for the given Program and Location) between the DET and captures

1010  Set qdf = CurrentDb.QueryDefs("qryDETCombinedWeeklyReportsValidateProgram_Inconsistent")

1020  Set rst = qdf.OpenRecordset
1030  If rst.EOF Then
1040      oSheetSummary.Cells(lngSheetSummaryRow, 1) = "Capture data for " & strProgram & " at " & strLocation & _
                " is consistent with the DET sheets"
1050  Else
1060      fSuccess = False
1070      oSheetSummary.Cells(lngSheetSummaryRow, 1) = "Capture data  for " & strProgram & " at " & strLocation & _
                " is inconsistent with the DET sheets"
1080      oSheetSummary.range(oSheetSummary.Cells(lngSheetSummaryRow, 1), oSheetSummary.Cells(lngSheetSummaryRow, 1)).Font.Color = vbRed

1090      Do While Not rst.EOF
          
1100          datDateEx = Nz(rst("DateEx"))
1110          strSpecies = Nz(rst("Species"))
1120          lngBanded_DET = Nz(rst("Banded_DET"))
1130          lngReturn_DET = Nz(rst("Return_DET"))
1140          lngRepeat_DET = Nz(rst("Repeat_DET"))
1150          lngAlien_DET = Nz(rst("Alien_DET"))
1160          lngReplacement_DET = Nz(rst("Replacement_DET"))
1170          lngBanded_Captures = Nz(rst("Banded_Captures"))
1180          lngReturn_Captures = Nz(rst("Return_Captures"))
1190          lngRepeat_Captures = Nz(rst("Repeat_Captures"))
1200          lngAlien_Captures = Nz(rst("Alien_Captures"))
1210          lngReplacement_Captures = Nz(rst("Replacement_Captures"))

1220          .Cells(row, colErrorType) = "Missing from DET"
1230          .Cells(row, colProgram) = strProgram
1240          .Cells(row, colLocation) = strLocation
1250          .Cells(row, colDateEx) = datDateEx
1260          .Cells(row, colSpecies) = strSpecies
1270          .Cells(row, colBanded_DET) = lngBanded_DET
1280          .Cells(row, colReturn_DET) = lngReturn_DET
1290          .Cells(row, colRepeat_DET) = lngRepeat_DET
1300          .Cells(row, colAlien_DET) = lngAlien_DET
1310          .Cells(row, colReplacement_DET) = lngReplacement_DET
1320          .Cells(row, colBanded_Captures) = lngBanded_Captures
1330          .Cells(row, colReturn_Captures) = lngReturn_Captures
1340          .Cells(row, colRepeat_Captures) = lngRepeat_Captures
1350          .Cells(row, colAlien_Captures) = lngAlien_Captures
1360          .Cells(row, colReplacement_Captures) = lngReplacement_Captures
1370          row = row + 1
            
1380          rst.MoveNext
1390      Loop
1400  End If
1410  lngSheetSummaryRow = lngSheetSummaryRow + 1
1420  rst.Close
1430  Set rst = Nothing

1440  .range(.columns(1), .columns(colLast)).AutoFit

1450  End With ' oSheet
1460  Set oSheet = Nothing

      'DD Error Handler Start
Exit_label:
1470       Exit Sub
Err_label:
1480       Select Case Err.Number
           Case Else
1490      Call LogError("basDET", "DETCombinedWeeklyReportsValidateProgram_Validate")
1500       End Select
1510       Resume Exit_label
      'DD Error Handler End
          
End Sub





'---------------------------------------------------------------------------------------
' getDETDate
'
'---------------------------------------------------------------------------------------
' Calculate the DET date that corresponds to a Capture Date.
' (DET Date = Capture date, except for Owling)
' (For Owling, before midday captures => DET Date = Capture Date - 1; after midday captures => DET Date = Capture Date)
' If the DET Date cannot be determined (Null weight time for Owling; unknown Season; ...), return the Capture date
' Called when user deletes a capture record
' Called when user adds a capture record on the capture form
' Called when the user edits a capture record on the capture form
' Called when a record is moved from a sheet to the captures table

Public Function getDETDate(ByVal datCaptureDate As Date, ByVal varWeightTime As Variant, ByVal strProgram As String) As Date

10    On Error GoTo Err_label

      Dim strSeason As String
      
20    getDETDate = datCaptureDate

30    strSeason = Nz(DLookup("MonitoringProgramSeason", "tblPrograms", "[Program] = '" & strProgram & "'"))
40    If strSeason = "Owling" Then
50        If IsNull(varWeightTime) Then

              ' If the weight time is Null for an Owling capture then return the Capture date

60            Exit Function
70        Else
80            If Hour(CDate(varWeightTime)) < 12 Then
90                getDETDate = datCaptureDate - 1
100           End If
110       End If
120   End If

      'DD Error Handler Start
Exit_label:
130        Exit Function
Err_label:
140        Select Case Err.Number
           Case Else
150             Call LogError("basDET", "getDETDate")
160        End Select
170        Resume Exit_label
      'DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' UpdateNextCapture
'---------------------------------------------------------------------------------------
' Given a band# and a capture date, find the next capture record for the bird, if any
' Recalculate the next capture record's DET Category (D18) and Days Since Most Recent Prior Capture (D20)
' If the DET Category was changed, update the corresponding DET sheet
'
' This procedure can be called just after a capture record is inserted OR just after a capture record has been deleted
'
' if fUpdate_tblCapturesEditOrDelete = True then check to see if the record is in tblCapturesEditOrDelete
' if so, copy D18, D20, D21 to it.
'
' Called from:
' basSheetNewBands.NewBands_Store()
' basSheetRecaps.Recaps_Store()
' frmCapturesEditOrDelete.cmdDeleteAllrecords_Click => cmdDeleteCaptureRecord()         after each delete
' frmCapturesEditOrDelete.cmdDeleteCurrentRecord_Click => cmdDeleteCaptureRecord()      after delete
' frmCapturesEditOrDelete.cmdUpdateCurrentRecord => cmdDeleteCaptureRecord()            after delete
' frmCapturesEditOrDelete.cmdUpdateCurrentRecord()                                      after store

Public Sub UpdateNextCapture(ByVal strBandPrefix As String, ByVal strBandSuffix As String, ByVal datCaptureDate As Date, Optional fUpdate_tblCapturesEditOrDelete = False)

10    On Error GoTo Err_label

      Dim strWhere As String
      Dim strWhereDETSpecies As String
      Dim rstDETSpecies As DAO.Recordset
      Dim strFieldname As String
      Dim dblValue As Double

      Dim strDETCategory_NextCapture As String
      Dim datCaptureDate_NextCapture As Date
      Dim strProgram_NextCapture As String
      Dim strLocation_NextCapture As String
      Dim varWeightTime_NextCapture As Variant
      Dim datDETDate_NextCapture As Date
      Dim strSpecies_NextCapture As String
      Dim lngBandID_nextCapture As Long

      ' Get the next capture record

20    strWhere = _
          "[BandPrefix] = '" & strBandPrefix & "' AND " & _
          "[BandSuffix] = '" & strBandSuffix & "' AND " & _
          "[CaptureDate] > #" & Format(datCaptureDate, "mm/dd/yyyy") & "#"
          
      Dim rstNextCapture As DAO.Recordset
      Dim strSQL As String
30    strSQL = "SELECT * FROM tblCaptures WHERE " & strWhere & " ORDER BY [CaptureDate]"
        
40    Set rstNextCapture = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)
50    If Not rstNextCapture.EOF Then

60        strDETCategory_NextCapture = rstNextCapture("D18")
70        datCaptureDate_NextCapture = rstNextCapture("Capturedate")
80        strProgram_NextCapture = rstNextCapture("Program")
90        strLocation_NextCapture = rstNextCapture("Location")
100       varWeightTime_NextCapture = rstNextCapture("WeightTime")
110       datDETDate_NextCapture = getDETDate(datCaptureDate_NextCapture, varWeightTime_NextCapture, strProgram_NextCapture)
120       strSpecies_NextCapture = Nz(rstNextCapture("Species"))
130       lngBandID_nextCapture = Nz(rstNextCapture("IDBand"))
          
          Dim strDETCategory_new As String
          Dim strReasonDETCategoryUnknown_new As String ' dummy
          Dim lngDaysSinceMostRecentPriorCapture_new As Long
          Dim fDETCategoryOverride As Boolean
          
140       fDETCategoryOverride = True
          
150       Call DETCategory(lngBandID_nextCapture, strDETCategory_new, strReasonDETCategoryUnknown_new, lngDaysSinceMostRecentPriorCapture_new, fDETCategoryOverride)

160       Call Update_D18_D20_D21(rstNextCapture, strDETCategory_new, lngDaysSinceMostRecentPriorCapture_new, datDETDate_NextCapture, True, "Update next capture DET Fields") ' log
                    
          ' if fUpdate_tblCapturesEditOrDelete && the next record is cached in tblCapturesEditOrDelete then update it too

170       If fUpdate_tblCapturesEditOrDelete Then
180           If DCount("*", "tblCapturesEditOrDelete", "[IDBand] = " & lngBandID_nextCapture) > 0 Then
                  Dim rstCaptureEditOrDelete As DAO.Recordset
190               strSQL = "SELECT * FROM tblCapturesEditOrDelete WHERE [IDBand] = " & lngBandID_nextCapture
200               Set rstCaptureEditOrDelete = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)
210               If Not rstCaptureEditOrDelete.EOF Then
220                   Call Update_D18_D20_D21(rstCaptureEditOrDelete, strDETCategory_new, lngDaysSinceMostRecentPriorCapture_new, datDETDate_NextCapture, True, "Update cached next capture DET Fields") ' log
230               End If
240               rstCaptureEditOrDelete.Close
250               Set rstCaptureEditOrDelete = Nothing
260           End If
270       End If

280       Call UpdateDETSpeciesCategory(strProgram_NextCapture, strLocation_NextCapture, datDETDate_NextCapture, strSpecies_NextCapture, _
            strDETCategory_NextCapture, strDETCategory_new, strBandPrefix, strBandSuffix)

290   End If

      'DD Error Handler Start
Exit_label:
300        Exit Sub
Err_label:
310        Select Case Err.Number
           Case Else
320             Call LogError("basDET", "UpdateNextCapture")
330        End Select
340        Resume Exit_label
      'DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
'Update_D18_D20_D21
'---------------------------------------------------------------------------------------

Public Sub Update_D18_D20_D21(ByRef rst As DAO.Recordset, _
    ByVal strDETCategory_new As String, _
    ByVal lngDaysSinceMostRecentPriorCapture_new As Long, _
    ByVal datDETDate_new As Date, _
    Optional ByVal fLog As Boolean = False, _
    Optional ByVal strMessagePrefix As String = "Update capture DET fields")

      Dim lngIDBand As Long
      Dim strBandPrefix As String
      Dim strBandSuffix As String
      Dim strDETCategory_old As String
      Dim lngDaysSinceMostRecentPriorCapture_old As Long
      Dim datDETDate_old As Date

      Dim fDETCategory As Boolean
      Dim fDaysSinceMostRecentPriorCapture As Boolean
      Dim fDETDate As Boolean

      Dim strLog As String

10    On Error GoTo Err_label

20    lngIDBand = Nz(rst("IDBand"))
30    strBandPrefix = Nz(rst("BandPrefix"))
40    strBandSuffix = Nz(rst("BandSuffix"))
50    strDETCategory_old = Nz(rst("D18"))
60    lngDaysSinceMostRecentPriorCapture_old = Nz(rst("D20"))
70    datDETDate_old = CDate(Nz(rst("D21")))

80    fDETCategory = (strDETCategory_old <> strDETCategory_new)

90    If Not (strDETCategory_new = "Return" Or strDETCategory_new = "Repeat") Then
100       lngDaysSinceMostRecentPriorCapture_new = 0
110   End If
120   fDaysSinceMostRecentPriorCapture = (lngDaysSinceMostRecentPriorCapture_old <> lngDaysSinceMostRecentPriorCapture_new)

130   fDETDate = (datDETDate_old <> datDETDate_new)

140   If fDETCategory Or fDaysSinceMostRecentPriorCapture Or fDETDate Then
150       rst.Edit
160       If fDETCategory Then rst("D18") = strDETCategory_new
170       If fDaysSinceMostRecentPriorCapture Then
180           If lngDaysSinceMostRecentPriorCapture_new > 0 Then
190               rst("D20") = lngDaysSinceMostRecentPriorCapture_new
200           Else
210                rst("D20") = Null
220           End If
230        End If
240        If fDETDate Then
250           If datDETDate_new = 0 Then
260               rst("D21") = Null
270           Else
280               rst("D21") = Format(datDETDate_new, "yyyy-mm-dd")
290           End If
300       End If
310       rst.Update
          
320       If fLog Then
330           strLog = strMessagePrefix & " [" & lngIDBand & "] : "
340           If fDETCategory Then
350               strLog = strLog & " D18 " & ZStr(strDETCategory_old) & " > " & ZStr(strDETCategory_new)
360           End If
370           If fDaysSinceMostRecentPriorCapture Then
380               strLog = strLog & " D20 " & ZLng(lngDaysSinceMostRecentPriorCapture_old) & " > " & ZLng(lngDaysSinceMostRecentPriorCapture_new)
390           End If
400           If fDETDate Then
410               strLog = strLog & " D21 " & ZDat(datDETDate_old) & " > " & ZDat(datDETDate_new)
420           End If
430       End If
440   Else
450       If fLog Then strLog = strMessagePrefix & " [" & lngIDBand & "] : no change"
460   End If
          
470   If fLog Then Call log(strLog)

    'DD Error Handler Start
Exit_label:
480       Exit Sub
Err_label:
490       Select Case Err.Number
    Case Else
500      Call LogError("basDET", "Update_D18_D20_D21")
510       End Select
520       Resume Exit_label
    ' DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' UpdateDET_AddCaptureRecord
'
' Called from NewBands_Store_v2
'             Recaps_Store_v2
'             frmCapturesEditOrDelete form AfterUpdate event
'
'---------------------------------------------------------------------------------------
' Uses the following fields of b_new

' Public Type CapturesType
'    IDBand          As Variant        only used when logging errors
'    Disposition     As Variant
'    Species         As Variant
'    CaptureDate     As Variant
'    WeightTime      As Variant
'    Program         As Variant
'    Location        As Variant
'    D(18)           As Variant         DET Category
'    ...
' End Type

' Skip disposition 4 or 8 capture records
' Skip BADE or BALO capture records
'
' Case: DET Category = Banded, Return, Repeat, Alien, Replacement
'    Calculate the DET Date from Capture Date, Weight Time, Program
'    If there is no DET Species record for this Program, Location, DET Date, Species, then
'       Create one
'       Log some info about this creation of a DET Species record to tblLog
'       If there is no DET Daily record for this Program, Location, DET Date, then
'           Create one
'           Log some info about this creation of a DET Daily record to tblLog
'    Increase the corresponding DET Category of the DET Species record
' Case: Unknown, None, ""
'    Do nothing
' Case else: report a silent error


Public Sub UpdateDET_AddCaptureRecord(ByRef b_new As CapturesType)
          
10    On Error GoTo Err_label

      Dim lngIDBand      As Long
      Dim strDisposition As String
      Dim strBandPrefix  As String
      Dim strBandSuffix  As String
      Dim strSpecies     As String
      Dim datCaptureDate As Date
      Dim varWeightTime  As Variant
      Dim strProgram     As String
      Dim strLocation    As String
      Dim strDETCategory As String

20    lngIDBand = Nz(b_new.IDBand)
30    strDisposition = Nz(b_new.Disposition)
40    strBandPrefix = Nz(b_new.BandPrefix)
50    strBandSuffix = Nz(b_new.BandSuffix)
60    strSpecies = Nz(b_new.Species)
70    datCaptureDate = Nz(b_new.CaptureDate)
80    varWeightTime = b_new.WeightTime
90    strProgram = Nz(b_new.Program)
100   strLocation = Nz(b_new.Location)
110   strDETCategory = Nz(b_new.D(18))

      ' Disposition 4/8 capture records are not recorded in the DET

120   If strDisposition = "4" Or strDisposition = "8" Then GoTo Exit_label
130   If strSpecies = "BADE" Or strSpecies = "BALO" Then GoTo Exit_label
          
140   Select Case strDETCategory
      Case "Banded", "Return", "Repeat", "Alien", "Replacement"

          Dim datDETDate As Date
150       datDETDate = getDETDate(CDate(datCaptureDate), varWeightTime, strProgram)
          
          ' Update DET for this program+location+day, by incrementing the corresponding field
          
          Dim strFieldname As String
          Dim rstDETSpecies As DAO.Recordset
          Dim rstDETDaily As DAO.Recordset
          Dim dblValue As Double
          Dim strWhereDETSpecies As String
          Dim strWhereDETDaily As String
          
160       strWhereDETSpecies = _
              "[Program] = '" & strProgram & "' AND " & _
              "[Location] = '" & strLocation & "' AND " & _
              "[DateEx] = #" & Format(datDETDate, "mm/dd/yyyy") & "# AND " & _
              "[Species] = '" & strSpecies & "'"

170       If Not Species_Exists(strProgram, strLocation, datDETDate, strSpecies) Then
          
              ' Insert a DETSpecies record
              
              Dim recSpecies As DETSpeciesType
              
180           recSpecies.Program = strProgram
190           recSpecies.Location = strLocation
200           recSpecies.DateEx = datDETDate
210           recSpecies.Species = strSpecies
220           recSpecies.Observed = Null
230           recSpecies.Census = Null
240           recSpecies.Banded = Null
250           recSpecies.Repeats = Null
260           recSpecies.Returns = Null
270           recSpecies.PKS = Null
280           recSpecies.DET = Null
290           recSpecies.VisibleEx = Null
300           recSpecies.Casual = Null
310           recSpecies.Observed3 = Null
320           recSpecies.Observed4 = Null
330           recSpecies.NonStandardBanded = Null
340           recSpecies.NonStandardRecaps = Null
350           recSpecies.DailySpeciesTotal = Null
360           recSpecies.Source = "Add capture"
370           Call Raw_Add_Species(recSpecies)
              
380           log ("Add DET Species - Add capture " & strWhereDETSpecies)
                             
              ' Do we need a parent?
        
              Dim recDaily As DETDailyType
        
390           If Not Daily_Exists(strProgram, strLocation, datDETDate) Then          '   If the tblDETDaily record does not exist
400               recDaily.Program = strProgram
410               recDaily.Location = strLocation
420               recDaily.DateEx = datDETDate
430               recDaily.Observers = Null
440               recDaily.SongbirdNets = Null
450               recDaily.CoverageCode = Null
460               recDaily.OtherTrap = Null            ' Hummingbird effort
470               recDaily.NonSongbirdNets = Null
480               recDaily.JTrap = Null
490               recDaily.Heliogoland = Null
500               recDaily.VisibleMigration = Null
510               recDaily.Source = "Add capture"
520               Call Raw_Add_Daily(recDaily)                   '     Add a tblDETDaily record (the non-key fields are set to null)
            
530               log ("Add DET Daily - UpdateDET_AddCaptureRecord" & strProgram & " " & strLocation & " " & Format(datDETDate, "d-mmm-yyyy"))
540           End If
550       End If

          Dim strSQL As String
560       strSQL = "SELECT * FROM tblDETSpecies WHERE " & strWhereDETSpecies

570       Set rstDETSpecies = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)
580       Call DETSpeciesIncreaseCategory(rstDETSpecies, strDETCategory, strBandPrefix, strBandSuffix)

590   Case "Unknown", "None"
600   Case Else
610     If strDETCategory <> "" Then
620         LogError "basDET", "UpdateDET_AddCaptureRecord", "Unrecognized DET Category IDBand=" & lngIDBand & " DETCategory=" & strDETCategory, Silent:=True
630     End If
640   End Select

      'DD Error Handler Start
Exit_label:
650        Exit Sub
Err_label:
660        Select Case Err.Number
           Case Else
670       Call LogError("basDET", "UpdateDET_AddCaptureRecord")
680        End Select
690        Resume Exit_label
      'DD Error Handler End


End Sub

'---------------------------------------------------------------------------------------
' UpdateDET_DeleteCaptureRecord
'
' Called from frmCapturesEditOrDelete during delete or update
' (called from DeleteCaptureRecord which is called from UpdateCaptureRecord, cmdDeleteAllRecords_Click, cmdDeleteCurrentRecord_Click)
'---------------------------------------------------------------------------------------
' Uses the following fields of b_old

' Public Type CapturesType
'    Disposition     As Variant
'    BandPrefix      As Variant
'    BandSuffix      As Variant
'    Species         As Variant
'    CaptureDate     As Variant
'    WeightTime      As Variant
'    Program         As Variant
'    Location        As Variant
'    D(18)           As Variant         DET Category
'    ...
' End Type

Public Sub UpdateDET_DeleteCaptureRecord(ByRef b_old As CapturesType)

10    On Error GoTo Err_label

Dim strDisposition As String
Dim strBandPrefix As String
Dim strBandSuffix As String
Dim strSpecies     As String
Dim datCaptureDate As Date
Dim varWeightTime  As Variant
Dim strProgram     As String
Dim strLocation    As String
Dim strDETCategory As String

20    strDisposition = Nz(b_old.Disposition)
70    strBandPrefix = Nz(b_old.BandPrefix)
25    strBandSuffix = Nz(b_old.BandSuffix)
30    strSpecies = Nz(b_old.Species)
40    datCaptureDate = Nz(b_old.CaptureDate)
50    varWeightTime = b_old.WeightTime
60    strProgram = Nz(b_old.Program)
66    strLocation = Nz(b_old.Location)
80    strDETCategory = Nz(b_old.D(18))

' Disposition 4/8 capture records are not recorded in the DET

90    If strDisposition = "4" Or strDisposition = "8" Or strDisposition = "X" Then GoTo Exit_label
100   If strSpecies = "BADE" Or strSpecies = "BALO" Then GoTo Exit_label
          
120   Select Case strDETCategory
      Case "Banded", "Return", "Repeat", "Alien", "Replacement"

          Dim datDETDate As Date
          
130       datDETDate = getDETDate(datCaptureDate, varWeightTime, strProgram)
          
          ' Update DET for this program+location+date+Species, by decrementing the corresponding field
          
          Dim rstDETSpecies As DAO.Recordset
          
          Dim strWhereDETSpecies As String
140       strWhereDETSpecies = _
              "[Program] = '" & strProgram & "' AND " & _
              "[Location] = '" & strLocation & "' AND " & _
              "[DateEx] = #" & Format(datDETDate, "mm/dd/yyyy") & "# AND " & _
              "[Species] = '" & strSpecies & "'"
              
          Dim lngValue_new As Long
           
150       Set rstDETSpecies = CurrentDb.OpenRecordset("SELECT * FROM tblDETSpecies WHERE " & strWhereDETSpecies, dbOpenDynaset)
160       If Not rstDETSpecies.EOF Then
170           Call DETSpeciesDecreaseCategory(rstDETSpecies, strDETCategory, lngValue_new, strBandPrefix, strBandSuffix)
180       End If

          ' Clean up the DET sheet
          
190       If lngValue_new = 0 Then
200           Call DETCleanGivenProgramLocationDETDateSpecies(strProgram, strLocation, datDETDate, strSpecies, fLog:=True, strSource:="Delete capture record")
210       End If

220   Case "Unknown", "None"
230   Case Else
240     If strDETCategory = "" Then
250         LogError "basDET", "UpdateDET_DeleteCaptureRecord", "Blank DET Category ", Silent:=True
260     Else
270         LogError "basDET", "UpdateDET_DeleteCaptureRecord", "Unrecognized DET Category " & strDETCategory, Silent:=True
280     End If
290   End Select

    'DD Error Handler Start
Exit_label:
300       Exit Sub
Err_label:
310       Select Case Err.Number
    Case Else
320      Call LogError("basDET", "UpdateDET_DeleteCaptureRecord")
330       End Select
340       Resume Exit_label
    ' DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
'DETSpeciesDecreaseCategory
'
' Called from UpdateDET_DeleteCaptureRecord and UpdateDETSpeciesCategory
'---------------------------------------------------------------------------------------
' Returns lngValue_new, the new value of the field  ( 0 => a Null was stored )
'
' strBandPrefix and strBandSuffix are used when logging to tblDETSpeciesLog
'
' This procedure does NOT delete the DETSpecies record if the resulting DETSpecies record has all Null/0 non-key field values

Public Sub DETSpeciesDecreaseCategory(ByRef rstDETSpecies As DAO.Recordset, ByVal strDETCategory As String, ByRef lngValue_new As Long, ByVal strBandPrefix As String, ByVal strBandSuffix As String)

      Dim strFieldname As String
      Dim lngValue_old As Long

      Dim strProgram As String
      Dim strLocation As String
      Dim datDETDate As Date
      Dim strSpecies As String

10    strProgram = Nz(rstDETSpecies("Program"))
20    strLocation = Nz(rstDETSpecies("Location"))
30    datDETDate = Nz(rstDETSpecies("DateEx"))
40    strSpecies = Nz(rstDETSpecies("Species"))
          
50    On Error GoTo Err_label

60    Select Case strDETCategory
      Case "Banded"
70        strFieldname = "Banded"
80    Case "Return"
90        strFieldname = "Returns"
100   Case "Repeat"
110       strFieldname = "Repeats"
120   Case "Alien"
130       strFieldname = "Observed3"
140   Case "Replacement"
150       strFieldname = "Observed4"
160   Case Else
170       GoTo Exit_label
180   End Select

      Dim varValue_old As Variant
      Dim varValue_new As Variant

190   varValue_old = rstDETSpecies(strFieldname)
200   lngValue_old = Nz(varValue_old)

210   If lngValue_old <= 1 Then
220      lngValue_new = 0
230      varValue_new = Null
240   ElseIf lngValue_old > 1 Then
250      lngValue_new = lngValue_old - 1
260      varValue_new = lngValue_new
270   End If

280   rstDETSpecies.Edit
290   rstDETSpecies(strFieldname) = varValue_new
300   rstDETSpecies.Update

310   log ("Edit DET: Program=" & strProgram & " Location=" & strLocation & " DET date=" & Format(datDETDate, "d-mmm-yyyy") & " Species=" & strSpecies & " DET category=" & _
           strDETCategory & " Decrement : " & ZLng(lngValue_old) & " > " & ZLng(lngValue_new))
           
320   Call logDETSpecies(strBandPrefix, strBandSuffix, strProgram, strLocation, strSpecies, datDETDate, strDETCategory, "Decrement", lngValue_old, lngValue_new)

      'DD Error Handler Start
Exit_label:
330        Exit Sub
Err_label:
340        Select Case Err.Number
           Case Else
350       Call LogError("basDET", "DETSpeciesDecreaseCategory")
360        End Select
370        Resume Exit_label
      'DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
'DETSpeciesIncreaseCategory
'
' Called from UpdateDET_AddCaptureRecord and UpdateDETSpeciesCategory
'---------------------------------------------------------------------------------------
' Assumption:  the DET species record exists

Public Sub DETSpeciesIncreaseCategory(ByRef rstDETSpecies As DAO.Recordset, ByVal strDETCategory As String, _
    ByVal strBandPrefix As String, ByVal strBandSuffix As String)

      Dim strFieldname As String
      Dim dblValue As Double

      Dim strProgram As String
      Dim strLocation As String
      Dim datDETDate As Date
      Dim strSpecies As String

10    On Error GoTo Err_label

20    strProgram = Nz(rstDETSpecies("Program"))
30    strLocation = Nz(rstDETSpecies("Location"))
40    datDETDate = Nz(rstDETSpecies("DateEx"))
50    strSpecies = Nz(rstDETSpecies("Species"))

60    Select Case strDETCategory
      Case "Banded"
70        strFieldname = "Banded"
80    Case "Return"
90        strFieldname = "Returns"
100   Case "Repeat"
110       strFieldname = "Repeats"
120   Case "Alien"
130       strFieldname = "Observed3"
140   Case "Replacement"
150       strFieldname = "Observed4"
160   Case Else
170       GoTo Exit_label
180   End Select

      ' Get data value from DETSpecies record
      ' Convert a null to 0
      ' Add 1
      ' Store

      Dim varValue_old As Variant

190   varValue_old = rstDETSpecies(strFieldname)

200   dblValue = Nz(varValue_old)

210   rstDETSpecies.Edit
220   rstDETSpecies(strFieldname) = dblValue + 1
230   rstDETSpecies.Update
       
240    log ("Edit DET: Program=" & strProgram & " Location=" & strLocation & " DET date=" & Format(datDETDate, "d-mmm-yyyy") & " Species=" & strSpecies & " DET category=" & _
       strDETCategory & " Increment : " & ZLng(dblValue) & " > " & dblValue + 1)

250   Call logDETSpecies(strBandPrefix, strBandSuffix, strProgram, strLocation, strSpecies, datDETDate, strDETCategory, "Increment", CLng(dblValue), CLng(dblValue) + 1)

      'DD Error Handler Start
Exit_label:
260        Exit Sub
Err_label:
270        Select Case Err.Number
           Case Else
280       Call LogError("basDET", "DETSpeciesIncreaseCategory")
290        End Select
300        Resume Exit_label
      'DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' logDETSpecies
'---------------------------------------------------------------------------------------
' D21 = DET Date      *** a string fomrmatted yyyy-mm-dd
' D18 = DETCategory
'
' Called from DETSpeciesIncreaseCategory() and DETSpeciesDecreaseCategory()


Private Sub logDETSpecies(ByVal strBandPrefix As String, ByVal strBandSuffix As String, _
    ByVal strProgram As String, ByVal strLocation As String, ByVal strSpecies As String, ByVal datDETDate As Date, _
    ByVal strDETCategory As String, ByVal strOperation As String, _
    ByVal lngValue_old As Long, ByVal lngValue_new As Long)
          
      Dim strSQL As String
      Dim strMessage As String

10    On Error GoTo Err_label

      ' Get the correct value

      Dim lngCorrectValue As Long
      Dim strWhere As String
20    strWhere = "Program = '" & strProgram & "' AND Location = '" & strLocation & "' AND Species = '" & strSpecies & "' AND D21 = '" & Format(datDETDate, "yyyy-mm-dd") & "' AND D18 = '" & strDETCategory & "'"
30    lngCorrectValue = DCount("*", "tblCaptures", strWhere)

40    If lngCorrectValue <> lngValue_new Then
        
          ' log the error to tblErrors
          
50        Call LogError("basDET", "logDETSpecies", "Incorrect DET value for " & strWhere & "Correct value=" & lngCorrectValue & " Value to be logged=" & lngValue_new)
60        Call ExportDebuggingLog
          
          ' log the error to tblLog
          
70        strMessage = "ERROR in logDETSpecies(): Band=" & strBandPrefix & "-" & strBandSuffix & _
          " Program=" & strProgram & " Location=" & strLocation & " DET Date=" & Format(datDETDate, "yyyy-mm-dd") & " Species=" & strSpecies & _
          " DETCategory=" & strDETCategory & " Operation=" & strOperation & _
          " lngValue_old=" & CStr(lngValue_old) & " lngValue_new=" & CStr(lngValue_new) & " Correct new value=" & lngCorrectValue
80        log (strMessage)
90    End If

      'Public Type DETSpeciesType
      '    Program           As String
      '    Location          As String
      '    DateEx            As Date
      '    Species           As String
      '    Observed          As Variant
      '    Census            As Variant
      '    Banded            As Variant
      '    Repeats           As Variant
      '    Returns           As Variant
      '    PKS               As Variant           ' no longer used
      '    DET               As Variant
      '    VisibleEx         As Variant           ' not used
      '    Casual            As Variant            ' not used
      '    Observed3         As Variant           ' Alien
      '    Observed4         As Variant           ' Replacement
      '    NonStandardBanded As Variant           ' not used
      '    NonStandardRecaps As Variant           ' not used
      '    DailySpeciesTotal As Variant           ' not used
      '    Timestamp         As Date
      '    Command           As String
      '    Source            As String
      'End Type


      Dim rec  As DETSpeciesType

100   rec.Program = strProgram
110   rec.Location = strLocation
120   rec.DateEx = datDETDate
130   rec.Species = strSpecies
140   rec.Observed = Null
150   rec.Census = Null
160   rec.Banded = Null
170   rec.Repeats = Null
180   rec.Returns = Null
190   rec.PKS = Null
200   rec.DET = Null
210   rec.VisibleEx = Null
220   rec.Casual = Null
230   rec.Observed3 = Null
240   rec.Observed4 = Null
250   rec.NonStandardBanded = Null
260   rec.NonStandardRecaps = Null
270   rec.DailySpeciesTotal = Null
280   rec.Timestamp = Now
290   rec.Command = " DETCategory=" & strDETCategory & " Operation=" & strOperation & _
          " lngValue_old=" & CStr(lngValue_old) & " lngValue_new=" & CStr(lngValue_new) & " Correct new value=" & lngCorrectValue
300   rec.Source = "logDETSpecies"
301   Call Log_DETSpecies(rec)


      'strSQL = _
      '    " INSERT INTO tblDETSpeciesLog " & _
      '    " (BandPrefix, BandSuffix, Program, Location, Species, DateEx, DETCategory, Operation, OldValue, NewValue, CorrectValue, TimestampEx) " & _
      '    " VALUES('" & strBandPrefix & "','" & strBandSuffix & "','" & _
      '    strProgram & "','" & strLocation & "','" & strSpecies & "',#" & Format(datDETDate, "mm/dd/yyyy") & "#,'" & strDETCategory & "','" & strOperation & "'," & _
      '    lngValue_old & "," & lngValue_new & "," & lngCorrectValue & ",'" & Format(Now(), "yyyy-mm-dd hh\hmm") & "')"

   ' CurrentDb.Execute (strSQL)

          'DD Error Handler Start
Exit_label:
320       Exit Sub
Err_label:
330       Select Case Err.Number
          Case Else
340      Call LogError("basDET", "logDETSpecies")
350       End Select
360       Resume Exit_label
          ' DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
'UpdateDETSpeciesCategory
'
' Called from UpdateNextCapture, ChangeFtoR, DeleteCaptureRecord
'---------------------------------------------------------------------------------------

Public Sub UpdateDETSpeciesCategory( _
    ByVal strProgram As String, ByVal strLocation As String, _
    ByVal datDETDate As Date, ByVal strSpecies As String, _
    ByVal strDETCategory_old As String, ByVal strDETCategory_new As String, _
    ByVal strBandPrefix As String, ByVal strBandSuffix As String)

      Dim strSQL As String
      Dim lngValue_new As Long ' dummy
      
10    On Error GoTo Err_label


20    strSQL = _
          "SELECT * FROM tblDETSpecies " & _
          " WHERE [Program] = '" & strProgram & "' AND " & _
          "       [Location] = '" & strLocation & "' AND " & _
          "       [DateEx] = #" & Format(datDETDate, "mm/dd/yyyy") & "# AND " & _
          "       [Species] = '" & strSpecies & "'"
      Dim rst As DAO.Recordset
30    Set rst = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)
40    If Not rst.EOF Then

        ' N.B. DETSpeciesDecreaseCategory assumes that the DETSpecies record exists  --- and it does exist
        ' The DETSpeciesDecreaseCategory procedure does not delete the DET Species record if all its non-key fields become NUll/0
        ' DETSpeciesIncreaseCategory assume that the DETSpecies record exists   --- and it does exist
        ' After the call of DETSpeciesIncreaseCategory, at least one of the non-key fields > 0
          
50        If strDETCategory_old <> strDETCategory_new Then
60            Call DETSpeciesDecreaseCategory(rst, strDETCategory_old, lngValue_new, strBandPrefix, strBandSuffix)
70            Call DETSpeciesIncreaseCategory(rst, strDETCategory_new, strBandPrefix, strBandSuffix)
80        End If

90    End If
100   rst.Close
110   Set rst = Nothing

      'DD Error Handler Start
Exit_label:
120        Exit Sub
Err_label:
130        Select Case Err.Number
           Case Else
140       Call LogError("basDET", "UpdateDETSpeciesCategory")
150        End Select
160        Resume Exit_label
      'DD Error Handler End


End Sub

'---------------------------------------------------------------------------------------
'ChangeFtoR
'---------------------------------------------------------------------------------------

' Update the disposition of corresponding F records to R
' The old sequence is                              F (DET Category = Alien) > F ( DET Category = Repeat or Return ) > ...
' The new sequence is 1 or 5 (DET Category = Banded) >  R ( DET Category = Repeat or Return ) > R ( DET Category = Repeat or Return )
' Update D18 (DET Category), D20 (Days since most recent capture) of the 1st F (now 1st R) record, and update the corresponding DET record.  The other old F (now R) records do not need to be changed.

' If fUpdatetblCapturesEditOrDelete then update the corresponding records in tblCapturesOrDelete too

Public Sub ChangeFtoR(ByVal strBandPrefix As String, ByVal strBandSuffix As String, Optional ByVal fUpdatetblCapturesEditOrDelete As Boolean, Optional ByVal fLog As Boolean = False)

10    On Error GoTo Err_label
        
      Dim strWhere As String
      Dim strSQL As String
          
      ' Are there any corresponding F records ?

20    strWhere = _
          " [BandPrefix] = '" & strBandPrefix & "' AND " & _
          " [BandSuffix] = '" & strBandSuffix & "' AND " & _
          " [Disposition] = 'F'"
          
      Dim lngCountRelated As Long
30    lngCountRelated = DCount("*", "tblCaptures", strWhere)

40    If lngCountRelated > 0 Then
          
          '   Update R/F of all corresponding tblCaptures F records to R

50        strSQL = _
              " UPDATE tblCaptures " & _
              " SET Disposition = 'R' " & _
              " WHERE " & strWhere
60        CurrentDb.Execute strSQL
          
70        If fLog Then log ("Changed disposition F to R in " & lngCountRelated & " same Band=" & strBandPrefix & "-" & strBandSuffix & " capture records")

80        If fUpdatetblCapturesEditOrDelete Then

          '   Update R/F of all corresponding tblCapturesEditOrDelete F records to R

90            strSQL = _
                  " UPDATE tblCapturesEditOrDelete " & _
                  " SET Disposition = 'R' " & _
                  " WHERE " & strWhere
100           CurrentDb.Execute strSQL
              
110           If fLog Then log ("Changed disposition F to R in " & lngCountRelated & " same Band=" & strBandPrefix & "-" & strBandSuffix & " cached capture records")
          
120       End If
          
          ' Update the DET Category and Days Since Most Recent Capture of the 1st corresponding (now) R record.  It is the record whose DET Category (D18) starts off as "Alien"

          Dim rst As DAO.Recordset
130       strWhere = _
              " [BandPrefix] = '" & strBandPrefix & "' AND " & _
              " [BandSuffix] = '" & strBandSuffix & "' AND " & _
              " [D18] = 'Alien'"
140       strSQL = _
              " SELECT * FROM  tblCaptures " & _
              " WHERE " & strWhere
150       Set rst = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)
160       If Not rst.EOF Then

              Dim lngIDBand_edit As Long
              Dim strProgram_edit As String
              Dim strLocation_edit As String
              Dim datCaptureDate_edit As Date
              Dim strSpecies_edit As String
              Dim varWeightTime_edit As Variant
              Dim datDETDate_edit As Date
              Dim strDETCategory_old As String
              Dim strDETCategory_new As String

170           lngIDBand_edit = Nz(rst("IDBand"))
180           strProgram_edit = Nz(rst("Program"))
190           strLocation_edit = Nz(rst("Location"))
200           datCaptureDate_edit = Nz(rst("CaptureDate"))
210           strSpecies_edit = Nz(rst("Species"))
220           varWeightTime_edit = Nz(rst("WeightTime"))
230           datDETDate_edit = getDETDate(datCaptureDate_edit, varWeightTime_edit, strProgram_edit)
240           strDETCategory_old = Nz(rst("D18"))
                
              Dim fDETCategoryOverride As Boolean
              Dim strReasonDETCategoryUnknown As String ' dummy
              Dim lngDaysSinceMostRecentPriorCapture As Long
          
250           fDETCategoryOverride = True
260           Call DETCategory(lngIDBand_edit, strDETCategory_new, strReasonDETCategoryUnknown, lngDaysSinceMostRecentPriorCapture, fDETCategoryOverride)
270           Call Update_D18_D20_D21(rst, strDETCategory_new, lngDaysSinceMostRecentPriorCapture, datDETDate_edit, True, "Update related capture DET Fields")

      '270           rst.Edit
      '280           rst("D18") = strDETCategory_new
      '290           If strDETCategory_new = "Return" Or strDETCategory_new = "Repeat" Then
      '300               rst("D20") = lngDaysSinceMostRecentPriorCapture
      '310           Else
      '320               rst("D20") = Null
      '330           End If
      '340           rst.Update

280           If fUpdatetblCapturesEditOrDelete Then

              ' Copy DETCategory, Days Since Most Recent Prior Capture to tblCapturesEditOrDelete record
              
                  Dim rstCapturesEditOrDelete As DAO.Recordset
290               strSQL = "SELECT * FROM tblCapturesEditOrDelete WHERE IDBand = " & lngIDBand_edit
300               Set rstCapturesEditOrDelete = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)
310               If Not rstCapturesEditOrDelete.EOF Then

320                   Call Update_D18_D20_D21(rstCapturesEditOrDelete, strDETCategory_new, lngDaysSinceMostRecentPriorCapture, datDETDate_edit, True, "Update cached related capture DET Fields")

      '                rstCapturesEditOrDelete.Edit
      '                rstCapturesEditOrDelete("D18") = strDETCategory_new
      '                If strDETCategory_new = "Return" Or strDETCategory_new = "Repeat" Then
      '                    rstCapturesEditOrDelete("D20") = lngDaysSinceMostRecentPriorCapture
      '                Else
      '                    rstCapturesEditOrDelete("D20") = Null
      '                End If
      '                rstCapturesEditOrDelete.Update
      '
330               End If
340               rstCapturesEditOrDelete.Close
350               Set rstCapturesEditOrDelete = Nothing

360           End If
              
              ' Update the corresponding DET Species record

370           Call UpdateDETSpeciesCategory(strProgram_edit, strLocation_edit, datDETDate_edit, strSpecies_edit, strDETCategory_old, strDETCategory_new, strBandPrefix, strBandSuffix)

380       End If
390       rst.Close
400       Set rst = Nothing
          
410   End If

      'DD Error Handler Start
Exit_label:
420        Exit Sub
Err_label:
430        Select Case Err.Number
           Case Else
440             Call LogError("basDET", "ChangeFtoR")
450        End Select
460        Resume Exit_label
      'DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' Raw_Add_Daily
'
' Caller must fill in data fields and the Source.  This procedure fills in the Command.  Log_DETDaily() will fill in the Timestamp.
'
' PRE: The DETDaily record does not exist
'
' This procedure is a raw add in that it does not take into account referential integrity
'-----------------------------------------------------------------------------------------------------------------------------------------
 
Public Sub Raw_Add_Daily(ByRef recDaily As DETDailyType)

10    On Error GoTo Err_label

      Dim rst As DAO.Recordset

20    Set rst = CurrentDb.OpenRecordset("tblDETDaily")

30    rst.AddNew
40    rst("Program") = recDaily.Program
50    rst("Location") = recDaily.Location
60    rst("DateEx") = recDaily.DateEx
70    rst("Observers") = recDaily.Observers
80    rst("SongbirdNets") = recDaily.SongbirdNets
90    rst("CoverageCode") = recDaily.CoverageCode
100   rst("OtherTrap") = recDaily.OtherTrap
110   rst.Update
120   rst.Close
130   Set rst = Nothing
          
140   recDaily.Command = "Add"
150   Call Log_DETDaily(recDaily)

          'DD Error Handler Start
Exit_label:
160       Exit Sub
Err_label:
170       Select Case Err.Number
          Case Else
180      Call LogError("basDET", "Raw_Add_Daily")
190       End Select
200       Resume Exit_label
          ' DD Error Handler End
End Sub


'---------------------------------------------------------------------------------------
' SaveDETDaily
'---------------------------------------------------------------------------------------
'
' Update, Create or Delete a DETDaily record based on the arguments
' Referential integrity is established
'
' PRE: the key is valid
'
' Tis routine only works with the following Effort fields:
' field           field type                    control name
' ----------------------------------------------------------
' Observers        Decimal Precision 5 Scale 1  txtEffort1
' SongbirdNets     Double                       txtEffort2
' CoverageCode     Decimal Precision 5 Scale 1  txtEffort3
' OtherTrap        Decimal Precision 5 Scale 1  txtEffort6
'
'Public Type DETDailyType
'    Program          As String      ' key
'    Location         As String      ' key
'    DateEx           As Date        ' key
'    Observers        As Variant     ' Observer effort    (txtEffort1)
'    SongbirdNets     As Variant     ' Net hours          (txtEffort2)
'    NonSongbirdNets  As Variant     ' not used
'    JTrap            As Variant     ' not used
'    OtherTrap        As Variant     ' Hummingbird effort (txtEffort6)
'    Heliogoland      As Variant     ' not used
'    VisibleMigration As Variant     ' not used
'    CoverageCode     As Variant     ' Coverage Code      (txtEffort3)
'    Timestamp        As Date        ' not used in this procedure
'    Command          As String      ' not used in this procedure
'    Source           As String      ' filled in, in this procedure
'End Type


Public Sub SaveDETDaily(ByRef recDaily As DETDailyType)

10    On Error GoTo Err_label

      ' If all Daily non-key controls are null/0 and there are no corresponding Species records and there are no corresponding Net Hours records
      '   If there is a Daily record
      '       Delete the Daily record
      ' Else
      '   If there isn't a Daily record
      '       Add a Daily record
      '   Else
      '       Update the Daily record

      Dim fIsNonKeyBlank As Boolean

      ' Are all non-key fields null/0 ?

20    fIsNonKeyBlank = _
          Nz(recDaily.Observers, 0) = 0 And _
          Nz(recDaily.SongbirdNets, 0) = 0 And _
          Nz(recDaily.OtherTrap, 0) = 0 And _
          Nz(recDaily.CoverageCode, 0) = 0

      ' Are there any corresponding Species records ?
      ' Are there any corresponding Net Hours records ?

      Dim strCriterionDET As String
      Dim fSpeciesExist As Boolean
      Dim fNetHoursExist As Boolean

40    strCriterionDET = _
              "Program = '" & recDaily.Program & "' AND " & _
              "Location = '" & recDaily.Location & "' AND " & _
              "DateEx = #" & Format(recDaily.DateEx, "mm/dd/yyyy") & "#"
50    fSpeciesExist = (DCount("*", "tblDETSpecies", strCriterionDET) <> 0)
60    fNetHoursExist = (DCount("*", "tblDETNetHours", strCriterionDET) <> 0)

30    recDaily.Source = "DET Daily: UpdateDETDaily"

70    If fIsNonKeyBlank And Not fSpeciesExist And Not fNetHoursExist Then
80        Call Raw_Delete_Daily(recDaily)
90    Else
100       If DCount("*", "tblDETDaily", strCriterionDET) = 0 Then
110           Call Raw_Add_Daily(recDaily)
120       Else
130           Call Raw_Update_Daily(recDaily)
140       End If
150   End If

    'DD Error Handler Start
Exit_label:
    Exit Sub
Err_label:
    Select Case Err.Number
    Case Else
         Call LogError("basDET", "SaveDETDaily")
    End Select
    Resume Exit_label
    ' DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' Raw_Update_Daily
'
' This is a raw update in the sense that it ignores referential integrity.
' PRE: Daily record exists for the given recDaily.Program, recDaily.Location, recDaily.DateEx
'
'
' Copy the following:
'     argument recDaily.Observers => tblDETDaily.Observers
'     argument recDaily.SongbirdNets => tblDETDaily.SongbirdNets
'     argument CoverageCode => tblDETDaily.CoverageCode
'     argument OtherTrap => tblDETDaily.OtherTrap                         aka Hummingbird Effort
'
' If none of the above values have changed, then the copy does not take place.
'
'
' Tis routine only works with the following Effort fields:
' field           field type                    control name
' ----------------------------------------------------------
' Observers        Decimal Precision 5 Scale 1  txtEffort1
' SongbirdNets     Double                       txtEffort2
' CoverageCode     Decimal Precision 5 Scale 1  txtEffort3
' OtherTrap        Decimal Precision 5 Scale 1  txtEffort6
'
' The caller fills in the data fields and the Source.  This procedure fills in the Command. Log_DETDaily() will fill in the Timestamp.
' ------------------------------------------------------------------------------------------------------------------------------------
 
'Public Type DETDailyType
'    Program          As String
'    Location         As String
'    DateEx           As Date
'    Observers        As Variant     ' Observer effort    (txtEffort1)
'    SongbirdNets     As Variant     ' Net hours          (txtEffort2)
'    NonSongbirdNets  As Variant     ' not used
'    JTrap            As Variant     ' not used
'    OtherTrap        As Variant     ' Hummingbird effort (txtEffort6)
'    Heliogoland      As Variant     ' not used
'    VisibleMigration As Variant     ' not used
'    CoverageCode     As Variant     ' Coverage Code      (txtEffort3)
'    Timestamp        As Date
'    Command          As String
'    Source           As String
'End Type
'
' Called from SaveDETDaily
 
Public Sub Raw_Update_Daily(ByRef recDaily As DETDailyType)

10    On Error GoTo Err_label

      Dim strCriterion As String
      Dim strSQL As String
      Dim rst As DAO.Recordset

      Dim fUpdatePerformed As Boolean
20    fUpdatePerformed = False

      Dim dblObservers As Double
      Dim dblSongbirdnets As Double
      Dim dblCoverageCode As Double
      Dim dblOtherTrap As Double

      Dim dblObserversForm As Double
      Dim dblSongbirdNetsForm As Double
      Dim dblCoverageCodeForm As Double
      Dim dblOtherTrapForm As Double

30    recDaily.Command = "Update"

40    strCriterion = _
          "Program = '" & recDaily.Program & "' AND " & _
          "Location = '" & recDaily.Location & "' AND " & _
          "DateEx = #" & Format(recDaily.DateEx, "mm/dd/yyyy") & "#"

50    strSQL = "SELECT * FROM tblDETDaily WHERE " & strCriterion
60    Set rst = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)

70    If Not rst.EOF Then

80        dblObservers = Nz(rst("Observers"))
90        dblSongbirdnets = Nz(rst("SongbirdNets"))
100       dblCoverageCode = Nz(rst("CoverageCode"))
110       dblOtherTrap = Nz(rst("OtherTrap"))
                         
120       dblObserversForm = Nz(recDaily.Observers)
130       dblSongbirdNetsForm = Nz(recDaily.SongbirdNets)
140       dblCoverageCodeForm = Nz(recDaily.CoverageCode)
150       dblOtherTrapForm = Nz(recDaily.OtherTrap)

160       If (dblObservers <> dblObserversForm) Or (dblSongbirdnets <> dblSongbirdNetsForm) Or _
             (dblCoverageCode <> dblCoverageCodeForm) Or (dblOtherTrap <> dblOtherTrapForm) Then
170           rst.Edit
180               rst("Observers") = recDaily.Observers
190               rst("SongbirdNets") = recDaily.SongbirdNets
200               rst("CoverageCode") = recDaily.CoverageCode
210               rst("OtherTrap") = recDaily.OtherTrap
220           rst.Update
230           rst.Close
240           Set rst = Nothing
250           fUpdatePerformed = True
260       End If
270   End If
          
280   If fUpdatePerformed Then
290       Call Log_DETDaily(recDaily)
300   End If

    'DD Error Handler Start
Exit_label:
310       Exit Sub
Err_label:
320       Select Case Err.Number
    Case Else
330      Call LogError("basDET", "Raw_Update_Daily")
340       End Select
350       Resume Exit_label
    ' DD Error Handler End
        
End Sub

'---------------------------------------------------------------------------------------
' Raw_Delete_Daily
'
' Caller must fill in: Program, Location, DateEx, Source
'
' This procedure is a raw delete in that it does not take into account referential integrity
'---------------------------------------------------------------------------------------
 
Public Sub Raw_Delete_Daily(ByRef recDaily As DETDailyType)

20    On Error GoTo Err_label

      Dim strCriterionDET As String
      Dim rst As DAO.Recordset

30    strCriterionDET = _
          "Program = '" & recDaily.Program & "' AND " & _
          "Location = '" & recDaily.Location & "' AND " & _
          "DateEx = #" & Format(recDaily.DateEx, "mm/dd/yyyy") & "#"
          
      Dim strSQL As String
40    strSQL = "DELETE * FROM tblDETDaily WHERE " & strCriterionDET

50    CurrentDb.Execute strSQL

      ' Log

60    recDaily.Timestamp = Now()
70    recDaily.Command = "Delete"
          
80    Call Log_DETDaily(recDaily)

          'DD Error Handler Start
Exit_label:
90        Exit Sub
Err_label:
100       Select Case Err.Number
          Case Else
110      Call LogError("basDET", "Raw_Delete_Daily")
120       End Select
130       Resume Exit_label
          ' DD Error Handler End
End Sub

''---------------------------------------------------------------------------------------
'' Daily_Update_NetHours
''---------------------------------------------------------------------------------------
'
'Public Sub Daily_Update_NetHours(ByVal strProgram As String, ByVal strLocation As String, ByVal datDateEx As Date, ByVal dblNetHours As Double)
'
'10    On Error GoTo Err_label
'
'      Dim recDaily As DETDailyType
'
'20    recDaily.Program = strProgram
'30    recDaily.Location = strLocation
'40    recDaily.DateEx = datDateEx
'50    recDaily.SongbirdNets = IIf(dblNetHours > 0, dblNetHours, Null)
'60    recDaily.Source = "Net Hours: Update Daily SongbirdNets"
'
'70    Call Raw_Update_Daily(recDaily)
'
'          'DD Error Handler Start
'Exit_label:
'80        Exit Sub
'Err_label:
'90        Select Case Err.Number
'          Case Else
'100      Call LogError("basDET", "Daily_Update_NetHours")
'110       End Select
'120       Resume Exit_label
'          ' DD Error Handler End
'
'End Sub

'---------------------------------------------------------------------------------------
' Daily_Exists
'
' Given a key (Program, Location, DateEx) determine if a DETDaily record exists
'---------------------------------------------------------------------------------------
 
Public Function Daily_Exists(ByVal strProgram As String, ByVal strLocation As String, ByVal datDateEx As Date) As Boolean
      Dim strCriterionDET As String

10    On Error GoTo Err_label

20    strCriterionDET = _
      "Program = '" & strProgram & "' AND " & _
      "Location = '" & strLocation & "' AND " & _
      "DateEx = #" & Format(datDateEx, "mm/dd/yyyy") & "#"
          
30    Daily_Exists = (DCount("*", "tblDETDaily", strCriterionDET) <> 0)

    'DD Error Handler Start
Exit_label:
40        Exit Function
Err_label:
50        Select Case Err.Number
    Case Else
60       Call LogError("basDET", "Daily_Exists")
70        End Select
80        Resume Exit_label
    ' DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' Daily_Childless
'---------------------------------------------------------------------------------------
' Determine if the Daily record has any child species or nethour records (
 
Public Function Daily_Childless(ByVal strProgram As String, ByVal strLocation As String, ByVal datDateEx As Date) As Boolean
10       On Error GoTo Err_label

20    On Error GoTo Err_label

      Dim strCriterion As String
      
30     strCriterion = _
      "Program = '" & strProgram & "' AND " & _
      "Location = '" & strLocation & "' AND " & _
      "DateEx = #" & Format(datDateEx, "mm/dd/yyyy") & "#"
          
40    Daily_Childless = _
          (DCount("*", "tblDETSpecies", strCriterion) = 0) And (DCount("*", "tblDETNetHours", strCriterion) = 0)

    'DD Error Handler Start
Exit_label:
50        Exit Function
Err_label:
60        Select Case Err.Number
    Case Else
70       Call LogError("basDET", "Daily_Childless")
80        End Select
90        Resume Exit_label
    ' DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' Species_Exists
'
' Given  a key (Program, Location, DateEx, Species) determine if a DETSpecies record exists
'---------------------------------------------------------------------------------------
 
Public Function Species_Exists(ByVal strProgram As String, ByVal strLocation As String, ByVal datDateEx As Date, ByVal strSpecies As String) As Boolean

10    On Error GoTo Err_label

      Dim strCriterionDETSpecies As String

20    strCriterionDETSpecies = "DateEx = #" & Format(datDateEx, "mm/dd/yyyy") & "# AND " & _
          "Location = '" & strLocation & "' AND " & _
          "Program = '" & strProgram & "' AND " & _
          "Species = '" & strSpecies & "'"
          
30    Species_Exists = (DCount("*", "tblDETSpecies", strCriterionDETSpecies) > 0)

    'DD Error Handler Start
Exit_label:
40        Exit Function
Err_label:
50        Select Case Err.Number
    Case Else
60       Call LogError("basDET", "Species_Exists")
70        End Select
80        Resume Exit_label
    ' DD Error Handler End
          
End Function

'---------------------------------------------------------------------------------------
' Raw_Add_Species

' Caller must fill in data fields and the Source.  This procedure fills in the Command.  Log_DETSpecies() will fill in the Timestamp.
'
' PRE: The DETDaily record does not alreadyexist
'
' This procedure is a raw add in that it does not take into account referential integrity
'
' -----------------------------------------------------------------------------------------
 
Public Sub Raw_Add_Species(ByRef rec As DETSpeciesType)

10    On Error GoTo Err_label

      Dim rst As DAO.Recordset

20    Set rst = CurrentDb.OpenRecordset("tblDETSpecies", dbOpenDynaset)
30    rst.AddNew
40    rst("Program") = rec.Program
50    rst("Location") = rec.Location
60    rst("DateEx") = rec.DateEx
70    rst("Species") = rec.Species
80    rst("Observed") = rec.Observed
90    rst("Census") = rec.Census
100   rst("Banded") = rec.Banded
110   rst("Repeats") = rec.Repeats
120   rst("Returns") = rec.Returns
130   rst("PKS") = rec.PKS
140   rst("DET") = rec.DET
150   rst("VisibleEx") = rec.VisibleEx
160   rst("Casual") = rec.Casual
170   rst("Observed3") = rec.Observed3
180   rst("Observed4") = rec.Observed4
190   rst("NonStandardBanded") = rec.NonStandardBanded
200   rst("NonStandardRecaps") = rec.NonStandardRecaps
210   rst("DailySpeciesTotal") = rec.DailySpeciesTotal
220   rst.Update
230   rst.Close

      ' Log
          
250   rec.Command = "Add"
260   Call Log_DETSpecies(rec)
     
          'DD Error Handler Start
Exit_label:
270       Exit Sub
Err_label:
280       Select Case Err.Number
          Case Else
290      Call LogError("basDET", "Raw_ Add_Species")
300       End Select
310       Resume Exit_label
          ' DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' Delete_Species
'
' Delete a record from tblDETSpecies
' This procedures doe not fix referential integrity
'---------------------------------------------------------------------------------------

Public Sub Delete_Species(ByRef rec As DETSpeciesType)

10    On Error GoTo Err_label

      Dim strCriterionDETSpecies As String
      Dim strSQL As String
      Dim rst As DAO.Recordset

20    strCriterionDETSpecies = _
          "DateEx = #" & Format(rec.DateEx, "mm/dd/yyyy") & "# AND " & _
          "Location = '" & rec.Location & "' AND " & _
          "Program = '" & rec.Program & "' AND " & _
          "Species = '" & rec.Species & "'"
30    strSQL = "DELETE * FROM tblDETSpecies WHERE " & strCriterionDETSpecies

40    CurrentDb.Execute strSQL

      ' Log

50    rec.Source = "DET Species"
60    rec.Command = "Delete"

70    Call Log_DETSpecies(rec)

          'DD Error Handler Start
Exit_label:
80        Exit Sub
Err_label:
90        Select Case Err.Number
          Case Else
100      Call LogError("basDET", "Delete_Species")
110       End Select
120       Resume Exit_label
          ' DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' Update_Species
'
' Caller must fill in all data fields and Source.
'---------------------------------------------------------------------------------------
' The key is Parent.Program, Parent.Location, Parent.DateEx, Me.Species
' Update the tblDETSpecies record using the values in the controls
'
' The tblDETSpecies record should already exist, but if it doesn't, this procedure does nothing
 
Public Sub Update_Species(ByRef recSpecies As DETSpeciesType)
10    On Error GoTo Err_label

      Dim rst As DAO.Recordset
      Dim strCriterionDETSpecies As String
      Dim fUpdatePerformed As Boolean

20    fUpdatePerformed = False

30    strCriterionDETSpecies = "DateEx = #" & Format(recSpecies.DateEx, "mm/dd/yyyy") & "# AND " & _
               "Location = '" & recSpecies.Location & "' AND " & _
               "Program = '" & recSpecies.Program & "' AND " & _
               "Species = '" & recSpecies.Species & "'"

      Dim strSQL As String
40    strSQL = "SELECT * FROM tblDETSpecies WHERE " & strCriterionDETSpecies

50    Set rst = CurrentDb.OpenRecordset(strSQL)
              
60    If Not rst.EOF Then
70        rst.Edit
80        rst("Observed") = recSpecies.Observed
90        rst("Census") = recSpecies.Census
100       rst("Banded") = recSpecies.Banded
110       rst("Repeats") = recSpecies.Repeats
120       rst("Returns") = recSpecies.Returns
130       rst("PKS") = recSpecies.PKS
140       rst("DET") = recSpecies.DET
150       rst("VisibleEx") = recSpecies.VisibleEx
160       rst("Casual") = recSpecies.Casual
170       rst("Observed3") = recSpecies.Observed3
180       rst("Observed4") = recSpecies.Observed4
190       rst("NonStandardBanded") = recSpecies.NonStandardBanded
200       rst("NonStandardRecaps") = recSpecies.NonStandardRecaps
210       rst("DailySpeciesTotal") = recSpecies.DailySpeciesTotal
220       rst.Update
230       fUpdatePerformed = True
240   End If
250   rst.Close
260   Set rst = Nothing

      ' Log

270   If fUpdatePerformed Then
         
280       recSpecies.Source = "DET Species"
290       recSpecies.Command = "Update"
          
300       Call Log_DETSpecies(recSpecies)
310   End If

    'DD Error Handler Start
Exit_label:
320       Exit Sub
Err_label:
330       Select Case Err.Number
    Case Else
340      Call LogError("basDET", "Update_Species")
350       End Select
360       Resume Exit_label
    ' DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' ExportDETSheet
'--------------------------------------------------------------------------------------
' Noot called
'
' Does nothing if the DETDaily record does not exist
' Exports to the "Export Folder"
' Exports the DET sheet to a single Excel file (there are 3 sheets)
' Returns
'     fExportOK
'     (if fExportOK) the full path to the exported Excel file


Public Sub ExportDETSheet(ByVal strProgram As String, ByVal strLocation As String, ByVal datDateEx As Date, _
    ByRef fExportOK As Boolean, ByRef strFilepath As String)

10    On Error GoTo Err_label

20    fExportOK = True
        
      Dim ErrNumber As Long
      Dim ErrDescription As String
      Dim datTimestamp As Date
      Dim strExportFolder As String
      Dim strFilename As String
      Dim strCriterionDET As String
      Dim strClauseProgram As String
      Dim strClauseLocation As String
      Dim strClauseDateEX As String
      Dim strSQL As String

30    datTimestamp = Now()

40    strExportFolder = GetExportFolder()
50    strFilename = Format(datTimestamp, "yyyy-mm-dd hh\hnn\sss") & " DET Sheet " & strProgram & " " & strLocation & " " & Format(datDateEx, "yyyy-mm-dd")
60    strFilepath = TrailingSlash(strExportFolder) & strFilename

70    strClauseProgram = "Program = '" & strProgram & "'"
80    strClauseLocation = "Location = '" & strLocation & "'"
90    strClauseDateEX = "DateEx = #" & Format(datDateEx, "mm/dd/yyyy") & "#"

100   strCriterionDET = _
      strClauseProgram & " AND " & _
      strClauseLocation & " AND " & _
      strClauseDateEX

110   If fExportOK Then
120       strSQL = "SELECT * FROM tblDETDaily WHERE " & strCriterionDET
130       Call ExportQueryToExcel_v2(strSQL, strFilepath, ErrNumber, ErrDescription, "DET Daily")
140       fExportOK = (ErrNumber = 0)
150   End If

160   If fExportOK Then
170       strSQL = "SELECT * FROM tblDETSpecies WHERE " & strCriterionDET
180       Call ExportQueryToExcel_v2(strSQL, strFilepath, ErrNumber, ErrDescription, "DET Species")
190       fExportOK = (ErrNumber = 0)
200   End If

210   If fExportOK Then
220       strSQL = "SELECT * FROM tblDETNetHours WHERE " & strCriterionDET
230       Call ExportQueryToExcel_v2(strSQL, strFilepath, ErrNumber, ErrDescription, "DET Net Hours")
240       fExportOK = (ErrNumber = 0)
250   End If

          'DD Error Handler Start
Exit_label:
260       Exit Sub
Err_label:
270       Select Case Err.Number
          Case Else
280      Call LogError("basDET", "ExportDETSheet")
290       End Select
300       Resume Exit_label
          ' DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' ExportQueryToExcel_v2
'---------------------------------------------------------------------------------------
' strSQL is an SQL SELECT statement

' Dim lngErrNumber As Long
' Dim strErrDescription As String
' Call ExportQueryToExcel_v2( strSQL,  strFilepath,  lngErrNumber,  strErrDescription, strSheetName)

Public Sub ExportQueryToExcel_v2(ByVal strSQL As String, ByVal strFilepath As String, ByRef ErrNumber As Long, ByRef ErrDescription As String, ByVal strSheetName As String)

      Dim qdf As DAO.QueryDef

10    On Error Resume Next
20    CurrentDb.QueryDefs.Delete "TempQuery"
30    On Error GoTo Err_label

40    Set qdf = CurrentDb.CreateQueryDef("TempQuery", strSQL)

50    On Error Resume Next
60    DoCmd.TransferSpreadsheet acExport, acSpreadsheetTypeExcel8, qdf.Name, strFilepath, True, strSheetName
70    If Err.Number <> 0 Then
80        ErrNumber = Err.Number
90        ErrDescription = Err.Description
100       Err.Clear
110   Else
120       ErrNumber = 0
130       ErrDescription = ""
140   End If

150   CurrentDb.QueryDefs.Delete "TempQuery"
160   On Error GoTo Err_label

          'DD Error Handler Start
Exit_label:
170       Exit Sub
Err_label:
180       Select Case Err.Number
          Case Else
190            Call LogError("Form_frmDETViewDaily2", "ExportQueryToExcel")
200       End Select
210       Resume Exit_label
          ' DD Error Handler End

End Sub

Public Sub Test_ExportQueryToExcel()
Dim lngErrNumber As Long
Dim strErrDescription As String
Call ExportQueryToExcel_v2("SELECT * FROM tblAge", "D:\Downloads\test", lngErrNumber, strErrDescription, "test")
End Sub



'---------------------------------------------------------------------------------------
' getCensusCoverageCode
'---------------------------------------------------------------------------------------
' 1 if census took place, otherwise 0
'

Public Function getCensusCoverageCode(ByVal strProgram As String, ByVal strLocation As String, ByVal datDateEx As Date) As Double

10    On Error GoTo Err_label

20    getCensusCoverageCode = 0

60    If strProgram = "" Or strLocation = "" Or datDateEx = 0 Then GoTo Exit_label

Dim strWhere As String

70    strWhere = _
    "[Program] = '" & strProgram & "' AND " & _
    "[Location] = '" & strLocation & "' AND " & _
    "[DateEx] = #" & Format(datDateEx, "mm/dd/yyyy") & "#"
    
80    If DSum("[Census]", "tblDETSpecies", strWhere) > 0 Then
90        getCensusCoverageCode = 1
100   Else
110       getCensusCoverageCode = 0
120   End If


    'DD Error Handler Start
Exit_label:
    Exit Function
Err_label:
    Select Case Err.Number
    Case Else
         Call LogError("basDET", "getCensusCoverageCode")
    End Select
    Resume Exit_label
    ' DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' getBandingCoverageCode
'---------------------------------------------------------------------------------------
'
' PRE: txtEffort2 contains the Net Hours
'
 
Public Function getBandingCoverageCode(ByVal dblNetHours As Double) As Double

   On Error GoTo Err_label

10    On Error GoTo Err_label


      Dim dblBandingCoverageCode As Double
      


20    If dblNetHours < 1 Then
30        dblBandingCoverageCode = 0
40    ElseIf dblNetHours < 25 Then
50        dblBandingCoverageCode = 0.5
60    ElseIf dblNetHours < 50 Then
70        dblBandingCoverageCode = 1
80    ElseIf dblNetHours < 75 Then
90        dblBandingCoverageCode = 1.5
100   Else
110       dblBandingCoverageCode = 2
120   End If

130   getBandingCoverageCode = dblBandingCoverageCode


    'DD Error Handler Start
Exit_label:
    Exit Function
Err_label:
    Select Case Err.Number
    Case Else
         Call LogError("basDET", "getBandingCoverageCode")
    End Select
    Resume Exit_label
    ' DD Error Handler End
End Function


'---------------------------------------------------------------------------------------
' getObservationsCoverageCode
'---------------------------------------------------------------------------------------
'
' PRE: txtEffort1 contains the Observer Hours

Public Function getObservationsCoverageCode(ByVal dblObserverHours As Double) As Double


Dim dblObservationsCoverageCode As Double

   On Error GoTo Err_label

10       On Error GoTo Err_label

30    If dblObserverHours < 0.5 Then
40        dblObservationsCoverageCode = 0
50    ElseIf dblObserverHours < 3 Then
60        dblObservationsCoverageCode = 0.5
70    ElseIf dblObserverHours < 6 Then
80        dblObservationsCoverageCode = 1
90    ElseIf dblObserverHours < 9 Then
100       dblObservationsCoverageCode = 1.5
110   Else
120       dblObservationsCoverageCode = 2
130   End If

140   getObservationsCoverageCode = dblObservationsCoverageCode

    'DD Error Handler Start
Exit_label:
    Exit Function
Err_label:
    Select Case Err.Number
    Case Else
         Call LogError("basDET", "getObservationsCoverageCode")
    End Select
    Resume Exit_label
    ' DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' VerifyDETCaptureFields_Period
'
' For a given Program, Location and a between the given DET dates,
' Validate the Banding info (Banded, Repeats, Returns, Observed3(Alien), Observed4(Replacement) in the tblDETSpecies records against tblCaptures
' Auto correct
'
' PRE: The DETCategory(D18), D20(Number of days since most recent prior (but not same day) capture  (for "Repeat" and "Return" only)) and D21(DET Date) fields are correct
'---------------------------------------------------------------------------------------
' Exclude Disposition 4 and 8 records. Their DET dates should by Null.

 
Public Sub VerifyDETCaptureFields_Period(ByVal strProgram As String, ByVal strLocation As String, ByVal datFrom As Date, ByVal datTo As Date, ByRef fSuccess As Boolean, _
    Optional ByVal fEmailErrors As Boolean = True)

10    On Error GoTo Err_label

      Dim rst As DAO.Recordset
      Dim strSQL As String

20    fSuccess = True

      Dim fRegenerateDETCategory As Boolean
      Dim fCreate_tblDET3 As Boolean

30    fRegenerateDETCategory = False
40    fCreate_tblDET3 = True

      ' tblDET3 has one record per DET Date. It contains
      '       ID (autonumber)
      '       Program     will be the same for all records
      '       Location    will be the same for all records
      '       DateEx      DET date
      '       Species     pseudo-species
      '       Banded      count of disposition 1 records
      '       Return
      '       Repeat
      '       Alien
      '       Replacement
      '       Unknown

      Dim cntRecords As Long
50    Call Create_tblDET3(cntRecords, strProgram, strLocation, "Create", datFrom, datTo)

60    Call ValidateDETCaptureFields_Period(strProgram, strLocation, datFrom, datTo, fSuccess, strExtraInfoForErrorLogging:="before auto correction")

70    If Not fSuccess Then

          ' Auto correct the DET

80        fRegenerateDETCategory = False
90        fCreate_tblDET3 = False

100       If Not UpdateDETProgram(fRegenerateDETCategory, fCreate_tblDET3, strProgram, strLocation, datFrom, datTo) Then
110           Call LogError( _
                  "basDET", _
                  "VerifyDETCaptureFields_Period", _
                  "Failed to auto correct the DET sheets - unable to continue " & "Program = " & strProgram & ", Date From = " & Format(datFrom, "yyyy mmm dd") & ", Date To = " & Format(datTo, "yyyy mmm dd"), _
                  Silent:=False)
120               fSuccess = False
130               GoTo Exit_label
140       End If
          
          ' Revalidate
          
150       Call ValidateDETCaptureFields_Period(strProgram, strLocation, datFrom, datTo, fSuccess, strExtraInfoForErrorLogging:="after auto correction")
160       If Not fSuccess Then
170           Call LogError( _
                  "basDET", _
                  "VerifyDETCaptureFields_Period", _
                  "Failed to auto correct the DET sheets - unable to continue" & strProgram, _
                  Silent:=False)
180               fSuccess = False
190           GoTo Exit_label
200       End If

210   End If

          'DD Error Handler Start
Exit_label:
220       Exit Sub
Err_label:
230       Select Case Err.Number
          Case Else
240            Call LogError("basDET", "VerifyDETCaptureFields_Period")
250       End Select
260       Resume Exit_label
          ' DD Error Handler End

End Sub


'---------------------------------------------------------------------------------------
' ValidateDETCaptureFields_Period
'
' datFrom and datTo are DET dates
'     For Owling programs datFrom and DateTo should be DateSerial(1900,1,1) and DateSerial(3000,1,1) respectively. (Owling programs have 1 period)
'     For non-Owling programs capture dates are the same as DET dates, so you can use capture dates
'
' tblDET3 has been created
'
' strExtraInfoForErrorLogging might be:
'      "before auto correction"
'      "after auto correction"
'      ""
'---------------------------------------------------------------------------------------
 
Public Sub ValidateDETCaptureFields_Period( _
    ByVal strProgram As String, ByVal strLocation As String, ByVal datFrom As Date, ByVal datTo As Date, _
    ByRef fSuccess As Boolean, _
    Optional ByVal fEmailErrors As Boolean = True, Optional ByVal strExtraInfoForErrorLogging As String = "")
          
10    On Error GoTo Err_label

20    fSuccess = True

      Dim datDateEx As Date
      Dim strSpecies As String
      Dim lngBanded_DET As Long
      Dim lngReturn_DET As Long
      Dim lngRepeat_DET As Long
      Dim lngAlien_DET As Long
      Dim lngReplacement_DET As Long
      Dim lngBanded_Captures As Long
      Dim lngReturn_Captures As Long
      Dim lngRepeat_Captures As Long
      Dim lngAlien_Captures As Long
      Dim lngReplacement_Captures As Long

      ' Are there any records in tblDET3 that are missing from the DET

      ' qryDETCombinedWeeklyReportsValidateProgram_Missing_DET
      ' ------------------------------------------------------
      ' tblDET3 LEFT OUTER JOIN tblDETSpecies
      ' WHERE tblDET.Program = NULL
      ' REPORT (the reported fields are from tblDET3) Program, Location, DateEx, species, Banded, Return, Repeat, Alien, Replacement

      Dim rst As DAO.Recordset
30    Set rst = CurrentDb.OpenRecordset("qryDETCombinedWeeklyReportsValidateProgram_Missing_DET", dbOpenDynaset)

40    fSuccess = rst.EOF

50    Do While Not rst.EOF

60        datDateEx = Nz(rst("DateEx"))
70        strSpecies = Nz(rst("Species"))
80        lngBanded_Captures = Nz(rst("Banded"))
90        lngReturn_Captures = Nz(rst("Return"))
100       lngRepeat_Captures = Nz(rst("Repeat"))
110       lngAlien_Captures = Nz(rst("Alien"))
120       lngReplacement_Captures = Nz(rst("Replacement"))
          
130       Call LogError("basDET", "ValidateDETCaptureFields_Period", _
              "In tblCaptures but missing from tblDETSpecies " & strExtraInfoForErrorLogging & _
              ": Program = " & strProgram & _
              ", DET Date = " & Format(datDateEx, "yyyy mmm dd") & _
              ", Species = " & strSpecies & _
              ", Banded = " & lngBanded_Captures & _
              ", Returns = " & lngReturn_Captures & _
              ", Repeats = " & lngRepeat_Captures & _
              ", Alien = " & lngAlien_Captures & _
              ", Replacement = " & lngReplacement_Captures, _
              Silent:=True, fEmailError:=fEmailErrors)

140       rst.MoveNext
150   Loop
160   rst.Close
170   Set rst = Nothing

      ' Are there any records (for the given Program and Location) in the DET that are missing from tblDET3

      ' qryDETCombinedWeeklyReportValidateProgram_Missing_Capture
      ' ---------------------------------------------------------
      ' tblDETSpecies LEFT OUTER JOIN tblDET3
      '
      ' WHERE Program = argProgram
      ' WHERE Location = argLocation
      ' WHERE DateEx BETWEEN argFrom AND argTo                           DET dates
      ' WHERE tblDET3.Program is Null
      ' WHERE Nz([tblDETSpecies].[Banded])+Nz([tblDETSpecies].[Returns])+Nz([tblDETSpecies].[Repeats])+Nz([tblDETSpecies].[Observed3])+nz([tblDETSpecies].[Observed4]) > 0
      ' REPORT (all reported fields are from tblDETSpecies) Program, Location, DateEx, Species, Banded, returns, repeats, Alien(Observed3), Replacement(Observed4)


      Dim qdf As DAO.QueryDef
180   Set qdf = CurrentDb.QueryDefs("qryDETCombinedWeeklyReportValidateProgram_Missing_Capture")
190   qdf.Parameters("argProgram").value = strProgram
200   qdf.Parameters("argLocation").value = strLocation
210   qdf.Parameters("argFrom").value = datFrom
220   qdf.Parameters("argTo").value = datTo

230   Set rst = qdf.OpenRecordset


240   fSuccess = fSuccess And rst.EOF


250   Do While Not rst.EOF

260       datDateEx = Nz(rst("DateEx"))
270       strSpecies = Nz(rst("Species"))
280       lngBanded_DET = Nz(rst("Banded"))
290       lngReturn_DET = Nz(rst("Returns"))
300       lngRepeat_DET = Nz(rst("Repeats"))
310       lngAlien_DET = Nz(rst("Alien"))
320       lngReplacement_DET = Nz(rst("Replacement"))
            
330       Call LogError("basDET", "ValidateDETCaptureFields_Period", _
              "In tblDETSpecies but missing from tblCaptures " & strExtraInfoForErrorLogging & _
              ": Program = " & strProgram & _
              ", DET Date = " & Format(datDateEx, "yyyy mmm dd") & _
              ", Species = " & strSpecies & _
              ", Banded = " & lngBanded_DET & _
              ", Returns = " & lngReturn_DET & _
              ", Repeats = " & lngRepeat_DET & _
              ", Alien = " & lngAlien_DET & _
              ", Replacement = " & lngReplacement_DET, _
              Silent:=True, fEmailError:=fEmailErrors)
              
340         rst.MoveNext
350   Loop
360   rst.Close
370   Set rst = Nothing

      ' Are there any contradictory records (for the given Program and Location) between the DET and captures


      ' qryDETCombinedWeeklyReportsValidateProgram_Inconsistent
      ' -------------------------------------------------------
      ' tblDETSpecies x tblDET3
      '
      ' WHERE tblDETSpecies.Banded <> tblDET3.Banded OR
      '       tblDETSpecies.Returns <> tblDET3.Returns OR
      '       tblDETSpecies.Repeats <> tblDET3.Repeats OR
      '       tblDETSpecies.Observed3 <> tblDET3.Alien OR
      '       tblDETSpecies.Observed4<> tblDET3.Replacement
      ' REPORT Program, Location. DateEx, SpeciestblDETSpecies.Banded,
      '       tblDETSpecies.Banded, tblDET3.Banded
      '       tblDETSpecies.Returns, tblDET3.Returns
      '       tblDETSpecies.Repeats,tblDET3.Repeats
      '       tblDETSpecies.Observed3,tblDET3.Alien
      '       tblDETSpecies.Observed4, tblDET3.Replacement


380   Set qdf = CurrentDb.QueryDefs("qryDETCombinedWeeklyReportsValidateProgram_Inconsistent")

390   Set rst = qdf.OpenRecordset

400   fSuccess = fSuccess And rst.EOF

410   Do While Not rst.EOF

420       datDateEx = Nz(rst("DateEx"))
430       strSpecies = Nz(rst("Species"))
440       lngBanded_DET = Nz(rst("Banded_DET"))
450       lngReturn_DET = Nz(rst("Return_DET"))
460       lngRepeat_DET = Nz(rst("Repeat_DET"))
470       lngAlien_DET = Nz(rst("Alien_DET"))
480       lngReplacement_DET = Nz(rst("Replacement_DET"))
490       lngBanded_Captures = Nz(rst("Banded_Captures"))
500       lngReturn_Captures = Nz(rst("Return_Captures"))
510       lngRepeat_Captures = Nz(rst("Repeat_Captures"))
520       lngAlien_Captures = Nz(rst("Alien_Captures"))
530       lngReplacement_Captures = Nz(rst("Replacement_Captures"))
          
540       Call LogError("basDET", "ValidateDETCaptureFields_Period", _
              "Incorrect banding data in tblDETSpecies " & strExtraInfoForErrorLogging & _
              ": Program = " & strProgram & _
              ", DET Date = " & Format(datDateEx, "yyyy mmm dd") & _
              ", Species = " & strSpecies & _
              ", DET: BND= " & lngBanded_DET & _
              ", RET= " & lngReturn_DET & _
              ", REP=" & lngRepeat_DET & _
              ", Alien=" & lngAlien_DET & _
              ", Repl.= " & lngReplacement_DET & _
              ", CAPTURES: BND= " & lngBanded_Captures & _
              ", RET= " & lngReturn_Captures & _
              ", REP= " & lngRepeat_Captures & _
              ", Alien=" & lngAlien_Captures & _
              ", Repl.= " & lngReplacement_Captures, _
              Silent:=True, fEmailError:=fEmailErrors)
        
550       rst.MoveNext
560   Loop

570   rst.Close
580   Set rst = Nothing

          'DD Error Handler Start
Exit_label:
590       Exit Sub
Err_label:
600       Select Case Err.Number
          Case Else
610            Call LogError("basDET", "ValidateDETCaptureFields_Period")
620       End Select
630       Resume Exit_label
          ' DD Error Handler End
          
End Sub
