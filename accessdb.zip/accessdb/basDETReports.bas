'---------------------------------------------------------------------------------------
' Module    : basDETReports
' Author    : David Davey
'---------------------------------------------------------------------------------------

Option Compare Database
Option Explicit

'---------------------------------------------------------------------------------------
' FirstOfMonitoringProgramByPeriod
'---------------------------------------------------------------------------------------
 
Public Sub FirstOfMonitoringProgramByPeriod( _
    ByRef oExcel As Excel.Application, _
    ByRef oBook As Excel.Workbook, _
    ByVal strLocation As String, _
    ByVal strProgram As String, _
    ByVal intReportYear As Integer, _
    ByVal strSeason As String)
          
10    On Error GoTo Err_label

      ' tblDETFirstOfReport
      ' ===================
      ' Program
      ' Location
      ' Species
      ' SpeciesDescriptionMBO
      ' AOUOrder
      ' Period                  Period 1, 2, ...
      ' FirstDayOfPeriod
      ' LastDayOfPeriod
      ' YearEX
      ' ObservedFirstDate     Date of first observation in program/location IF in this period
      ' BandedFirstDate       Date of first banding in program/location IF in this period
      ' RepeatedFirstDate     Date of first repeat in program/location IF in this period
      ' ReturnsFirstDate      Date of first return in program/location IF in this period
      ' PKSFirstDate          Date of first PKS in program/location IF in this period
      ' DETFirstDate          Date of first DET in program/location IF in this period

      ' ZAP tblDETFirstOfReport

20    CurrentDb.Execute "DELETE * FROM tblDETFirstOfReport"

      ' Determine the first and last date of the monitoring program

      Dim datFirstDateProgram As Date
      Dim datLastDateProgram  As Date
      Dim intTotalPeriods     As Integer

      Dim strWhere As String
30    strWhere = "[Program] = '" & strProgram & "' AND " & _
          "[Location] = '" & strLocation & "'"
          
40    If 0 = DCount("*", "tblDETSpecies", strWhere) Then
50        MsgBox "There are no DET records for given Program and Location", , "First of Program by Week or Period"
60        Exit Sub
70    End If
          
80    Call getProgramPeriods(strProgram, strSeason, _
          datFirstDateProgram, datLastDateProgram, intTotalPeriods)
           
90    If datFirstDateProgram = 0 Then
100       MsgBox "The monitoring program does not have a start date", , "DET First of Program by Week or Period"
110       Exit Sub
120   End If

      ' Open tblDETFirstOfReport

      Dim rstFirstOf As Recordset
130   Set rstFirstOf = CurrentDb.OpenRecordset("tblDETFirstOfReport")
           
      ' Loop over each Period

      Dim datFirstDatePeriod As Date
      Dim datLastDatePeriod As Date

      ' Inialise the progress meter

      Dim retval As Variant
140   retval = SysCmd(acSysCmdInitMeter, "Creating DET First of Monitoring Program by Week or Period Report ...", intTotalPeriods)

      Dim Species As String
      Dim SpeciesDescriptionMBO As String
      Dim intAOUOrder As Long
      Dim datObserved As Date
      Dim datCensus As Date
      Dim datBanded As Date
      Dim datRepeats As Date
      Dim datReturns As Date
      Dim datPKS As Date
      Dim datDET As Date

      Dim intPeriod As Integer
150   For intPeriod = 1 To intTotalPeriods

      ' Update the progress meter

160     retval = SysCmd(acSysCmdUpdateMeter, intPeriod)

      ' qryDETFirstOfProgram
      ' -------------------------------------------------------------------
      ' A list of the species that have DET records for the progam+location
      ' -------------------------------------------------------------------
      ' FROM tblDETSpecies x tblSpecies
      ' Program (argument)
      ' Location (argument)
      '
      ' Species
      ' SpeciesDescription
      ' AOUOrder ASC

      '   Open a recordset for the species

      Dim qdf As QueryDef
170   Set qdf = CurrentDb.QueryDefs("qryDETFirstOfProgram")
180   qdf.Parameters("argProgram").value = strProgram
190   qdf.Parameters("argLocation").value = strLocation

      Dim rstSpecies As DAO.Recordset
200   Set rstSpecies = qdf.OpenRecordset

      '   Loop over all species

210   Do While Not rstSpecies.EOF
               
          
220       Call getFirstAndLastDatePeriod(intReportYear, strSeason, _
              datFirstDateProgram, datLastDateProgram, intPeriod, _
              datFirstDatePeriod, datLastDatePeriod)
          
230       Species = Nz(rstSpecies("Species"), "")
240       SpeciesDescriptionMBO = Nz(rstSpecies("SpeciesDescriptionMBO"), "")
250       intAOUOrder = Nz(rstSpecies("AOUOrder"), 0)
          
          ' datObserved = Nz(DMin("DateEx", "tblDETSpecies", strWhere & " AND ([Observed] > 0) AND [Species] = '" & Species & "'"))
          ' datCensus = Nz(DMin("DateEx", "tblDETSpecies", strWhere & " AND ([Census] > 0) AND [Species] = '" & Species & "'"))
260       datBanded = Nz(DMin("DateEx", "tblDETSpecies", strWhere & " AND ([Banded] > 0) AND [Species] = '" & Species & "'"))
270       datRepeats = Nz(DMin("DateEx", "tblDETSpecies", strWhere & " AND ([Repeats] > 0) AND [Species] = '" & Species & "'"))
280       datReturns = Nz(DMin("DateEx", "tblDETSpecies", strWhere & " AND ([Returns] > 0) AND [Species] = '" & Species & "'"))
290       datDET = Nz(DMin("DateEx", "tblDETSpecies", strWhere & " AND ([DET] > 0) AND [Species] = '" & Species & "'"))
            
300       rstFirstOf.AddNew
310       rstFirstOf("Program") = strProgram
320       rstFirstOf("Location") = strLocation
330       rstFirstOf("Period") = intPeriod
340       rstFirstOf("FirstDayOfPeriod") = datFirstDatePeriod
350       rstFirstOf("LastDayOfPeriod") = datLastDatePeriod
360       rstFirstOf("Species") = Species
370       rstFirstOf("SpeciesDescriptionMBO") = SpeciesDescriptionMBO
380       rstFirstOf("AOUOrder") = intAOUOrder
        
            Dim fWrite As Boolean
390         fWrite = False
            
          '  If (FirstDayOfPeriod <= datObserved) And (datObserved <= LastDayOfPeriod) Then
          '    rstFirstOf("ObservedFirstDate") = datObserved
          '    fWrite = True
          '  End If
            
          '  If (FirstDayOfPeriod <= datCensus) And (datCensus <= LastDayOfPeriod) Then
          '    rstFirstOf("CensusFirstDate") = datCensus
          '    fWrite = True
          '  End If
            
400             If (datFirstDatePeriod <= datBanded) And (datBanded <= datLastDatePeriod) Then
410           rstFirstOf("BandedFirstDate") = datBanded
420           fWrite = True
430             End If
                
440             If (datFirstDatePeriod <= datRepeats) And (datRepeats <= datLastDatePeriod) Then
450           rstFirstOf("RepeatsFirstDate") = datRepeats
460           fWrite = True
470             End If
                
480             If (datFirstDatePeriod <= datReturns) And (datReturns <= datLastDatePeriod) Then
490           rstFirstOf("ReturnsFirstDate") = datReturns
500           fWrite = True
510             End If
            
520           If (datFirstDatePeriod <= datDET) And (datDET <= datLastDatePeriod) Then
530             rstFirstOf("DETFirstDate") = datDET
540             fWrite = True
550           End If
560           If fWrite Then rstFirstOf.Update
570           rstSpecies.MoveNext
580       Loop
590       rstSpecies.Close

600   Next

      ' Close the Progress Meter

610     retval = SysCmd(acSysCmdRemoveMeter)

620   If DCount("*", "tblDETFirstOfReport") = 0 Then
630       MsgBox "The First of Monitoring Program Report is empty"
640       GoTo Exit_label
650   End If

      ' Create an Excel Worksheet

      Dim colLocation As Integer
      Dim colProgram As Integer
      Dim colPeriod As Integer
      Dim colFirstDayOfPeriod As Integer
      Dim colLastDayOfPeriod As Integer
      Dim colSpecies As Integer
      Dim colSpeciesDescription As Integer
      Dim colBandedFirstDate As Integer
      Dim colReturnsFirstDate As Integer
      Dim colRepeatsFirstDate As Integer
      Dim colDETFirstDate As Integer
      Dim colEnd As Integer

660   colLocation = 1
670   colProgram = 2
680   colPeriod = 3
690   colFirstDayOfPeriod = 4
700   colLastDayOfPeriod = 5
710   colSpecies = 6
720   colSpeciesDescription = 7
730   colBandedFirstDate = 8
740   colReturnsFirstDate = 9
750   colRepeatsFirstDate = 10
760   colDETFirstDate = 11
770   colEnd = 11

      Dim datFirstDayOfPeriod As Date
      Dim datLastDayOfPeriod As Date
      Dim strSpeciesDescriptionMBO As String

      Dim oSheet As Excel.Worksheet
780   Set oSheet = oBook.Worksheets.Add(After:=oBook.Worksheets(oBook.Worksheets.count))
790   oSheet.Name = "First " & intReportYear & " " & strSeason

800   With oSheet
       
          ' Fill in headers
          
810       .Cells(3, colLocation) = "Location"
820       .Cells(3, colProgram) = "Program"
830       .Cells(3, colPeriod) = "Week or Period"
840       .Cells(2, colFirstDayOfPeriod) = "First Day"
850       .Cells(3, colFirstDayOfPeriod) = "of Period"
860       .Cells(2, colLastDayOfPeriod) = "Last Day"
870       .Cells(3, colLastDayOfPeriod) = "of Period"
880       .Cells(3, colSpeciesDescription) = "Species"
890       .Cells(2, colBandedFirstDate) = " First Date"
900       .range(.Cells(2, colBandedFirstDate), .Cells(2, colDETFirstDate)).Merge
910       .Cells(3, colBandedFirstDate) = "Banded"
920       .Cells(3, colReturnsFirstDate) = "Returns"
930       .Cells(3, colRepeatsFirstDate) = "Repeats"
940       .Cells(3, colDETFirstDate) = "DET"
          
          Dim rst As DAO.Recordset
950       Set rst = CurrentDb.OpenRecordset("tblDETFirstOfReport", dbOpenDynaset)
          
          Dim strSpecies As String
          Dim lngBanded As Long
          
          Dim row As Long
960       row = 4
          
          Dim rowStart As Integer
970       rowStart = row
          
          Dim intPeriodPrevious As Integer
980       intPeriodPrevious = -1
          
          Dim lngColour As Long
          
990       .Cells(row, colLocation) = strLocation
1000      .Cells(row, colProgram) = strProgram
          
1010      Do While Not rst.EOF
          
1020          intPeriod = Nz(rst("Period"))
1030          datFirstDayOfPeriod = Nz(rst("FirstDayOfPeriod"))
1040          datLastDayOfPeriod = Nz(rst("LastDayOfPeriod"))
1050          strSpecies = Nz(rst("Species"))
1060          strSpeciesDescriptionMBO = Nz(rst("SpeciesDescriptionMBO"))
1070          datBanded = Nz(rst("BandedFirstDate"))
1080          datReturns = Nz(rst("ReturnsFirstDate"))
1090          datRepeats = Nz(rst("RepeatsFirstDate"))
1100          datDET = Nz(rst("DETFirstDate"))
              
1110          If intPeriod <> intPeriodPrevious Then
1120              .Cells(row, colPeriod) = intPeriod
1130              .Cells(row, colFirstDayOfPeriod) = datFirstDayOfPeriod
1140              .Cells(row, colLastDayOfPeriod) = datLastDayOfPeriod
1150              intPeriodPrevious = intPeriod
1160              Select Case intPeriod Mod 4
                  Case 0
1170                  lngColour = RGB(253, 233, 217)
1180              Case 1
1190                  lngColour = RGB(219, 238, 243)
1200              Case 2
1210                  lngColour = RGB(234, 241, 221)
1220              Case 3
1230                  lngColour = RGB(255, 201, 201)
1240              End Select
1250              With .range(.Cells(row, colPeriod), .Cells(row, colEnd)).Borders(xlEdgeTop)
1260                  .LineStyle = xlContinuous
1270                  .Weight = xlThin
1280              End With
1290          End If
1300          If row Mod 2 = 0 Then
1310              .range(.Cells(row, colSpecies), .Cells(row, colEnd)).Interior.Color = lngColour
1320          End If
1330          .Cells(row, colSpecies) = strSpecies
1340          .Cells(row, colSpeciesDescription) = strSpeciesDescriptionMBO
1350          If datBanded <> 0 Then
1360              .Cells(row, colBandedFirstDate) = datBanded
1370          End If
1380          If datReturns <> 0 Then
1390              .Cells(row, colReturnsFirstDate) = datReturns
1400          End If
1410          If datRepeats <> 0 Then
1420              .Cells(row, colRepeatsFirstDate) = datRepeats
1430          End If
1440          If datDET <> 0 Then
1450              .Cells(row, colDETFirstDate) = datDET
1460          End If
                
1470          row = row + 1
1480          rst.MoveNext
1490      Loop
1500      rst.Close
1510      Set rst = Nothing
          
          Dim rowEnd As Long
1520      rowEnd = row - 1
          
1530      .range(.columns(colFirstDayOfPeriod), .columns(colLastDayOfPeriod)).NumberFormat = "d mmm yy"
1540      .range(.columns(colBandedFirstDate), .columns(colDETFirstDate)).NumberFormat = "d mmm yy"
1550      .range(.columns(colPeriod), .columns(colLastDayOfPeriod)).HorizontalAlignment = xlCenter
1560      .range(.columns(colBandedFirstDate), .columns(colDETFirstDate)).HorizontalAlignment = xlCenter
          
1570      .range(.columns(1), .columns(colDETFirstDate)).AutoFit

1580      .Cells(1, 1) = intReportYear & " " & strSeason & " " & "DET First of Monitoring Program by Week or Period Report " & strProgram & " at " & strLocation
1590      .range(.Cells(1, 1), .Cells(1, 1)).HorizontalAlignment = xlLeft
1600      .range(.Cells(1, 1), .Cells(1, 1)).Font.Size = 14
1610      .range(.Cells(1, 1), .Cells(1, 1)).Font.Bold = True

1620  End With

1630  oSheet.range("A4").Select
1640  oExcel.ActiveWindow.FreezePanes = True

1650  Set oSheet = Nothing

      'DD Error Handler Start
Exit_label:
1660       Exit Sub
Err_label:
1670       Select Case Err.Number
           Case Else
1680            Call LogError("basDETReports", "FirstOfMonitoringProgramByPeriod")
1690       End Select
1700       Resume Exit_label
      'DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' FirstOfLocationReport
'---------------------------------------------------------------------------------------
 
Public Sub FirstOfLocationReport( _
    ByRef fValid As Boolean, _
    ByVal strLocation As String, _
    ByRef oExcel As Excel.Application, _
    ByRef oBook As Excel.Workbook)

      ' Save parameters

' 10    strLocation = argLocation

10    fValid = True

      ' tblDETFirstOfReport
      ' Program                 (not used)
      ' Location
      ' Species
      ' SpeciesDescriptionMBO
      ' AOUOrder
      ' Week                    (not used)
      ' FirstDayOfWeek          (not used)
      ' LastDayOfWeek           (not used)
      ' YearEX                  (not used)
      ' ObservedFirstDate     Date of first observation at location
      ' BandedFirstDate       Date of first banding at location
      ' RepeatsFirstDate      Date of first repeat at location
      ' ReturnsFirstDate      Date of first return at location
      ' DETFirstDate          Date of first DET at location

      ' ZAP tblDETFirstOfReport

20    On Error GoTo Err_label

30    CurrentDb.Execute "DELETE * FROM tblDETFirstOfReport"

      Dim strWhere As String
40    strWhere = "[Location] = '" & strLocation & "'"

      ' Loop over all species

       ' qryDETFirstOfLocation
      ' ... a list of the species that have DET records for the location
      ' ... ordered in AOU Order
      ' from tblDETSpecies x tblSpecies
      ' Species
      ' SpeciesDescription
      ' AOUOrder ASC
      '
      ' Location (argument)

      '   Open a recordset for the species

      Dim qdf As QueryDef
50    Set qdf = CurrentDb.QueryDefs("qryDETFirstOfLocation")
60    qdf.Parameters("argLocation").value = strLocation

      Dim rstSpecies As DAO.Recordset
70    Set rstSpecies = qdf.OpenRecordset

80    rstSpecies.MoveLast
      Dim intCountSpecies As Integer
90    intCountSpecies = rstSpecies.RecordCount
100   rstSpecies.MoveFirst

      Dim rstFirstOf As Recordset
110   Set rstFirstOf = CurrentDb.OpenRecordset("tblDETFirstOfReport")

      Dim Species As String
      Dim SpeciesDescriptionMBO As String
      Dim lngAOUOrder As Long
      Dim datObserved As Date
      Dim datCensus As Date
      Dim datBanded As Date
      Dim datRepeats As Date
      Dim datReturns As Date
      Dim datAlien As Date          ' Observed3
      Dim datReplacement As Date    ' Observed4
      Dim datDET As Date
      Dim lngDET As Long

      '   Inialise the progress meter

      Dim retval As Variant
120   retval = SysCmd(acSysCmdInitMeter, "Creating DET First of Location Report ...", intCountSpecies)

130   intCountSpecies = 1
140   Do While Not rstSpecies.EOF

150       If CInt(intCountSpecies / 10) * 10 = intCountSpecies Then
160     SysCmd acSysCmdUpdateMeter, intCountSpecies
170     DoEvents
180       End If
190       intCountSpecies = intCountSpecies + 1

200       Species = Nz(rstSpecies("Species"), "")
210       SpeciesDescriptionMBO = Nz(rstSpecies("SpeciesDescriptionMBO"), "")
220       lngAOUOrder = Nz(rstSpecies("AOUOrder"), 0)

230       datObserved = Nz(DMin("DateEx", "tblDETSpecies", strWhere & " AND ([Observed] > 0) AND [Species] = '" & Species & "'"))
240       datCensus = Nz(DMin("DateEx", "tblDETSpecies", strWhere & " AND ([Census] > 0) AND [Species] = '" & Species & "'"))
250       datBanded = Nz(DMin("DateEx", "tblDETSpecies", strWhere & " AND ([Banded] > 0) AND [Species] = '" & Species & "'"))
260       datRepeats = Nz(DMin("DateEx", "tblDETSpecies", strWhere & " AND ([Repeats] > 0) AND [Species] = '" & Species & "'"))
270       datReturns = Nz(DMin("DateEx", "tblDETSpecies", strWhere & " AND ([Returns] > 0) AND [Species] = '" & Species & "'"))
280       datAlien = Nz(DMin("DateEx", "tblDETSpecies", strWhere & " AND ([Observed3] > 0) AND [Species] = '" & Species & "'"))
290       datReplacement = Nz(DMin("DateEx", "tblDETSpecies", strWhere & " AND ([Observed4] > 0) AND [Species] = '" & Species & "'"))
300       datDET = Nz(DMin("DateEx", "tblDETSpecies", strWhere & " AND ([DET] > 0) AND [Species] = '" & Species & "'"))
310       lngDET = Nz(DSum("DET", "tblDETSpecies", strWhere & " AND [Species] = '" & Species & "'"))

320       rstFirstOf.AddNew
'340       rstFirstOf("Program") = strProgram
330       rstFirstOf("Location") = strLocation
340       rstFirstOf("Species") = Species
350       rstFirstOf("SpeciesDescriptionMBO") = SpeciesDescriptionMBO
360       rstFirstOf("AOUOrder") = lngAOUOrder
370       rstFirstOf("ObservedFirstDate") = IIf(datObserved = 0, Null, datObserved)
380       rstFirstOf("CensusFirstDate") = IIf(datCensus = 0, Null, datCensus)
390       rstFirstOf("BandedFirstDate") = IIf(datBanded = 0, Null, datBanded)
400       rstFirstOf("RepeatsFirstDate") = IIf(datRepeats = 0, Null, datRepeats)
410       rstFirstOf("ReturnsFirstDate") = IIf(datReturns = 0, Null, datReturns)
420       rstFirstOf("AlienFirstDate") = IIf(datAlien = 0, Null, datAlien)
430       rstFirstOf("ReplacementFirstDate") = IIf(datReplacement = 0, Null, datReplacement)
440       rstFirstOf("DETFirstDate") = IIf(datDET = 0, Null, datDET)
450       rstFirstOf("DETCountIndividuals") = lngDET
460       rstFirstOf.Update

470       rstSpecies.MoveNext
480   Loop
490   rstSpecies.Close

500   retval = SysCmd(acSysCmdRemoveMeter)

510   If DCount("*", "tblDETFirstOfReport") = 0 Then
520       MsgBox "The First of Monitoring Program Report is empty"
530       GoTo Exit_label
540   End If

      Dim oSheet As Excel.Worksheet
      Dim rst As DAO.Recordset
      Dim strSpecies As String
      Dim lngDETCountIndividuals As Long
      Dim row As Long
      Dim rowStart As Integer

      ' Create an Excel Worksheet

      Const colSpecies As Integer = 1
      Const colSpeciesDescription As Integer = 2
      Const colObservedFirstDate As Integer = 3
      Const colCensusFirstDate As Integer = 4
      Const colAlienFirstDate As Integer = 5
      Const colReplacementFirstDate As Integer = 6
      Const colBandedFirstDate As Integer = 7
      Const colReturnsFirstDate As Integer = 8
      Const colRepeatsFirstDate As Integer = 9
      Const colDETFirstDate As Integer = 10
      Const colDETCountIndividuals = 11
      Const colEnd As Integer = 11

      Dim strSpeciesDescriptionMBO As String
    
'      Dim oSheet As Excel.Worksheet
550   Set oSheet = oBook.Worksheets.Add(After:=oBook.Worksheets(oBook.Worksheets.count))
560   oSheet.Name = "First at " & strLocation

570   With oSheet

          ' Fill in headers

580       .Cells(3, colSpeciesDescription) = "Species"
590       .Cells(2, colBandedFirstDate) = " First Date"
600       .range(.Cells(2, colObservedFirstDate), .Cells(2, colDETFirstDate)).Merge
610       .Cells(3, colObservedFirstDate) = "Observed"
620       .Cells(3, colCensusFirstDate) = "Census"
630       .Cells(3, colAlienFirstDate) = "Alien"
640       .Cells(3, colReplacementFirstDate) = "Replacement"
650       .Cells(3, colBandedFirstDate) = "Banded"
660       .Cells(3, colReturnsFirstDate) = "Returns"
670       .Cells(3, colRepeatsFirstDate) = "Repeats"
680       .Cells(3, colDETFirstDate) = "DET"
690       .Cells(3, colDETCountIndividuals) = "# DET individuals"

700       Set rst = CurrentDb.OpenRecordset("tblDETFirstOfReport", dbOpenDynaset)
          
710       row = 4

720       rowStart = row

      '    Dim intWeekPrevious As Integer
      '    intWeekPrevious = -1

730       Do While Not rst.EOF

740     strSpecies = Nz(rst("Species"))
750     strSpeciesDescriptionMBO = Nz(rst("SpeciesDescriptionMBO"))
760     datObserved = Nz(rst("ObservedFirstDate"))
770     datCensus = Nz(rst("CensusFirstDate"))
780     datAlien = Nz(rst("AlienFirstDate"))
790     datReplacement = Nz(rst("ReplacementFirstDate"))
800     datBanded = Nz(rst("BandedFirstDate"))
810     datReturns = Nz(rst("ReturnsFirstDate"))
820     datRepeats = Nz(rst("RepeatsFirstDate"))
830     datDET = Nz(rst("DETFirstDate"))
840     lngDETCountIndividuals = Nz(rst("DETCountIndividuals"))

850     .Cells(row, colSpecies) = strSpecies
860     .Cells(row, colSpeciesDescription) = strSpeciesDescriptionMBO
870     If datObserved <> 0 Then
880         .Cells(row, colObservedFirstDate) = datObserved
890     End If
900     If datCensus <> 0 Then
910         .Cells(row, colCensusFirstDate) = datCensus
920     End If
930     If datAlien <> 0 Then
940         .Cells(row, colAlienFirstDate) = datAlien
950     End If
960     If datReplacement <> 0 Then
970         .Cells(row, colReplacementFirstDate) = datReplacement
980     End If
990     If datBanded <> 0 Then
1000        .Cells(row, colBandedFirstDate) = datBanded
1010    End If
1020    If datReturns <> 0 Then
1030        .Cells(row, colReturnsFirstDate) = datReturns
1040    End If
1050    If datRepeats <> 0 Then
1060        .Cells(row, colRepeatsFirstDate) = datRepeats
1070    End If
1080    If datDET <> 0 Then
1090        .Cells(row, colDETFirstDate) = datDET
1100    End If
        
1110    .Cells(row, colDETCountIndividuals) = lngDETCountIndividuals
1120    If lngDETCountIndividuals <= 10 Then
1130        .range(.Cells(row, 1), .Cells(row, colEnd)).Interior.Color = RGB(255, 255, 153)
1140    End If

1150    row = row + 1
1160    rst.MoveNext
1170      Loop
1180      rst.Close
1190      Set rst = Nothing

          Dim rowEnd As Long
1200      rowEnd = row - 1

1210      .range(.columns(colObservedFirstDate), .columns(colDETFirstDate)).NumberFormat = "d mmm yy"
1220      .range(.columns(colObservedFirstDate), .columns(colEnd)).HorizontalAlignment = xlCenter
1230      .range(.columns(colObservedFirstDate), .columns(colReplacementFirstDate)).Font.Color = RGB(128, 128, 128)

1240      .range(.columns(1), .columns(colEnd)).AutoFit

1250      .Cells(1, 1) = "DET First of Location Report at " & strLocation
1260      .range(.Cells(1, 1), .Cells(1, 1)).HorizontalAlignment = xlLeft
1270      .range(.Cells(1, 1), .Cells(1, 1)).Font.Size = 14
1280      .range(.Cells(1, 1), .Cells(1, 1)).Font.Bold = True

1290      .Cells(5, colEnd + 2) = "This sheet reports pseudo-species"
1300      .Cells(5, colEnd + 2) = "All Monitoring Programs at location MBO are used"
1310      .Cells(8, colEnd + 2) = "Yellow highlight => At most 10 DET individuals"
          
1320  End With

1330  oSheet.range("A4").Select
1340  oExcel.ActiveWindow.FreezePanes = True

      ' Output sheets for pseudo-species
      ' 0 = DET
      ' 1 = Banded
      ' 2 = Returns
      ' 3 = Repeats
      ' 4 = Observed
      ' 5 = Census
      ' 6 = Alien
      ' 7 = Replacement

      Dim datFirstDate As Date
      Dim CumulativeSpecies As Long
      Dim CumulativeSpeciesPrevious As Long
      Dim CumulativePseudospecies As Long

      Dim dicCumulativeSpecies As Scripting.Dictionary
1350  Set dicCumulativeSpecies = New Scripting.Dictionary

      Dim fld As Integer
1360  For fld = 0 To 7

1370      dicCumulativeSpecies.RemoveAll
1380      CumulativeSpeciesPrevious = 0

1390      Set oSheet = oBook.Worksheets.Add(After:=oBook.Worksheets(oBook.Worksheets.count))
          
1400      Select Case fld
          Case 0
1410      oSheet.Name = "DET"
1420      Case 1
1430      oSheet.Name = "Banded"
1440      Case 2
1450      oSheet.Name = "Returns"
1460      Case 3
1470      oSheet.Name = "Repeats"
1480      Case 4
1490      oSheet.Name = "Observed (OBS)"
1500      Case 5
1510      oSheet.Name = "Census"
1520      Case 6
1530      oSheet.Name = "Alien"
1540      Case 7
1550      oSheet.Name = "Replacement"

1560      End Select

1570      With oSheet

          ' Fill in headers

1580      .Cells(3, 1) = "First Date"
1590      .Cells(3, 2) = "Species"
1600      .Cells(3, 4) = "AOU Order"
1610      .Cells(3, 5) = "Preudo-species"
1620      .Cells(3, 6) = "AOU Species"
          
1630      Select Case fld
          Case 0
1640    .Cells(1, 5) = "DET"
1650      Case 1
1660    .Cells(1, 5) = "Banded"
1670      Case 2
1680    .Cells(1, 5) = "Returns"
1690      Case 3
1700    .Cells(1, 5) = "Repeats"
1710      Case 4
1720    .Cells(1, 5) = "Observed"
1730      Case 5
1740    .Cells(1, 5) = "Census"
1750      Case 6
1760    .Cells(1, 5) = "Alien"
1770      Case 7
1780    .Cells(1, 5) = "Replacement"
1790      End Select

1800  .range(.Cells(1, 5), .Cells(1, 5)).Font.Bold = True
1810  .range(.Cells(1, 5), .Cells(1, 5)).HorizontalAlignment = xlCenter
1820  .range(.Cells(1, 5), .Cells(1, 5)).Font.Size = 14
1830  .range(.Cells(1, 5), .Cells(1, 6)).Merge

          Dim strSQL As String
          
1840      Select Case fld
          Case 0
1850    strSQL = _
            "SELECT * FROM tblDETFirstOfReport " & _
            "WHERE [DETFirstDate] is not null " & _
            "ORDER BY [DETFirstDate]"
1860      Case 1
1870    strSQL = _
            "SELECT * FROM tblDETFirstOfReport " & _
            "WHERE [BandedFirstDate] is not null " & _
            "ORDER BY [BandedFirstDate]"
1880      Case 2
1890    strSQL = _
            "SELECT * FROM tblDETFirstOfReport " & _
            "WHERE [ReturnsFirstDate] is not null " & _
            "ORDER BY [ReturnsFirstDate]"
1900      Case 3
1910    strSQL = _
            "SELECT * FROM tblDETFirstOfReport " & _
            "WHERE [RepeatsFirstDate] is not null " & _
            "ORDER BY [RepeatsFirstDate]"
1920      Case 4
1930    strSQL = _
            "SELECT * FROM tblDETFirstOfReport " & _
            "WHERE [ObservedFirstDate] is not null " & _
            "ORDER BY [ObservedFirstDate]"
1940      Case 5
1950    strSQL = _
            "SELECT * FROM tblDETFirstOfReport " & _
            "WHERE [CensusFirstDate] is not null " & _
            "ORDER BY [CensusFirstDate]"
1960    Case 6
1970    strSQL = _
            "SELECT * FROM tblDETFirstOfReport " & _
            "WHERE [AlienFirstDate] is not null " & _
            "ORDER BY [AlienFirstDate]"
1980      Case 7
1990    strSQL = _
            "SELECT * FROM tblDETFirstOfReport " & _
            "WHERE [ReplacementFirstDate] is not null " & _
            "ORDER BY [ReplacementFirstDate]"
2000      End Select
          
2010      Set rst = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)

2020      row = 4

2030      rowStart = row

2040      Do While Not rst.EOF

2050           strSpecies = UCase(Nz(rst("Species")))
2060           strSpeciesDescriptionMBO = Nz(rst("SpeciesDescriptionMBO"))
               
               Dim fSpecialCase As Boolean
2070           fSpecialCase = False
               
2080           If 0 < DCount("*", "tblSubspecies", "[Species] = '" & strSpecies & "'") Then
2090               fSpecialCase = True
2100           ElseIf 0 < DCount("*", "tblSubspecies", "[subSpecies] = '" & strSpecies & "'") Then
2110               fSpecialCase = True
2120           ElseIf 0 < DCount("*", "tblSuperspecies", "[SuperSpecies] = '" & strSpecies & "'") Then
2130               fSpecialCase = True
2140           ElseIf 0 < DCount("*", "tblSuperspecies", "[Species] = '" & strSpecies & "'") Then
2150               fSpecialCase = True
2160           End If
2170           If fSpecialCase Then
2180                .range(.Cells(row, 2), .Cells(row, 3)).Font.Color = vbRed
2190           End If
               
2200           Select Case fld
               Case 0
2210                   datFirstDate = Nz(rst("DETFirstDate"))
2220           Case 1
2230                   datFirstDate = Nz(rst("BandedFirstDate"))
2240           Case 2
2250                   datFirstDate = Nz(rst("ReturnsFirstDate"))
2260           Case 3
2270                   datFirstDate = Nz(rst("RepeatsFirstDate"))
2280           Case 4
2290                   datFirstDate = Nz(rst("ObservedFirstDate"))
2300           Case 5
2310                   datFirstDate = Nz(rst("CensusFirstDate"))
2320           Case 6
2330                   datFirstDate = Nz(rst("AlienFirstDate"))
2340           Case 7
2350                   datFirstDate = Nz(rst("ReplacementFirstDate"))
2360           End Select
               
               Dim dblAOUOrder As Double
2370           dblAOUOrder = Nz(rst("AOUOrder"))
               
2380           .Cells(row, 1) = datFirstDate
2390           .Cells(row, 2) = strSpecies
2400           .Cells(row, 3) = strSpeciesDescriptionMBO
2410           .Cells(row, 4) = dblAOUOrder
2420           .Cells(row, 5) = row - rowStart + 1
             
2430           If Not dicCumulativeSpecies.Exists(strSpecies) Then
2440               Call dicCumulativeSpecies.Add(strSpecies, strSpecies)
2450           End If

2460           CumulativeSpecies = CountSpeciesInDictionary(dicCumulativeSpecies)
                     
2470          If CumulativeSpeciesPrevious = CumulativeSpecies Then
2480              .range(.Cells(row, 6), .Cells(row, 6)).Font.Color = vbRed
2490          End If

2500          .Cells(row, 6) = CumulativeSpecies
2510          CumulativeSpeciesPrevious = CumulativeSpecies
                  
2520          row = row + 1
2530          rst.MoveNext
2540      Loop
2550      rst.Close
2560      Set rst = Nothing

2570      rowEnd = row - 1

2580      .range(.columns(1), .columns(1)).NumberFormat = "d mmm yy"
2590      .range(.columns(1), .columns(1)).HorizontalAlignment = xlCenter
2600      .range(.columns(4), .columns(6)).HorizontalAlignment = xlCenter
        
2610      .range(.columns(1), .columns(colEnd)).AutoFit

2620      .Cells(1, 1) = "DET First of Location Report at " & strLocation
2630      .range(.Cells(1, 1), .Cells(1, 1)).HorizontalAlignment = xlLeft
2640      .range(.Cells(1, 1), .Cells(1, 1)).Font.Size = 14
2650      .range(.Cells(1, 1), .Cells(1, 1)).Font.Bold = True

2660      .Cells(6, 8) = "All Monitoring Programs at location MBO are used"


2670  End With

2680  Next


2690  On Error Resume Next
2700  Call ExcelDeleteAllButFirstWorksheet(oBook)
2710  oBook.Worksheets("Sheet1").Delete
2720  On Error GoTo Err_label
2730  Set oSheet = Nothing


      'DD Error Handler Start
Exit_label:
2740       Exit Sub
Err_label:
2750       Select Case Err.Number
           Case Else
2760      Call LogError("basDETReports", "FirstOfLocationReport")
2770       End Select
2780       Resume Exit_label
      'DD Error Handler End

End Sub



























'---------------------------------------------------------------------------------------
' FirstOfYearDailySummaryReport
'
' Each day, count the species as they are encountered for the first time in a
' Winter, Spring, Summer or Fall monitoring program
' since the start of a year at a location
'
' Take into account sub-species and super-species
'---------------------------------------------------------------------------------------
  
Public Sub FirstOfYearDailySummaryReport( _
    ByRef fValid As Boolean, _
    ByVal intYear As Integer, _
    ByVal strLocation As String, _
    ByRef oExcel As Excel.Application, _
    ByRef oBook As Excel.Workbook)

10    On Error GoTo Err_label

      ' Save parameters

'20    intYear = argYear
'30    strLocation = argLocation
'40    Set oExcel = arg_excel
'50    Set oBook = arg_book

      Dim datFrom As Date
      Dim datTo As Date

20    datFrom = DateSerial(intYear, 1, 1)
30    datTo = DateSerial(intYear, 12, 31)

      Dim DET As New Scripting.Dictionary
      Dim BND As New Scripting.Dictionary ' Banded
      Dim REP As New Scripting.Dictionary ' Repeat
      Dim RET As New Scripting.Dictionary ' Return

      Dim strSQL As String
      Dim strWhere As String

      ' ZAP tblNewSpecies

40    strSQL = "DELETE * FROM tblNewSpecies"
50    CurrentDb.Execute strSQL

      Dim sumDETPreviousDay As Integer
      Dim SumDET As Integer
      Dim cntDET As Integer
      Dim sumBNDPreviousDay As Integer
      Dim SumBND As Integer
      Dim cntBND As Integer
      Dim sumREPPreviousDay As Integer
      Dim SumREP As Integer
      Dim cntREP As Integer
      Dim sumRETPreviousDay As Integer
      Dim SumRET As Integer
      Dim cntRET As Integer

60    sumDETPreviousDay = 0
70    sumBNDPreviousDay = 0
80    sumREPPreviousDay = 0
90    sumRETPreviousDay = 0

      ' Loop over all dates in the year + location
         
      ' Inialise the progress meter

      Dim retval As Variant
100   retval = SysCmd(acSysCmdInitMeter, "Creating DET First of Year Daily Summary Report ...", (datTo - datFrom))

      Dim dat As Date
110   For dat = datFrom To datTo

120       retval = SysCmd(acSysCmdUpdateMeter, dat - datFrom)

130       strSQL = _
        "SELECT * FROM tblDETSpecies " & _
        "WHERE Location = '" & strLocation & "' AND " & _
        "      DateEx = #" & Format(dat, "mm/dd/yyyy") & "#"
        
          ' Loop over each species for location + date
          
          Dim rst As DAO.Recordset
140       Set rst = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)
150       Do While Not rst.EOF

        ' Only process records from Winter, Spring, Summer and Fall monitoring programs
        
        Dim strProgram As String
160     strProgram = Nz(rst("Program"), "")
        Dim strSeason As String
170     strSeason = Nz(DLookup("MonitoringProgramSeason", "tblPrograms", "[Program] = '" & strProgram & "'"), "")
180     Select Case strSeason
        Case "Winter", "Spring", "Summer", "Fall"
          
          ' Process a species
          
          Dim strSpecies As String
190       strSpecies = Nz(rst("Species"), "")
200       If strSpecies <> "" Then
          
                ' If strSpecies is a sub-species, then add its species instead

210             If DCount("*", "tblSubspecies", "Subspecies = '" & strSpecies & "'") > 0 Then
220                 strSpecies = DLookup("Species", "tblSubspecies", "Subspecies = '" & strSpecies & "'")
230             End If

                Dim intDET As Integer
240             intDET = Nz(rst("DET"), 0)
250             If intDET > 0 Then
260                 If Not DET.Exists(strSpecies) Then
270                     Call DET.Add(strSpecies, strSpecies)
280                 End If
290             End If

                Dim intBND As Integer
300             intBND = Nz(rst("Banded"), 0)
310             If intBND > 0 Then
320                 If Not BND.Exists(strSpecies) Then
330                     Call BND.Add(strSpecies, strSpecies)
340                 End If
350             End If
                
                Dim intREP As Integer
360             intREP = Nz(rst("Repeats"), 0)
370             If intREP > 0 Then
380                 If Not REP.Exists(strSpecies) Then
390                     Call REP.Add(strSpecies, strSpecies)
400                 End If
410             End If
                
                Dim intRET As Integer
420             intRET = Nz(rst("Returns"), 0)
430             If intRET > 0 Then
440                 If Not RET.Exists(strSpecies) Then
450                     Call RET.Add(strSpecies, strSpecies)
460                 End If
470             End If

480         End If
490     End Select
500     rst.MoveNext
510       Loop
520       rst.Close
          
          ' Deduct any super-species with at least one component species in the dictionary
        
          ' Loop over all super-species
          
          Dim countDETRedundantSuperSpecies
          Dim countBNDRedundantSuperSpecies
          Dim countREPRedundantSuperSpecies
          Dim countRETRedundantSuperSpecies
          
530       countDETRedundantSuperSpecies = 0
540       countBNDRedundantSuperSpecies = 0
550       countREPRedundantSuperSpecies = 0
560       countRETRedundantSuperSpecies = 0
          
570       strSQL = "SELECT SuperSpecies FROM tblSuperSpecies GROUP BY SuperSpecies"
          Dim rstSuperSpecies As DAO.Recordset
580       Set rstSuperSpecies = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)
590       Do While Not rstSuperSpecies.EOF
          
        ' If the super-species in the dictionary
          
        Dim strSuperSpecies As String
600     strSuperSpecies = rstSuperSpecies("SuperSpecies")
        
        ' If any of its component species is in the dictionary
        '    then don't count the superspecies
        
        Dim rstComponentSpecies As DAO.Recordset
        Dim strComponentSpecies As String
        
610     If DET.Exists(strSuperSpecies) Then
620         strSQL = "SELECT * FROM tblSuperSpecies WHERE SuperSpecies = '" & strSuperSpecies & "'"
630         Set rstComponentSpecies = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)
640         Do While Not rstComponentSpecies.EOF
650             strComponentSpecies = rstComponentSpecies("Species")
660             If DET.Exists(strComponentSpecies) Then
670                 countDETRedundantSuperSpecies = countDETRedundantSuperSpecies + 1
680                 Exit Do
690             End If
700             rstComponentSpecies.MoveNext
710         Loop
720     End If
        
730     If BND.Exists(strSuperSpecies) Then
740         strSQL = "SELECT * FROM tblSuperSpecies WHERE SuperSpecies = '" & strSuperSpecies & "'"
        
750         Set rstComponentSpecies = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)
760         Do While Not rstComponentSpecies.EOF
770             strComponentSpecies = rstComponentSpecies("Species")
780             If BND.Exists(strComponentSpecies) Then
790                 countBNDRedundantSuperSpecies = countBNDRedundantSuperSpecies + 1
800                 Exit Do
810             End If
820             rstComponentSpecies.MoveNext
830         Loop
840     End If
        
850     If REP.Exists(strSuperSpecies) Then
860        strSQL = "SELECT * FROM tblSuperSpecies WHERE SuperSpecies = '" & strSuperSpecies & "'"
        
870        Set rstComponentSpecies = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)
880        Do While Not rstComponentSpecies.EOF
890            strComponentSpecies = rstComponentSpecies("Species")
900            If REP.Exists(strComponentSpecies) Then
910                countREPRedundantSuperSpecies = countREPRedundantSuperSpecies + 1
920                Exit Do
930            End If
940            rstComponentSpecies.MoveNext
950        Loop
960     End If
        
970     If RET.Exists(strSuperSpecies) Then
980        strSQL = "SELECT * FROM tblSuperSpecies WHERE SuperSpecies = '" & strSuperSpecies & "'"
990        Set rstComponentSpecies = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)
1000       Do While Not rstComponentSpecies.EOF
1010           strComponentSpecies = rstComponentSpecies("Species")
1020           If RET.Exists(strComponentSpecies) Then
1030               countRETRedundantSuperSpecies = countRETRedundantSuperSpecies + 1
1040               Exit Do
1050           End If
1060           rstComponentSpecies.MoveNext
1070       Loop
1080    End If
        
1090    rstSuperSpecies.MoveNext
1100      Loop
1110      rstSuperSpecies.Close
        
1120      SumDET = DET.count() - countDETRedundantSuperSpecies
1130      SumBND = BND.count() - countBNDRedundantSuperSpecies
1140      SumREP = REP.count() - countREPRedundantSuperSpecies
1150      SumRET = RET.count() - countRETRedundantSuperSpecies
          
1160      cntDET = SumDET - sumDETPreviousDay
1170      sumDETPreviousDay = SumDET
1180      cntBND = SumBND - sumBNDPreviousDay
1190      sumBNDPreviousDay = SumBND
1200      cntREP = SumREP - sumREPPreviousDay
1210      sumREPPreviousDay = SumREP
1220      cntRET = SumRET - sumRETPreviousDay
1230      sumRETPreviousDay = SumRET
          
1240      strSQL = _
        "INSERT INTO tblNewSpecies " & _
        "(Program, Location, DateEx, DET, SumDET, BND, SumBND, REP, SumREP, RET, SumRET) " & _
        "VALUES('" & "" & "','" & strLocation & "', #" & Format(dat, "mm/dd/yyyy") & "#," & _
        cntDET & "," & SumDET & "," & _
        cntBND & "," & SumBND & "," & _
        cntREP & "," & SumREP & "," & _
        cntRET & "," & SumRET & ")"
1250      CurrentDb.Execute strSQL

1260  Next dat

1270  retval = SysCmd(acSysCmdRemoveMeter)


           '    Create Excel Worksheet

      Dim colLocation As Integer
      Dim colDateEx As Integer
      Dim colBND As Integer
      Dim colSumBND As Integer
      Dim colRET As Integer
      Dim colSumRET As Integer
      Dim colREP As Integer
      Dim colSumREP As Integer
      Dim colDET As Integer
      Dim colSumDET As Integer
      Dim colEnd As Integer

1280  colLocation = 1
1290  colDateEx = 2
1300  colBND = 3
1310  colSumBND = 4
1320  colRET = 5
1330  colSumRET = 6
1340  colREP = 7
1350  colSumREP = 8
1360  colDET = 9
1370  colSumDET = 10
1380  colEnd = 10

      Dim oSheet As Excel.Worksheet
1390  Set oSheet = oBook.Worksheets.Add(After:=oBook.Worksheets(oBook.Worksheets.count))
1400  oSheet.Name = "First " & intYear

1410  With oSheet

          ' Fill in headers

1420      .Cells(3, colLocation) = "Location"
1430      .Cells(2, colBND) = "Banded"
1440      .range(.Cells(2, colBND), .Cells(2, colSumBND)).Merge
1450      .Cells(3, colSumBND) = "Sum"
1460      .Cells(2, colRET) = "Returns"
1470      .range(.Cells(2, colRET), .Cells(2, colSumRET)).Merge
1480      .Cells(3, colSumRET) = "Sum"
1490      .Cells(2, colREP) = "Repeats"
1500      .range(.Cells(2, colREP), .Cells(2, colSumREP)).Merge
1510      .Cells(3, colSumREP) = "Sum"
1520      .Cells(2, colDET) = "DET"
1530      .range(.Cells(2, colDET), .Cells(2, colSumDET)).Merge
1540      .Cells(3, colSumDET) = "Sum"

1550      .range(.Cells(2, colLocation), .Cells(3, colEnd)).HorizontalAlignment = xlCenter
           
      '   Dim strSQL As String
1560      strSQL = "SELECT * FROM tblNewSpecies ORDER BY DateEx"
      '   Dim rst As DAO.Recordset
1570      Set rst = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)

          Dim row As Long
1580      row = 4

          Dim rowStart As Integer
1590      rowStart = row

          Dim datDateEx As Date
          Dim lngBND As Long
          Dim lngSumBND As Long
          Dim lngRET As Long
          Dim lngSumRET As Long
          Dim lngREP As Long
          Dim lngSumREP As Long
          Dim lngDET As Long
          Dim lngSumDET As Long
          
1600      .Cells(row, colLocation) = strLocation

1610      Do While Not rst.EOF
          
1620          datDateEx = Nz(rst("DateEx"))
1630          lngBND = Nz(rst("BND"))
1640          lngSumBND = Nz(rst("SumBND"))
1650          lngRET = Nz(rst("RET"))
1660          lngSumRET = Nz(rst("SumRET"))
1670          lngREP = Nz(rst("REP"))
1680          lngSumREP = Nz(rst("SumREP"))
1690          lngDET = Nz(rst("DET"))
1700          lngSumDET = Nz(rst("SumDET"))
              
1710          .Cells(row, colDateEx) = datDateEx
1720          If lngBND <> 0 Then
1730              .Cells(row, colBND) = lngBND
1740          End If
1750          If lngSumBND <> 0 Then
1760          .Cells(row, colSumBND) = lngSumBND
1770          End If
1780          If lngRET <> 0 Then
1790              .Cells(row, colRET) = lngRET
1800          End If
1810          If lngSumRET <> 0 Then
1820          .Cells(row, colSumRET) = lngSumRET
1830          End If
1840          If lngREP <> 0 Then
1850              .Cells(row, colREP) = lngREP
1860          End If
1870          If lngSumREP <> 0 Then
1880              .Cells(row, colSumREP) = lngSumREP
1890          End If
1900          If lngDET <> 0 Then
1910              .Cells(row, colDET) = lngDET
1920          End If
1930          If lngSumDET <> 0 Then
1940          .Cells(row, colSumDET) = lngSumDET
1950          End If

              Dim lngColour As Long
1960          lngColour = RGB(253, 233, 217)
1970          If row Mod 2 = 1 Then
1980              .range(.Cells(row, colDateEx), .Cells(row, colEnd)).Interior.Color = lngColour
1990          End If
              
2000          row = row + 1
2010          rst.MoveNext
2020      Loop
2030      rst.Close
2040      Set rst = Nothing

          Dim rowEnd As Long
2050      rowEnd = row - 1

2060      .range(.columns(colDateEx), .columns(colDateEx)).NumberFormat = "d mmm yy"
2070      .range(.columns(colBND), .columns(colSumDET)).HorizontalAlignment = xlCenter
          
2080      .range("A4").Select
2090       oExcel.ActiveWindow.FreezePanes = True
          
2100      .range(.columns(1), .columns(2)).AutoFit
2110      .range(.columns(colBND), .columns(colSumRET)).ColumnWidth = 7

           Dim strTitle As String

2120      strTitle = intYear & " Annual " & _
              "DET First of Year Daily Summary Report at " & strLocation

2130      .Cells(1, 1) = strTitle
2140      .range(.Cells(1, 1), .Cells(1, 1)).HorizontalAlignment = xlLeft
2150      .range(.Cells(1, 1), .Cells(1, 1)).Font.Size = 14
2160      .range(.Cells(1, 1), .Cells(1, 1)).Font.Bold = True

2170      .Cells(2, colEnd + 2) = "Only for Winter, SMMP, MAPS and FMMP.  Owling, SNBU do not count"
2180      .Cells(3, colEnd + 2) = "Counts species, not pseudo-species"

2190  End With

2200  Set oSheet = Nothing


      'DD Error Handler Start
Exit_label:
2210       Exit Sub
Err_label:
2220       Select Case Err.Number
           Case Else
2230      Call LogError("basDETReports", "FirstOfYearDailySummaryReport")
2240       End Select
2250       Resume Exit_label
      'DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' FirstOfYearByPeriodReport
'---------------------------------------------------------------------------------------
 
Public Sub FirstOfYearByPeriodReport( _
    ByVal intYear As Integer, _
    ByVal strLocation As String, _
    ByRef oExcel As Excel.Application, _
    ByRef oBook As Excel.Workbook)
          
      ' tblDETFirstOfYear_Union
      ' -----------------------
      ' Species
      ' FirstDate
      ' Stat              DET, BND, RET, REP

      Dim strSQL As String
10    On Error GoTo Err_label

20    strSQL = "DELETE * FROM tblDETFirstOfYear_Union"
30    CurrentDb.Execute strSQL
         

      ' qryDETFirstOfYear_BND
      '----------------------
      ' tblDETSpecies x tblSpecies
      ' Location = [Location]
      ' GROUP BY Species
      ' FirstDate = Min DateEx
      ' Stat = BND
      ' Year(DateEx) = intYearReport
      ' SpeciesDescriptionMBO
      ' AOUOrder
      ' Append to  tblDETFirstOfYear_Union
      ' Report Species, FirstDate, Stat, SpeciesDescriptionMBO, AOUOrder

      ' qryDETFirstOfYear_RET
      ' ---------------------
      ' as above, except for Returns
      
      ' qryDETFirstOfYear_REP
      ' ---------------------
      ' as above, except for Repeats
      
      ' qryDETFirstOfYear_DET
      ' ---------------------
      ' as above, except for DET

      Dim qdf As QueryDef
40    Set qdf = CurrentDb.QueryDefs("qryDETFirstOfYear_DET")
50    qdf.Parameters("argLocation").value = strLocation
60    qdf.Parameters("argYear").value = intYear
70    qdf.Execute

80    Set qdf = CurrentDb.QueryDefs("qryDETFirstOfYear_BND")
90    qdf.Parameters("argLocation").value = strLocation
100   qdf.Parameters("argYear").value = intYear
110   qdf.Execute

120   Set qdf = CurrentDb.QueryDefs("qryDETFirstOfYear_RET")
130   qdf.Parameters("argLocation").value = strLocation
140   qdf.Parameters("argYear").value = intYear
150   qdf.Execute

160   Set qdf = CurrentDb.QueryDefs("qryDETFirstOfYear_REP")
170   qdf.Parameters("argLocation").value = strLocation
180   qdf.Parameters("argYear").value = intYear
190   qdf.Execute

      ' Fill in the Season and Period columns

      Dim rst As DAO.Recordset
200   Set rst = CurrentDb.OpenRecordset("tblDETFirstOfYear_Union", dbOpenDynaset)
210   Do While Not rst.EOF

          Dim datFirstDate As Date
          Dim strSpecies As String
          Dim strWhere As String
          Dim intCount As Integer
          Dim strProgram As String
          Dim strSeason As String
          Dim intPeriod As Integer
          Dim datDateFrom As Date
          
220       strSpecies = Nz(rst("Species"))
230       datFirstDate = Nz(rst("FirstDate"))
          
          ' if the first date for a species is in more than one monitoring program,
          ' then we pick one of the monitoring programs at random

240       If datFirstDate <> 0 Then
250           strWhere = _
                  "[Location] ='" & strLocation & "' AND " & _
                  "[Species] = '" & strSpecies & "' AND " & _
                  "[DateEx] = #" & Format(datFirstDate, "m/d/yyyy") & "#"

260           strProgram = Nz(DLookup("Program", "tblDETSpecies", strWhere))
270           If strProgram = "" Then GoTo Label_NextRecord
              
280           strSeason = Nz(DLookup("MonitoringProgramSeason", "tblPrograms", "[Program] = '" & strProgram & "'"))
290           If strSeason = "" Then GoTo Label_NextRecord

300           datDateFrom = Nz(DLookup("DateFrom", "tblPrograms", "[Program] = '" & strProgram & "'"))
310           If datDateFrom = 0 Then GoTo Label_NextRecord

320           intPeriod = getPeriodPost2014(datFirstDate, datDateFrom, strSeason)
330           If intPeriod = 0 Then GoTo Label_NextRecord
              
              Dim intSeasonOrder As Integer
340           Select Case strSeason
              Case "Winter"
350               If Month(datFirstDate) <= 6 Then
360                   intSeasonOrder = 1
370               Else
380                   intSeasonOrder = 7
390               End If
400           Case "Spring"
410               intSeasonOrder = 2
420           Case "Summer"
430               intSeasonOrder = 3
440           Case "Nextbox"
450               intSeasonOrder = 4
460           Case "Fall"
470                intSeasonOrder = 5
480           Case "Owling"
490               intSeasonOrder = 6
500           Case Else
510               intSeasonOrder = 7
520           End Select
              
              Dim datFirstDateProgram As Date
              Dim datLastDateProgram  As Date
              Dim intTotalPeriods     As Integer
              Dim datFirstDatePeriod As Date
              Dim datLastDatePeriod As Date

530           Call getProgramPeriods(strProgram, strSeason, _
                  datFirstDateProgram, datLastDateProgram, intTotalPeriods)
              
540           Call getFirstAndLastDatePeriod(intYear, strSeason, _
                    datFirstDateProgram, datLastDateProgram, intPeriod, _
                    datFirstDatePeriod, datLastDatePeriod)

550           rst.Edit
560           rst("Season") = strSeason
570           rst("Period") = intPeriod
580           rst("SeasonOrder") = intSeasonOrder
590           rst("FirstDatePeriod") = datFirstDatePeriod
600           rst("LastDatePeriod") = datLastDatePeriod
              
610           rst.Update
620       End If
Label_NextRecord:
630       rst.MoveNext
640   Loop
650   rst.Close
660   Set rst = Nothing

670   Call ExportFirstOfYearToExcel(intYear, strLocation, oExcel, oBook)
680   Call ExportFirstOfYearPeriodToExcel(intYear, strLocation, oExcel, oBook)

      'DD Error Handler Start
Exit_label:
690        Exit Sub
Err_label:
700        Select Case Err.Number
           Case Else
710             Call LogError("basDETReports", "FirstOfYearByPeriodReport")
720        End Select
730        Resume Exit_label
      'DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' ExportFirstOfYearPeriodToExcel
'
' Export data from qryDETFirstOfYear_Crosstab
'---------------------------------------------------------------------------------------

Private Sub ExportFirstOfYearPeriodToExcel( _
    ByVal intYear As Integer, _
    ByVal strLocation As String, _
    ByRef oExcel As Excel.Application, _
    ByRef oBook As Excel.Workbook)
          
10    On Error GoTo Err_label

      Const intColSeason As Integer = 1
      Const intColWeek As Integer = 2
      Const intColDateFrom As Integer = 3
      Const intColDateTo As Integer = 4
      Const intColSpecies As Integer = 5
      Const intColSpeciesDescription As Integer = 6
      Const intColDET As Integer = 7
      Const intColBND As Integer = 8
      Const intColREP As Integer = 10
      Const intColRET As Integer = 9
      Const intColEnd As Integer = 10
      Const lngRowHeader As Integer = 2
      Const lngRowDataStart As Integer = 3
       
      ' qryDETFirstOfYearPeriod_Crosstab
      ' --------------------------------
      ' tblDETFirstOfYear_Union
      ' Row Heading SeasonOrder, Season, Period, FirstDatePeriod, LastDatePeriod, Species, SpeciesDescriptionMBO, AOUOrder
      ' Column Heading: Stat
      ' Value: FirstDate
      ' ORDER BY SeasonOrder, Period, AOUOrder

      Dim oSheet As Excel.Worksheet
20    Set oSheet = oBook.Worksheets.Add(After:=oBook.Worksheets(oBook.Worksheets.count))
30    oSheet.Name = "First " & intYear & " by Period"

40    With oSheet

      ' Fill in the header rows

50        .Cells(lngRowHeader, intColSeason) = "Season"
60        .Cells(lngRowHeader, intColWeek) = "Week"
70        .Cells(lngRowHeader, intColDateFrom) = "From"
80        .Cells(lngRowHeader, intColDateTo) = "To"
90        .Cells(lngRowHeader, intColSpecies) = "Species"
100       .Cells(lngRowHeader, intColDET) = "Observed"
110       .Cells(lngRowHeader, intColBND) = "Banded"
120       .Cells(lngRowHeader, intColREP) = "Repeats"
130       .Cells(lngRowHeader, intColRET) = "Returns"

          ' Fill in the data

          ' Open a recordset to tblNewSpecies

          Dim rst As DAO.Recordset
140       Set rst = CurrentDb.OpenRecordset("SELECT * FROM qryDETFirstOfYearPeriod_Crosstab")
        
150       If Not rst.EOF Then
160           .Cells(1, 1) = "MBO " & intYear & " Annual DET First of Year by Week/Period at " & strLocation
170       End If
          
          Dim row As Long
180       row = lngRowDataStart
          
          Dim intPeriod As Integer
          Dim datFrom As Date
          Dim datTo As Date
          Dim strSeason As String
          Dim strWeek As String
          Dim strSpecies As String
          Dim datDET As Date
          Dim datBND As Date
          Dim datREP As Date
          Dim datRET As Date
          
          Dim intPeriodPrevious As Integer
          Dim strSeasonPrevious As String
190       intPeriodPrevious = 0
200       strSeasonPrevious = ""
          
          ' Initialise the progress meter

          Dim progressMax As Long
210       progressMax = DCount("*", "qryDETFirstOfYear_Crosstab", "True")
          Dim retval As Variant
220       retval = SysCmd(acSysCmdInitMeter, "Exporting Excel Workbook ...", progressMax)
          Dim progress As Long
230       progress = 0

240       Do While Not rst.EOF
          
250           retval = SysCmd(acSysCmdUpdateMeter, progress)
260           progress = progress + 1

270           intPeriod = Nz(rst("Period"), 0)
280           strSeason = Nz(rst("Season"), "")
290           If (strSeason <> strSeasonPrevious) Or (intPeriod <> intPeriodPrevious) Then
300               intPeriodPrevious = intPeriod
310               strSeasonPrevious = strSeason
        
                  ' Process first row of a period
                    
320               .Cells(row, intColSeason) = Nz(rst("Season"), "")
330               If strSeason = "Spring" Or strSeason = "Fall" Then
340                   strWeek = Nz(rst("Period"), "")
350                   If strWeek <> "" Then
360                       strWeek = "Week " & strWeek
370                       .Cells(row, intColWeek) = strWeek
380                   End If
390               End If
400               datFrom = Nz(rst("FirstDatePeriod"), "")
410               If datFrom <> 0 Then
420                   .Cells(row, intColDateFrom) = datFrom
430               End If
440               datTo = Nz(rst("LastDatePeriod"), "")
450               If datTo <> 0 Then
460                   .Cells(row, intColDateTo) = datTo
470               End If

480               With .range(.Cells(row, intColSeason), .Cells(row, intColEnd)).Borders(xlEdgeTop)
490                 .LineStyle = xlContinuous
500                 .Weight = xlThin
510               End With

520           End If
        
530           Select Case strSeason
              Case "Winter"
540             .range(.Cells(row, intColSeason), .Cells(row, intColDateTo)).Interior.Color = _
                    RGB(219, 238, 243)
550           Case "Spring"
560             .range(.Cells(row, intColSeason), .Cells(row, intColDateTo)).Interior.Color = _
                    RGB(255, 255, 204)
570           Case "Summer"
580             .range(.Cells(row, intColSeason), .Cells(row, intColDateTo)).Interior.Color = _
                    RGB(189, 211, 149)
590           Case "Fall"
600             .range(.Cells(row, intColSeason), .Cells(row, intColDateTo)).Interior.Color = _
                    RGB(250, 197, 102)
610           Case "Owling"
620             .range(.Cells(row, intColSeason), .Cells(row, intColDateTo)).Interior.Color = _
                    RGB(221, 217, 195)
630           Case Else
640             .range(.Cells(row, intColSeason), .Cells(row, intColDateTo)).Interior.Color = _
                    RGB(255, 121, 121)
650           End Select

660           strSpecies = Nz(rst("Species"), "")
670           .Cells(row, intColSpecies) = strSpecies
680           If DCount("*", "tblSuperSpecies", "[SuperSpecies] = '" & strSpecies & "'") > 0 Then
690               .range(.Cells(row, intColSpecies), .Cells(row, intColEnd)).Font.Color = _
                      RGB(255, 0, 0)
700           End If
710           If DCount("*", "tblSubSpecies", "[SubSpecies] = '" & strSpecies & "'") > 0 Then
720               .range(.Cells(row, intColSpecies), .Cells(row, intColEnd)).Font.Color = _
                      RGB(255, 0, 0)
730           End If
              Dim strSpeciesDescription As String
740           strSpeciesDescription = _
                  Nz(DLookup("SpeciesDescriptionMBO", "tblSpecies", "[Species] = '" & strSpecies & "'"), "")
750           .Cells(row, intColSpeciesDescription) = strSpeciesDescription
              
760           On Error Resume Next
770           datDET = Nz(rst("DET"), 0)
780           If datDET <> 0 Then
790                 .Cells(row, intColDET) = datDET
800           End If
810           datBND = Nz(rst("BND"), 0)
820           If datBND <> 0 Then
830                 .Cells(row, intColBND) = datBND
840           End If
850           datREP = Nz(rst("REP"), 0)
860           If datREP <> 0 Then
870                 .Cells(row, intColREP) = datREP
880           End If
890           datRET = Nz(rst("RET"), 0)
900           If datRET <> 0 Then
910                 .Cells(row, intColRET) = datRET
920           End If
930           On Error GoTo Err_label
           
940           row = row + 1
950           rst.MoveNext
960       Loop
970       rst.Close
       
980   End With

      Dim lngRowDataEnd As Long
990   lngRowDataEnd = row - 1

1000  With oSheet
1010  .range(.Cells(1, 1), .Cells(1, 1)).Font.Size = 15
1020  .range(.Cells(1, 1), .Cells(1, 1)).Font.FontStyle = "Bold"
          
1030      .range(.Cells(lngRowDataStart, intColDateFrom), .Cells(lngRowDataEnd, intColDateTo)).NumberFormat = "dd mmm"
1040      .range(.Cells(lngRowHeader, intColDateFrom), .Cells(lngRowDataEnd, intColDateTo)).HorizontalAlignment = xlCenter
1050      .range(.Cells(lngRowDataStart, intColDET), .Cells(lngRowDataEnd, intColRET)).NumberFormat = "dd mmm"
1060      .range(.Cells(lngRowHeader, intColDET), .Cells(lngRowDataEnd, intColRET)).HorizontalAlignment = xlCenter
          
1070      .range(.Cells(1, intColSeason), .Cells(1, intColRET)).BorderAround Color:=RGB(0, 0, 0)
1080      .range(.Cells(lngRowHeader, intColSeason), .Cells(lngRowHeader, intColRET)).BorderAround Color:=RGB(0, 0, 0)
1090      .range(.Cells(lngRowDataStart, intColSeason), .Cells(lngRowDataEnd, intColRET)).BorderAround Color:=RGB(0, 0, 0)

1100      .range(.Cells(lngRowHeader, intColSeason), .Cells(lngRowDataEnd, intColWeek)).BorderAround Color:=RGB(0, 0, 0)
1110      .range(.Cells(lngRowHeader, intColDateFrom), .Cells(lngRowDataEnd, intColDateTo)).BorderAround Color:=RGB(0, 0, 0)
1120      .range(.Cells(lngRowHeader, intColDET), .Cells(lngRowDataEnd, intColDET)).BorderAround Color:=RGB(0, 0, 0)
1130      .range(.Cells(lngRowHeader, intColBND), .Cells(lngRowDataEnd, intColBND)).BorderAround Color:=RGB(0, 0, 0)
1140      .range(.Cells(lngRowHeader, intColREP), .Cells(lngRowDataEnd, intColREP)).BorderAround Color:=RGB(0, 0, 0)
1150      .range(.Cells(lngRowHeader, intColRET), .Cells(lngRowDataEnd, intColRET)).BorderAround Color:=RGB(0, 0, 0)
          
1160      .range(.Cells(lngRowHeader, intColDET), .Cells(lngRowDataEnd, intColDET)).Interior.Color = RGB(153, 204, 255)
1170      .range(.Cells(lngRowHeader, intColBND), .Cells(lngRowDataEnd, intColBND)).Interior.Color = RGB(204, 255, 204)
1180      .range(.Cells(lngRowHeader, intColREP), .Cells(lngRowDataEnd, intColREP)).Interior.Color = RGB(255, 204, 153)
1190      .range(.Cells(lngRowHeader, intColRET), .Cells(lngRowDataEnd, intColRET)).Interior.Color = RGB(255, 255, 153)

1200      .range(.Cells(lngRowHeader, intColDET), .Cells(lngRowDataEnd, intColDET)).NumberFormat = "dd mmm"
1210      .range(.Cells(lngRowHeader, intColBND), .Cells(lngRowDataEnd, intColBND)).NumberFormat = "dd mmm"
1220      .range(.Cells(lngRowHeader, intColREP), .Cells(lngRowDataEnd, intColREP)).NumberFormat = "dd mmm"
1230      .range(.Cells(lngRowHeader, intColRET), .Cells(lngRowDataEnd, intColRET)).NumberFormat = "dd mmm"

1240      .columns(intColSpeciesDescription).ColumnWidth = 30
          
          ' Freeze rows and columns
          
1250      oExcel.GoTo oSheet.range(.Cells(lngRowDataStart, intColSeason), .Cells(lngRowDataStart, intColSeason))
1260      oExcel.ActiveWindow.FreezePanes = True

1270      .Cells(1, intColEnd + 2) = "This report lists pseudo-species."
1280      .Cells(2, intColEnd + 2) = "Subspecies (e.g. YPWA, WPWA) and super-species (e.g. TRFL) are shown in red."

1290      .Cells(4, intColEnd + 2) = "This report is for all monitoring programs at the MBO site"
1300      .Cells(11, intColEnd + 2) = "Observed means DET, not OBS"

1310  End With

1320  Set oSheet = Nothing

1330  retval = SysCmd(acSysCmdRemoveMeter)

      'DD Error Handler Start
Exit_label:
1340       Exit Sub
Err_label:
1350       Select Case Err.Number
           Case Else
1360      Call LogError("Form_frmDETAnnualReports", "ExportFirstOfYearPeriodToExcel")
1370       End Select
1380       Resume Exit_label
      'DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' ExportFirstOfYearToExcel
'---------------------------------------------------------------------------------------
 
Public Sub ExportFirstOfYearToExcel( _
    ByVal intYear As Integer, _
    ByVal strLocation As String, _
    ByRef oExcel As Excel.Application, _
    ByRef oBook As Excel.Workbook)

10    On Error GoTo Err_label


'    Create Excel Worksheet

      Dim colLocation As Integer
      Dim colYear As Integer
      Dim colSpecies As Integer
      Dim colSpeciesEnglish As Integer
      Dim colBandedFirstDate As Integer
      Dim colReturnsFirstDate As Integer
      Dim colRepeatsFirstDate As Integer
      Dim colDETFirstDate As Integer
      Dim colEnd As Integer

20    colLocation = 1
30    colYear = 2
40    colSpecies = 3
50    colSpeciesEnglish = 4
60    colDETFirstDate = 5
70    colBandedFirstDate = 6
80    colReturnsFirstDate = 7
90    colRepeatsFirstDate = 8

100   colEnd = 8

      Dim oSheet As Excel.Worksheet
110   Set oSheet = oBook.Worksheets.Add(After:=oBook.Worksheets(oBook.Worksheets.count))
120   oSheet.Name = "First " & intYear

130   With oSheet

          ' Fill in headers

140       .Cells(2, colLocation) = "Location"
150       .Cells(2, colYear) = "Year"
160       .Cells(2, colSpecies) = ""
170       .Cells(2, colSpeciesEnglish) = "Species"
180       .Cells(2, colDETFirstDate) = "DET"
190       .Cells(2, colBandedFirstDate) = "Banded"
200       .Cells(2, colReturnsFirstDate) = "Returns"
210       .Cells(2, colRepeatsFirstDate) = "Repeats"
          
220       .range(.Cells(2, colLocation), .Cells(2, colEnd)).HorizontalAlignment = xlCenter

' tblDETFirstOfYear_Union
' --------------------
' Species
' FirstDate
' Stat                                DET, BND, RET, REP
' SpeciesDescriptionMBO
' AOUOrder
' Season
' Period
' SeasonOrder
' FirstDatePeriod
' LastDatePeriod

' qryDETFirstOfYear_Crosstab
' --------------------------
' tblDETFirstOfYear_Union
' ROW HEADING - GROUP BY Species
' ROW HEADING - GROUP BY AOUOrder
' ROW HEADING - GROUP BY SpeciesDescriptionMBO
' COLUMN HEADING - GROUP BY Stat
' VALUE - FIRST FirstDate
' ORDER BY AOUOrder
        
          Dim strSQL As String
230       strSQL = "SELECT * FROM qryDETFirstOfYear_Crosstab"
          Dim rst As DAO.Recordset
240       Set rst = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)

          Dim row As Long
250       row = 3

          Dim rowStart As Integer
260       rowStart = row

          Dim strSpecies As String
          Dim strSpeciesEnglish As String
          Dim datBandedFirstDate As Date
          Dim datRepeatsFirstDate As Date
          Dim datReturnsFirstDate As Date
          Dim datDETFirstDate As Date
          
270       .Cells(row, colLocation) = strLocation
280       .Cells(row, colYear) = intYear

290       Do While Not rst.EOF

300           datBandedFirstDate = 0
310           datReturnsFirstDate = 0
320           datRepeatsFirstDate = 0
330           datDETFirstDate = 0
          
340           strSpecies = Nz(rst("Species"))
350           strSpeciesEnglish = Nz(rst("SpeciesDescriptionMBO"))

360           On Error Resume Next
370           datBandedFirstDate = Nz(rst("BND"))
380           datReturnsFirstDate = Nz(rst("RET"))
390           datRepeatsFirstDate = Nz(rst("REP"))
400           datDETFirstDate = Nz(rst("DET"))
410           On Error GoTo Err_label

420           .Cells(row, colSpecies) = strSpecies
430           .Cells(row, colSpeciesEnglish) = strSpeciesEnglish
440           If datBandedFirstDate <> 0 Then
450               .Cells(row, colBandedFirstDate) = datBandedFirstDate
460           End If
470           If datReturnsFirstDate <> 0 Then
480           .Cells(row, colReturnsFirstDate) = datReturnsFirstDate
490           End If
500           If datRepeatsFirstDate <> 0 Then
510           .Cells(row, colRepeatsFirstDate) = datRepeatsFirstDate
520           End If
530           If datDETFirstDate <> 0 Then
540           .Cells(row, colDETFirstDate) = datDETFirstDate
550           End If

              Dim lngColour As Long
560           lngColour = RGB(253, 233, 217)
                
570           If row Mod 2 = 1 Then
580               .range(.Cells(row, colSpecies), .Cells(row, colEnd)).Interior.Color = lngColour
590           End If
              
600           row = row + 1
610           rst.MoveNext
620       Loop
630       rst.Close
640       Set rst = Nothing

          Dim rowEnd As Long
650       rowEnd = row - 1

660       .range(.columns(colDETFirstDate), .columns(colRepeatsFirstDate)).NumberFormat = "d mmm yy"
          
670       .range("A3").Select
680        oExcel.ActiveWindow.FreezePanes = True
          
690        .range(.columns(1), .columns(colEnd)).AutoFit

           Dim strTitle As String

700       strTitle = intYear & " Annual " & _
              "DET First of Year Report at " & strLocation

710       .Cells(1, 1) = strTitle
720       .range(.Cells(1, 1), .Cells(1, 1)).HorizontalAlignment = xlLeft
730       .range(.Cells(1, 1), .Cells(1, 1)).Font.Size = 14
740       .range(.Cells(1, 1), .Cells(1, 1)).Font.Bold = True

750   End With

760   Set oSheet = Nothing

      'DD Error Handler Start
Exit_label:
770        Exit Sub
Err_label:
780        Select Case Err.Number
           Case Else
790       Call LogError("basDETReports", "ExportFirstOfYearToExcel")
800        End Select
810        Resume Exit_label
      'DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' DETTop10ByPeriodReport
'---------------------------------------------------------------------------------------
'
' strStatistic = "DET" or "Banded"

Public Sub DETTop10ByPeriodReport( _
    ByVal intReportYear As Integer, _
    ByVal strLocation As String, _
    ByVal strProgram As String, _
    ByVal strSeason As String, _
    ByVal strStatistic As String)

10    On Error GoTo Err_label

Dim strTop10DETReport As String
20    If strStatistic = "Banded" Then
30       strTop10DETReport = "tblTop10DETReport_Banded"
40    Else
50       strTop10DETReport = "tblTop10DETReport_DET"
60    End If

      Dim datFrom As Date
70    datFrom = Nz(DLookup("DateFrom", "tblPrograms", "Program = '" & strProgram & "'"))
80    If datFrom = 0 Then
90        MsgBox "The monitoring program does not have a start date", , "DET Top 10 Report"
100       Exit Sub
110   End If

      ' qryTop10DET ==== used for DET
      ' from tblDETSpecies x tblPrograms
      ' Program  (argument)
      ' Location (argument)
      ' Period = getPeriodPost2014([DateEx],[DateFrom],[MonitoringProgramSeason])
      ' FirstDatePeriod = getStartDatePeriodPost2014([DateEx],[DateFrom],[MonitoringProgramSeason])
      ' LastDatePeriod = getLastDatePeriodPost2014_v2([DateEx],[DateFrom],[MonitoringProgramSeason],[tblDETSpecies].[Program])
      ' Stat (DET summed over Period)
      ' Sorted by Period, Stat DESC

      ' qryTop10Banded ==== used for Banded
      ' from tblDETSpecies x tblPrograms
      ' Program  (argument)
      ' Location (argument)
      ' Period = getPeriodPost2014([DateEx],[DateFrom],[MonitoringProgramSeason])
      ' FirstDatePeriod = getStartDatePeriodPost2014([DateEx],[DateFrom],[MonitoringProgramSeason])
      ' LastDatePeriod = getLastDatePeriodPost2014_v2([DateEx],[DateFrom],[MonitoringProgramSeason],[tblDETSpecies].[Program])
      ' Stat (Banded summed over Period)
      ' Sorted by Period, Stat DESC

      ' tblTop10DETReport_DET           and      tblTop10DETReport_Banded
      ' Program
      ' Location
      ' Period
      ' FirstDatePeriod
      ' LastDatePeriod
      ' Species
      ' Stat (DET or Banded)
      ' Rank
      ' RankPreviousPeriod

      ' qryTop10DETReport
      ' from tblTop10Report x tblSpecies
      ' Program
      ' Location
      ' Period
      ' Rank
      ' SpeciesDescriptionMBO
      ' Stat (DET or Banded)
      ' Mean (average Stat / 7)  ... not adjusted for days with no DET
      ' RankPreviousPeriod
      ' DateEx (first day of Period)

      Dim rstDETReport As DAO.Recordset
      Dim rstTop10DETReport As DAO.Recordset

      ' ZAP strTop10DETReport

120   CurrentDb.Execute "DELETE * FROM " & strTop10DETReport

      ' Load strTop10DETReport

      Dim db As Database
      Dim qdf As QueryDef
      Dim prm As Parameter
130   Set db = CurrentDb
140   If strStatistic = "Banded" Then
150      Set qdf = db.QueryDefs("qryTop10Banded")
160   Else
170       Set qdf = db.QueryDefs("qryTop10DET")
180   End If
190   qdf.Parameters("argProgram").value = strProgram
200   qdf.Parameters("argLocation").value = strLocation
210   Set rstDETReport = qdf.OpenRecordset

220   Set rstTop10DETReport = CurrentDb.OpenRecordset(strTop10DETReport)

      ' To avoid a lot of reworking DET means either DET or Banded ...

      Dim lngDETSaved As Long
      Dim intPeriodSaved As Integer
230   lngDETSaved = -1
240   intPeriodSaved = -1

250   Do While Not rstDETReport.EOF
          Dim strSpecies As String
          Dim lngDET As Long
          Dim intPeriod As Integer
          Dim datFirstDatePeriod As Date
          Dim datLastDatePeriod As Date
          Dim intRank As Integer
          Dim intCountSpecies As Integer
          
      '   Get record
          
260       strSpecies = Nz(rstDETReport("Species"), 0)
270       lngDET = Nz(rstDETReport("Stat"), 0)
280       intPeriod = Nz(rstDETReport("Period"), 0)
290       datFirstDatePeriod = Nz(rstDETReport("FirstDatePeriod"), 0)
300       datLastDatePeriod = Nz(rstDETReport("LastDatePeriod"), 0)
          
      ' Count pseudospecies within Period
      ' Pause the ranking when two records have the same DET
      ' Catch up the ranking when two records do not have the same DET

310       If intPeriod <> intPeriodSaved Then
320           intCountSpecies = 1
330           intRank = 1
340       Else
350           intCountSpecies = intCountSpecies + 1
360           If lngDET <> lngDETSaved Then
370               intRank = intCountSpecies
380           End If
390       End If
       
      '   Process record

          Dim intPeriodPrevious As Integer
          Dim intRankPrevious As Integer
          
400       If intRank <= 10 Then
          
410           If lngDET <> 0 Then
                
              '   Put record
              
420                 rstTop10DETReport.AddNew
430                 rstTop10DETReport("Program") = strProgram
440                 rstTop10DETReport("Location") = strLocation
450                 rstTop10DETReport("FirstDatePeriod") = datFirstDatePeriod
460                 rstTop10DETReport("LastDatePeriod") = datLastDatePeriod
470                 rstTop10DETReport("Species") = strSpecies
480                 rstTop10DETReport("Stat") = lngDET
490                 rstTop10DETReport("Period") = intPeriod
500                 rstTop10DETReport("Rank") = intRank
                  
510                 intPeriodPrevious = intPeriod - 1
520                 If intPeriodPrevious >= 1 Then
530                     intRankPrevious = Nz(DLookup("Rank", strTop10DETReport, _
                            "[Period] = " & intPeriodPrevious & " AND [Species] = '" & strSpecies & "'"))
540                     If intRankPrevious = 0 Then
550                         rstTop10DETReport("RankPreviousPeriod") = Null
560                     Else
570                         rstTop10DETReport("RankPreviousPeriod") = intRankPrevious
580                     End If
590                 Else
600                     rstTop10DETReport("RankPreviousPeriod") = Null
610                 End If
620                 rstTop10DETReport.Update
                
630             End If
640       End If
          
650       intPeriodSaved = intPeriod
660       lngDETSaved = lngDET
670       rstDETReport.MoveNext
680   Loop
690   rstDETReport.Close

      'DD Error Handler Start
Exit_label:
700        Exit Sub
Err_label:
710        Select Case Err.Number
           Case Else
720       Call LogError("basDETReports", "DETTop10ByPeriodReport")
730        End Select
740        Resume Exit_label
      'DD Error Handler End

End Sub


Public Sub DETTop10ByPeriodReportExport( _
    ByVal intReportYear As Integer, _
    ByVal strLocation As String, _
    ByVal strProgram As String, _
    ByVal strSeason As String, _
    ByRef oExcel As Excel.Application, _
    ByRef oBook As Excel.Workbook, _
    ByVal strStatistic As String)
    
      Dim strTop10DETReport As String

10    If strStatistic = "Banded" Then
20       strTop10DETReport = "qryTop10DETReport_Banded"
30    Else
40       strTop10DETReport = "qryTop10DETReport_DET"
50    End If
          
      '    Create Excel Worksheet

      Dim colLocation As Integer
      Dim colProgram As Integer
      Dim colPeriod As Integer
      Dim colFirstDatePeriod As Integer
      Dim colLastDatePeriod As Integer
      Dim colSpecies As Integer
      Dim colSpeciesEnglish As Integer
      Dim colRank As Integer
      Dim colDET As Integer
      Dim colMean As Integer
      Dim colRankPreviousPeriod As Integer
      Dim colEnd As Integer

60       On Error GoTo Err_label

70    colLocation = 1
80    colProgram = 2
90    colPeriod = 3
100   colFirstDatePeriod = 4
110   colLastDatePeriod = 5
120   colSpecies = 6
130   colSpeciesEnglish = 7
140   colDET = 8
150   colMean = 9
160   colRank = 10
170   colRankPreviousPeriod = 11
180   colEnd = 11

      Dim oSheet As Excel.Worksheet
190   Set oSheet = oBook.Worksheets.Add(After:=oBook.Worksheets(oBook.Worksheets.count))
200   oSheet.Name = "Top 10 " & intReportYear & " " & strSeason & " " & strStatistic

210   With oSheet

          ' Fill in headers

220       .Cells(3, colLocation) = "Location"
230       .Cells(3, colProgram) = "Program"
240       .Cells(3, colPeriod) = "Period"
250       .Cells(3, colFirstDatePeriod) = "Start"
260       .Cells(3, colLastDatePeriod) = "End"
270       .Cells(3, colSpecies) = ""
280       .Cells(3, colSpeciesEnglish) = "Species"
290       .Cells(3, colRank) = "Rank"
300       If strStatistic = "Banded" Then
310           .Cells(3, colDET) = "Banded"
320       Else
330           .Cells(3, colDET) = "DET"
340       End If
350       .Cells(3, colMean) = "Mean"
360       .Cells(2, colRankPreviousPeriod) = "Previous Period"
370       .Cells(3, colRankPreviousPeriod) = "Rank"
          
380       .range(.Cells(3, colLocation), .Cells(3, colEnd)).HorizontalAlignment = xlCenter
          
              Dim qdf As QueryDef
390     Set qdf = CurrentDb.QueryDefs(strTop10DETReport)
        Dim rst As DAO.Recordset
400     Set rst = qdf.OpenRecordset

          Dim row As Long
410       row = 4

          Dim rowStart As Integer
420       rowStart = row

          Dim lngPeriod As Integer
          Dim datFirstDatePeriod As Date
          Dim datLastDatePeriod As Date
          Dim strSpecies As String
          Dim strSpeciesEnglish As String
          Dim intRank As Integer
          Dim lngDET As Integer
          Dim lngMean As Integer
          Dim intRankPreviousPeriod As Integer
          
          Dim lngPeriodPrevious As Long
430       lngPeriodPrevious = -1
          
440       .Cells(row, colLocation) = strLocation
450       .Cells(row, colProgram) = strProgram

460       Do While Not rst.EOF
          
470           lngPeriod = Nz(rst("Period"))
480           datFirstDatePeriod = Nz(rst("FirstDatePeriod"))
490           datLastDatePeriod = Nz(rst("LastDatePeriod"))
500           strSpecies = Nz(rst("Species"))
510           strSpeciesEnglish = Nz(rst("SpeciesDescriptionMBO"))
520           lngDET = Nz(rst("Stat"))
530           intRank = Nz(rst("Rank"))
540           intRankPreviousPeriod = Nz(rst("RankPreviousPeriod"))
550           lngMean = Nz(rst("Mean"))
         
560           If lngPeriod <> lngPeriodPrevious Then
570               lngPeriodPrevious = lngPeriod
580               .Cells(row, colPeriod) = lngPeriod
590               .Cells(row, colFirstDatePeriod) = datFirstDatePeriod
600               .Cells(row, colLastDatePeriod) = datLastDatePeriod
610                With .range(.Cells(row, colPeriod), .Cells(row, colEnd)).Borders(xlEdgeTop)
620                         .LineStyle = xlContinuous
630                         .Weight = xlThin
640                End With
650           End If
              
660           .Cells(row, colSpecies) = strSpecies
670           .Cells(row, colSpeciesEnglish) = strSpeciesEnglish
680           .Cells(row, colDET) = IIf(lngDET <> 0, lngDET, "")
690           Select Case strSeason
              Case "Spring", "Summer", "Fall", "Owling"
700              .Cells(row, colMean) = IIf(lngDET <> 0, lngMean, "")
710           End Select
720           .Cells(row, colRank) = intRank
730           .Cells(row, colRankPreviousPeriod) = IIf(intRankPreviousPeriod <> 0, intRankPreviousPeriod, "")
              
              Dim lngColour As Long
740           Select Case lngPeriod Mod 4
                  Case 0
750                   lngColour = RGB(253, 233, 217)
760               Case 1
770                   lngColour = RGB(219, 238, 243)
780               Case 2
790                   lngColour = RGB(234, 241, 221)
800               Case 3
810                   lngColour = RGB(255, 201, 201)
820           End Select
                
830           If row Mod 2 = 0 Then
840               .range(.Cells(row, colSpecies), .Cells(row, colEnd)).Interior.Color = lngColour
850           End If
              
860           row = row + 1
870           rst.MoveNext
880       Loop
890       rst.Close
900       Set rst = Nothing

          Dim rowEnd As Long
910       rowEnd = row - 1

920       .range(.columns(colFirstDatePeriod), .columns(colLastDatePeriod)).NumberFormat = "d mmm yy"
930       .range(.columns(colPeriod), .columns(colPeriod)).HorizontalAlignment = xlCenter
940       .range(.columns(colDET), .columns(colRankPreviousPeriod)).HorizontalAlignment = xlCenter

950       .range("A4").Select
960        oExcel.ActiveWindow.FreezePanes = True
          
970        .range(.columns(1), .columns(colEnd)).AutoFit

          Dim strTitle As String
980       If strStatistic = "Banded" Then
990           strTitle = intReportYear & " " & strSeason & " " & _
                  "DET Top 10 Banded by Period Report " & strProgram & " at " & strLocation
1000      Else
1010          strTitle = intReportYear & " " & strSeason & " " & _
                  "DET Top 10 by Period Report " & strProgram & " at " & strLocation
1020      End If

1030      .Cells(1, 1) = strTitle
1040      .range(.Cells(1, 1), .Cells(1, 1)).HorizontalAlignment = xlLeft
1050      .range(.Cells(1, 1), .Cells(1, 1)).Font.Size = 14
1060      .range(.Cells(1, 1), .Cells(1, 1)).Font.Bold = True
          
1070      .Cells(2, colEnd + 2) = "Reports pseudo-species i.e. TRFL, ALFL, WIFL, YPWA. WPWA"
1080      .Cells(3, colEnd + 2) = "The mean does NOT account for incomplete periods (less than 7 days DET in a week)"
          
1090  End With

1100  Set oSheet = Nothing

          'DD Error Handler Start
Exit_label:
1110      Exit Sub
Err_label:
1120      Select Case Err.Number
          Case Else
1130     Call LogError("basDETReports", "DETTop10ByPeriodReportExport")
1140      End Select
1150      Resume Exit_label
          ' DD Error Handler End

End Sub


Public Sub DETTop10ByPeriodReportExportWord( _
    ByRef wd As Word.Application, _
    ByRef doc As Word.Document, _
    ByRef rng As Word.range, _
    ByVal intPeriod As Integer, _
    ByVal strStatistic As String, _
    ByVal strLanguage As String)
          
      Dim strTop10DETReport As String

10       On Error GoTo Err_label

20    If strStatistic = "Banded" Then
30       strTop10DETReport = "qryTop10DETReportFacebook_Banded"
40    Else
50       strTop10DETReport = "qryTop10DETReportFacebook_DET"
60    End If
           
      Dim qdf As QueryDef
70    Set qdf = CurrentDb.QueryDefs(strTop10DETReport)
80    qdf.Parameters("argPeriod") = intPeriod
      Dim rst As DAO.Recordset
90    Set rst = qdf.OpenRecordset

      Dim intRank As Integer
      Dim strSpeciesLanguage As String
      Dim lngStat As Long

100   Do While Not rst.EOF
        
110         intRank = Nz(rst("Rank"))
120         If strLanguage = "English" Then
130             strSpeciesLanguage = Nz(rst("SpeciesDescriptionMBO"))
140         Else
150                 strSpeciesLanguage = Nz(rst("Speciesfrench"))
160         End If
170         lngStat = Nz(rst("Stat"))
180         If strStatistic = "DET" Then
190             lngStat = CLng(lngStat / 7)
200         End If
       
210         rng.InsertAfter intRank & ". " & strSpeciesLanguage & " (" & lngStat & ")"
220         rng.InsertParagraphAfter

230         rst.MoveNext
240     Loop
250     rst.Close
260     Set rst = Nothing

    'DD Error Handler Start
Exit_label:
270       Exit Sub
Err_label:
280       Select Case Err.Number
    Case Else
290      Call LogError("basDETReports", "DETTop10ByPeriodReportExportWord")
300       End Select
310       Resume Exit_label
    ' DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' DETMonitoringProgramSummaryReport
'---------------------------------------------------------------------------------------
 
'Public Sub DETMonitoringProgramSummaryReport( _
'    ByRef fValid As Boolean, _
'    ByVal intYear As Integer, _
'    ByVal strLocation As String, _
'    ByVal strprogram As String, _
'    ByVal strSeason As String, _
'    ByVal datFrom As Date, _
'    ByVal datTo As Date, _
'    ByRef oExcel As Excel.Application, _
'    ByRef oBook As Excel.Workbook)
'
'10    On Error GoTo Err_label
'
'      ' Save parameters
'
''20    intYear = argYear
''30    strLocation = argLocation
''40    strProgram = argProgram
''50    strSeason = argSeason
''60    Set oExcel = arg_excel
''70    Set oBook = arg_book
'
'20    fValid = True
'
'      ' Create the temporary table tblDETReport_Rows
'
'      ' tblDETReport_Rows
'      ' from tblDETSpecies
'      ' Program (argument)
'      ' strLocation (argument)
'      ' Period (one per day)
'      ' Species
'      ' Obs
'      ' Cns
'      ' Bnd
'      ' Rep
'      ' Ret
'      ' DET
'      ' Alien       (summed over program)
'      ' Replacement (summed over program)
'      ' FirstDatePeriod
'      ' LastDatePeriod
'
'30    On Error Resume Next
'40    DoCmd.DeleteObject ObjectType:=acTable, ObjectName:="tblDETReport_Rows"
'50    On Error GoTo Err_label
'
'      Dim qdf As QueryDef
'60    Set qdf = CurrentDb.QueryDefs("qryDETProgramReport")
'70    qdf.Parameters("argProgram").value = strprogram
'80    qdf.Parameters("argLocation").value = strLocation
'90    qdf.Parameters("argFrom").value = datFrom
'100   qdf.Parameters("argTo").value = datTo
'110   qdf.Execute
'
'120   Call CreateTblDETReport
'
'130   If DCount("*", "tblDETReport") = 0 Then
'140       MsgBox "There are no DET records for the given Program and Location", , "DET Report"
'150       GoTo Exit_label
'160   End If
'
'      Dim strTitle As String
'170   strTitle = intYear & " " & strSeason & " " & _
'          "DET Program Summary Report " & strprogram & " at " & strLocation
'180   Call Export_tblDETReport( _
'    intYear, strSeason, strprogram, strLocation, strTitle, oExcel, oBook, "Program")
'
'      'DD Error Handler Start
'Exit_label:
'190        Exit Sub
'Err_label:
'200        Select Case Err.Number
'           Case Else
'210       Call LogError("basDETReports", "DETMonitoringProgramSummaryReport")
'220        End Select
'230        Resume Exit_label
'      'DD Error Handler End
'
'    End Sub

'---------------------------------------------------------------------------------------
' DETDailyReport
'---------------------------------------------------------------------------------------
'
'Public Sub DETDailyReport( _
'    ByRef fValid As Boolean, _
'    ByVal strLocation As String, _
'    ByVal strprogram As String, _
'    ByVal intYear As Integer, _
'    ByVal strSeason As String, _
'    ByVal datFrom As Date, _
'    ByVal datTo As Date, _
'    ByRef oExcel As Excel.Application, _
'    ByRef oBook As Excel.Workbook)
'
'10    On Error GoTo Err_label
'
'20    fValid = True
'
'      ' Create the temporary table tblDETReport_Rows
'
'      ' tblDETReport_Rows
'      ' from tblDETSpecies
'      ' Program (argument)
'      ' strLocation (argument)
'      ' Period (one per day)
'      ' Species
'      ' Obs
'      ' Cns
'      ' Bnd
'      ' Rep
'      ' Ret
'      ' DET
'      ' Alien       (summed over day)
'      ' Replacement (summed over day)
'      ' FirstDatePeriod
'      ' LastDatePeriod
'
'30    On Error Resume Next
'40    DoCmd.DeleteObject ObjectType:=acTable, ObjectName:="tblDETReport_Rows"
'50    On Error GoTo Err_label
'
'      Dim qdf As QueryDef
'60    Set qdf = CurrentDb.QueryDefs("qryDETDailyReport")
'70    qdf.Parameters("argProgram").value = strprogram
'80    qdf.Parameters("argLocation").value = strLocation
'90    qdf.Parameters("argFrom").value = datFrom
'100   qdf.Parameters("argTo").value = datTo
'110   qdf.Execute
'
'120   Call CreateTblDETReport
'
'130   If DCount("*", "tblDETReport") = 0 Then
'140       MsgBox "There are no DET records for the given Program and Location", , "DET Report"
'150       GoTo Exit_label
'160   End If
'
'      Dim strTitle As String
'
'170   strTitle = intYear & " " & strSeason & " " & _
'          "DET Daily Report from " & Format(datFrom, "d mmm yyyy") & " to " & _
'          Format(datTo, "d mmm yyyy") & " " & strprogram & " at " & strLocation
'180   Call Export_tblDETReport( _
'    intYear, strSeason, strprogram, strLocation, strTitle, oExcel, oBook, "Daily")
'
'      'DD Error Handler Start
'Exit_label:
'190        Exit Sub
'Err_label:
'200        Select Case Err.Number
'           Case Else
'210       Call LogError("basDETReports", "DETWeeklyReport")
'220        End Select
'230        Resume Exit_label
'      'DD Error Handler End
'
'    End Sub


'---------------------------------------------------------------------------------------
' Export_tblDETReport
'---------------------------------------------------------------------------------------
' Called from DETDailyReport                        strReport = "Daily"
'             DETWeeklyReport                                 = "Weekly"
'             DETMonitoringProgramSummaryReport               = Program"
'
' For the daily DET report I also write out the effort data
 
 
'Private Sub Export_tblDETReport( _
'    ByVal intYear As Integer, _
'    ByVal strSeason As String, _
'    ByVal strprogram As String, _
'    ByVal strLocation As String, _
'    ByVal strTitle As String, _
'    ByRef oExcel As Excel.Application, _
'    ByRef oBook As Excel.Workbook, _
'    ByVal strReport As String)
'
'      Dim colLocation As Integer
'      Dim colProgram As Integer
'      Dim colPeriod As Integer
'      Dim colFirstDatePeriod As Integer
'      Dim colLastDatePeriod As Integer
'      Dim colSpecies As Integer
'      Dim colObserved As Integer
'      Dim colCensus As Integer
'      Dim colBanded As Integer
'      Dim colRepeats As Integer
'      Dim colReturns As Integer
'      Dim colAlien As Integer
'      Dim colReplacement As Integer
'      Dim colDET As Integer
'      Dim colObservedSpecies As Integer
'      Dim colCensusSpecies As Integer
'      Dim colBandedSpecies As Integer
'      Dim colRepeatsSpecies As Integer
'      Dim colReturnsSpecies As Integer
'      Dim colAlienSpecies As Integer
'      Dim colReplacementSpecies As Integer
'      Dim colDETSpecies As Integer
'      Dim colEnd As Integer
'      Dim colNetHours As Integer
'
'10    On Error GoTo Err_label
'
'20    colLocation = 1
'30    colProgram = 2
'40    colPeriod = 3
'50    colFirstDatePeriod = 4
'60    colLastDatePeriod = 5
'70    colSpecies = 6
'80    colObserved = 7
'90    colCensus = 8
'100   colBanded = 9
'110   colReturns = 10
'120   colRepeats = 11
'130   colAlien = 12
'140   colReplacement = 13
'150   colDET = 14
'160   colObservedSpecies = 15
'170   colCensusSpecies = 16
'180   colBandedSpecies = 17
'190   colReturnsSpecies = 18
'200   colRepeatsSpecies = 19
'210   colAlienSpecies = 20
'220   colReplacementSpecies = 21
'230   colDETSpecies = 22
'240   colNetHours = 23
'
'250   If strReport = "Daily" Then
'260       colEnd = 23
'270   Else
'280       colEnd = 22
'290   End If
'
'      Dim oSheet As Excel.Worksheet
'300   Set oSheet = oBook.Worksheets.Add(After:=oBook.Worksheets(oBook.Worksheets.count))
'310   oSheet.Name = intYear & " " & strSeason & " " & strReport
'
'320   With oSheet
'
'          ' Fill in headers
'
'330       .Cells(3, colLocation) = "Location"
'340       .Cells(3, colProgram) = "Program"
'350       .Cells(2, colPeriod) = "Period"
'360       .range(.Cells(2, colPeriod), .Cells(2, colLastDatePeriod)).Merge
'370       .Cells(3, colPeriod) = "#"
'380       .Cells(3, colFirstDatePeriod) = "Start"
'390       .Cells(3, colLastDatePeriod) = "End"
'400       .Cells(3, colSpecies) = "Species"
'410       .Cells(2, colObserved) = "Individuals"
'420       .range(.Cells(2, colObserved), .Cells(2, colDET)).Merge
'430       .Cells(3, colObserved) = "Observed"
'440       .Cells(3, colCensus) = "Census"
'450       .Cells(3, colBanded) = "Banded"
'460       .Cells(3, colRepeats) = "Repeats"
'470       .Cells(3, colReturns) = "Returns"
'480       .Cells(3, colAlien) = "Alien"
'490       .Cells(3, colReplacement) = "Replacement"
'500       .Cells(3, colDET) = "DET"
'510       .Cells(2, colObservedSpecies) = "Species"
'520       .range(.Cells(2, colObservedSpecies), .Cells(2, colDETSpecies)).Merge
'530       .Cells(3, colObservedSpecies) = "Observed"
'540       .Cells(3, colCensusSpecies) = "Census"
'550       .Cells(3, colBandedSpecies) = "Banded"
'560       .Cells(3, colRepeatsSpecies) = "Repeats"
'570       .Cells(3, colReturnsSpecies) = "Returns"
'580       .Cells(3, colAlienSpecies) = "Alien"
'590       .Cells(3, colReplacementSpecies) = "Replacement"
'600       .Cells(3, colDETSpecies) = "DET"
'
'610       If strReport = "Daily" Then
'620           .Cells(3, colNetHours) = "Net Hours"
'630       End If
'
'640       .range(.Cells(2, colLocation), .Cells(3, colEnd)).HorizontalAlignment = xlCenter
'
'         Dim strSQL As String
'650       strSQL = "SELECT * FROM tblDETReport ORDER BY Period, SpeciesOrder"
'
'         Dim rst As DAO.Recordset
'660       Set rst = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)
'
'          Dim row As Long
'670       row = 4
'
'          Dim rowStart As Integer
'680       rowStart = row
'
'          Dim lngPeriod As Integer
'          Dim datFirstDatePeriod As Date
'          Dim datLastDatePeriod As Date
'          Dim strSpecies As String
'          Dim lngObserved As Integer
'          Dim lngCensus As Integer
'          Dim lngBanded As Integer
'          Dim lngRepeats As Integer
'          Dim lngReturns As Integer
'          Dim lngAlien As Integer
'          Dim lngReplacement As Integer
'          Dim lngDET As Integer
'          Dim lngObservedSpecies As Integer
'          Dim lngCensusSpecies As Integer
'          Dim lngBandedSpecies As Integer
'          Dim lngRepeatsSpecies As Integer
'          Dim lngReturnsSpecies As Integer
'          Dim lngAlienSpecies As Integer
'          Dim lngReplacementSpecies As Integer
'          Dim lngDETSpecies As Integer
'          Dim fHighlight As Boolean
'
'          Dim lngPeriodPrevious As Long
'690       lngPeriodPrevious = -1
'
'700       Do While Not rst.EOF
'
'710           lngPeriod = Nz(rst("Period"))
'720           datFirstDatePeriod = Nz(rst("FirstDatePeriod"))
'730           datLastDatePeriod = Nz(rst("LastDatePeriod"))
'740           strSpecies = Nz(rst("Species"))
'750           lngObserved = Nz(rst("Obs"))
'760           lngCensus = Nz(rst("Cns"))
'770           lngBanded = Nz(rst("Bnd"))
'780           lngReturns = Nz(rst("Ret"))
'790           lngRepeats = Nz(rst("Rep"))
'800           lngAlien = Nz(rst("Alien"))
'810           lngReplacement = Nz(rst("Replacement"))
'820           lngDET = Nz(rst("DET"))
'830           lngObservedSpecies = Nz(rst("ObsSpecies"))
'840           lngCensusSpecies = Nz(rst("CnsSpecies"))
'850           lngBandedSpecies = Nz(rst("BndSpecies"))
'860           lngReturnsSpecies = Nz(rst("RetSpecies"))
'870           lngRepeatsSpecies = Nz(rst("RepSpecies"))
'880           lngAlienSpecies = Nz(rst("AlienSpecies"))
'890           lngReplacementSpecies = Nz(rst("ReplacementSpecies"))
'900           lngDETSpecies = Nz(rst("DETSpecies"))
'910           fHighlight = Nz(rst("Highlight"))
'
'920             .Cells(row, colPeriod) = lngPeriod
'930             If lngPeriod <> lngPeriodPrevious Then
'940                 lngPeriodPrevious = lngPeriod
'950                 .Cells(row, colLocation) = strLocation
'960                 .Cells(row, colProgram) = strprogram
'970                 .Cells(row, colFirstDatePeriod) = datFirstDatePeriod
'980                 .Cells(row, colLastDatePeriod) = datLastDatePeriod
'990                   With .range(.Cells(row, colPeriod), .Cells(row, colEnd)).Borders(xlEdgeTop)
'1000                      .LineStyle = xlContinuous
'1010                      .Weight = xlThin
'1020                  End With
'
'1030                  If strReport = "Daily" Then
'                          Dim strwhere As String
'                          Dim varNetHours As Variant
'1040                      strwhere = _
'                              "[Location] = '" & strLocation & "' AND " & _
'                              "[Program] = '" & strprogram & "' AND " & _
'                              "[DateEx] = #" & Format(datFirstDatePeriod, "mm/dd/yyyy") & "#"
'1050                      varNetHours = DLookup("SongBirdNets", "tblDETDaily", strwhere)
'1060                      If Not IsNull(varNetHours) Then
'1070                          .Cells(row, colNetHours) = varNetHours
'1080                      End If
'1090                  End If
'
'1100            End If
'
'1110          .Cells(row, colSpecies) = strSpecies
'1120          .Cells(row, colObserved) = IIf(lngObserved <> 0, lngObserved, "")
'1130          .Cells(row, colCensus) = IIf(lngCensus <> 0, lngCensus, "")
'1140          .Cells(row, colBanded) = IIf(lngBanded <> 0, lngBanded, "")
'1150          .Cells(row, colRepeats) = IIf(lngRepeats <> 0, lngRepeats, "")
'1160          .Cells(row, colReturns) = IIf(lngReturns <> 0, lngReturns, "")
'1170          .Cells(row, colAlien) = IIf(lngAlien <> 0, lngAlien, "")
'1180          .Cells(row, colReplacement) = IIf(lngReplacement <> 0, lngReplacement, "")
'1190          .Cells(row, colDET) = IIf(lngDET <> 0, lngDET, "")
'1200          .Cells(row, colObservedSpecies) = IIf(lngObservedSpecies = 1, 1, "")
'1210          .Cells(row, colCensusSpecies) = IIf(lngCensusSpecies = 1, 1, "")
'1220          .Cells(row, colBandedSpecies) = IIf(lngBandedSpecies = 1, 1, "")
'1230          .Cells(row, colRepeatsSpecies) = IIf(lngRepeatsSpecies = 1, 1, "")
'1240          .Cells(row, colReturnsSpecies) = IIf(lngReturnsSpecies = 1, 1, "")
'1250          .Cells(row, colAlienSpecies) = IIf(lngAlienSpecies = 1, 1, "")
'1260          .Cells(row, colReplacementSpecies) = IIf(lngReplacementSpecies = 1, 1, "")
'1270          .Cells(row, colDETSpecies) = IIf(lngDETSpecies = 1, 1, "")
'
'              Dim lngColour As Long
'1280          Select Case lngPeriod Mod 4
'                  Case 0
'1290                  lngColour = RGB(253, 233, 217)
'1300              Case 1
'1310                  lngColour = RGB(219, 238, 243)
'1320              Case 2
'1330                  lngColour = RGB(234, 241, 221)
'1340              Case 3
'1350                  lngColour = RGB(255, 201, 201)
'1360          End Select
'
'1370          If row Mod 2 = 0 Then
'1380              .range(.Cells(row, colSpecies), .Cells(row, colEnd)).Interior.Color = lngColour
'1390          End If
'
'1400          If fHighlight Then
'1410              .range(.Cells(row, 1), .Cells(row, colEnd)).Interior.Color = vbYellow
'1420          End If
'
'1430          row = row + 1
'1440          rst.MoveNext
'1450      Loop
'1460      rst.Close
'1470      Set rst = Nothing
'
'          Dim rowEnd As Long
'1480      rowEnd = row - 1
'
'1490      .range(.Columns(colFirstDatePeriod), .Columns(colLastDatePeriod)).NumberFormat = "d mmm yy"
'1500      .range(.Columns(colPeriod), .Columns(colPeriod)).HorizontalAlignment = xlCenter
'1510      .range(.Columns(colObserved), .Columns(colDETSpecies)).HorizontalAlignment = xlCenter
'
'1520      .range("A4").Select
'1530       oExcel.ActiveWindow.FreezePanes = True
'
'      ' Subtotal
'
'1540      .range(.Cells(3, 1), .Cells(rowEnd, colEnd)).Subtotal _
'              GroupBy:=3, Function:=xlSum, _
'              TotalList:=Array(7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22), _
'              Replace:=True, PageBreaks:=False, SummaryBelowData:=True
'
'      ' Find the last row, then blank the grand totals for species
'
'          Dim col As Long
'
'1550      rowEnd = .Cells(.Rows.count, "C").End(xlUp).row
'1560      For col = colObservedSpecies To colDETSpecies
'1570          .Cells(rowEnd, col) = ""
'1580      Next
'
'1590       .range(.Columns(1), .Columns(colEnd)).AutoFit
'
'1600      .Cells(1, 1) = strTitle
'1610      .range(.Cells(1, 1), .Cells(1, 1)).HorizontalAlignment = xlLeft
'1620      .range(.Cells(1, 1), .Cells(1, 1)).Font.Size = 14
'1630      .range(.Cells(1, 1), .Cells(1, 1)).Font.Bold = True
'
'1640       .Cells(1, colEnd + 2) = "Species totals are correct for all Species/sub-species e.g. PAWA, YPWA, WPWA"
'1650       .Cells(2, colEnd + 2) = "Species totals are correct for all Super-species/species e.g. TRFL, ALFL, WIFL"
'
'1660       .Columns(3).Hidden = True
'
'1670  End With
'1680  Set oSheet = Nothing
'
'      'DD Error Handler Start
'Exit_label:
'1690       Exit Sub
'Err_label:
'1700       Select Case Err.Number
'           Case Else
'1710      Call LogError("basDETReports", "Export_tblDETReport")
'1720       End Select
'1730       Resume Exit_label
'      'DD Error Handler End
'
'End Sub


'---------------------------------------------------------------------------------------
' CreateTblDETReport
'---------------------------------------------------------------------------------------'
' Called during the creation of the following reports:
'   DET Daily Report,
'   DET Monitoring Program Summary Report,
'   DET Weekly Summary Report
'
' For the DET Daily Report, each "Period" corresponds to one day
' For the DET Monitoring Program Summary Report, there is only one "Period"
' For the DET Weekly/Period Summary Report, each period is one week for Spring and Fall
'     more or less a month for Winter, and 1 for all other monitoring programs
'
' PRE: tblDETReport_Rows has been created and populated
'
' tblDETReport_Rows
' from tblDETSpecies
' Program  (argument)
' Location (arguement)
' Period
' Species
' Obs         (summed over period)    period can be one day, a week, month, or monitoring program
' Cns         (summed over period)
' Bnd         (summed over period)
' Rep         (summed over period)
' Ret         (summed over period)
' DET         (summed over period)
' Alien       (summed over period)
' Replacement (summed over period)
' FirstDatePeriod
' LastDatePeriod

Public Sub CreateTblDETReport()

      ' tblDETReport
      ' from tblDETReport_Rows x tblSpecies
      ' Program (argument)
      ' Location (argument)
      ' Period
      ' Species
      ' Obs         (summed over period)
      ' Cns         (summed over period)
      ' Bnd         (summed over period)
      ' Ret         (summed over period)
      ' Rep         (summed over period)
      ' DET         (summed over period)
      ' Alien       (summed over period)
      ' Replacement (summed over period)
      ' DateOfFirstOfPeriod
      ' DateOfLastOfPeriod
      ' ObsSpecies = 1 if Obs > 0
      ' CnsSpecies = 1 if Cns > 0
      ' BndSpecies = 1 if Bnd > 0
      ' RetSpecies = 1 if Ret > 0
      ' RepSpecies = 1 if Rep > 0
      ' DETSpecies = 1 if Obs > 0
      ' AlienSpecies = 1 if Alien > 0
      ' ReplacementSpecies = 1 if Replacement > 0
      ' SpeciesOrder = AOUOrder
      ' Highlight = True if member of a species/subspecies or superspecies/species

      ' Delete the temporary table tblDETReport

10    On Error GoTo Err_label

20    If Not IsNull(DLookup("Name", "MSysObjects", "Name='tblDETReport'")) Then
30        On Error Resume Next
40        DoCmd.DeleteObject ObjectType:=acTable, ObjectName:="tblDETReport"
50        If Err.Number <> 0 Then
60             Call LogError("basDETReports", "CreateTblDETReport", "Failed to delete tblDETReport" & vbCrLf & Err.Number & Err.Description, True)
70        End If
80        On Error GoTo Err_label
90    End If

      ' Create and populate tblDETReport

100   CurrentDb.Execute "qryDETReport"

110   Call ProcessSuperSpecies
120   Call ProcessSubspecies

      'DD Error Handler Start
Exit_label:
130        Exit Sub
Err_label:
140        Select Case Err.Number
           Case Else
150             Call LogError("basDETReports", "CreateTblDETReport")
160        End Select
170        Resume Exit_label
      'DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' ProcessSuperSpecies
'---------------------------------------------------------------------------------------
' Adjust tblDETReport to account for superspecies/species
'
 
Private Sub ProcessSuperSpecies()

      Const conMaxStat As Integer = 8

10    On Error GoTo Err_label

      Dim StatName(conMaxStat) As String
20    StatName(1) = "ObsSpecies"
30    StatName(2) = "CnsSpecies"
40    StatName(3) = "BndSpecies"
50    StatName(4) = "RetSpecies"
60    StatName(5) = "RepSpecies"
70    StatName(6) = "DETSpecies"
80    StatName(7) = "AlienSpecies"
90    StatName(8) = "ReplacementSpecies"

      'Dim StatValue(conMaxStat) As Integer

      ' For each super-species
      '   For each period
      '       If there is a super-species record in tblDETReport for the period
      '           For each species column
      '               For each component species record in tblWeeklyDETSpecies for the period
      '                   If the column species = 1
      '                       Zero the species column in the super-species record

      Dim strSQL As String

      Dim rstSuperSpecies As New ADODB.Recordset        ' List of super-species
      Dim rstSpecies As New ADODB.Recordset             ' List of species for a super-species
      Dim rstDETSuperSpecies  As New ADODB.Recordset
      Dim rstDETSpecies As New ADODB.Recordset

      Dim strSuperSpecies As String

      ' Loop over super-species
      ' e.g. TRFL

      ' Dim strSQL As String
100   strSQL = "SELECT SuperSpecies FROM tblSuperSpecies GROUP BY SuperSpecies"

110   rstSuperSpecies.ActiveConnection = CurrentProject.Connection
120   rstSuperSpecies.Source = strSQL
130   rstSuperSpecies.CursorType = adOpenDynamic
140   rstSuperSpecies.LockType = adLockPessimistic
150   rstSuperSpecies.Open
160   Do While Not rstSuperSpecies.EOF

170       strSuperSpecies = rstSuperSpecies("SuperSpecies")
          
          ' Construct IN('species1','species2',...) clause
          ' e.g. "IN ('ALFL','WIFL')"

          Dim strIN As String
180       strIN = ""

          ' Loop over each species

190       strSQL = _
              "SELECT Species FROM tblSuperSpecies " & _
              "WHERE SuperSpecies = '" & strSuperSpecies & "'"

200             rstSpecies.ActiveConnection = CurrentProject.Connection
210             rstSpecies.Source = strSQL
220             rstSpecies.CursorType = adOpenDynamic
230             rstSpecies.LockType = adLockPessimistic
240             rstSpecies.Open
250             Do While Not rstSpecies.EOF
260           If strIN = "" Then
270               strIN = "IN ( '" & rstSpecies("Species") & "'"
280           Else
290               strIN = strIN & ",'" & rstSpecies("Species") & "'"
300           End If
310           rstSpecies.MoveNext
320       Loop
330       rstSpecies.Close
340       strIN = strIN & ")"
          
           ' Loop over each period of tblDETReport
          
          Dim lngPeriodFirst As Long
          Dim lngPeriodLast As Long
          Dim lngPeriod As Long
          
350       lngPeriodFirst = Nz(DMin("Period", "tblDETReport", "True"))
360       lngPeriodLast = Nz(DMax("Period", "tblDETReport", "True"))
370       For lngPeriod = lngPeriodFirst To lngPeriodLast
          
              ' Skip if there is no super-species record in this period
              
              Dim strSuperSpeciesWhere As String
380           strSuperSpeciesWhere = "Period = " & lngPeriod & " AND Species = '" & strSuperSpecies & "'"
390           If DCount("*", "tblDETReport", strSuperSpeciesWhere) = 0 Then GoTo Next_Period_label
                                       
            ' Skip if there are no species record for this super-species in this period
              
              Dim strSpeciesWhere As String
400           strSpeciesWhere = "Period = " & lngPeriod & " AND Species " & strIN
410           If DCount("*", "tblDETReport", strSpeciesWhere) = 0 Then GoTo Next_Period_label
             
              ' Highlight all records for the superspecies and its species in this period
          
420           strSQL = _
                  "UPDATE tblDETReport SET Highlight = True WHERE " & strSuperSpeciesWhere
430           CurrentDb.Execute strSQL
          
440           strSQL = _
                  "UPDATE tblDETReport SET Highlight = True WHERE " & strSpeciesWhere
450               CurrentDb.Execute strSQL
                          
              ' Loop over each statistic
              
              Dim stat As Integer
460           For stat = 1 To conMaxStat
              
                  ' if any of the species of the super-species has a non-zero
                  ' statistic in the period, then null the super-species stat
              
470               If DSum(StatName(stat), "tblDETReport", strSpeciesWhere) > 0 Then
480                   strSQL = _
                          "UPDATE tblDETReport " & _
                          " SET " & StatName(stat) & "=0 " & _
                          " WHERE " & strSuperSpeciesWhere
490                   CurrentDb.Execute strSQL
500               End If
              
510           Next
             
Next_Period_label:
520        Next
           
530        rstSuperSpecies.MoveNext
540   Loop

      'DD Error Handler Start
Exit_label:
550        Exit Sub
Err_label:
560        Select Case Err.Number
           Case Else
570       Call LogError("basDETReports", "ProcessSuperSpecies")
580        End Select
590        Resume Exit_label
      'DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' ProcessSubspecies
'---------------------------------------------------------------------------------------
' Adjust tblDETReport to account for species/subspecies
'
Private Sub ProcessSubspecies()

      Const conMaxStat As Integer = 8

      Dim StatName(conMaxStat) As String
10    On Error GoTo Err_label

20    StatName(1) = "ObsSpecies"
30    StatName(2) = "CnsSpecies"
40    StatName(3) = "BndSpecies"
50    StatName(4) = "RetSpecies"
60    StatName(5) = "RepSpecies"
70    StatName(6) = "DETSpecies"
80    StatName(7) = "AlienSpecies"
90    StatName(8) = "ReplacementSpecies"

      Dim StatValue(conMaxStat) As Integer

      ' Loop over species that have subspecies
      ' e.g. PAWA

      Dim strSQL As String
100   strSQL = "SELECT Species FROM tblSubspecies GROUP BY Species"
      Dim rstSpecies As New ADODB.Recordset
110   rstSpecies.ActiveConnection = CurrentProject.Connection
120   rstSpecies.Source = strSQL
130   rstSpecies.CursorType = adOpenDynamic
140   rstSpecies.LockType = adLockPessimistic
150   rstSpecies.Open
160   Do While Not rstSpecies.EOF
          
          ' Construct IN('subspecies1','subspecies2',...) clause
          ' e.g. "IN ('WPWA','YPWA')"
          
          Dim strSpecies As String
170       strSpecies = rstSpecies("Species")
          
          Dim strIN As String
180       strIN = ""

          ' Loop over each subspecies
       
190       strSQL = _
              "SELECT Subspecies FROM tblSubspecies " & _
              "WHERE Species = '" & strSpecies & "'"
          Dim rstSubSpecies As New ADODB.Recordset
200       rstSubSpecies.ActiveConnection = CurrentProject.Connection
210       rstSubSpecies.Source = strSQL
220       rstSubSpecies.CursorType = adOpenDynamic
230       rstSubSpecies.LockType = adLockPessimistic
240       rstSubSpecies.Open
250       Do While Not rstSubSpecies.EOF
260           If strIN = "" Then
270               strIN = "IN ( '" & rstSubSpecies("Subspecies") & "'"
280           Else
290               strIN = strIN & ",'" & rstSubSpecies("Subspecies") & "'"
300           End If
310           rstSubSpecies.MoveNext
320       Loop
330       rstSubSpecies.Close
340       strIN = strIN & ")"
          
          ' Highlight all records for the species and its subspecies
          
350        strSQL = _
              "UPDATE tblDETReport SET Highlight = True WHERE Species = '" & strSpecies & "'"
360       CurrentDb.Execute strSQL
          
370       strSQL = _
              "UPDATE tblDETReport SET Highlight = True WHERE Species " & strIN
380       CurrentDb.Execute strSQL
          
          ' Loop over each period of tblDETReport
          
          Dim lngPeriodFirst As Long
          Dim lngPeriodLast As Long
          Dim lngPeriod As Long
          
390       lngPeriodFirst = Nz(DMin("Period", "tblDETReport", "True"))
400       lngPeriodLast = Nz(DMax("Period", "tblDETReport", "True"))
410       For lngPeriod = lngPeriodFirst To lngPeriodLast
          
              ' Skip if there are no subspecies records for species in period
          
              Dim strWhere As String
420           strWhere = "Species " & strIN & " AND " & "Period = " & lngPeriod
              
              Dim cnt As Integer
430           cnt = DCount("*", "tblDETReport", strWhere)
440           If cnt >= 1 Then
              
                  ' If necessary add a record for the species
                    
450               If 0 = DCount("*", "tblDETReport", "Species = '" & strSpecies & "' AND " & "Period = " & lngPeriod) Then
                      
                      Dim datFirstDatePeriod As Date
                      Dim datLastDatePeriod As Date
460                   datFirstDatePeriod = Nz(DLookup("FirstDatePeriod", "tblDETReport", "Period = " & lngPeriod))
470                   datLastDatePeriod = Nz(DLookup("LastDatePeriod", "tblDETReport", "Period = " & lngPeriod))
                      Dim lngSpeciesOrder As Long
480                   lngSpeciesOrder = Nz(DLookup("AOUOrder", "tblSpecies", "Species='" & strSpecies & "'"))
        
490                   strSQL = _
                          "INSERT INTO tblDETReport(Period,Species,FirstDatePeriod,LastDatePeriod," & _
                          "ObsSpecies,CnsSpecies,RepSpecies,RetSpecies,DETSpecies,BndSpecies," & _
                          "SpeciesOrder,Highlight)" & _
                          " VALUES(" & _
                          lngPeriod & "," & _
                          "'" & strSpecies & "'," & _
                          "#" & Format(datFirstDatePeriod, "mm/dd/yyyy") & "#," & _
                          "#" & Format(datLastDatePeriod, "mm/dd/yyyy") & "#," & _
                          "0,0,0,0,0,0," & _
                          lngSpeciesOrder & "," & _
                          "True)"
500                   CurrentDb.Execute strSQL
              
510               End If
        
                  ' Loop over subspecies for period
              
520               strSQL = "SELECT * FROM tblDETReport WHERE " & strWhere
                  Dim rstDET As New ADODB.Recordset
530               rstDET.ActiveConnection = CurrentProject.Connection
540               rstDET.Source = strSQL
550               rstDET.CursorType = adOpenDynamic
560               rstDET.LockType = adLockPessimistic
570               rstDET.Open
                  
                  Dim stat As Integer
580               For stat = 1 To conMaxStat
590                   StatValue(stat) = 0
600               Next
              
610               Do While Not rstDET.EOF
                  Dim i As Integer

                      ' Process next subspecies record
                      
620                   For stat = 1 To conMaxStat
630                       If rstDET(StatName(stat)) = 1 Then
640                           StatValue(stat) = 1
650                       End If
660                       rstDET(StatName(stat)) = Null
670                   Next stat
                      
680                   rstDET.Update
690                   rstDET.MoveNext
700               Loop
710               rstDET.Close
                  
                  ' Merge statistics into species record
                  
720               strSQL = _
                      "SELECT * FROM tblDETReport WHERE " & _
                      "Species = '" & strSpecies & "' AND Period = " & lngPeriod
                  Dim rstDETPeriodSpecies As New ADODB.Recordset
730               rstDETPeriodSpecies.ActiveConnection = CurrentProject.Connection
740               rstDETPeriodSpecies.Source = strSQL
750               rstDETPeriodSpecies.CursorType = adOpenDynamic
760               rstDETPeriodSpecies.LockType = adLockPessimistic
770               rstDETPeriodSpecies.Open
                  
780               For stat = 1 To conMaxStat
790                   If StatValue(stat) = 1 Then
800                       rstDETPeriodSpecies(StatName(stat)) = 1
810                   End If
820               Next stat
830               rstDETPeriodSpecies.Update
840               rstDETPeriodSpecies.Close
850               Set rstDETPeriodSpecies = Nothing

860           End If
870       Next
880       rstSpecies.MoveNext
890   Loop
900   rstSpecies.Close

      'DD Error Handler Start
Exit_label:
910        Exit Sub
Err_label:
920        Select Case Err.Number
           Case Else
930       Call LogError("basDETReports", "ProcessSubspecies")
940        End Select
950        Resume Exit_label
      'DD Error Handler End

End Sub
