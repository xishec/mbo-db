'---------------------------------------------------------------------------------------
' Module    : basDETGeneralExport
' Author    : David Davey
'---------------------------------------------------------------------------------------

Option Compare Database
Option Explicit

'---------------------------------------------------------------------------------------
' DETGeneralExport
'
' strExport = "DET General Export"
'                                               mothballed: "Barbara Frei Census Export"  (not updated for Hummongbird Effort)
'---------------------------------------------------------------------------------------
 
Public Sub DETGeneralExport(ByVal strExport As String)

Dim oExcel As Excel.Application
Dim oBook As Excel.Workbook
Dim strSQL As String
Dim strSaveFilename As String

10    On Error GoTo Err_label

' ZAP tblDETGeneralExportSpecies

20    strSQL = "DELETE * FROM tblDETGeneralExportSpecies"
30    CurrentDb.Execute strSQL

' Fill in tblDETGeneralExportSpecies

40    CurrentDb.Execute "qryDETGeneralExportSpecies"

Dim col As Long

50    col = 0
60    strSQL = "SELECT * FROM tblDETGeneralExportSpecies"
      Dim rstSpecies As DAO.Recordset
70    Set rstSpecies = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)
80    Do While Not rstSpecies.EOF
90        rstSpecies.Edit
100       rstSpecies("col") = col
110       col = col + 1
120       rstSpecies.Update
130       rstSpecies.MoveNext
140   Loop
150   rstSpecies.Close

160   Set oExcel = New Excel.Application
170   oExcel.Caption = "MBO-Temp"

180   Set oBook = oExcel.Workbooks.Add

190   Select Case strExport
      Case "DET General Export"
200       Call DETGeneralExportDailyXSpecies(oExcel, oBook)
'210   Case "Barbara Frei Census Export"
'220       Call DETGeneralExportSheet(oExcel, oBook, "Cns")
'230       Call BarbaraFreiCensusSummary(oExcel, oBook)
'240       oExcel.Worksheets("Cns").Activate
210   End Select

' Delete the blank worksheets

220   Call ExcelDeleteAllButFirstWorksheet(oBook)
240   oBook.Worksheets(1).Delete

' Get the folder and construct the filename

Dim strFolder As String
250   strFolder = GetExportFolder()

Dim strInitialSaveFilename As String

Dim strFilenamePrefix As String
260   Select Case strExport
      Case "DET General Export"
270     strFilenamePrefix = "DET General Report"
280   Case "Barbara Frei Census Export"
290     strFilenamePrefix = "Barbara Frei Census Report"
300   End Select

  Dim strSaveFilepath As String
      Dim fValid As Boolean
310   fValid = True
320   Call SaveAndCloseExcelWorkbook(oExcel, oBook, strFilenamePrefix, fValid, strSaveFilepath)


' oBook.SaveAs strSaveFilename, FileFormat:=52 ' xslm


330   Set oBook = Nothing
340   oExcel.Quit
350   Set oExcel = Nothing

360   Call OpenExcelWorkbook(strSaveFilepath)


'DD Error Handler Start
Exit_label:
370        Exit Sub
Err_label:
380        Select Case Err.Number
     Case Else
390       Call LogError("basDETGeneralExport", "DETGeneralExport")
400        End Select
410        Resume Exit_label
'DD Error Handler End

End Sub
 


'---------------------------------------------------------------------------------------
' DETGeneralExportDailyXSpecies
'---------------------------------------------------------------------------------------
 
Private Sub DETGeneralExportDailyXSpecies( _
    oExcel As Excel.Application, _
    oBook As Excel.Workbook)

      Dim colLocation As Integer
      Dim colDateEx As Integer
      Dim colProgram As Integer
      Dim colProgramYear As Integer
      Dim colSeason As Integer
      Dim colPeriod As Integer
      Dim colObservers As Integer
      Dim colSongbirdNets As Integer
      Dim colOtherTrap As Integer
      Dim colCoverageCode As Integer
      Dim colSpecies As Integer
      Dim colObserved As Integer
      Dim colCensus As Integer
      Dim colBanded As Integer
      Dim colRepeats As Integer
      Dim colReturns As Integer
      Dim colDET As Integer

10    On Error GoTo Err_label

20    colLocation = 1
30    colDateEx = 2
40    colProgram = 3
50    colProgramYear = 4
60    colSeason = 5
70    colPeriod = 6
80    colObservers = 7
90    colSongbirdNets = 8
100   colOtherTrap = 9        ' Hummingbird hours
110   colCoverageCode = 10
120   colSpecies = 11
130   colObserved = 12
140   colCensus = 13
150   colBanded = 14
160   colRepeats = 15
170   colReturns = 16
180   colDET = 17

      Dim oSheet As Excel.Worksheet
190   Set oSheet = oBook.Worksheets.Add(After:=oBook.Worksheets(oBook.Worksheets.count))
200   oSheet.Name = "Daily x Species"

      Dim rst As DAO.Recordset
210   Set rst = CurrentDb.OpenRecordset("qryDETGeneralExportDailyXSpecies", dbOpenDynaset)

220   rst.MoveLast 'Needed to get the accurate number of records

      'Show the progress bar
230   SysCmd acSysCmdInitMeter, "Exporting ...", rst.RecordCount

240   rst.MoveFirst

      Dim row As Long
250   row = 2

260   With oSheet
270       Do While Not rst.EOF
              Dim strLocation As String
              Dim datDateEx As Date
              Dim strProgram As String
              Dim intProgramYear As Integer
              Dim strSeason As String
              Dim intPeriod As Integer
              Dim dblObservers As Double
              Dim dblSongbirdnets As Double
              Dim dblOtherTrap As Double
              Dim dblCoverageCode As Double
              Dim strSpecies As String
              Dim intObserved As Integer
              Dim intCensus As Integer
              Dim intBanded As Integer
              Dim intRepeats As Integer
              Dim intReturns As Integer
              Dim intDET As Integer

      '        Dim intYear As Integer
              
280           strLocation = Nz(rst("Location"), "")
290           datDateEx = Nz(rst("DateEx"), 0)
300           strProgram = Nz(rst("Program"), "")
310           intProgramYear = Nz(rst("ProgramYear"))
320           strSeason = Nz(rst("Season"))
330           intPeriod = Nz(rst("Period"))
340           dblObservers = Nz(rst("Observers"), 0)
350           dblSongbirdnets = Nz(rst("SongBirdNets"), 0)
360           dblOtherTrap = Nz(rst("OtherTrap"), 0)
370           dblCoverageCode = Nz(rst("CoverageCode"), 0)
380           strSpecies = Nz(rst("Species"), "")
390           intObserved = Nz(rst("Observed"), 0)
400           intCensus = Nz(rst("Census"), 0)
410           intBanded = Nz(rst("Banded"), 0)
420           intRepeats = Nz(rst("Repeats"), 0)
430           intReturns = Nz(rst("Returns"), 0)
440           intDET = Nz(rst("DET"), 0)
              
450           .Cells(row, colLocation) = strLocation
460           .Cells(row, colDateEx) = datDateEx
470           .Cells(row, colProgram) = strProgram
480           If intProgramYear <> 0 Then
490               .Cells(row, colProgramYear) = Format(intProgramYear, "0000")
500           End If
510           .Cells(row, colSeason) = strSeason
520           If intPeriod > 0 Then
530               .Cells(row, colPeriod) = intPeriod
540           End If
550           .Cells(row, colObservers) = dblObservers
560           .Cells(row, colSongbirdNets) = dblSongbirdnets
570           .Cells(row, colOtherTrap) = dblOtherTrap
580           .Cells(row, colCoverageCode) = dblCoverageCode
590           .Cells(row, colSpecies) = strSpecies
600           .Cells(row, colObserved) = intObserved
610           .Cells(row, colCensus) = intCensus
620           .Cells(row, colBanded) = intBanded
630           .Cells(row, colRepeats) = intRepeats
640           .Cells(row, colReturns) = intReturns
650           .Cells(row, colDET) = intDET
              
660           row = row + 1
      '640                    If row = 100 Then Exit Do

             ' Update the progress bar every 1000 records

670           If CLng(row / 1000) * 1000 = row Then
680               SysCmd acSysCmdUpdateMeter, row
690               DoEvents
700           End If

710           rst.MoveNext
720       Loop
730       rst.Close

740       .columns("B:B").NumberFormat = "dd-mmm-yy"
750       .columns("F:J").HorizontalAlignment = xlCenter
760       .columns("L:Q").HorizontalAlignment = xlCenter
770       .columns("A:Q").EntireColumn.AutoFit
780       .columns("F:F").ColumnWidth = 3.3

          ' Fill in header
          
790       .Cells(1, colLocation) = "Location"
800       .Cells(1, colProgram) = "Monitoring Program"
810       .Cells(1, colDateEx) = "Date"
820       .Cells(1, colProgramYear) = "Program Year"
830       .Cells(1, colSeason) = "Season"
840       .Cells(1, colPeriod) = "Period"
850       .Cells(1, colObservers) = "Observer Hours"
860       .Cells(1, colSongbirdNets) = "Net Hours"
870       .Cells(1, colOtherTrap) = "Hummingbird Hours"
880       .Cells(1, colCoverageCode) = "Coverage Code"
890       .Cells(1, colSpecies) = "Species"
900       .Cells(1, colObserved) = "Observed"
910       .Cells(1, colCensus) = "Census"
920       .Cells(1, colBanded) = "Banded"
930       .Cells(1, colRepeats) = "Repeats"
940       .Cells(1, colReturns) = "Retruns"
950       .Cells(1, colDET) = "DET"

960       .range(.Cells(1, 1), .Cells(1, 17)).Orientation = 90
970       .range(.Cells(1, 1), .Cells(1, 17)).HorizontalAlignment = xlCenter
          
          'Remove the progress bar
980       SysCmd acSysCmdRemoveMeter

      ' Freeze the top row

990   .range("A2").Select
1000  oExcel.ActiveWindow.FreezePanes = True

1010  End With

1020  Set oSheet = Nothing

      'DD Error Handler Start
Exit_label:
1030       Exit Sub
Err_label:
1040       Select Case Err.Number
           Case Else
1050      Call LogError("basDETGeneralExport", "DETGeneralExportDailyXSpecies")
1060       End Select
1070       Resume Exit_label
      'DD Error Handler End

End Sub
