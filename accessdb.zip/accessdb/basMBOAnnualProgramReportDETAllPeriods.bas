Option Compare Database
Option Explicit

Const conSpring  As Integer = 1
Const conFall    As Integer = 3

'---------------------------------------------------------------------------------------
' MBOAnnualProgramReportDETAllPeriods
'---------------------------------------------------------------------------------------
' Spring and Fall only
' Excel only report

Public Sub MBOAnnualProgramReportDETAllPeriods(ByVal intYear As Integer, ByVal strLocation As String, ByVal strSeason As String, ByRef oExcel As Excel.Application, ByRef oBook As Excel.Workbook)

      ' oExcel.Visible = True

      Dim intYearFirst As Integer

10       On Error GoTo Err_label

20    intYearFirst = 2005

30    If intYear <= intYearFirst Then GoTo Exit_label

      Dim intSeason As Integer

40    Select Case strSeason
      Case "Spring"
50        intSeason = conSpring
60    Case "Fall"
70        intSeason = conFall
80    Case Else
90        GoTo Exit_label
100   End Select

      ' Create an Excel Worksheet

      Dim oSheet As Excel.Worksheet
110   Set oSheet = InsertSheet(oBook, strSeason)
120   oSheet.Name = strSeason & " DET All Periods"

      ' tblMBOAnnualProgramReportDETAllPeriods
      ' --------------------------------------
      ' CountPeriods
      ' YearEx
      ' AOUOrder
      ' SpeciesEnglish

      ' ZAP tblMBOAnnualProgramReportDETAllPeriods

130   CurrentDb.Execute "DELETE * FROM tblMBOAnnualProgramReportDETAllPeriods"

      ' qryMBOAnnualProgramReport_DETAllPeriods_A
      ' ---------------------------------------------------------------------------
      ' For a given location, season, year - list the DET for each species x period
      ' ---------------------------------------------------------------------------
      ' tblDETSpecies x tblPrograms
      ' GROUP BY Period: toPeriod([MonitoringProgramSeason],[DateEx],[DateFrom])
      ' SUM DET
      ' GROUP BY Species
      ' GROUP BY YearEx = [argYear]
      ' WHERE Location = [argLocation]
      ' WHERE MonitoringProgramSeason = [argSeason]
      ' Report Period, DET, Species, YearEx

      ' Append records for each year

      Dim Y As Integer
140   For Y = intYearFirst To intYear

          ' qryMBOAnnualProgramReport_DETAllPeriods_C    (Append Table tblMBOAnnualProgramReportDETAllPeriods)
          ' -----------------------------------------------------------------------------------------------------------------------------------------------
          ' For a given location, season, year - list the Species, SpeciesEnglish, AOUOrder for species that were DETed in all periods of the season x year
          ' -----------------------------------------------------------------------------------------------------------------------------------------------
          ' qryMBOProgramReportDETAllPeriods_A x tblSpecies
          ' CountPeriods: Sum(IIf([DET]>0,1,0))    WHERE [argNumberOfPeriods]
          ' GROUP BY Species
          ' GROUP BY YearEx
          ' GROUP BY AOUOrder
          ' GROUP BY SpeciesEnglish
          ' Report CountPeriods, YearEx, AOUOrder, SpeciesEnglish
          
          Dim qdf As QueryDef
150       Set qdf = CurrentDb.QueryDefs("qryMBOAnnualProgramReport_DETAllPeriods_C")
160       qdf.Parameters("argYear").value = Y
170       qdf.Parameters("argSeason").value = strSeason
180       qdf.Parameters("argLocation").value = strLocation
190       qdf.Parameters("argNumberOFPeriods").value = intPeriodLast_SeasonYear(intSeason, Y)
200       qdf.Execute

210   Next

      Dim colSpecies As Integer
      Dim colSpeciesEnglish As Integer
      Dim colYear_First As Integer
      Dim colYearLast As Integer

220   colSpecies = 1
230   colSpeciesEnglish = 2
240   colYear_First = 3


      Dim strSpecies As String
      Dim strSpeciesEnglish As String

      Dim col As Long
      Dim row As Long

250   row = 3

260   With oSheet

270   .Cells(row, colSpecies) = "Species"
280   For Y = intYearFirst To intYear
290       .Cells(row, colYear_First + Y - intYearFirst) = Y
300   Next

310   row = row + 1

      ' qryMBOAnnualProgramReportDETAllPeriods_D_Crosstab
      ' -------------------------------------------------
      ' tblMBOAnnualProgramReportDETAllPeriods
      ' ROW HEADING - GROUP BY AOUOrder, Species, SpeciesEnglish
      ' COLUMN HEADING - GROUP BY YearEx
      ' SUM CountPeriods

      Dim intNumberOfPeriods As Integer

      Dim rst As DAO.Recordset
320   Set rst = CurrentDb.OpenRecordset("qryMBOAnnualProgramReportDETAllPeriods_D_Crosstab")
330   Do While Not rst.EOF

340       strSpecies = Nz(rst("Species"))
350       strSpeciesEnglish = Nz(rst("SpeciesEnglish"))
          
360       .Cells(row, colSpecies) = strSpecies
370       .Cells(row, colSpeciesEnglish) = strSpeciesEnglish

380       On Error Resume Next
390       For Y = intYearFirst To intYear
400           intNumberOfPeriods = Nz(rst(CStr(Y)))
410           If intNumberOfPeriods > 0 Then
420               .Cells(row, colYear_First + Y - intYearFirst) = intNumberOfPeriods
430           End If
440       Next
450       Err.Clear
460       On Error GoTo Err_label
          
470       .Cells(row, colSpecies) = strSpecies
480       .Cells(row, colSpeciesEnglish) = strSpeciesEnglish

490       row = row + 1
500       rst.MoveNext
510   Loop
520   rst.Close
530   Set rst = Nothing

540   .range(.columns(1), .columns(colYear_First + intYear - intYearFirst)).AutoFit

550   .Cells(1, 1) = "Species observed (DET) in all periods.  The number of periods is listed (should be 10 for Spring, 13 or 14 for Fall)"

560   End With


          'DD Error Handler Start
Exit_label:
570       Exit Sub
Err_label:
580       Select Case Err.Number
          Case Else
590      Call LogError("basMBOAnnualProgramReportDETAllPeriods", "MBOAnnualProgramReportDETAllPeriods")
600       End Select
610       Resume Exit_label
          ' DD Error Handler End

End Sub
