'---------------------------------------------------------------------------------------
' Module: basMBOProgramReport_MeanGraphs
' Author: David Davey
'---------------------------------------------------------------------------------------
'
' ================================================================================================================
' No longer used.  I use basMBOAnnualProgramReport7DayMeanGraph and basMBO10YearProgtamReport3DayMeanGraph instead
' ================================================================================================================



Option Explicit
Option Compare Database

' Statistics

Const conDET As Integer = 0
Const conBND As Integer = 1
Const conRET As Integer = 2
Const conREP As Integer = 3
Const conCNS As Integer = 4

' ====================================================================================================================================
' The following instance variables are reinitialised for each chart: "Banded Birds", "Banded Species", "Census Species", "DET Species"
' ====================================================================================================================================

' A standardized date is a date in which the year has ben replaced by 2000.

Private intYearFirst As Integer     ' First report year (2005)
Private intYearLast As Integer      ' Last/current report year
Private strLocation As String       ' MBO
Private strSeason As String         ' "Spring" or "Fall"
Private oExcel As Excel.Application
Private oBook As Excel.Workbook
Private strChart As String          ' "Banded Birds", "Banded Species", "Census Species", "DET Species"
Private fDebug As Boolean
Private intNumberOfDaysInMean       ' 3 (5x-year report) or 7 (annual reports)

Private dblStat() As Double

' ---------
' The following tables are filled in by FirstLastDays()

Private datDateYearLast() As Date   ' The date in the current report year that corresponds to a standardised date

Private datDayFirstTable() As Date  ' intFirstYear .. intLastYear+1   datDayFirstTable(year) is the standardised eariest date that the chart's stat > 0
                                    '                                                        is 2001-01-01 if stat was never > 0 for the season x year
                                    '                                 datDayFirstTable(intLastYear+1) is the min from datDayFirstTable(intFirstYear .. intLastYear)

Private datDayLastTable() As Date   ' intFirstYear .. intLastYear+1   datDayLastTable(year) is the standardised latest date that the chart's stat > 0
                                    '                                                       is 1999-12-31 if stat was never > 0 for the season x year
                                    '                                 datDayFirstTable(intLastYear+1) is the max from datDayFirstTable(intFirstYear .. intLastYear)

Private datDayFirst As Date         ' Same as datDayFirstTable(intLastYear+1)             I use both, so I must ensure they are equal
Private datDayLast As Date          ' Same as datDayFirstTable(intLastYear+1)

Private datDayFirstANY As Date  ' the first standardised date for ANY data (DET, Observed, Census, Banded, Alien, Replacement, DET)  in the season
Private datDayLastANY As Date   ' the last standardised date for ANY data (DET, Observed, Census, Banded, Alien, Replacement, DET) in the season

' --------

Private colDate As Long
Private colPeriod As Long
Private colYearFirst As Long
Private colYearLast As Long
Private colYearAverage As Long
Private colMeanYearFirst As Long
Private colMeanYearLast As Long
Private colMeanYearAverage As Long
Private colDateYearLast As Long ' A column for the dates for the last year.  The column is used by the current year graph.  The column is hidden
Private colChart As Long        ' Starting column for charts

'---------------------------------------------------------------------------------------
' MBOProgramReportMeanGraph
'---------------------------------------------------------------------------------------
' 3-day means (Multiple year reports) or 7-day means (Annual reports)

Public Sub MBOProgramReportMeanGraph( _
    ByVal argYearFirst As Integer, _
    ByVal argYearLast As Integer, _
    ByVal argLocation As String, _
    ByVal argSeason As String, _
    ByRef arg_excel As Excel.Application, _
    ByRef arg_book As Excel.Workbook, _
    ByVal arg_chart As String, _
    ByVal arg_debug As Boolean, _
    ByVal arg_NumberOfDaysInMean As Integer)

' Save parameters

On Error GoTo Err_label

intYearFirst = argYearFirst
intYearLast = argYearLast
strLocation = argLocation
strSeason = argSeason
Set oExcel = arg_excel
Set oBook = arg_book
strChart = arg_chart
fDebug = arg_debug
intNumberOfDaysInMean = arg_NumberOfDaysInMean

colDate = 1
colPeriod = colDate + 1
colYearFirst = colPeriod + 1
colYearLast = colYearFirst + (intYearLast - intYearFirst)
colYearAverage = colYearLast + 1
colMeanYearFirst = colYearAverage + 1
colMeanYearLast = colMeanYearFirst + (intYearLast - intYearFirst)
colMeanYearAverage = colMeanYearLast + 1
colDateYearLast = colMeanYearAverage + 1
colChart = colDateYearLast + 2

Dim qdf As QueryDef
Dim rst As DAO.Recordset

' For a given season ("Spring" or "Fall", calculates the earliest and latest dates (standardised to the year 2000) when DET+Observed+Census+Banded+Repeats+Returns+Alien+Replacement > 0

' qryMBO10YearProgramReport3DayMeanGraph_ANYMinMaxDays
' ----------------------------------------------------
' tblDETSpecies x tblPrograms
'
' Totals Query
'
' WHERE YearEx between the first and last years inclusive
' WHERE Location = [argLocation]
' WHERE DET > 0 OR Observed > 0 OR Census > 0 OR Banded > 0 OR Repeats > 0 or Returns > 0 OR Observed3 (Alien) > 0 OR Observed4 (Replacement) > 0
' DateFirst = MIN DateSerial(2000,Month([DateEX]),Day([DateEx])
' DateLast = MAX DateSerial(2000,Month([DateEX]),Day([DateEx])
'
' The result is a single record.
' I have assumed that there is at one stat recorded for the season, over all years ...

Set qdf = CurrentDb.QueryDefs("qryMBO10YearProgramReport3DayMeanGraph_ANYMinMaxDays")
qdf.Parameters("argSeason").value = strSeason
qdf.Parameters("argLocation").value = strLocation
qdf.Parameters("argYearFirst").value = intYearFirst
qdf.Parameters("argYearLast").value = intYearLast

Set rst = qdf.OpenRecordset

datDayFirstANY = Nz(rst("DayFirst"))
datDayLastANY = Nz(rst("DayLast"))
rst.Close
Set rst = Nothing

Call FirstLastDays(strChart)

' Initialise statistics

ReDim dblStat(datDayFirst To datDayLast, intYearFirst To intYearLast)

Dim D As Date
Dim Y As Integer
For D = datDayFirst To datDayLast
    For Y = intYearFirst To intYearLast
        dblStat(D, Y) = 0
    Next
Next

Select Case strChart
Case "Banded Birds"
    Call BandedBirds
Case "Banded Species"
    Call Species(conBND)
Case "Census Species"
    Call Species(conCNS)
Case "DET Species"
    Call Species(conDET)
End Select

    'DD Error Handler Start
Exit_label:
    Exit Sub
Err_label:
    Select Case Err.Number
    Case Else
   Call LogError("basMBOProgramReport_MeanGraphs", "MBOProgramReportMeanGraph")
    End Select
    Resume Exit_label
    ' DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' Species
'---------------------------------------------------------------------------------------

Private Sub Species(ByVal intFld As Integer)

      Dim qdf As QueryDef
      Dim rst As DAO.Recordset
      Dim strSQL As String

20    On Error GoTo Err_label

      Dim Y As Integer

      ' ********** Just the first 10 days during debugging *******************

30    If fDebug Then
40        datDayLast = datDayFirst + 10
50        For Y = intYearFirst To intYearLast
60      datDayLastTable(Y) = datDayFirst + 10
70        Next
80    End If

90    ReDim dblStat(datDayFirst To datDayLast, intYearFirst To intYearLast)

      Dim D As Long

100   For D = datDayFirst To datDayLast
110       For Y = intYearFirst To intYearLast
120     dblStat(D, Y) = 0
130       Next
140   Next

      ' Calculate the number of true species for each day x year

      Dim dicSpecies As Scripting.Dictionary
150   Set dicSpecies = New Scripting.Dictionary
      Dim strSpecies As String

160   For Y = intYearFirst To intYearLast
170       For D = datDayFirstTable(Y) To datDayLastTable(Y)

180     strSQL = toQueryname_FLDSpecies_FromFLD(intFld)
190     Set qdf = CurrentDb.QueryDefs(strSQL)
200     qdf.Parameters("argSeason").value = strSeason
210     qdf.Parameters("argLocation").value = strLocation
220     qdf.Parameters("argDateEx").value = DateSerial(Y, Month(D), Day(D))

230     Set rst = qdf.OpenRecordset

        ' Skip if the stat was not measured

240     If Not rst.EOF Then
250         Do While Not rst.EOF
260             strSpecies = Nz(rst("Species"))

                ' Add the species + superspecies to the dictionary

270             If Not dicSpecies.Exists(strSpecies) Then
280                 Call dicSpecies.Add(strSpecies, strSpecies)
290             End If
300             rst.MoveNext
310         Loop
320         rst.Close
330         Set rst = Nothing

            ' How many true species are in the dictionary ?

340         dblStat(D, Y) = CountSpeciesInDictionary(dicSpecies)

            ' Empty the dictionary

350         Call dicSpecies.RemoveAll
360     End If
370       Next D
380   Next Y

      Dim oSheet As Excel.Worksheet
390   Set oSheet = InsertSheet(oBook, strSeason)

      Dim strName As String
400   strName = strSeason & toSheetname_FromFLD(intFld)

410   oSheet.Name = strName
420   With oSheet

      ' Output to Excel

430   For D = datDayFirst To datDayLast
440       .Cells(toRowFromDay(D), 1) = D
450   Next

460   For Y = intYearFirst To intYearLast
470       .Cells(1, toColFromYear(Y)) = Y
480   Next

490   Call FillInPeriods(oSheet)

500   .Cells(1, toColFromYear(intYearLast) + 1) = "Average"

510   For Y = intYearFirst To intYearLast
520       For D = datDayFirstTable(Y) To datDayLastTable(Y)
530           If dblStat(D, Y) > 0 Then
540               .Cells(toRowFromDay(D), toColFromYear(Y)) = dblStat(D, Y)
550           End If
560       Next
570   Next

      ' Insert zeros for Capture Days with no captures - For Banded Species only

580   If intFld = conBND Then

      ' qryMBOProgramReport_MeanGraphs_A
      ' --------------------------------
      ' For a given season, list the days with 0 captures
      ' -------------------------------------------------
      ' tblDETSpecies x tblPrograms
      ' WHERE Location = [argLocation]
      ' WHERE MonitoringProgramSeason = [argSeason]
      ' GROUP BY YearEx
      ' HAVING Captures: Sum(Nz([Banded])+Nz([Returns])+Nz([Repeats])+Nz([Observed3])+Nz([Observed4])) > 0
      ' GROUP BY DateEx
      ' GROUP BY Program
      ' Report YearEx, DateEx, Program

      ' qryMBOProgramReport_MeanGraphs_B
      ' --------------------------------
      ' For a given season, list the Capture days with no captures
      ' ----------------------------------------------------------
      ' qryMBOProgramReport_MeanGraphs_A x tblDETDaily
      ' YearEx
      ' DateEx
      ' WHERE SongbirdNets > 0
      ' Report YearEx, DateEx

      Dim datDateEx As Date

      ' Dim qdf As QueryDef
590   Set qdf = CurrentDb.QueryDefs("qryMBOProgramReport_MeanGraphs_B")
600   qdf.Parameters("argSeason").value = strSeason
610   qdf.Parameters("argLocation").value = strLocation

      'Dim rst As DAO.Recordset
620   Set rst = qdf.OpenRecordset
630   Do While Not rst.EOF

640       datDateEx = Nz(rst("DateEx"))
650       Y = Nz(rst("YearEx"))

660       D = DateSerial(2000, Month(datDateEx), Day(datDateEx))
670       .Cells(toRowFromDay(D), toColFromYear(Y)) = 0

680       rst.MoveNext
690   Loop
700   rst.Close
710   Set rst = Nothing

720   End If

      ' Fill in the column - average over all years

730   Call AverageOverAllYears(oSheet)

740   .range(.Cells(toRowFromDay(datDayFirst), toColFromYear(intYearLast + 1)), .Cells(toRowFromDay(datDayLast), toColFromYear(intYearLast + 1))).NumberFormat = "#0.0;-#0.0;0"

750   .range(.Cells(1, 2), .Cells(2 + datDayLast - datDayFirst, 2 + intYearLast - intYearFirst)).NumberFormat = "#0;-#0;0"
760   .range(.Cells(2, 2 + datDayLast - datDayFirst + 1), .Cells(2 + datDayLast - datDayFirst, 2 + datDayLast - datDayFirst + 1)).NumberFormat = "#0.0;-#0.0;0"
770   .range(.Cells(2, 1), .Cells(2 + datDayLast - datDayFirst, 1)).NumberFormat = "[$-1009]dd-mmm"

      ' Calculate the means

780   Call Means(oSheet)

      ' Calculate maximums and minimums for each year
      ' Highlight maximum and minimum values

790   Call MinMax(oSheet)

800   oSheet.range(.columns(1), .columns(toColMeanFromYear(intYearLast) + 1)).AutoFit

810   .Cells(2, 2) = "7-day running averages"
820   .Cells(3, 2) = "The Average nr. species is calculated over all previous years. It excludes the current year."
830   .Cells(4, 2) = "The 7-day Average is the 7-day running average over the Average column"

      ' Generate a multi-year chart

      Dim strXAxisTitle As String
840   Select Case strChart
      Case "Banded Species"
850           strXAxisTitle = "# species banded daily"
860   Case "Census Species"
870           strXAxisTitle = "# species observed daily on census"
880   Case "DET Species"
890           strXAxisTitle = "# species observed daily"
900   End Select

910   Call MultiYearChart(oSheet, strXAxisTitle:=strXAxisTitle)

      '  Generate a chart for the current year

920   Call CurrentYearChart(oSheet, intFld)

930   .range("B2").Select
940   oBook.Application.ActiveWindow.FreezePanes = True


950   End With ' oSheet

960   Set oSheet = Nothing

    'DD Error Handler Start
Exit_label:
970       Exit Sub
Err_label:
980       Select Case Err.Number
    Case Else
990      Call LogError("basMBOProgramReport_MeanGraphs", "Species")
1000      End Select
1010      Resume Exit_label
    ' DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' BirdsBanded
'---------------------------------------------------------------------------------------

Private Sub BandedBirds()

On Error GoTo Err_label

Dim qdf As QueryDef
Dim rst As DAO.Recordset
Dim datDate As Date
Dim datDay As Date
Dim intYear As Integer
Dim D As Date
Dim Y As Integer
Dim oSheet As Excel.Worksheet

Set oSheet = InsertSheet(oBook, strSeason)
oSheet.Name = strSeason & " Banded Birds"
With oSheet

' Birds Banded

' Fill in dblStat(day, year) with the number of birds banded on a standardized day x year

' qryMBO10YearProgramReport3DayMeanGraph_BandedBirds
' --------------------------------------------------
' tblDETSpecies x tblPrograms
'
' WHERE Location = [argLocation]          MBO
' WHERE Season = [argSeason]              Spring or Fall
' WHERE Banded > 0
' WHERE YearEx BETWEEN first year and ast year
' GROUP BY YearEx, DateEx
' CountBandedBirds = SUM Banded           we are summing over species
'
' Report YearEx, DateEx, CountBandedBirds
' There is a record for every day in each year of the season, for which banding of any species > 0


Set qdf = CurrentDb.QueryDefs("qryMBO10YearProgramReport3DayMeanGraph_BandedBirds")
qdf.Parameters("argSeason").value = strSeason
qdf.Parameters("argLocation").value = strLocation
qdf.Parameters("argYearFirst").value = intYearFirst
qdf.Parameters("argYearLast").value = intYearLast

Set rst = qdf.OpenRecordset

Dim CountBandedBirds As Integer

Do While Not rst.EOF
    intYear = Nz(rst("YearEx"))
    CountBandedBirds = Nz(rst("CountBandedBirds"))
    datDate = Nz(rst("DateEx"))
    datDay = DateSerial(2000, Month(datDate), Day(datDate))
    dblStat(datDay, intYear) = CountBandedBirds
    rst.MoveNext
Loop
rst.Close
Set rst = Nothing

' Calculate the averages over the years

' Output to Excel


For D = datDayFirst To datDayLast
    .Cells(toRowFromDay(D), colDate) = D
Next

For Y = intYearFirst To intYearLast
    .Cells(1, toColFromYear(Y)) = Y
Next

Call FillInPeriods(oSheet)


' Insert zeros for Capture Days with no captures

' qryMBOProgramReport_MeanGraphs_A
' --------------------------------
' For a given season, list the days with 0 captures
' -------------------------------------------------
' tblDETSpecies x tblPrograms
' WHERE Location = [argLocation]
' WHERE MonitoringProgramSeason = [argSeason]
' GROUP BY YearEx
' HAVING Captures: Sum(Nz([Banded])+Nz([Returns])+Nz([Repeats])+Nz([Observed3])+Nz([Observed4])) > 0
' GROUP BY DateEx
' GROUP BY Program
' Report YearEx, DateEx, Program

' qryMBOProgramReport_MeanGraphs_B
' --------------------------------
' For a given season, list the Capture days with no captures
' ----------------------------------------------------------
' qryMBOProgramReport_MeanGraphs_A x tblDETDaily
' YearEx
' DateEx
' WHERE SongbirdNets > 0
' Report YearEx, DateEx

Dim datDateEx As Date

' Dim qdf As QueryDef
Set qdf = CurrentDb.QueryDefs("qryMBOProgramReport_MeanGraphs_B")
qdf.Parameters("argSeason").value = strSeason
qdf.Parameters("argLocation").value = strLocation

'Dim rst As DAO.Recordset
Set rst = qdf.OpenRecordset
Do While Not rst.EOF

    datDateEx = Nz(rst("DateEx"))
    Y = Nz(rst("YearEx"))

    D = DateSerial(2000, Month(datDateEx), Day(datDateEx))
    .Cells(toRowFromDay(D), toColFromYear(Y)) = 0

    rst.MoveNext
Loop
rst.Close
Set rst = Nothing

For Y = intYearFirst To intYearLast
    If datDayFirstTable(Y) <> 0 And datDayLastTable(Y) <> 0 Then
        For D = datDayFirstTable(Y) To datDayLastTable(Y)
            If dblStat(D, Y) > 0 Then
              .Cells(toRowFromDay(D), toColFromYear(Y)) = dblStat(D, Y)
            End If
        Next
    End If
Next

.Cells(1, colYearAverage) = "Average"

' Fill in the column - average over all years

Call AverageOverAllYears(oSheet)


' the data is in rows toRowFromDay(datDayFirst) to toRowFromDay(datDayLast)
' colData is formatted  "[$-1009]d-mmm"
' colPeriod is not used
' colYearFirst to colYearLast are formatted "#0;-#0;0"
' colYearAverage, colMeanYearFirst to colMeanYearLast, colMeanYearAverage are formatted "#0.0;-#0.0;0"

.range(.Cells(toRowFromDay(datDayFirst), colDate), .Cells(toRowFromDay(datDayLast), colDate)).NumberFormat = "[$-1009]d-mmm"
.range(.Cells(toRowFromDay(datDayFirst), colYearFirst), .Cells(toRowFromDay(datDayLast), colYearLast)).NumberFormat = "#0;-#0;0"
.range(.Cells(toRowFromDay(datDayFirst), colYearAverage), .Cells(toRowFromDay(datDayLast), colYearAverage)).NumberFormat = "#0.0;-#0.0;0"
.range(.Cells(toRowFromDay(datDayFirst), colMeanYearFirst), .Cells(toRowFromDay(datDayLast), colMeanYearLast)).NumberFormat = "#0.0;-#0.0;0"
.range(.Cells(toRowFromDay(datDayFirst), colMeanYearAverage), .Cells(toRowFromDay(datDayLast), colMeanYearAverage)).NumberFormat = "#0.0;-#0.0;"


' Calculate the means
Select Case strSeason
Case "Spring", "Fall", "Owling"
  Call Means(oSheet)
End Select

' Calculate maximums and minimums for each year
' Highlight maximum and minimum values

Call MinMax(oSheet)

oSheet.range(.columns(1), .columns(toColMeanFromYear(intYearLast) + 1)).AutoFit

.Cells(2, 2) = "7-day running averages"
.Cells(3, 2) = "The Average nr. birds is calculated over all previous years. It excludes the current year."
.Cells(4, 2) = "The 7-day Average is the 7-day running average over the Average column"

' Generate a multi-year chart

Select Case strSeason
Case "Spring", "Fall"
    Call MultiYearChart(oSheet, strXAxisTitle:="# of individuals banded daily")
End Select

' Generate a chart for the current year

Select Case strSeason
Case "Spring", "Fall"
    Call CurrentYearChart(oSheet, conBND)
End Select

.range("C2").Select
oBook.Application.ActiveWindow.FreezePanes = True

End With ' oSheet

Set oSheet = Nothing

    'DD Error Handler Start
Exit_label:
    Exit Sub
Err_label:
    Select Case Err.Number
    Case Else
   Call LogError("basMBOProgramReport_MeanGraphs", "BandedBirds")
    End Select
    Resume Exit_label
    ' DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' FillInPeriods
'---------------------------------------------------------------------------------------
' Fill in the Periods column

Private Sub FillInPeriods(ByRef oSheet As Excel.Worksheet)

10    On Error GoTo Err_label

20    With oSheet

30        .Cells(1, colPeriod) = "Period"

          Dim row As Long
          Dim strPeriod As String
          Dim D As Date

          Dim datProgramDateFrom As Date
40        datProgramDateFrom = Nz(DLookup("[DateFrom]", "tblPrograms", "[MonitoringProgramSeason] = '" & strSeason & "' AND [YearEx] = " & intYearLast))
50        For D = datDayFirst To datDayLast
60          row = toRowFromDay(D)
70          strPeriod = Period(datProgramDateFrom, datDateYearLast(D), strSeason)
80          If strPeriod <> "" Then
90                .Cells(row, colPeriod) = strPeriod
100        End If
110       Next

120       .range(.Cells(toRowFromDay(datDayFirst), colPeriod), .Cells(toRowFromDay(datDayLast), colPeriod)).HorizontalAlignment = xlCenter

130   End With

          'DD Error Handler Start
Exit_label:
140       Exit Sub
Err_label:
150       Select Case Err.Number
          Case Else
160      Call LogError("basMBOProgramReport_MeanGraphs", "FillInPeriods")
170       End Select
180       Resume Exit_label
          ' DD Error Handler End
End Sub


'---------------------------------------------------------------------------------------
' AverageOverAllYears
'---------------------------------------------------------------------------------------
' Fill in the column - average over all years

Private Sub AverageOverAllYears(ByRef oSheet As Excel.Worksheet)

10    On Error GoTo Err_label

      Dim D As Date

20    With oSheet

30    For D = datDayFirst To datDayLast

40          .Cells(toRowFromDay(D), toColFromYear(intYearLast + 1)) = _
                  "=if(count(" & _
                  .Cells(toRowFromDay(D), toColFromYear(intYearFirst)).Address(0, 0) & _
                  ":" & _
                  .Cells(toRowFromDay(D), toColFromYear(intYearLast - 1)).Address(0, 0) & _
                  ") > 0, average(" & _
                  .Cells(toRowFromDay(D), toColFromYear(intYearFirst)).Address(0, 0) & _
                  ":" & _
                  .Cells(toRowFromDay(D), toColFromYear(intYearLast - 1)).Address(0, 0) & _
                  "),0)"

50    Next

60    End With

          'DD Error Handler Start
Exit_label:
70        Exit Sub
Err_label:
80        Select Case Err.Number
          Case Else
90       Call LogError("basMBOProgramReport_MeanGraphs", "AverageOverAllYears")
100       End Select
110       Resume Exit_label
          ' DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' Means
'---------------------------------------------------------------------------------------
' Calculate the means
'
' The annual rports use 7-day means; the 5x-year report use 3-day means

Private Sub Means(ByRef oSheet As Excel.Worksheet)

10       On Error GoTo Err_label

   Dim Y As Integer
   Dim D As Date

20    With oSheet

      Dim intOffset As Integer
30    Select Case intNumberOfDaysInMean
      Case 3
40        intOffset = 1
50    Case 7
60        intOffset = 3
70    Case Else
80        intOffset = 0
90    End Select


100   For Y = intYearFirst To intYearLast + 1
110       For D = datDayFirstTable(Y) + intOffset To datDayLastTable(Y) - intOffset

120           .Cells(toRowFromDay(D), toColMeanFromYear(Y)) = _
              "=if(count(" & _
              .Cells(toRowFromDay(D) - intOffset, toColFromYear(Y)).Address(0, 0) & _
              ":" & _
              .Cells(toRowFromDay(D) + intOffset, toColFromYear(Y)).Address(0, 0) & _
              ") > 0, average(" & _
              .Cells(toRowFromDay(D) - intOffset, toColFromYear(Y)).Address(0, 0) & _
              ":" & _
              .Cells(toRowFromDay(D) + intOffset, toColFromYear(Y)).Address(0, 0) & _
              "),0)"

130       Next D
140   Next Y

150   .range(.Cells(toRowFromDay(datDayFirst), toColMeanFromYear(intYearFirst)), .Cells(toRowFromDay(datDayLast), toColMeanFromYear(intYearLast + 1))).NumberFormat = "#0.0;-#0.0;0"

160   For Y = intYearFirst To intYearLast
170       .Cells(1, toColMeanFromYear(Y)) = Y
180   Next

190   .Cells(1, toColMeanFromYear(intYearLast + 1)) = "Average"

200   End With

    'DD Error Handler Start
Exit_label:
210       Exit Sub
Err_label:
220       Select Case Err.Number
    Case Else
230      Call LogError("basMBOProgramReport_MeanGraphs", "Means")
240       End Select
250       Resume Exit_label
    ' DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' MinMax
'---------------------------------------------------------------------------------------
      ' Calculate maximums, minimums and averages for each year
      ' Highlight maximum and minimum values

Private Sub MinMax(ByRef oSheet As Excel.Worksheet)

          Dim Y As Integer
          Dim D As Date
          Dim dblMax As Double
          Dim dblMeanMax As Double
          Dim dblMin As Double
          Dim dblMeanMin As Double
          Dim dblSum As Double
          Dim lngCount As Long
          Dim dblMeanSum As Double
          Dim lngMeanCount As Long

10    On Error GoTo Err_label

20    With oSheet

30    .Cells(toRowFromDay(datDayLast) + 1, 1) = "Max"
40    .Cells(toRowFromDay(datDayLast) + 2, 1) = "Min"
50    .Cells(toRowFromDay(datDayLast) + 3, 1) = "Mean"
60    .range(.Cells(toRowFromDay(datDayLast) + 1, 1), .Cells(toRowFromDay(datDayLast) + 3, 1)).Font.Bold = True

      ' Process the raw data and their average

70    For Y = intYearFirst To intYearLast + 1
80        dblMax = 0
90        dblMin = 9999
100       dblSum = 0
110       lngCount = 0
120       For D = datDayFirst To datDayLast
130           If Round(.Cells(toRowFromDay(D), toColFromYear(Y)), 1) > dblMax Then
140               dblMax = Round(.Cells(toRowFromDay(D), toColFromYear(Y)), 1)
150           End If
160           If .Cells(toRowFromDay(D), toColFromYear(Y)) > 0 And Round(.Cells(toRowFromDay(D), toColFromYear(Y)), 1) < dblMin Then
170               dblMin = Round(.Cells(toRowFromDay(D), toColFromYear(Y)), 1)
180           End If
190           If .Cells(toRowFromDay(D), toColFromYear(Y)) > 0 Then
200               dblSum = dblSum + .Cells(toRowFromDay(D), toColFromYear(Y))
210               lngCount = lngCount + 1
220           End If
230       Next
240       .Cells(toRowFromDay(datDayLast) + 1, toColFromYear(Y)) = dblMax
250       .Cells(toRowFromDay(datDayLast) + 2, toColFromYear(Y)) = dblMin
260       If lngCount > 0 Then
270           .Cells(toRowFromDay(datDayLast) + 3, toColFromYear(Y)) = dblSum / lngCount
280       End If
290       For D = datDayFirst To datDayLast
300           If Round(.Cells(toRowFromDay(D), toColFromYear(Y)), 1) = dblMax Then
310               .range(.Cells(toRowFromDay(D), toColFromYear(Y)), .Cells(toRowFromDay(D), toColFromYear(Y))).Interior.Color = vbYellow
320           End If
330           If Round(.Cells(toRowFromDay(D), toColFromYear(Y)), 1) = dblMin Then
340               .range(.Cells(toRowFromDay(D), toColFromYear(Y)), .Cells(toRowFromDay(D), toColFromYear(Y))).Font.Color = vbRed
350           End If
360       Next
370   Next
380   .range(.Cells(toRowFromDay(datDayLast) + 1, toColFromYear(intYearFirst)), .Cells(toRowFromDay(datDayLast) + 2, toColFromYear(intYearLast))).NumberFormat = "#0;-#0;0"
390   .range(.Cells(toRowFromDay(datDayLast) + 1, toColFromYear(intYearLast + 1)), .Cells(toRowFromDay(datDayLast) + 2, toColFromYear(intYearLast + 1))).NumberFormat = "#0.0;-#0.0;0"

400   .range(.Cells(toRowFromDay(datDayLast) + 1, toColFromYear(intYearFirst)), .Cells(toRowFromDay(datDayLast) + 1, toColFromYear(intYearLast) + 1)).Interior.Color = vbYellow
410   .range(.Cells(toRowFromDay(datDayLast) + 2, toColFromYear(intYearFirst)), .Cells(toRowFromDay(datDayLast) + 2, toColFromYear(intYearLast) + 1)).Font.Color = vbRed

      ' Process the 7-day means and their average

420   Select Case strSeason
      Case "Spring", "Fall", "Owling"

430       For Y = intYearFirst To intYearLast + 1

440           dblMeanMax = 0
450           dblMeanMin = 9999
460           dblMeanSum = 0
470           lngMeanCount = 0
480           For D = datDayFirst To datDayLast
490               If Round(.Cells(toRowFromDay(D), toColMeanFromYear(Y)), 1) > dblMeanMax Then
500                   dblMeanMax = Round(.Cells(toRowFromDay(D), toColMeanFromYear(Y)), 1)
510               End If
520               If .Cells(toRowFromDay(D), toColMeanFromYear(Y)) > 0 And Round(.Cells(toRowFromDay(D), toColMeanFromYear(Y)), 1) < dblMeanMin Then
530                   dblMeanMin = Round(.Cells(toRowFromDay(D), toColMeanFromYear(Y)), 1)
540               End If
550               If .Cells(toRowFromDay(D), toColMeanFromYear(Y)) > 0 Then
560                   dblMeanSum = dblMeanSum + .Cells(toRowFromDay(D), toColMeanFromYear(Y))
570                   lngMeanCount = lngMeanCount + 1
580               End If
590           Next

600           .Cells(toRowFromDay(datDayLast) + 1, toColMeanFromYear(Y)) = dblMeanMax
610           .Cells(toRowFromDay(datDayLast) + 2, toColMeanFromYear(Y)) = dblMeanMin

620           If lngMeanCount > 0 Then
630               .Cells(toRowFromDay(datDayLast) + 3, toColMeanFromYear(Y)) = dblMeanSum / lngMeanCount
640           End If

650           For D = datDayFirst To datDayLast

660               If Round(.Cells(toRowFromDay(D), toColMeanFromYear(Y)), 1) = Round(dblMeanMax, 1) Then
670                   .range(.Cells(toRowFromDay(D), toColMeanFromYear(Y)), .Cells(toRowFromDay(D), toColMeanFromYear(Y))).Interior.Color = vbYellow
680               End If

690               If Round(.Cells(toRowFromDay(D), toColMeanFromYear(Y)), 1) = Round(dblMeanMin, 1) Then
700                   .range(.Cells(toRowFromDay(D), toColMeanFromYear(Y)), .Cells(toRowFromDay(D), toColMeanFromYear(Y))).Font.Color = vbRed
710               End If
720           Next

730       Next

740       .range(.Cells(toRowFromDay(datDayLast) + 1, toColMeanFromYear(intYearFirst)), .Cells(toRowFromDay(datDayLast) + 2, toColMeanFromYear(intYearLast + 1))).NumberFormat = "#0.0;-#0.0;0"
750       .range(.Cells(toRowFromDay(datDayLast) + 3, toColFromYear(intYearFirst)), .Cells(toRowFromDay(datDayLast) + 3, toColMeanFromYear(intYearLast + 1))).NumberFormat = "#0.0;-#0.0;0"
760       .range(.Cells(toRowFromDay(datDayLast) + 1, toColMeanFromYear(intYearFirst)), .Cells(toRowFromDay(datDayLast) + 1, toColMeanFromYear(intYearLast) + 1)).Interior.Color = vbYellow
770       .range(.Cells(toRowFromDay(datDayLast) + 2, toColMeanFromYear(intYearFirst)), .Cells(toRowFromDay(datDayLast) + 2, toColMeanFromYear(intYearLast) + 1)).Font.Color = vbRed

780   End Select

790   End With

          'DD Error Handler Start
Exit_label:
800       Exit Sub
Err_label:
810       Select Case Err.Number
          Case Else
820      Call LogError("basMBOProgramReport_MeanGraphs", "MinMax")
830       End Select
840       Resume Exit_label
          ' DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' CurrentYearChart
'---------------------------------------------------------------------------------------
' Chart for current year
' strSeason is a module-level variable

Private Sub CurrentYearChart(ByRef oSheet As Excel.Worksheet, ByVal intFld As Integer)

      Dim lngleft As Long
      Dim lngTop As Long
      Dim oChartObject As Excel.ChartObject
      Dim oChart As Excel.Chart

      ' The columns are 1, toColFromYear(intYear), toColMeanFromYear(intYear)
      ' The rows are rowTop, rowBottom

      Dim rowTop As Long
      Dim rowBottom As Long
      Dim row As Long

10    On Error GoTo Err_label

      ' Do not create a chart if there is no FLd data for the current year

20    If datDayFirstTable(intYearLast) = DateSerial(2001, 1, 1) Then
30        GoTo Exit_label
40    End If

50    With oSheet

60    For row = toRowFromDay(datDayFirst) To toRowFromDay(datDayLast)
70        If .Cells(row, toColFromYear(intYearLast)) > 0 Then
80            Exit For
90        End If
100   Next
110   rowTop = row

120   For row = toRowFromDay(datDayLast) To toRowFromDay(datDayFirst) Step -1
130       If .Cells(row, toColFromYear(intYearLast)) > 0 Then
140           Exit For
150       End If
160   Next
170   rowBottom = row

      ' Fill in the dates for current year column

180   For row = rowTop To rowBottom
190       .Cells(row, colDateYearLast) = DateSerial(intYearLast, Month(.Cells(row, 1)), Day(.Cells(row, 1)))
200   Next
210   .range(.Cells(rowTop, colDateYearLast), .Cells(rowBottom, colDateYearLast)).NumberFormat = "[$-1009]d-mmm-yy"

220   lngleft = .range(.Cells(2, colChart), .Cells(2, colChart)).Left
230   lngTop = .range(.Cells(2, colChart), .Cells(2, colChart)).Top

240   Set oChartObject = oSheet.ChartObjects.Add(lngleft, lngTop, 600, 250)
250   Set oChart = oChartObject.Chart

      Dim oRange1 As Excel.range
      Dim oRange2 As Excel.range
      Dim oRange3 As Excel.range

260   Set oRange1 = .range(.Cells(rowTop, colDateYearLast), .Cells(rowBottom, colDateYearLast))
270   Set oRange2 = .range(.Cells(rowTop, toColFromYear(intYearLast)), .Cells(rowBottom, toColFromYear(intYearLast)))
280   Set oRange3 = .range(.Cells(rowTop, toColMeanFromYear(intYearLast)), .Cells(rowBottom, toColMeanFromYear(intYearLast)))

290   End With

300   With oChart
310       With .SeriesCollection.NewSeries
320           .XValues = oRange1
330           .Values = oRange2
340       End With
350       With .SeriesCollection.NewSeries
360           .XValues = oRange1
370           .Values = oRange3
380       End With

      '    .SetSourceData Source:=oExcel.Union(oRange1, oRange2, oRange3)
390       .HasLegend = False
400       .Axes(xlCategory, xlPrimary).TickLabels.Orientation = 90
410       Select Case strSeason
          Case "Spring"
420           If intFld = conBND Then
430               .Axes(xlCategory).MajorUnit = 1
440           Else
450               .Axes(xlCategory).MajorUnit = 2
460           End If
470       Case "Fall"
480            .Axes(xlCategory).MajorUnit = 4
490       End Select
500       .SeriesCollection(1).ChartType = xlColumnClustered
510       .SeriesCollection(1).Interior.Color = RGB(0, 112, 192) ' blue
520       .SeriesCollection(2).ChartType = xlLine
530       .SeriesCollection(2).Border.Color = vbBlack
540       .PlotVisibleOnly = False

      '360       .Axes(xlCategory, xlPrimary).TickLabels.NumberFormat = "d-mmm"

550    End With

560   Set oChart = Nothing
570   Set oChartObject = Nothing

580   oSheet.range(oSheet.columns(colDateYearLast), oSheet.columns(colDateYearLast)).Hidden = True


          'DD Error Handler Start
Exit_label:
590       Exit Sub
Err_label:
600       Select Case Err.Number
          Case Else
610      Call LogError("basMBOProgramReport_MeanGraphs", "CurrentYearChart")
620       End Select
630       Resume Exit_label
          ' DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' MultiYearChart
'---------------------------------------------------------------------------------------
' Generate a multi-year chart

Private Sub MultiYearChart(ByRef oSheet As Excel.Worksheet, ByVal strXAxisTitle As String)

      Dim lngleft As Long
      Dim lngTop As Long
      Dim oChartObject As Excel.ChartObject
      Dim oChart As Excel.Chart
      Dim intYear As Integer
      Dim intYearFirstWithData As Integer
      Dim intSeriesNumber As Integer                     ' the graph series are numbered 1,2,3, ...

10    On Error GoTo Err_label


      ' datDayFirstTable(intFirstYear .. intLastYear) contains the first day with data for each year; DateSerial(2001,1,1) when a year has no data
      ' datDayFirstTable(intFirstYear .. intLastYear) contains the last day with data for each year; DateSerial(1999,12,31) when a year has no data

      ' Determine the first year that has data

20    intYearFirstWithData = -1
30    For intYear = intYearFirst To intYearLast
40        If datDayFirstTable(intYear) <> DateSerial(2001, 1, 1) Then
50            intYearFirstWithData = intYear
60            Exit For
70        End If
80    Next

      ' Quit if there is no data at all

90    If intYearFirstWithData = -1 Then
100       GoTo Exit_label
110   End If


      ' I have used columns Date, Period, YeaFirst, ... YearLast, YearAverage, MeanYearFirst, ... MeanYearLast, MeanYearAverage, DateYearLast
      ' colChart is 2 columns to the right of the above columns.
      ' The top left corner of the multi-year graph is the top left corner of the cell in row 1, col colChart

120   lngleft = oSheet.range(oSheet.Cells(1, colChart), oSheet.Cells(1, colChart)).Left  ' Distance in pixels of the left side of the graph from the left side of the worksheet
130   lngTop = oSheet.range(oSheet.Cells(30, colChart), oSheet.Cells(30, colChart)).Top  ' Distance in pixels of the top of the graph from the top of the worksheet

      ' I'm assuming that there is something to graph, i.e. there is data for at least one year.

140   Set oChartObject = oSheet.ChartObjects.Add(lngleft, lngTop, 600, 400)
150   Set oChart = oChartObject.Chart

160   With oChart
170       .ChartType = xlXYScatterLinesNoMarkers      '  XY graphs with lines but no data markers

          Dim rowDayFirst As Long
          Dim rowDayLast As Long
          Dim colYear As Integer

          ' The topmost row for the data (row 5) corresponds to the earliest standardised data for all years
          ' toRowFromDay maps standardised dates to row numbers

180       rowDayFirst = toRowFromDay(datDayFirstTable(intYearFirstWithData) + 1) ' the row corresponding to day 2 of the first year
                                                                                 ' the means are calculated over 3 days, so there is no value for the first day
190       rowDayLast = toRowFromDay(datDayLastTable(intYearFirstWithData) - 1)   ' the row corresponding to the before last day of the first year
                                                                                 ' the means are calculated over 3 days, so there is no value for the last day
200       colYear = toColMeanFromYear(intYearFirstWithData)                      ' the column that contains the mean value for the first year

          ' define the graph for the first year with data

210       .SetSourceData Source:=oSheet.range(oSheet.Cells(rowDayFirst, colYear), oSheet.Cells(rowDayLast, colYear))
220       .SeriesCollection(1).Name = "=""" & intYearFirstWithData & """"
230       .SeriesCollection(1).XValues = oSheet.range(oSheet.Cells(rowDayFirst, 1), oSheet.Cells(rowDayLast, 1))
240       .SeriesCollection(1).Format.Line.Weight = 1.5

250       .Axes(xlCategory, xlPrimary).TickLabels.Orientation = 90
260       .Axes(xlCategory, xlPrimary).TickLabels.NumberFormat = "[$-1009]dd-mmm"

270       .HasTitle = False
280       .HasLegend = True
290       .Legend.Position = xlLegendPositionRight

300       .Axes(xlCategory, xlPrimary).HasTitle = True
310       .Axes(xlCategory, xlPrimary).AxisTitle.Characters.Text = "Date (first day of each week shown)"
320       .Axes(xlCategory, xlPrimary).AxisTitle.Top = 380

330       .Axes(xlValue, xlPrimary).HasTitle = True
340       .Axes(xlValue, xlPrimary).AxisTitle.Characters.Text = strXAxisTitle ' "# of individuals banded daily"

          ' add series for each of the other years

          ' the series are numbered from 1

350       intSeriesNumber = 1

360       For intYear = intYearFirstWithData + 1 To intYearLast

              ' Skip years with no data

370           If datDayFirstTable(intYear) <> DateSerial(2001, 1, 1) Then

380               rowDayFirst = toRowFromDay(datDayFirstTable(intYear) + 1)
390               rowDayLast = toRowFromDay(datDayLastTable(intYear) - 1)
400               colYear = toColMeanFromYear(intYear)

410               .SeriesCollection.NewSeries
420               intSeriesNumber = intSeriesNumber + 1
430               .SeriesCollection(intSeriesNumber).Name = "=""" & intYear & """"
440               .SeriesCollection(intSeriesNumber).XValues = oSheet.range(oSheet.Cells(rowDayFirst, 1), oSheet.Cells(rowDayLast, 1))
450               .SeriesCollection(intSeriesNumber).Values = oSheet.range(oSheet.Cells(rowDayFirst, colYear), oSheet.Cells(rowDayLast, colYear))
460               .SeriesCollection(intSeriesNumber).Format.Line.Weight = 1.5
470           End If
480       Next

          ' add a series for the mean over all years

490       rowDayFirst = toRowFromDay(datDayFirst + 1)
500       rowDayLast = toRowFromDay(datDayLast - 1)
510       colYear = toColMeanFromYear(intYearLast + 1)

          Dim ser As Excel.series

520       .SeriesCollection.NewSeries
530       intSeriesNumber = intSeriesNumber + 1
540       Set ser = .SeriesCollection(intSeriesNumber)
550       ser.Name = "=""" & "Mean" & """"
560       ser.XValues = oSheet.range(oSheet.Cells(rowDayFirst, 1), oSheet.Cells(rowDayLast, 1))
570       ser.Values = oSheet.range(oSheet.Cells(rowDayFirst, colYear), oSheet.Cells(rowDayLast, colYear))
580       ser.Format.Line.Visible = msoFalse
590       ser.Format.Line.Visible = msoTrue
600       ser.Format.Line.Weight = 3

610       .SeriesCollection(intSeriesNumber).Format.Line.ForeColor.RGB = RGB(0, 0, 0)


620       oSheet.Shapes(1).Width = 600
630       oSheet.Shapes(1).Height = 400
640       oChart.Axes(xlCategory, xlPrimary).MajorUnit = 7
650       oChart.Axes(xlCategory, xlPrimary).MinimumScale = datDayFirstANY
660       oChart.Axes(xlCategory, xlPrimary).MaximumScale = datDayLastANY
670       oChart.ChartArea.Border.LineStyle = xlNone

680       .PlotArea.Height = 300

690   End With ' oChart

700   Set oChart = Nothing

          'DD Error Handler Start
Exit_label:
710       Exit Sub
Err_label:
720       Select Case Err.Number
          Case Else
730            Call LogError("basMBOProgramReport_MeanGraphs", "MultiYearChart")
740       End Select
750       Resume Exit_label
          ' DD Error Handler End

End Sub


'---------------------------------------------------------------------------------------
' toColMeanFromYear
'---------------------------------------------------------------------------------------

Private Function toColMeanFromYear(ByVal intYear As Integer) As Integer
10       On Error GoTo Err_label

20       On Error GoTo Err_label

30        toColMeanFromYear = colMeanYearFirst + intYear - intYearFirst

    'DD Error Handler Start
Exit_label:
40        Exit Function
Err_label:
50        Select Case Err.Number
    Case Else
60       Call LogError("basMBOProgramReport_MeanGraphs", "toColMeanFromYear")
70        End Select
80        Resume Exit_label
    ' DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' toRowFromDay
'---------------------------------------------------------------------------------------

Private Function toRowFromDay(ByVal datDay As Date) As Integer
10       On Error GoTo Err_label

' The topmost row for the data (row 5) corresponds to the earliest standardised data for all years

30        toRowFromDay = 5 + datDay - datDayFirst

    'DD Error Handler Start
Exit_label:
40        Exit Function
Err_label:
50        Select Case Err.Number
    Case Else
60       Call LogError("basMBOProgramReport_MeanGraphs", "toRowFromDay")
70        End Select
80        Resume Exit_label
    ' DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' toColFromYear
'---------------------------------------------------------------------------------------

Private Function toColFromYear(ByVal intYear As Integer) As Integer
10       On Error GoTo Err_label

20        toColFromYear = colYearFirst + intYear - intYearFirst

    'DD Error Handler Start
Exit_label:
30        Exit Function
Err_label:
40        Select Case Err.Number
    Case Else
50       Call LogError("basMBOProgramReport_MeanGraphs", "toColFromYear")
60        End Select
70        Resume Exit_label
    ' DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' toQueryname_FLDMinMaxDates_FromFLD
'---------------------------------------------------------------------------------------

Private Function toQueryname_FLDMinMaxDates_FromFLD(ByVal fld As Integer) As String
10       On Error GoTo Err_label

20    Select Case fld
      Case conCNS
30        toQueryname_FLDMinMaxDates_FromFLD = "qryMBO10YearProgramReport3DayMeanGraph_CensusMinMaxDates"
40    Case conDET
50        toQueryname_FLDMinMaxDates_FromFLD = "qryMBO10YearProgramReport3DayMeanGraph_DETMinMaxDates"
60    Case conBND
70        toQueryname_FLDMinMaxDates_FromFLD = "qryMBO10YearProgramReport3DayMeanGraph_BandedMinMaxDates"
80    End Select

    'DD Error Handler Start
Exit_label:
90        Exit Function
Err_label:
100       Select Case Err.Number
    Case Else
110      Call LogError("basMBOProgramReport_MeanGraphs", "toQueryname_FLDMinMaxDates_FromFLD")
120       End Select
130       Resume Exit_label
    ' DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' toSheetname_FromFLD
'---------------------------------------------------------------------------------------

Private Function toSheetname_FromFLD(ByVal fld As Integer) As String
10       On Error GoTo Err_label

20    Select Case fld
      Case conCNS
30        toSheetname_FromFLD = " Graph CNS Sp"
40    Case conDET
50        toSheetname_FromFLD = " Graph DET Sp"
60    Case conBND
70        toSheetname_FromFLD = " Graph BND Sp"
80    Case Else
90        Call LogError("basMBOProgramReport_MeanGraphs", "toSheetname_FromFLD", "Invalid fld " & fld, False, 1)
100   End Select

    'DD Error Handler Start
Exit_label:
110       Exit Function
Err_label:
120       Select Case Err.Number
    Case Else
130      Call LogError("basMBOProgramReport_MeanGraphs", "toSheetname_FromFLD")
140       End Select
150       Resume Exit_label
    ' DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' toYAxisTitle_FromFLD
'---------------------------------------------------------------------------------------

Private Function toYAxisTitle_FromFLD(ByVal fld As Integer) As String
10       On Error GoTo Err_label

20    Select Case fld
      Case conCNS
30        toYAxisTitle_FromFLD = "# species observed daily on census"
40    Case conDET
50        toYAxisTitle_FromFLD = "# species observed daily"
60    Case conBND
70        toYAxisTitle_FromFLD = "# species banded daily"
80    End Select

    'DD Error Handler Start
Exit_label:
90        Exit Function
Err_label:
100       Select Case Err.Number
    Case Else
110      Call LogError("basMBOProgramReport_MeanGraphs", "toYAxisTitle_FromFLD")
120       End Select
130       Resume Exit_label
    ' DD Error Handler End
End Function



'---------------------------------------------------------------------------------------
' toQueryname_FLDSpecies_FromFLD
'---------------------------------------------------------------------------------------

Private Function toQueryname_FLDSpecies_FromFLD(ByVal fld As Integer) As String
10       On Error GoTo Err_label

20    Select Case fld
      Case conCNS
30        toQueryname_FLDSpecies_FromFLD = "qryMBO10YearProgramReport3DayMeanGraph_CensusSpecies"
40    Case conDET
50        toQueryname_FLDSpecies_FromFLD = "qryMBO10YearProgramReport3DayMeanGraph_DETSpecies"
60    Case conBND
70        toQueryname_FLDSpecies_FromFLD = "qryMBO10YearProgramReport3DayMeanGraph_BandedSpecies"
80    End Select

    'DD Error Handler Start
Exit_label:
90        Exit Function
Err_label:
100       Select Case Err.Number
    Case Else
110      Call LogError("basMBOProgramReport_MeanGraphs", "toQueryname_FLDSpecies_FromFLD")
120       End Select
130       Resume Exit_label
    ' DD Error Handler End
End Function


'---------------------------------------------------------------------------------------
' Period
'---------------------------------------------------------------------------------------
' datProgramDateFrom = Nz(DLookup("[DateFrom]", "tblPrograms", "[MonitoringProgramSeason] = '" & strSeason & "' AND [YearEx] = " & intYearLast))
'

Private Function Period(ByVal datProgramDateFrom As Date, ByVal datDate As Date, ByVal strSeason As String) As String

10       On Error GoTo Err_label

         Dim strPeriod As String

20        Select Case strSeason
          Case "Spring", "Fall", "Owling"
30            If datProgramDateFrom <> 0 And datDate <> 0 Then
40                If datDate >= datProgramDateFrom Then
50                    strPeriod = toPeriod(strSeason, datDate, datProgramDateFrom)
60                    If strSeason = "Owling" Then
70                      strPeriod = strPeriod & " (F" & 8 + strPeriod & ")"
80                  End If
90                End If
100           End If
110       Case "Winter"
120           Select Case Month(datDate)
              Case 7 To 11                          ' Jul - Nov
130               strPeriod = 1
140           Case 12
150               strPeriod = 2                      ' Dec
160           Case 1 To 3
170               strPeriod = 2 + Month(datDate)   ' Jan, Feb, Mar
180           Case Else
190               strPeriod = 5                      ' Apr - Jun
200           End Select
210       Case "Summer", "Nestbox", "SummerNestbox"
220           Select Case Month(datDate)
              Case 1 To 6
230               strPeriod = 1
240           Case 7 To 12
250               strPeriod = 2
260           End Select
270       Case Else
280           strPeriod = ""
290       End Select

300       Period = strPeriod

          'DD Error Handler Start
Exit_label:
310       Exit Function
Err_label:
320       Select Case Err.Number
          Case Else
330      Call LogError("basMBOProgramReport_MeanGraphs", "Period")
340       End Select
350       Resume Exit_label
          ' DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' FirstLastDays
'---------------------------------------------------------------------------------------
' strChart = "Banded Birds", "Banded Species", "Census Species", "DET Species"

Private Sub FirstLastDays(ByVal strChart As String)

' Fill in:
'        datDayFirstTable() As Date  ' intFirstYear .. intLastYear+1   datDayFirstTable(year) is the standardised eariest date that the chart's stat > 0
'                                    '                                                        is 2001-01-01 if stat was never > 0 for the season x year
'                                    '                                 datDayFirstTable(intLastYear+1) is the min from datDayFirstTable(intFirstYear .. intLastYear)
'
'        datDayLastTable() As Date   ' intFirstYear .. intLastYear+1   datDayLastTable(year) is the standardised latest date that the chart's stat > 0
'                                    '                                                       is 1999-12-31 if stat was never > 0 for the season x year
'                                    '                                 datDayFirstTable(intLastYear+1) is the max from datDayFirstTable(intFirstYear .. intLastYear)
'
'        datDayFirst As Date         ' Same as datDayFirstTable(intLastYear+1)             I use both, so I must ensure they are equal
'        datDayLast As Date          ' Same as datDayFirstTable(intLastYear+1)

'        datDateYearLast() As Date   ' The date in the current report year that corresponds to a standardised date

On Error GoTo Err_label

Dim qdf As QueryDef
Dim rst As DAO.Recordset
Dim datDate As Date
Dim datDay As Date
Dim intYear As Integer

ReDim datDayFirstTable(intYearFirst To intYearLast + 1)
ReDim datDayLastTable(intYearFirst To intYearLast + 1)

For intYear = intYearFirst To intYearLast + 1
    datDayFirstTable(intYear) = DateSerial(2001, 1, 1)  ' A date that is after any possible First Day.  Recall that we are only processig Spring and Fall
    datDayLastTable(intYear) = DateSerial(1999, 12, 31) ' A date that is before than any possible Last Day
Next

datDayFirst = DateSerial(2001, 1, 1)
datDayLast = DateSerial(1999, 12, 31)


' qryMBO10YearProgramReport3DayMeanGraph_BandedMinMaxDates
' --------------------------------------------------------
' For a given season determine the earliest and latest banding dates in each year
'
' tblDETSpecies x tblprograms
'
' WHERE Season = [argSeason]
' WHERE Location = [argLocation]
' WHERE Banded > 0
' GROUP BY Year where Year is between [argYearFirst] and [argYearLast] inclusive
' DateFirst = MIN DateEX
' DateLast = MAX DateEx
'
' The result is one record your each year (in the given season) for which there was at least one banding


' qryMBO10YearProgramReport3DayMeanGraph_BandedMinMaxDates
' --------------------------------------------------------
' The same as qryMBO10YearProgramReport3DayMeanGraph_BandedMinMaxDates


' qryMBO10YearProgramReport3DayMeanGraph_CensusMinMaxDates
' --------------------------------------------------------
' The same as qryMBO10YearProgramReport3DayMeanGraph_BandedMinMaxDates, but for Census instead of Banding


' qryMBO10YearProgramReport3DayMeanGraph_DETMinMaxDates
' --------------------------------------------------------
' The same as qryMBO10YearProgramReport3DayMeanGraph_BandedMinMaxDates, but for DET instead of Banding

Select Case strChart
Case "Banded Birds"
    Set qdf = CurrentDb.QueryDefs("qryMBO10YearProgramReport3DayMeanGraph_BandedMinMaxDates")
Case "Banded Species"
    Set qdf = CurrentDb.QueryDefs(toQueryname_FLDMinMaxDates_FromFLD(conBND))
Case "Census Species"
    Set qdf = CurrentDb.QueryDefs(toQueryname_FLDMinMaxDates_FromFLD(conCNS))
Case "DET Species"
    Set qdf = CurrentDb.QueryDefs(toQueryname_FLDMinMaxDates_FromFLD(conDET))
End Select

qdf.Parameters("argSeason").value = strSeason
qdf.Parameters("argLocation").value = strLocation
qdf.Parameters("argYearFirst").value = intYearFirst
qdf.Parameters("argYearLast").value = intYearLast

Set rst = qdf.OpenRecordset
Do While Not rst.EOF
    intYear = Nz(rst("YearEx"))

    datDate = Nz(rst("DateFirst"))
    datDay = DateSerial(2000, Month(datDate), Day(datDate))
    datDayFirstTable(intYear) = datDay
    If datDay < datDayFirst Then
        datDayFirst = datDay
    End If

    datDate = Nz(rst("DateLast"))
    datDay = DateSerial(2000, Month(datDate), Day(datDate))
    datDayLastTable(intYear) = datDay
    If datDay > datDayLast Then
        datDayLast = datDay
    End If
    rst.MoveNext
Loop
rst.Close
Set rst = Nothing

datDayFirstTable(intYearLast + 1) = datDayFirst
datDayLastTable(intYearLast + 1) = datDayLast

' Fill in  datDateYearLast()

ReDim datDateYearLast(datDayFirst To datDayLast)

Dim D As Date

For D = datDayFirstTable(intYearLast) To datDayLastTable(intYearLast)
    datDateYearLast(D) = DateSerial(intYearLast, Month(D), Day(D))
Next

    'DD Error Handler Start
Exit_label:
    Exit Sub
Err_label:
    Select Case Err.Number
    Case Else
   Call LogError("basMBOProgramReport_MeanGraphs", "FirstLastDays")
    End Select
    Resume Exit_label
    ' DD Error Handler End

End Sub
