'---------------------------------------------------------------------------------------
' Module: basFileFolderOpertions
' Author: David Davey
'---------------------------------------------------------------------------------------

Option Compare Database
Option Explicit

'---------------------------------------------------------------------------------------
' ValidateFullFolderpath
'---------------------------------------------------------------------------------------
' Dim strError As String)
' Call ValidatFullFolderpath( strFolderpath, strError)
'
' This code does not catch all possible errors, e.g. \\, reserved names

Public Sub ValidateFullFolderpath(ByRef strFolderpath As String, ByRef strError As String)

          ' Validate that strFolder isn't blank
          ' Validate that strFolder starts with letter : \

10    On Error GoTo Err_label
         
20    strError = ""

30    If Not ValidatePath_IsNotBlank(strFolderpath) Then
40        strError = "You must specify the full path to the folder"
50        GoTo Exit_label
60    End If

70    If Not ValidatePath_StartsWithLetterColonBackslash(strFolderpath) Then
80        strError = "The full path to the folder must begin with a drive letter followed by a colon and a backslash"
90        GoTo Exit_label
100   End If

      ' Invalid characters: <  >  :  "  /  |  ?  *

110     With CreateObject("VBScript.RegExp")
120       .Pattern = "[<>:""/\|\?\*]"

130       If .Test(Mid(strFolderpath, 4)) Then                       ' strip off the letter colon backslash
140           strError = "The path contains an invalid character"
150           GoTo Exit_label
160       End If
170     End With

          'DD Error Handler Start
Exit_label:
180       Exit Sub
Err_label:
190       Select Case Err.Number
          Case Else
200      Call LogError("basFileFolderOpertions", "ValidateFullFolderpath")
210       End Select
220       Resume Exit_label
          ' DD Error Handler End

End Sub




'---------------------------------------------------------------------------------------
' GetFolder
'
' Returns "" if the user cancels
'---------------------------------------------------------------------------------------

Public Function GetFolder(ByVal strInitialFolderpath As String) As String

10       On Error GoTo Err_label

          Dim fldr As FileDialog
          Dim sItem As String
          
20        sItem = ""

30        Set fldr = Application.FileDialog(msoFileDialogFolderPicker)
40        With fldr
50            .Title = "Select a Folder"
60            .AllowMultiSelect = False
70            .InitialFileName = strInitialFolderpath
80            If .Show <> -1 Then GoTo NextCode
90            sItem = .SelectedItems(1)
100       End With
NextCode:
110       GetFolder = sItem
120       Set fldr = Nothing

          'DD Error Handler Start
Exit_label:
130       Exit Function
Err_label:
140       Select Case Err.Number
          Case Else
150            Call LogError("basFileFolderOperations", "GetFolder")
160       End Select
170       Resume Exit_label
          ' DD Error Handler End
End Function


'---------------------------------------------------------------------------------------
' CreateFolder
'---------------------------------------------------------------------------------------

Public Sub CreateFolder(ByVal strFolderpath As String, ByRef strError As String)

10    On Error GoTo Err_label

      Dim fso As New Scripting.FileSystemObject

         
20    strError = ""
30    fso.CreateFolder (strFolderpath)


          'DD Error Handler Start
Exit_label:
40        Exit Sub
Err_label:
50        Select Case Err.Number
          Case Else
60             strError = "Failed to create the folder " & strFolderpath
70             GoTo Exit_label
80        End Select
90        Resume Exit_label
          ' DD Error Handler End

End Sub
