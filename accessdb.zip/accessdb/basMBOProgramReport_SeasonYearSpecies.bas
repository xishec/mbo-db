Option Compare Database
Option Explicit

Const conNonSeason As Integer = -1
Const conWinter  As Integer = 0
Const conSpring  As Integer = 1
Const conSummer  As Integer = 2
Const conFall    As Integer = 3
Const conOwling  As Integer = 4
Const conRTHU    As Integer = 5
Const conNestbox As Integer = 6
Const conSummerNestbox As Integer = 7

Const conDETSeasonFirst As Integer = -1
Const conDETSeasonLast  As Integer = 3

Const intSeasonFirst As Integer = -1
Const intSeasonLast  As Integer = 7

Const intStatBanded As Integer = 0
Const intStatReturns As Integer = 1
Const intStatRepeats As Integer = 2
Const intStatAlien As Integer = 3
Const intStatDET As Integer = 4
Const intStatCensus As Integer = 5
Const intStatMeanDET As Integer = 6

Const intStatFirst As Integer = 0
Const intStatLast As Integer = 6

'---------------------------------------------------------------------------------------
' MBOProgramReport_SeasonYearSpecies
'---------------------------------------------------------------------------------------
 
Public Sub MBOProgramReport_SeasonYearSpecies( _
    ByVal intYearFirst As Integer, _
    ByVal intYearLast As Integer, _
    ByVal strLocation As String, _
    ByRef oBook As Excel.Workbook)
          
10    On Error GoTo Err_label

      Dim oSheet As Excel.Worksheet

20    ReDim lngStatSeasonSpeciesYear(intYearFirst To intYearLast) As Long   ' Season x Species x Year
30    ReDim lngStatSeasonYear(intYearFirst To intYearLast) As Long          ' Season x Year             (column) total over species
      Dim lngStatSeasonSpecies As Long                                      ' Season x Species          (row) total over years
      Dim lngStatSeason As Long                                             ' Season                     grand total

      Dim intSeason As Integer
      Dim strSeason As String
      Dim intYear As Integer
      Dim strSpecies As String
      Dim strSpeciesEnglish As String
      Dim strPriorityCategory As String

      Dim row As Long
      Dim col As Long

      Dim rowBase As Long
      Dim rowDataFirst As Long
      Dim rowDataLast As Long
      Dim colSpecies As Long
      Dim colSpeciesEnglish As Long
      Dim colPriorityCategory As Long
      Dim colDataTotal As Integer
      Dim rowTotal As Long
      Dim colDataFirst As Long
      Dim colDataLast As Long
      Dim colPercentFirst As Long
      Dim colPercentLast As Long
      Dim colPercentTotal As Long
      Dim colRankFirst As Long
      Dim colRankLast As Long
      Dim colAOUOrder As Long
      Dim colLast As Long
      Dim lngDETDays As Long

40    colSpecies = 1
50    colSpeciesEnglish = 2
60    colPriorityCategory = 3
70    colDataFirst = 4
80    colDataLast = colDataFirst + intYearLast - intYearFirst
90    colDataTotal = colDataLast + 1
100   colPercentFirst = colDataTotal + 1
110   colPercentLast = colPercentFirst + (intYearLast - intYearFirst)
120   colPercentTotal = colPercentLast + 1
130   colRankFirst = colPercentTotal + 1
140   colRankLast = colRankFirst + (intYearLast - intYearFirst)
150   colAOUOrder = colRankLast + 1
160   colLast = colAOUOrder

      ' Each season has its own spreadsheet

170   For intSeason = intSeasonFirst To intSeasonLast
180       strSeason = toStrSeasonFromIntSeason(intSeason)

190       SysCmd acSysCmdSetStatus, strSeason & " Year x Species"
          
200       On Error Resume Next
210       DoCmd.DeleteObject acTable, "tblMBOProgramReport_SeasonYearSpecies"
220       On Error GoTo Err_label
          
          Dim qdf As QueryDef
230       Set qdf = CurrentDb.QueryDefs("qryMBOProgramReport_SeasonYearSpecies_MakeTable")
240       qdf.Parameters("argYearFirst").value = intYearFirst
250       qdf.Parameters("argYearLast").value = intYearLast
260       qdf.Parameters("argLocation").value = strLocation
270       qdf.Parameters("argSeason").value = strSeason
280       qdf.Execute
          
290       Set oSheet = InsertSheet(oBook, strSeason)
300       oSheet.Name = strSeason & " Year x Species"
310       With oSheet
          
          ' Some global headings appear on row 2 - we will freeze under row 2

320       .Cells(2, colSpecies) = strSeason
330       .Cells(2, colPriorityCategory) = "Pr"
340       For intYear = intYearFirst To intYearLast
350           col = colDataFirst + intYear - intYearFirst
360           .Cells(2, col) = intYear
370           col = colPercentFirst + intYear - intYearFirst
380            .Cells(2, col) = intYear
390           col = colRankFirst + intYear - intYearFirst
400            .Cells(2, col) = intYear
410       Next
420       .Cells(2, colDataTotal) = "Total"
430       .Cells(2, colPercentTotal) = "All Years"
440       .Cells(2, colAOUOrder) = "AOS Order"
450       .Rows(2).Font.Bold = True

460       rowBase = 3
          
          Dim intStat As Integer
          Dim strStat As String
          
          ' Each statistic is reported as a vertical block, starting at rowBase
           
470       For intStat = intStatFirst To intStatLast
          
480           Select Case intStat
              Case intStatBanded
490               strStat = "banded"
500           Case intStatReturns
510               strStat = "returns"
520           Case intStatRepeats
530               strStat = "repeats"
540           Case intStatAlien
550               strStat = "alien"
560           Case intStatDET
570               strStat = "DET"
580           Case intStatCensus
590               strStat = "census"
600           Case intStatMeanDET
610               strStat = "mean DET"
620           End Select

630           SysCmd acSysCmdSetStatus, strSeason & " Year x Species : " & strStat
           
640           row = rowBase
              
650           .Cells(row, colDataFirst) = strStat
660           .Rows(row).Font.Bold = True
670           .range(.Cells(row, colDataFirst), .Cells(row, colDataTotal)).Merge
680           If intStat <> intStatMeanDET Then
690               .Cells(row, colPercentFirst) = "% " & strStat
700               .range(.Cells(row, colPercentFirst), .Cells(row, colPercentTotal)).Merge
710           End If
720           .Cells(row, colRankFirst) = "rank"
730           .range(.Cells(row, colRankFirst), .Cells(row, colRankLast)).Merge
740           row = row + 1
          
750           .Cells(row, colSpecies) = "Species"
760           .Cells(row, colSpeciesEnglish) = "English"
770           .Cells(row, colPriorityCategory) = "Pr"
780           For intYear = intYearFirst To intYearLast
790               col = colDataFirst + intYear - intYearFirst
800               .Cells(row, col) = intYear
810               If intStat <> intStatMeanDET Then
820                   col = colPercentFirst + intYear - intYearFirst
830                   .Cells(row, col) = intYear
840               End If
850               col = colRankFirst + intYear - intYearFirst
860            .Cells(row, col) = intYear
870           Next
880           .Cells(row, colDataTotal) = "All Years"
890           If intStat <> intStatMeanDET Then
900                .Cells(row, colPercentTotal) = "All Years"
910           End If
920           .Cells(row, colAOUOrder) = "AOS Order"
930           .Rows(row).Font.Bold = True
940           row = row + 1

950           rowDataFirst = row
              
960           For intYear = intYearFirst To intYearLast
970               lngStatSeasonYear(intYear) = 0
980           Next
              
990           lngStatSeason = 0
          
              Dim strSQL As String
              Dim dblAOUOrder As Double
              
1000          Select Case intStat
              Case intStatBanded
1010              strSQL = "SELECT * FROM qryMBOProgramReport_SeasonYearSpecies_banded_CrossTab"
1020          Case intStatReturns
1030              strSQL = "SELECT * FROM qryMBOProgramReport_SeasonYearSpecies_returns_CrossTab"
1040          Case intStatRepeats
1050              strSQL = "SELECT * FROM qryMBOProgramReport_SeasonYearSpecies_repeats_CrossTab"
1060          Case intStatAlien
1070              strSQL = "SELECT * FROM qryMBOProgramReport_SeasonYearSpecies_alien_CrossTab"
1080          Case intStatDET
1090              strSQL = "SELECT * FROM qryMBOProgramReport_SeasonYearSpecies_DET_CrossTab"
1100          Case intStatCensus
1110              strSQL = "SELECT * FROM qryMBOProgramReport_SeasonYearSpecies_Census_CrossTab"
1120          Case intStatMeanDET
1130              strSQL = "SELECT * FROM qryMBOProgramReport_SeasonYearSpecies_DET_CrossTab"
1140          End Select
                           
              Dim rst As DAO.Recordset
1150          Set rst = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)
1160          Do While Not rst.EOF
            
1170              lngStatSeasonSpecies = 0
1180              strSpecies = Nz(rst("Species"))
1190              strSpeciesEnglish = Nz(rst("SpeciesEnglish"))
1200              strPriorityCategory = Nz(rst("PriorityCategory"))
1210              dblAOUOrder = Nz(rst("AOUOrder"))
1220              On Error Resume Next
1230              For intYear = intYearFirst To intYearLast
1240                  lngStatSeasonSpeciesYear(intYear) = 0
1250                  lngStatSeasonSpeciesYear(intYear) = Nz(rst(CStr(intYear)))
1260                  lngStatSeasonSpecies = lngStatSeasonSpecies + lngStatSeasonSpeciesYear(intYear)
1270                  lngStatSeasonYear(intYear) = lngStatSeasonYear(intYear) + lngStatSeasonSpeciesYear(intYear)
1280              Next
1290              On Error GoTo Err_label
                  
                    ' Only output the row if at least one value is > 0
                  
1300              If lngStatSeasonSpecies > 0 Then
1310                  .Cells(row, colSpecies) = strSpecies
1320                  .Cells(row, colSpeciesEnglish) = strSpeciesEnglish
1330                  .Cells(row, colPriorityCategory) = strPriorityCategory
1340                  .Cells(row, colAOUOrder) = dblAOUOrder
1350                  For intYear = intYearFirst To intYearLast
1360                      If lngStatSeasonSpeciesYear(intYear) > 0 Then
1370                          col = 4 + intYear - intYearFirst
1380                          If intStat <> intStatMeanDET Then
1390                              .Cells(row, col) = lngStatSeasonSpeciesYear(intYear)
1400                          Else
1410                              lngDETDays = getDETDays_SeasonYear(intSeason, intYear)
1420                               If lngDETDays > 0 Then
1430                                  .Cells(row, col) = lngStatSeasonSpeciesYear(intYear) / lngDETDays
1440                              End If
1450                          End If
1460                      End If
1470                  Next
1480                  If intStat <> intStatMeanDET Then
1490                      .Cells(row, colDataTotal) = lngStatSeasonSpecies
1500                  Else
1510                      lngDETDays = getDETDays_Season(intSeason)
1520                      .Cells(row, colDataTotal) = lngStatSeasonSpecies / lngDETDays
1530                  End If
1540                  row = row + 1
1550              End If
                
1560              rst.MoveNext
1570          Loop
1580          rst.Close
1590          Set rst = Nothing

1600          rowDataLast = row - 1
1610          rowTotal = row
               
1620          .range(.Cells(rowBase, colDataLast), .Cells(rowDataLast, colDataLast)).Interior.Color = RGB(215, 228, 188) ' green
1630          .range(.Cells(rowBase, colDataTotal), .Cells(rowDataLast, colDataTotal)).Interior.Color = RGB(182, 221, 232) ' blue
1640          If intStat <> intStatMeanDET Then
1650              .range(.Cells(rowBase, colPercentLast), .Cells(rowDataLast, colPercentLast)).Interior.Color = RGB(215, 228, 188) ' green
1660              .range(.Cells(rowBase, colPercentTotal), .Cells(rowDataLast, colPercentTotal)).Interior.Color = RGB(182, 221, 232) ' blue
1670          End If

              ' Grand total over column totals
          
1680          For intYear = intYearFirst To intYearLast
1690              lngStatSeason = lngStatSeason + lngStatSeasonYear(intYear)
1700          Next
              
              ' Sort the data
              
1710          If lngStatSeason > 0 Then
1720              .range(.Cells(rowDataFirst, 1), .Cells(rowDataLast, colLast)).Sort _
                      key1:=.range(.Cells(rowDataFirst, colDataLast), .Cells(rowDataLast, colDataLast)), _
                      Order1:=xlDescending, _
                      key2:=.range(.Cells(rowDataFirst, colAOUOrder), .Cells(rowDataLast, colAOUOrder)), _
                      Order2:=xlAscending, _
                      Header:=xlNo
1730          End If
          
          
              ' Report column totals + grand total
              
1740          If lngStatSeason > 0 And intStat <> intStatMeanDET Then
1750              For intYear = intYearFirst To intYearLast
1760                  col = 4 + intYear - intYearFirst
1770                  .Cells(rowTotal, col) = lngStatSeasonYear(intYear)
1780              Next
1790              .Cells(rowTotal, colDataTotal) = lngStatSeason
1800              .range(.Cells(rowTotal, 1), .Cells(rowTotal, colDataTotal)).Interior.Color = RGB(182, 221, 232) ' blue
1810              row = row + 1
1820          End If
        
              ' Max, prior maximums
          
              Dim dblMaxYear As Double
              Dim intYear_MaxYear As Integer
              Dim dblStat As Double
              
1830          If lngStatSeason > 0 Then
1840              For row = rowDataFirst To rowDataLast
1850                  dblMaxYear = 0
1860                  For intYear = intYearFirst To intYearLast
1870                      col = 4 + intYear - intYearFirst
1880                      If .Cells(row, col) > 0 Then
1890                          dblStat = .Cells(row, col)
1900                          If dblStat > dblMaxYear Then
1910                              dblMaxYear = dblStat
1920                              intYear_MaxYear = intYear
1930                              .Cells(row, col).Interior.Color = RGB(255, 255, 185) ' light yelloe
1940                          End If
1950                      End If
1960                  Next
1970                  If dblMaxYear > 0 Then
1980                      col = 4 + intYear_MaxYear - intYearFirst
1990                      .Cells(row, col).Interior.Color = RGB(255, 255, 0) ' bright yellow
2000                  End If
2010               Next
2020           End If
               
              ' Percent
               
2030           If intStat <> intStatMeanDET Then
              
                  Dim colPercent As Long
              
2040              For intYear = intYearFirst To intYearLast
2050                  col = colDataFirst + intYear - intYearFirst
2060                  colPercent = colPercentFirst + intYear - intYearFirst
2070                  For row = rowDataFirst To rowDataLast
2080                      If lngStatSeasonYear(intYear) > 0 And .Cells(row, col) > 0 Then
2090                          .Cells(row, colPercent) = .Cells(row, col) / lngStatSeasonYear(intYear)
2100                      End If
2110                  Next
2120              Next
                  
2130              For row = rowDataFirst To rowDataLast
2140                  If lngStatSeason > 0 Then
2150                      .Cells(row, colPercentTotal) = .Cells(row, colDataTotal) / lngStatSeason
2160                  End If
2170              Next
                  
2180           End If
               
              ' Rank
                     
              Dim dicToRowFomStrSpecies As Scripting.Dictionary
2190          Set dicToRowFomStrSpecies = New Scripting.Dictionary

2200          For row = rowDataFirst To rowDataLast
2210              strSpecies = .Cells(row, colSpecies)
2220              If Not dicToRowFomStrSpecies.Exists(strSpecies) Then
2230                  dicToRowFomStrSpecies.Add strSpecies, row
2240              End If
2250          Next

              Dim lngValue As Long
              Dim lngValue_previous As Long
              Dim intRank As Integer
              Dim intCountSpecies As Integer
              Dim rowRank As Long
              Dim colRank As Long
              Dim strStatLookup As String
              
2260          For intYear = intYearFirst To intYearLast
              
2270             lngValue_previous = -1
2280             intCountSpecies = 0
2290             intRank = 1
                 
2300             If intStat <> intStatMeanDET Then
2310                  strStatLookup = strStat
2320              Else
                     ' Mean DET and DET have identical rankings since the # DET days in a season x year is the same for all species
2330                 strStatLookup = "DET"
2340              End If
                  
2350              strSQL = _
                      "SELECT * FROM tblMBOProgramReport_SeasonYearSpecies WHERE " & _
                           strStatLookup & " > 0 AND [YearEx] = " & intYear & " ORDER BY " & strStatLookup & " Desc, AOUOrder"
                             
2360             Set rst = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)
2370             Do While Not rst.EOF
2380                 strSpecies = Nz(rst("Species"))
2390                 lngValue = Nz(rst(strStatLookup))
2400                 rowRank = dicToRowFomStrSpecies(strSpecies)
2410                 colRank = colRankFirst + intYear - intYearFirst
2420                 intCountSpecies = intCountSpecies + 1
2430                 If lngValue <> lngValue_previous Then
2440                     intRank = intCountSpecies
2450                     lngValue_previous = lngValue
2460                 End If
2470                 .Cells(rowRank, colRank) = intRank
2480                 rst.MoveNext
2490             Loop
2500             rst.Close
2510             Set rst = Nothing
              
2520          Next intYear

2530          dicToRowFomStrSpecies.RemoveAll
              
               
2540          If intStat <> intStatMeanDET Then
2550              .range(.Cells(rowDataFirst, colDataFirst), .Cells(rowDataLast, colDataTotal)).NumberFormat = "#0"
2560          Else
2570              .range(.Cells(rowDataFirst, colDataFirst), .Cells(rowDataLast, colDataTotal)).NumberFormat = "#0.000"
2580          End If
2590          .range(.Cells(rowDataFirst, colPercentFirst), .Cells(rowDataLast, colPercentTotal)).NumberFormat = "0%"
                     
2600          rowBase = row + 2
                  
2610      Next intStat
         
2620      .range(.columns(colDataFirst), .columns(colRankLast)).HorizontalAlignment = xlCenter
2630      .range(.columns(1), .columns(colRankLast)).AutoFit
          
2640      .Cells(1, 1) = "Bright yellow = max, light yellow = prior max)"
          
2650      row = rowBase
2660              .Cells(row, 1) = "Mean DET and DET have identical rankings since the # DET days in a season x year is the same for all species."
          
2670      .range("D3").Select
2680      oBook.Application.ActiveWindow.FreezePanes = True
          
2690      SysCmd acSysCmdClearStatus
              
2700      End With
2710  Next intSeason
           
           'DD Error Handler End

      'DD Error Handler Start
Exit_label:
2720       Exit Sub
Err_label:
2730       Select Case Err.Number
           Case Else
2740      Call LogError("basMBOProgramReport_SeasonYearSpecies", "MBOProgramReport_SeasonYearSpecies")
2750       End Select
2760       Resume Exit_label
      'DD Error Handler End

End Sub
