'---------------------------------------------------------------------------------------
' Module: basMBOProgramReport_Recaps
' Author: David Davey
'---------------------------------------------------------------------------------------

Option Compare Database
Option Explicit

Private colSpecies As Long
Private colSpeciesEnglish As Long
Private colReturnsFirst As Long
Private colReturnsLast As Long
Private colReturnsTotal As Long
Private colRepeatsFirst As Long
Private colRepeatsLast As Long
Private colRepeatsTotal As Long
Private colRecapsFirst As Long
Private colRecapsLast As Long
Private colRecapsTotal As Long
Private colPercentReturnsFirst As Long
Private colPercentReturnsLast As Long
Private colPercentReturnsTotal As Long
Private colPercentRepeatsFirst As Long
Private colPercentRepeatsLast As Long
Private colPercentRepeatsTotal As Long
Private colLast As Long

'---------------------------------------------------------------------------------------
' Initialise
'---------------------------------------------------------------------------------------

Private Sub initialise(ByVal intYearFirst As Integer, ByVal intYearLast As Integer)
      Dim col As Long
10       On Error GoTo Err_label

20    col = 1
30    colSpecies = col
40    col = col + 1
50    colSpeciesEnglish = col
60    col = col + 1
70    colReturnsFirst = col
80    col = col + (intYearLast - intYearFirst)
90    colReturnsLast = col
100   col = col + 1
110   colReturnsTotal = col
120   col = col + 1
130   colRepeatsFirst = col
140   col = col + (intYearLast - intYearFirst)
150   colRepeatsLast = col
160   col = col + 1
170   colRepeatsTotal = col
180   col = col + 1
190   colRecapsFirst = col
200   col = col + (intYearLast - intYearFirst)
210   colRecapsLast = col
220   col = col + 1
230   colRecapsTotal = col
240   col = col + 1
250   colPercentReturnsFirst = col
260   col = col + (intYearLast - intYearFirst)
270   colPercentReturnsLast = col
280   col = col + 1
290   colPercentReturnsTotal = col
300   col = col + 1
310   colPercentRepeatsFirst = col
320   col = col + (intYearLast - intYearFirst)
330   colPercentRepeatsLast = col
340   col = col + 1
350   colPercentRepeatsTotal = col
360   colLast = col


          'DD Error Handler Start
Exit_label:
370       Exit Sub
Err_label:
380       Select Case Err.Number
          Case Else
390            Call LogError("basMBOProgramReport_Recaps", "Initialise")
400       End Select
410       Resume Exit_label
          ' DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' MBOProgramReport_Recaps
'---------------------------------------------------------------------------------------
 
Public Sub MBOProgramReport_Recaps( _
    ByVal intYearFirst As Integer, _
    ByVal intYearLast As Integer, _
    ByVal strLocation As String, _
    ByRef oBook As Excel.Workbook)
          
10    On Error GoTo Err_label
          
      Dim varSeason As Variant
      Dim strSeason As String
      Dim intYear As Integer

      Dim oSheet As Excel.Worksheet
      Dim row As Long
      Dim col As Long

20    If intYearLast < intYearFirst Then Exit Sub

30    Call initialise(intYearFirst, intYearLast)

      ' For each Season

      Dim arrSeason() As Variant
40    arrSeason = Array("Winter", "Spring", "Summer", "Fall", "Owling")

50    For Each varSeason In arrSeason
60        strSeason = CStr(varSeason)

70        SysCmd acSysCmdSetStatus, strSeason & " Recaps"
          
80        Set oSheet = InsertSheet(oBook, strSeason)
90        oSheet.Name = strSeason & " Recaps"
100       With oSheet
          
          ' Columns
          ' -------
          ' Species, SpeciesEnglish
          ' Returns_YearFirst ... Returns_YearLast
          ' ReturnsTotal
          ' Repeats_YearFirst ... Returns_YearLast
          ' RepeatsTotal
          ' Recaps_YearFirst ... Returns_YearLast
          ' RecapsTotal
          ' %Returns_YearFirst ... %Returns_YearLast
          ' %PercentReturnsTotal
          ' %Repeats_YearFirst ... %Returns_YearLast
          ' %PercentRepeatsTotal
          
          Dim rowTitle As Long
          
110       rowTitle = 1
                    
120       row = 1
          
130       row = row + 1
140       .Cells(row, colReturnsFirst) = "Returns"
150       .Cells(row, colRepeatsFirst) = "Repeats"
160       .Cells(row, colRecapsFirst) = "Recaps"
170       .Cells(row, colPercentReturnsFirst) = "%Returns"
180       .Cells(row, colPercentRepeatsFirst) = "%Repeats"

190       .Cells(row, colReturnsFirst).HorizontalAlignment = xlCenter
200       .Cells(row, colRepeatsFirst).HorizontalAlignment = xlCenter
210       .Cells(row, colRecapsFirst).HorizontalAlignment = xlCenter
220       .Cells(row, colPercentReturnsFirst).HorizontalAlignment = xlCenter
230       .Cells(row, colPercentRepeatsFirst).HorizontalAlignment = xlCenter
          
240       .range(.Cells(row, colReturnsFirst), .Cells(row, colReturnsLast)).Merge
250       .range(.Cells(row, colRepeatsFirst), .Cells(row, colRepeatsLast)).Merge
260       .range(.Cells(row, colRecapsFirst), .Cells(row, colRecapsLast)).Merge
270       .range(.Cells(row, colPercentReturnsFirst), .Cells(row, colPercentReturnsLast)).Merge
280       .range(.Cells(row, colPercentRepeatsFirst), .Cells(row, colPercentRepeatsLast)).Merge
290       .range(.Cells(row, colPercentReturnsFirst), .Cells(row, colPercentReturnsLast)).Merge

300       row = row + 1
310       .Cells(row, colSpecies) = "Species"
320       .Cells(row, colSpeciesEnglish) = "20"
330       .Cells(row, colSpeciesEnglish).HorizontalAlignment = xlRight
340       For intYear = intYearFirst To intYearLast
350           .Cells(row, colReturnsFirst + (intYear - intYearFirst)) = Right(CStr(intYear), 2)
360           .Cells(row, colRepeatsFirst + (intYear - intYearFirst)) = Right(CStr(intYear), 2)
370           .Cells(row, colRecapsFirst + (intYear - intYearFirst)) = Right(CStr(intYear), 2)
380           .Cells(row, colPercentReturnsFirst + (intYear - intYearFirst)) = Right(CStr(intYear), 2)
390           .Cells(row, colPercentRepeatsFirst + (intYear - intYearFirst)) = Right(CStr(intYear), 2)

400           .Cells(row, colReturnsFirst + (intYear - intYearFirst)).NumberFormat = "00"
410           .Cells(row, colRepeatsFirst + (intYear - intYearFirst)).NumberFormat = "00"
420           .Cells(row, colRecapsFirst + (intYear - intYearFirst)).NumberFormat = "00"
430           .Cells(row, colPercentReturnsFirst + (intYear - intYearFirst)).NumberFormat = "00"
440           .Cells(row, colPercentRepeatsFirst + (intYear - intYearFirst)).NumberFormat = "00"

450       Next
460       .Cells(row, colReturnsTotal) = "Total"
470       .Cells(row, colRepeatsTotal) = "Total"
480       .Cells(row, colRecapsTotal) = "Total"
490       .Cells(row, colPercentReturnsTotal) = "Total"
500       .Cells(row, colPercentRepeatsTotal) = "Total"

510   row = row + 1

      Dim rowFirst As Long
      Dim rowLast As Long
520   rowFirst = row

      ' qryMBOProgramReport_Recaps
      ' --------------------------
      'tblSpecies x  tblDETSpecies x tblPrograms
      '
      ' WHERE MonitoringProgramSeason = strSeason
      ' WHERE YearEx BETWEEN intYearFirst AND intYearLast
      ' GROUP BY YearEx
      ' GROUP BY Species
      ' GROUP BY SpeciesEnglish = xxxx
      ' Repeats = SUM REP
      ' Returns = SUM RET
      ' Report Species, SpeciesEnglish, YearEx, Repeats, Returns
      ' Order BY Species, YearEx

        
      Dim qdf As DAO.QueryDef
      Dim rst As DAO.Recordset
      Dim strSpecies As String
      Dim strSpeciesEnglish As String
      Dim strSpecies_previous As String
      Dim intReturns As Integer
      Dim intRepeats As Integer
      Dim intReturnsTotal As Integer
      Dim intRepeatsTotal As Integer

530   intReturnsTotal = 0
540   intRepeatsTotal = 0

550   strSpecies_previous = ""
560   Set qdf = CurrentDb.QueryDefs("qryMBOProgramReport_Recaps")
570   qdf.Parameters("argSeason") = strSeason
580   qdf.Parameters("argYearFirst") = intYearFirst
590   qdf.Parameters("argYearLast") = intYearLast
600   qdf.Parameters("argLocation") = "MBO"
610   Set rst = qdf.OpenRecordset
620   Do While Not rst.EOF

630      strSpecies = Nz(rst("Species"))
640      strSpeciesEnglish = Nz(rst("SpeciesEnglish"))
         
650      If strSpecies <> strSpecies_previous Then
660           If strSpecies_previous <> "" Then
                  ' Process F1
                  
                  Dim intRecapsTotal As Integer
670               intRecapsTotal = intReturnsTotal + intRepeatsTotal
                  
680               If intReturnsTotal <> 0 Then
690                   .Cells(row, colReturnsTotal) = intReturnsTotal
700               End If
710               If intRepeatsTotal <> 0 Then
720                   .Cells(row, colRepeatsTotal) = intRepeatsTotal
730                End If
740               If intRecapsTotal <> 0 Then
750                   .Cells(row, colRecapsTotal) = intRecapsTotal
760               End If
770               If intRecapsTotal <> 0 Then
780                   .Cells(row, colPercentReturnsTotal) = intReturnsTotal / intRecapsTotal
790               End If
800               If intRecapsTotal <> 0 Then
810                   .Cells(row, colPercentRepeatsTotal) = intRepeatsTotal / intRecapsTotal
820               End If
                  
830               row = row + 1
840           End If
              
              ' process H1 (change of species)
              
850           intReturnsTotal = 0
860           intRepeatsTotal = 0

870           .Cells(row, colSpecies) = strSpecies
880           .Cells(row, colSpeciesEnglish) = strSpeciesEnglish
              
890           strSpecies_previous = strSpecies
900       End If
          
         ' Process detail

910      intYear = Nz(rst("YearEx"))
920      intReturns = Nz(rst("Returns"))
930      intRepeats = Nz(rst("Repeats"))
         
         Dim intRecaps As Integer
         
940      intRecaps = intReturns + intRepeats
950      intReturnsTotal = intReturnsTotal + intReturns
960      intRepeatsTotal = intRepeatsTotal + intRepeats

970      If intReturns <> 0 Then
980           .Cells(row, colReturnsFirst + (intYear - intYearFirst)) = intReturns
990       End If
1000      If intRepeats <> 0 Then
1010          .Cells(row, colRepeatsFirst + (intYear - intYearFirst)) = intRepeats
1020      End If
1030      If intRecaps <> 0 Then
1040          .Cells(row, colRecapsFirst + (intYear - intYearFirst)) = intRecaps
1050          .Cells(row, colPercentReturnsFirst + (intYear - intYearFirst)) = intReturns / intRecaps
1060         .Cells(row, colPercentRepeatsFirst + (intYear - intYearFirst)) = intRepeats / intRecaps
1070      End If

1080      rst.MoveNext
1090  Loop

1100  If strSpecies_previous <> "" Then

          ' Process F1
          
1110      intRecapsTotal = intReturnsTotal + intRepeatsTotal
          
1120      If intReturnsTotal <> 0 Then
1130          .Cells(row, colReturnsTotal) = intReturnsTotal
1140      End If
1150      If intRepeatsTotal <> 0 Then
1160          .Cells(row, colRepeatsTotal) = intRepeatsTotal
1170       End If
1180      If intRecapsTotal <> 0 Then
1190          .Cells(row, colRecapsTotal) = intRecapsTotal
1200      End If
1210      If intReturnsTotal <> 0 And intRepeatsTotal <> 0 Then
1220          .Cells(row, colPercentReturnsTotal) = intReturnsTotal / intRecapsTotal
1230      End If
1240      If intReturnsTotal <> 0 And intRepeatsTotal <> 0 Then
1250          .Cells(row, colPercentRepeatsTotal) = intRepeatsTotal / intRecapsTotal
1260      End If

1270      row = row + 1
          
          ' Process FR - nothing
          
1280  End If

1290  rst.Close
1300  Set rst = Nothing



1310  rowLast = row - 1

1320  .range(.Cells(rowFirst, colPercentReturnsFirst), .Cells(rowLast, colPercentRepeatsTotal)).NumberFormat = "0%"

1330  .range(.Cells(rowFirst - 2, colReturnsTotal), .Cells(rowLast, colReturnsTotal)).Interior.Color = RGB(200, 200, 200)
1340  .range(.Cells(rowFirst - 2, colRepeatsTotal), .Cells(rowLast, colRepeatsTotal)).Interior.Color = RGB(200, 200, 200)
1350  .range(.Cells(rowFirst - 2, colRecapsTotal), .Cells(rowLast, colRecapsTotal)).Interior.Color = RGB(200, 200, 200)
1360  .range(.Cells(rowFirst - 2, colPercentReturnsTotal), .Cells(rowLast, colPercentReturnsTotal)).Interior.Color = RGB(200, 200, 200)
1370  .range(.Cells(rowFirst - 2, colPercentRepeatsTotal), .Cells(rowLast, colPercentRepeatsTotal)).Interior.Color = RGB(200, 200, 200)

1380  .range(.Cells(rowTitle, colSpecies), .Cells(rowFirst - 1, colLast)).Interior.Color = RGB(200, 200, 200)

      ' Copy rows: 1 to rowLast  colSpecies to colLast      To    rows  rowLast + 2 ...rowLast + 1 + rowLast
      
      Dim rowTargetTitle As Long
      Dim rowTargetDataFirst As Long
      Dim rowTargetDataLast As Long
      
1390  rowTargetTitle = rowLast + 2
1400  rowTargetDataFirst = rowTargetTitle + (rowFirst - 1)
1410  rowTargetDataLast = rowTargetDataFirst + (rowLast - rowFirst)

1420  .range(.Cells(rowTargetTitle, colSpecies), .Cells(rowTargetDataFirst - 1, colLast)).Interior.Color = RGB(200, 200, 200)
      

      Dim rangeSource As Excel.range
      Dim rangeTarget As Excel.range
1430  Set rangeSource = .range(.Cells(1, colSpecies), .Cells(rowLast, colLast))
1440  Set rangeTarget = .range(.Cells(rowTargetTitle, colSpecies), .Cells(rowTargetDataLast, colLast))
1450  rangeSource.Copy Destination:=rangeTarget

      ' Sort rowFirst to rowLast   colSpecies to colLast     key = colReturnsLast   DESC

      Dim rangeData As Excel.range
1460  Set rangeData = .range(.Cells(rowFirst, colSpecies), .Cells(rowLast, colLast))
      Dim rangeKey As Excel.range
1470  Set rangeKey = .range(.Cells(rowFirst, colReturnsLast), .Cells(rowLast, colReturnsLast))
1480  rangeData.Sort key1:=rangeKey, Order1:=xlDescending


      ' Sort target data     key = colReturnsLast   DESC

1490  Set rangeData = .range(.Cells(rowTargetDataFirst, colSpecies), .Cells(rowTargetDataLast, colLast))
1500  Set rangeKey = .range(.Cells(rowTargetDataFirst, colRepeatsLast), .Cells(rowTargetDataLast, colRepeatsLast))
1510  rangeData.Sort key1:=rangeKey, Order1:=xlDescending



1520  .range(.columns(1), .columns(colLast)).AutoFit


1530      .Cells(1, 1) = "Sorted by the current report year's RETURNS"

1540      .Cells(rowTargetTitle, 1) = "Sorted by the current report year's REPEATS"


1550      End With
1560  Next

          'DD Error Handler Start
Exit_label:
1570      Exit Sub
Err_label:
1580      Select Case Err.Number
          Case Else
1590     Call LogError("basMBOProgramReport_Recaps", "MBOProgramReport_Recaps")
1600      End Select
1610      Resume Exit_label
          ' DD Error Handler End
End Sub
         
        
''---------------------------------------------------------------------------------------
'' getCol
''---------------------------------------------------------------------------------------
'
'Private Function getCol(ByVal strStatistic As String, ByVal intYear As Integer, ByVal intYearFirst As Integer, ByVal intYearLast As Integer) As Long
'
'10       On Error GoTo Err_label
'
'20        Select Case strStatistic
'          Case "Species"
'30            getCol = 1
'40        Case "Returns"
'50            getCol = 2 + (intYear - intYearFirst + 1)
'60        Case "SumReturns"
'70            getCol = 3 + (intYearLast - intYearFirst + 1)
'80        Case "Repeats"
'90            getCol = 3 + (intYearLast - intYearFirst + 1) + (intYear - intYearFirst + 1)
'100       Case "SumRepeats"
'110           getCol = 4 + 2 * (intYearLast - intYearFirst + 1)
'120       Case "Recaps"
'130           getCol = 4 + 2 * (intYearLast - intYearFirst + 1) + (intYear - intYearFirst + 1)
'140       Case "SumRecaps"
'150           getCol = 5 + 3 * (intYearLast - intYearFirst + 1)
'160       Case "PercentReturns"
'170           getCol = 5 + 3 * (intYearLast - intYearFirst + 1) + (intYear - intYearFirst + 1)
'180       Case "PercentSumReturns"
'190           getCol = 5 + 4 * (intYearLast - intYearFirst + 1)
'200       Case "PercentRepeats"
'210           getCol = 6 + 4 * (intYearLast - intYearFirst + 1) + (intYear - intYearFirst + 1)
'220       Case "PercentSumRecaps", "LastColumn"
'230           getCol = 7 + 5 * (intYearLast - intYearFirst + 1)
'240       Case Else
'250           getCol = 1
'260       End Select
'
'          'DD Error Handler Start
'Exit_label:
'270       Exit Function
'Err_label:
'280       Select Case Err.Number
'          Case Else
'290            Call LogError("basMBOProgramReport_Recaps", "getCol")
'300       End Select
'310       Resume Exit_label
'          ' DD Error Handler End
'End Function
