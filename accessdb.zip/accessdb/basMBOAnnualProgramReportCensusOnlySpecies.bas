Option Compare Database
Option Explicit

'---------------------------------------------------------------------------------------
' MBOAnnualProgramReportCensusOnlySpecies
'---------------------------------------------------------------------------------------

Public Sub MBOAnnualProgramReportCensusOnlySpecies( _
    ByVal intYear As Integer, _
    ByVal strLocation As String, _
    ByVal strProgram As String, _
    ByVal strSeason As String, _
    ByRef oExcel As Excel.Application, _
    ByRef oBook As Excel.Workbook)


10    On Error GoTo Err_label

' oExcel.Visible = True

      Dim intYearFirst As Integer
      Dim intYearLast As Integer

20    intYearFirst = 2005
30    intYearLast = intYear

      ' Create an Excel Worksheet

      Dim colSpecies As Integer
      Dim colSpeciesEnglish As Integer
      Dim colYearFirst As Integer
      Dim colYearLast As Integer

40    colSpecies = 1
50    colSpeciesEnglish = 2
60    colYearFirst = 3
70    colYearLast = colYearFirst + (intYearLast - intYearFirst)

      ' qryMBOAnnualProgramReport_CensusOnlyBySpeciesXYear_1
      ' ----------------------------------------------------
      ' For a given Season,
      ' For each Year x Species: Sum Census, Sum Captures + Observed
      ' ----------------------------------------------------
      ' tblSpecies x tblPrograms
      ' GROUP BY YearEx
      ' GROUP BY Species
      ' SUM Census
      ' NotCensus: Sum(Nz([Banded])+Nz([Returns])+Nz([Repeats])+Nz([Observed3])+Nz([Observed4])+nz([Observed]))
      ' Location = [argLocation]
      ' MonitoringProgramSeason = [argSeason]

      ' qryMBOAnnualProgramReport_CensusOnlyBySpeciesXYear_2
      ' ----------------------------------------------------
      ' For a given Season
      ' For each Year x Species, report Sum Census when Sum Captures + Observed = 0
      ' ----------------------------------------------------
      ' qryMBOAnnualProgramReport_CensusOnlyBySpeciesXYear_1 x tblSpecies
      ' Species
      ' YearEx
      ' SumOfCensus
      ' SpeciesDescriptionMBO
      ' Location = [argLocation]
      ' MonitoringProgramSeason = [argSeason]
      ' WHERE NotCensus = 0

      ' qryMBOAnnualProgramReport_CensusOnlyBySpeciesXYear_3_Crosstab
      ' -------------------------------------------------------------
      ' Crosstab of qryMBOAnnualProgramReport_CensusOnlyBySpeciesXYear_2
      ' Row: Species, SpeciesDescriptionMBO, AOUOrder (sort by AOUOrder)
      ' Column: YearEx
      ' Value: SumOfCensus

      Dim col As Long
      Dim row As Long

      Dim strSpecies As String
      Dim strSpeciesEnglish As String
      Dim intCensus As Integer


      Dim oSheet As Excel.Worksheet
80    Set oSheet = InsertSheet(oBook, strSeason)
90    oSheet.Name = strSeason & " Census Only"

100   With oSheet

110       row = 1
          ' reserve a row for a comment
120       row = row + 1
       
          ' Fill in headers
          
130       .Cells(row, colSpecies) = "Species"
140       For col = colYearFirst To colYearLast
150         .Cells(row, col) = intYearFirst + (col - colYearFirst)
160       Next

          Dim qdf As QueryDef
170       Set qdf = CurrentDb.QueryDefs("qryMBOAnnualProgramReport_CensusOnlyBySpeciesXYear_3_Crosstab")
180       qdf.Parameters("argSeason").value = strSeason
190       qdf.Parameters("argLocation").value = strLocation
          
          Dim rst As DAO.Recordset
200       Set rst = qdf.OpenRecordset

210       row = row + 1
          
220       Do While Not rst.EOF
          
230           strSpecies = Nz(rst("Species"))
240           strSpeciesEnglish = Nz(rst("SpeciesDescriptionMBO"))
              
250           .Cells(row, colSpecies) = strSpecies
260           .Cells(row, colSpeciesEnglish) = strSpeciesEnglish
              
270           On Error Resume Next
280           For intYear = intYearFirst To intYearLast
290               On Error Resume Next
300               intCensus = Nz(rst(CStr(intYear)))
310               If Err.Number = 0 Then
320                   If intCensus > 0 Then
330                       .Cells(row, colYearFirst + (intYear - intYearFirst)) = intCensus
340                       If intYear = intYearLast Then
                              ' Highlight species"
350                           .range(.Cells(row, colSpecies), .Cells(row, colSpeciesEnglish)).Interior.Color = vbYellow
360                           .Cells(row, colYearLast).Interior.Color = vbYellow
370                       End If
380                   End If
390               Else
400                   Err.Clear
410               End If
420               On Error GoTo Err_label
430           Next



440           row = row + 1
450           rst.MoveNext
460       Loop
470       rst.Close
480       Set rst = Nothing

490      .range(.columns(1), .columns(intYearLast)).AutoFit

500       .Cells(1, 1) = strSeason & " - For each Year x Species: The number of birds that were observed on Census but not captured or otherwise observed"

510      .range("C2").Select
520      oExcel.ActiveWindow.FreezePanes = True

530    End With



          'DD Error Handler Start
Exit_label:
540       Exit Sub
Err_label:
550       Select Case Err.Number
          Case Else
560      Call LogError("Module1", "MBOAnnualProgramReportCensusOnlySpecies")
570       End Select
580       Resume Exit_label
          ' DD Error Handler End
End Sub
