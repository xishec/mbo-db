Option Compare Database
Option Explicit

'---------------------------------------------------------------------------------------
' getProgram
'---------------------------------------------------------------------------------------
 
Public Function getProgram( _
    ByVal intYearReport As Integer, _
    ByVal strSeason As String) As String

10    On Error GoTo Err_label

20    getProgram = Nz(DLookup( _
          "Program", _
          "tblPrograms", _
          "[YearEx] = " & intYearReport & " AND " & _
          "[MonitoringProgramSeason] = '" & strSeason & "'"))

      'DD Error Handler Start
Exit_label:
30         Exit Function
Err_label:
40         Select Case Err.Number
           Case Else
50              Call LogError("basProgram", "getProgram")
60         End Select
70         Resume Exit_label
      'DD Error Handler End

End Function

'---------------------------------------------------------------------------------------
' getProgramPeriods
'---------------------------------------------------------------------------------------
 
Public Sub getProgramPeriods( _
    ByVal strProgram As String, _
    ByVal strSeason As String, _
    ByRef datFirstDateProgram As Date, _
    ByRef datLastDateProgram As Date, _
    ByRef intTotalPeriods As Integer)
          
10    On Error GoTo Err_label

20    datFirstDateProgram = Nz(DLookup("DateFrom", "tblPrograms", "Program = '" & strProgram & "'"))
30    If datFirstDateProgram = 0 Then Exit Sub

40    datLastDateProgram = getLastDateProgram(strProgram)

50    Select Case strSeason
      Case "Spring", "Fall"
60            intTotalPeriods = Fix((datLastDateProgram - datFirstDateProgram) / 7) + 1
70    Case "Winter"
80        intTotalPeriods = 5
90    Case Else
100       intTotalPeriods = 1
110   End Select

      'DD Error Handler Start
Exit_label:
120        Exit Sub
Err_label:
130        Select Case Err.Number
           Case Else
140             Call LogError("basProgram", "getProgramPeriods")
150        End Select
160        Resume Exit_label
      'DD Error Handler End
          
End Sub

'---------------------------------------------------------------------------------------
' getLastDateProgram
'
' The last date of a monitoring program is the date of the last capture
'---------------------------------------------------------------------------------------
 
Public Function getLastDateProgram(ByVal strProgram As Variant) As Date

10    On Error GoTo Err_label

20    getLastDateProgram = Nz(DMax("DateEx", "tblDETDaily", "[Program] = '" & strProgram & "'"))

      'DD Error Handler Start
Exit_label:
30         Exit Function
Err_label:
40         Select Case Err.Number
           Case Else
50              Call LogError("basDET", "getLastDateProgram")
60         End Select
70         Resume Exit_label
      'DD Error Handler End

End Function

'---------------------------------------------------------------------------------------
' getLastDatePeriodPost2014_v2
'
' Called from qryDETWeeklyReport
'---------------------------------------------------------------------------------------
' Given a date, we need to determine the last date of the period this date is in
'
' For Spring and Fall, that is the either 6 days after the start of the period the date is in or
' the last capture date of the program, whichever is earlier.
'
' For winter:
' If date is in October or November then the last day of Novemeber
' If the date is in December then the last day of December
' If the date is in any other month then the last day of the month

' For all other monitoring programs:
' The date of the last capture


Public Function getLastDatePeriodPost2014_v2( _
    ByVal datDateEx As Variant, _
    ByVal datDateFrom As Variant, _
    ByVal strSeason As Variant, _
    ByVal strProgram As Variant) As Date

10    On Error GoTo Err_label

      Dim intMonth As Integer
      Dim intYear As Integer
      Dim datLastDatePeriod As Date
      Dim datLastDateProgram As Date

20    datLastDatePeriod = 0
30    Select Case strSeason
      Case "Spring", "Fall"
40        datLastDatePeriod = Fix((datDateEx - datDateFrom) / 7) * 7 + datDateFrom + 6

50        datLastDateProgram = getLastDateProgram(strProgram)
60        If datLastDateProgram < datLastDatePeriod Then
70            datLastDatePeriod = datLastDateProgram
80        End If

90    Case "Winter"

100       intMonth = Month(datDateEx)
110       intYear = Year(datDateEx)

120       Select Case intMonth
          Case 10, 11
130           datLastDatePeriod = DateSerial(intYear, 12, 1) - 1
140       Case 12
150           datLastDatePeriod = DateSerial(intYear + 1, 1, 1) - 1
160       Case Else
170           datLastDatePeriod = DateSerial(intYear, intMonth + 1, 1) - 1
180       End Select ' intMonth
190   Case Else
200       datLastDatePeriod = Nz(DMax("DateEx", "tblDETDaily", "[Program] = '" & strProgram & "'"))
210       If datLastDatePeriod = 0 Then
220           datLastDatePeriod = datDateFrom
230       End If
240   End Select

250   getLastDatePeriodPost2014_v2 = datLastDatePeriod

      'DD Error Handler Start
Exit_label:
260        Exit Function
Err_label:
270        Select Case Err.Number
           Case Else
280       Call LogError("basDET", "getLastDatePeriodPost2014_v2")
290        End Select
300        Resume Exit_label
      'DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' getPeriodPost2014
'
' Called from qryDETWeeklyReport
'             qryTop10DET
'             qryTop10Banded
'---------------------------------------------------------------------------------------
' Given a date, we need to determine the period this date is in
'
' For Spring and Fall: 1 + the number of whole weeks since the start of the monitoring program
'
' For winter:
' If date is in October or November then 1
' If the date is in December then 2
' If the date is in January then 3
' If the date is in February then 4
' If the date is in March then 5

' For all other monitoring programs: 1

 
Public Function getPeriodPost2014( _
    ByVal datDateEx As Variant, _
    ByVal datDateFrom As Variant, _
    ByVal strSeason As Variant) As Integer
          
10    On Error GoTo Err_label

      Dim intMonth As Integer
      Dim intYear As Integer

20    getPeriodPost2014 = 1

30    Select Case strSeason
      Case "Spring", "Fall"
40        getPeriodPost2014 = Fix((datDateEx - datDateFrom) / 7) + 1
50    Case "Winter"

60        intMonth = Month(datDateEx)
70        intYear = Year(datDateEx)

80        Select Case intMonth
          Case 1, 2, 3
90            getPeriodPost2014 = 2 + intMonth
100       Case 10, 11
110           getPeriodPost2014 = 1
120       Case 12
130           getPeriodPost2014 = 2

140       End Select ' intMonth
150   Case Else
160       getPeriodPost2014 = 1
170   End Select ' strSeason

      'DD Error Handler Start
Exit_label:
180        Exit Function
Err_label:
190        Select Case Err.Number
           Case Else
200       Call LogError("basDET", "getPeriodPost2014")
210        End Select
220        Resume Exit_label
      'DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' getFirstAndLastDatePeriod
'---------------------------------------------------------------------------------------
 
Public Sub getFirstAndLastDatePeriod( _
    ByVal intReportYear As Integer, _
    ByVal strSeason As String, _
    ByVal datFirstDateProgram As Date, _
    ByVal datLastDateProgram As Date, _
    ByVal intPeriod As Integer, _
    ByRef datFirstDatePeriod As Date, _
    ByRef datLastDatePeriod As Date)
          
10    On Error GoTo Err_label

20    datFirstDatePeriod = datFirstDateProgram
30    datLastDatePeriod = datLastDateProgram

40    Select Case strSeason
      Case "Spring", "Fall"
50        datFirstDatePeriod = datFirstDateProgram + (intPeriod - 1) * 7
60        datLastDatePeriod = datFirstDatePeriod + 6
70    Case "Winter"
80        Select Case intPeriod
          Case 1
90            datFirstDatePeriod = datFirstDateProgram
100           datLastDatePeriod = DateSerial(intReportYear - 1, 11, 30)
110       Case 2
120           datFirstDatePeriod = DateSerial(intReportYear - 1, 12, 1)
130           datLastDatePeriod = DateSerial(intReportYear - 1, 12, 31)
140       Case 3
150           datFirstDatePeriod = DateSerial(intReportYear, 1, 1)
160           datLastDatePeriod = DateSerial(intReportYear, 1, 31)
170       Case 4
180           datFirstDatePeriod = DateSerial(intReportYear, 2, 1)
190           datLastDatePeriod = DateSerial(intReportYear, 3, 1) - 1
200       Case 5
210           datFirstDatePeriod = DateSerial(intReportYear, 3, 1)
220           datLastDatePeriod = DateSerial(intReportYear, 3, 27)
230       End Select
240   Case Else
250       datFirstDatePeriod = datFirstDateProgram
260       datLastDatePeriod = datLastDateProgram
270   End Select

      'DD Error Handler Start
Exit_label:
280        Exit Sub
Err_label:
290        Select Case Err.Number
           Case Else
300       Call LogError("basDET", "getFirstAndLastDatePeriod")
310        End Select
320        Resume Exit_label
      'DD Error Handler End
End Sub

' getStartDatePeriodPost2014
'
' Called from qryDETWeeklyReport
'             qryTop10DET
'             qryTop10Banded
'---------------------------------------------------------------------------------------
 
Public Function getStartDatePeriodPost2014( _
    ByVal datDateEx As Variant, _
    ByVal datDateFrom As Variant, _
    ByVal strSeason As Variant) As Date
          
10    On Error GoTo Err_label

      Dim intMonth As Integer
      Dim intYear As Integer
      Dim datStartDatePeriod As Date

20    datStartDatePeriod = 0
30    Select Case strSeason
      Case "Spring", "Fall"
40        datStartDatePeriod = Fix((datDateEx - datDateFrom) / 7) * 7 + datDateFrom
50    Case "Winter"

60        intMonth = Month(datDateEx)
70        intYear = Year(datDateEx)

80        Select Case intMonth
          Case 1, 2, 3, 12
90            datStartDatePeriod = DateSerial(intYear, intMonth, 1)
100       Case 10, 11
110           datStartDatePeriod = datDateFrom
120       End Select ' intMonth
130   Case Else
140       datStartDatePeriod = datDateFrom
       
150   End Select ' strSeason
160   getStartDatePeriodPost2014 = datStartDatePeriod

      'DD Error Handler Start
Exit_label:
170        Exit Function
Err_label:
180        Select Case Err.Number
           Case Else
190       Call LogError("basDET", "getStartDatePeriodPost2014")
200        End Select
210        Resume Exit_label
      'DD Error Handler End
End Function


'---------------------------------------------------------------------------------------
' getWinterPeriod
'
' Probably dead code
'---------------------------------------------------------------------------------------
 
Public Function getWinterPeriod(ByVal datDateEx) As Integer
          Dim intMonth As Integer

10    On Error GoTo Err_label

20        intMonth = Month(datDateEx)
30        Select Case intMonth
          Case 1
40            getWinterPeriod = 3
50        Case 2
60            getWinterPeriod = 4
70        Case 3 To 6
80            getWinterPeriod = 5
90        Case 6 To 11
100           getWinterPeriod = 1
110       Case 12
120           getWinterPeriod = 2
130       End Select

'DD Error Handler Start
Exit_label:
140        Exit Function
Err_label:
150        Select Case Err.Number
     Case Else
160       Call LogError("basMBOAnnualProgramReport", "getWinterPeriod")
170        End Select
180        Resume Exit_label
'DD Error Handler End
End Function
