'---------------------------------------------------------------------------------------
' Module    : basHistory
' Author    : David Davey
'---------------------------------------------------------------------------------------

Option Compare Database
Option Explicit

'---------------------------------------------------------------------------------------
' ShowHistory
'---------------------------------------------------------------------------------------
 
Public Sub ShowHistory(ByVal BandPrefix As String, ByVal BandSuffix As String)
10    On Error GoTo Err_label

      Dim strNotBypassableErr As String
      Dim strNotBypassableMsg As String

      ' Validate Prefix and Suffix

20    strNotBypassableMsg = ""

30    Call IsBandPrefixValid(BandPrefix, strNotBypassableErr)
40    strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr

50    Call IsBandSuffixValid(BandSuffix, strNotBypassableErr)
60    strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr

70    If strNotBypassableMsg <> "" Then
80        MsgBox "Cannot display the band's history since" & vbCrLf & strNotBypassableMsg
90    Else

100       DoCmd.OpenForm "frmCaptures", acNormal, , , , acHidden
          Dim frm As Form
110       Set frm = Forms("frmCaptures")
120       frm.Filter = _
              "[BandPrefix] = '" & BandPrefix & "' AND " & _
              "[BandSuffix] = '" & BandSuffix & "'"
130       frm.Tag = BandPrefix & BandSuffix
140       frm.FilterOn = True
150       frm.Visible = True
160   End If

      'DD Error Handler Start
Exit_label:
170        Exit Sub
Err_label:
180        Select Case Err.Number
           Case Else
190       Call LogError("basHistory", "ShowHistory")
200        End Select
210        Resume Exit_label
      'DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' ProcessAutoHistory
'
' If there exists a corresponding Capture record whose AutoHistory is on
' then display the history.  (If this record is a Captures record then exclude it from
'  the set of corresponding Captures records.)
'
' strForm = "Captures"  when called from frmCaptures
'           "Bands" when called from frmBands
'           "Recaptures" when called from frmRecaptures
'---------------------------------------------------------------------------------------
 
Public Sub ProcessAutoHistory(ByVal strForm As String, _
    ByVal strPrefix As String, ByVal strSuffix As String, ByVal lngIDBand As Long)

10    On Error GoTo Err_label

      Dim count As Long
      Dim strCriterion As String

20    Select Case strForm
      Case "Captures"
30        strCriterion = _
              "BandPrefix = '" & strPrefix & "' AND " & _
              "BandSuffix = '" & strSuffix & "' AND " & _
              "IDBand <> " & lngIDBand & " AND " & _
              "AutoHistory"
40    Case "Bands", "Recaptures"
50        strCriterion = _
              "BandPrefix = '" & strPrefix & "' AND " & _
              "BandSuffix = '" & strSuffix & "' AND " & _
              "AutoHistory"
60    End Select

70    count = DCount("*", "tblCaptures", strCriterion)
80    If count > 0 Then
90        Call ShowHistory(strPrefix, strSuffix)
100   End If

      'DD Error Handler Start
Exit_label:
110        Exit Sub
Err_label:
120        Select Case Err.Number
           Case Else
130             Call LogError("basHistory", "ProcessAutoHistory")
140        End Select
150        Resume Exit_label
      'DD Error Handler End
End Sub
