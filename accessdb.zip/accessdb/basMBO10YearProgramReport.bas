Option Compare Database
Option Explicit

'Const conDET As Integer = 0
'Const conBND As Integer = 1
'Const conRET As Integer = 2
'Const conREP As Integer = 3
'Const conCNS As Integer = 4
'
'Const conNonSeason As Integer = -1
'Const conWinter  As Integer = 0
'Const conSpring  As Integer = 1
'Const conSummer  As Integer = 2
'Const conFall    As Integer = 3
'Const conOwling  As Integer = 4
'Const conRTHU    As Integer = 5
'Const conNestbox As Integer = 6
'Const conSummerNestbox As Integer = 7

'---------------------------------------------------------------------------------------
' Module    : basMBO10YearProgramReport
' Author    : David Davey
'---------------------------------------------------------------------------------------

Private intSpeciesParts As Integer
Private docSpecies() As Word.Document

'---------------------------------------------------------------------------------------
' MBO10YearProgramReport
'---------------------------------------------------------------------------------------
' This code is also called when generating the abundance chart        --- Update : No generating abundance chart

Public Sub MBO10YearProgramReport( _
    ByVal intYearFirst As Integer, _
    ByVal intYearLast As Integer, _
    ByVal strLocation As String, _
    ByVal intSpeciesParts As Integer, _
    ByVal intSpeciesNumberFrom As Integer, _
    ByVal intSpeciesNumberTo As Integer, _
    ByVal strSpecies As String, _
    ByVal fDebug As Boolean, _
    Optional ByVal fAbundanceChart = False)             '   fAbundanceChart = true => generate the abundance chart

10    On Error GoTo Err_label

      '      ' Load tblMBO10YearProgramReportSpecies
      '      ' -------------------------------------
      '      ' tblDETSpecies x tblPrograms
      '      ' WHERE YearEx BETWEEN argYearFirst AND argYearLast
      '      ' WHERE Location = argLocation      "MBO"
      '      ' The records for ("UNSG","UNAC","UNEM","UNGU","UNSC","PAWA","UNPW") are excluded
      '      ' The records for ("TRFL","ALFL","WIFL") are merged into TRFL records
      '      ' The records for ("LSGO","GSGO","SNGO") are merged into SNGO records
      '      '
      '      ' Season = MonitoringProgramSeason
      '      ' YearEx
      '      ' Period: toPeriod([MonitoringProgramSeason],[DateEx],[DateFrom])
      '      ' DateEx
      '      ' Banded
      '      ' Returns
      '      ' Repeats
      '      ' Alien = Observed3
      '      ' Replacement = Observed4
      '      ' DET
      '
      '      Dim qdf As dao.QueryDef
      '
      '20    CurrentDb.Execute "DELETE * FROM tblMBO10YearProgramReportSpecies"
      '
      '      ' qryMBO10YearProgramReportSpecies_Append
      '      ' ------------------------------------------
      '      ' tblDETSpecies without the TRFL et al, SNGO et al,
      '      ' UNxx, PAWA pseudospecies.
      '      ' Only records for the years in the report.
      '      ' ------------------------------------------
      '      ' APPEND TO tblMBO10YearProgramReportSpecies
      '      ' tblDETSpecies x tblPrograms
      '      '
      '      ' WHERE YearEx BETWEEN argYearFirst AND argYearLast
      '      ' WHERE Species NOT IN ("TRFL","ALFL","WIFL","LSGO","GSGO","SNGO","UNSG","UNAC","UNEM","UNGU","UNSC","PAWA","UNPW")
      '      ' WHERE Location = argLocation
      '      ' Season = MonitoringProgramSeason
      '      ' Period: toPeriod([MonitoringProgramSeason],[DateEx],[DateFrom])
      '      ' Alien = Observed3
      '      ' Replacement = Observed4
      '      '
      '      ' SELECT YearEx, Season, DateEx, Period, Banded, Returns, Repeats, DET, Alien, Replacement
      '
      '30    Set qdf = CurrentDb.QueryDefs("qryMBO10YearProgramReportSpecies_Append")
      '40    qdf.Parameters("argLocation").value = strLocation
      '50    qdf.Parameters("argYearFirst").value = intYearFirst
      '60    qdf.Parameters("argYearLast").value = intYearLast
      '70    qdf.Execute
      '
      '      ' qryMBO10YearProgramReportSpecies_TRFL
      '      ' -------------------------------------
      '      ' tblDETSpecies x tblPrograms
      '      '
      '      ' WHERE YearEx BETWEEN argYearFirst AND argYearLast
      '      ' WHERE Species IN ("TRFL","ALFL","WIFL")
      '      ' WHERE Location = argLocation
      '      ' Season = MonitoringProgramSeason
      '      ' Period: toPeriod([MonitoringProgramSeason],[DateEx],[DateFrom])
      '      ' Alien = Observed3
      '      ' Replacement = Observed4
      '      ' GROUP BY Season, YearEx, DateEx, Period, Location
      '      ' Banded: SUM Banded
      '      ' Repeats: SUM Repeats
      '      ' Returns: SUM Returns
      '      ' DET: SUM DET
      '      ' Alien: SUM Observed3
      '      ' Replacement: SUM Observed4
      '      '
      '      ' SELECT YearEx, Season, DateEx, Period, Banded, Returns, Repeats, DET, Alien, Replacement
      '
      '      ' qryMBO10Year10YearReportSpecies_Append_TRFL
      '      ' -------------------------------------------
      '      ' APPEND TO tblMBO10YearProgramReportSpecies
      '      ' qryMBO10YearProgramReportSpecies_TRFL
      '      '
      '      ' Species = "TRFL"
      '      '
      '      ' SELECT YearEx, Season, DateEx, Period, Species, Banded, Returns, Repeats, DET, Alien, Replacement
      '
      '80    Set qdf = CurrentDb.QueryDefs("qryMBO10YearProgramReportSpecies_Append_TRFL")
      '90    qdf.Parameters("argLocation").value = strLocation
      '100   qdf.Parameters("argYearFirst").value = intYearFirst
      '110   qdf.Parameters("argYearLast").value = intYearLast
      '120   qdf.Execute
      '
      '      ' qryMBO10YearProgramReportSpecies_SNGO
      '      ' -------------------------------------
      '      ' tblDETSpecies x tblPrograms
      '      '
      '      ' WHERE YearEx BETWEEN argYearFirst AND argYearLast
      '      ' WHERE Species IN ("LSGO","GSGO","SNGO")
      '      ' WHERE Location = argLocation
      '      ' Season = MonitoringProgramSeason
      '      ' Period: toPeriod([MonitoringProgramSeason],[DateEx],[DateFrom])
      '      ' Alien = Observed3
      '      ' Replacement = Observed4
      '      ' GROUP BY Season, YearEx, DateEx, Period, Location
      '      ' Banded: SUM Banded
      '      ' Repeats: SUM Repeats
      '      ' Returns: SUM Returns
      '      ' DET: SUM DET
      '      ' Alien: SUM Observed3
      '      ' Replacement: SUM Observed4
      '      '
      '      ' SELECT YearEx, Season, DateEx, Period, Banded, Returns, Repeats, DET, Alien, Replacement
      '
      '      ' qryMBO10Year10YearReportSpecies_Append_SNGO
      '      ' -------------------------------------------
      '      ' APPEND TO tblMBO10YearProgramReportSpecies
      '      ' qryMBO10YearProgramReportSpecies_SNGO
      '      '
      '      ' Species = "SNGO"
      '      '
      '      ' SELECT YearEx, Season, DateEx, Period, Species, Banded, Returns, Repeats, DET, Alien, Replacement
      '
      '130   Set qdf = CurrentDb.QueryDefs("qryMBO10YearProgramReportSpecies_Append_SNGO")
      '140   qdf.Parameters("argLocation").value = strLocation
      '150   qdf.Parameters("argYearFirst").value = intYearFirst
      '160   qdf.Parameters("argYearLast").value = intYearLast
      '170   qdf.Execute

      '280   Call DETDaysCount_CapturesYearsCount(intYearFirst, intYearLast, intPeriodLast)


      Dim oExcel As Excel.Application
20    Set oExcel = New Excel.Application

      Dim oBook As Excel.Workbook
30    Set oBook = oExcel.Workbooks.Add

40    Call MBOProgramReport_Initialise(intYearFirst, intYearLast, strLocation, oBook)

      Dim wd As Word.Application
      Dim doc As Word.Document

50    Call WordInitialise(wd, doc)

      Dim strWhere As String

60    If Not fAbundanceChart Then
70        strWhere = _
        "[ID] IN ('Winter Seasonal','SMMP Seasonal','MAPS Seasonal','FMMP Seasonal', 'SMMP Top 10', 'FMMP Top 10') AND " & _
        "[Generate]"
80        If DCount("*", "tblMBO10YearProgramReport", strWhere) > 0 Then
              
              ' I don't recall why I process Top10 stats in the initialisation
                  
90              SysCmd acSysCmdSetStatus, "Generate Top10"
              
100             Call load_tbl10YearProgramReportSpecies_Classic(intYearFirst, intYearLast)
                  
110             CurrentDb.Execute "DELETE * FROM tblMBO10YearProgramReport_Top10"
120             Call Append_tblMBO10YearProgramReport_Top10("Spring")
130             Call Append_tblMBO10YearProgramReport_Top10("Fall")
140             Call Append_tblMBO10YearProgramReport_Top10("Winter")
150             Call Append_tblMBO10YearProgramReport_Top10("Summer")
160             Call Export_tblMBO10YearProgramReport_Top10(oExcel, oBook)
170       End If

180   End If

          Dim fValid As Boolean
190       fValid = True

      Dim range As Word.range



200   If fAbundanceChart Then
      '360       SysCmd acSysCmdSetStatus, "Abundance  Chart"
      '370       fDebug = False
      '
      '          ' Switch to landscape
      '
      '380       Set range = MoveInsertionPointToEndOfDocument(wd, doc)
      '390       range.PageSetup.Orientation = wdOrientLandscape
      '
      '          ' Set all margins to 0.79"
      '
      '400       With doc.PageSetup
      '410           .LeftMargin = doc.Application.InchesToPoints(0.5)
      '420           .RightMargin = doc.Application.InchesToPoints(0.5)
      '430           .TopMargin = doc.Application.InchesToPoints(0.79)
      '440           .BottomMargin = doc.Application.InchesToPoints(0.79)
      '450       End With
      '
      '460       Call MBO10YearProgramReportAbundance( _
      '              intYearFirst, intYearLast, strLocation, _
      '              wd, doc, oExcel, oBook, fDebug, fAbundanceChart)
      '470       Call MBO10YearProgramReportAbundance_Owling( _
      '              intYearFirst, intYearLast, strLocation, _
      '              oExcel, oBook, fDebug, fAbundanceChart)
210   Else
          
          Dim fGenerate As Boolean
          Dim strID As String
          Dim strCaptionHeading As String
          
          Dim fSpecies As Boolean    ' True iff the species appendix is generated
220       fSpecies = False
          
          Dim strSQL As String
230       strSQL = "SELECT * FROM tblMBO10YearProgramReport ORDER BY [Order]"
          Dim rst As DAO.Recordset
240       Set rst = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)
250       Do While Not rst.EOF
          
260       strID = Nz(rst("ID"))
270       strCaptionHeading = Nz(rst("CaptionHeading"))
280       fGenerate = Nz(rst("Generate"))
290       If fGenerate Then
300       SysCmd acSysCmdSetStatus, strID
310       Select Case strID
          Case "TC"
320          Call MBOProgramReportTC(wd, doc)
330        Case "Key Personnel"
340          Call WordGenerateCaption(wd, doc, "Table", strCaptionHeading, "Key personnel at MBO, 2004" & "-" & intYearLast)
350        Case "Volunteer Effort"
360          Call WordGenerateCaption(wd, doc, "Table", strCaptionHeading, "Volunteer effort at MBO during migration monitoring programs, " & intYearFirst & "-" & intYearLast)
370        Case "Map MBO"
380          Call WordGenerateCaption(wd, doc, "Figure", strCaptionHeading, "Map of McGill Bird Observatory")
390        Case "Winter Summary"
400            Call WordGenerateCaption(wd, doc, "Table", strCaptionHeading, "Winter summary statistics " & intYearFirst & "-" & intYearLast)
410            Call MBO10YearProgramReportSummary(fValid, _
                   intYearFirst, intYearLast, strLocation, "Winter", _
                   wd, doc, oExcel, oBook)
420        Case "SMMP Summary"
430            Call WordGenerateCaption(wd, doc, "Table", strCaptionHeading, "SMMP summary statistics " & intYearFirst & "-" & intYearLast)
440            Call MBO10YearProgramReportSummary(fValid, _
                   intYearFirst, intYearLast, strLocation, "Spring", _
                   wd, doc, oExcel, oBook)
450        Case "MAPS Summary"
460        Call WordGenerateCaption(wd, doc, "Table", strCaptionHeading, "Summer summary statistics " & intYearFirst & "-" & intYearLast)
470            Call MBO10YearProgramReportSummary(fValid, _
                   intYearFirst, intYearLast, strLocation, "Summer", _
                   wd, doc, oExcel, oBook)
480        Case "FMMP Summary"
490        Call WordGenerateCaption(wd, doc, "Table", strCaptionHeading, "FMMP summary statistics " & intYearFirst & "-" & intYearLast)
500            Call MBO10YearProgramReportSummary(fValid, _
                   intYearFirst, intYearLast, strLocation, "Fall", _
                   wd, doc, oExcel, oBook)
510        Case "Owling Summary"
520        Call WordGenerateCaption(wd, doc, "Table", strCaptionHeading, "Owl banding summary statistics " & intYearFirst & "-" & intYearLast)
530            Call MBO10YearProgramReportSummary(fValid, _
                   intYearFirst, intYearLast, strLocation, "Owling", _
                   wd, doc, oExcel, oBook)
540        Case "Nestlings Summary"
550        Call WordGenerateCaption(wd, doc, "Table", strCaptionHeading, "Nestling summary statistics " & intYearFirst & "-" & intYearLast)
560            Call MBO10YearProgramReportNestlingsSummary(fValid, _
                   intYearFirst, intYearLast, strLocation, _
                   wd, doc, oExcel, oBook)
570       Case "SMMP Banded Birds"
580            Call WordGenerateCaption(wd, doc, "Figure", strCaptionHeading, "Running three-day mean of the number of individuals banded daily throughout spring")
590            Call MBO10YearProgramReport3DayMeanGraph(fValid, _
                   intYearFirst, intYearLast, strLocation, "Spring", _
                   wd, doc, oExcel, oBook, "Banded Birds", fDebug)
600       Case "FMMP Banded Birds"
610            Call WordGenerateCaption(wd, doc, "Figure", strCaptionHeading, "Running three-day mean of the number of individuals banded daily throughout fall")
620            Call MBO10YearProgramReport3DayMeanGraph(fValid, _
                   intYearFirst, intYearLast, strLocation, "Fall", _
                   wd, doc, oExcel, oBook, "Banded Birds", fDebug)
630       Case "SMMP Census Species"
640            Call WordGenerateCaption(wd, doc, "Figure", strCaptionHeading, "Running three-day mean of the daily species count on census throughout spring")
650            Call MBO10YearProgramReport3DayMeanGraph(fValid, _
                   intYearFirst, intYearLast, strLocation, "Spring", _
                   wd, doc, oExcel, oBook, "Census Species", fDebug)
660        Case "FMMP Census Species"
670             Call WordGenerateCaption(wd, doc, "Figure", strCaptionHeading, "Running three-day mean of the daily species count on census throughout fall")
680             Call MBO10YearProgramReport3DayMeanGraph(fValid, _
                    intYearFirst, intYearLast, strLocation, "Fall", _
                    wd, doc, oExcel, oBook, "Census Species", fDebug)
690       Case "SMMP DET Species"
700             Call WordGenerateCaption(wd, doc, "Figure", strCaptionHeading, "Running three-day mean of the number of species observed daily throughout spring")
710             Call MBO10YearProgramReport3DayMeanGraph(fValid, _
                    intYearFirst, intYearLast, strLocation, "Spring", _
                    wd, doc, oExcel, oBook, "DET Species", fDebug)
720        Case "FMMP DET Species"
730             Call WordGenerateCaption(wd, doc, "Figure", strCaptionHeading, "Running three-day mean of the number of species observed daily throughout fall")
740             Call MBO10YearProgramReport3DayMeanGraph(fValid, _
                    intYearFirst, intYearLast, strLocation, "Fall", _
                    wd, doc, oExcel, oBook, "DET Species", fDebug)
750         Case "SMMP Banded Species"
760             Call WordGenerateCaption(wd, doc, "Figure", strCaptionHeading, "Running three-day mean of the number of species banded daily throughout spring")
770             Call MBO10YearProgramReport3DayMeanGraph(fValid, _
                    intYearFirst, intYearLast, strLocation, "Spring", _
                    wd, doc, oExcel, oBook, "Banded Species", fDebug)
780        Case "FMMP Banded Species"
790             Call WordGenerateCaption(wd, doc, "Figure", strCaptionHeading, "Running three-day mean of the number of species banded daily throughout fall")
800             Call MBO10YearProgramReport3DayMeanGraph(fValid, _
                    intYearFirst, intYearLast, strLocation, "Fall", _
                    wd, doc, oExcel, oBook, "Banded Species", fDebug)
810       Case "Winter Seasonal"
820            Call MBO10YearProgramReportSeasonal(fValid, _
                   intYearFirst, intYearLast, strLocation, "Winter", _
                   wd, doc, oExcel, oBook, fDebug)
830        Case "SMMP Seasonal"
840            Call MBO10YearProgramReportSeasonal(fValid, _
                   intYearFirst, intYearLast, strLocation, "Spring", _
                   wd, doc, oExcel, oBook, fDebug)
850         Case "MAPS Seasonal"
860            Call MBO10YearProgramReportSeasonal(fValid, _
                   intYearFirst, intYearLast, strLocation, "Summer", _
                   wd, doc, oExcel, oBook, fDebug)
870        Case "FMMP Seasonal"
880            Call MBO10YearProgramReportSeasonal(fValid, _
                   intYearFirst, intYearLast, strLocation, "Fall", _
                   wd, doc, oExcel, oBook, fDebug)
890        Case "SMMP Overview"
900            Call MBO10YearProgramReportOverview_AB( _
                   intYearFirst, intYearLast, strLocation, "Spring", _
                   wd, doc, oExcel, oBook, fDebug)
910        Case "FMMP Overview"
920            Call MBO10YearProgramReportOverview_AB( _
                   intYearFirst, intYearLast, strLocation, "Fall", _
                   wd, doc, oExcel, oBook, fDebug)
930        Case "SMMP Top 10"
940            Call MBO10YearProgramReportTop10_C(fValid, _
                   intYearFirst, intYearLast, strLocation, "Spring", _
                   wd, doc, fDebug)
950        Case "FMMP Top 10"
960            Call MBO10YearProgramReportTop10_C(fValid, _
                   intYearFirst, intYearLast, strLocation, "Fall", _
                   wd, doc, fDebug)
970         Case "Species"
980              fSpecies = True
990              Call basMBO10YearProgramReportSpecies.MBO10YearProgramReportSpecies( _
                    intYearFirst, intYearLast, _
                    wd, docSpecies(), _
                    intSpeciesParts, intSpeciesNumberFrom, intSpeciesNumberTo, strSpecies)
                  
1000        Case "Volunteers"
1010            Call MBO10YearProgramReportVolunteers(fValid, _
                    intYearFirst, intYearLast, strLocation, _
                    wd, doc, oExcel, oBook, fDebug)
          
1020        Case "Max DET Species"
1030            Call MBO10YearProgramReportMaxSpeciesDET( _
                    intYearFirst, intYearLast, strLocation, _
                    wd, doc, oExcel, oBook, fDebug)
          
1040        Case "Max Banded Species"
1050            Call MBO10YearProgramReportMaxSpeciesBanded( _
                    intYearFirst, intYearLast, strLocation, _
                    wd, doc, oExcel, oBook, fDebug)
          
1060        Case "Other Stats"
1070            Call MBO10YearProgramReportOtherStats( _
                    intYearFirst, intYearLast, strLocation, _
                    wd, doc, oExcel, oBook, fDebug)
              
1080        Case "Birds of MBO Tables"
1090            Call MBO10YearProgramReportSpeciesObservedAtMBO_Tables( _
                    intYearFirst, intYearLast, _
                    wd, doc, oExcel, oBook, fDebug)
          
1100        Case "Birds of MBO Abundance Charts"
1110             Call MBO10YearProgramReportBirdsAtMBO_AbundanceCharts( _
                    intYearFirst, intYearLast, _
                    wd, doc, oExcel, oBook, fDebug)
                
1120      Case "Encounters"
1130          Call MBO10YearProgramReportEncounters( _
                  intYearFirst, intYearLast, _
                  wd, doc, oExcel, oBook, fDebug)
          
1140    End Select
1150      End If
1160      rst.MoveNext
1170      Loop
1180      rst.Close
1190      Set rst = Nothing

1200  End If

      Dim strFolder As String
      Dim strSaveFilename As String
      Dim strSaveFilepath As String

           ' Save the Excel Workbook
           
1210  Call DeleteEndOfSeasonSheets(oExcel, oBook)

1220  On Error Resume Next
1230  Call ExcelDeleteAllButFirstWorksheet(oBook)
1240  oBook.Sheets("Sheet1").Delete
1250  On Error GoTo Err_label
       
      Dim fUserCancelled As Boolean
1260  fUserCancelled = False

      ' 1610  strFolder = GetExportFolder()

1270  strSaveFilename = _
          "MBO Multi-Year Program Report " & intYearFirst & "-" & intYearLast
1280  Call SaveAndCloseExcelWorkbookEx(oExcel, oBook, strSaveFilename, strSaveFilepath, fUserCancelled)

      '1710   MsgBox ExcelInstances() & " instances of Excel are running" & vbCrLf & _
      '             WordInstances() & " instances of Word are running"

1290  Set oBook = Nothing
1300  oExcel.Quit
1310  Set oExcel = Nothing
1320  Call Sleep(10000)

      '1430  If Not fUserCancelled Then
      '1440        Call OpenExcelWorkbook(strSaveFilepath)
      '1450  End If

1330  If fSpecies Then
1340      If strSpecies <> "" Then
          
1350          strSaveFilename = _
                  "MBO Multi-Year Program Report Species " & strSpecies & " " & intYearFirst & "-" & intYearLast
1360          Call SaveAndCloseWordDocument(wd, docSpecies(1), strSaveFilename, fValid, strSaveFilepath)
1370          DoEvents
1380          Sleep (1000)
1390          Set docSpecies(1) = Nothing
1400      Else
          
              Dim i As Integer
1410          For i = 1 To intSpeciesParts
1420              strSaveFilename = _
                      "MBO Multi-Year Program Report Species " & i & " of " & intSpeciesParts & " " & intYearFirst & "-" & intYearLast
1430              Call SaveAndCloseWordDocument(wd, docSpecies(i), strSaveFilename, fValid, strSaveFilepath)
1440              DoEvents
1450              Sleep (1000)
1460              Set docSpecies(i) = Nothing
1470          Next
1480      End If
1490  End If


1500  Call wordFinalise(wd, doc)

      ' Save the Word document

1510  strSaveFilename = _
          "MBO Multi-Year Program Report " & intYearFirst & "-" & intYearLast
1520  Call SaveAndCloseWordDocument(wd, doc, strSaveFilename, fValid, strSaveFilepath)

1530  DoEvents
1540  Sleep (1000)



1550  wd.DisplayAlerts = wdAlertsAll

1560  Set doc = Nothing
1570  wd.Quit
1580  Set wd = Nothing

      'DD Error Handler Start
Exit_label:

1590       Exit Sub
Err_label:
1600      Select Case Err.Number
          Case Else
1610     Call LogError("basMBO10YearProgramReport", "MBO10YearProgramReport")
1620       End Select
1630       Resume Exit_label
      'DD Error Handler End

End Sub



'---------------------------------------------------------------------------------------
' toPeriodTitle
'---------------------------------------------------------------------------------------
 
Public Function toPeriodTitle(ByVal strSeason As String, ByVal Period As Integer) As String
10    On Error GoTo Err_label

20        Select Case strSeason
          Case "Winter"
30            toPeriodTitle = "Winter Month " & Period & " ("
40            Select Case Period
              Case 1
50                toPeriodTitle = toPeriodTitle & "October 31 - November 30"
60            Case 2
70                toPeriodTitle = toPeriodTitle & "December 1 - 31"
80            Case 3
90            toPeriodTitle = toPeriodTitle & "January 1 - 31"
100           Case 4
110               toPeriodTitle = toPeriodTitle & "February 1 - 28"
120           Case 5
130               toPeriodTitle = toPeriodTitle & "March 1 - 27"
140           End Select
150       Case "Spring"
160           toPeriodTitle = "Spring Week " & Period & " ("
170           Select Case Period
              Case 1
180               toPeriodTitle = toPeriodTitle & "March 28 - April 3"
190           Case 2
200                   toPeriodTitle = toPeriodTitle & "April 4 - 10"
210           Case 3
220               toPeriodTitle = toPeriodTitle & "April 11 - 17"
230           Case 4
240               toPeriodTitle = toPeriodTitle & "April 18 - 24"
250           Case 5
260               toPeriodTitle = toPeriodTitle & "April 25 - May 1"
270           Case 6
280               toPeriodTitle = toPeriodTitle & "May 2 - 8"
290           Case 7
300               toPeriodTitle = toPeriodTitle & "May 9 - 15"
310           Case 8
320               toPeriodTitle = toPeriodTitle & "May 16 - 22"
330           Case 9
340               toPeriodTitle = toPeriodTitle & "May 23 - 29"
350           Case 10
360                toPeriodTitle = toPeriodTitle & "May 30 - June 5"
370           End Select
380       Case "Summer"
390           toPeriodTitle = "Summer Month " & Period & " ("
400           Select Case Period
              Case 1
410               toPeriodTitle = toPeriodTitle & "June 6 - 30"
420           Case 2
430               toPeriodTitle = toPeriodTitle & "July 1 - 31"
440           End Select
450       Case "Fall"
460           toPeriodTitle = "Fall Week " & Period & " ("
470           Select Case Period
              Case 1
480               toPeriodTitle = toPeriodTitle & "August 1 - 7"
490           Case 2
500                toPeriodTitle = toPeriodTitle & "August 8 - 14"
510           Case 3
520               toPeriodTitle = toPeriodTitle & "August 15 - 21"
530           Case 4
540               toPeriodTitle = toPeriodTitle & "August 22 - 28"
550           Case 5
560               toPeriodTitle = toPeriodTitle & "August 29 - September 4"
570           Case 6
580               toPeriodTitle = toPeriodTitle & "September 5 - 11"
590           Case 7
600               toPeriodTitle = toPeriodTitle & "September 12 - 18"
610           Case 8
620               toPeriodTitle = toPeriodTitle & "September 19 - 25"
630           Case 9
640               toPeriodTitle = toPeriodTitle & "September 26 - October 2"
650           Case 10
660                toPeriodTitle = toPeriodTitle & "October 3 - 9"
670           Case 11
680                toPeriodTitle = toPeriodTitle & "October 10 - 16"
690           Case 12
700                toPeriodTitle = toPeriodTitle & "October 17 - 23"
710           Case 13
720                toPeriodTitle = toPeriodTitle & "October 24 - 30"
730           Case 14
740                toPeriodTitle = toPeriodTitle & "October 31 - November 6"
750           End Select
760       End Select
770       toPeriodTitle = toPeriodTitle & ")"

      'DD Error Handler Start
Exit_label:
780        Exit Function
Err_label:
790        Select Case Err.Number
           Case Else
800             Call LogError("basMBO10YearProgramReport", "toPeriodTitle")
810        End Select
820        Resume Exit_label
      'DD Error Handler End
End Function


'---------------------------------------------------------------------------------------
' FullNetCoverage
'
' Called by a query
'---------------------------------------------------------------------------------------
 
Public Function FullNetCoverage(ByVal intYear As Integer, ByVal strSeason As String) As Integer

10    On Error GoTo Err_label

20    If intYear < 2005 Then
30        FullNetCoverage = 0
40    Else
      '    FullNetCoverage = 0.9 * 16 * 5 ' 16 nets
      '    Select Case intYear
      '    Case 2005
      '        Select Case strSeason
      '        Case "Spring"
      '            FullNetCoverage = 0.9 * 13 * 5 ' 13 nets
      '        Case "Fall"
      '            FullNetCoverage = 0.9 * 14 * 5 ' 14 nets
      '        End Select
      '    Case 2006
      '        Select Case strSeason
      '        Case "Spring"
      '            FullNetCoverage = 0.9 * 13 * 5 ' 13 nets
      '        Case "Fall"
      '            FullNetCoverage = 0.9 * 15 * 5 ' 15 nets
      '        End Select
      '    Case 2007
      '        FullNetCoverage = 0.9 * 15 * 5 ' 15 nets
      '    End Select

50        FullNetCoverage = 75 ' 16 nets
60        Select Case intYear
          Case 2005
70            Select Case strSeason
              Case "Spring"
80                FullNetCoverage = 60 ' 13 nets
90            Case "Fall"
100               FullNetCoverage = 65 ' 14 nets
110           End Select
120       Case 2006
130           Select Case strSeason
              Case "Spring"
140               FullNetCoverage = 60 ' 13 nets
150           Case "Fall"
160               FullNetCoverage = 70 ' 15 nets
170           End Select
180       Case 2007
190           FullNetCoverage = 70 ' 15 nets
200       End Select
210   End If

      'DD Error Handler Start
Exit_label:
220        Exit Function
Err_label:
230        Select Case Err.Number
           Case Else
240             Call LogError("basMBO10YearProgramReport", "FullNetCoverage")
250        End Select
260        Resume Exit_label
      'DD Error Handler End
    End Function

''---------------------------------------------------------------------------------------
'' Save_tblMBO10YearProgramReportSpecies
''---------------------------------------------------------------------------------------
'
'Private Sub Save_tblMBO10YearProgramReportSpecies()
'
'' Delete tblMBO10YearProgramReportSpecies_Save_Temp
'
'10    On Error GoTo Err_label
'
'20    DoCmd.SetWarnings False
'30    On Error Resume Next
'40    DoCmd.DeleteObject acTable = acDefault, "tblMBO10YearProgramReportSpecies_Save_Temp"
'50    On Error GoTo Err_label
'60    DoCmd.SetWarnings True
'
'' Copy tblMBO10YearProgramReportSpecies => tblMBO10YearProgramReportSpecies_Save_Temp
'
'70    DoCmd.CopyObject NewName:="tblMBO10YearProgramReportSpecies_Save_Temp", _
'    SourceObjectType:=acTable, _
'    SourceObjectName:="tblMBO10YearProgramReportSpecies"
'
''DD Error Handler Start
'Exit_label:
'80         Exit Sub
'Err_label:
'90         Select Case Err.Number
'     Case Else
'100       Call LogError("basMBO10YearProgramReport", "Save_tblMBO10YearProgramReportSpecies")
'110        End Select
'120        Resume Exit_label
''DD Error Handler End
'
'End Sub


''---------------------------------------------------------------------------------------
'' Restore_tblMBO10YearProgramReportSpecies
''---------------------------------------------------------------------------------------
'
'Private Sub Restore_tblMBO10YearProgramReportSpecies()
'
'' Delete tblMBO10YearProgramReportSpecies
'
'10    On Error GoTo Err_label
'
'20    DoCmd.SetWarnings False
'30    On Error Resume Next
'40    DoCmd.DeleteObject acTable = acDefault, "tblMBO10YearProgramReportSpecies"
'50    On Error GoTo Err_label
'60    DoCmd.SetWarnings True
'
'' Copy tblMBO10YearProgramReportSpecies_Save_Temp=> tblMBO10YearProgramReportSpecies
'
'70    DoCmd.CopyObject NewName:="tblMBO10YearProgramReportSpecies", _
'    SourceObjectType:=acTable, _
'    SourceObjectName:="tblMBO10YearProgramReportSpecies_Save_Temp"
'
'
''DD Error Handler Start
'Exit_label:
'80         Exit Sub
'Err_label:
'90         Select Case Err.Number
'     Case Else
'100       Call LogError("basMBO10YearProgramReport", "Restore_tblMBO10YearProgramReportSpecies")
'110        End Select
'120        Resume Exit_label
''DD Error Handler End
'
'End Sub
