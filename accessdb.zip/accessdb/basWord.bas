'---------------------------------------------------------------------------------------
' Module    : basWord
' Author    : David Davey
'---------------------------------------------------------------------------------------

Option Compare Database
Option Explicit

'Private Declare Function GetDesktopWindow Lib "user32" () As Long
'
'Private Declare Function FindWindowEx Lib "user32" Alias _
'  "FindWindowExA" (ByVal hWnd1 As Long, ByVal hWnd2 As Long, ByVal lpsz1 As String, ByVal lpsz2 As String) As Long

'---------------------------------------------------------------------------------------
' SaveAndCloseWordDocument
'---------------------------------------------------------------------------------------
 
Public Sub SaveAndCloseWordDocument( _
    ByRef oWord As Word.Application, _
    ByRef oDoc As Word.Document, _
    ByVal strBaseFilename As String, _
    ByVal fValid As Boolean, _
    ByRef strSaveFilepath As String)

10    On Error GoTo Err_label

      Dim strFolder As String
      Dim strSaveFilename As String

20    If fValid Then

30        strFolder = GetExportFolder()
          
40        strSaveFilename = strBaseFilename & _
              " generated " & _
               Format(Now, "yyyy-mm-dd hh\hnn") & _
              ".docx"
          
50        strSaveFilepath = FileSaveDialogWord(strSaveFilename, strFolder, "")
          
60        If strSaveFilepath <> "" Then
65            DoEvents
66            Sleep (1000)
70            oDoc.SaveAs strSaveFilepath
80            oDoc.Close saveChanges:=wdSaveChanges
90            strFolder = FolderFromPath(strSaveFilepath)
100           Call PutExportFolder(strFolder)
110       Else
120           oDoc.Close saveChanges:=wdDoNotSaveChanges
130       End If

140   Else
150       oDoc.Close saveChanges:=wdDoNotSaveChanges
160   End If


      'DD Error Handler Start
Exit_label:
170        Exit Sub
Err_label:
180        Select Case Err.Number
           Case Else
190       Call LogError("basWord", "SaveAndCloseWordDocument", "Filename = " & strSaveFilename)
200        End Select
210        Resume Exit_label
      'DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' OpenWordDocument
'---------------------------------------------------------------------------------------
 
Public Sub OpenWordDocument( _
    ByVal strFilepath As String, _
    Optional ByVal fPrompt As Boolean = True)

10    On Error GoTo Err_label

      Dim intResponse As Integer
      Dim fOpen As Boolean

20    If strFilepath = "" Then GoTo Exit_label

30    fOpen = True

40    If fPrompt Then
50        intResponse = MsgBox("Export completed" & vbCrLf & vbCrLf & _
                  strFilepath & vbCrLf & vbCrLf & _
                  "Do you wish to open the Word document?", _
                  vbYesNo, "Word Export")
60        fOpen = (intResponse = vbYes)
70    End If

80    If Not fOpen Then GoTo Exit_label

      ' Open Excel file

      Dim strShellCommand As String
90    strShellCommand = "cmd /c " & """" & strFilepath & """"

      'Call Shell(strShellCommand)   --- does not wait

      Dim objShell As WshShell
100   Set objShell = New WshShell
      Dim result As Integer
110   result = objShell.Run(strShellCommand, 0, True)

      'DD Error Handler Start
Exit_label:
120        Exit Sub
Err_label:
130        Select Case Err.Number
           Case Else
140       Call LogError("basWord", "OpenWordDocument")
150        End Select
160        Resume Exit_label
      'DD Error Handler End
          
End Sub

'---------------------------------------------------------------------------------------
' WordInstances
'
' CAVEAT: This also counts instances of Outlook !
'---------------------------------------------------------------------------------------
 
Public Function WordInstances() As Long
          Dim hWndDesk As Variant   ' Long on 32-bit; LongPtr on 64-bit
          Dim hWndXL As Variant     ' Long on 32-bit; LongPtr on 64-bit

          'Get a handle to the desktop
10    On Error GoTo Err_label

20        hWndDesk = GetDesktopWindow

30        Do
              'Get the next Word window
40            hWndXL = FindWindowEx(GetDesktopWindow, hWndXL, _
                "OpusApp", vbNullString)

              'If we got one, increment the count
50            If hWndXL > 0 Then
60                WordInstances = WordInstances + 1
70            End If

              'Loop until we've found them all
80        Loop Until hWndXL = 0

      'DD Error Handler Start
Exit_label:
90         Exit Function
Err_label:
100        Select Case Err.Number
           Case Else
110             Call LogError("Form_frmMaintenance", "WordInstances")
120        End Select
130        Resume Exit_label
      'DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' MoveInsertionPointToEndOfDocument
' Returns a range for the insertion point (= Selection)
'---------------------------------------------------------------------------------------
 
Public Function MoveInsertionPointToEndOfDocument(ByRef wd As Word.Application, ByRef doc As Word.Document) As Word.range
10    On Error GoTo Err_label

      'doc.Characters.Last.Select
      'wd.Selection.Collapse
      'Set MoveInsertionPointToEndOfDocument = wd.Selection.range

20    wd.Selection.EndKey unit:=wdStory
30    wd.Selection.Collapse wdCollapseEnd
40    Set MoveInsertionPointToEndOfDocument = wd.Selection.range

      'DD Error Handler Start
Exit_label:
50         Exit Function
Err_label:
60         Select Case Err.Number
           Case Else
70              Call LogError("Form_frmDevelopersTests", "MoveInsertionPointToEndOfDocument")
80         End Select
90         Resume Exit_label
      'DD Error Handler End
End Function


'---------------------------------------------------------------------------------------
' StyleExists
'---------------------------------------------------------------------------------------
' Determines whether or not the target style exists in the
' active document.

Public Function StyleExists(ByRef doc As Word.Document, ByVal strStyleName As String) As Boolean

10    On Error GoTo Err_label

      Dim objStyle As Word.Style

20    StyleExists = False
30    For Each objStyle In doc.Styles
40        If objStyle.NameLocal = strStyleName Then
50            StyleExists = True
60            Exit For
70        End If
80    Next objStyle

      'DD Error Handler Start
Exit_label:
90         Exit Function
Err_label:
100        Select Case Err.Number
           Case Else
110             Call LogError("basWord", "StyleExists")
120        End Select
130        Resume Exit_label
      'DD Error Handler End

End Function
