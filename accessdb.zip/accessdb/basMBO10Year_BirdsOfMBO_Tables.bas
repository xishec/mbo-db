'---------------------------------------------------------------------------------------
' Module: basMBO10Year_BirdsOfMBO_Tables
' Author: David Davey
'---------------------------------------------------------------------------------------

Option Compare Database
Option Explicit

Const conWinter  As Integer = 0
Const conSpring  As Integer = 1
Const conSummer  As Integer = 2
Const conFall    As Integer = 3

Const conAllSeasons As Integer = 4

Private conLastSpeciesGroup  As Integer               ' loaded in MBO10YearProgramReportSpeciesObservedAtMBO_Tables()
Private conAllSpeciesGroups As Integer                ' loaded in MBO10YearProgramReportSpeciesObservedAtMBO_Tables()

' Statistics

Const conSpeciesObservedAnnually As Integer = 0
Const conSpeciesObservedTotal As Integer = 1
Const conIndividualsObserved As Integer = 2
Const conSpeciesBanded As Integer = 3
Const conIndividualsBanded As Integer = 4

Private lngStats() As Long                            ' longStats( intStatistic 0 to 4, intSeason 0 to 4, intSpeciesgroup 1 to conAllSpeciesGroups)
                                                      ' the intSeason = 4 indesx is used for All Seasons
                                                      ' the conAllSpeciesGroup index is used for All Species Groups

' ------------------------------------------------------------------------------------------
' tblMBO10Year_BirdsOfMBO_Temp
' ------------------------------------------------------------------------------------------
' YearEx
' Season
' SpeciesGroup
' Species
' Banded
' DET
' ------------------------------------------------------------------------------------------

Public Sub MBO10YearProgramReportSpeciesObservedAtMBO_Tables( _
    ByVal intYearFirst As Integer, ByVal intYearLast As Integer, _
    ByRef wd As Word.Application, ByRef doc As Word.Document, _
    ByRef oExcel As Excel.Application, ByRef oBook As Excel.Workbook, _
    ByVal fDebug As Boolean)
          
10    On Error GoTo Err_label

      Dim range As Word.range
      Dim intSeason As Integer

20    conLastSpeciesGroup = DMax("ID", "tblMBO10Year_SpeciesGroups_SpeciesObservedAtMBO", "True")
30    conAllSpeciesGroups = conLastSpeciesGroup + 1

40    SysCmd acSysCmdSetStatus, "BirdsOfMBO - Load tables"

50    Call Load_tbl15YearReport_BirdsOfMBO_DET_Temp(intYearFirst, intYearLast)
60    Call Load_tbl15YearReport_BirdsOfMBO_Banded_Temp(intYearFirst, intYearLast)

70    SysCmd acSysCmdSetStatus, "BirdsOfMBO - Calculate statistics"

80    Call Calculate_statistics(intYearFirst, intYearLast)

90    Call AdjustSpeciesStatsForSuperspecies

100   SysCmd acSysCmdSetStatus, "BirdsOfMBO - Word output"

110   Set range = MoveInsertionPointToEndOfDocument(wd, doc)
120   Call WordGenerateTableBirdsOfMBO(doc, range, fAllSpeciesGroups:=True)

130   With range.Tables(1)

140       For intSeason = 0 To 3
150           .Cell(2, intSeason + 2).range.Text = lngStats(conSpeciesObservedAnnually, intSeason, conAllSpeciesGroups)
160           .Cell(3, intSeason + 2).range.Text = lngStats(conSpeciesObservedTotal, intSeason, conAllSpeciesGroups)
170           .Cell(4, intSeason + 2).range.Text = lngStats(conIndividualsObserved, intSeason, conAllSpeciesGroups)
180           .Cell(5, intSeason + 2).range.Text = lngStats(conSpeciesBanded, intSeason, conAllSpeciesGroups)
190           .Cell(6, intSeason + 2).range.Text = lngStats(conIndividualsBanded, intSeason, conAllSpeciesGroups)
200       Next

210       .Cell(2, 6).range.Text = lngStats(conSpeciesObservedAnnually, conAllSeasons, conAllSpeciesGroups)
220       .Cell(3, 6).range.Text = lngStats(conSpeciesObservedTotal, conAllSeasons, conAllSpeciesGroups)
230       .Cell(4, 6).range.Text = lngStats(conIndividualsObserved, conAllSeasons, conAllSpeciesGroups)
240       .Cell(5, 6).range.Text = lngStats(conSpeciesBanded, conAllSeasons, conAllSpeciesGroups)
250       .Cell(6, 6).range.Text = lngStats(conIndividualsBanded, conAllSeasons, conAllSpeciesGroups)
          
260   End With

      Dim intSpeciesGroup As Integer

270   For intSpeciesGroup = 1 To conLastSpeciesGroup

280       Set range = MoveInsertionPointToEndOfDocument(wd, doc)
290       range.InsertAfter ""
300       range.InsertParagraphAfter
          
          Dim strSpeciesGroup
310       strSpeciesGroup = DLookup("SpeciesGroup", "tblMBO10Year_SpeciesGroups_SpeciesObservedAtMBO", "ID = " & intSpeciesGroup)
320       Set range = MoveInsertionPointToEndOfDocument(wd, doc)
330       range.InsertAfter CStr(intSpeciesGroup) & " - " & strSpeciesGroup
340       range.InsertParagraphAfter
          
350       Set range = MoveInsertionPointToEndOfDocument(wd, doc)
360       Call WordGenerateTableBirdsOfMBO(doc, range)
          
370       With range.Tables(1)
          
380           For intSeason = 0 To 3
          
390               .Cell(2, intSeason + 2).range.Text = lngStats(conSpeciesObservedAnnually, intSeason, intSpeciesGroup) & strPercentage(conSpeciesObservedAnnually, intSeason, intSpeciesGroup)
400               .Cell(3, intSeason + 2).range.Text = lngStats(conSpeciesObservedTotal, intSeason, intSpeciesGroup) & strPercentage(conSpeciesObservedTotal, intSeason, intSpeciesGroup)
410               .Cell(4, intSeason + 2).range.Text = lngStats(conIndividualsObserved, intSeason, intSpeciesGroup) & strPercentage(conIndividualsObserved, intSeason, intSpeciesGroup)
420               .Cell(5, intSeason + 2).range.Text = lngStats(conSpeciesBanded, intSeason, intSpeciesGroup) & strPercentage(conSpeciesBanded, intSeason, intSpeciesGroup)
430               .Cell(6, intSeason + 2).range.Text = lngStats(conIndividualsBanded, intSeason, intSpeciesGroup) & strPercentage(conIndividualsBanded, intSeason, intSpeciesGroup)
440           Next
          
450           .Cell(2, 6).range.Text = lngStats(conSpeciesObservedAnnually, conAllSeasons, intSpeciesGroup) & strPercentage(conSpeciesObservedAnnually, conAllSeasons, intSpeciesGroup)
460           .Cell(3, 6).range.Text = lngStats(conSpeciesObservedTotal, conAllSeasons, intSpeciesGroup) & strPercentage(conSpeciesObservedTotal, conAllSeasons, intSpeciesGroup)
470           .Cell(4, 6).range.Text = lngStats(conIndividualsObserved, conAllSeasons, intSpeciesGroup) & strPercentage(conIndividualsObserved, conAllSeasons, intSpeciesGroup)
480           .Cell(5, 6).range.Text = lngStats(conSpeciesBanded, conAllSeasons, intSpeciesGroup) & strPercentage(conSpeciesBanded, conAllSeasons, intSpeciesGroup)
490           .Cell(6, 6).range.Text = lngStats(conIndividualsBanded, conAllSeasons, intSpeciesGroup) & strPercentage(conIndividualsBanded, conAllSeasons, intSpeciesGroup)
              
500       End With

510   Next

520   SysCmd acSysCmdSetStatus, "BirdsOfMBO - Excel output"

530   Call ExcelReport(oBook, intYearFirst, intYearLast, "DET")
540   Call ExcelReport(oBook, intYearFirst, intYearLast, "Banded")

550   SysCmd acSysCmdClearStatus

          'DD Error Handler Start
Exit_label:
560       Exit Sub
Err_label:
570       Select Case Err.Number
          Case Else
580      Call LogError("basMBO10YearProgramReportSpeciesObservedAtMBO_Tables", "MBO10YearProgramReportSpeciesObservedAtMBO_Tables")
590       End Select
600       Resume Exit_label
          ' DD Error Handler End
          
End Sub

'---------------------------------------------------------------------------------------
' AdjustSpeciesStatsForSuperspecies
'---------------------------------------------------------------------------------------

Private Sub AdjustSpeciesStatsForSuperspecies()

10       On Error GoTo Err_label
         
      Dim lngAnyArr(0 To 1, 0 To 4, 0 To 5) As Long          ' intStat, intSeason, intSpecies                          intSeason 4 = All Seasons

      Dim intSeason As Integer
      Dim intSpecies As Integer
      Dim intStat As Integer

      Dim strStatArr As Variant
20    strStatArr = Array("DET", "Banded")

      Const conDET = 0
      Const conBanded = 1

      Dim strSeasonArr As Variant
30    strSeasonArr = Array("Winter", "Spring", "Summer", "Fall")

      Dim strSpeciesArr As Variant
40    strSpeciesArr = Array("USCA", "LESC", "GRSC", "TRFL", "WIFL", "ALFL")

      Const conUSCA = 0
      Const conLESC = 1
      Const conGRSC = 2
      Const conTRFL = 3
      Const conWIFL = 4
      Const conALFL = 5

      Const conWaterfowl = 1
      Const conFlycatchers = 10

      Dim strWhere As String

      ' DET - by season

50    For intSeason = 0 To 3
60        For intSpecies = 0 To 5
70            strWhere = "[Season] = '" & strSeasonArr(intSeason) & "' AND [Species] = '" & strSpeciesArr(intSpecies) & "'"
80            lngAnyArr(conDET, intSeason, intSpecies) = Nz(DSum("DET", "tbl15YearReport_BirdsOfMBO_DET_Temp", strWhere))
90        Next
100   Next

      ' DET - by All Seasons

110   For intSpecies = 0 To 5
120       lngAnyArr(conDET, 4, intSpecies) = Nz(DSum("DET", "tbl15YearReport_BirdsOfMBO_DET_Temp", "[Species] = '" & strSpeciesArr(intSpecies) & "'"))
130   Next

      ' Banded - by Report Season

140   For intSeason = 0 To 3
150       For intSpecies = 0 To 5
160           strWhere = "[Season] = '" & strSeasonArr(intSeason) & "' AND [Species] = '" & strSpeciesArr(intSpecies) & "'"
170           lngAnyArr(conBanded, intSeason, intSpecies) = Nz(DSum("Banded", "tbl15YearReport_BirdsOfMBO_Banded_Temp", strWhere))
180       Next
190   Next

      ' Banded - by All Seasons

200   For intSpecies = 0 To 5
210       lngAnyArr(conBanded, 4, intSpecies) = Nz(DSum("Banded", "tbl15YearReport_BirdsOfMBO_Banded_Temp", "[Species] = '" & strSpeciesArr(intSpecies) & "'"))
220   Next


      ' Adjust species counts for USCA

230   For intSeason = 0 To 4
240       If lngAnyArr(conDET, intSeason, conUSCA) > 0 And lngAnyArr(conDET, intSeason, conLESC) = 0 And lngAnyArr(conDET, intSeason, conGRSC) = 0 Then
250           lngStats(conSpeciesObservedTotal, intSeason, conWaterfowl) = lngStats(conSpeciesObservedTotal, intSeason, conWaterfowl) + 1
260           lngStats(conSpeciesObservedTotal, intSeason, conAllSpeciesGroups) = lngStats(conSpeciesObservedTotal, intSeason, conAllSpeciesGroups) + 1
270       End If
280   Next

290   For intSeason = 0 To 4
300       If lngAnyArr(conBanded, intSeason, conUSCA) > 0 And lngAnyArr(conBanded, intSeason, conLESC) = 0 And lngAnyArr(conBanded, intSeason, conGRSC) = 0 Then
310           lngStats(conSpeciesBanded, intSeason, conWaterfowl) = lngStats(conSpeciesBanded, intSeason, conWaterfowl) + 1
320           lngStats(conSpeciesBanded, intSeason, conAllSpeciesGroups) = lngStats(conSpeciesBanded, intSeason, conAllSpeciesGroups) + 1
330       End If
340   Next
              
      ' Adjust species counts for TRFL

350   For intSeason = 0 To 4
360       If lngAnyArr(conDET, intSeason, conTRFL) > 0 And lngAnyArr(conDET, intSeason, conWIFL) = 0 And lngAnyArr(conDET, intSeason, conALFL) = 0 Then
370           lngStats(conSpeciesObservedTotal, intSeason, conFlycatchers) = lngStats(conSpeciesObservedTotal, intSeason, conFlycatchers) + 1
380           lngStats(conSpeciesObservedTotal, intSeason, conAllSpeciesGroups) = lngStats(conSpeciesObservedTotal, intSeason, conAllSpeciesGroups) + 1
390       End If
400   Next

410   For intSeason = 0 To 4
420       If lngAnyArr(conBanded, intSeason, conTRFL) > 0 And lngAnyArr(conBanded, intSeason, conWIFL) = 0 And lngAnyArr(conBanded, intSeason, conALFL) = 0 Then
430           lngStats(conSpeciesBanded, intSeason, conFlycatchers) = lngStats(conSpeciesBanded, intSeason, conFlycatchers) + 1
440           lngStats(conSpeciesBanded, intSeason, conAllSpeciesGroups) = lngStats(conSpeciesBanded, intSeason, conAllSpeciesGroups) + 1
450       End If
460   Next


          'DD Error Handler Start
Exit_label:
470       Exit Sub
Err_label:
480       Select Case Err.Number
          Case Else
490            Call LogError("basMBO10Year_BirdsOfMBO_Tables", "AdjustSpeciesStatsForSuperspecies")
500       End Select
510       Resume Exit_label
          ' DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' ExcelReport
'
' strFLD = "DET" or "Banded"
'---------------------------------------------------------------------------------------

Private Sub ExcelReport(ByRef oBook As Excel.Workbook, ByVal intYearFirst As Integer, ByVal intYearLast As Integer, ByVal strFLD As String)

10    On Error GoTo Err_label

      Dim oSheet As Excel.Worksheet


20    Set oSheet = oBook.Worksheets.Add(After:=oBook.Worksheets(oBook.Worksheets.count))
30    oSheet.Name = "BirdsOfMBO_" & strFLD

      Dim strSQL As String
      Dim rst As DAO.Recordset
      Dim intYearEx As Integer
      Dim strSeason As String
      Dim intSpeciesGroup As Integer
      Dim lngStat As Long
      Dim row As Long
      Dim col As Long
      Dim strSpecies As String

40    row = 3

      Dim colDataFirst As Long
      Dim colDataLast As Long
50    colDataFirst = 5
60    colDataLast = intYearLast - intYearFirst + 5

      Dim intNumYears As Integer
70    intNumYears = intYearLast - intYearFirst + 1

      Dim intCountYears As Integer
      Dim intCountAllYears As Integer
      Dim intCountAnyYears As Integer

80    intCountAllYears = 0
90    intCountAnyYears = 0
100   intCountYears = 0

      Dim cnt As Integer
      
110   SysCmd acSysCmdSetStatus, "BirdsOfMBO - Excel " & strFLD & " output"

120   With oSheet

130   For intYearEx = intYearFirst To intYearLast
140     .Cells(2, intYearEx - intYearFirst + 5) = intYearEx
150   Next

160   .Cells(2, colDataLast + 1) = "All"
170   .Cells(2, colDataLast + 2) = "Any"

      ' qry15YearReport_BirdsOfMBO_Tables_DET_Excel
      ' ----------------------------------------------------------------------------------------------------------
      ' => BirdsOfMBO DET worksheet
      ' Report years, MBO-site, Big4 MP, exclude UNAC, UNEM, UNGU, HYWA, include TRFL, USCA, nerge SNGO, merge PAWA
      ' -----------------------------------------------------------------------------------------------------------
      ' tbl15YearReport_BirdsOfMBO_DET_Temp x tblSpecies
      '
      ' WHERE Species NOT IN ("UNAC","UNEM","UNGU","HYWA")
      ' WHERE PseudoSpeciesType <> "Hybrid"
      '
      ' intSeason: toIntSeasonFromStrSeason(Season)
      '
      ' GROUP BY SpeciesGroup, intSeason, Season, Species, YearEx
      ' DET: SUM DET          HAVING SUM DET > 0
      '
      ' ORDER BY SpeciesGroup, intSeason, AOUOrder
      '
      ' Report SpeciesGroup, Season, Species, YearEx, DET

      ' qry15YearReport_BirdsOfMBO_Tables_Banded_Excel
      ' ----------------------------------------------------------
      ' tbl15YearReport_BirdsOfMBO_Banded_Temp x tblSpecies
      
      ' WHERE Species NOT IN ("UNAC","UNEM","UNGU","HYWA")
      ' WHERE PseudoSpeciesType <> "Hybrid"
      
      ' intSeason: toIntSeasonFromStrSeason(Season)

      ' GROUP BY SpeciesGroup, intSeason, Season, Species, YearEx
      ' Banded: SUM Banded          HAVING SUM Banded > 0
      '
      ' ORDER BY SpeciesGroup, intSeason, AOUOrder
      '
      ' Report SpeciesGroup, Season, Species, YearEx, Banded


180   If strFLD = "DET" Then
190       strSQL = "qry15YearReport_BirdsOfMBO_Tables_DET_Excel"
200   Else
210       strSQL = "qry15YearReport_BirdsOfMBO_Tables_Banded_Excel"
220   End If

      ' L1 is the outermost level (except for FR)
      '
      ' strSpeciesGroup is L1
      ' strSeason is L2
      ' strSpecies is L3

      Dim intSpeciesGroup_previous As Integer
      Dim strSeason_previous As String
      Dim strSpecies_previous As String

230   Set rst = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)

240   If Not rst.EOF Then

          ' get L1, L2, L3, details
          
250       intSpeciesGroup = Nz(rst("SpeciesGroup"))
260       strSeason = Nz(rst("Season"))
270       strSpecies = Nz(rst("Species"))
280       intYearEx = Nz(rst("YearEx"))
          
290       If strFLD = "DET" Then
300           lngStat = Nz(rst("DET"))
310       Else
320           lngStat = Nz(rst("Banded"))
330       End If

      '    HR - do nothing
      '    H1 - do nothing
      '    H2 - reset the counters intCountAllYears, intCountAnyYears; write strGroupSpecies, strSeason, strSpecies; colour super- and sub-species

340        intCountAllYears = 0
350        intCountAnyYears = 0
           
360        .Cells(row, 1) = strFLD
370        .Cells(row, 2) = intSpeciesGroup
380        .Cells(row, 3) = strSeason
390        .Cells(row, 4) = strSpecies
           
400        Select Case strSpecies
           Case "TRFL", "USCA"
410            .range(.Cells(row, 1), .Cells(row, colDataLast)).Interior.Color = vbYellow
420        Case "WIFL", "ALFL", "LESC", "GRSC"
430            .range(.Cells(row, 1), .Cells(row, colDataLast)).Interior.Color = vbGreen
440        End Select
           
                          
           ' H3 - reset the counter intCountYears; write strGroupSpecies, strSeason, strSpecies; colour super- and sub-species

450        intCountYears = 0

460        .Cells(row, 1) = strFLD
470        .Cells(row, 2) = intSpeciesGroup
480        .Cells(row, 3) = strSeason
490        .Cells(row, 4) = strSpecies
          
500        Select Case strSpecies
           Case "TRFL", "USCA"
510            .range(.Cells(row, 1), .Cells(row, colDataLast + 3)).Interior.Color = vbYellow
520        Case "WIFL", "ALFL", "LESC", "GRSC"
530            .range(.Cells(row, 1), .Cells(row, colDataLast + 3)).Interior.Color = vbGreen
540        End Select
        
      '    Detail - write lngStat to col determined by intYeaEx
          
550       If lngStat > 0 Then
560           .Cells(row, intYearEx - intYearFirst + 5) = lngStat
570           intCountYears = intCountYears + 1
580       End If
590       strSpecies_previous = strSpecies
600       strSeason_previous = strSeason
610       intSpeciesGroup_previous = intSpeciesGroup

620        rst.MoveNext
           
630        Do While Not rst.EOF

      '        get L1, L2, L3, details

640           intSpeciesGroup = Nz(rst("SpeciesGroup"))
650           strSeason = Nz(rst("Season"))
660           strSpecies = Nz(rst("Species"))
670           intYearEx = Nz(rst("YearEx"))
680           If strFLD = "DET" Then
690               lngStat = Nz(rst("DET"))
700           Else
710               lngStat = Nz(rst("Banded"))
720           End If

730           If intSpeciesGroup <> intSpeciesGroup_previous Or strSeason <> strSeason_previous Or strSpecies <> strSpecies_previous Then
              
              '    F3 - update intCountAllYears, intCountAnyYears; newline
                      
740                If intCountYears = intNumYears Then
750                    intCountAllYears = intCountAllYears + 1
760                End If
                   
                  
770                If intCountYears > 0 Then
780                    intCountAnyYears = intCountAnyYears + 1
790                End If
800                row = row + 1

810               If intSpeciesGroup <> intSpeciesGroup_previous Or strSeason <> strSeason_previous Then
                  
                  '    F2 - write the counters intCountAllYears, intCountAnyYears newline
                  
820                   .Cells(row, colDataLast + 1) = intCountAllYears
830                   .Cells(row, colDataLast + 2) = intCountAnyYears
840                   row = row + 1

850                   If intSpeciesGroup <> intSpeciesGroup_previous Then
                      
                      '   F1 - do nothing
                      '   H1 - do nothing

860                   End If
                      
                  '   H2 - reset the counters intCountAllYears, intCountAnyYears
          
870                    intCountAllYears = 0
880                    intCountAnyYears = 0
                       
890               End If
                   
                  '   H3 - reset the counter intCountYears; write strGroupSpecies, strSeason, strSpecies; colour super- and sub-species
                  
900               intCountYears = 0
                  
910               .Cells(row, 1) = strFLD
920               .Cells(row, 2) = intSpeciesGroup
930               .Cells(row, 3) = strSeason
940               .Cells(row, 4) = strSpecies
                  
950               Select Case strSpecies
                  Case "TRFL", "USCA"
960                   .range(.Cells(row, 1), .Cells(row, colDataLast)).Interior.Color = vbYellow
970               Case "WIFL", "ALFL", "LESC", "GRSC"
980                   .range(.Cells(row, 1), .Cells(row, colDataLast)).Interior.Color = vbGreen
990               End Select
       
1000              strSpecies_previous = strSpecies
1010              strSeason_previous = strSeason
1020              intSpeciesGroup_previous = intSpeciesGroup
1030           End If
               
      '        D - write lngStat, update intCountYears

1040           If lngStat > 0 Then
1050              .Cells(row, intYearEx - intYearFirst + 5) = lngStat
1060              intCountYears = intCountYears + 1
1070           End If

1080           rst.MoveNext
1090       Loop
           
      '    F3 - update intCountAllYears, intCountAnyYears; newline
              
1100       If intCountYears = intNumYears Then
1110           intCountAllYears = intCountAllYears + 1
1120       End If
           
          
1130       If intCountYears > 0 Then
1140           intCountAnyYears = intCountAnyYears + 1
1150       End If
1160       row = row + 1

      '    F2 - write the counters intCountAllYears, intCountAnyYears, newline

1170      .Cells(row, colDataLast + 1) = intCountAllYears
1180      .Cells(row, colDataLast + 2) = intCountAnyYears
1190      row = row + 1

      '    F1 - do nothing
      '    FR - do nothing
          
1200  End If

1210  .range(.columns(1), .columns(colDataLast + 2)).AutoFit

1220  If strFLD = "DET" Then
1230      .Cells(1, 1) = "Report years, MBO-site, Winter SMMP MAPS FMMP MPs, exclude UNAC, UNEM, UNGU, hybrids, include TRFL, USCA, merge SNGO, merge PAWA"
1240  Else
1250      .Cells(1, 1) = "Report years, MBO-site, All MBO-site MPs, exclude UNAC, UNEM, UNGU, hybrids, include TRFL, USCA, merge SNGO, merge PAWA"
1260  End If

1270  .range("A3").Select
1280  oBook.Application.ActiveWindow.FreezePanes = True

1290  End With

          'DD Error Handler Start
Exit_label:
1300      Exit Sub
Err_label:
1310      Select Case Err.Number
          Case Else
1320           Call LogError("basMBO10Year_BirdsOfMBO_Tables", "ExcelReport")
1330      End Select
1340      Resume Exit_label
          ' DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' strPercentage
'---------------------------------------------------------------------------------------

Private Function strPercentage(intStat, intSeason, intSpeciesGroup) As String
Dim dbl As Double

On Error GoTo Err_label

If lngStats(intStat, intSeason, conAllSpeciesGroups) > 0 Then
    dbl = 100# * lngStats(intStat, intSeason, intSpeciesGroup) / lngStats(intStat, intSeason, conAllSpeciesGroups)
    strPercentage = " (" & FormatNumberEnglish(dbl, 1) & "%)"
Else
    strPercentage = ""
End If

    'DD Error Handler Start
Exit_label:
    Exit Function
Err_label:
    Select Case Err.Number
    Case Else
         Call LogError("basMBO10Year_BirdsOfMBO_Tables", "strPercentage")
    End Select
    Resume Exit_label
    ' DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' WordGenerateTableBirdsOfMBO
'---------------------------------------------------------------------------------------
' entry:  range = a collapsed range that is the insertion point for the table
' exit:   range = range that includes the table
'
' I will need one of these for the "All species groups" table, and ' one for each species group

Private Sub WordGenerateTableBirdsOfMBO( _
    ByRef doc As Word.Document, _
    ByRef range As Word.range, _
    Optional ByVal fAllSpeciesGroups As Boolean = False)

On Error GoTo Err_label

Const conNumRows As Integer = 6

Dim row As Integer
Dim col As Integer

doc.Tables.Add range:=range, NumRows:=conNumRows, NumColumns:=6
    
range.Expand (wdTable)
With range.Tables(1)

    .Borders.InsideLineStyle = wdLineStyleSingle
    .Borders.OutsideLineStyle = wdLineStyleSingle
    
    .range.Style = "ddData"
    .LeftPadding = doc.Application.InchesToPoints(0#)
    .RightPadding = doc.Application.InchesToPoints(0#)
    .TopPadding = doc.Application.InchesToPoints(0.02)
    
    ' Left align the table
    
    .Rows.Alignment = wdAlignRowLeft

    ' Column widths
    
   .columns(1).Width = doc.Application.CentimetersToPoints(6)
   .columns(2).Width = doc.Application.CentimetersToPoints(2.32)
   .columns(3).Width = doc.Application.CentimetersToPoints(2.32)
   .columns(4).Width = doc.Application.CentimetersToPoints(2.32)
   .columns(5).Width = doc.Application.CentimetersToPoints(2.32)
   .columns(6).Width = doc.Application.CentimetersToPoints(2.32)
   
   ' Headings
    
    .Cell(1, 2).range.Text = "Winter"
    .Cell(1, 3).range.Text = "Spring"
    .Cell(1, 4).range.Text = "Summer"
    .Cell(1, 5).range.Text = "Fall"
    .Cell(1, 6).range.Text = "Total"
    
    ' Labels
    
    If fAllSpeciesGroups Then
        .Cell(2, 1).range.Text = "Species observed annually"
        .Cell(3, 1).range.Text = "Species observed total"
        .Cell(4, 1).range.Text = "Individuals observed"
        .Cell(5, 1).range.Text = "Species banded"
        .Cell(6, 1).range.Text = "Individuals banded"
    Else
        .Cell(2, 1).range.Text = "Species observed annually (% of total)"
        .Cell(3, 1).range.Text = "Species observed total (% of total)"
        .Cell(4, 1).range.Text = "Individuals observed (% of total)"
        .Cell(5, 1).range.Text = "Species banded (% of total)"
        .Cell(6, 1).range.Text = "Individuals banded (% of total)"
    End If


    For row = 2 To conNumRows
        .Cell(row, 1).LeftPadding = doc.Application.CentimetersToPoints(0.2)
    Next

    ' Format Header Row
    
    For col = 2 To 5
      .Cell(1, col).range.Style = "ddMultiYear_BirdsOfMBO_Header"
    Next
    .Cell(1, col).range.Style = "ddMultiYear_BirdsOfMBO_Header_Total"
    
    .Cell(1, 2).Shading.BackgroundPatternColor = RGB(182, 221, 232)
    .Cell(1, 3).Shading.BackgroundPatternColor = RGB(253, 233, 217)
    .Cell(1, 4).Shading.BackgroundPatternColor = RGB(229, 184, 189)
    .Cell(1, 5).Shading.BackgroundPatternColor = RGB(178, 161, 199)
    .Cell(1, 6).Shading.BackgroundPatternColor = vbBlack
    

    ' Format Labels Column
  
    For row = 2 To conNumRows
      .Cell(row, 1).range.Style = "ddMultiYear_BirdsOfMBO_Label"
    Next
    
    ' Format Data
  
    For col = 2 To 6
        For row = 2 To conNumRows
            .Cell(row, col).range.Style = "ddMultiYear_BirdsOfMBO_Data"
        Next
    Next
   
    ' Repeat heading row at the top of subsequent pages

    .Rows.WrapAroundText = False

End With

    'DD Error Handler Start
Exit_label:
    Exit Sub
Err_label:
    Select Case Err.Number
    Case Else
         Call LogError("basMBO10Year_BirdsOfMBO_Tables", "WordGenerateTableBirdsOfMBO")
    End Select
    Resume Exit_label
    ' DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' Calculate_statistics
'---------------------------------------------------------------------------------------
' Fill in stats( statistic, season, speciesgroup )
' From data in tbl15YearReport_BirdsOfMBO_Tables_DET_Temp
'              tbl15YearReport_BirdsOfMBO_Tables_Banded_Temp


Private Sub Calculate_statistics(ByVal intYearFirst As Integer, ByVal intYearLast As Integer)

On Error GoTo Err_label

conLastSpeciesGroup = DMax("ID", "tblMBO10Year_SpeciesGroups_SpeciesObservedAtMBO", "True")
conAllSpeciesGroups = conLastSpeciesGroup + 1

ReDim lngStats(0 To 4, 0 To 4, 0 To conAllSpeciesGroups)

Call Calculate_statistics_fld("DET", intYearFirst, intYearLast)
Call Calculate_statistics_fld("Banded", intYearFirst, intYearLast)

    'DD Error Handler Start
Exit_label:
    Exit Sub
Err_label:
    Select Case Err.Number
    Case Else
         Call LogError("basMBO10Year_BirdsOfMBO_Tables", "Calculate_statistics")
    End Select
    Resume Exit_label
    ' DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' Calculate_statistics_FLD
'
' FLD = "DET" or "Banded"
'---------------------------------------------------------------------------------------

Private Sub Calculate_statistics_fld(ByVal strFLD As String, ByVal intYearFirst As Integer, ByVal intYearLast As Integer)

10    On Error GoTo Err_label

' Load tbl15YearReport_BirdsOfMBO_Tables_FLD_Temp

20    CurrentDb.Execute "DELETE * FROM tbl15YearReport_BirdsOfMBO_FLD_Temp"

30    If strFLD = "DET" Then
40        CurrentDb.Execute "qry15YearReport_BirdsOfMBO_FLD_DET_Append"
50    Else
60        CurrentDb.Execute "qry15YearReport_BirdsOfMBO_FLD_Banded_Append"
70    End If

      ' ===================================================================================
      ' =                       Species                                                   =
      ' ===================================================================================
      ' Exclude ther following pseudo-species: UNAC, UNEM, UNGU, HYWA, TRFL, USCA
      

      ' ====================== For each report season (Winter, Spring, Summer, Fall) ===================================================================
            
      ' qry15YearReport_BirdsOfMBO_Tables_FLD_A
      ' ---------------------------------------------
      ' For each season x year x species, sum FLD
      ' ---------------------------------------------
      ' tbl15YearReport_BirdsOfMBO_FLD_Temp x tblSpecies
      '
      ' WHERE Species NOT IN ("UNAC","UNEM","UNGU","HYWA","TRFL","USCA")
      ' WHERE PseudoSpeciesType <> "Hybrid"
      '
      ' GROUP BY Season, YearEx, SpeciesGroup, Species
      ' FLD: SUM FLD
      '
      ' Select Season, YearEx, SpeciesGroup, Species, FLD
            
      ' = = = = = = = = = =
      
           
      ' qry15YearReport_BirdsOfMBO_Tables_FLD_B
      ' ---------------------------------------------
      ' For each season x species, sum IIf(Nz([FLD])>0,1,0)
      ' ---------------------------------------------
      ' qry15YearReport_BirdsOfMBO_Tables_FLD_A
      '
      ' GROUP BY Season, SpeciesGroup, Species
      ' SFLD: Sum(IIf(Nz([FLD])>0,1,0))
      '
      ' Select Season, SpeciesGroup, Species, SFLD

      ' = = = = = = = = = =

      ' qry15YearReport_BirdsOfMBO_Tables_FLD_C
      ' --------------------------------------------------------------------------
      ' For each season x species, compute the FLD AllYears and AnyYear statistics
      ' --------------------------------------------------------------------------
      ' qry15YearReport_BirdsOfMBO_Tables_FLD_B
      '
      ' Season
      ' SpeciesGroup
      ' Species
      ' SBanded
      ' SFLD
      ' AllYearsFLD: IIf([SFLD]=([argYearLast]-[argYearFirst]+1),1,0)
      ' AnyYearFLD: IIf([SFLD]>0,1,0)
      '
      ' SELECT Season, SpeciesGroup, Species, SFLD, AllYearsFLD, AnyYearFLD

      ' = = = = = = = = = =

      ' qry15YearReport_BirdsOfMBO_Tables_FLD_D
      ' -----------------------------------------------------------------------------------------
      ' For each season x species group, sum the FLD AllYears and AnyYear statistics over species
      ' Exclude the superspecies (TRFL, USCA) from the sums
      ' -----------------------------------------------------------------------------------------
      ' qry15YearReport_BirdsOfMBO_Tables_FLD_C
      '
      ' GROUP BY Season, SpeciesGroup
      ' SUM AllYearsFLD, AnyYearDET
      '
      ' SELECT Season, SpeciesGroup, AllYearsFLD, AnyYearDET

      ' = = = = = = = = = =

      Dim qdf As DAO.QueryDef
      Dim rst As DAO.Recordset
      Dim strSeason As String
      Dim intSeason As Integer
      Dim intSpeciesGroup As Integer
      Dim intAllYears_FLD As Integer
      Dim intAnyYear_FLD As Integer

80    Set qdf = CurrentDb.QueryDefs("qry15YearReport_BirdsOfMBO_Tables_FLD_D")
90    qdf.Parameters("argYearFirst") = intYearFirst
100   qdf.Parameters("argYearLast") = intYearLast
110   Set rst = qdf.OpenRecordset
120   Do While Not rst.EOF
130       strSeason = Nz(rst("Season"))
140       intSpeciesGroup = Nz(rst("SpeciesGroup"))
150       intAllYears_FLD = Nz(rst("AllYearsFLD"))
160       intAnyYear_FLD = Nz(rst("AnyYearFLD"))
          
170       intSeason = toIntSeasonFromStrSeason(strSeason)
180       If intSeason < 0 Or intSeason > 3 Then
190         Call LogError("basMBO10Year_BirdsOfMBO_Tables", "Calculate_statistics", "Invalid Season = " & strSeason)
200         GoTo Exit_label
210       End If
          
220       If strFLD = "DET" Then
230           lngStats(conSpeciesObservedAnnually, intSeason, intSpeciesGroup) = intAllYears_FLD
240           lngStats(conSpeciesObservedTotal, intSeason, intSpeciesGroup) = intAnyYear_FLD
250           lngStats(conSpeciesObservedAnnually, intSeason, conAllSpeciesGroups) = lngStats(conSpeciesObservedAnnually, intSeason, conAllSpeciesGroups) + intAllYears_FLD
260           lngStats(conSpeciesObservedTotal, intSeason, conAllSpeciesGroups) = lngStats(conSpeciesObservedTotal, intSeason, conAllSpeciesGroups) + intAnyYear_FLD
270       Else
280           lngStats(conSpeciesBanded, intSeason, intSpeciesGroup) = intAnyYear_FLD
290           lngStats(conSpeciesBanded, intSeason, conAllSpeciesGroups) = lngStats(conSpeciesBanded, intSeason, conAllSpeciesGroups) + intAnyYear_FLD
300       End If
          
310       rst.MoveNext
320   Loop
330   rst.Close
340   Set rst = Nothing


      ' ====================== All Seasons ==========================================

      ' qryMBO10Year_BirdsOfMBO_AllSeasons
      ' --------------------------------------
      ' For each year x species, SUM FLD
      ' --------------------------------------
      ' tbl15YearReport_BirdsOfMBO_Tables_FLD_Temp x tblSpecies
      '
      ' WHERE Species NOT IN ("UNAC","UNEM","UNGU","HYWA","TRFL","USCA")
      ' WHERE PseudoSpeciesType <> "Hybrid"
      '
      ' GROUP BY YearEx, SpeciesGroup, Species
      ' SUM (over all report seasons) FLD
      '
      ' SELECT YearEx, SpeciesGroup, Species, FLD

      ' = = = = = = = = = =

      ' qryMBO10Year_BirdsOfMBO_AllSeasons_A
      ' ------------------------------------
      ' For each species, SUM IIf(Nz([FLD])>0,1,0)
      ' ------------------------------------
      ' qryMBO10Year_BirdsOfMBO_AllSeasons
      '
      ' GROUP BY SpeciesGroup, Species
      ' SFLD: Sum(IIf(Nz([FLD])>0,1,0))          summed over years
      '
      ' SELECT SpeciesGroup, Species, FLD

      ' = = = = = = = = = =

      ' qryMBO10Year_BirdsOfMBO_AllSeasons_B
      ' --------------------------------------------------------------------------
      ' For each species, compute the FLD AllYears and AnyYear statistics
      ' --------------------------------------------------------------------------
      ' qryMBO10Year_BirdsOfMBO_AllSeasons_A
      '
      ' SpeciesGroup
      ' Species
      ' SBanded
      ' SDET
      ' AllYearsFLD: IIf([SFLD]=([argYearLast]-[argYearFirst]+1),1,0)
      ' AnyYearFLD: IIf([SFLD]>0,1,0)
      '
      ' SELECT SpeciesGroup, Species, SFLD, AllyearsFLD, AnyYearFLD

      ' = = = = = = = = = =

      ' qryMBO10Year_BirdsOfMBO_AllSeasons_C
      ' -----------------------------------------------------------------------------------------
      ' For each species group, sum the FLD AllYearsFLD and AnyYearFLD statistics over species
      ' -----------------------------------------------------------------------------------------
      ' qryMBO10Year_BirdsOfMBO_AllSeasons_B
      '
      ' GROUP BY SpeciesGroup
      ' SUM (over Species) AllYearsFLD, AllYearsFLD
      '
      ' SELECT SpeciesGroup, AllYearsFLD, AllYearsFLD


350   Set qdf = CurrentDb.QueryDefs("qryMBO10Year_BirdsOfMBO_AllSeasons_C")
360   qdf.Parameters("argYearFirst") = intYearFirst
370   qdf.Parameters("argYearLast") = intYearLast
380   Set rst = qdf.OpenRecordset
390   Do While Not rst.EOF
400       intSpeciesGroup = Nz(rst("SpeciesGroup"))
410       intAllYears_FLD = Nz(rst("AllYearsFLD"))
420       intAnyYear_FLD = Nz(rst("AnyYearFLD"))

430       If strFLD = "DET" Then
440           lngStats(conSpeciesObservedAnnually, conAllSeasons, intSpeciesGroup) = intAllYears_FLD
450           lngStats(conSpeciesObservedTotal, conAllSeasons, intSpeciesGroup) = intAnyYear_FLD
              
460           lngStats(conSpeciesObservedAnnually, conAllSeasons, conAllSpeciesGroups) = lngStats(conSpeciesObservedAnnually, conAllSeasons, conAllSpeciesGroups) + intAllYears_FLD
470           lngStats(conSpeciesObservedTotal, conAllSeasons, conAllSpeciesGroups) = lngStats(conSpeciesObservedTotal, conAllSeasons, conAllSpeciesGroups) + intAnyYear_FLD
480       Else
490           lngStats(conSpeciesBanded, conAllSeasons, intSpeciesGroup) = intAnyYear_FLD
500           lngStats(conSpeciesBanded, conAllSeasons, conAllSpeciesGroups) = lngStats(conSpeciesBanded, conAllSeasons, conAllSpeciesGroups) + intAnyYear_FLD
510       End If

520       rst.MoveNext
530   Loop
540   rst.Close
550   Set rst = Nothing


      ' ===================================================================================
      ' =                       Individuals                                               =
      ' ===================================================================================

      Dim lngIndividials_FLD As Long

      ' qry15YearReport_BirdsOfMBO_Tables_Birds_FLD
      ' ------------------------------------------
      ' For each species group, SUM FLD
      ' ------------------------------------------
      ' tbl15YearReport_BirdsOfMBO_Tables_FLD_Temp
      '
      ' GROUP BY Season, Speciesgroup
      ' SUM (over YearEx, Species) FLD

560   Set qdf = CurrentDb.QueryDefs("qry15YearReport_BirdsOfMBO_Tables_Birds_FLD")
570   Set rst = qdf.OpenRecordset
580   Do While Not rst.EOF
590       strSeason = Nz(rst("Season"))
600       intSpeciesGroup = Nz(rst("SpeciesGroup"))
610       lngIndividials_FLD = Nz(rst("FLD"))

620       intSeason = toIntSeasonFromStrSeason(strSeason)
630       If intSeason < 0 Or intSeason > 3 Then
640         Call LogError("basMBO10Year_BirdsOfMBO_Tables", "Calculate_statistics", "Invalid Season = " & strSeason)
650         GoTo Exit_label
660       End If
          
670       If strFLD = "DET" Then
680           lngStats(conIndividualsObserved, intSeason, intSpeciesGroup) = lngIndividials_FLD
690           lngStats(conIndividualsObserved, conAllSeasons, intSpeciesGroup) = lngStats(conIndividualsObserved, conAllSeasons, intSpeciesGroup) + lngIndividials_FLD
700           lngStats(conIndividualsObserved, intSeason, conAllSpeciesGroups) = lngStats(conIndividualsObserved, intSeason, conAllSpeciesGroups) + lngIndividials_FLD
710           lngStats(conIndividualsObserved, conAllSeasons, conAllSpeciesGroups) = lngStats(conIndividualsObserved, conAllSeasons, conAllSpeciesGroups) + lngIndividials_FLD
720       Else
730           lngStats(conIndividualsBanded, intSeason, intSpeciesGroup) = lngIndividials_FLD
740           lngStats(conIndividualsBanded, conAllSeasons, intSpeciesGroup) = lngStats(conIndividualsBanded, conAllSeasons, intSpeciesGroup) + lngIndividials_FLD
750           lngStats(conIndividualsBanded, intSeason, conAllSpeciesGroups) = lngStats(conIndividualsBanded, intSeason, conAllSpeciesGroups) + lngIndividials_FLD
760           lngStats(conIndividualsBanded, conAllSeasons, conAllSpeciesGroups) = lngStats(conIndividualsBanded, conAllSeasons, conAllSpeciesGroups) + lngIndividials_FLD
770       End If

780       rst.MoveNext
790   Loop
800   rst.Close
810   Set rst = Nothing

          'DD Error Handler Start
Exit_label:
820       Exit Sub
Err_label:
830       Select Case Err.Number
          Case Else
840            Call LogError("basMBO10Year_BirdsOfMBO_Tables", "Calculate_statistics_fld")
850       End Select
860       Resume Exit_label
          ' DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' Load_tbl15YearReport_BirdsOfMBO_DET_Temp
'---------------------------------------------------------------------------------------
' Report years, MBO-site, Big4 MP
' Includes: "UNAC","UNEM","UNGU", "HIWA",merged PAWA, merged SNGO

Private Sub Load_tbl15YearReport_BirdsOfMBO_DET_Temp(ByVal intYearFirst As Integer, ByVal intYearLast As Integer)

10    On Error GoTo Err_label

      Dim qdf As DAO.QueryDef

20    CurrentDb.Execute "DELETE * FROM tbl15YearReport_BirdsOfMBO_DET_Temp"

      ' qry15YearReport_BirdsOfMBO_DET_Append
      ' ----------------------------------------------------------------
      ' APPEND TO tbl15YearReport_BirdsOfMBO_DET_Temp
      ' tblDETSpecies x tblPrograms x tblSpecies
      '
      ' WHERE Location = "MBO"
      ' WHERE YearEx BETWEEN [argYearFirst] AND [argYearLast]
      ' WHERE MonitoringProgramSeason IN ("Winter","Spring","Summer","Fall")
      ' WHERE Species NOT IN ("PAWA", "WPWA", "YPWA", "LSGO","GSGO","SNGO")
      '
      ' SELECT    MonitoringProgramSeason, YearEx, DateEx, Speciesgroup, Species, DET
      ' APPEND TO Season,                  YearEx, DateEx, SpeciesGroup, Species, DET

30    Set qdf = CurrentDb.QueryDefs("qry15YearReport_BirdsOfMBO_DET_Append")
40    qdf.Parameters("argYearFirst") = intYearFirst
50    qdf.Parameters("argYearLast") = intYearLast
60    qdf.Execute

      ' qry15YearReport_BirdsofMBO_DET_PAWA_Append
      ' ---------------------------------------------------
      ' APPEND TO tbl15YearReport_BirdsOfMBO_DET_Temp
      ' tblDETSpecies x tblPrograms x tblSpecies
      '
      ' WHERE Location = "MBO"
      ' WHERE YearEx BETWEEN [argYearFirst] AND [argYearLast]
      ' WHERE MonitoringProgramSeason IN ("Winter","Spring","Summer","Fall")
      ' WHERE Species IN ("PAWA","WPWA","YPWA")
      '
      ' SpeciesEx = "PAWA"
      ' SpeciesGroup = FIRST SpeciesGroup
      '
      ' GROUP BY MonitoringProgramSeason, YearEx, DateEx, SpeciesEx
      '
      ' SELECT    MonitoringProgramSeason, YearEx, DateEx, SpeciesGroup, SpeciesEx, SUM DET
      ' APPEND TO Season,                  YearEx, DateEx, SpeciesGroup, Species,   DET


70    Set qdf = CurrentDb.QueryDefs("qry15YearReport_BirdsofMBO_DET_PAWA_Append")
80    qdf.Parameters("argYearFirst") = intYearFirst
90    qdf.Parameters("argYearLast") = intYearLast
100   qdf.Execute

      ' qry15YearReport_BirdsofMBO_DET_SNGO_Append
      ' ---------------------------------------------------
      ' APPEND TO tbl15YearReport_BirdsOfMBO_DET_Temp
      ' tblDETSpecies x tblPrograms x tblSpecies
      '
      ' WHERE Location = "MBO"
      ' WHERE YearEx BETWEEN [argYearFirst] AND [argYearLast]
      ' WHERE MonitoringProgramSeason IN ("Winter","Spring","Summer","Fall")
      ' WHERE Species IN ("LSGO","GSGO","SNGO")
      '
      ' SpeciesEx = "SNGO"
      ' SpeciesGroup = FIRST SpeciesGroup
      '
      ' GROUP BY MonitoringProgramSeason, YearEx, DateEx, SpeciesEx
      '
      ' SELECT    MonitoringProgramSeason, YearEx, DateEx, SpeciesGroup, SpeciesEx, SUM DET
      ' APPEND TO Season,                  YearEx, DateEx, SpeciesGroup, Species,   DET


110   Set qdf = CurrentDb.QueryDefs("qry15YearReport_BirdsofMBO_DET_SNGO_Append")
120   qdf.Parameters("argYearFirst") = intYearFirst
130   qdf.Parameters("argYearLast") = intYearLast
140   qdf.Execute

    'DD Error Handler Start
Exit_label:
150       Exit Sub
Err_label:
160       Select Case Err.Number
    Case Else
170      Call LogError("basMBO10YearProgramReportSpecies", "Load_tbl15YearReport_BirdsOfMBO_DET_Temp")
180       End Select
190       Resume Exit_label
    ' DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' Load_tbl15YearReport_BirdsOfMBO_Banded_Temp
'---------------------------------------------------------------------------------------

Private Sub Load_tbl15YearReport_BirdsOfMBO_Banded_Temp(ByVal intYearFirst As Integer, ByVal intYearLast As Integer)

10    On Error GoTo Err_label

      Dim qdf As DAO.QueryDef

20    CurrentDb.Execute "DELETE * FROM tbl15YearReport_BirdsOfMBO_Banded_Temp"

      ' qry15YearReport_BirdsOfMBO_Banded_Append
      ' ----------------------------------------------------------------
      ' APPEND TO tbl15YearReport_BirdsOfMBO_Banded_Temp
      ' tblDETSpecies x tblPrograms x tblSpecies
      '
      ' WHERE Location = "MBO"
      ' WHERE YearEx BETWEEN [argYearFirst] AND [argYearLast]
      ' WHERE Species NOT IN ("PAWA", "WPWA", "YPWA", "LSGO","GSGO","SNGO")
      '
      ' Season = toReportSeason([MonitoringProgramSeason],[DateEx])
      '
      ' SELECT    Season, YearEx, DateEx, Speciesgroup, Species, Banded
      ' APPEND TO Season, YearEx, DateEx, SpeciesGroup, Species, Banded


30    Set qdf = CurrentDb.QueryDefs("qry15YearReport_BirdsOfMBO_Banded_Append")
40    qdf.Parameters("argYearFirst") = intYearFirst
50    qdf.Parameters("argYearLast") = intYearLast
60    qdf.Execute

      ' qry15YearReport_BirdsofMBO_Banded_PAWA_Append
      ' ---------------------------------------------------
      ' APPEND TO tbl15YearReport_BirdsOfMBO_Banded_Temp
      ' tblDETSpecies x tblPrograms x tblSpecies
      '
      ' WHERE Location = "MBO"
      ' WHERE YearEx BETWEEN [argYearFirst] AND [argYearLast]
      ' WHERE MonitoringProgramSeason IN ("Winter","Spring","Summer","Fall")
      ' WHERE Species IN ("PAWA","WPWA","YPWA")
      '
      ' SpeciesEx = "PAWA"
      ' SpeciesGroup = FIRST SpeciesGroup
      ' Season = toReportSeason([MonitoringProgramSeason],[DateEx])
      '
      ' GROUP BY Season, YearEx, DateEx, Speciesgroup, SpeciesEx
      '
      ' SELECT    Season, YearEx, DateEx, SpeciesGroup, SpeciesEx, SUM Banded
      ' APPEND TO Season, YearEx, DateEx, SpeciesGroup, Species,   Banded


70    Set qdf = CurrentDb.QueryDefs("qry15YearReport_BirdsofMBO_Banded_PAWA_Append")
80    qdf.Parameters("argYearFirst") = intYearFirst
90    qdf.Parameters("argYearLast") = intYearLast
100   qdf.Execute

      ' qry15YearReport_BirdsofMBO_Banded_TRFL_Append
      ' ---------------------------------------------------
      ' APPEND TO tbl15YearReport_BirdsOfMBO_Banded_Temp
      ' tblDETSpecies x tblPrograms x tblSpecies
      '
      ' WHERE Location = "MBO"
      ' WHERE YearEx BETWEEN [argYearFirst] AND [argYearLast]
      ' WHERE MonitoringProgramSeason IN ("Winter","Spring","Summer","Fall")
      ' WHERE Species IN ("LSGO","GSGO","SNGO")
      '
      ' SpeciesEx = "SNGO"
      ' SpeciesGroup = FIRST SpeciesGroup
      ' Season = toReportSeason([MonitoringProgramSeason],[DateEx])
      '
      ' GROUP BY Season, YearEx, DateEx, Speciesgroup, SpeciesEx
      '
      ' SELECT    Season, YearEx, DateEx, SpeciesGroup, SpeciesEx, SUM Banded
      ' APPEND TO Season, YearEx, DateEx, SpeciesGroup, Species,   Banded


110   Set qdf = CurrentDb.QueryDefs("qry15YearReport_BirdsofMBO_Banded_SNGO_Append")
120   qdf.Parameters("argYearFirst") = intYearFirst
130   qdf.Parameters("argYearLast") = intYearLast
140   qdf.Execute

    'DD Error Handler Start
Exit_label:
150       Exit Sub
Err_label:
160       Select Case Err.Number
    Case Else
170      Call LogError("basMBO10YearProgramReportSpecies", "Load_tbl15YearReport_BirdsOfMBO_Banded_Temp")
180       End Select
190       Resume Exit_label
    ' DD Error Handler End

End Sub


'---------------------------------------------------------------------------------------
' toBirdsOfMBOSeason
'
' Convert a season to "Winter", "Spring", "Summer", "Fall", "Ignore"
'
' Called from qryMBO10Year_BirdsOfMBO_Append
'---------------------------------------------------------------------------------------

Public Function toBirdsOfMBOSeason(ByVal strSeason As String) As String

   On Error GoTo Err_label

10    On Error GoTo Err_label

20    Select Case strSeason
      Case "Winter"
30        toBirdsOfMBOSeason = "Winter"
40    Case "Spring", "RTHU_Spring"
50        toBirdsOfMBOSeason = "Spring"
60    Case "Summer"
70        toBirdsOfMBOSeason = "Summer"
80    Case "Fall", "Owling", "RTHU_Fall"
90        toBirdsOfMBOSeason = "Fall"
100   Case Else
110       toBirdsOfMBOSeason = "Ignore"
120   End Select

    'DD Error Handler Start
Exit_label:
    Exit Function
Err_label:
    Select Case Err.Number
    Case Else
         Call LogError("basMBO10Year_BirdsOfMBO_Tables", "toBirdsOfMBOSeason")
    End Select
    Resume Exit_label
    ' DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' intBirdsOfMBOSeason
'
' Convert a season to 0, 1, 2, 3, -1
'
' Called from qryMBO10Year_BirdsOfMBO_Append
'---------------------------------------------------------------------------------------

Public Function intBirdsOfMBOSeason(ByVal strSeason As String) As String

10    On Error GoTo Err_label

20    Select Case strSeason
      Case "Winter"
30        intBirdsOfMBOSeason = 0
40    Case "Spring", "RTHU_Spring"
50        intBirdsOfMBOSeason = 1
60    Case "Summer"
70        intBirdsOfMBOSeason = 2
80    Case "Fall", "Owling", "RTHU_Fall"
90        intBirdsOfMBOSeason = 3
100   Case Else
110       intBirdsOfMBOSeason = -1
120   End Select

          'DD Error Handler Start
Exit_label:
130       Exit Function
Err_label:
140       Select Case Err.Number
          Case Else
150      Call LogError("basMBO10Year_BirdsOfMBO_Tables", "toBirdsOfMBOSeason")
160       End Select
170       Resume Exit_label
          ' DD Error Handler End
End Function
