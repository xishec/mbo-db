'---------------------------------------------------------------------------------------
' Module    : basFileExist
'---------------------------------------------------------------------------------------

Option Compare Database
Option Explicit

'---------------------------------------------------------------------------------------
' FileExists
'---------------------------------------------------------------------------------------
 
Public Function FileExists(ByVal strFile As String, Optional bFindFolders As Boolean) As Boolean
          'Purpose:   Return True if the file exists, even if it is hidden.
          'Arguments: strFile: File name to look for. Current directory searched if no path included.
          '           bFindFolders. If strFile is a folder, FileExists() returns False unless this argument is True.
          'Note:      Does not look inside subdirectories for the file.
          'Author:    Allen Browne. http://allenbrowne.com June, 2006.
          Dim lngAttributes As Long

          'Include read-only files, hidden files, system files.
10    On Error GoTo Err_label

20        lngAttributes = (vbReadOnly Or vbHidden Or vbSystem)

30        If bFindFolders Then
40            lngAttributes = (lngAttributes Or vbDirectory) 'Include folders as well.
50        Else
              'Strip any trailing slash, so Dir does not look inside the folder.
60            Do While Right$(strFile, 1) = "\"
70                strFile = Left$(strFile, Len(strFile) - 1)
80            Loop
90        End If

          'If Dir() returns something, the file exists.
100       On Error Resume Next
110       FileExists = (Len(Dir(strFile, lngAttributes)) > 0)

      'DD Error Handler Start
Exit_label:
120        Exit Function
Err_label:
130        Select Case Err.Number
           Case Else
140       Call LogError("basFileExist", "FileExists")
150        End Select
160        Resume Exit_label
      'DD Error Handler End
End Function

Public Function FolderExists(strPath As String) As Boolean
10    On Error GoTo Err_label

20        On Error Resume Next
30        FolderExists = ((GetAttr(strPath) And vbDirectory) = vbDirectory)

      'DD Error Handler Start
Exit_label:
40         Exit Function
Err_label:
50         Select Case Err.Number
           Case Else
60        Call LogError("basFileExist", "FolderExists")
70         End Select
80         Resume Exit_label
      'DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' TrailingSlash
' If the argument filepath already ends with "\" this function returns the argument
' Otherwise, this function returns the argument with a "\" appended to its end
'---------------------------------------------------------------------------------------
 
Public Function TrailingSlash(varIn As Variant) As String
10    On Error GoTo Err_label

20        If Len(varIn) > 0 Then
30            If Right(varIn, 1) = "\" Then
40                TrailingSlash = varIn
50            Else
60                TrailingSlash = varIn & "\"
70            End If
80        End If

      'DD Error Handler Start
Exit_label:
90         Exit Function
Err_label:
100        Select Case Err.Number
           Case Else
110       Call LogError("basFileExist", "TrailingSlash")
120        End Select
130        Resume Exit_label
      'DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' StripTrailingSlashes
'---------------------------------------------------------------------------------------

Public Sub StripTrailingSlashes(ByRef strFolderpath As String)
10       On Error GoTo Err_label

20        Do While Len(strFolderpath) > 0
30            If Right(strFolderpath, 1) = "\" Then
40                strFolderpath = Left(strFolderpath, Len(strFolderpath) - 1)
50            Else
60                Exit Do
70            End If
80        Loop

          'DD Error Handler Start
Exit_label:
90        Exit Sub
Err_label:
100       Select Case Err.Number
          Case Else
110            Call LogError("basFileExist", "StripTrailingSlashes")
120       End Select
130       Resume Exit_label
          ' DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' StripAllExtensionsFromFilename
'---------------------------------------------------------------------------------------
' Public Function StripAllExtensionsFromFilename(ByVal strFilename As String)
'
' Strip the extension from a filename
' If there are several periods, this function strips everything after the leftmost period, and the period too
' ---------------------------------------------------------------------------------------

Public Function StripAllExtensionsFromFilename(ByVal strFilename As String)
On Error GoTo Err_label

Dim intPosFirstPeriod As Integer

intPosFirstPeriod = InStr(strFilename, ".")

' If there are no periods then there is nothing to strip

If intPosFirstPeriod = 0 Then
    ' If there are no periods then there is nothing to strip
    
    StripAllExtensionsFromFilename = strFilename
Else
    ' Strips everything after the leftmost period, and the period too
    StripAllExtensionsFromFilename = Left(strFilename, intPosFirstPeriod - 1)
End If

    'DD Error Handler Start
Exit_label:
    Exit Function
Err_label:
    Select Case Err.Number
    Case Else
         Call LogError("basFileExist", "StripAllExtensionsFromFilename")
    End Select
    Resume Exit_label
    ' DD Error Handler End
End Function



'---------------------------------------------------------------------------------------
' FileNameFromPath
'---------------------------------------------------------------------------------------
 
Public Function FileNameFromPath(strFullPath As String) As String
10    On Error GoTo Err_label

20        FileNameFromPath = Right(strFullPath, Len(strFullPath) - InStrRev(strFullPath, "\"))

      'DD Error Handler Start
Exit_label:
30         Exit Function
Err_label:
40         Select Case Err.Number
           Case Else
50              Call LogError("basFileExist", "FileNameFromPath")
60         End Select
70         Resume Exit_label
      'DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' FolderFromPath
'---------------------------------------------------------------------------------------

Public Function FolderFromPath(strFullPath As String) As String
10    On Error GoTo Err_label

20        FolderFromPath = Left(strFullPath, InStrRev(strFullPath, "\") - 1)

      'DD Error Handler Start
Exit_label:
30         Exit Function
Err_label:
40         Select Case Err.Number
           Case Else
50              Call LogError("basFileExist", "FolderFromPath")
60         End Select
70         Resume Exit_label
      'DD Error Handler End
End Function
