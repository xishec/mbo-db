'---------------------------------------------------------------------------------------
' Module: basExportBBL
' Author: David Davey
'---------------------------------------------------------------------------------------

Option Compare Database
Option Explicit

' frmCaptures.cmdExportBBL_Click
' ---ExportBB
' ------ FillIn_tblExportBBL_Log_Add_From_tblCaptures
' ------ Create_output_file
' ------ FillInBBLExcelFile
' ------ OpenExcelWorkbook
' ------ BBLExport_Commit


' frmBBLExports.cmdBBLExport_Again_Click
' --- BBLExportAgain
' ------ FillIn_tblExportBBL_Log_Add_From_tblExport_Log
' ------ Create_output_file
' ------ FillInBBLExcelFile
' ------ OpenExcelWorkbook


' frmBBLExports.cmdBBLExport_View_Click
' --- ExportBBL_ViewExport


' Create_output_file
' --- GetBBLTemplateFilepath
' --- PutBBLTemplateFilepath
' --- FileNameFromPath
' --- StripAllExtensionsFromFilename
' --- FolderFromPath
' --- FileExists
' --- GetExportFolder
' --- FolderExists
' --- Rep_Documents
' --- TrailingSlash
' --- CopyFile


' FillInBBLExcelFile
' --- VerifyWoksheetStructure
' ---FillInSheet



'---------------------------------------------------------------------------------------
' ExportBBL_ViewExport
' Display the tblExportBBL_Log records for a given BBL Export Timestamp
' PRE: The BL Export Timestamp is not "", and is a valid BBL Exprt Timestamp
'---------------------------------------------------------------------------------------

Public Sub ExportBBL_ViewExport(ByVal strTimestamp As String)
10    On Error GoTo Err_label

      Dim strSQL As String

20    strSQL = "SELECT * FROM tblExportBBL_Log WHERE BBLExport_Timestamp = '" & strTimestamp & "'"

30    On Error Resume Next
40    CurrentDb.QueryDefs.Delete "qryExportBBL_Log_Timestamp"
50    DoCmd.Close acQuery, "qryExportBBL_Log_Timestamp"
60    On Error GoTo Err_label

      Dim qdf As DAO.QueryDef
70    Set qdf = CurrentDb.CreateQueryDef("qryExportBBL_Log_Timestamp", strSQL)

80    DoCmd.OpenQuery "qryExportBBL_Log_Timestamp", acViewNormal, acReadOnly

          'DD Error Handler Start
Exit_label:
90        Exit Sub
Err_label:
100       Select Case Err.Number
          Case Else
110      Call LogError("basExportBBL", "ExportBBL_View")
120       End Select
130       Resume Exit_label
          ' DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' ExportBBL
' Called from the BBL Export commend button on the Captures form
'---------------------------------------------------------------------------------------
' tblExportBBL_Log_Add only has ToBeExported records that are Valid OR Bypassed

Public Sub ExportBBL(ByRef lngCountExportedRecords)
10    On Error GoTo Err_label

Dim fError As Boolean
Dim strExportTimestamp As String

'   Create the BBL export timestamp YYYY-MM-DD HHhMM
'   The same timestamp will mark each BBL Excel output filename
'   as well as all records appended to the BBL Export Log table
'   as well as exported Capture records

20    strExportTimestamp = Format(Now(), "yyyy-mm-dd hh\hmm")

' Fill in tblExportBBL_Log_Add

30    Call FillIn_tblExportBBL_Log_Add_From_tblCaptures(strExportTimestamp, fError)
40    If fError Then
50        lngCountExportedRecords = 0
60        GoTo Exit_label
70    End If

' Create the BBL Excel files

Dim strBBLFiletype(1 To 4) As String

80    strBBLFiletype(1) = "Banding"
90    strBBLFiletype(2) = "Recaps"
100   strBBLFiletype(3) = "BandingAUX"
110   strBBLFiletype(4) = "RecapsAUX"

Dim fBBLFiletype(1 To 4) As Boolean
Dim strReportFilepath(1 To 4) As String
Dim i As Integer
Dim lngBBLFiletype As Long

120   For i = 1 To 4

    Dim strWhere As String
130       strWhere = "BBL_Filetype = '" & strBBLFiletype(i) & "'"
    
140       lngBBLFiletype = DCount("*", "tblExportBBL_Log_Add", strWhere)
150       If lngBBLFiletype > 0 Then
160     strReportFilepath(i) = Create_output_file(strBBLFiletype(i), strExportTimestamp)
170       Else
180     strReportFilepath(i) = ""
190       End If
200   Next

' Verify there is anything to export

Dim fExport As Boolean
210   fExport = False
220   For i = 1 To 4
230       fExport = fExport Or (strReportFilepath(i) <> "")
240   Next
250   If Not fExport Then
260       lngCountExportedRecords = 0
270       GoTo Exit_label
280   End If

' tblExportBBL_Long_Add => BBL Excel files
' If anything goes wrong exit

290   For i = 1 To 4
300       If strReportFilepath(i) <> "" Then
310     Call FillInBBLExcelFile(strBBLFiletype(i), strReportFilepath(i), fError)
320       End If
330       If fError Then
340     lngCountExportedRecords = 0
350     GoTo Exit_label
360       End If
370   Next

      ' Open the workbooks. Do not prompt.

380   For i = 1 To 4
390       If strReportFilepath(i) <> "" Then
400           Call OpenExcelWorkbook(strReportFilepath(i), False)   ' Do not prompt
410       End If
420   Next

    ' Commit

430   lngCountExportedRecords = BBLExport_Commit()

    'DD Error Handler Start
Exit_label:
440       Exit Sub
Err_label:
450       Select Case Err.Number
    Case Else
460      Call LogError("basExportBBL", "ExportBBL")
470       End Select
480       Resume Exit_label
    ' DD Error Handler End

End Sub


'---------------------------------------------------------------------------------------
' BBLExport_Commit
'---------------------------------------------------------------------------------------
' Append the records from tblExportBBL_Log_Add to tblExportBBL_Log
' Update the ToBeExported fields in the exported records
' If anything goes wrong, rollback the append and update

Private Function BBLExport_Commit() As Integer
10    On Error GoTo Err_label

' qryExportBBLLog_Append
' ---------------------------------------------------------------------
' Append the contents of tblExport_Log_Add to tblExport_Log

' qryExportBBLCaptures_Update
' ----------------------------------------------------------------------
' Update the tblCapture records that were exported
' Remove the ToBeExported flag
' Store the timestamp of the BBL Export in D14
' Bump D15, the number of BBL exports.  This number should never be > 1 ...
' ----------------------------------------------------------------------
' tblCaptures x tblExport_Log_Add
' ToBeExported = False
' D14 = BBLExport_Timestamp
' D15 (Number of BBL exports) = CStr(IIf(Nz([D15])="",0,Int(Nz([D15])))+1)

20    DAO.DBEngine.BeginTrans
30    On Error GoTo Tran_Err
40    CurrentDb.Execute ("qryExportBBLLog_Append")
50    CurrentDb.Execute ("qryExportBBLCaptures_Update")
60    DAO.DBEngine.CommitTrans
70    BBLExport_Commit = DCount("*", "tblExportBBL_Log_Add")

    'DD Error Handler Start
Exit_label:
80        Exit Function
Tran_Err:
90        DAO.DBEngine.Rollback
100       MsgBox "Failed to update the ToBeExported flags in the Capture records, As far as the database is concerned, no records were exported", vbExclamation
110       BBLExport_Commit = 0
Err_label:
120       Select Case Err.Number
    Case Else
130      Call LogError("basExportBBL", "BBLExport_Commit")
140       End Select
150       Resume Exit_label
    ' DD Error Handler End

End Function

'---------------------------------------------------------------------------------------
' FillInBBLExcelFile
'---------------------------------------------------------------------------------------
' Write to a single BBL excel file
' strBBLFileType = "Banding", "Recaps", "BandingAUX", "RecapsAUX"
' strReportFilepath = path to the Excel file.  PRE: It exists
'
' Call FillInBBLExcelFile(strBBLFiletype, strReportFilepath,  fError)

Private Sub FillInBBLExcelFile(ByVal strBBLFiletype As String, ByVal strReportFilepath As String, ByRef fError As Boolean)

      Dim strSheetName As String

10        fError = True

          ' Open the workbook
          
          Dim oExcel As Excel.Application
          Dim oBook As Excel.Workbook
          Dim oSheet As Excel.Worksheet
          Dim strErrorMessage As String
          
20        On Error GoTo Err_label

30        Set oExcel = New Excel.Application
40        oExcel.Visible = True                       ' I have a vague memory the code will not work unless Excel is visible
          
          ' Open the Excel file
          
50        On Error Resume Next
60        Set oBook = oExcel.Workbooks.Open(strReportFilepath)
70        If Err.Number <> 0 Then
80          MsgBox "Failed to open the " & strBBLFiletype & " file"
90          Err.Clear
100         GoTo Exit_label
110       End If
120       On Error GoTo Err_label
          
          ' Open the first worksheet
          
130       On Error Resume Next
140       Set oSheet = oBook.Worksheets(1)
150       If Err.Number <> 0 Then
160         MsgBox "Failed to find a worksheet in the " & strBBLFiletype & " file"
170         Err.Clear
180         GoTo Exit_label
190       End If
200       On Error GoTo Err_label
          
          ' Verify the structure of the worksheet

210       If Not VerifyWoksheetStructure(oSheet, strBBLFiletype, strErrorMessage) Then
220           oBook.Close saveChanges:=False
230           oExcel.Quit
240           MsgBox strErrorMessage, vbOKOnly
250           GoTo Exit_label
260       End If
          
270       Call FillInSheet(oSheet, strBBLFiletype)

280       oBook.Close saveChanges:=True
290       oExcel.Quit

300       fError = False
              
          'DD Error Handler Start
Exit_label:
310       Exit Sub
Err_label:
320       Select Case Err.Number
          Case Else
330            Call LogError("basExportBBL", "FillInBBLExcelFile")
340       End Select
350       Resume Exit_label
          ' DD Error Handler End

End Sub

Public Sub FillInBBLExcelFile_Test()
Dim strReportFilepath As String
Dim strBBLFiletype As String
Dim fError As Boolean

10    strReportFilepath = "D:\Documents\Banding_Data_Upload_Template_NO_MARKERS_08272024.xlsx"
20    strBBLFiletype = "Banding"

30    Call FillInBBLExcelFile(strBBLFiletype, strReportFilepath, fError)
40    Debug.Print fError

End Sub



Public Sub FillInSheet_Test()

      Dim strReportFilepath As String
      Dim strBBLFiletype As String

10       On Error GoTo Err_label

20    strReportFilepath = "D:\Documents\Banding_Data_Upload_Template_NO_MARKERS_08272024.xlsx"
30    strBBLFiletype = "Banding"

          ' Open the workbook
          
          Dim oExcel As Excel.Application
          Dim oBook As Excel.Workbook
          Dim oSheet As Excel.Worksheet
          Dim strErrorMessage As String
          
40        On Error GoTo Err_label

50        Set oExcel = New Excel.Application
60        oExcel.Visible = True
          
          ' Open the Excel file
          
70        On Error Resume Next
80        Set oBook = oExcel.Workbooks.Open(strReportFilepath)
90        If Err.Number <> 0 Then
100         MsgBox "Failed to open the " & strBBLFiletype & " file"
110         Err.Clear
120         GoTo Exit_label
130       End If
140       On Error GoTo Err_label
          
          ' Open the first worksheet
          
150       On Error Resume Next
160       Set oSheet = oBook.Worksheets(1)
170       If Err.Number <> 0 Then
180         MsgBox "Failed to find a worksheet in the " & strBBLFiletype & " file"
190         Err.Clear
200         GoTo Exit_label
210       End If
220       On Error GoTo Err_label
          
          ' Verify the structure of the worksheet
         
230       Call FillInSheet(oSheet, strBBLFiletype)


240       oBook.Close saveChanges:=True
250       oExcel.Quit

          'DD Error Handler Start
Exit_label:
260       Exit Sub
Err_label:
270       Select Case Err.Number
          Case Else
280            Call LogError("basExportBBL", "FillInSheet_Test")
290       End Select
300       Resume Exit_label
          ' DD Error Handler End

End Sub



'---------------------------------------------------------------------------------------
' VerifyWoksheetStructure
'---------------------------------------------------------------------------------------
'Private Function VerifyWoksheetStructure( _
'    ByRef oSheet As Excel.Worksheet, _
'    ByVal strBBLFiletype As String, _
'    ByRef strErrorMessage As String) As Boolean
'
' strBBLFileType = "Banding", "Recaps", "BandingAUX", "RecapsAUX"
' Returns True if no errors were encounterd. strErrorMessage = ""
' Returns False if the structure is invalid.  sstrErrorMessage contains the error message
'
' Verify the presence of the Band Number column
' For Recaps, RecapsAUX verify there is a How Obtained column
' Verify the User Field 5 column exists and is in the expected column
'---------------------------------------------------------------------------------------

Private Function VerifyWoksheetStructure( _
    ByRef oSheet As Excel.Worksheet, _
    ByVal strBBLFiletype As String, _
    ByRef strErrorMessage As String) As Boolean
10    On Error GoTo Err_label

      Dim col As Long
      Dim strHeading As String
      Dim strLookupColumn As String
      Dim strLookupHeading As String

20    VerifyWoksheetStructure = False
30    strErrorMessage = ""

40    strLookupHeading = strBBLFiletype & "_ColumnID"
50    strLookupColumn = strBBLFiletype & "_Column"

      ' Verify the presence of the Band Number column
      ' tblExportBBL_Excel_Columns
      '     ColumnID ... My internal name for the BBL Spreadsheet Column, e.g. "Band Number", "How Captured", "User Field 5"
      '     Banding_Column ... Excel col# in a BBL Banding worksheet
      '     Recaps_Column  ... Excel col# in a BBL Recaps worksheet
      '     BandingAUX_Column ... Excel col# in a BBL BandingAUX worksheet
      '     RecapsAUX_Column  ... Excel col# in a BBL RecapsAUX worksheet

60    col = Nz(DLookup(strLookupColumn, "tblExportBBL_Excel_Columns", "ColumnID = 'Band Number'"))

70    If col = 0 Then
80        strErrorMessage = "Error: There is no Excel column number for 'Band Number' for the " & strBBLFiletype & "BBL Export worksheet in tblExportBBL_Excel_Columns."
90        GoTo Exit_label
100   End If


110   strHeading = oSheet.Cells(1, col)

120   If strHeading <> "Band Number" Then
130       strErrorMessage = "The worksheet is not a " & strBBLFiletype & "BBL Export worksheet." & vbCrLf & _
          "Failed to find a Band Number column in the " & strBBLFiletype & " worksheet"
140       GoTo Exit_label
150   End If

      ' For Recaps, RecapsAUX verify there is a How Obtained column

160   If strBBLFiletype = "Recaps" Or strBBLFiletype = "RecapsAUX" Then

170       col = Nz(DLookup(strLookupColumn, "tblExportBBL_Excel_Columns", "ColumnID = 'How Obtained'"))
          
180       If col = 0 Then
190       strErrorMessage = "Error: There is no Excel column number for 'How Obtained' for the " & strBBLFiletype & "BBL Export worksheet in tblExportBBL_Excel_Columns."
200       GoTo Exit_label
210       End If
          
220       strHeading = oSheet.Cells(1, col)
          
230       If strHeading <> "How Obtained" Then
240           strErrorMessage = "The worksheet is not a " & strBBLFiletype & "BBL Export worksheet." & vbCrLf & _
              "Failed to find a How Obtained column in the " & strBBLFiletype & " worksheet"
250           GoTo Exit_label
260       End If
270   End If

      ' Verify the User Field 5 column exists and is in the expected column

280   col = Nz(DLookup(strLookupColumn, "tblExportBBL_Excel_Columns", "ColumnID = 'User Field 5'"))

290   If col = 0 Then
300       strErrorMessage = "Error: There is no Excel column number for 'User Field 5' for the " & strBBLFiletype & "BBL Export worksheet in tblExportBBL_Excel_Columns."
310       GoTo Exit_label
320   End If
          
330   strHeading = oSheet.Cells(1, col)

340   If strHeading <> "User Field 5" Then
350       strErrorMessage = "The worksheet is not a " & strBBLFiletype & "BBL Export worksheet." & vbCrLf & _
          "Failed to find a User Field 5 column in column " & col & " of the " & strBBLFiletype & " worksheet"
360       GoTo Exit_label
370   End If

380   VerifyWoksheetStructure = True

          'DD Error Handler Start
Exit_label:
390       Exit Function
Err_label:
400       strErrorMessage = "Failed to validate the " & strBBLFiletype & " worksheet"
          
410       Select Case Err.Number
          Case Else
420            Call LogError("basExportBBL", "VerifyWoksheetStructure")
430       End Select

440       Resume Exit_label
          ' DD Error Handler End

End Function

Public Sub VerifyWoksheetStructure_Test()
Dim oExcel As Excel.Application
Dim oBook As Excel.Workbook
Dim oSheet As Excel.Worksheet
Dim strBBLFiletype As String
Dim strReportFilepath As String
Dim strErrorMessage As String

'strReportFilepath = "R:\MBO Data Entry\2014-02-13 Transition away from Bandit\Banding_Data_Upload_Template_AUX_MARKERS_08272024.xlsx"
'strBBLFiletype = "Recaps"

'strReportFilepath = "R:\MBO Data Entry\2014-02-13 Transition away from Bandit\Banding_Data_Upload_Template_AUX_MARKERS_08272024.xlsx"
'strBBLFiletype = "Banding"

strReportFilepath = "R:\MBO Data Entry\2014-02-13 Transition away from Bandit\Banding_Data_Upload_Template_AUX_MARKERS_08272024.xlsx"
strBBLFiletype = "BandingAUX"

Set oExcel = New Excel.Application
oExcel.Visible = True
Set oBook = oExcel.Workbooks.Open(strReportFilepath)
Set oSheet = oBook.Worksheets(1)
If VerifyWoksheetStructure(oSheet, strBBLFiletype, strErrorMessage) Then
    MsgBox "OK", vbOKOnly
    oBook.Close saveChanges:=False
    oExcel.Quit
Else
    oBook.Close saveChanges:=False
    oExcel.Quit
    MsgBox strErrorMessage, vbOKOnly
End If

End Sub

'---------------------------------------------------------------------------------------
' FillIn_tblExportBBL_Log_Add_From_tblCaptures
'---------------------------------------------------------------------------------------
' Warn ther user if there are any ToBeExported is True and ( Valid = "" and ByPassErrors = False ) records
' ZAP tblExportBBL_Log_Add
'
' Copy data from tblCaptures where ToBeExported is True and ( Valid = "v" or ByPassErrors = True ) To tblExportBBL_Log_Add
' Convert the data to BBL fields as you go
' Fill in the Timestamp, BandID, and BBL Filetype fields

Private Sub FillIn_tblExportBBL_Log_Add_From_tblCaptures(ByVal strExportTimestamp As String, ByRef fError As Boolean)
10    On Error GoTo Err_label

      Dim lngCountToBeExportedRecords As Long
      Dim lngCountInvalidUnbypassedToBeExportedRecords As Long
      Dim strMessage As String

20    fError = True

      ' Warn ther user if there are any ToBeExported is True and ( IsValid = "" or ByPassErrors = False )

30    lngCountToBeExportedRecords = DCount("*", "tblCaptures", "ToBeExported")
40    lngCountInvalidUnbypassedToBeExportedRecords = DCount("*", "tblCaptures", "ToBeExported AND  Nz(Valid) <> 'v' AND not BypassErrors")

50    If lngCountInvalidUnbypassedToBeExportedRecords > 0 Then
60        strMessage = "There are " & _
              lngCountInvalidUnbypassedToBeExportedRecords & _
              " ToBeExported records that have unbypassed errors" & vbCrLf & _
              "Do you wish to continue?" & vbCrLf & vbCrLf & _
              "N.B. If you continue, only the " & _
              lngCountToBeExportedRecords - lngCountInvalidUnbypassedToBeExportedRecords & _
              " records that are Valid or have bypassed errors will be exported." & _
              " Invalid records with non-bypassed errors will not be exported anyhow."

70        If vbYes <> MsgBox(strMessage, vbExclamation + vbYesNo) Then
80            GoTo Exit_label
90        End If
100   End If

      ' ZAP tblExportBBL_Log_Add

110   CurrentDb.Execute "DELETE * FROM tblExportBBL_Log_Add"

      ' Process qryBBLExport = tblCaptures ToBeExported AND (IsValid = "v" OR BypassErrors )

      Dim qdf As DAO.QueryDef
      Dim rst As DAO.Recordset
      Dim rstBBL As DAO.Recordset

120   Set qdf = CurrentDb.QueryDefs("qryExportBBL")
130   Set rst = qdf.OpenRecordset
140   Set rstBBL = CurrentDb.OpenRecordset("tblExportBBL_Log_Add")

150   Do While Not rst.EOF
           
160       rstBBL.AddNew
          
          ' IDBand
          
          Dim lngIDBand As Long
170       lngIDBand = Nz(rst.Fields("IDBand"))
180       rstBBL.Fields("IDBand") = lngIDBand
          
          ' BBL_Export_Timestamp
          
190       rstBBL.Fields("BBLExport_Timestamp") = strExportTimestamp
          
          Dim strDisposition
          
200       strDisposition = Nz(rst.Fields("Disposition"))
          
          Dim strBBLFiletype As String
          
          Dim strD3 As String   ' Aux Marker Type  01A, 01B
          Dim strD4 As String   ' Is Aux Marker Coded   "Y", "N"
          Dim strD5 As String   ' Aux Marker Code
          Dim strD6 As String   ' Aux Marker Band Color
          Dim strD7 As String   ' Aux Marker Code Color
          Dim strD8 As String   ' Left Leg Color 1
          Dim strD9 As String   ' Left Leg Color 2
          Dim strD10 As String  ' Left Leg Color 3
          Dim strD11 As String  ' Right Leg Color 1
          Dim strD12 As String  ' Right Leg Color 2
          Dim strD13 As String  ' Right Leg Color 3
          Dim i As Integer

' AUX: Nz([D3]) & Nz([D4]) & Nz([D5]) & Nz([D6]) & Nz([D7]) & Nz([D8]) & Nz([D9]) & Nz([D10]) & Nz([D11]) & Nz([D12]) & Nz([D13])

              
          Dim strAUX As String                        '      "" iif there is no AUX data
210       strAUX = Nz(rst.Fields("AUX"))
          
220       If strAUX = "" Then
230           If strDisposition = "R" Or strDisposition = "F" Then
240               strBBLFiletype = "Recaps"
250           Else
260               strBBLFiletype = "Banding"
270           End If
280       Else
290           If strDisposition = "R" Or strDisposition = "F" Then
300               strBBLFiletype = "RecapsAUX"
310           Else
320               strBBLFiletype = "BandingAUX"
330           End If
340       End If
350       rstBBL.Fields("BBL_Filetype") = strBBLFiletype
             
        ' Process the columns
        
        Dim strColumnID As String
        Dim rstCol As DAO.Recordset
        Dim lngID As Long
        Dim strFieldname As String
        Dim col As Long
        Dim strDataValue As String
        
        
        ' Special processing for the AUX fields
        
360     If strAUX <> "" Then
          
370           strD3 = Nz(rst.Fields("D3"))
380           strD4 = Nz(rst.Fields("D4"))
390           strD5 = Nz(rst.Fields("D5"))
400           strD6 = Nz(rst.Fields("D6"))
410           strD7 = Nz(rst.Fields("D7"))
420           strD8 = Nz(rst.Fields("D8"))
430           strD9 = Nz(rst.Fields("D9"))
440           strD10 = Nz(rst.Fields("D10"))
450           strD11 = Nz(rst.Fields("D11"))
460           strD12 = Nz(rst.Fields("D12"))
470           strD13 = Nz(rst.Fields("D13"))
              
              Dim strMarkerType(1 To 6) As String
              Dim strMarkerCode(1 To 6) As String
              Dim strMarkerColor(1 To 6) As String
              Dim strMarkerCodeColor(1 To 6) As String
              Dim strSideOfBird(1 To 6) As String
              
480           For i = 1 To 6
490               strMarkerType(i) = ""
500           Next
              
510           If strD4 = "Y" Then
520               strMarkerType(1) = strD3
530               strMarkerCode(1) = strD5
540               strMarkerColor(1) = strD6
550               strMarkerCodeColor(1) = strD7
560           Else
570               If strD8 <> "" Then
580                   strMarkerType(1) = strD3
590                   strMarkerColor(1) = strD8
600                   strSideOfBird(1) = "L"
610               End If
620               If strD9 <> "" Then
630                   strMarkerType(2) = strD3
640                   strMarkerColor(2) = strD9
650                   strSideOfBird(2) = "L"
660               End If
670               If strD10 <> "" Then
680                   strMarkerType(3) = strD3
690                   strMarkerColor(3) = strD10
700                   strSideOfBird(3) = "L"
710               End If
720                If strD11 <> "" Then
730                   strMarkerType(4) = strD3
740                   strMarkerColor(4) = strD11
750                   strSideOfBird(4) = "R"
760               End If
770               If strD12 <> "" Then
780                   strMarkerType(5) = strD3
790                   strMarkerColor(5) = strD12
800                   strSideOfBird(5) = "R"
810               End If
820               If strD13 <> "" Then
830                   strMarkerType(6) = strD3
840                   strMarkerColor(6) = strD13
850                   strSideOfBird(6) = "R"
860               End If
                  
                  
870           End If
              
880           For i = 1 To 6
890               If strMarkerType(i) <> "" Then
900                   strDataValue = strMarkerType(i)
910                   strColumnID = "Marker Type " & CStr(i)
920                   col = Nz(DLookup(strBBLFiletype & "_Column", "tblExportBBL_Excel_Columns", "ColumnID = '" & strColumnID & "'"))
930                   If col <> 0 Then
940                       rstBBL.Fields(strColumnID) = strDataValue
950                   End If
960               End If
970                If strMarkerCode(i) <> "" Then
980                   strDataValue = strMarkerCode(i)
990                   strColumnID = "Marker Code " & CStr(i)
1000                  col = Nz(DLookup(strBBLFiletype & "_Column", "tblExportBBL_Excel_Columns", "ColumnID = '" & strColumnID & "'"))
1010                  If col <> 0 Then
1020                      rstBBL.Fields(strColumnID) = strDataValue
1030                  End If
1040              End If
1050              If strMarkerColor(i) <> "" Then
1060                  strDataValue = strMarkerColor(i)
1070                  strColumnID = "Marker Color " & CStr(i)
1080                  col = Nz(DLookup(strBBLFiletype & "_Column", "tblExportBBL_Excel_Columns", "ColumnID = '" & strColumnID & "'"))
1090                  If col <> 0 Then
1100                      rstBBL.Fields(strColumnID) = strDataValue
1110                  End If
1120              End If
1130              If strMarkerCodeColor(i) <> "" Then
1140                  strDataValue = strMarkerCodeColor(i)
1150                  strColumnID = "Marker Code Color " & CStr(i)
1160                  col = Nz(DLookup(strBBLFiletype & "_Column", "tblExportBBL_Excel_Columns", "ColumnID = '" & strColumnID & "'"))
1170                  If col <> 0 Then
1180                      rstBBL.Fields(strColumnID) = strDataValue
1190                  End If
1200              End If
1210               If strSideOfBird(i) <> "" Then
1220                  strDataValue = strSideOfBird(i)
1230                  strColumnID = "Side Of Bird " & CStr(i)
1240                  col = Nz(DLookup(strBBLFiletype & "_Column", "tblExportBBL_Excel_Columns", "ColumnID = '" & strColumnID & "'"))
1250                  If col <> 0 Then
1260                      rstBBL.Fields(strColumnID) = strDataValue
1270                  End If
1280              End If
                  
1290          Next
1300      End If
          
      ' Process all the fields except AUX fields
       
1310    Set rstCol = CurrentDb.OpenRecordset("tblExportBBL_Excel_Columns")
1320    Do While Not rstCol.EOF
1330        strFieldname = Nz(rstCol.Fields("Fieldname"))       ' Field name in tblCaptures
1340        strColumnID = Nz(rstCol.Fields("ColumnID"))         ' Field name in tblExportBBL_Log_Add
      '      col = Nz(rstCol.Fields(strBBLFiletype & "_Column")) ' Excel column number
1350        If strFieldname <> "" And strFieldname <> "AUX" Then

1360            On Error Resume Next
1370            strDataValue = Nz(rst.Fields(strFieldname))      ' Get the data from tblCaptures.�strFieldname�
1380            If Err.Number <> 0 Then
1390                Call LogError("basExportBBL", "FillIn_tblExportBBL_Log_Add", "Error: Failed to get data from the " & strFieldname & " field in tblCaptures", True)
1400                Err.Clear
1410                fError = True
1420                GoTo Exit_label
1430            End If
1440            If strDataValue <> "" Then
      '              If col <> 0 Then
                    
1450                    Select Case strFieldname
                        
                        Case "HowAged"
                        
                            ' Translate internal Capture How Aged codes to BBL How Aged codes
                            '
                            ' Here we lookup tblHowAgedCaptureCodes (not tblHowAged)
                            ' tblHowAged is used to validate MBO HowAged codes and translate them to the HowAged codes used in tblCaptures
                            ' tblHowAgedCaptureCodes is used to validate the tblCaptures.HowAged codes used in tblCaptures and translate them to BBL How Aged codes
                      
1460                        strDataValue = Nz(DLookup("HowAgedBBLCode", "tblHowAgedCaptureCodes", "[HowAgedCaptureCode] = '" & strDataValue & "'"))

1470                    Case "HowSexed"
                        
                            ' Translate internal Capture How Sexed codes to BBL How Sexed codes
                            '
                            ' Here we lookup tblHowSexedCaptureCodes (not tblHowSexed)
                            ' tblHowSexed is used to validate MBO HowAged codes and translate them to the HowAged codes used in tblCaptures
                            ' tblHowSexedCaptureCodes is used to validate the tblCaptures.HowSexed codes used in tblCaptures and translate them to BBL How Sexed codes
                            
1480                        strDataValue = Nz(DLookup("HowSexedBBLCode", "tblHowSexedCaptureCodes", "[HowSexedCaptureCode] = '" & strDataValue & "'"))
                        
1490                    Case "WeightTimeStr"
                        
                              
                              ' "00:00" => ""
1500                          If strDataValue = "00:00" Then
1510                              strDataValue = ""
1520                          End If
                            
1530                      End Select
                        
1540                    rstBBL.Fields(strColumnID) = strDataValue
      '              End If
1550            End If
1560        End If
1570        rstCol.MoveNext
1580      Loop
           
1590      rstBBL.Update
1600      rst.MoveNext
1610  Loop
1620  rst.Close
1630  Set rst = Nothing
1640  rstBBL.Close
1650  Set rstBBL = Nothing

1660  fError = False

          'DD Error Handler Start
Exit_label:
1670      Exit Sub
Err_label:
1680      Select Case Err.Number
          Case Else
1690           Call LogError("basExportBBL", "FillIn_tblExportBBL_Log_Add")
1700      End Select
1710      Resume Exit_label
          ' DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' FillInSheet
'---------------------------------------------------------------------------------------
'
' oSheet is the Excel worksheet to be filled in from data in the table tblExportBBL_Log_Add
' strBBLFileType = "Banding", "Recaps", "BandingAUX", "RecapsAUX"
'
' tblExportBBL_Excel_Columns
' ColumnID ... a field name from tblExportBBL_Log_Add
' �strBBLFiletype�_Column ... column number in a �strBBLFiletype� BBL Export Excel file

' For every record in tblExportBBL_Log_Add for a given BBL Filetype
'    For every record in tblExportBBL_Excel_Columns
'        Get fieldname = tblExportBBL_Excel_Columns.ColumnID
'        Get col = tblExportBBL_Excel_Columns.�strBBLFiletype�_Column
'        If col <> 0 then
'            Get data from tblExportBBL_Log_Add.�fieldname�
'            Write date to column col of the worksheet




Private Sub FillInSheet(ByRef oSheet As Excel.Worksheet, ByVal strBBLFiletype As String)
10    On Error GoTo Err_label

      Dim row As Long
      Dim col As Long
      Dim strFieldname As String
      Dim strDataValue As String
      Dim strColumnID As String

      Dim strSQL As String
20    strSQL = "SELECT * FROM tblExportBBL_Log_Add WHERE BBL_Filetype = '" & strBBLFiletype & "'"
       
      Dim rst As DAO.Recordset
30    Set rst = CurrentDb.OpenRecordset(strSQL)

      ' For each row in tblExportBBL_Excel_Columns.
      '    Get the ColumnID - this will be the name of the field in tblExportBBL_Add_Log
      '    Get the  � strBBLFiletype�_Column - this is the Excel column

40    row = 2
50    Do While Not rst.EOF
              
           Dim rstCol As DAO.Recordset
           Dim lngID As Long
          
60         Set rstCol = CurrentDb.OpenRecordset("tblExportBBL_Excel_Columns")
70         Do While Not rstCol.EOF
80             strFieldname = Nz(rstCol.Fields("ColumnID"))  '  This is a field name in tblExportBBL_Add_Log
90             col = Nz(rstCol.Fields(strBBLFiletype & "_Column"))
100            If col <> 0 Then
110               If strFieldname <> "" Then
120                   On Error Resume Next
130                   strDataValue = Nz(rst.Fields(strFieldname))
140                   If Err.Number <> 0 Then
150                       Call LogError("basExportBBL", "FillInSheet", "Error: Failed to get data from the " & strFieldname & " field in tblExportBBL_Log_add", False)
160                       Err.Clear
170                   End If
180                   If strDataValue <> "" Then
190                       oSheet.Cells(row, col) = strDataValue
200                   End If
210               End If
220            End If
230            rstCol.MoveNext
240        Loop

250       row = row + 1
260       rst.MoveNext
270   Loop
280   rst.Close
290   Set rst = Nothing

          'DD Error Handler Start
Exit_label:
300       Exit Sub
Err_label:
310       Select Case Err.Number
          Case Else
320      Call LogError("basExportBBL", "FillInSheet")
330       End Select
340       Resume Exit_label
          ' DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' Create_output_file
'---------------------------------------------------------------------------------------
' Private Function Create_output_fileByVal strBBLFiletype As String, ByVal strBBLExportTimestamp As String) As String
' Clones a BBL Export Template for a specified BBL Export filetype
' Returns the filepath to the copy.
' The filename of the copy is the same as the filename of the BBL Excel template, but with an appended BBL Export Timestamp
'
' Return "" if there are no ToBeExported records for this BBL file type in tblExportBBL_Log_Add
' Browse for the BBL template
' Return "" if the BBL template does not exist
' Clone the BBL template file.  The clone is created in the reports folder
' Return the filepath to the clone
'
' Return "" if the user cancels the dialog box
'
' If anything goes wrong - return ""
'
'
' strFilepath = Create_output_file( strBBLFiletype , strBBLExportTimestamp )


Private Function Create_output_file(ByVal strBBLFiletype As String, ByVal strBBLExportTimestamp As String) As String
10    On Error GoTo Err_label

      Dim strTemplateFilepath As String
      Dim fs As Scripting.FileSystemObject
      Dim strReportFolderpath As String
      Dim strTemplateFilepathInitial As String
      Dim strTemplateFilepath_Banding As String
      Dim fTemplateFileExists As Boolean
      Dim strTemplateFilename As String
      Dim strTemplateFolderpath As String
      Dim strReportFilepath As String
      Dim strWhere As String

20    Create_output_file = ""

      ' Are there any records in tblExportBBL_Log_Add for this BBL Filetype
      ' tblExportBBL_Log_Add.BBL_Filetype
          
30    strWhere = "BBL_Filetype = '" & strBBLFiletype & "'"

40    If (DCount("*", "tblExportBBL_Log_Add", strWhere) > 0) Then

          ' Get the template file

50        strTemplateFilepathInitial = GetBBLTemplateFilepath(strBBLFiletype)
60        strTemplateFilepath = FileOpenDialogExcel(strTemplateFilepathInitial, "Open the BBL " & strBBLFiletype & " Template")
70        If strTemplateFilepath = "" Then
80            GoTo Exit_label
90        End If
          
100       strTemplateFilename = FileNameFromPath(strTemplateFilepath)
110       strTemplateFilename = StripAllExtensionsFromFilename(strTemplateFilename)
120       strTemplateFolderpath = FolderFromPath(strTemplateFilepath)
          
          ' Verify the template file exists
          
130       fTemplateFileExists = FileExists(strTemplateFilepath)
140       If Not fTemplateFileExists Then
150           MsgBox "The BBO Template file is missing", vbOKOnly
160           GoTo Exit_label
170       End If
                
          ' Get the folder for the output files
          
180       strReportFolderpath = GetExportFolder()
190       If Not FolderExists(strReportFolderpath) Then
200           strReportFolderpath = Rep_Documents()
210       End If
          
          ' Build the filepath to the new output file
          
220       strReportFilepath = TrailingSlash(strReportFolderpath) & strTemplateFilename & " " & strBBLExportTimestamp & ".xlsx"
          
          ' Clone the template file
          
230       Set fs = New Scripting.FileSystemObject
          
240       On Error Resume Next
250       Call fs.CopyFile(strTemplateFilepath, strReportFilepath, True)
260       If Err.Number <> 0 Then
270           MsgBox "Failed to copy a " & strBBLFiletype & " BBL Template file", vbOKOnly
280           Create_output_file = ""
290           Err.Clear
300           On Error GoTo Err_label
310           GoTo Exit_label
320       End If
              
330       Create_output_file = strReportFilepath
340   End If
              
          'DD Error Handler Start
Exit_label:
350       Exit Function
Err_label:
360       Select Case Err.Number
          Case Else
370            Call LogError("basExportBBL", "Create_output_file")
380       End Select
390       Resume Exit_label
          ' DD Error Handler End
              
End Function

Public Function Create_output_file_Test()
Dim strFilepath As String
Dim strBBLFiletype As String
Dim strBBLExportTimestamp As String

strBBLFiletype = "Banding"
strBBLExportTimestamp = "2025-03-01 12h49"
strFilepath = Create_output_file(strBBLFiletype, strBBLExportTimestamp)
Debug.Print strFilepath
End Function

Public Function Export_BBL_Test()
Dim lngCountExportedRecords As Long
Call ExportBBL(lngCountExportedRecords)
End Function

Public Function Test()

      Dim strToBeExported As String
      Dim strValid As String
      Dim strBypassErrors As String
      Dim fExport As Boolean
      Dim strBandPrefix As String
      Dim strBandSuffix As String
      Dim strBandNumber As String


      Dim qdf As QueryDef
10    Set qdf = CurrentDb.QueryDefs("qryExportBBL_Banding")
       
      Dim rst As DAO.Recordset
20    Set rst = qdf.OpenRecordset
30    Do While Not rst.EOF
          
      '    strToBeExported = Nz(rst.Fields("ToBeExported"))
      '    strValid = Trim(Nz(rst.Fields("Valid")))
      '    strBypassErrors = Nz(rst.Fields("BypassErrors"))
      '
      '    If strToBeExported = "True" And _
      '        (strValid = "v" Or strBypassErrors = "True") Then
      '        fExport = True
      '    Else
      '        fExport = False
      '    End If

40        strValid = Trim(Nz(rst.Fields("Valid")))
50        strBypassErrors = Nz(rst.Fields("BypassErrors"))

60        fExport = (strValid = "v" Or strBypassErrors = "True")
       
70        If fExport Then

80            strBandPrefix = Nz(rst.Fields("BandPrefix"))
90            strBandSuffix = Nz(rst.Fields("BandSuffix"))
100           strBandNumber = strBandPrefix & strBandSuffix

110           Debug.Print strBandNumber
120       End If

130       rst.MoveNext
140   Loop
150   rst.Close
160   Set rst = Nothing

End Function


'---------------------------------------------------------------------------------------
' FillIn_tblExportBBL_Log_Add_From_tblExport_Log
'---------------------------------------------------------------------------------------
' For a given BBL Export Timestamp, copy the records from tblExportBBL_Log to tblExportBBL_Log_Add
'
' We start by zapping tblExportBBL_Log_Add
' tblExportBBL_Log.BBLExport_Timestamp contains a BBL Export Timestamp
'
' Call FillIn_tblExportBBL_Log_Add_From_tblExport_Log(strBBLExportTimestamp)


Public Sub FillIn_tblExportBBL_Log_Add_From_tblExport_Log(ByVal strBBLExportTimestamp As String)
10    On Error GoTo Err_label

      ' ZAP tblExportBBL_Log_Add

20    CurrentDb.Execute "DELETE * FROM tblExportBBL_Log_Add"

      ' qryExportBBL_Reexport_Append
      ' ----------------------------
      ' Append query
      ' tblExportBBL_Log => tblExportBBL_Log_Add
      ' WHERE BBLExport_Timestamp = [argTimestamp]

      ' Copy the records from tblExportBBL_Long to tblExportBBL_Log_Add

      Dim qdf As QueryDef
30    Set qdf = CurrentDb.QueryDefs("qryExportBBL_Reexport_Append")
40    qdf.Parameters("argTimestamp").value = strBBLExportTimestamp
50    qdf.Execute

          'DD Error Handler Start
Exit_label:
60        Exit Sub
Err_label:
70        Select Case Err.Number
          Case Else
80       Call LogError("basExportBBL", "FillIn_tblExportBBL_Log_Add_From_tblExport_Log")
90        End Select
100       Resume Exit_label
          ' DD Error Handler End
End Sub


Public Sub FillIn_tblExportBBL_Log_Add_From_tblExport_Log_Test()
Dim strBBLExportTimestamp As String

strBBLExportTimestamp = "2025-03-01 12h49"
Call FillIn_tblExportBBL_Log_Add_From_tblExport_Log(strBBLExportTimestamp)

End Sub

'---------------------------------------------------------------------------------------
' BBLExportAgain
' Called from frmBBLExports.cbdBBLExport_Again_Click
'---------------------------------------------------------------------------------------
' tblExportBBL_Log (for a given BBL Export Timestamp) => BBL Excel files
' *** Does not change anything in tblCaptures ***

Public Sub BBLExportAgain(ByVal strExportTimestamp As String)
10    On Error GoTo Err_label

      Dim lngCountExportedRecords As Long
      Dim fError As Boolean

20    Call FillIn_tblExportBBL_Log_Add_From_tblExport_Log(strExportTimestamp)

      ' Create the BBL Excel files

      Dim strBBLFiletype(1 To 4) As String

30    strBBLFiletype(1) = "Banding"
40    strBBLFiletype(2) = "Recaps"
50    strBBLFiletype(3) = "BandingAUX"
60    strBBLFiletype(4) = "RecapsAUX"

      Dim fBBLFiletype(1 To 4) As Boolean
      Dim strReportFilepath(1 To 4) As String
      Dim i As Integer
      Dim lngBBLFiletype As Long

70    For i = 1 To 4

          Dim strWhere As String
80        strWhere = "BBL_Filetype = '" & strBBLFiletype(i) & "'"
          
90        lngBBLFiletype = DCount("*", "tblExportBBL_Log_Add", strWhere)
100       If lngBBLFiletype > 0 Then
110           strReportFilepath(i) = Create_output_file(strBBLFiletype(i), strExportTimestamp)
120       Else
130           strReportFilepath(i) = ""
140       End If
150   Next

      ' Verify there is anything to export

      Dim fExport As Boolean
160   fExport = False
170   For i = 1 To 4
180       fExport = fExport Or (strReportFilepath(i) <> "")
190   Next
200   If Not fExport Then
210       lngCountExportedRecords = 0
220       GoTo Exit_label
230   End If

      ' tblExportBBL_Long_Add => BBL Excel files
      ' If anything goes wrong exit

240   For i = 1 To 4
250       If strReportFilepath(i) <> "" Then
260     Call FillInBBLExcelFile(strBBLFiletype(i), strReportFilepath(i), fError)
270       End If
280       If fError Then
290     lngCountExportedRecords = 0
300     GoTo Exit_label
310       End If
320   Next

      ' Open the workbooks. Do not prompt.

330   For i = 1 To 4
340       If strReportFilepath(i) <> "" Then
350           Call OpenExcelWorkbook(strReportFilepath(i), False)
360       End If
370   Next

          'DD Error Handler Start
Exit_label:
380       Exit Sub
Err_label:
390       Select Case Err.Number
          Case Else
400      Call LogError("basExportBBL", "BBLExportAgain")
410       End Select
420       Resume Exit_label
          ' DD Error Handler End

End Sub
