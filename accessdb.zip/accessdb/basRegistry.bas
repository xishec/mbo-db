'---------------------------------------------------------------------------------------
' Module: basRegistry
' Author: David Davey
'---------------------------------------------------------------------------------------

Option Compare Database
Option Explicit

'---------------------------------------------------------------------------------------
' WriteRegistryKeys
'---------------------------------------------------------------------------------------
'
'MBODatabaseFilepath
'MBOAccessFilepath
'MBOBackupFilepath
'ExternalBackup
'ReplicationFolder
'ReplicationFolderMaximumNumberOfFiles
'ExternalBackupFolder
'ExternalBackupFolderMaximumNumberOfDatabaseFiles
'ViewErrorsAsTheyOccur
'DisplaySilentErrors


Public Sub WriteRegistryKeys()
On Error GoTo Err_label

' Write out "True" to the "PerformBackup" registry key

Call SaveSetting("MBO Database", "Default", "PerformBackup", "True")

' Write out the database program's path to the registry key MBO Database\Default\MBODatabaseFilepath

Dim strMBODatabaseFilepath As String
strMBODatabaseFilepath = CurrentProject.Fullname
Call SaveSetting("MBO Database", "Default", "MBODatabaseFilepath", strMBODatabaseFilepath)

' Write out the path to the Access executable to the registry  key MBO Database\Default\MBOAccessFilepath

Dim strPathToAccess As String
strPathToAccess = TrailingSlash(SysCmd(acSysCmdAccessDir)) & "Msaccess.exe"
Call SaveSetting("MBO Database", "Default", "MBOAccessFilepath", strPathToAccess)
    
' write out the path to the backup program to the registry  key MBO Database\Default\MBOBackupFilepath

Dim strPathToBackupProgram As String
strPathToBackupProgram = GetSettingEx("PathToBackupProgram")
Call SaveSetting("MBO Database", "Default", "MBOBackupFilepath", strPathToBackupProgram)

Call SaveSetting("MBO Database", "Default", "ExternalBackup", IIf(GetDataEntrySource() = "Live", "True", "False"))

Call SaveSetting("MBO Database", "Default", "ReplicationFolder", GetSettingEx("MBODataEntryReplicationFolder"))
    
Call SaveSetting("MBO Database", "Default", "ReplicationFolderMaximumNumberOfFiles", GetSettingEx("MBODataEntryReplicationFolderMaximumNumberOfFiles"))

Call SaveSetting("MBO Database", "Default", "ExternalBackupFolder", GetSettingEx("USBFlashDriveBackupFolder"))
    
Call SaveSetting("MBO Database", "Default", "ExternalBackupFolderMaximumNumberOfDatabaseFiles", GetSettingEx("USBFlashDriveBackupFolderMaximumNumberOfDatabaseFiles"))

    
Dim strViewErrorsAsTheyOccur As String
strViewErrorsAsTheyOccur = GetSettingEx("ViewErrorsAsTheyOccur")
Call SaveSetting("MBO Database", "Default", "ViewErrorsAsTheyOccur", strViewErrorsAsTheyOccur)
    
Dim fDisplaySilentErrors As Boolean
fDisplaySilentErrors = GetDisplaySilentErrors()
Call SaveSetting("MBO Database", "Default", "DisplaySilentErrors", _
    IIf(fDisplaySilentErrors, "True", "False"))



    

    'DD Error Handler Start
Exit_label:
    Exit Sub
Err_label:
    Select Case Err.Number
    Case Else
         Call LogError("basRegistry", "WriteRegistryKeys")
    End Select
    Resume Exit_label
    ' DD Error Handler End
End Sub
