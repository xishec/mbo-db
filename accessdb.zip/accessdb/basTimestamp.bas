Option Compare Database
Option Explicit

Private m_strTimestamp As String
Private m_intDelta As Integer


' Timestamp+ values are strings: yyyy-mm-dd hh:nn:ss 9999
' The delta 9999 is reset to 0000 every second.                   In pracice I supose it will always be 0000

'---------------------------------------------------------------------------------------
' Timestamp_Initialise
'---------------------------------------------------------------------------------------
' Call whenever the database is launched.
'
' Initilise the Timestamp+ generator

Public Sub Timestamp_Initialise()

10    On Error GoTo Err_label

20    m_strTimestamp = Format(Now(), "yyyy-mm-dd hh:nn:ss")
30    m_intDelta = 0

          'DD Error Handler Start
Exit_label:
40        Exit Sub
Err_label:
50        Select Case Err.Number
          Case Else
60             Call LogError("basTimestamp", "Timestamp_Initialise")
70        End Select
80        Resume Exit_label
          ' DD Error Handler End
End Sub


'---------------------------------------------------------------------------------------
' GetTimestamp
'---------------------------------------------------------------------------------------
' Each generated timestamp is guaranteed to be unique.

Public Function GetTimestamp() As String

      Dim strTimestamp_now As String

10       On Error GoTo Err_label

20    strTimestamp_now = Format(Now(), "yyyy-mm-dd hh:nn:ss")

30    If strTimestamp_now = m_strTimestamp Then
40        m_intDelta = m_intDelta + 1
50        If m_intDelta >= 900 Then Sleep (1000)
60        GetTimestamp = strTimestamp_now & Format(m_intDelta, " 0000")
70    Else
80        m_strTimestamp = strTimestamp_now
90        m_intDelta = 0
100       GetTimestamp = strTimestamp_now & " 0000"
110   End If


    'DD Error Handler Start
Exit_label:
120       Exit Function
Err_label:
130       Select Case Err.Number
    Case Else
140      Call LogError("basTimestamp", "GetTimestamp")
150       End Select
160       Resume Exit_label
    ' DD Error Handler End

End Function
