'---------------------------------------------------------------------------------------
' Module: basRestore
' Author: David Davey
'---------------------------------------------------------------------------------------

Option Compare Database
Option Explicit


' tblRestore_Temp
' ---------------
' IDRestore                 AutoNumber  Surrogate key - not used
' CreationTimestamp Text
' ModifyTimestampLog        Text    ModifyTimestamp in the logging record
' Command Text
' Source Text
' ModifyTimestampNewBand    Text    ModifyTimestamp on the NewBand record with the same CreationTimestamp (if there is such a record)
' ModifyTimestampRecapture  Text    ModifyTimestamp on the Recapture d record with the same CreationTimestamp (if there is such a record)
' ModifyTimestampCapture    Text    ModifyTimestamp on the Capture record with the same CreationTimestamp (if there is such a record)
' Action Text
' Select                    Yes/No - So Simon can choose the logging records to be restored
' BandPrefix Text
' BandSuffix Text
' ErrorMessage Text
' ModifyTimestampDatabase   Text     ModifyTimestamp on the NewBand, Recapture, or Capture record with the same CreationTimestamp (if there is such a record)
'
'
' =====================================================================================================================
' qryDataEntrySummary_Log
' ----------------------------------------
' tblCaptures_Log_CopyOfExternal_Temp
'
'CreationTimestamp:  D16
'ModifyTimestamp:  D17
' WHERE Command <> "Test"
'
' Report IDLog, CreationTimestamp, ModifyTimestamp, Command, Source, BandPrefix, BandSuffix
'
'
' =====================================================================================================================
' qryDataEntrySummary_Log_MaxIDLogForEachRecording
' ---------------------------------------------------------------------
' For each recording, filter out all log records except the most recent
' ---------------------------------------------------------------------
' qryDataEntrySummary_Log
'
' GROUP BY CreationTimestamp
'ModifyTimestamp:  Max ModifyTimestamp
'
' Report CreationTimestamp, ModifyTimestamp
'
' =====================================================================================================================
' qryDataEntrySummary_Log_Restore
' --------------------------------------------------------------------------------------------
' qryDataEntrySummary_Log_MaxIDLogForEachRecording x qryDataEntrySumary_Log ON ModifyTimestamp
'
'Report:  IDLog , CreationTimestamp, ModifyTimestamp, Command, Source, BandPrefix, BandSuffix
'
' =====================================================================================================================
' qryDataEntrySummary_Log_Restore_A
' ---------------------------------
' qryDataEntrySummary_Log_Restore LEFT OUTER JOIN tblCaptures ON CreationTimestamp
' qryDataEntrySummary_Log_Restore LEFT OUTER JOIN tblSheetNewBandsMultiSize_v2 ON CreationTimestamp
' qryDataEntrySummary_Log_Restore LEFT OUTER JOIN tblSheetRecaps_v2 ON CreationTimestamp
'
'ModifyTimestampLog:  ModifyTimestamp
'ModifyTimestampNewBand:    tblSheetNewBandsMultiSize_v2.D17
'ModifyTimestampRecapture:  tblSheetNewBandsMultiSize_v2.D17
'ModifyTimestampCapture:    tblCapturesD17
'
'Reports:  IDLog , CreationTimestamp, ModifyTimestampLog, Command, Source, ModifyTimestampNewBand, ModifyTimestampRecapture, ModifyTimestampCapture
'
' =====================================================================================================================
' qryDataEntrySummary_Log_Restore_Append
' ---------------------------------------------------------------------------
' Loads tblRestore_Temp from the results of qryDataEntrySummary_Log_Restore_B
' ---------------------------------------------------------------------------
' qryDataEntrySummary_Log_Restore_A
'
'ModifyTimestampLog:  ModifyTimestamp
'
'Stores:   IDLog , CreationTimestamp, ModifyTimestampLog, Command, Source, ModifyTimestampNewBand, ModifyTimestampRecapture, ModifyTimestampCapture
'
'
'Public Sub Load_tblRestore(ByRef strFolderpath As String)
'
'10    On Error GoTo Err_label
'
'20    Call CopyExternalDataEntryLogsToTemporaryInternalDataEntryLogs(strFolderpath)
'30    If strFolderpath = "" Then GoTo Exit_label
'
'40    On Error Resume Next
'50    CurrentDb.Execute "DELETE * FROM tblRestore_Temp"
'60    On Error GoTo Err_label
'
'      Dim qdf As QueryDef
'70    Set qdf = CurrentDb.QueryDefs("qryDataEntrySummary_Log_Restore_Append")
'80    qdf.Execute
'90    qdf.Close
'100   Set qdf = Nothing
'
'      Dim strModifyTimestampLog As String
'      Dim strModifyTimestampNewBand As String
'      Dim strModifyTimestampRecapture As String
'      Dim strModifyTimestampCapture As String
'      Dim strModifyTimestampDatabase As String
'
'      Dim strDatabaseRecordType As String                ' None, newBand, Recapture, Capture
'      Dim strSource             As String                ' Bands, Recaptures, Captures
'      Dim strCommand            As String                ' Add, Update, Delete, Test
'
'       For each logging operation
'
'      Dim strAction As String
'
'      Dim rst As DAO.Recordset
'110   Set rst = CurrentDb.OpenRecordset("tblRestore_Temp", dbOpenDynaset)
'120   Do While Not rst.EOF
'
'130       strAction = ""
'
'140       strSource = Nz(rst("Source"))
'150       strCommand = Nz(rst("Command"))
'160       strModifyTimestampLog = Nz(rst("ModifyTimestampLog"))
'170       strModifyTimestampNewBand = Nz(rst("ModifyTimestampNewBand"))
'180       strModifyTimestampRecapture = Nz(rst("ModifyTimestampRecapture"))
'190       strModifyTimestampCapture = Nz(rst("ModifyTimestampCapture"))
'
'           Validate there is at most one non-"" strModifyTimestampBand, strModifyTimestampRecapture, strModifyTimestampCapture
'
'           Determine the nature of the database record
'             None
'             NewBand
'             Recapture
'             Capture
'
'200       If strModifyTimestampNewBand <> "" Then
'210           If strModifyTimestampRecapture <> "" Or strModifyTimestampCapture <> "" Then
'220                strAction = "INVALID: Multiple records in the database"
'230                GoTo Continue_label
'240           End If
'250           strDatabaseRecordType = "NewBand"
'260           strModifyTimestampDatabase = strModifyTimestampNewBand
'270       ElseIf strModifyTimestampRecapture <> "" Then
'280           If strModifyTimestampNewBand <> "" Or strModifyTimestampCapture <> "" Then
'290                strAction = "INVALID: Multiple records in the database"
'300                GoTo Continue_label
'310           End If
'320           strDatabaseRecordType = "Recapture"
'330           strModifyTimestampDatabase = strModifyTimestampRecapture
'340       ElseIf strModifyTimestampCapture <> "" Then
'350           If strModifyTimestampNewBand <> "" Or strModifyTimestampRecapture <> "" Then
'360                strAction = "INVALID: Multiple records in the database"
'370                GoTo Continue_label
'380           End If
'390           strDatabaseRecordType = "Capture"
'400           strModifyTimestampDatabase = strModifyTimestampCapture
'410       Else
'420           strDatabaseRecordType = "None"
'430           strModifyTimestampDatabase = ""
'440       End If
'
'
'
'           If the ModifyTimestamp in the database record > the ModifyTimestamp in the data entry log record
'           => the supposedly latest data entry log record for this recording is'nt the latest
'           => i.e. the data entry log is missing the latest data entry log record for this recording
'           If ModifyTimestampDatabase = "", then the data entry log record is indeed the latest
'
'450       If strModifyTimestampDatabase > strModifyTimestampLog Then
'460           strAction = "INVALID: Incomplete log"
'470           GoTo Continue_label
'480       End If
'
'           Skip log records that correspond to a database record with the identical ModifyTimestamp
'           If strModifyTimestampLog = "", then the log record will be processed
'
'490       If strModifyTimestampDatabase = strModifyTimestampLog Then
'500           strAction = ""
'510           GoTo Continue_label
'520       End If
'
'           Command = "Test" log records will be skipped
'           Defensive - I filtered out "Test" logging records when I loaded tblRestore_Temp
'
'           Determine the action
'
'530       Select Case strSource
'          Case "Captures"
'540           Select Case strDatabaseRecordType
'              Case "None"
'550               Select Case strCommand
'                  Case "Add", "Update"
'560                   strAction = "Add capture"
'570               Case "Delete"
'580                    strAction = "Do nothing"
'590               End Select
'600           Case "NewBand"
'610               Select Case strCommand
'                  Case "Add", "Update"
'620                   strAction = "Delete new band + Add capture"
'630               Case "Delete"
'640                   strAction = "Delete new band but log delete capture"
'650               End Select
'660           Case "Recapture"
'670               Select Case strCommand
'                  Case "Add", "Update"
'680                   strAction = "Delete recapture + Add capture"
'690               Case "Delete"
'700                   strAction = "Delete recapture but log delete capture"
'710               End Select
'720           Case "Capture"
'730               Select Case strCommand
'                  Case "Add"
'740                   strAction = "Do nothing"
'750               Case "Update"
'760                   strAction = "Update capture"
'770               Case "Delete"
'780                   strAction = "Delete capture"
'790               End Select
'800           End Select
'810       Case "Bands"
'820           Select Case strDatabaseRecordType
'              Case "None"
'830               Select Case strCommand
'                  Case "Add", "Update"
'840                   strAction = "Add new band"
'850               Case "Delete"
'860                   strAction = "Do nothing"
'870               End Select
'880           Case "NewBand"
'890               Select Case strCommand
'                  Case "Add"
'900                   strAction = "Do nothing"
'910               Case "Update"
'920                   strAction = "Update new band"
'930               Case "Delete"
'940                   strAction = "Delete new band"
'950               End Select
'960           Case "Recapture"
'970                strAction = "INVALID: New band log record but there is record in the recapture sheet"
'980           Case "Capture"
'990                strAction = "INVALID: New band log record but there is capture record in the database"
'1000          End Select
'1010      Case "Recaptures"
'1020          Select Case strDatabaseRecordType
'              Case "None"
'1030              Select Case strCommand
'                  Case "Add", "Update"
'1040                  strAction = "Add recapture"
'1050              Case "Delete"
'1060                  strAction = "Do nothing"
'1070              End Select
'1080          Case "NewBand"
'1090               strAction = "INVALID: Recapture log record but there is record in the new band sheet"
'1100          Case "Recapture"
'1110              Select Case strCommand
'                  Case "Add"
'1120                   strAction = "Do nothing"
'1130              Case "Update"
'1140                   strAction = "Update recapture"
'1150              Case "Delete"
'1160                   strAction = "Delete recapture"
'1170              End Select
'1180          Case "Capture"
'1190               strAction = "INVALID: Recapture log record but there is capture record in the database"
'1200          End Select
'1210      End Select
'
'Continue_label:
'
'           Initialise the Select field in tblRestore_Temp to True
'           Update the Action field in tblRestore_Temp
'           Initialise the ErrorMessage field in tblRestore_Temp to ""
'
'1220      rst.Edit
'1230      rst("Select") = True
'1240      rst("Action") = strAction
'1250      rst("ErrorMessage") = Null
'1260      rst("ModifyTimestampDatabase") = strModifyTimestampDatabase
'1270      rst.Update
'
'1280      rst.MoveNext
'1290  Loop
'1300  rst.Close
'1310  Set rst = Nothing
'
'          DD Error Handler Start
'Exit_label:
'1320      Exit Sub
'Err_label:
'1330      Select Case Err.Number
'          Case Else
'1340     Call LogError("basRestore", "Load_tblRestore")
'1350      End Select
'1360      Resume Exit_label
'           DD Error Handler End
'End Sub





'Public Type CapturesType
'    IDBand             As Variant
'    Disposition        As Variant
'    BandPrefix         As Variant
'    BandSuffix         As Variant
'    Species            As Variant
'    WingChord          As Variant
'    Age                As Variant
'    HowAged            As Variant
'    Sex                As Variant
'    HowSexed           As Variant
'    Fat                As Variant
'    Weight             As Variant
'    CaptureDate        As Variant
'    WeightTime         As Variant
'    Bander             As Variant
'    Scribe             As Variant
'    Net                As Variant
'    NotesForMBO        As Variant
'    ToBeExported       As Variant
'    Valid              As Variant
'    Invalid            As Variant
'    BypassErrors       As Variant
'    AutoHistory        As Variant
'    ProbableAge        As Variant
'    ProbableSex        As Variant
'    Location           As Variant
'    BirdStatus         As Variant
'    PresentCondition   As Variant
'    HowObtainedCode    As Variant
'    Program            As Variant
'    FCombined          As Variant
'    F(conMaxUserField) As Variant
'    D(conMaxDataField) As Variant
'    Flags              As Variant
'    TimeStamp          As Date
'    Command            As String
'    Source             As String
'    IDLog              As Long
'End Type

'---------------------------------------------------------------------------------------
' GetCaptureRecordFromCapturesLogGivenPrimaryKey
'---------------------------------------------------------------------------------------
' Return C.IDBand = "ERROR", if the procedure fails

Public Sub GetCaptureRecordFromCapturesLogGivenPrimaryKey( _
    ByRef c As CapturesType, ByVal strModifyTimestamp As String, _
    Optional ByVal strCapturesLogTable = "tblCaptures_Log_CopyOfExternal_Temp")

      Dim rst As DAO.Recordset
      Dim u As Integer
      Dim D As Integer

10    On Error GoTo Err_label

20    Set rst = CurrentDb.OpenRecordset("SELECT * FROM " & strCapturesLogTable & " WHERE [D17] = '" & strModifyTimestamp & "'", dbOpenDynaset)
30    If rst.EOF Then
40        c.IDBand = "ERROR"
50        rst.Close
60        Set rst = Nothing
70        GoTo Exit_label
80    End If

90    c.IDBand = rst("IDBand")
100   c.Disposition = rst("Disposition")
110   c.BandPrefix = rst("BandPrefix")
120   c.BandSuffix = rst("BandSuffix")
130   c.Species = rst("Species")
140   c.WingChord = rst("WingChord")
150   c.Age = rst("Age")
160   c.HowAged = rst("HowAged")
170   c.Sex = rst("Sex")
180   c.HowSexed = rst("HowSexed")
190   c.Fat = rst("Fat")
200   c.Weight = rst("Weight")
210   c.CaptureDate = rst("CaptureDate")
220   c.WeightTime = rst("WeightTime")
230   c.Bander = rst("Bander")
240   c.Scribe = rst("Scribe")
250   c.Net = rst("Net")
260   c.NotesForMBO = rst("NotesForMBO")
270   c.ToBeExported = rst("ToBeExported")
280   c.Valid = rst("Valid")
290   c.Invalid = rst("Invalid")
300   c.BypassErrors = rst("BypassErrors")
310   c.AutoHistory = rst("AutoHistory")
320   c.ProbableAge = rst("ProbableAge")
330   c.ProbableSex = rst("ProbableSex")
340   c.Location = rst("Location")
350   c.BirdStatus = rst("BirdStatus")
360   c.PresentCondition = rst("PresentCondition")
370   c.HowObtainedCode = rst("HowObtainedCode")
380   c.Program = rst("Program")
390   c.FCombined = rst("F")
400   For u = 1 To conMaxUserField
410       c.F(u) = rst("F" & u)
420   Next
430   For D = 1 To conMaxDataField
440       c.D(D) = rst("D" & D)
450   Next
460   c.Flags = rst("Flags")

470   c.Command = rst("Command")
480   c.Source = rst("Source")


          'DD Error Handler Start
Exit_label:
490       Exit Sub
Err_label:
500       Select Case Err.Number
          Case Else
510           Call LogError("basRestore", "GetCaptureRecordFromCapturesLogGivenPrimaryKey")
520       End Select
530       Resume Exit_label
          ' DD Error Handler End
End Sub


'Public Type SheetNewBandsType
'    BandID             As Variant
'    Disposition        As Variant
'    BandSizeID         As Variant
'    BandPrefix         As Variant
'    BandSuffix         As Variant
'    Species            As Variant
'    WingChord          As Variant
'    Age                As Variant
'    HowAged            As Variant
'    Sex                As Variant
'    HowSexed           As Variant
'    Fat                As Variant
'    Weight             As Variant
'    CaptureDate        As Variant
'    CaptureYear        As Variant
'    WeightTime         As Variant
'    Bander             As Variant
'    Scribe             As Variant
'    Net                As Variant
'    NotesForMBO        As Variant
'    Valid              As Variant
'    Invalid            As Variant
'    Duplicate          As Variant
'    BypassErrors       As Variant
'    AutoHistory        As Variant
'    ProbableAge        As Variant
'    ProbableSex        As Variant
'    Location           As Variant
'    BirdStatus         As Variant
'    Program            As Variant
'    FCombined          As Variant
'    F(conMaxUserField) As Variant
'    Flags              As Variant
'    d(conMaxDataField) As Variant
'    TimeStamp          As Date
'    Command            As String
'    Source             As String
'    IDLog              As Long
'End Type

'---------------------------------------------------------------------------------------
' GetBandRecordFromBandsLogGivenPrimaryKey
'---------------------------------------------------------------------------------------
' Return B.BandID = "ERROR", if the procedure fails
'
' Called from
'    frmRestore.ActionAddNewBand
'    frmRestore.ActionDeleteNewBand
'
' The primary key is the Modify Timesatmp D17

Public Sub GetNewBandRecordFromDataEntryLogGivenPrimaryKey( _
    ByRef B As SheetNewBandsType, ByVal strModifyTimestamp As String, _
    Optional ByVal strCapturesLogTable = "tblCaptures_Log_CopyOfExternal_Temp")
          
      Dim rst As DAO.Recordset
      Dim u As Integer
      Dim D As Integer

10    On Error GoTo Err_label

20    Set rst = CurrentDb.OpenRecordset("SELECT * FROM " & strCapturesLogTable & " WHERE [D17] = '" & strModifyTimestamp & "'", dbOpenDynaset)
30    If rst.EOF Then
40        B.BandID = "ERROR"
50        rst.Close
60        Set rst = Nothing
70        GoTo Exit_label
80    End If

90    B.BandID = rst("BandID_Sheets")
100   B.Disposition = rst("Disposition")
110   B.BandSizeID = rst("BandSizeID_NewBands")
120   B.BandPrefix = rst("BandPrefix")
130   B.BandSuffix = rst("BandSuffix")
140   B.Species = rst("Species")
150   B.WingChord = rst("WingChord_Sheets")
160   B.Age = rst("Age")
170   B.HowAged = rst("HowAged")
180   B.Sex = rst("Sex")
190   B.HowSexed = rst("HowSexed")
200   B.Fat = rst("Fat")
210   B.Weight = rst("Weight")
220   B.CaptureDate = rst("CaptureDate_Sheets")
230   B.CaptureYear = rst("CaptureYear_Sheets")
240   B.WeightTime = rst("WeightTime_Sheets")
250   B.Bander = rst("Bander")
260   B.Scribe = rst("Scribe")
270   B.Net = rst("Net")
280   B.NotesForMBO = rst("NotesForMBO")
290   B.Valid = rst("Valid")
300   B.Invalid = rst("Invalid")
310   B.Duplicate = rst("Duplicate_NewBands")
320   B.BypassErrors = rst("BypassErrors")
330   B.AutoHistory = rst("AutoHistory")
340   B.ProbableAge = rst("ProbableAge")
350   B.ProbableSex = rst("ProbableSex")
360   B.Location = rst("Location")
370   B.BirdStatus = rst("BirdStatus")
380   B.Program = rst("Program")
390   B.FCombined = rst("F")
400   For u = 1 To conMaxUserField
410       B.F(u) = rst("F" & u)
420   Next
430   For D = 1 To conMaxDataField
440       B.D(D) = rst("D" & D)
450   Next
460   B.Flags = rst("Flags")

470   B.Command = rst("Command")
480   B.Source = rst("Source")


          'DD Error Handler Start
Exit_label:
490       Exit Sub
Err_label:
500       Select Case Err.Number
          Case Else
510            Call LogError("basRestore", "GetNewBandRecordFromDataEntryLogGivenPrimaryKey")
520       End Select
530       Resume Exit_label
          ' DD Error Handler End
          
End Sub

'Public Type SheetRecapturesType
'    BandID             As Variant
'    Disposition        As Variant
'    BandPrefix         As Variant
'    BandSuffix         As Variant
'    Species            As Variant
'    WingChord          As Variant
'    Age                As Variant
'    HowAged            As Variant
'    Sex                As Variant
'    HowSexed           As Variant
'    Fat                As Variant
'    Weight             As Variant
'    CaptureDate        As Variant
'    CaptureYear        As Variant
'    WeightTime         As Variant
'    Bander             As Variant
'    Scribe             As Variant
'    Net                As Variant
'    NotesForMBO        As Variant
'    Valid              As Variant
'    Invalid            As Variant
'    Duplicate          As Variant  '  Not used
'    BypassErrors       As Variant
'    AutoHistory        As Variant
'    ProbableAge        As Variant
'    ProbableSex        As Variant
'    Location           As Variant
'    BirdStatus         As Variant
'    PresentCondition   As Variant
'    HowObtainedCode    As Variant
'    Program            As Variant
'    FCombined          As Variant
'    F(conMaxUserField) As Variant
'    D(conMaxDataField) As Variant
'    Flags              As Variant
'    TimeStamp          As Date
'    Command            As String
'    Source             As String
'    IDLog              As Long
'End Type

'---------------------------------------------------------------------------------------
' GetRecaptureRecordFromDataEntryLogGivenPrimaryKey
'---------------------------------------------------------------------------------------
' Return R.BandID = "ERROR", if the procedure fails

Public Sub GetRecaptureRecordFromDataEntryLogGivenPrimaryKey( _
    ByRef R As SheetRecapturesType, ByVal strModifyTimestamp As String, _
    Optional ByVal strCapturesLogTable = "tblCaptures_Log_CopyOfExternal_Temp")
          
      Dim rst As DAO.Recordset
      Dim u As Integer
      Dim D As Integer

10    On Error GoTo Err_label

20    Set rst = CurrentDb.OpenRecordset("SELECT * FROM " & strCapturesLogTable & " WHERE [D17] = '" & strModifyTimestamp & "'", dbOpenDynaset)
30    If rst.EOF Then
40        R.BandID = "ERROR"
50        rst.Close
60        Set rst = Nothing
70        GoTo Exit_label
80    End If

90    R.BandID = rst("BandID_Sheets")
100   R.Disposition = rst("Disposition")
110   R.BandPrefix = rst("BandPrefix")
120   R.BandSuffix = rst("BandSuffix")
130   R.Species = rst("Species")
140   R.WingChord = rst("WingChord_Sheets")
150   R.Age = rst("Age")
160   R.HowAged = rst("HowAged")
170   R.Sex = rst("Sex")
180   R.HowSexed = rst("HowSexed")
190   R.Fat = rst("Fat")
200   R.Weight = rst("Weight")
210   R.CaptureDate = rst("CaptureDate_Sheets")
220   R.CaptureYear = rst("CaptureYear_Sheets")
230   R.WeightTime = rst("WeightTime_Sheets")
240   R.Bander = rst("Bander")
250   R.Scribe = rst("Scribe")
260   R.Net = rst("Net")
270   R.NotesForMBO = rst("NotesForMBO")
280   R.Valid = rst("Valid")
290   R.Invalid = rst("Invalid")
300   R.BypassErrors = rst("BypassErrors")
310   R.AutoHistory = rst("AutoHistory")
320   R.ProbableAge = rst("ProbableAge")
330   R.ProbableSex = rst("ProbableSex")
340   R.Location = rst("Location")
350   R.BirdStatus = rst("BirdStatus")
360   R.PresentCondition = rst("PresentCondition")
370   R.HowObtainedCode = rst("HowObtainedCode")
380   R.Program = rst("Program")

390   R.FCombined = rst("F")
400   For u = 1 To conMaxUserField
410       R.F(u) = rst("F" & u)
420   Next
430   For D = 1 To conMaxDataField
440       R.D(D) = rst("D" & D)
450   Next
460   R.Flags = rst("Flags")

470   R.Command = rst("Command")
480   R.Source = rst("Source")


          'DD Error Handler Start
Exit_label:
490       Exit Sub
Err_label:
500       Select Case Err.Number
          Case Else
510            Call LogError("basRestore", "GetRecaptureRecordFromDataEntryLogGivenPrimaryKey")
520       End Select
530       Resume Exit_label
          ' DD Error Handler End

    End Sub
    
'---------------------------------------------------------------------------------------
' AddBandRecord
'---------------------------------------------------------------------------------------
' BandID is AutoNumber
'
' Called from ActionAddNewBand

Public Sub AddNewBandRecord_Raw(ByRef B As SheetNewBandsType)

      Dim rst As DAO.Recordset
      Dim u As Integer
      Dim D As Integer

10    On Error GoTo Err_label

20    Set rst = CurrentDb.OpenRecordset("tblSheetNewBandsMultiSize_v2", dbOpenDynaset)

30    rst.AddNew
40    rst("Disposition") = B.Disposition
50    rst("BandSizeID") = B.BandSizeID
60    rst("BandPrefix") = B.BandPrefix
70    rst("BandSuffix") = B.BandSuffix
80    rst("Species") = B.Species
90    rst("WingChord") = B.WingChord
100   rst("Age") = B.Age
110   rst("HowAged") = B.HowAged
120   rst("Sex") = B.Sex
130   rst("HowSexed") = B.HowSexed
140   rst("Fat") = B.Fat
150   rst("Weight") = B.Weight
160   rst("CaptureDate") = B.CaptureDate
170   rst("CaptureYear") = B.CaptureYear
180   rst("WeightTime") = B.WeightTime
190   rst("Bander") = B.Bander
200   rst("Scribe") = B.Scribe
210   rst("Net") = B.Net
220   rst("NotesForMBO") = B.NotesForMBO
230   rst("Valid") = B.Valid
240   rst("Invalid") = B.Invalid
250   rst("Duplicate") = B.Duplicate
260   rst("BypassErrors") = B.BypassErrors
270   rst("AutoHistory") = B.AutoHistory
280   rst("ProbableAge") = B.ProbableAge
290   rst("ProbableSex") = B.ProbableSex
300   rst("Location") = B.Location
310   rst("BirdStatus") = B.BirdStatus
320   rst("Program") = B.Program
330   rst("F") = B.FCombined
340   For u = 1 To conMaxUserField
350       rst("F" & u) = B.F(u)
360   Next
370   rst("Flags") = B.Flags
380   For D = 1 To conMaxDataField
390       rst("D" & D) = B.D(D)
400   Next
410   rst.Update

420   rst.Close
430   Set rst = Nothing

          'DD Error Handler Start
Exit_label:
440       Exit Sub
Err_label:
450       Select Case Err.Number
          Case Else
460            Call LogError("basRestore", "AddBandRecord")
470       End Select
480       Resume Exit_label
          ' DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' AddRecaptureRecord
'---------------------------------------------------------------------------------------
' BandID is AutoNumber

Public Sub AddRecaptureRecord_Raw(ByRef R As SheetRecapturesType)

Dim rst As DAO.Recordset
Dim u As Integer
Dim D As Integer

10    On Error GoTo Err_label

20    Set rst = CurrentDb.OpenRecordset("tblSheetRecaps_v2", dbOpenDynaset)

30    rst.AddNew
40    rst("Disposition") = R.Disposition
50    rst("BandPrefix") = R.BandPrefix
60    rst("BandSuffix") = R.BandSuffix
70    rst("Species") = R.Species
80    rst("WingChord") = R.WingChord
90    rst("Age") = R.Age
100   rst("HowAged") = R.HowAged
110   rst("Sex") = R.Sex
120   rst("HowSexed") = R.HowSexed
130   rst("Fat") = R.Fat
140   rst("Weight") = R.Weight
150   rst("CaptureDate") = R.CaptureDate
160   rst("CaptureYear") = R.CaptureYear
170   rst("WeightTime") = R.WeightTime
180   rst("Bander") = R.Bander
190   rst("Scribe") = R.Scribe
200   rst("Net") = R.Net
210   rst("NotesForMBO") = R.NotesForMBO
220   rst("Valid") = R.Valid
230   rst("Invalid") = R.Invalid
240   rst("BypassErrors") = R.BypassErrors
250   rst("AutoHistory") = R.AutoHistory
260   rst("ProbableAge") = R.ProbableAge
270   rst("ProbableSex") = R.ProbableSex
280   rst("Location") = R.Location
290   rst("BirdStatus") = R.BirdStatus
300   rst("PresentCondition") = R.PresentCondition
310   rst("HowObtainedCode") = R.HowObtainedCode
320   rst("Program") = R.Program
330   rst("F") = R.FCombined
340   For u = 1 To conMaxUserField
350       rst("F" & u) = R.F(u)
360   Next
370   rst("Flags") = R.Flags
380   For D = 1 To conMaxDataField
390       rst("D" & D) = R.D(D)
400   Next
410   rst.Update

420   rst.Close
430   Set rst = Nothing

    'DD Error Handler Start
Exit_label:
440       Exit Sub
Err_label:
450       Select Case Err.Number
    Case Else
460      Call LogError("basRestore", "AddRecaptureRecord")
470       End Select
480       Resume Exit_label
    ' DD Error Handler End
End Sub





'---------------------------------------------------------------------------------------
' UpdateStatusFlagsInRecapturesVariantRecord

' Priority 1 - Not bypassable errors
'          2 - Bypassable errors
'          3 - Valid records
'---------------------------------------------------------------------------------------

Public Sub UpdateStatusFlagsInRecapturesVariantRecord( _
    ByRef R As SheetRecapturesType, _
    ByVal strBypassableMsg As String, _
    ByVal strNotBypassableMsg As String)

10    On Error GoTo Err_label

20    If strNotBypassableMsg <> "" Then
30        R.Valid = Null
40        R.Invalid = "E"
50        R.Disposition = Null
60    ElseIf strBypassableMsg <> "" Then
70        R.Valid = Null
80        R.Invalid = "x"
90    Else
100       R.Valid = "v"
110       R.Invalid = Null
120   End If

          'DD Error Handler Start
Exit_label:
130       Exit Sub
Err_label:
140       Select Case Err.Number
          Case Else
150            Call LogError("basRestore", "UpdateStatusFlagsInRecapturesVariantRecord")
160       End Select
170       Resume Exit_label
          ' DD Error Handler End

End Sub


'---------------------------------------------------------------------------------------
' TranslateSheetNewBandRecordTypeToSheetNewBandsType
'---------------------------------------------------------------------------------------

Public Sub TranslateSheetNewBandRecordTypeToSheetNewBandsType(ByRef B As SheetNewBandRecordType, ByRef B_variant As SheetNewBandsType)

      Dim uf As Integer
      Dim df As Integer

10    On Error GoTo Err_label

20    B_variant.BandID = B.BandID
30    B_variant.Disposition = B.Disposition
40    B_variant.BandSizeID = B.BandSizeID
50    B_variant.BandPrefix = B.BandPrefix
60    B_variant.BandSuffix = B.BandSuffix
70    B_variant.Species = B.Species
80    B_variant.WingChord = B.WingChord
90    B_variant.Age = B.Age
100   B_variant.HowAged = B.HowAged
110   B_variant.Sex = B.Sex
120   B_variant.HowSexed = B.HowSexed
130   B_variant.Fat = B.Fat
140   B_variant.Weight = B.Weight
150   B_variant.CaptureDate = B.CaptureDate
160   B_variant.CaptureYear = B.CaptureYear
170   B_variant.WeightTime = B.WeightTime
180   B_variant.Bander = B.Bander
190   B_variant.Scribe = B.Scribe
200   B_variant.Net = B.Net
210   B_variant.NotesForMBO = B.NotesForMBO
220   B_variant.Valid = B.Valid
230   B_variant.Invalid = B.Invalid
240   B_variant.Duplicate = B.Duplicate
250   B_variant.BypassErrors = B.BypassErrors
260   B_variant.AutoHistory = B.AutoHistory
270   B_variant.ProbableAge = B.ProbableAge
280   B_variant.ProbableSex = B.ProbableSex
290   B_variant.Location = B.Location
300   B_variant.BirdStatus = B.BirdStatus
310   B_variant.Program = B.Program
320   B_variant.FCombined = B.FCombined
330   For uf = 1 To conMaxUserField
340       B_variant.F(uf) = B.F(uf)
350   Next
360   For df = 1 To conMaxDataField
370       B_variant.D(df) = B.D(df)
380   Next


          'DD Error Handler Start
Exit_label:
390       Exit Sub
Err_label:
400       Select Case Err.Number
          Case Else
410            Call LogError("basRestore", "TranslateSheetNewBandRecordTypeToSheetNewBandsType")
420       End Select
430       Resume Exit_label
          ' DD Error Handler End
End Sub


'---------------------------------------------------------------------------------------
' TranslateSheetNewBandTypeToSheetNewBandsRecordType
'---------------------------------------------------------------------------------------
' variant => typed
'
' Called from frmRestore.ActionAddNewBand

Public Sub TranslateSheetNewBandTypeToSheetNewBandsRecordType(ByRef B_variant As SheetNewBandsType, ByRef B_typed As SheetNewBandRecordType)

      Dim uf As Integer
      Dim df As Integer

10    On Error GoTo Err_label

20    B_typed.BandID = Trim(Nz(B_variant.BandID))
30    B_typed.Disposition = Trim(Nz(B_variant.Disposition))
40    B_typed.BandSizeID = Trim(Nz(B_variant.BandSizeID))
50    B_typed.BandPrefix = Trim(Nz(B_variant.BandPrefix))
60    B_typed.BandSuffix = Trim(Nz(B_variant.BandSuffix))
70    B_typed.Species = Trim(Nz(B_variant.Species))
80    B_typed.WingChord = Trim(Nz(B_variant.WingChord))
90    B_typed.Age = Trim(Nz(B_variant.Age))
100   B_typed.HowAged = Trim(Nz(B_variant.HowAged))
110   B_typed.Sex = Trim(Nz(B_variant.Sex))
120   B_typed.HowSexed = Trim(Nz(B_variant.HowSexed))
130   B_typed.Fat = Trim(Nz(B_variant.Fat))
140   B_typed.Weight = Trim(Nz(B_variant.Weight))
150   B_typed.CaptureDate = Trim(Nz(B_variant.CaptureDate))
160   B_typed.CaptureYear = Trim(Nz(B_variant.CaptureYear))
170   B_typed.WeightTime = Trim(Nz(B_variant.WeightTime))
180   B_typed.Bander = Trim(Nz(B_variant.Bander))
190   B_typed.Scribe = Trim(Nz(B_variant.Scribe))
200   B_typed.Net = Trim(Nz(B_variant.Net))
210   B_typed.NotesForMBO = Trim(Nz(B_variant.NotesForMBO))
220   B_typed.Valid = Trim(Nz(B_variant.Valid))
230   B_typed.Invalid = Trim(Nz(B_variant.Invalid))
240   B_typed.Duplicate = Trim(Nz(B_variant.Duplicate))
250   B_typed.BypassErrors = Trim(Nz(B_variant.BypassErrors))
260   B_typed.AutoHistory = Trim(Nz(B_variant.AutoHistory))
270   B_typed.ProbableAge = Trim(Nz(B_variant.ProbableAge))
280   B_typed.ProbableSex = Trim(Nz(B_variant.ProbableSex))
290   B_typed.Location = Trim(Nz(B_variant.Location))
300   B_typed.BirdStatus = Trim(Nz(B_variant.BirdStatus))
310   B_typed.Program = Trim(Nz(B_variant.Program))
320   B_typed.FCombined = Trim(Nz(B_variant.FCombined))
330   For uf = 1 To conMaxUserField
340       B_typed.F(uf) = Trim(Nz(B_variant.F(uf)))
350   Next
360   For df = 1 To conMaxDataField
370       B_typed.D(df) = Trim(Nz(B_variant.D(df)))
380   Next

          'DD Error Handler Start
Exit_label:
390       Exit Sub
Err_label:
400       Select Case Err.Number
          Case Else
410            Call LogError("basRestore", "TranslateSheetNewBandTypeToSheetNewBandsRecordType")
420       End Select
430       Resume Exit_label
          ' DD Error Handler End
End Sub


'---------------------------------------------------------------------------------------
' TranslateSheetRecaptureTypeToSheetRecapturesRecordType
'---------------------------------------------------------------------------------------
' variant => typed

Public Sub TranslateSheetRecaptureTypeToSheetRecapturesRecordType( _
    ByRef R_variant As SheetRecapturesType, _
    ByRef R_typed As SheetRecaptureRecordType)

      Dim uf As Integer
      Dim df As Integer

10    On Error GoTo Err_label

20    R_typed.BandID = Trim(Nz(R_variant.BandID))
30    R_typed.LineNumber = ""
40    R_typed.Disposition = Trim(Nz(R_variant.Disposition))
50    R_typed.BandPrefix = Trim(Nz(R_variant.BandPrefix))
60    R_typed.BandSuffix = Trim(Nz(R_variant.BandSuffix))
70    R_typed.Species = Trim(Nz(R_variant.Species))
80    R_typed.WingChord = Trim(Nz(R_variant.WingChord))
90    R_typed.Age = Trim(Nz(R_variant.Age))
100   R_typed.HowAged = Trim(Nz(R_variant.HowAged))
110   R_typed.Sex = Trim(Nz(R_variant.Sex))
120   R_typed.HowSexed = Trim(Nz(R_variant.HowSexed))
130   R_typed.Fat = Trim(Nz(R_variant.Fat))
140   R_typed.Weight = Trim(Nz(R_variant.Weight))
150   R_typed.CaptureDate = Trim(Nz(R_variant.CaptureDate))
160   R_typed.WeightTime = Trim(Nz(R_variant.WeightTime))
170   R_typed.Bander = Trim(Nz(R_variant.Bander))
180   R_typed.Scribe = Trim(Nz(R_variant.Scribe))
190   R_typed.Net = Trim(Nz(R_variant.Net))
200   R_typed.NotesForMBO = Trim(Nz(R_variant.NotesForMBO))
210   R_typed.Valid = Trim(Nz(R_variant.Valid))
220   R_typed.Invalid = Trim(Nz(R_variant.Invalid))
230   R_typed.BypassErrors = Nz(R_variant.BypassErrors)
240   R_typed.AutoHistory = Nz(R_variant.AutoHistory)
250   R_typed.ProbableAge = Trim(Nz(R_variant.ProbableAge))
260   R_typed.ProbableSex = Trim(Nz(R_variant.ProbableSex))
270   R_typed.CaptureYear = Trim(Nz(R_variant.CaptureYear))
280   R_typed.Location = Trim(Nz(R_variant.Location))
290   R_typed.Program = Trim(Nz(R_variant.Program))
300   R_typed.BirdStatus = Trim(Nz(R_variant.BirdStatus))
310   R_typed.HowObtainedCode = Trim(Nz(R_variant.HowObtainedCode))
320   R_typed.PresentCondition = Trim(Nz(R_variant.PresentCondition))
330   R_typed.FCombined = Trim(Nz(R_variant.FCombined))
340   R_typed.CaptureCount = Nz(R_variant.CaptureCount)
350   For uf = 1 To conMaxUserField
360       R_typed.F(uf) = Trim(Nz(R_variant.F(uf)))
370   Next
380   R_typed.Flags = Trim(Nz(R_variant.Flags))
390   For df = 1 To conMaxDataField
400       R_typed.D(df) = Trim(Nz(R_variant.D(df)))
410   Next

          'DD Error Handler Start
Exit_label:
420       Exit Sub
Err_label:
430       Select Case Err.Number
          Case Else
440            Call LogError("basRestore", "TranslateSheetRecaptureTypeToSheetRecapturesRecordType")
450       End Select
460       Resume Exit_label
          ' DD Error Handler End
End Sub


'---------------------------------------------------------------------------------------
' TranslateSheetRecaptureRecordTypeToSheetRecapturesType
'---------------------------------------------------------------------------------------
' Call TranslateSheetRecaptureRecordTypeToSheetRecapturesType(R_typed, R_variant)
'
' typed -> variant

Public Sub TranslateSheetRecaptureRecordTypeToSheetRecapturesType( _
    ByRef R_typed As SheetRecaptureRecordType, _
    ByRef R_variant As SheetRecapturesType)

      Dim uf As Integer
      Dim df As Integer

10    On Error GoTo Err_label

20    R_variant.BandID = R_typed.BandID
30    R_variant.Disposition = R_typed.Disposition

40    R_variant.BandPrefix = R_typed.BandPrefix
50    R_variant.BandSuffix = R_typed.BandSuffix
60    R_variant.Species = R_typed.Species
70    R_variant.WingChord = R_typed.WingChord
80    R_variant.Age = R_typed.Age
90    R_variant.HowAged = R_typed.HowAged
100   R_variant.Sex = R_typed.Sex
110   R_variant.HowSexed = R_typed.HowSexed
120   R_variant.Fat = R_typed.Fat
130   R_variant.Weight = R_typed.Weight
140   R_variant.CaptureDate = R_typed.CaptureDate
150   R_variant.WeightTime = R_typed.WeightTime
160   R_variant.Bander = R_typed.Bander
170   R_variant.Scribe = R_typed.Scribe
180   R_variant.Net = R_typed.Net
190   R_variant.NotesForMBO = R_typed.NotesForMBO
200   R_variant.Valid = R_typed.Valid
210   R_variant.Invalid = R_typed.Invalid
220   R_variant.BypassErrors = R_typed.BypassErrors
230   R_variant.AutoHistory = R_typed.AutoHistory
240   R_variant.ProbableAge = R_typed.ProbableAge
250   R_variant.ProbableSex = R_typed.ProbableSex
260   R_variant.CaptureYear = R_typed.CaptureYear
270   R_variant.Location = R_typed.Location
280   R_variant.Program = R_typed.Program
290   R_variant.BirdStatus = R_typed.BirdStatus
300   R_variant.HowObtainedCode = R_typed.HowObtainedCode
310   R_variant.PresentCondition = R_typed.PresentCondition
320   R_variant.CaptureCount = R_typed.CaptureCount

330   R_variant.FCombined = R_typed.FCombined
340   For uf = 1 To conMaxUserField
350       R_variant.F(uf) = R_typed.F(uf)
360   Next
370   R_variant.Flags = R_typed.Flags
380   For df = 1 To conMaxDataField
390       R_variant.D(df) = R_typed.D(df)
400   Next

    'DD Error Handler Start
Exit_label:
410       Exit Sub
Err_label:
420       Select Case Err.Number
    Case Else
430      Call LogError("basRestore", "TranslateSheetRecaptureRecordTypeToSheetRecapturesType")
440       End Select
450       Resume Exit_label
    ' DD Error Handler End
End Sub


''---------------------------------------------------------------------------------------
'' TranslateSheetNewBandRecordTypeToSheetNewBandsType
''---------------------------------------------------------------------------------------
'
'Public Sub TranslateSheetNewBandsTypeToCapturesType(ByRef B As SheetNewBandsType, ByRef C As CapturesType)
'
'Dim uf As Integer
'Dim df As Integer
'
'On Error GoTo Err_label
'
'' BandID and IDBand are AutoNumber surrogate primary keys in the New Bands and Captures tables.  Do not copy.
'' LineNumber is no longer used.
'
'C.Disposition = B.Disposition
'C.BandSizeID = B.BandSizeID
'C.BandPrefix = B.BandPrefix
'C.BandSuffix = B.BandSuffix
'C.Species = B.Species
'
'' WingChord in SheetNewBandsType is "999"; in CapturesRecordType it is Long 99.9
'
'varWingChord = ConvertWingChordToVBALong(B.WingChord)
'
'
'C.Age = B.Age
'C.HowAged = B.HowAged
'C.Sex = B.Sex
'C.HowSexed = B.HowSexed
'C.Fat = B.Fat
'C.Weight = B.Weight
'C.CaptureDate = B.CaptureDate
'C.CaptureYear = B.CaptureYear
'C.WeightTime = B.WeightTime
'C.Bander = B.Bander
'C.Scribe = B.Scribe
'C.Net = B.Net
'C.NotesForMBO = B.NotesForMBO
'C.Valid = B.Valid
'C.Invalid = B.Invalid
'C.Duplicate = B.Duplicate
'C.BypassErrors = B.BypassErrors
'C.AutoHistory = B.AutoHistory
'C.ProbableAge = B.ProbableAge
'C.ProbableSex = B.ProbableSex
'C.Location = B.Location
'C.BirdStatus = B.BirdStatus
'C.Program = B.Program
'C.FCombined = B.FCombined
'For uf = 1 To conMaxUserField
'    CF(uf) = B.F(uf)
'Next
'For df = 1 To conMaxDataField
'    CD(df) = B.D(df)
'Next
'
'
'    'DD Error Handler Start
'Exit_label:
'    Exit Sub
'Err_label:
'    Select Case Err.Number
'    Case Else
'         Call LogError("basRestore", "TranslateSheetNewBandRecordTypeToSheetNewBandsType")
'    End Select
'    Resume Exit_label
'    ' DD Error Handler End
'End Sub

'---------------------------------------------------------------------------------------
' TranslateCapturesTypeToCapturesRecordType
'---------------------------------------------------------------------------------------
' variant => typed

Public Sub TranslateCapturesTypeToCapturesRecordType(ByRef C_variant As CapturesType, ByRef C_typed As CapturesRecordType)

      Dim uf As Integer
      Dim df As Integer

10    On Error GoTo Err_label

20    C_typed.IDBand = Nz(C_variant.IDBand)
30    C_typed.Disposition = Trim(Nz(C_variant.Disposition))

40    C_typed.BandPrefix = Trim(Nz(C_variant.BandPrefix))
50    C_typed.BandSuffix = Trim(Nz(C_variant.BandSuffix))
60    C_typed.Species = Trim(Nz(C_variant.Species))
70    C_typed.WingChord = Nz(C_variant.WingChord)
80    C_typed.Age = Trim(Nz(C_variant.Age))
90    C_typed.HowAged = Trim(Nz(C_variant.HowAged))
100   C_typed.Sex = Trim(Nz(C_variant.Sex))
110   C_typed.HowSexed = Trim(Nz(C_variant.HowSexed))
120   C_typed.Fat = Trim(Nz(C_variant.Fat))
130   C_typed.Weight = Nz(C_variant.Weight)
140   C_typed.CaptureDate = Nz(C_variant.CaptureDate)
150   C_typed.WeightTime = C_variant.WeightTime                ' C_typed.WeightTime is a Variant
160   C_typed.Bander = Trim(Nz(C_variant.Bander))
170   C_typed.Scribe = Trim(Nz(C_variant.Scribe))
180   C_typed.Net = Trim(Nz(C_variant.Net))
190   C_typed.NotesForMBO = Trim(Nz(C_variant.NotesForMBO))
200   C_typed.ToBeExported = Nz(C_variant.ToBeExported)
210   C_typed.Valid = Trim(Nz(C_variant.Valid))
220   C_typed.Invalid = Trim(Nz(C_variant.Invalid))
230   C_typed.BypassErrors = Nz(C_variant.BypassErrors)
240   C_typed.AutoHistory = Nz(C_variant.AutoHistory)
250   C_typed.ProbableAge = Trim(Nz(C_variant.ProbableAge))
260   C_typed.ProbableSex = Trim(Nz(C_variant.ProbableSex))
270   C_typed.Location = Trim(Nz(C_variant.Location))
280   C_typed.Program = Trim(Nz(C_variant.Program))
290   C_typed.BirdStatus = Trim(Nz(C_variant.BirdStatus))
300   C_typed.PresentCondition = Trim(Nz(C_variant.PresentCondition))
310   C_typed.HowObtainedCode = Trim(Nz(C_variant.HowObtainedCode))
320   C_typed.FCombined = Trim(Nz(C_variant.FCombined))

330   For uf = 1 To conMaxUserField
340       C_typed.F(uf) = Trim(Nz(C_variant.F(uf)))
350   Next

360   C_typed.Flags = Trim(Nz(C_variant.Flags))

370   For df = 1 To conMaxDataField
380       C_typed.D(df) = Trim(Nz(C_variant.D(df)))
390   Next

          'DD Error Handler Start
Exit_label:
400       Exit Sub
Err_label:
410       Select Case Err.Number
          Case Else
420            Call LogError("basRestore", "TranslateCapturesTypeToCapturesRecordType")
430       End Select
440       Resume Exit_label
          ' DD Error Handler End
End Sub
