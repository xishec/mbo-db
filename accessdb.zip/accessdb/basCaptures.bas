'---------------------------------------------------------------------------------------
' Module    : basCaptures
' Author    : David Davey
'---------------------------------------------------------------------------------------

Option Compare Database
Option Explicit

Private PrefixOldValue As String ' To pass OldValue to After Update event
Private SuffixOldValue As String
Private SpeciesOldValue As String

' When the user deletes one or more capture records
' The Delete event saves each band number
' The AfterDelConfirm event recalculates the DET Category (D18) for each capture record of the saved bands

Private DeletedBands As Scripting.Dictionary

'---------------------------------------------------------------------------------------
' Raw_AddRecordToCapturesTable
'---------------------------------------------------------------------------------------
' This code works for all Dispositions
' Input: varCapture has been filled in
' Output: varCapture.IDBand and varCapture.D22 = the new IDBand
' No spin off processing

Public Sub Raw_AddRecordToCapturesTable(ByRef varCapture As CapturesType)
On Error GoTo Err_label

Dim varWeightTime As Variant

' Add an empty record to tblCaptures

Dim lngIDBand As Long
lngIDBand = Raw_AddEmptyRecordToCapturesTable()

' Fill in the new captures record from varCapture

Dim rstStore As DAO.Recordset
Dim strSQL As String
strSQL = "SELECT * FROM tblCaptures WHERE IDBand = " & lngIDBand
Set rstStore = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)

rstStore.Edit
rstStore("Disposition") = varCapture.Disposition
rstStore("BandPrefix") = varCapture.BandPrefix
rstStore("BandSuffix") = varCapture.BandSuffix
rstStore("Species") = varCapture.Species
rstStore("WingChord") = varCapture.WingChord
rstStore("Age") = varCapture.Age
rstStore("HowAged") = varCapture.HowAged
rstStore("Sex") = varCapture.Sex
rstStore("HowSexed") = varCapture.HowSexed
rstStore("Fat") = varCapture.Fat
rstStore("Weight") = varCapture.Weight
rstStore("CaptureDate") = varCapture.CaptureDate
varWeightTime = varCapture.WeightTime
rstStore("WeightTime") = varWeightTime
rstStore("Bander") = varCapture.Bander
rstStore("Scribe") = varCapture.Scribe
rstStore("Net") = varCapture.Net
rstStore("NotesForMBO") = varCapture.NotesForMBO
rstStore("ProbableAge") = varCapture.ProbableAge
rstStore("ProbableSex") = varCapture.ProbableSex
rstStore("BirdStatus") = varCapture.BirdStatus
rstStore("Location") = varCapture.Location
rstStore("Program") = varCapture.Program
rstStore("HowObtainedCode") = varCapture.HowObtainedCode
rstStore("PresentCondition") = varCapture.PresentCondition
rstStore("BypassErrors") = varCapture.BypassErrors
rstStore("Valid") = varCapture.Valid
rstStore("Invalid") = varCapture.Invalid
rstStore("ToBeExported") = varCapture.ToBeExported
rstStore("AutoHistory") = varCapture.AutoHistory
rstStore("F") = varCapture.FCombined
rstStore("Flags") = varCapture.Flags

Dim uf As Integer

For uf = 1 To conMaxUserField
    rstStore("F" & uf) = varCapture.F(uf)
Next uf

Dim df As Integer

For df = 1 To conMaxDataField
    rstStore("D" & df) = varCapture.D(df)
Next df

rstStore("D22") = lngIDBand

Dim strTimestamp As String
strTimestamp = Format(Now(), "yyyy-mm-dd hh\hnn\mss")

rstStore("D16") = strTimestamp ' Creation Timestamp
rstStore("D17") = strTimestamp ' Modification Timestamp

rstStore.Update
    
varCapture.IDBand = lngIDBand
varCapture.D(22) = lngIDBand
varCapture.D(16) = strTimestamp
varCapture.D(17) = strTimestamp




    'DD Error Handler Start
Exit_label:
    Exit Sub
Err_label:
    Select Case Err.Number
    Case Else
   Call LogError("basCaptures", "Raw_AddRecordToCapturesTable")
    End Select
    Resume Exit_label
    ' DD Error Handler End
End Sub




'---------------------------------------------------------------------------------------
' Raw_AddEmptyRecordToCapturesTable
'---------------------------------------------------------------------------------------
' Lookup IDBandNext for this PC
' IDBand for the new record = IDBandNext
' IDBandNext++
' Update IDBandNext for this PC
' INSERT an empty record (except for its primary key IDBand) into tblCaptures
' Returns IDBand

Public Function Raw_AddEmptyRecordToCapturesTable() As Long
10    On Error GoTo Err_label

      Dim strWinDeviceName As String
      Dim lngIDBand As Long
      Dim strSQL As String

20    strWinDeviceName = GetWinDeviceName()
30    lngIDBand = DLookup("IDBandNext", "tblPC", "[WinDeviceName] = '" & strWinDeviceName & "'")
40    strSQL = "UPDATE tblPC SET IDBandNext = " & lngIDBand + 1 & " WHERE [WinDeviceName] = '" & strWinDeviceName & "'"
50    CurrentDb.Execute strSQL
60    strSQL = "INSERT INTO tblCaptures(IDBand) VALUES( " & lngIDBand & ")"
70    CurrentDb.Execute strSQL
80    Raw_AddEmptyRecordToCapturesTable = lngIDBand

          'DD Error Handler Start
Exit_label:
90        Exit Function
Err_label:
100       Select Case Err.Number
          Case Else
110            Call LogError("basCaptures", "Raw_AddEmptyRecordToCapturesTable")
120       End Select
130       Resume Exit_label
          ' DD Error Handler End
End Function



'---------------------------------------------------------------------------------------
' ValidateToBeExportedCaptures
'
' I first Null the Valid and Invalid flags for ALL capture records.
' When I am finished here, the Valid and Invalid of all NOT To Be Exported records are Null
' and they are assigned for each To Be Exported record
'---------------------------------------------------------------------------------------
 
Public Sub ValidateToBeExportedCaptures()

10    On Error GoTo Err_label

      Dim rst As DAO.Recordset
      Dim strSQL As String
      
'      ' just in case ...
'
'20    Call SetBypassableErrorMessageCurrentProgram

20    strSQL = "UPDATE tblCaptures SET Valid = Null, Invalid = Null"
30    CurrentDb.Execute strSQL

40    strSQL = "SELECT * FROM tblCaptures WHERE ToBeExported"
50    Set rst = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)
60    rst.MoveLast
      Dim lngRecordCount As Long
70    lngRecordCount = rst.RecordCount
80    SysCmd acSysCmdInitMeter, "validating...", lngRecordCount
90    rst.MoveFirst

      Dim n As Long
100   n = 0

      Dim IsValid As basTypes.IsValidType
      Dim B As BandsType
      Dim strNotBypassableMsg As String
      Dim strBypassableMsg As String

110   Do While Not rst.EOF

         ' Update the progress bar every 10 records
         
120       n = n + 1
130      If CLng(n / 10) * 10 = n Then

140          SysCmd acSysCmdInitMeter, "validating " & lngRecordCount - n, lngRecordCount
150          SysCmd acSysCmdUpdateMeter, n
160          DoEvents
170      End If

180       Call basCaptures.GetRecord(rst("IDBand"), B)
190       Call basCaptures.ValidateRecord(B, False, conUpdateValidationFlagsTrue, IsValid, _
              strNotBypassableMsg, strBypassableMsg)
200       rst.MoveNext
210   Loop
220   rst.Close
230   Set rst = Nothing

240   SysCmd acSysCmdRemoveMeter

      'DD Error Handler Start
Exit_label:
250        Exit Sub
Err_label:
260        Select Case Err.Number
           Case Else
270       Call LogError("basCaptures", "cmdValidateToBeExportedBandsTable_Click")
280        End Select
290        Resume Exit_label
      'DD Error Handler End
End Sub

''---------------------------------------------------------------------------------------
'' cmdHistory_Click
''---------------------------------------------------------------------------------------
'
'Public Sub cmdHistory_Click(frm As Form)
'10    On Error GoTo Err_label
'
'20    If frm.Dirty Then frm.Dirty = False
'
'      Dim BandPrefix As String
'      Dim BandSuffix As String
'
'30    BandPrefix = Trim(Nz(frm.Prefix))
'40    BandSuffix = Trim(Nz(frm.Suffix))
'
'50    Call ShowHistory(BandPrefix, BandSuffix)
'
'      'DD Error Handler Start
'Exit_label:
'60         Exit Sub
'Err_label:
'70         Select Case Err.Number
'           Case Else
'80        Call LogError("basCaptures", "cmdHistory_Click")
'90         End Select
'100        Resume Exit_label
'      'DD Error Handler End
'End Sub

'------------------------------------------------------------
' UpdateStatusFlags
'
' Compute what the validation flags should be
' If fUpdateValidationFlags = True
'     Update the validation flags
'
' Priority 1 - Duplicate New Captures
'          2 - Blank record
'          3 - Not bypassable errors
'          4 - Bypassable errors
'          5 - Valid records
'
' Called from ValidateRecord()
'------------------------------------------------------------

Private Sub UpdateStatusFlags( _
    IDBand As Long, _
    ByVal fToBeExported As Boolean, _
    ByVal fIsLineBlank As Boolean, _
    ByVal strBypassableMsg As String, _
    ByVal strNotBypassableMsg As String, _
    ByVal fUpdateValidationFlags As Boolean, _
    ByRef varValid As Variant, _
    ByRef varInvalid As Variant)
          
10    On Error GoTo Err_label

20    If Not fToBeExported Then
30        varValid = Null
40        varInvalid = Null
50    ElseIf fIsLineBlank Then
60        varValid = Null
70        varInvalid = Null
80    ElseIf strNotBypassableMsg <> "" Then
90        varValid = Null
100       varInvalid = "E"
110   ElseIf strBypassableMsg <> "" Then
120       varValid = Null
130       varInvalid = "x"
140   Else
150       varValid = "v"
160       varInvalid = Null
170   End If

180   If fUpdateValidationFlags Then
          
          Dim rst As DAO.Recordset
          Dim strSQL As String
190       strSQL = _
              "SELECT * " & _
              "FROM tblCaptures " & _
              "WHERE IDBand = " & IDBand
200       Set rst = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)
210       If rst.EOF Then Exit Sub
          
220           rst.Edit
230           If Not fToBeExported Then
240               rst("Valid") = varValid
250               rst("Invalid") = varInvalid
260           ElseIf fIsLineBlank Then
270               rst("Valid") = varValid
280               rst("Invalid") = varInvalid
290               rst("BypassErrors") = False
300           ElseIf strNotBypassableMsg <> "" Then
310               rst("Valid") = varValid
320               rst("Invalid") = varInvalid
330           ElseIf strBypassableMsg <> "" Then
340               rst("Valid") = varValid
350               rst("Invalid") = varInvalid
360           Else
370               rst("Valid") = varValid
380               rst("Invalid") = varInvalid
390           End If
400           rst.Update
              
410       rst.Close

420   End If

      'DD Error Handler Start
Exit_label:
430        Exit Sub
Err_label:
440        Select Case Err.Number
           Case Else
450       Call LogError("basCaptures", "UpdateStatusFlags")
460        End Select
470        Resume Exit_label
      'DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' GetRecord
'---------------------------------------------------------------------------------------

Public Sub GetRecord(ByVal IDBand As Long, ByRef B As BandsType)

      Dim rst As DAO.Recordset
      Dim strSQL As String
10    strSQL = _
          "SELECT * " & _
          "FROM tblCaptures " & _
          "WHERE IDBand = " & IDBand
20    Set rst = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)
30    If rst.EOF Then Exit Sub

40    B.IDBand = rst("IDBand")

50    B.BandPrefix = Trim(Nz(rst("BandPrefix")))
60    B.BandSuffix = Trim(Nz(rst("BandSuffix")))
70    B.Disposition = Trim(Nz(rst("Disposition")))
80    B.Species = Trim(Nz(rst("Species")))
90    B.Age = Trim(Nz(rst("Age")))
100   B.HowAged = Trim(Nz(rst("HowAged")))
110   B.Sex = Trim(Nz(rst("Sex")))
120   B.HowSexed = Trim(Nz(rst("HowSexed")))
130   B.WingChord = Nz(rst("WingChord"))
140   B.Fat = Trim(Nz(rst("Fat")))
150   B.Weight = Nz(rst("Weight"))
160   B.CaptureDate = Nz(rst("CaptureDate"))
170   B.WeightTime = Nz(rst("WeightTime"))
180   B.Bander = Trim(Nz(rst("Bander")))
190   B.Net = Trim(Nz(rst("Net")))
200   B.Scribe = Trim(Nz(rst("Scribe")))
210   B.BirdStatus = Trim(Nz(rst("BirdStatus")))
220   B.Location = Trim(Nz(rst("Location")))
230   B.ProbableAge = Trim(Nz(rst("ProbableAge")))
240   B.ProbableSex = Trim(Nz(rst("ProbableSex")))
250   B.NotesForMBO = Trim(Nz(rst("NotesForMBO")))
260   B.PresentCondition = Trim(Nz(rst("PresentCondition")))
270   B.HowObtainedCode = Trim(Nz(rst("HowObtainedCode")))
280   B.Program = Trim(Nz(rst("Program")))
290   B.AutoHistory = Nz(rst("AutoHistory"))
300   B.ToBeExported = Nz(rst("ToBeExported"))

      Dim df As Integer
310   For df = 1 To conMaxUserField
320       B.F(df) = Trim(Nz(rst("F" & df)))
330   Next df

340   rst.Close

End Sub

' ---------------------------------------------------------------------------
' ValidateRecord
' ---------------------------------------------------------------------------
' Validate a single capture record
'
' Validate the Prefix
' Validate the Suffix
' IsValid.BandValid = (Prefix is valid ) AND (Suffix is valid)
'
' If ToBeExported OR fDisplayErrors OR fValidationRequired
'     Validate the record
'     Validate the user fields
' Call UpdateStatusFlags - determines the Valid and Invalid flags
' For NOT ToBeExported OR blank records, the Valid and Invalid flags are Null
' Otherwise for records with a NotBypassable error, Valid = Null, Invalid = "E"
' Otherwise for records with a Bypassable error, Valid = Null, Invalid = "E"
' Otherwise Valid = "v", Invalid= Null
' If fUpdateValidationFlags then update the Valid and Invalid flags in the record
' If fDisplayErrors, display the errors, if any

Public Sub ValidateRecord(B As BandsType, _
    ByVal fDisplayErrors As Boolean, _
    ByVal fUpdateValidationFlags As Boolean, _
    ByRef IsValid As basTypes.IsValidType, _
    ByRef strNotBypassableMsg As String, _
    ByRef strBypassableMsg As String, _
    Optional ByVal fValidationRequired As Boolean = False)

10    On Error GoTo Err_label

      Dim strNotBypassableErr As String
      Dim strBypassableErr As String
      Dim fIsLineBlank As Boolean

20    IsValid.IsBandValid = True

      ' Validate the prefix

30    strNotBypassableErr = ""
40    strBypassableErr = ""
50    If Not IsBandPrefixValid(B.BandPrefix, strNotBypassableErr) Then
60        strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
70        IsValid.IsBandValid = False
80    End If

      ' Validate the suffix

90    strNotBypassableErr = ""
100   strBypassableErr = ""
110   If Not IsBandSuffixValid(B.BandSuffix, strNotBypassableErr, False) Then
120       strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
130       IsValid.IsBandValid = False
140   End If

150   If B.ToBeExported Or fDisplayErrors Or fValidationRequired Then

160       strNotBypassableMsg = ""
170       strBypassableMsg = ""
180       Call ValidateBandsRecord(B, strNotBypassableMsg, _
              strBypassableMsg, fIsLineBlank, IsValid)

            ' Validate the user fields
          
            Dim F(conMaxUserField) As String
            Dim df As Integer
190         For df = 1 To conMaxUserField
200             F(df) = B.F(df)
210         Next df
220         strBypassableErr = ""
230         If Not ValidateUserFields(B.Species, F, strBypassableErr) Then
240             strBypassableMsg = strBypassableMsg & strBypassableErr
250         End If

260   End If

      Dim varValid As Variant
      Dim varInvalid As Variant

270   Call UpdateStatusFlags(B.IDBand, B.ToBeExported, fIsLineBlank, _
          strBypassableMsg, strNotBypassableMsg, fUpdateValidationFlags, _
          varValid, varInvalid)
          
280   IsValid.varValid = varValid
290   IsValid.varInvalid = varInvalid

300   If fDisplayErrors Then

          Dim strErr As String
          
310       If fIsLineBlank Then
320           If IsLoaded("frmValidationErrors") Then
330               DoCmd.Close acForm, "frmValidationErrors"
340           End If
350       Else
360           If strNotBypassableMsg <> "" Then
370               strErr = strErr & _
                      "Non-bypassable errors" & vbCrLf & _
                       "---------------------" & vbCrLf & _
                       strNotBypassableMsg & vbCrLf & vbCrLf
380           End If
        
390           If strBypassableMsg <> "" Then
400               strErr = strErr & _
                      "Bypassable errors" & vbCrLf & _
                      "-----------------" & vbCrLf & _
                      strBypassableMsg
410           End If
                
420           If strErr <> "" Then
430               DoCmd.OpenForm "frmValidationErrors", OpenArgs:=strErr
440           Else
450               On Error Resume Next
460               DoCmd.Close acForm, "frmValidationErrors"
470               On Error GoTo Err_label
480           End If
490       End If

500   End If

      'DD Error Handler Start
Exit_label:
510        Exit Sub
Err_label:
520        Select Case Err.Number
           Case Else
530       Call LogError("basCaptures", "ValidateRecord")
540        End Select
550        Resume Exit_label
      'DD Error Handler End

End Sub

''---------------------------------------------------------------------------------------
'' UpdateSpecies
''---------------------------------------------------------------------------------------
'
'Private Sub UpdateSpecies(ByVal IDBand As Long, ByVal Species As String)
'
'       '   Open a recordset for the record
'
'      Dim rst As DAO.Recordset
'      Dim strSQL As String
'
'10    On Error GoTo Err_label
'
'20    strSQL = _
'          "SELECT * " & _
'          "FROM tblCaptures " & _
'          "WHERE IDBand = " & IDBand
'30    Set rst = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)
'40    If rst.EOF Then Exit Sub
'
'50    rst.Edit
'60    rst("Species") = Species
'70    rst.Update
'
'80    rst.Close
'
'      'DD Error Handler Start
'Exit_label:
'90         Exit Sub
'Err_label:
'100        Select Case Err.Number
'           Case Else
'110             Call LogError("basCaptures", "UpdateSpecies")
'120        End Select
'130        Resume Exit_label
'      'DD Error Handler End
'
'End Sub

''---------------------------------------------------------------------------------------
'' UpdateRecaptureDisposition
''---------------------------------------------------------------------------------------
'
'Private Sub UpdateRecaptureDisposition(ByVal Prefix As String, ByVal Suffix As String)
'10    On Error GoTo Err_label
'
'20    If Prefix = "" Or Suffix = "" Then Exit Sub
'
'       '   Open a recordset for the band's recaptures
'
'      Dim rst As DAO.Recordset
'      Dim strSQL As String
'
'      ' Determine the new disposition
'
'      Dim strWhere As String
'30    strWhere = _
'          " BandPrefix = '" & Prefix & "' AND " & _
'          " BandSuffix = '" & Suffix & "' AND " & _
'          " Disposition not in ('R','F')"
'
'      Dim Disposition As String
'40    If DCount("*", "tblCaptures", strWhere) = 0 Then
'50        Disposition = "F"
'60    Else
'70        Disposition = "R"
'80    End If
'
'      ' Update the recapture records
'
'90    strSQL = _
'          "SELECT * " & _
'          "FROM tblCaptures " & _
'          "WHERE BandPrefix = '" & Prefix & "' AND " & _
'          "      BandSuffix = '" & Suffix & "' AND " & _
'          "      Disposition in ('R','F')"
'100   Set rst = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)
'110   Do While Not rst.EOF
'120       rst.Edit
'130       rst("Disposition") = Disposition
'140       rst.Update
'150       rst.MoveNext
'160   Loop
'170   rst.Close
'
'      'DD Error Handler Start
'Exit_label:
'180        Exit Sub
'Err_label:
'190        Select Case Err.Number
'           Case Else
'200             Call LogError("basCaptures", "UpdateRecaptureDisposition")
'210        End Select
'220        Resume Exit_label
'      'DD Error Handler End
'
'End Sub

''---------------------------------------------------------------------------------------
'' ValidateCaptureNotBypassableErrorsOnly
''
'' b.IDBand is either 0 or the key of a tblCaptures record
'' If non-zero, exclude the record from searches
''
'' fSkipEqualCaptures = True when records are imported
''                      False when records are moved from sheets or edited on
''                      the Captures or History forms
'' If fSetEqualCapture = True, compare the contents of this record with the contents of
'' the duplicate stored capture record. Set fEqualCapture accordingly.
''
'' Assumptions:
''   The following have values:
''       b.IDBand
''       b.Disposition
''       b.BandPrefix
''       b.BandSuffix
''       b.CaptureDate
''       b.Program (possibly "")
''       varWeightTime can be Null
''
''---------------------------------------------------------------------------------------
'
'Public Sub ValidateCaptureNotBypassableErrorsOnly( _
'    ByRef B As BandsType, _
'    ByVal fSetEqualCapture, _
'    ByVal varWeightTime As Variant, _
'    ByRef strNotBypassableMsg As String, _
'    ByRef fEqualCapture)
'
'      Dim strNotBypassableErr As String
'      Dim fDispositionValid As Boolean
'      Dim fBandNumberValid As Boolean
'      Dim fCaptureDateValid As Boolean
'
'10    On Error GoTo Err_label
'
'20    strNotBypassableMsg = ""
'
'30    fBandNumberValid = True
'40    fCaptureDateValid = True
'50    fDispositionValid = True
'
'60    If Not IsDispositionValid(B.Disposition, strNotBypassableErr, "All Captures") Then
'70        strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
'80        fDispositionValid = False
'90    End If
'
'100   If Not IsBandPrefixValid(B.BandPrefix, strNotBypassableErr) Then
'110       strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
'120       fBandNumberValid = False
'130   End If
'
'140   If Not IsBandSuffixValid(B.BandSuffix, strNotBypassableErr) Then
'150       strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
'160       fBandNumberValid = False
'170   End If
'
'180   If Not IsCapturesTableCaptureDateValid(B.CaptureDate, strNotBypassableErr, B.Disposition) Then
'190       strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
'200       fCaptureDateValid = False
'210   End If
'
'220   If Not fDispositionValid Or Not fBandNumberValid Or Not fCaptureDateValid Then
'230       Exit Sub
'240   End If
'
'      ' === Process Lost and Destroyed bands
'
'250   If B.Disposition = "4" Or B.Disposition = "8" Then
'
'      ' Is there (another)capture records with the same band number?
'
'          Dim strCriterion As String
'260       strCriterion = _
'              "([Disposition] = 'R' OR [Disposition] = 'F' ) AND " & _
'              " [BandPrefix] = '" & B.BandPrefix & "' AND " & _
'              " [BandSuffix] = '" & B.BandSuffix & "'"
'270       If B.IDBand <> 0 Then
'280           strCriterion = strCriterion & " AND IDBand <> " & B.IDBand
'290       End If
'300       If DCount("*", "tblCaptures", strCriterion) > 0 Then
'310           strNotBypassableMsg = strNotBypassableMsg & _
'                  "Existing capture record for a lost or destroyed band"
'320           Exit Sub
'330       End If
'340   End If
'
'      Dim IDBandID2 As Long
'      Dim b2 As BandsType
'
'      ' Process duplicate new bands
'      '   Skip equal new bands during an import
'
'350   If Not (B.Disposition = "R" Or B.Disposition = "F") Then
'360       If IsNewCaptureDuplicate(B.BandPrefix, B.BandSuffix, B.IDBand, strNotBypassableErr, IDBandID2) Then
'370           If fSetEqualCapture Then
'380               Call getCaptureRecord(IDBandID2, b2)
'390               If AreTwoBanditCaptureRecordsEqual(B, b2) Then
'400                   fEqualCapture = True
'410                   Exit Sub
'420               End If
'430           End If
'440           strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
'450           Exit Sub
'460       End If
'470   End If
'
'      ' Date and Time Analysis
'      '   Recapture before Banding
'      '   Same Day Analysis
'      '   Duplicate captures
'
'      Dim fDuplicateRecapture As Boolean
'480   Call DateAndTimeAnalysis(B.Disposition, B.BandPrefix, B.BandSuffix, _
'           B.CaptureDate, varWeightTime, _
'           B.Program, B.IDBand, strNotBypassableErr, fDuplicateRecapture)
'
'      ' Skip equal recapture records during an import
'
'490   If fDuplicateRecapture Then
'500       If fSetEqualCapture Then
'510           Call IsBanditImportRecaptureDuplicate(B.BandPrefix, B.BandSuffix, B.CaptureDate, _
'                  strNotBypassableErr, IDBandID2)
'520           Call getCaptureRecord(IDBandID2, b2)
'530           If AreTwoBanditCaptureRecordsEqual(B, b2) Then
'540               fEqualCapture = True
'550               Exit Sub
'560           End If
'570       End If
'580   End If
'
'590   If strNotBypassableErr <> "" Then
'600       strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
'610       Exit Sub
'620   End If
'
'      'DD Error Handler Start
'Exit_label:
'630        Exit Sub
'Err_label:
'640        Select Case Err.Number
'           Case Else
'650             Call LogError("basCaptures", "ValidateCaptureNotBypassableErrorsOnly")
'660        End Select
'670        Resume Exit_label
'      'DD Error Handler End
'
'End Sub

'---------------------------------------------------------------------------------------
' IsNewCaptureDuplicate
'
' Assumptions:
'   BandPrefix, BandSuffix exist this record and are valid
'   BandPrefix, BandSuffix exist in tblCaptures and are valid
'   IDBand = 0 or is a valid key of a capture record
'
' IDBand is 0 when this record is being imported or moved from a sheet
' IDBand is valid when this tblCaptures record is being edited
' If duplicate, returns the key (IDBand2) of the other capture record
'
'---------------------------------------------------------------------------------------
 
Private Function IsNewCaptureDuplicate( _
    ByVal strBandPrefix As String, _
    ByVal strBandSuffix As String, _
    ByVal IDBand As Long, _
    ByRef strNotBypassableErr As String, _
    ByRef IDBand2 As Long) As Boolean
          
10    On Error GoTo Err_label

20    strNotBypassableErr = ""
30    IDBand2 = 0

      Dim strCriterion As String
40    strCriterion = "BandPrefix = '" & strBandPrefix & "' AND " & _
          "BandSuffix = '" & strBandSuffix & "' AND " & _
          " NOT (Disposition = 'F' or Disposition = 'R')"
50    If IDBand <> 0 Then
60        strCriterion = strCriterion & _
              " AND IDBand <> " & IDBand
70    End If

80    If (DCount("*", "tblCaptures", strCriterion) <> 0) Then
90        IDBand2 = Nz(DLookup("IDBand", "tblCaptures", strCriterion))
100       strNotBypassableErr = "Duplicate band"
110   End If

120   IsNewCaptureDuplicate = (strNotBypassableErr <> "")

      'DD Error Handler Start
Exit_label:
130        Exit Function
Err_label:
140        Select Case Err.Number
           Case Else
150       Call LogError("basBanditImport", "IsNewCaptureDuplicate")
160        End Select
170        Resume Exit_label
      'DD Error Handler End

End Function

''---------------------------------------------------------------------------------------
'' CountCaptureRecords
''
'' PRE: Band# is valid
''---------------------------------------------------------------------------------------
'
'Public Function CountCaptureRecords(ByVal Prefix As String, ByVal Suffix As String)
'      Dim strCriterion As String
'10    On Error GoTo Err_label
'
'20    strCriterion = _
'          "BandPrefix = '" & Prefix & "' AND BandSuffix = '" & Suffix & "'"
'30        CountCaptureRecords = Nz(DCount("*", "tblCaptures", strCriterion))
'
'      'DD Error Handler Start
'Exit_label:
'40         Exit Function
'Err_label:
'50         Select Case Err.Number
'           Case Else
'60              Call LogError("basCaptures", "CountCaptureRecords")
'70         End Select
'80         Resume Exit_label
'      'DD Error Handler End
'End Function

''---------------------------------------------------------------------------------------
'' GetCaptureRecord
''
'' Given a surrogate key value, get a record from tblCaptures
''---------------------------------------------------------------------------------------
'
'Public Sub getCaptureRecord(ByRef lngBandID As Long, ByRef b2 As BandsType)
'
'
'10    On Error GoTo Err_label
'
'      Dim i As Integer
'
'      Dim rst As DAO.Recordset
'      Dim strSQL As String
'20    strSQL = "SELECT * FROM tblCaptures WHERE IDBand = " & lngBandID
'30    Set rst = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)
'40    If rst.EOF Then
'50        Call LogError("basBandsTable", "GetBandRecord", _
'              "No tblCaptures record for IDBand = " & lngBandID)
'60        b2.BandPrefix = ""
'70        b2.BandSuffix = ""
'80        b2.Disposition = ""
'90        b2.Species = ""
'100       b2.Age = ""
'110       b2.HowAged = ""
'120       b2.Sex = ""
'130       b2.HowSexed = ""
'140       b2.WingChord = 0
'150       b2.Fat = ""
'160       b2.Weight = 0
'170       b2.CaptureDate = 0
'180       b2.WeightTime = 0
'190       b2.Bander = ""
'200       b2.Net = ""
'210       b2.NotesForMBO = ""
'220       b2.Scribe = ""
'230       b2.BirdStatus = ""
'240       b2.Location = ""
'250       b2.Program = ""
'
'260       b2.ProbableAge = ""
'270       b2.ProbableSex = ""
'280       b2.PresentCondition = ""
'290       b2.HowObtainedCode = ""
'300       b2.AutoHistory = False
'
'310       For i = 1 To conMaxUserField
'320           b2.F(i) = ""
'330       Next i
'
'340   Else
'350       b2.BandPrefix = Nz(rst.Fields("BandPrefix"), "")
'360       b2.BandSuffix = Nz(rst.Fields("BandSuffix"), "")
'370       b2.Disposition = Nz(rst.Fields("Disposition"), "")
'380       b2.Species = Nz(rst.Fields("Species"), "")
'390       b2.Age = Nz(rst.Fields("Age"), "")
'400       b2.HowAged = Nz(rst.Fields("HowAged"), "")
'410       b2.Sex = Nz(rst.Fields("Sex"), "")
'420       b2.HowSexed = Nz(rst.Fields("HowSexed"), "")
'430       b2.WingChord = Nz(rst.Fields("WingChord"), 0)
'440       b2.Fat = Nz(rst.Fields("Fat"), "")
'450       b2.Weight = Nz(rst.Fields("Weight"), 0)
'460       b2.CaptureDate = Nz(rst.Fields("CaptureDate"), 0)
'470       b2.WeightTime = Nz(rst.Fields("WeightTime"), 0)
'480       b2.Bander = Nz(rst.Fields("Bander"), "")
'490       b2.Net = Nz(rst.Fields("Net"), "")
'500       b2.NotesForMBO = Nz(rst.Fields("NotesForMBO"), "")
'510       b2.Scribe = Nz(rst.Fields("Scribe"), "")
'520       b2.BirdStatus = Nz(rst.Fields("BirdStatus"), "")
'530       b2.Location = Nz(rst.Fields("Location"), "")
'540       b2.Program = Nz(rst.Fields("Program"), "")
'550       b2.ProbableAge = Nz(rst.Fields("ProbableAge"), "")
'560       b2.ProbableSex = Nz(rst.Fields("ProbableSex"), "")
'570       b2.PresentCondition = Nz(rst.Fields("PresentCondition"), "")
'580       b2.HowObtainedCode = Nz(rst.Fields("HowObtainedCode"), "")
'590       b2.AutoHistory = rst.Fields("AutoHistory")
'
'600       For i = 1 To conMaxUserField
'610           b2.F(i) = Nz(rst("F" & i), "")
'620       Next i
'
'630   End If
'
''DD Error Handler Start
'Exit_label:
'640        Exit Sub
'Err_label:
'650        Select Case Err.Number
'     Case Else
'660       Call LogError("basCaptures", "GetCaptureRecord")
'670        End Select
'680        Resume Exit_label
''DD Error Handler End
'End Sub

' ---------------------------------------------------------------------------
' ValidateBandsRecord
' ---------------------------------------------------------------------------

Private Sub ValidateBandsRecord( _
    ByRef B As BandsType, _
    ByRef strNotBypassableMsg As String, _
    ByRef strBypassableMsg As String, _
    ByRef fIsLineBlank As Boolean, _
    ByRef IsValid As basTypes.IsValidType)

10    On Error GoTo Err_label

      Dim strNotBypassableErr As String
      Dim strBypassableErr As String

20    strNotBypassableMsg = ""
30    strBypassableMsg = ""
40    fIsLineBlank = False
50    IsValid.IsBandValid = True
60    IsValid.IsDateValid = True

70    If IsBandsLineBlank(B) Then
80        fIsLineBlank = True
90        Exit Sub
100   End If

      ' Update the array of bypassable error messages

110   Call IsProgramValid(B.Program, strNotBypassableErr, strBypassableErr)
120   strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
130   strBypassableMsg = strBypassableMsg & strBypassableErr

140   If strBypassableErr = "" And strNotBypassableErr = "" Then
150       Call SetBypassableErrorMessageCurrentProgram(B.Program)
160   Else
170       Call SetBypassableErrorMessageCurrentProgram("")
180   End If

      Dim fDisposition As Boolean

190   fDisposition = IsDispositionValid(B.Disposition, strNotBypassableErr, "All Captures")
200   strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr

210   If Not IsBandPrefixValid(B.BandPrefix, strNotBypassableErr) Then
220       IsValid.IsBandValid = False
230   End If
240   strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr

250   If Not IsBandSuffixValid(B.BandSuffix, strNotBypassableErr) Then
260       IsValid.IsBandValid = False
270   End If
280   strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr

      ' Only validate prefix, suffix for Disposition = "4","8" records

290   If B.Disposition = "4" Or B.Disposition = "8" Then
300       strNotBypassableMsg = ""
310       strBypassableMsg = ""
320       If Not IsValid.IsBandValid Then
330           If Not IsBandPrefixValid(B.BandPrefix, strNotBypassableErr) Then
340               IsValid.IsBandValid = False
350           End If
360           strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
              
370           If Not IsBandSuffixValid(B.BandSuffix, strNotBypassableErr) Then
380               IsValid.IsBandValid = False
390           End If
400           strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
410           End If
420       Exit Sub
430   End If

440   If IsValid.IsBandValid Then
450       IsValid.IsSpeciesValid = IsSpeciesValid(B.Species, strNotBypassableErr, strBypassableErr, B.Disposition, _
        B.BandPrefix, B.BandSuffix, B.IDBand)
460   Else
470       IsValid.IsSpeciesValid = IsSpeciesValid(B.Species, strNotBypassableErr, strBypassableErr, B.Disposition)
480   End If
490   strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
500   strBypassableMsg = strBypassableMsg & strBypassableErr

510   If Not IsCapturesTableCaptureDateValid(B.CaptureDate, strNotBypassableErr, B.Disposition) Then
520       IsValid.IsDateValid = False
530   End If
540   strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
550   strBypassableMsg = strBypassableMsg & strBypassableErr

560   IsValid.IsMultiRecordError = False

570   If IsValid.IsBandValid And IsValid.IsDateValid Then
580       Call IsAgeValid(B.Age, B.BandPrefix, B.BandSuffix, Year(B.CaptureDate), _
              strNotBypassableErr, strBypassableErr, _
              IsValid.IsMultiRecordError, B.IDBand)
590       strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
600       strBypassableMsg = strBypassableMsg & strBypassableErr
610   End If

620   Call IsHowAgedValid(B.HowAged, strBypassableErr, True)  ' Bandit Code
630   strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
640   strBypassableMsg = strBypassableMsg & strBypassableErr

      Dim fIsSexValid As Boolean

650   If IsValid.IsBandValid And fDisposition Then
660       fIsSexValid = IsSexValid(B.Sex, strNotBypassableErr, strBypassableErr, _
              IsValid.IsMultiRecordError, _
              B.BandPrefix, B.BandSuffix, B.Disposition, B.IDBand)
670   Else
680       fIsSexValid = IsSexValid(B.Sex, strNotBypassableErr, strBypassableErr, _
              IsValid.IsMultiRecordError)
690   End If
700   strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
710   strBypassableMsg = strBypassableMsg & strBypassableErr

      Dim argSpecies As String
      Dim argSex As String
720   argSpecies = IIf(IsValid.IsSpeciesValid, B.Species, "")
730   argSex = IIf(fIsSexValid, B.Sex, "")

740   Call IsBandsTableWingChordValid(B.WingChord, strNotBypassableErr, strBypassableErr, _
          argSpecies, argSex)
750   strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
760   strBypassableMsg = strBypassableMsg & strBypassableErr

770   Call IsHowSexedValid(B.HowSexed, strBypassableErr)
780   strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
790   strBypassableMsg = strBypassableMsg & strBypassableErr

800   Call IsFatValid(B.Fat, strNotBypassableErr, strBypassableErr)
810   strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
820   strBypassableMsg = strBypassableMsg & strBypassableErr

830   Call IsBandsTableWeightValid(B.Weight, strNotBypassableErr, strBypassableErr, _
          argSpecies, argSex)
840   strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
850   strBypassableMsg = strBypassableMsg & strBypassableErr

860   Call IsBandsTableWeightTimeValid(B.WeightTime, strNotBypassableErr, strBypassableErr)
870   strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
880   strBypassableMsg = strBypassableMsg & strBypassableErr

890   Call IsBanderValid(B.Bander, False, strNotBypassableErr, strBypassableErr) ' all banders
900   strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
910   strBypassableMsg = strBypassableMsg & strBypassableErr

920   Call IsScribeValid(B.Scribe, False, strNotBypassableErr, strBypassableErr)
930   strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
940   strBypassableMsg = strBypassableMsg & strBypassableErr

950   Call IsNetValid(B.Net, strNotBypassableErr, strBypassableErr, False) ' all Nets
960   strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
970   strBypassableMsg = strBypassableMsg & strBypassableErr

980   Call IsProbableAgeValid(B.ProbableAge, strNotBypassableErr, strBypassableErr)
990   strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
1000  strBypassableMsg = strBypassableMsg & strBypassableErr

1010  Call IsProbableSexValid(B.ProbableSex, strNotBypassableErr, strBypassableErr)
1020  strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
1030  strBypassableMsg = strBypassableMsg & strBypassableErr

1040  Call IsLocationValid(B.Location, strNotBypassableErr, strBypassableErr)
1050  strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
1060  strBypassableMsg = strBypassableMsg & strBypassableErr

1070  Call IsBirdStatusValid(B.BirdStatus, strNotBypassableErr, strBypassableErr)
1080  strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
1090  strBypassableMsg = strBypassableMsg & strBypassableErr

1100  If B.Disposition = "F" Or B.Disposition = "R" Then

1110      Call IsPresentConditionValid(B.PresentCondition, strNotBypassableErr, strBypassableErr)
1120      strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
1130      strBypassableMsg = strBypassableMsg & strBypassableErr
          
1140      Call IsHowObtainedCodeValid(B.HowObtainedCode, strNotBypassableErr, strBypassableErr)
1150      strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
1160      strBypassableMsg = strBypassableMsg & strBypassableErr
          
1170  Else
1180      If B.PresentCondition <> "" Then
1190          strBypassableMsg = strBypassableMsg & _
              "Present Condition should be blank for a new band" & vbCrLf
1200      End If
          
1210      If B.HowObtainedCode <> "" Then
1220          strBypassableMsg = strBypassableMsg & _
              "How Obtained Code should be blank for a new band" & vbCrLf
1230      End If
1240  End If



'DD Error Handler Start
Exit_label:
1250       Exit Sub
Err_label:
1260       Select Case Err.Number
     Case Else
1270      Call LogError("basCaptures", "ValidateBandsRecord")
1280       End Select
1290       Resume Exit_label
'DD Error Handler End
End Sub

' ---------------------------------------------------------------------------
' IsBandsLineBlank
' ---------------------------------------------------------------------------
'
Private Function IsBandsLineBlank(ByRef B As BandsType) As Boolean
10    On Error GoTo Err_label



20    IsBandsLineBlank = False

30    If (Trim(B.BandPrefix) = "") Then
40      If (Trim(B.BandSuffix) = "") Then
50        If (Trim(B.Species) = "") Then
60          If (B.WingChord = 0) Then
70            If (Trim(B.Age) = "") Then
80              If (Trim(B.HowAged) = "") Then
90                If (Trim(B.Sex) = "") Then
100                 If (Trim(B.HowSexed) = "") Then
110   If (Trim(B.Fat) = "") Then
120       If (B.Weight = 0) Then
130         If (B.CaptureDate = 0) Then
140           If (B.WeightTime = 0) Then
150             If (Trim(B.Bander) = "") Then
160               If (Trim(B.Scribe) = "") Then
170                 If (Trim(B.Net) = "") Then
180                   If (Trim(B.NotesForMBO) = "") Then
190                     If (Trim(B.ProbableAge) = "") Then
200                       If (Trim(B.ProbableSex) = "") Then
210   If Trim(B.Disposition) = "" Then
220       If Trim(B.Location) = "" Then
230         If Trim(B.Program) = "" Then
240           If Trim(B.BirdStatus) = "" Then
250             If Trim(B.PresentCondition) = "" Then
260               If Trim(B.HowObtainedCode) = "" Then

270                           IsBandsLineBlank = True

280               End If
290             End If
300           End If
310         End If
320       End If
330   End If
340                     End If
350                   End If
360                 End If
370               End If
380             End If
390           End If
400         End If
410       End If
420     End If
430   End If
440                 End If
450               End If
460             End If
470           End If
480         End If
490       End If
500     End If
510   End If

      'DD Error Handler Start
Exit_label:
520        Exit Function
Err_label:
530        Select Case Err.Number
           Case Else
540             Call LogError("basCaptures", "IsBandsLineBlank")
550        End Select
560        Resume Exit_label
      'DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' VerifyDETCategories_Period
'---------------------------------------------------------------------------------------
' For the tblCaptures records in a given Program, Location and between two capture dates (inclusive)
' Validate D18, D20 and D21
'   D18 = DET Category
'   D20 = Number of days since most recent prior (but not same day) capture  (for "Repeat" and "Return" only)
'   D21 = DET Date
' Auto correct any errors
'
' If fEmailErrors = True, then email any errors
'
' The only valid capture sequences are:
' 1 .... R .... R ....
' 5 .... R .... R ....
' F .... F .... F ....
 
Public Sub VerifyDETCategories_Period( _
    ByVal strProgram As String, ByVal strLocation As String, ByVal datFrom As Date, ByVal datTo As Date, _
    Optional ByVal fEmailErrors As Boolean = True)
    
10    On Error GoTo Err_label

      Dim lngIDBand As Long
      Dim strReasonDETCategoryUnknown As String
      Dim datCaptureDate As Date
      Dim fDETCategoryError As Boolean

      Dim strSQL As String
      Dim rst As DAO.Recordset
      
30    strSQL = "SELECT * FROM tblCaptures " & _
         "WHERE [Program] = '" & strProgram & "' AND " & _
         "      [Location] = '" & strLocation & "' AND " & _
         "      [CaptureDate] BETWEEN #" & Format(datFrom, "mm/dd/yyyy") & "#" & _
                                " AND #" & Format(datTo, "mm/dd/yyyy") & "#"
40    Set rst = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)

      Dim strDETCategory_old As String
      Dim strDETCategory_new As String
      Dim lngDaysSinceMostRecentPriorCapture_old As Long
      Dim lngDaysSinceMostRecentPriorCapture_new As Long
      Dim strDETDate As String
      Dim datDETDate_old As Date
      Dim datDETDate_new As Date
      Dim varWeightTime As Variant


50    Do While Not rst.EOF
         
60       fDETCategoryError = False

70        lngIDBand = Nz(rst("IDBand"))
80        strDETCategory_old = Nz(rst("D18"))
90        lngDaysSinceMostRecentPriorCapture_old = Nz(rst("D20"))
          
100       strDETDate = Nz(rst("D21"))
110       If strDETDate = "" Then
120           datDETDate_old = 0
130       Else
140           datDETDate_old = CDate(strDETDate)
150       End If
          
160       datCaptureDate = Nz(rst("CaptureDate"))
170       varWeightTime = rst("WeightTime")
180       strProgram = Nz(rst("Program"))
          
190       Call DETCategory(lngIDBand, strDETCategory_new, strReasonDETCategoryUnknown, lngDaysSinceMostRecentPriorCapture_new)
200       datDETDate_new = getDETDate(datCaptureDate, varWeightTime, strProgram)
              
210       If (strDETCategory_old <> strDETCategory_new) Then
                 
220           rst.Edit
230           rst("D18") = strDETCategory_new
240           If strDETCategory_new = "Return" Or strDETCategory_new = "Repeat" Then
250               rst("D20") = lngDaysSinceMostRecentPriorCapture_new
260           Else
270               rst("D20") = Null
280           End If
290           rst.Update
              
300           fDETCategoryError = True
                     
310       ElseIf (strDETCategory_new = "Return" Or strDETCategory_new = "Repeat") And (lngDaysSinceMostRecentPriorCapture_old <> lngDaysSinceMostRecentPriorCapture_new) Then
              
320           rst.Edit
330           If strDETCategory_new = "Return" Or strDETCategory_new = "Repeat" Then
340               rst("D20") = lngDaysSinceMostRecentPriorCapture_new
350               fDETCategoryError = True
360           Else
370               rst("D20") = Null
380           End If
390           rst.Update
400       End If
          
410       If datDETDate_old <> datDETDate_new Then
420           rst.Edit
430           rst("D21") = Format(datDETDate_new, "yyyy-mm-dd")
440           rst.Update
450           fDETCategoryError = True
460       End If
          
470       If fDETCategoryError Then
480           Call LogError("basCaptures", "VerifyDETCategories_Period", _
                        "Corrected a DET Category Error" & _
                        ": Program = " & strProgram & _
                        ", Capture ID = " & lngIDBand & _
                        ", new DET Category = " & strDETCategory_new & _
                        ", old DET Category = " & strDETCategory_old & _
                        ", new days to prior capture = " & lngDaysSinceMostRecentPriorCapture_new & _
                        ", old days to prior capture = " & lngDaysSinceMostRecentPriorCapture_old & _
                        ", new DET Date = " & Format(datDETDate_new, "dd mmm yyyy") & _
                        ", old DET Date = " & Format(datDETDate_old, "dd mmm yyyy"), _
                    Silent:=True, fEmailError:=fEmailErrors)
490       End If
          
500       rst.MoveNext
510   Loop
520   rst.Close
530   Set rst = Nothing

    'DD Error Handler Start
Exit_label:
540       Exit Sub
Err_label:
550       Select Case Err.Number
    Case Else
560      Call LogError("basCaptures", "VerifyDETCategories_Period")
570       End Select
580       Resume Exit_label
    ' DD Error Handler End

End Sub
