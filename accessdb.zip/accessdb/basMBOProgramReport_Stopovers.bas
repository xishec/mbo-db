'---------------------------------------------------------------------------------------
' Module    : basMBOProgramReport_Stopovers
' Author    : David Davey
'---------------------------------------------------------------------------------------

Option Compare Database
Option Explicit

Const conNonSeason As Integer = -1
Const conWinter  As Integer = 0
Const conSpring  As Integer = 1
Const conSummer  As Integer = 2
Const conFall    As Integer = 3
Const conOwling  As Integer = 4
Const conRTHU    As Integer = 5
Const conNestbox As Integer = 6
Const conSummerNestbox As Integer = 7

Const intSeasonFirst As Integer = -1
Const intSeasonLast As Integer = 6

'---------------------------------------------------------------------------------------
' MBOProgramReport_Stopovers
'---------------------------------------------------------------------------------------
 
Public Sub MBOProgramReport_Stopovers( _
    ByVal intYearFirst As Integer, _
    ByVal intYearLast As Integer, _
    ByVal strLocation As String, _
    ByRef oBook As Excel.Workbook)
          
      Dim colSeason As Integer
      Dim colYear As Integer
      Dim colSpecies As Integer
      Dim colSpeciesEnglish As Integer
      Dim colStopover As Integer
      Dim colCountBirds As Integer
      Dim colLast As Integer

10    colSeason = 1
20    colYear = 2
30    colSpecies = 3
40    colSpeciesEnglish = 4
50    colStopover = 5
60    colCountBirds = 6
70    colLast = 6

' I have decided to only report the stopovers for the current year

80        intYearFirst = intYearLast
          
      Dim intSeason As Integer
      Dim strSeason As String
      Dim strSpecies As String
      Dim strSpeciesEnglish As String
      Dim lngStopover As Long
      Dim lngCountBirds As Long
      Dim oSheet As Excel.Worksheet
      Dim row As Long
      Dim strSQL As String
      Dim qdf As DAO.QueryDef
      Dim rst As DAO.Recordset
      Dim intYear As Integer
      Dim intYear_previous As Integer

90    On Error GoTo Err_label

100   For intSeason = intSeasonFirst To intSeasonLast
110       Select Case intSeason
          Case conSpring, conFall, conOwling
        
120           strSeason = toStrSeasonFromIntSeason(intSeason)
        
130           Set oSheet = InsertSheet(oBook, strSeason)
140           oSheet.Name = strSeason & " Stopovers"
150           With oSheet
              
160           intYear_previous = 0
              
170           row = 1
180           .Cells(row, colSeason) = "Season"
190           .Cells(row, colYear) = "Year"
200           .Cells(row, colSpecies) = "Species"
210           .Cells(row, colSpeciesEnglish) = "English"
220           .Cells(row, colStopover) = "Stopover"
230           .Cells(row, colCountBirds) = "# birds"
240           .Rows(row).Font.Bold = True
              
250           row = 2


' qryMBOProgramReport_Stpovers_B
' ------------------------------
' qryMBOProgramReport_Stpovers
'
' Season
' YearEx
' BnadPrefix
' BandSuffix
' FirstOfSpecies
' StopOver = CaptureDateLast - CaptureDateFirst     >0



' qryMBOProgramReport_Stpovers_C
' ------------------------------
' qryMBOProgramReport_Stpovers_B x tblSpecies
'
' GROUP BY SEASON
' GROUP BY YearEx
' GROUP BY FirstOfSpecies
' GROUP BY SpeciesDescriptionMBO
' GROUP BY Stopover
' CountBirds = Sum(1)
' GROUP BY AOUOrder
' SORT BY YearEx, AOUOrder, Stopover DESC

















        
260           strSQL = "qryMBOProgramReport_Stopovers_C"
270           Set qdf = CurrentDb.QueryDefs(strSQL)
280           qdf("argLocation") = "MBO"                         ' defensive
290           qdf("argSeason") = strSeason
300           qdf("argYearFirst") = intYearFirst
310           qdf("argYearLast") = intYearLast
320           Set rst = qdf.OpenRecordset
          
330           Do While Not rst.EOF
340               intYear = Nz(rst("YearEx"))
350               strSpecies = Nz(rst("Species"))
360               strSpeciesEnglish = Nz(rst("SpeciesEnglish"))
370               lngStopover = Nz(rst("Stopover"))
380               lngCountBirds = Nz(rst("CountBirds"))
                  
390               If intYear <> intYear_previous And intYear_previous <> 0 Then row = row + 1
                
400               .Cells(row, colSeason) = strSeason
410               .Cells(row, colYear) = intYear
420               .Cells(row, colSpecies) = strSpecies
430               .Cells(row, colSpeciesEnglish) = strSpeciesEnglish
440               .Cells(row, colStopover) = lngStopover
450               .Cells(row, colCountBirds) = lngCountBirds
460               row = row + 1
            
470               intYear_previous = intYear

480               rst.MoveNext
490           Loop
500           rst.Close
510           Set rst = Nothing

520          .range(.columns(1), .columns(colLast)).AutoFit
530         .range("A2").Select
540         oBook.Application.ActiveWindow.FreezePanes = True

550   SysCmd acSysCmdClearStatus
              
560           End With
              
570       End Select
580   Next

      'DD Error Handler Start
Exit_label:
590        Exit Sub
Err_label:
600        Select Case Err.Number
           Case Else
610             Call LogError("basMBOProgramReport_Stopovers", "MBOProgramReport_Stopovers")
620        End Select
630        Resume Exit_label
      'DD Error Handler End

End Sub
