'---------------------------------------------------------------------------------------
' Module    : basMBO10YearProgramReportOverview
' Author    : David Davey
'---------------------------------------------------------------------------------------
' Appendix A

Option Compare Database
Option Explicit

' Statistics

Const conBirdsBanded As Integer = 0
Const conSpeciesBanded As Integer = 1
Const conBirdsReturns As Integer = 2
Const conSpeciesReturns As Integer = 3
Const conBirdsRepeats As Integer = 4
Const conSpeciesRepeats As Integer = 5
Const conSpeciesDET As Integer = 6
Const conNetHours As Integer = 7
Const conBirdsPer100NetHours As Integer = 8
Const conDaysOperating As Integer = 9
Const conDaysBanding As Integer = 10
Const conDaysFullCoverage As Integer = 11
Const conStatLast As Integer = 11

Const conDET As Integer = 0
Const conBND As Integer = 1
Const conRET As Integer = 2
Const conREP As Integer = 3

Const dblMax As Double = 1.7E+300

Private intYearFirst As Integer
Private intYearLast As Integer
Private strLocation As String
Private strSeason As String
Private wd As Word.Application
Private doc As Word.Document
Private oExcel As Excel.Application
Private oBook As Excel.Workbook
Private fDebug As Boolean

Private dblStat() As Double     ' statistic x Year x Period
Private dblStatMin() As Double  ' statistic x Period
Private dblStatMax() As Double  ' statistic x Period

Private dblStatCumulative() As Double     ' statistic x Year x Period
Private dblStatCumulativeMin() As Double  ' statistic x Period
Private dblStatCumulativeMax() As Double  ' statistic x Period

'ReDim dblStat(conStatLast, intYearFirst To intYearLast, intPeriodFirst To intPeriodLast) As Double
'ReDim dblStatCumulative(conStatLast, intYearFirst To intYearLast, intPeriodFirst To intPeriodLast) As Double
'ReDim dblStatMin(conStatLast, intPeriodFirst To intPeriodLast) As Double
'ReDim dblStatMax(conStatLast, intPeriodFirst To intPeriodLast) As Double
'ReDim dblStatCumulativeMin(conStatLast, intPeriodFirst To intPeriodLast) As Double
'ReDim dblStatCumulativeMax(conStatLast, intPeriodFirst To intPeriodLast) As Double

Private BirdsBanded() As Long
Private BirdsReturns() As Long
Private BirdsRepeats() As Long
Private lngSpecies() As Long
Private NetHours() As Double
Private DaysOperating() As Integer
Private DaysBanding() As Integer
Private DaysFullCoverage() As Integer

Private intCount(conStatLast) As Integer
Private dblTotal(conStatLast) As Double
Private dblAverage(conStatLast) As Double

'---------------------------------------------------------------------------------------
' MBO10YearProgramReportOverview
'---------------------------------------------------------------------------------------
' Appendix A = Spring
' Appendix B = Fall
' There is no overview for other seasons
 
 Public Sub MBO10YearProgramReportOverview_AB( _
    ByVal intYearFirst As Integer, _
    ByVal intYearLast As Integer, _
    ByVal strLocation As String, _
    ByVal strSeason As String, _
    ByRef wd As Word.Application, _
    ByRef doc As Word.Document, _
    ByRef oExcel As Excel.Application, _
    ByRef oBook As Excel.Workbook, _
    ByVal fDebug As Boolean)
           
10    On Error GoTo Err_label

      Dim lngBlue As Long
      Dim lngRed As Long

20    lngBlue = RGB(0, 112, 192)
30    lngRed = wdColorRed '   RGB(255, 0, 0)

      Dim intSeason As Integer
40    intSeason = toIntSeasonFromStrSeason(strSeason)

      ' local_intPeriodLast_Season (currently: 10 for spring, 14 for fall)

      Dim local_intPeriodFirst_Season As Integer
      Dim local_intPeriodLast_Season As Integer
50    local_intPeriodFirst_Season = 1
60    local_intPeriodLast_Season = intPeriodLast_Season(intSeason)

      Dim p As Integer        ' period
      Dim stat As Integer
      Dim Y As Integer        ' year
      Dim qdf As QueryDef
      Dim rst As DAO.Recordset

      ' --------------------------------------
      ' Compute Information
      ' --------------------------------------

70    ReDim dblStat(conStatLast, intYearFirst To intYearLast, local_intPeriodFirst_Season To local_intPeriodLast_Season) As Double
80    ReDim dblStatCumulative(conStatLast, intYearFirst To intYearLast, local_intPeriodFirst_Season To local_intPeriodLast_Season) As Double
90    ReDim dblStatMin(conStatLast, local_intPeriodFirst_Season To local_intPeriodLast_Season) As Double
100   ReDim dblStatMax(conStatLast, local_intPeriodFirst_Season To local_intPeriodLast_Season) As Double
110   ReDim dblStatCumulativeMin(conStatLast, local_intPeriodFirst_Season To local_intPeriodLast_Season) As Double
120   ReDim dblStatCumulativeMax(conStatLast, local_intPeriodFirst_Season To local_intPeriodLast_Season) As Double

130   For stat = 0 To conStatLast
140       For Y = intYearFirst To intYearLast
150           For p = local_intPeriodFirst_Season To local_intPeriodLast_Season
160               dblStat(stat, Y, p) = 0
170               dblStatCumulative(stat, Y, p) = 0
180           Next
190       Next
200   Next

210   For stat = 0 To conStatLast
220       For p = local_intPeriodFirst_Season To local_intPeriodLast_Season
230           dblStatMin(stat, p) = 0
240           dblStatMax(stat, p) = 0
250           dblStatCumulativeMin(stat, p) = 0
260           dblStatCumulativeMax(stat, p) = 0
270       Next
280   Next

      ' Birds Banded, Returns, Repeats

290   Set qdf = CurrentDb.QueryDefs("qryMBO10YearProgramReportOverview_Birds")
300   qdf.Parameters("argSeason").value = strSeason
310   qdf.Parameters("argLocation").value = strLocation
320   qdf.Parameters("argYearFirst").value = intYearFirst
330   qdf.Parameters("argYearLast").value = intYearLast
340   Set rst = qdf.OpenRecordset

350   Do While Not rst.EOF
360       Y = Nz(rst("YearEx"))
370       p = Nz(rst("Period"))
380       dblStat(conBirdsBanded, Y, p) = Nz(rst("BirdsBanded"))
390       dblStat(conBirdsReturns, Y, p) = Nz(rst("BirdsReturns"))
400       dblStat(conBirdsRepeats, Y, p) = Nz(rst("BirdsRepeats"))
410       rst.MoveNext
420   Loop
430   rst.Close
440   Set rst = Nothing

450   For Y = intYearFirst To intYearLast
460       For p = local_intPeriodFirst_Season To local_intPeriodLast_Season
470           dblStatCumulative(conBirdsBanded, Y, p) = dblStat(conBirdsBanded, Y, p)
480           dblStatCumulative(conBirdsReturns, Y, p) = dblStat(conBirdsReturns, Y, p)
490           dblStatCumulative(conBirdsRepeats, Y, p) = dblStat(conBirdsRepeats, Y, p)
500           If p > local_intPeriodFirst_Season Then
510               dblStatCumulative(conBirdsBanded, Y, p) = _
                      dblStat(conBirdsBanded, Y, p) + dblStatCumulative(conBirdsBanded, Y, p - 1)
520               dblStatCumulative(conBirdsReturns, Y, p) = _
                      dblStat(conBirdsReturns, Y, p) + dblStatCumulative(conBirdsReturns, Y, p - 1)
530               dblStatCumulative(conBirdsRepeats, Y, p) = _
                      dblStat(conBirdsRepeats, Y, p) + dblStatCumulative(conBirdsRepeats, Y, p - 1)
540           End If

550       Next
560   Next

      ' Species DET, banded, Returns, Repeats

570   ReDim dicSpecies(conDET To conREP, intYearFirst To intYearLast, local_intPeriodFirst_Season To local_intPeriodLast_Season) As Scripting.Dictionary
580   ReDim dicSpeciesCumulative(conDET To conREP, intYearFirst To intYearLast, local_intPeriodFirst_Season To local_intPeriodLast_Season) As Scripting.Dictionary

      Dim fld As Integer

590   For fld = conDET To conREP
600       For Y = intYearFirst To intYearLast
610           For p = local_intPeriodFirst_Season To local_intPeriodLast_Season
620               Set dicSpecies(fld, Y, p) = New Scripting.Dictionary
630               Set dicSpeciesCumulative(fld, Y, p) = New Scripting.Dictionary
640           Next p
650       Next
660   Next

670   For fld = conDET To conREP
          
680       Select Case fld
          Case conDET
690           Set qdf = CurrentDb.QueryDefs("qryMBO10YearProgramReportOverview_DETSpecies")
700       Case conBND
710           Set qdf = CurrentDb.QueryDefs("qryMBO10YearProgramReportOverview_BNDSpecies")
720       Case conRET
730           Set qdf = CurrentDb.QueryDefs("qryMBO10YearProgramReportOverview_RETSpecies")
740       Case conREP
750           Set qdf = CurrentDb.QueryDefs("qryMBO10YearProgramReportOverview_REPSpecies")
760       End Select
770       qdf.Parameters("argSeason").value = strSeason
780       qdf.Parameters("argLocation").value = strLocation
790       qdf.Parameters("argYearFirst").value = intYearFirst
800       qdf.Parameters("argYearLast").value = intYearLast
810       Set rst = qdf.OpenRecordset
820       Do While Not rst.EOF
              Dim strSpecies As String
830           strSpecies = Nz(rst("Species"))
840           Y = Nz(rst("YearEx"))
850           p = Nz(rst("Period"))
860           If Not dicSpecies(fld, Y, p).Exists(strSpecies) Then
870               Call dicSpecies(fld, Y, p).Add(strSpecies, strSpecies)
880           End If
890           rst.MoveNext
900       Loop
910       rst.Close
920       Set rst = Nothing
930   Next

      Dim key As Variant

940   For fld = conDET To conREP
950       For Y = intYearFirst To intYearLast
960           For p = local_intPeriodFirst_Season To local_intPeriodLast_Season
970               For Each key In dicSpecies(fld, Y, p)
980                   dicSpeciesCumulative(fld, Y, p).Add CStr(key), CStr(key)
990               Next
1000              If p > local_intPeriodFirst_Season Then
1010                  For Each key In dicSpeciesCumulative(fld, Y, p - 1)
1020                      If Not dicSpeciesCumulative(fld, Y, p).Exists(key) Then
1030                          Call dicSpeciesCumulative(fld, Y, p).Add(CStr(key), CStr(key))
1040                      End If
1050                  Next
1060              End If
1070          Next
1080      Next
1090  Next

      ' Count true species

1100  For Y = intYearFirst To intYearLast
1110      For p = local_intPeriodFirst_Season To local_intPeriodLast_Season
1120          dblStat(conSpeciesDET, Y, p) = CountSpeciesInDictionary(dicSpecies(conDET, Y, p))
1130          dblStat(conSpeciesBanded, Y, p) = CountSpeciesInDictionary(dicSpecies(conBND, Y, p))
1140          dblStat(conSpeciesReturns, Y, p) = CountSpeciesInDictionary(dicSpecies(conRET, Y, p))
1150          dblStat(conSpeciesRepeats, Y, p) = CountSpeciesInDictionary(dicSpecies(conREP, Y, p))
1160          dblStatCumulative(conSpeciesDET, Y, p) = CountSpeciesInDictionary(dicSpeciesCumulative(conDET, Y, p))
1170          dblStatCumulative(conSpeciesBanded, Y, p) = CountSpeciesInDictionary(dicSpeciesCumulative(conBND, Y, p))
1180          dblStatCumulative(conSpeciesReturns, Y, p) = CountSpeciesInDictionary(dicSpeciesCumulative(conRET, Y, p))
1190          dblStatCumulative(conSpeciesRepeats, Y, p) = CountSpeciesInDictionary(dicSpeciesCumulative(conREP, Y, p))
1200      Next
1210  Next

      ' Net Hours

1220  Set qdf = CurrentDb.QueryDefs("qryMBO10YearProgramReportOverview_NetHours")
1230  qdf.Parameters("argSeason").value = strSeason
1240  qdf.Parameters("argLocation").value = strLocation
1250  qdf.Parameters("argYearFirst").value = intYearFirst
1260  qdf.Parameters("argYearLast").value = intYearLast
1270  Set rst = qdf.OpenRecordset

1280  Do While Not rst.EOF
1290      Y = Nz(rst("YearEx"))
1300      p = Nz(rst("Period"))
1310      dblStat(conNetHours, Y, p) = Nz(rst("NetHours"))
1320      rst.MoveNext
1330  Loop
1340  rst.Close
1350  Set rst = Nothing

1360  For Y = intYearFirst To intYearLast
1370      For p = local_intPeriodFirst_Season To local_intPeriodLast_Season
1380          dblStatCumulative(conNetHours, Y, p) = dblStat(conNetHours, Y, p)
1390          If p > local_intPeriodFirst_Season Then
1400              dblStatCumulative(conNetHours, Y, p) = _
                      dblStatCumulative(conNetHours, Y, p) + dblStatCumulative(conNetHours, Y, p - 1)
1410          End If
1420      Next
1430  Next
          
1440  Set rst = Nothing

      ' Birds per 100 Net Hours

1450  For Y = intYearFirst To intYearLast
1460      For p = local_intPeriodFirst_Season To local_intPeriodLast_Season
1470          If dblStat(conNetHours, Y, p) > 0 Then
1480              dblStat(conBirdsPer100NetHours, Y, p) = _
                      Round(100 * dblStat(conBirdsBanded, Y, p) / dblStat(conNetHours, Y, p), 1)
1490          End If
1500          If dblStatCumulative(conNetHours, Y, p) > 0 Then
1510              dblStatCumulative(conBirdsPer100NetHours, Y, p) = _
                      Round(100 * dblStatCumulative(conBirdsBanded, Y, p) / dblStatCumulative(conNetHours, Y, p), 1)
1520          End If
1530      Next
1540  Next

      ' Minimum Stat

      Dim dblStatMinEx As Double

1550  For stat = 0 To conStatLast
1560      For p = local_intPeriodFirst_Season To local_intPeriodLast_Season
1570          dblStatMinEx = dblMax
1580          For Y = intYearFirst To intYearLast
1590              If stat = conSpeciesDET Then
1600                  If getDETDays_SeasonYearPeriod(intSeason, Y, p) > 0 Then
1610                      If dblStat(stat, Y, p) < dblStatMinEx Then
1620                          dblStatMinEx = dblStat(stat, Y, p)
1630                      End If
1640                  End If
1650              Else
1660                  If getCaptureDays_SeasonYearPeriod(intSeason, Y, p) > 0 Then
1670                      If dblStat(stat, Y, p) < dblStatMinEx Then
1680                          dblStatMinEx = dblStat(stat, Y, p)
1690                      End If
1700                  End If
1710              End If
1720          Next
1730          dblStatMin(stat, p) = dblStatMinEx
1740      Next
1750  Next

1760  For stat = 0 To conStatLast
1770      For p = local_intPeriodFirst_Season To local_intPeriodLast_Season
1780          dblStatMinEx = dblMax
1790          For Y = intYearFirst To intYearLast
1800              If stat = conSpeciesDET Then
1810                  If getDETDays_SeasonYearPeriod(intSeason, Y, p) > 0 Then
1820                      If dblStatCumulative(stat, Y, p) < dblStatMinEx Then
1830                          dblStatMinEx = dblStatCumulative(stat, Y, p)
1840                      End If
1850                  End If
1860              Else
1870                  If getCaptureDays_SeasonYearPeriod(intSeason, Y, p) > 0 Then
1880                      If dblStatCumulative(stat, Y, p) < dblStatMinEx Then
1890                          dblStatMinEx = dblStatCumulative(stat, Y, p)
1900                      End If
1910                  End If
1920              End If
1930          Next
1940          dblStatCumulativeMin(stat, p) = dblStatMinEx
1950      Next
1960  Next

      ' Maximum Year

      Dim dblStatMaxEx As Double

1970  For stat = 0 To conStatLast
1980      For p = local_intPeriodFirst_Season To local_intPeriodLast_Season
1990          dblStatMaxEx = -1
2000          For Y = intYearFirst To intYearLast
2010              If stat = conSpeciesDET Then
2020                  If getDETDays_SeasonYearPeriod(intSeason, Y, p) > 0 Then
2030                      If dblStat(stat, Y, p) > dblStatMaxEx Then
2040                          dblStatMaxEx = dblStat(stat, Y, p)
2050                      End If
2060                  End If
2070              Else
2080                  If getCaptureDays_SeasonYearPeriod(intSeason, Y, p) > 0 Then
2090                      If dblStat(stat, Y, p) > dblStatMaxEx Then
2100                          dblStatMaxEx = dblStat(stat, Y, p)
2110                      End If
2120                  End If
2130              End If
2140          Next
2150          dblStatMax(stat, p) = dblStatMaxEx
2160      Next
2170  Next

2180  For stat = 0 To conStatLast
2190      For p = local_intPeriodFirst_Season To local_intPeriodLast_Season
2200          dblStatMaxEx = -1
2210          For Y = intYearFirst To intYearLast
              
2220              If stat = conSpeciesDET Then
2230                  If getDETDays_SeasonYearPeriod(intSeason, Y, p) > 0 Then
2240                      If dblStatCumulative(stat, Y, p) > dblStatMaxEx Then
2250                          dblStatMaxEx = dblStatCumulative(stat, Y, p)
2260                      End If
2270                  End If
2280              Else
2290                  If getCaptureDays_SeasonYearPeriod(intSeason, Y, p) > 0 Then
2300                      If dblStatCumulative(stat, Y, p) > dblStatMaxEx Then
2310                          dblStatMaxEx = dblStatCumulative(stat, Y, p)
2320                      End If
2330                  End If
2340              End If
2350          Next
2360          dblStatCumulativeMax(stat, p) = dblStatMaxEx
2370      Next
2380  Next

      ' --------------------------------------
      ' Output Excel Worksheet
      ' --------------------------------------

      Dim oSheet As Excel.Worksheet
2390  Set oSheet = InsertSheet(oBook, strSeason)
2400  oSheet.Name = strSeason & " Overview"
2410  With oSheet

      ' Output the header row

2420  .Cells(1, 2) = "Year"

2430  For p = local_intPeriodFirst_Season To local_intPeriodLast_Season
2440      .Cells(1, toColFromPeriod(p)) = Left(strSeason, 1) & p
2450  Next

      Dim row As Long

2460  row = 2

2470  .Cells(row, 1) = "# individuals banded"

2480  For Y = intYearFirst To intYearLast
2490      .Cells(row, 2) = Y
2500      For p = local_intPeriodFirst_Season To local_intPeriodLast_Season
2510          .Cells(row, toColFromPeriod(p)) = dblStat(conBirdsBanded, Y, p)
2520      Next
2530      row = row + 1
2540  Next

2550  .Cells(row, 1) = "# individuals banded cumulative"

2560  For Y = intYearFirst To intYearLast
2570      .Cells(row, 2) = Y
2580      For p = local_intPeriodFirst_Season To local_intPeriodLast_Season
2590          .Cells(row, toColFromPeriod(p)) = dblStatCumulative(conBirdsBanded, Y, p)
2600      Next
2610      row = row + 1
2620  Next

2630  .Cells(row, 1) = "# individuals returns"

2640  For Y = intYearFirst To intYearLast
2650      .Cells(row, 2) = Y
2660      For p = local_intPeriodFirst_Season To local_intPeriodLast_Season
2670          .Cells(row, toColFromPeriod(p)) = dblStat(conBirdsReturns, Y, p)
2680      Next
2690      row = row + 1
2700  Next

2710  .Cells(row, 1) = "# individuals returns cumulative"

2720  For Y = intYearFirst To intYearLast
2730      .Cells(row, 2) = Y
2740      For p = local_intPeriodFirst_Season To local_intPeriodLast_Season
2750          .Cells(row, toColFromPeriod(p)) = dblStatCumulative(conBirdsReturns, Y, p)
2760      Next
2770      row = row + 1
2780  Next

2790  .Cells(row, 1) = "# individuals repeats"

2800  For Y = intYearFirst To intYearLast
2810      .Cells(row, 2) = Y
2820      For p = local_intPeriodFirst_Season To local_intPeriodLast_Season
2830          .Cells(row, toColFromPeriod(p)) = dblStat(conBirdsRepeats, Y, p)
2840      Next
2850      row = row + 1
2860  Next

2870  .Cells(row, 1) = "# individuals repeats cumulative"

2880  For Y = intYearFirst To intYearLast
2890      .Cells(row, 2) = Y
2900      For p = local_intPeriodFirst_Season To local_intPeriodLast_Season
2910          .Cells(row, toColFromPeriod(p)) = dblStatCumulative(conBirdsRepeats, Y, p)
2920      Next
2930      row = row + 1
2940  Next

2950  .Cells(row, 1) = "# species banded"

2960  For Y = intYearFirst To intYearLast
2970      .Cells(row, 2) = Y
2980      For p = local_intPeriodFirst_Season To local_intPeriodLast_Season
2990          .Cells(row, toColFromPeriod(p)) = dblStat(conSpeciesBanded, Y, p)
3000      Next
3010      row = row + 1
3020  Next

3030  .Cells(row, 1) = "# species banded cumulative"

3040  For Y = intYearFirst To intYearLast
3050      .Cells(row, 2) = Y
3060      For p = local_intPeriodFirst_Season To local_intPeriodLast_Season
3070          .Cells(row, toColFromPeriod(p)) = dblStatCumulative(conSpeciesBanded, Y, p)
3080      Next
3090      row = row + 1
3100  Next

3110  .Cells(row, 1) = "# species returns"

3120  For Y = intYearFirst To intYearLast
3130      .Cells(row, 2) = Y
3140      For p = local_intPeriodFirst_Season To local_intPeriodLast_Season
3150          .Cells(row, toColFromPeriod(p)) = dblStat(conSpeciesReturns, Y, p)
3160      Next
3170      row = row + 1
3180  Next

3190  .Cells(row, 1) = "# species returns cumulative"

3200  For Y = intYearFirst To intYearLast
3210      .Cells(row, 2) = Y
3220      For p = local_intPeriodFirst_Season To local_intPeriodLast_Season
3230          .Cells(row, toColFromPeriod(p)) = dblStatCumulative(conSpeciesReturns, Y, p)
3240      Next
3250      row = row + 1
3260  Next

3270  .Cells(row, 1) = "# species repeats"

3280  For Y = intYearFirst To intYearLast
3290      .Cells(row, 2) = Y
3300      For p = local_intPeriodFirst_Season To local_intPeriodLast_Season
3310          .Cells(row, toColFromPeriod(p)) = dblStat(conSpeciesRepeats, Y, p)
3320      Next
3330      row = row + 1
3340  Next

3350  .Cells(row, 1) = "# species repeats cumulative"

3360  For Y = intYearFirst To intYearLast
3370      .Cells(row, 2) = Y
3380      For p = local_intPeriodFirst_Season To local_intPeriodLast_Season
3390          .Cells(row, toColFromPeriod(p)) = dblStatCumulative(conSpeciesRepeats, Y, p)
3400      Next
3410      row = row + 1
3420  Next

3430  .Cells(row, 1) = "# species observed"

3440  For Y = intYearFirst To intYearLast
3450      .Cells(row, 2) = Y
3460      For p = local_intPeriodFirst_Season To local_intPeriodLast_Season
3470          .Cells(row, toColFromPeriod(p)) = dblStat(conSpeciesDET, Y, p)
3480      Next
3490      row = row + 1
3500  Next

3510  .Cells(row, 1) = "# species observed cumulative"

3520  For Y = intYearFirst To intYearLast
3530      .Cells(row, 2) = Y
3540      For p = local_intPeriodFirst_Season To local_intPeriodLast_Season
3550          .Cells(row, toColFromPeriod(p)) = dblStatCumulative(conSpeciesDET, Y, p)
3560      Next
3570      row = row + 1
3580  Next

3590  .Cells(row, 1) = "# net hours"

3600  For Y = intYearFirst To intYearLast
3610      .Cells(row, 2) = Y
3620      For p = local_intPeriodFirst_Season To local_intPeriodLast_Season
3630          .Cells(row, toColFromPeriod(p)) = dblStat(conNetHours, Y, p)
3640      Next
3650      row = row + 1
3660  Next

3670  .Cells(row, 1) = "# net hours cumulative"

3680  For Y = intYearFirst To intYearLast
3690      .Cells(row, 2) = Y
3700      For p = local_intPeriodFirst_Season To local_intPeriodLast_Season
3710          .Cells(row, toColFromPeriod(p)) = dblStatCumulative(conNetHours, Y, p)
3720      Next
3730      row = row + 1
3740  Next

3750  .Cells(row, 1) = "# net birds banded / 10 net hours"

3760  For Y = intYearFirst To intYearLast
3770      .Cells(row, 2) = Y
3780      For p = local_intPeriodFirst_Season To local_intPeriodLast_Season
3790          .Cells(row, toColFromPeriod(p)) = dblStat(conBirdsPer100NetHours, Y, p)
3800      Next
3810      row = row + 1
3820  Next

3830  .Cells(row, 1) = "# net birds banded / 10 net hours cumulative cumulative"

3840  For Y = intYearFirst To intYearLast
3850      .Cells(row, 2) = Y
3860      For p = local_intPeriodFirst_Season To local_intPeriodLast_Season
3870          .Cells(row, toColFromPeriod(p)) = dblStatCumulative(conBirdsPer100NetHours, Y, p)
3880      Next
3890      row = row + 1
3900  Next

3910  .range(.columns(1), .columns(1)).AutoFit

      '.range(.Cells(toRow(0), toCol(0)), .Cells(toRow(conStatLast), colLast + 2)).NumberFormat = "#0;-#0;0"
      '
      '.range(.Cells(toRow(conNetHours), 2), .Cells(toRow(conNetHours), colLast + 2)).NumberFormat = "#0.0;-#0.0;#"
      '.range(.Cells(toRow(conBirdsPer100NetHours), 2), _
      '       .Cells(toRow(conBirdsPer100NetHours), colLast + 2)).NumberFormat = "#0.0;-#0.0;#"
      '
3920  .range(.Cells(1, 2), .Cells(1, toColFromPeriod(local_intPeriodLast_Season))).HorizontalAlignment = xlRight

3930  End With

3940  Set oSheet = Nothing

      ' ==============
      ' Output to Word
      ' ==============

      Dim range As Word.range

3950  Set range = MoveInsertionPointToEndOfDocument(wd, doc)

3960  Call WordGenerateTableOverview(doc, range, strSeason, local_intPeriodLast_Season, intYearFirst, intYearLast)

      Dim table As Word.table
3970  Set table = range.Tables(1)

      '       Expand the table to 6 * number of years data rows
      '
      Dim intCountYears As Integer
3980  intCountYears = (intYearLast - intYearFirst + 1)

      Dim dblStatistic As Double
      Dim intPeriod As Integer
      Dim intYear As Integer

3990  row = 2

      ' # individual bird (species) banded
      ' # individual bird (species) returns
      ' # individual bird (species) repeats

4000  For stat = conBirdsBanded To conBirdsRepeats Step 2

4010      For intYear = intYearFirst To intYearLast
4020          For intPeriod = 1 To local_intPeriodLast_Season
4030              table.Cell(row, 2 + intPeriod).range.Select
4040              With doc.ActiveWindow.Selection
4050                  If getCaptureDays_SeasonYearPeriod(intSeason, intYear, intPeriod) = 0 Then
4060                      .TypeText "n/a"
4070                  Else
4080                      dblStatistic = dblStat(stat, intYear, intPeriod)
4090                      If dblStatistic > 0 Then
4100                          If dblStatistic = dblStatMax(stat, intPeriod) Then .Font.Color = lngRed
4110                          If dblStatistic = dblStatMin(stat, intPeriod) Then .Font.Color = lngBlue
4120                          .TypeText dblStatistic
4130                          .Font.Color = wdColorAutomatic
4140                          If dblStat(stat + 1, intYear, intPeriod) = dblStatMax(stat + 1, intPeriod) Then .Font.Color = lngRed
4150                          If dblStat(stat + 1, intYear, intPeriod) = dblStatMin(stat + 1, intPeriod) Then .Font.Color = lngBlue
4160                          If dblStatistic < 1000 Then
4170                              .TypeText " ("
4180                          Else
4190                              .TypeText "("
4200                          End If
4210                          .TypeText dblStat(stat + 1, intYear, intPeriod)
4220                          .TypeText ")"
4230                      Else
4240                          .Font.Color = lngBlue
4250                          .TypeText "0 (0)"
4260                      End If
4270                      .Font.Color = wdColorAutomatic
4280                      .TypeParagraph
4290                      dblStatistic = dblStatCumulative(stat, intYear, intPeriod)
4300                      If dblStatistic > 0 Then
4310                          If dblStatistic = dblStatCumulativeMax(stat, intPeriod) Then
4320                              .Font.Color = lngRed
4330                          End If
4340                          If dblStatistic = dblStatCumulativeMin(stat, intPeriod) Then
4350                              .Font.Color = lngBlue
4360                          End If
4370                          .TypeText dblStatistic
4380                          .Font.Color = wdColorAutomatic
4390                          If dblStatCumulative(stat + 1, intYear, intPeriod) = dblStatCumulativeMax(stat + 1, intPeriod) Then .Font.Color = lngRed
4400                          If dblStatCumulative(stat + 1, intYear, intPeriod) = dblStatCumulativeMin(stat + 1, intPeriod) Then .Font.Color = lngBlue
4410                          If dblStatistic < 1000 Then
4420                              .TypeText " ("
4430                          Else
4440                              .TypeText "("
4450                          End If
4460                          .TypeText dblStatCumulative(stat + 1, intYear, intPeriod)
4470                          .TypeText ")"
4480                      Else
4490                          .Font.Color = lngBlue
4500                          .TypeText "0 (0)"
4510                      End If
4520                      .Font.Color = wdColorAutomatic
4530                  End If
4540              End With
4550          Next
          
4560          table.Cell(row, 3 + local_intPeriodLast_Season).range.Select
4570          With doc.ActiveWindow.Selection
4580              If intCapturesYearsCountSeasonYear(intSeason, intYear) = 0 Then
4590                  .TypeText "n/a"
4600              Else
4610                  dblStatistic = dblStatCumulative(stat, intYear, local_intPeriodLast_Season)
4620                  If dblStatistic = dblStatCumulativeMax(stat, local_intPeriodLast_Season) Then
4630                      .Font.Color = lngRed
4640                  End If
4650                  If dblStatistic = dblStatCumulativeMin(stat, local_intPeriodLast_Season) Then
4660                      .Font.Color = lngBlue
4670                  End If
4680                  If dblStatistic > 0 Then
4690                      .TypeText dblStatistic
4700                  Else
4710                      .Font.Color = lngBlue
4720                      .TypeText "0 (0)"
4730                  End If
4740                  .Font.Color = wdColorAutomatic
4750                  .TypeParagraph
4760                  dblStatistic = dblStatCumulative(stat + 1, intYear, local_intPeriodLast_Season)
4770                  If dblStatistic = dblStatCumulativeMax(stat + 1, local_intPeriodLast_Season) Then
4780                      .Font.Color = lngRed
4790                  End If
4800                  If dblStatistic = dblStatCumulativeMin(stat + 1, local_intPeriodLast_Season) Then
4810                      .Font.Color = lngBlue
4820                  End If
4830                  If dblStatistic > 0 Then
4840                      .TypeText " (" & dblStatistic & ")"
4850                  Else
4860                      .Font.Color = lngBlue
4870                      .TypeText "0 (0)"
4880                  End If
4890                  .Font.Color = wdColorAutomatic
4900              End If
4910          End With
4920          row = row + 1
4930      Next
4940  Next

      ' # species observed
      ' # net hours
      ' # birds banded / 100 net hours

      Dim fIsNotApplicable As Boolean

4950  For stat = conSpeciesDET To conBirdsPer100NetHours

4960      For intYear = intYearFirst To intYearLast
4970          For intPeriod = 1 To local_intPeriodLast_Season
4980              table.Cell(row, 2 + intPeriod).range.Select
4990              With doc.ActiveWindow.Selection
5000                  fIsNotApplicable = False
5010                  Select Case stat
                      Case conSpeciesDET
5020                      If getDETDays_SeasonYearPeriod(intSeason, intYear, intPeriod) = 0 Then
5030                          fIsNotApplicable = True
5040                      End If
5050                  Case conNetHours, conBirdsPer100NetHours
5060                      If getCaptureDays_SeasonYearPeriod(intSeason, intYear, intPeriod) = 0 Then
5070                          fIsNotApplicable = True
5080                      End If
5090                  End Select
5100                  If fIsNotApplicable Then
5110                      .TypeText "n/a"
5120                  Else
5130                      dblStatistic = dblStat(stat, intYear, intPeriod)
5140                      If dblStatistic > 0 Then
5150                          If Round(10 * dblStatistic, 0) = Round(10 * dblStatMax(stat, intPeriod), 0) Then
5160                              .Font.Color = lngRed
5170                          End If
5180                          If Round(10 * dblStatistic, 0) = Round(10 * dblStatMin(stat, intPeriod), 0) Then
5190                              .Font.Color = lngBlue
5200                          End If
5210                          Select Case stat
                              Case conSpeciesDET
5220                              .TypeText FormatNumberEnglish(dblStatistic, 0)
5230                          Case conNetHours, conBirdsPer100NetHours
5240                              .TypeText FormatNumberEnglish(dblStatistic, 1)
5250                          End Select
5260                      Else
5270                          .Font.Color = lngBlue
5280                          .TypeText "0 (0)"
5290                      End If
5300                      .Font.Color = wdColorAutomatic
5310                      .TypeParagraph
5320                      dblStatistic = dblStatCumulative(stat, intYear, intPeriod)
5330                      If dblStatistic > 0 Then
5340                          If Round(10 * dblStatistic, 0) = Round(10 * dblStatCumulativeMax(stat, intPeriod), 0) Then
5350                              .Font.Color = lngRed
5360                          End If
5370                          If Round(10 * dblStatistic, 0) = Round(10 * dblStatCumulativeMin(stat, intPeriod), 0) Then
5380                              .Font.Color = lngBlue
5390                          End If
5400                          Select Case stat
                              Case conSpeciesDET
5410                              .TypeText FormatNumberEnglish(dblStatistic, 0)
5420                          Case conNetHours, conBirdsPer100NetHours
5430                              .TypeText FormatNumberEnglish(dblStatistic, 1)
5440                          End Select
5450                      Else
5460                          .Font.Color = lngBlue
5470                          .TypeText "0"
5480                      End If
5490                     .Font.Color = wdColorAutomatic
5500                  End If
5510              End With
5520          Next
          
5530          table.Cell(row, 3 + local_intPeriodLast_Season).range.Select
5540          With doc.ActiveWindow.Selection
5550              fIsNotApplicable = False
5560              Select Case stat
                  Case conSpeciesDET
5570                  If getDETDays_SeasonYear(intSeason, intYear) = 0 Then
5580                      fIsNotApplicable = True
5590                  End If
5600              Case conNetHours, conBirdsPer100NetHours
5610                  If intCapturesYearsCountSeasonYear(intSeason, intYear) = 0 Then
5620                      fIsNotApplicable = True
5630                  End If
5640              End Select
5650              If fIsNotApplicable Then
5660                  .TypeText "n/a"
5670              Else
5680                  dblStatistic = dblStatCumulative(stat, intYear, local_intPeriodLast_Season)
5690                  If dblStatistic > 0 Then
5700                      If Round(10 * dblStatistic, 0) = Round(10 * dblStatCumulativeMax(stat, local_intPeriodLast_Season), 0) Then
5710                          .Font.Color = lngRed
5720                      End If
5730                      If Round(10 * dblStatistic, 0) = Round(10 * dblStatCumulativeMin(stat, local_intPeriodLast_Season), 0) Then
5740                          .Font.Color = lngBlue
5750                      End If
5760                      Select Case stat
                          Case conSpeciesDET
5770                          .TypeText FormatNumberEnglish(dblStatistic, 0)
5780                      Case conNetHours, conBirdsPer100NetHours
5790                          .TypeText FormatNumberEnglish(dblStatistic, 1)
5800                      End Select
5810                  Else
5820                      .Font.Color = lngBlue
5830                      .TypeText "0"
5840                  End If
5850                  .Font.Color = wdColorAutomatic
5860              End If
5870          End With
5880          row = row + 1
5890      Next

5900  Next

      ' Style all rows except for the header row

5910  For row = 2 To 1 + 6 * intCountYears
5920      table.Rows(row).range.Style = "ddOverviewData"
5930      table.Cell(row, 1).range.Style = "ddOverviewLabelColumn"
5940      table.Cell(row, 2).range.Style = "ddOverviewYearColumn"
5950  Next
          
      ' Merge column 1 row headers

5960  If intCountYears >= 2 Then
5970      For row = 2 To 2 + 5 * intCountYears Step intCountYears
5980          table.Cell(row, 1).Merge table.Cell(row + intCountYears - 1, 1)
5990      Next row
6000  End If

      ' Blank line

6010  Set range = MoveInsertionPointToEndOfDocument(wd, doc)
6020  range.InsertParagraphAfter
6030  range.Style = "ddBody"


      'DD Error Handler Start
Exit_label:
6040       Exit Sub
Err_label:
6050       Select Case Err.Number
           Case Else
6060            Call LogError("basMBO10YearProgramReportOverview", "MBO10YearProgramReportOverview")
6070       End Select
6080       Resume Exit_label
      'DD Error Handler End
          
End Sub


'---------------------------------------------------------------------------------------
' toRow
'---------------------------------------------------------------------------------------

Private Function toRow(ByVal stat As Integer)
10       On Error GoTo Err_label

20    toRow = stat + 2

    'DD Error Handler Start
Exit_label:
30        Exit Function
Err_label:
40        Select Case Err.Number
    Case Else
50       Call LogError("basMBO10YearProgramReportOverview", "toRow")
60        End Select
70        Resume Exit_label
    ' DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' toColFromPeriod
'---------------------------------------------------------------------------------------

Private Function toColFromPeriod(ByVal p As Integer) As Integer
10       On Error GoTo Err_label

20    toColFromPeriod = p + 2

          'DD Error Handler Start
Exit_label:
30        Exit Function
Err_label:
40        Select Case Err.Number
          Case Else
50       Call LogError("basMBO10YearProgramReportOverview", "toColFromPeriod")
60        End Select
70        Resume Exit_label
          ' DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' WordGenerateTableOverview
'---------------------------------------------------------------------------------------

Public Sub WordGenerateTableOverview( _
    ByRef doc As Word.Document, _
    ByRef range As Word.range, _
    ByVal strSeason As String, _
    ByVal local_intPeriodLast_Season As Integer, _
    ByVal intYearFirst As Integer, _
    ByVal intYearLast As Integer)

10    On Error GoTo Err_label

      Dim intCountYears As Integer
20    intCountYears = (intYearLast - intYearFirst + 1)

      Dim col As Integer

30    doc.Tables.Add range:=range, NumRows:=1 + 6 * intCountYears, NumColumns:=3 + local_intPeriodLast_Season
          
40    range.Expand (wdTable)
50    With range.Tables(1)

60        .Borders.InsideLineStyle = wdLineStyleSingle
70        .Borders.OutsideLineStyle = wdLineStyleSingle

80    Select Case strSeason
      Case "Spring"
90        .LeftPadding = doc.Application.CentimetersToPoints(0#)
100       .RightPadding = doc.Application.CentimetersToPoints(0#)
110       .TopPadding = doc.Application.CentimetersToPoints(0.05)
120   Case "Fall"
130       .LeftPadding = doc.Application.CentimetersToPoints(0#)
140       .RightPadding = doc.Application.CentimetersToPoints(0#)
150       .TopPadding = doc.Application.CentimetersToPoints(0.05)

160   End Select
          
          ' Center the table
          
170       .Rows.Alignment = wdAlignRowCenter

          Dim dblTableWidth As Double
          Dim dblColumnWidth_Label As Double
          Dim dblColumnWidth_Year As Double
          Dim dblColumnWidth_Period As Double
          Dim dblColumnWidth_Final As Double
          
180       Select Case strSeason
          Case "Spring"
190           dblTableWidth = 17.78
200           dblColumnWidth_Label = 1.93
210           dblColumnWidth_Year = 1.05
220           dblColumnWidth_Final = 1.2
230       Case "Fall"
240           dblTableWidth = 18.14
250           dblColumnWidth_Label = 1.69
260           dblColumnWidth_Year = 0.8
270           dblColumnWidth_Final = 0.96
280       End Select

290       dblColumnWidth_Period = (dblTableWidth - dblColumnWidth_Label - dblColumnWidth_Year - dblColumnWidth_Final) / local_intPeriodLast_Season
              
300       .columns(1).Width = doc.Application.CentimetersToPoints(dblColumnWidth_Label)
310       .columns(2).Width = doc.Application.CentimetersToPoints(dblColumnWidth_Year)
320       For col = 3 To 2 + local_intPeriodLast_Season
330           .columns(col).Width = doc.Application.CentimetersToPoints(dblColumnWidth_Period)
340       Next
350       .columns(3 + local_intPeriodLast_Season).Width = doc.Application.CentimetersToPoints(dblColumnWidth_Final)

          ' Format Header Row
          
360       Call FormatWordTableRowAsHeader(.Rows(1), "ddOverviewHeaderRow")
370       .Rows(1).range.ParagraphFormat.Alignment = wdAlignParagraphCenter

380       .Cell(1, 2).range.Style = "ddOverviewHeaderYear"
390       .Cell(1, 3 + local_intPeriodLast_Season).range.Style = "ddOverviewHeaderFinal"

          ' Headings
          
          Dim Period As Integer
          
400       .Cell(1, 2).range.Text = "Year"
410       For Period = 1 To local_intPeriodLast_Season
420           col = Period + 2
430           .Cell(1, col).range.Text = IIf(strSeason = "Spring", "S", "F") & Period
440       Next
450       .Cell(1, 3 + local_intPeriodLast_Season).range.Text = "FINAL"
                    
          ' Repeat heading row at the top of subsequent pages

460       .Rows.WrapAroundText = False
          
          ' Row labels in column 1

470       .Cell(2, 1).range.Text = "# individual birds (species) banded"
480       .Cell(2 + intCountYears, 1).range.Text = "# individual birds (species) return"
490       .Cell(2 + 2 * intCountYears, 1).range.Text = "# individual birds (species) repeat"
500       .Cell(2 + 3 * intCountYears, 1).range.Text = "# species observed"
510       .Cell(2 + 4 * intCountYears, 1).range.Text = "# net hours"
520       .Cell(2 + 5 * intCountYears, 1).range.Text = "# birds banded / 100 net hours"

          Dim row As Long

530       For row = 2 To 2 + 5 * intCountYears Step intCountYears
540           .Cell(row, 1).range.ParagraphFormat.Alignment = wdAlignParagraphCenter
550       Next
          
          ' Row labels (Years) in column 2
          
          Dim intStat As Integer
          Dim intYear As Integer

          
560       row = 2
          
570       For intStat = 1 To 6
580           For intYear = intYearFirst To intYearLast
590               .Cell(row, 2).range.Text = intYear
600               .Cell(row, 2).range.ParagraphFormat.Alignment = wdAlignParagraphCenter
610               row = row + 1
620           Next
630       Next

640   End With

          'DD Error Handler Start
Exit_label:
650       Exit Sub
Err_label:
660       Select Case Err.Number
          Case Else
670      Call LogError("basMBO10YearProgramReportOverview", "WordGenerateTableOverview")
680       End Select
690       Resume Exit_label
          ' DD Error Handler End

End Sub
