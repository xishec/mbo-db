Option Compare Database
Option Explicit

Const strForm As String = "basValidations"

'---------------------------------------------------------------------------------------
' AppendBypassableErrorMessage
'---------------------------------------------------------------------------------------
 
Private Sub AppendBypassableErrorMessage( _
    ByRef strBypassableErr As String, _
    ByVal BypassableErrorMessageID As Long, _
    Optional ByVal arg1 As String = "", _
    Optional ByVal arg2 As String = "")
        
10    On Error GoTo Err_label

      Dim strBypassableMsg As String
      
20    On Error Resume Next
30    strBypassableMsg = BypassableErrorMessage(BypassableErrorMessageID)
40    If Err.Number <> 0 Then
50        Call LogError("basValidations", "AppendBypassableErrorMessage", "BypassableErrorMessage array is empty")
60        GoTo Exit_label
70        Err.Clear
80    End If

90    If strBypassableMsg <> "" Then
100       If arg1 <> "" Then
110           strBypassableMsg = Replace(strBypassableMsg, "?1", arg1)
120       End If
130       If arg2 <> "" Then
140           strBypassableMsg = Replace(strBypassableMsg, "?2", arg1)
150       End If
160       If strBypassableMsg <> "" Then
170           strBypassableErr = strBypassableErr & strBypassableMsg & vbCrLf
180       End If
190   End If

      'DD Error Handler Start
Exit_label:
200        Exit Sub
Err_label:
210        Select Case Err.Number
      '     Case 9 ' Invalid Subscript
      '        CashBypassableErrorMessages
      '        UpdateBypassableErrorMessages (CurrentProgram)
      '        Resume
           Case Else
220             Call LogError("basValidations", "AppendBypassableErrorMessage")
230        End Select
240        Resume Exit_label
      'DD Error Handler End
End Sub


' Bypassable errors
' 1 = Species is required (4 letters)
' 2 = Species must be 4 letters
' 3 = Recaptures cannot be BADE (Band Destroyed)
' 4 = BADE Species can only be used when the Disposition is 4
' 5 = Recaptures cannot be BALO (Band Lost)
' 6 = BALO Species can only be used when the Disposition is 8
' 7 = Species is unknown (i.e. not in MBO's banding list
' 8 = Species is different in corresponding capture records

' ---------------------------------------------------------------------------
' IsSpeciesValid
'
' Required
' 4 characters
' BADE is ok when Disposition 4
' BALO is ok when Disposition = 8
' Validate in tblSpecies
' Is it the same as in other corresponding capture records

' PRE If BandPrefix, BandSuffix are supplied they are valid
' PRE If IDBand is supplied it is valid.
' ---------------------------------------------------------------------------

Public Function IsSpeciesValid( _
    ByVal Species As String, _
    ByRef strNotBypassableErr As String, _
    ByRef strBypassableErr As String, _
    ByVal Disposition As String, _
    Optional ByVal BandPrefix As String = "", _
    Optional ByVal BandSuffix As String = "", _
    Optional ByVal IDBand As Long = -1) As Boolean
          
10    On Error GoTo Err_label

20    strNotBypassableErr = ""
30    strBypassableErr = ""

40    If Len(Species) = 0 Then
50        Call AppendBypassableErrorMessage(strBypassableErr, 1)
60        GoTo Return_label
70    End If

80    If Len(Species) <> 4 Then
90        Call AppendBypassableErrorMessage(strBypassableErr, 2)
100       GoTo Return_label
110   End If

      Dim i As Integer
120   For i = 1 To 4
130       If Mid(Species, i, 1) < "A" Or Mid(Species, i, 1) > "Z" Then
140           Call AppendBypassableErrorMessage(strBypassableErr, 2)
150           GoTo Return_label
160       End If
170   Next i

180   Select Case Species
      Case "BADE"
190       If Disposition = "" Then
200           Call AppendBypassableErrorMessage(strBypassableErr, 3)
210           GoTo Return_label
220       ElseIf Disposition <> "4" Then
230           Call AppendBypassableErrorMessage(strBypassableErr, 4)
240           GoTo Return_label
250       End If
260   Case "BALO"
270       If Disposition = "" Then
280           Call AppendBypassableErrorMessage(strBypassableErr, 5)
290           GoTo Return_label
300       ElseIf Disposition <> "8" Then
310           Call AppendBypassableErrorMessage(strBypassableErr, 6)
320           GoTo Return_label
330       End If
340   Case Else
350       If DCount("*", "tblSpecies", "Species = '" & Species & "' AND MBOBandingList") = 0 Then
360           Call AppendBypassableErrorMessage(strBypassableErr, 7)
370           GoTo Return_label
380       End If

390   End Select

400   If Disposition <> "4" And Disposition <> "8" And Disposition <> "9" Then
410       If BandPrefix <> "" And BandSuffix <> "" Then
              Dim strCondition As String
420           strCondition = _
                  "[Species] <> '" & Species & "' AND " & _
                  "[BandPrefix] = '" & BandPrefix & "' AND " & _
                  "[BandSuffix] = '" & BandSuffix & "' AND " & _
                  "[IDBand] <> " & IDBand
430           If DCount("*", "tblCaptures", strCondition) > 0 Then
440               Call AppendBypassableErrorMessage(strBypassableErr, 8)
450               GoTo Return_label
460           End If
470       End If
480   End If

Return_label:
490       IsSpeciesValid = (strNotBypassableErr = "") And (strBypassableErr = "")

      'DD Error Handler Start
Exit_label:
500        Exit Function
Err_label:
510        Select Case Err.Number
           Case Else
520             Call LogError("basValidations", "IsSpeciesValid")
530        End Select
540        Resume Exit_label
      'DD Error Handler End
End Function

' ---------------------------------------------------------------------------
' IsBandPrefixValid
'
' Required
' 4 digits
' ---------------------------------------------------------------------------

Public Function IsBandPrefixValid( _
    ByVal BandPrefix As String, _
    ByRef strNotBypassableErr As String) As Boolean

10    On Error GoTo Err_label

20    strNotBypassableErr = ""

30    If BandPrefix = "" Then
40        strNotBypassableErr = strNotBypassableErr & "Prefix is required" & vbCrLf
50        GoTo Return_label
60    End If

70    If Len(BandPrefix) <> 4 Then
80        strNotBypassableErr = strNotBypassableErr & "Prefix must have 4 digits" & vbCrLf
90        GoTo Return_label
100   Else
          Dim i As Integer
110       For i = 1 To 4
120           If Mid(BandPrefix, i, 1) < "0" Or Mid(BandPrefix, i, 1) > "9" Then
130               strNotBypassableErr = strNotBypassableErr & "Prefix must have 4 digits" & vbCrLf
140               GoTo Return_label
150           End If
160       Next i
170   End If

Return_label:
180       IsBandPrefixValid = (strNotBypassableErr = "")

      'DD Error Handler Start
Exit_label:
190        Exit Function
Err_label:
200        Select Case Err.Number
           Case Else
210       Call LogError("basValidations", "IsBandPrefixValid")
220        End Select
230        Resume Exit_label
      'DD Error Handler End

End Function

' ---------------------------------------------------------------------------
' IsBandSuffixValid
'
' Required
' 5 digits
' ---------------------------------------------------------------------------

Public Function IsBandSuffixValid( _
    ByVal BandSuffix As String, _
    ByRef strNotBypassableErr As String, _
    Optional ByVal fShort As Boolean = False) As Boolean
          
10    On Error GoTo Err_label

20    strNotBypassableErr = ""

30    If BandSuffix = "" Then
40        strNotBypassableErr = strNotBypassableErr & "Suffix is required" & vbCrLf
50        GoTo Return_label
60    End If

      Dim length As Integer
70    length = IIf(fShort, 3, 5)

80    If Len(BandSuffix) <> length Then
90        strNotBypassableErr = strNotBypassableErr & _
              "Suffix must have " & CStr(length) & " digits" & vbCrLf
100       GoTo Return_label
110   Else
          Dim i As Integer
120       For i = 1 To length
130           If Mid(BandSuffix, i, 1) < "0" Or Mid(BandSuffix, i, 1) > "9" Then
140               strNotBypassableErr = strNotBypassableErr & _
                     "Suffix must have " & CStr(length) & " digits" & vbCrLf
150               GoTo Return_label
160           End If
170       Next i
180   End If

Return_label:
190       IsBandSuffixValid = (strNotBypassableErr = "")

      'DD Error Handler Start
Exit_label:
200        Exit Function
Err_label:
210        Select Case Err.Number
           Case Else
220       Call LogError("basValidations", "IsBandSuffixValid")
230        End Select
240        Resume Exit_label
      'DD Error Handler End

End Function

' ---------------------------------------------------------------------------
' IsShortSuffixValid(ByVal Suffix As String) As String
'
' Required
' 5 digits
' ---------------------------------------------------------------------------

Public Function IsShortSuffixValid(ByVal Suffix As String) As String

10    On Error GoTo Err_label

      Dim strErr As String

20    strErr = ""

30    If Len(Suffix) <> 3 Then
40        strErr = strErr & "Suffix must have 3 digits" & vbCrLf
50        GoTo Return_label
60    Else
          Dim i As Integer
70        For i = 1 To 3
80            If Mid(Suffix, i, 1) < "0" Or Mid(Suffix, i, 1) > "9" Then
90                strErr = strErr & "Suffix must have 3 digits" & vbCrLf
100               GoTo Return_label
110           End If
120       Next i
130   End If

Return_label:
140       IsShortSuffixValid = strErr

Exit_label:
150       Exit Function
Err_label:
160       Select Case Err.Number
          Case Else
170       If isDebug Then
180           MsgBox Err.Number & vbCrLf & Err.Description, _
                  Title:=strForm & " " & "IsShortSuffixValid"
190       End If
200       End Select
210       Resume Exit_label
End Function

' Bypassable errors
'  9 = Age is required
' 10 = Age is unknown
' 11 = Age is not consistent with the age in related capture records

' ---------------------------------------------------------------------------
' IsAgeValid
'
' Required
' Lookup in tblAge
'
' Assumption: Age has been trimmed
' Prefix, Suffix, CaptureDate are valid
'
' fIsMultiRecordError is True if the error involves multiple capture records for the band
' ---------------------------------------------------------------------------

Public Function IsAgeValid( _
    ByVal Age As String, _
    ByVal Prefix As String, _
    ByVal Suffix As String, _
    ByVal CaptureYear As Integer, _
    ByRef strNotBypassableErr As String, _
    ByRef strBypassableErr As String, _
    ByRef fIsMultiRecordError As Boolean, _
    Optional ByVal IDBand As Long = -1) As Boolean
          
10    On Error GoTo Err_label

20    strNotBypassableErr = ""
30    strBypassableErr = ""

      Dim intLen As Long
40    intLen = Len(Age)

50    If intLen = 0 Then
60        Call AppendBypassableErrorMessage(strBypassableErr, 9)
70        GoTo Return_label
80    End If

90    If DCount("*", "tblAge", "AgeID = '" & Age & "'") = 0 Then
100       Call AppendBypassableErrorMessage(strBypassableErr, 10)
110       GoTo Return_label
120   End If

      ' Is Age consistent with the age on other stored records with the same band number

130   If Not IsAgeConsistent(Prefix, Suffix, Age, CaptureYear, IDBand) Then
140       Call AppendBypassableErrorMessage(strBypassableErr, 11)
150       GoTo Return_label
160   End If

Return_label:
170       IsAgeValid = (strNotBypassableErr = "") And (strBypassableErr = "")

      'DD Error Handler Start
Exit_label:
180        Exit Function
Err_label:
190        Select Case Err.Number
           Case Else
200             Call LogError("basValidations", "IsAgeValid")
210        End Select
220        Resume Exit_label
      'DD Error Handler End
End Function

' Bypassable errors
' 12 = How Aged is required
' 13 = How Aged cannot have more than 2 characters
' 14 = How Aged is unknown

' ---------------------------------------------------------------------------
' IsAgeValid
'
' At least one how aged code is required
' Lookup in tblHowAged
'
' Assumption: HowAged has been trimmed
' ---------------------------------------------------------------------------

Public Function IsHowAgedValid( _
    ByVal HowAged As String, _
    ByRef strBypassableErr As String, _
    Optional IsBandit3HowAgedCode As Boolean = False) As Boolean
          
10    On Error GoTo Err_label

20    strBypassableErr = ""

30    If HowAged = "" Then
40      Call AppendBypassableErrorMessage(strBypassableErr, 12)
50      GoTo Return_label
60    End If

70    If Len(HowAged) > 2 Then
80        Call AppendBypassableErrorMessage(strBypassableErr, 13)
90        GoTo Return_label
100   End If


110   If IsBandit3HowAgedCode Then
120       If DCount("*", "tblHowAged", "HowAgedBanditCode = '" & HowAged & "'") = 0 Then
130           Call AppendBypassableErrorMessage(strBypassableErr, 14)
140           GoTo Return_label
150       End If
160   Else
170       If DCount("*", "tblHowAged", "HowAgedID = '" & HowAged & "'") = 0 Then
180           Call AppendBypassableErrorMessage(strBypassableErr, 14)
190           GoTo Return_label
200       End If
210   End If

Return_label:
220       IsHowAgedValid = (strBypassableErr = "")

      'DD Error Handler Start
Exit_label:
230        Exit Function
Err_label:
240        Select Case Err.Number
           Case Else
250       Call LogError("basValidations", "IsHowAgedValid")
260        End Select
270        Resume Exit_label
      'DD Error Handler End

End Function

' Bypassable errors
' 15 = Sex is required
' 16 = Sex is unknown
' 17 = Sex is  not consistent with the sex in related capture records
' 18 = This recapture is sex 4,5,6,7; original banding was sex 0
' 60 = This recapture is sex 6; original banding was sex 4
' 61 = This recapture is sex 7; original banding was sex 5

' ---------------------------------------------------------------------------
' IsSexValid
'
' Required
' Lookup in tblSex: 0, 4, 5, 6, 7
'
' PRE: Sex has been trimmed
'      BandPrefix and BandSuffix are either both "" or valid
'
' fIsMultiRecordError = True when the error involves several capture records for a band
' ---------------------------------------------------------------------------

Public Function IsSexValid( _
    ByVal Sex As String, _
    ByRef strNotBypassableErr As String, _
    ByRef strBypassableErr As String, _
    ByRef fIsMultiRecordError As Boolean, _
    Optional ByVal BandPrefix As String = "", _
    Optional ByVal BandSuffix As String = "", _
    Optional ByVal Disposition As String = "", _
    Optional ByVal IDBand As Long = -1) As Boolean

10    On Error GoTo Err_label

20    strNotBypassableErr = ""
30    strBypassableErr = ""

      Dim intLen As String
40    intLen = Len(Sex)

      ' Verify Sex is not null

50    If intLen = 0 Then
60        Call AppendBypassableErrorMessage(strBypassableErr, 15)
70        GoTo Return_label
80    End If

      ' Verify Sex is a valid code

90    If DCount("*", "tblSex", "SexID = '" & Sex & "'") = 0 Then
100       Call AppendBypassableErrorMessage(strBypassableErr, 16)
110       GoTo Return_label
120   End If

      ' If the Sex = 4 or 6 then verify there are no same-band records with Sex = 5 or 7
      ' If the Sex = 5 or 7 then verify there are no same-band records with Sex = 4 or 6

130   If BandPrefix <> "" And BandSuffix <> "" And Sex <> "0" Then
          Dim strCondition As String
140       strCondition = ""
150       If Sex = "4" Or Sex = "6" Then
160           strCondition = _
                  "( [Sex] = '5' OR [Sex] = '7' ) AND " & _
                  "[BandPrefix] = '" & BandPrefix & "' AND " & _
                  "[BandSuffix] = '" & BandSuffix & "' AND " & _
                  "[IDBand] <> " & IDBand
170       End If
180       If Sex = "5" Or Sex = "7" Then
190           strCondition = _
                  "( [Sex] = '4' OR [Sex] = '6' ) AND " & _
                  "[BandPrefix] = '" & BandPrefix & "' AND " & _
                  "[BandSuffix] = '" & BandSuffix & "' AND " & _
                  "[IDBand] <> " & IDBand
200       End If
210       If strCondition <> "" Then
220           If DCount("*", "tblCaptures", strCondition) > 0 Then
230               Call AppendBypassableErrorMessage(strBypassableErr, 17)
240               fIsMultiRecordError = True
250               GoTo Return_label
260           End If
270       End If
280   End If

      ' If Disposition = "R" and Sex = 4, 5, 6 or 7 then verify there are no disposition '1' band record with Sex = 0

290   If Disposition = "R" Then
300       If BandPrefix <> "" And BandSuffix <> "" And Sex <> "0" Then
310           If Sex = "4" Or Sex = "5" Or Sex = "6" Or Sex = "7" Then
320               strCondition = _
                      "[Disposition] = '1' AND " & _
                      "[Sex] = '0' AND " & _
                      "[BandPrefix] = '" & BandPrefix & "' AND " & _
                      "[BandSuffix] = '" & BandSuffix & "' AND " & _
                      "[IDBand] <> " & IDBand
330               If DCount("*", "tblCaptures", strCondition) > 0 Then
340                   Call AppendBypassableErrorMessage(strBypassableErr, 18)
350                   fIsMultiRecordError = True
360                   GoTo Return_label
370               End If
380           End If
390       End If
400   End If

      ' If Disposition = "R" and Sex = 6 then verify there are no disposition '1' band record with Sex = 4

410   If Disposition = "R" Then
420       If BandPrefix <> "" And BandSuffix <> "" And Sex = "6" Then
430           strCondition = _
                  "[Disposition] = '1' AND " & _
                  "[Sex] = '4' AND " & _
                  "[BandPrefix] = '" & BandPrefix & "' AND " & _
                  "[BandSuffix] = '" & BandSuffix & "' AND " & _
                  "[IDBand] <> " & IDBand
440           If DCount("*", "tblCaptures", strCondition) > 0 Then
450               Call AppendBypassableErrorMessage(strBypassableErr, 60)
460               fIsMultiRecordError = True
470               GoTo Return_label
480           End If
490       End If
500   End If


      ' If Disposition = "R" and Sex = 7 then verify there are no disposition '1' band record with Sex = 5

510   If Disposition = "R" Then
520       If BandPrefix <> "" And BandSuffix <> "" And Sex = "7" Then
530           strCondition = _
                  "[Disposition] = '1' AND " & _
                  "[Sex] = '5' AND " & _
                  "[BandPrefix] = '" & BandPrefix & "' AND " & _
                  "[BandSuffix] = '" & BandSuffix & "' AND " & _
                  "[IDBand] <> " & IDBand
540           If DCount("*", "tblCaptures", strCondition) > 0 Then
550               Call AppendBypassableErrorMessage(strBypassableErr, 61)
560               fIsMultiRecordError = True
570               GoTo Return_label
580           End If
590       End If
600   End If


Return_label:
610       IsSexValid = (strNotBypassableErr = "") And (strBypassableErr = "")

      'DD Error Handler Start
Exit_label:
620        Exit Function
Err_label:
630        Select Case Err.Number
           Case Else
640       Call LogError("basValidations", "IsSexValid")
650        End Select
660        Resume Exit_label
      'DD Error Handler End

End Function

' Bypassable errors
' 19 = How Sexed is required
' 20 = How Sexed cannot have more than 2 characters
' 21 = How Sexed is unknown

' ---------------------------------------------------------------------------
' IsHowSexedValid
'
' At least one how sexed code is required
' Lookup in tblHowSexed
'
' Assumptions: HowSexed has been trimmed
' ---------------------------------------------------------------------------

Public Function IsHowSexedValid( _
    ByVal HowSexed As String, _
    ByRef strBypassableErr As String, _
    Optional IsBandit3HowSexedCode As Boolean = False) As Boolean
          
10    On Error GoTo Err_label

20    strBypassableErr = ""

30    If HowSexed = "" Then
40        Call AppendBypassableErrorMessage(strBypassableErr, 19)
50        GoTo Return_label
60    End If

70    If Len(HowSexed) > 2 Then
80        Call AppendBypassableErrorMessage(strBypassableErr, 20)
90        GoTo Return_label
100   End If

110   If IsBandit3HowSexedCode Then
120       If DCount("*", "tblHowSexed", "HowSexedBanditCode = '" & HowSexed & "'") = 0 Then
130           Call AppendBypassableErrorMessage(strBypassableErr, 21)
140           GoTo Return_label
150       End If
160   Else
170       If DCount("*", "tblHowSexed", "HowSexedID = '" & HowSexed & "'") = 0 Then
180           Call AppendBypassableErrorMessage(strBypassableErr, 21)
190           GoTo Return_label
200       End If
210   End If

Return_label:
220       IsHowSexedValid = (strBypassableErr = "")

      'DD Error Handler Start
Exit_label:
230        Exit Function
Err_label:
240        Select Case Err.Number
           Case Else
250       Call LogError("basValidations", "IsHowSexedValid")
260        End Select
270        Resume Exit_label
      'DD Error Handler End

End Function

' Bypassable errors
' 22 = Weight is required
' 55 - Wing Chord out of range

' ---------------------------------------------------------------------------
' IsWeightValid
'
' Required
' Number > 0
'
' ---------------------------------------------------------------------------

Public Function IsWingChordValid( _
    ByVal WingChord As String, _
    ByRef strNotBypassableErr As String, _
    ByRef strBypassableErr As String, _
    ByVal Species As String, _
    ByVal Sex As String _
    ) As Boolean
          
10    On Error GoTo Err_label

20    strNotBypassableErr = ""
30    strBypassableErr = ""

      Dim intLen As Integer
40    intLen = Len(Trim(WingChord))

50    If intLen = 0 Then
60        Call AppendBypassableErrorMessage(strBypassableErr, 22)
70        GoTo Return_label
80    End If

      Dim i As Integer
90    For i = 1 To intLen
100       If Mid(WingChord, i, 1) < "0" Or Mid(WingChord, i, 1) > "9" Then
110           strNotBypassableErr = strNotBypassableErr & "Wing must be numeric, or blank" & vbCrLf
120           GoTo Return_label
130       End If
140   Next i

150   If CInt(WingChord) = 0 Then
160       strNotBypassableErr = strNotBypassableErr & "Wing must be > 0, or blank" & vbCrLf
170       GoTo Return_label
180   End If

190   If Species <> "" Then
          Dim WingMaxMale As Integer
          Dim WingMinMale As Integer
          Dim WingMaxFemale As Integer
          Dim WingMinFemale As Integer
          Dim WingMin As Integer
          Dim WingMax As Integer
          Dim WingValidate As Boolean
          
200       WingValidate = Nz(DLookup("WingValidate", "tblSpecies", "Species = '" & Species & "'"), False)
210       If WingValidate Then
          
220     WingMaxMale = Nz(DLookup("WingMaxMale", "tblSpecies", "Species = '" & Species & "'"), 0)
230     WingMaxFemale = Nz(DLookup("WingMaxFemale", "tblSpecies", "Species = '" & Species & "'"), 0)
240     WingMinMale = Nz(DLookup("WingMinMale", "tblSpecies", "Species = '" & Species & "'"), 0)
250     WingMinFemale = Nz(DLookup("WingMinFemale", "tblSpecies", "Species = '" & Species & "'"), 0)
260     Select Case Sex
        Case "", "0" ' unknown or invalid
270         If WingMinMale = 0 Then
280             WingMin = WingMinFemale
290         ElseIf WingMinFemale = 0 Then
300             WingMin = WingMinMale
310         Else
320             WingMin = IIf(WingMinMale < WingMinFemale, WingMinMale, WingMinFemale)
330         End If
340         If WingMaxMale = 0 Then
350             WingMax = WingMaxFemale
360         ElseIf WingMaxFemale = 0 Then
370             WingMax = WingMaxMale
380         Else
390             WingMax = IIf(WingMaxMale > WingMaxFemale, WingMaxMale, WingMaxFemale)
400         End If
410     Case "4" ' Male
420         WingMax = WingMaxMale
430         WingMin = WingMinMale
440     Case "5" ' Female
450         WingMax = WingMaxFemale
460         WingMin = WingMinFemale
470     End Select
480     If WingMin <> 0 Then
490         If CInt(WingChord) < WingMin Then
500             Call AppendBypassableErrorMessage(strBypassableErr, 55, CStr(WingMin))
510             GoTo Return_label
520         End If
530     End If
540     If WingMax <> 0 Then
550         If CInt(WingChord) > WingMax Then
560             Call AppendBypassableErrorMessage(strBypassableErr, 57, CStr(WingMax))
570             GoTo Return_label
580         End If
590     End If
600       End If
           
610   End If

Return_label:
620       IsWingChordValid = (strNotBypassableErr = "") And (strBypassableErr = "")

      'DD Error Handler Start
Exit_label:
630        Exit Function
Err_label:
640        Select Case Err.Number
           Case Else
650       Call LogError("basValidations", "IsWingChordValid")
660        End Select
670        Resume Exit_label
      'DD Error Handler End
End Function

' Bypassable errors
' 23 = Fat is required
' 24 = Fat is unknown

' ---------------------------------------------------------------------------
' IsFatValid
'
' Required
' Validate in tblFat
'
' ASSUMPTIONS
' Fat has been trimmed
'
' N.B. A Fat code of "11" is a bypassable error
' ---------------------------------------------------------------------------

Public Function IsFatValid( _
    ByVal Fat As String, _
    ByRef strNotBypassableErr As String, _
    ByRef strBypassableErr As String) As Boolean
          
10    On Error GoTo Err_label

20    strNotBypassableErr = ""
30    strBypassableErr = ""

40    If Fat = "" Then
50        Call AppendBypassableErrorMessage(strBypassableErr, 23)
60        GoTo Return_label
70    End If

80    If DCount("*", "tblFat", "FatID = '" & Fat & "'") = 0 Then
90        Call AppendBypassableErrorMessage(strBypassableErr, 24)
100       GoTo Return_label
110   End If

Return_label:
120       IsFatValid = (strNotBypassableErr = "") And (strBypassableErr = "")

      'DD Error Handler Start
Exit_label:
130        Exit Function
Err_label:
140        Select Case Err.Number
           Case Else
150       Call LogError("basValidations", "IsFatValid")
160        End Select
170        Resume Exit_label
      'DD Error Handler End

End Function

' ---------------------------------------------------------------------------
' IsDateValid
'
'       Date MMDD
'       Year YYYY
'
' Required fields
' MMDD must have 4 digits
' Int(leftmost 2 digits) between 1 and 12
' Int(rightmost 2 digits) between 1 and 31
' YYYY must have 4 digits
' MMDDYYYY must be a valid date
' Date >= Program's official start date
' Date <= Program's official end date
' ---------------------------------------------------------------------------

Public Function IsDateValid( _
    ByVal CaptureDate As String, ByVal CaptureYear As String, _
    ByVal strProgram As String, _
    ByRef strNotBypassableErr As String, _
    ByRef strBypassableErr As String) As Boolean
          
10    On Error GoTo Err_label

      Dim i As Integer
      Dim chr As String

20    strNotBypassableErr = ""
30    strBypassableErr = ""

      ' Validate the Month and Day

      Dim intLen As String
40    intLen = Len(CaptureDate)

50    If intLen = 0 Then
60        strNotBypassableErr = strNotBypassableErr & "Date is required (format MMDD)" & vbCrLf
70        GoTo ValidateYear_label
80    End If

90    If intLen <> 4 Then
100       strNotBypassableErr = strNotBypassableErr & "Date must be in the format MMDD" & vbCrLf
110       GoTo ValidateYear_label
120   End If

130   For i = 1 To intLen
140       chr = Mid(CaptureDate, i, 1)
150       If chr < "0" Or chr > "9" Then
160           strNotBypassableErr = strNotBypassableErr & "Date must be in the format MMDD" & vbCrLf
170           GoTo ValidateYear_label
180       End If
190   Next i

200   If Int(Left(CaptureDate, 2)) = 0 Or Int(Left(CaptureDate, 2)) > 12 Then
210       strNotBypassableErr = strNotBypassableErr & "Month must be between 01 and 12" & vbCrLf
220       GoTo ValidateYear_label
230   End If
240   If Int(Right(CaptureDate, 2)) = 0 Or Int(Right(CaptureDate, 2)) > 31 Then
250       strNotBypassableErr = strNotBypassableErr & "Day must be between 01 and 31" & vbCrLf
260       GoTo ValidateYear_label
270   End If

      ' Validate the Year

ValidateYear_label:

280   intLen = Len(CaptureYear)

290   If intLen = 0 Then
300       strNotBypassableErr = strNotBypassableErr & "Year is required (format YYYY)" & vbCrLf
310       GoTo Return_label
320   End If

330   If intLen <> 4 Then
340       strNotBypassableErr = strNotBypassableErr & "Year must have 4 digits" & vbCrLf
350       GoTo Return_label
360   End If

370   If strBypassableErr = "" And strNotBypassableErr = "" Then
380       For i = 1 To 4
390           chr = Mid(CaptureYear, i, 1)
400           If chr < "0" Or chr > "9" Then
410               strNotBypassableErr = strNotBypassableErr & "Year must have 4 digits" & vbCrLf
420               GoTo Return_label
430           End If
440       Next i
450   End If

      Dim varDate As Variant
460   varDate = ConvertCaptureDateAndCaptureYearToVBADate(CaptureDate, CaptureYear)
470   If IsNull(varDate) Then
480       strNotBypassableErr = "Date or Year is invalid" & vbCrLf
490       GoTo Return_label
500   End If

      ' Verify date >= program's official start date

      Dim datOfficialStartDate As Date
510   datOfficialStartDate = Nz(DLookup("DateFrom", "tblPrograms", "[Program] = '" & strProgram & "'"))
520   If datOfficialStartDate <> 0 Then
530       If CDate(varDate) < datOfficialStartDate Then
540           strBypassableErr = strBypassableErr & "Before start of program " & Format(CDate(varDate), "d mmm yyyy") & " < " & Format(datOfficialStartDate, "d mmm yyyy") & vbCrLf
550       End If
560   End If

      ' Verify date <= program's official end date

      Dim datOfficialEndDate As Date
570   datOfficialEndDate = Nz(DLookup("DateTo", "tblPrograms", "[Program] = '" & strProgram & "'"))
580   If datOfficialEndDate <> 0 Then
590       If CDate(varDate) > datOfficialEndDate Then
600           strBypassableErr = strBypassableErr & "After end of program " & Format(CDate(varDate), "d mmm yyyy") & " > " & Format(datOfficialEndDate, "d mmm yyyy") & vbCrLf
610       End If
620   End If

Return_label:
630       IsDateValid = (strNotBypassableErr = "") And (strBypassableErr = "")

      'DD Error Handler Start
Exit_label:
640        Exit Function
Err_label:
650        Select Case Err.Number
           Case Else
660       Call LogError("basValidations", "IsDateValid")
670        End Select
680        Resume Exit_label
      'DD Error Handler End
End Function

' Bypassable errors
' 25 = Bander is required (2 to 3 letters)
' 26 = Bander must be left justified (2 to 3 letters)
' 27 = Bander is unknown

' ---------------------------------------------------------------------------
' IsBanderValid
'
' Required
' 2 or 3 uppercase letters
'
' ASSUMPTIONS
'   0 to 3 characters
'   Letters are in uppercase
'   Bander has been trimmed
' ---------------------------------------------------------------------------

Public Function IsBanderValid( _
    ByVal Bander As String, _
    ByVal fCurrentBander As Boolean, _
    ByRef strNotBypassableErr As String, _
    ByRef strBypassableErr As String) As Boolean
          
10    On Error GoTo Err_label

20    strNotBypassableErr = ""
30    strBypassableErr = ""

      Dim intLen As String
40    intLen = Len(Bander)

50    If intLen = 0 Then
60        Call AppendBypassableErrorMessage(strBypassableErr, 25)
70        GoTo Return_label
80    End If

90    If Left(Bander, 1) = " " Then
100       Call AppendBypassableErrorMessage(strBypassableErr, 26)
110       GoTo Return_label
120   End If

      Dim strWhere As String
          
130   If fCurrentBander Then
140       strWhere = _
              "VolunteerCode = '" & Bander & "' AND " & _
              "IsBander = True AND IsCurrent = True"
150   Else
160       strWhere = _
              "VolunteerCode = '" & Bander & "' AND " & _
              "IsBander = True"
170   End If

180   If DCount("*", "tblVolunteers", strWhere) = 0 Then
190       Call AppendBypassableErrorMessage(strBypassableErr, 27)
200       GoTo Return_label
210   End If

Return_label:
220       IsBanderValid = (strNotBypassableErr = "") And (strBypassableErr = "")

      'DD Error Handler Start
Exit_label:
230        Exit Function
Err_label:
240        Select Case Err.Number
           Case Else
250       Call LogError("basValidations", "IsBanderValid")
260        End Select
270        Resume Exit_label
      'DD Error Handler End

End Function


' ---------------------------------------------------------------------------
' IsDispositionValid
'
' strDispositionCategory: All Captures
'                         New Captures
'                         Recaptures
'
' Assumptions:
' Disposition has been trimmed
'
' Bypassable Errors
' -----------------
' 63 Disposition is ?1
'
' fDisposition = IsDispositionValid(B.Disposition, strNotBypassableErr, strBypasableErr, strDispositionCategory)
' ---------------------------------------------------------------------------

Public Function IsDispositionValid( _
    ByVal Disposition As String, _
    ByRef strNotBypassableErr As String, _
    ByRef strBypassableErr As String, _
    Optional ByVal strDispositionCategory As String = "All Captures") As Boolean
          
10    On Error GoTo Err_label

20    strNotBypassableErr = ""
30    strBypassableErr = ""

      ' Required

      Dim intLen As String
40    intLen = Len(Disposition)

50    If intLen = 0 Then
60        strNotBypassableErr = strNotBypassableErr & "Disposition is required" & vbCrLf
70        GoTo Return_label
80    End If

      ' All Captures
      ' ------------
      ' If the Disposition is not "1", "5", "R", "F", "4", "8" => non bypassabe error

      ' New Captures (c.f. tblDisposition)
      ' ---------
      ' If the Disposition isn't 1 5 4 8 => non bypassable error

      ' Recaptures
      ' ----------
      ' If the Disposition isn't "R or "F" => a non bypassable error


90    Select Case strDispositionCategory
      Case "All Captures"
100       Select Case Disposition
          Case "1", "5", "R", "F", "4", "8"
110       Case Else
120           strNotBypassableErr = strNotBypassableErr & "The MBO Database cannot store records with Disposition " & Disposition & vbCrLf
130       End Select
140   Case "New Captures"

150       Select Case Disposition
          Case "1", "5", "4", "8"
160       Case Else
170           strNotBypassableErr = strNotBypassableErr & "Disposition must be 1, 5, 4, 8 in the Bands sheet" & vbCrLf
180       End Select

190   Case "Recaptures"
200       If Not (Disposition = "R" Or Disposition = "F") Then
210           strNotBypassableErr = strNotBypassableErr & "Disposition must be R or F in the Recaptures sheet" & vbCrLf
220       End If
230   End Select

Return_label:
240       IsDispositionValid = (strNotBypassableErr = "") And (strBypassableErr = "")

      'DD Error Handler Start
Exit_label:
250        Exit Function
Err_label:
260        Select Case Err.Number
           Case Else
270       Call LogError("basValidations", "IsDispositionValid")
280        End Select
290        Resume Exit_label
      'DD Error Handler End

End Function
'
'' ---------------------------------------------------------------------------
'' IsDispositionValid(ByVal Disposition As String, _
'    Optional ByVal strDispositionCategory As String = "All Captures") As String
''
'' strDispositionCategory: All Captures
''                         New Captured
''                         Recaptures
''
'' Required
'' Validate in tblDisposition
''
'' Assumptions:
'' Disposition has been trimmed
'' ---------------------------------------------------------------------------
'
'Public Function IsDispositionValid( _
'    ByVal Disposition As String, _
'    ByRef strNotBypassableErr As String, _
'    Optional ByVal strDispositionCategory As String = "All Captures") As Boolean
'
'10    On Error GoTo Err_label
'
'20    strNotBypassableErr = ""
'
'      Dim intLen As String
'30    intLen = Len(Disposition)
'
'40    If intLen = 0 Then
'50        strNotBypassableErr = strNotBypassableErr & "Disposition is required" & vbCrLf
'60        GoTo Return_label
'70    End If
'
'80    If strDispositionCategory = "All Captures" Then
'90        If DCount("*", "tblDisposition", "DispositionID = '" & Disposition & "'") = 0 Then
'100           strNotBypassableErr = strNotBypassableErr & "Disposition is unknown" & vbCrLf
'110           GoTo Return_label
'120       End If
'130   Else
'140       If DCount("*", "tblDisposition", "DispositionID = '" & Disposition & "' AND " & _
'                  "Category = '" & strDispositionCategory & "'") = 0 Then
'150           strNotBypassableErr = strNotBypassableErr & "Disposition is unknown" & vbCrLf
'160           GoTo Return_label
'170       End If
'180   End If
'
'Return_label:
'190       IsDispositionValid = (strNotBypassableErr = "")
'
'      'DD Error Handler Start
'Exit_label:
'200        Exit Function
'Err_label:
'210        Select Case Err.Number
'           Case Else
'220       Call LogError("basValidations", "IsDispositionValid")
'230        End Select
'240        Resume Exit_label
'      'DD Error Handler End
'
'End Function

' Bypassable errors
' 28 = Weight is required
' 56 - Weight out of range
' ---------------------------------------------------------------------------
' IsWeightValid
'
' Required
' 1 to 4 digit strictly positive integer, right justifed in 4 character positions
' ---------------------------------------------------------------------------

Public Function IsWeightValid( _
    ByVal Weight As String, _
    ByRef strNotBypassableErr As String, _
    ByRef strBypassableErr As String, _
    ByVal Species As String, _
    ByVal Sex As String _
    ) As Boolean
          
10    On Error GoTo Err_label

20    strNotBypassableErr = ""
30    strBypassableErr = ""

      Dim intLen As Integer
40    intLen = Len(Trim(Weight))

50    If Weight = "" Then
60        Call AppendBypassableErrorMessage(strBypassableErr, 28)
70        GoTo Return_label
80    End If

      Dim i As Integer
90    For i = 1 To intLen
100       If Mid(Weight, i, 1) < "0" Or Mid(Weight, i, 1) > "9" Then
110           strNotBypassableErr = strNotBypassableErr & _
                  "Weight must be numeric without the implied decimal point, or blank" & vbCrLf
120           GoTo Return_label
130       End If
140   Next i

150   If CInt(Weight) = 0 Then
160       strNotBypassableErr = strNotBypassableErr & "Weight must be > 0, or blank" & vbCrLf
170       GoTo Return_label
180   End If

190   If Species <> "" Then
          Dim WeightMaxMale As Integer
          Dim WeightMinMale As Integer
          Dim WeightMaxFemale As Integer
          Dim WeightMinFemale As Integer
          Dim WeightMin As Integer
          Dim WeightMax As Integer
          Dim WeightValidate As Boolean
          
200       WeightValidate = Nz(DLookup("WeightValidate", "tblSpecies", "Species = '" & Species & "'"), False)
210       If WeightValidate Then
          
220     WeightMaxMale = Nz(DLookup("WeightMaxMale", "tblSpecies", "Species = '" & Species & "'"), 0)
230     WeightMaxFemale = Nz(DLookup("WeightMaxFemale", "tblSpecies", "Species = '" & Species & "'"), 0)
240     WeightMinMale = Nz(DLookup("WeightMinMale", "tblSpecies", "Species = '" & Species & "'"), 0)
250     WeightMinFemale = Nz(DLookup("WeightMinFemale", "tblSpecies", "Species = '" & Species & "'"), 0)
260     Select Case Sex
        Case "", "0" ' unknown or invalid
270         If WeightMinMale = 0 Then
280             WeightMin = WeightMinFemale
290         ElseIf WeightMinFemale = 0 Then
300             WeightMin = WeightMinMale
310         Else
320             WeightMin = IIf(WeightMinMale < WeightMinFemale, WeightMinMale, WeightMinFemale)
330         End If
340         If WeightMaxMale = 0 Then
350             WeightMax = WeightMaxFemale
360         ElseIf WeightMaxFemale = 0 Then
370             WeightMax = WeightMaxMale
380         Else
390             WeightMax = IIf(WeightMaxMale > WeightMaxFemale, WeightMaxMale, WeightMaxFemale)
400         End If
410     Case "4" ' Male
420         WeightMax = WeightMaxMale
430         WeightMin = WeightMinMale
440     Case "5" ' Female
450         WeightMax = WeightMaxFemale
460         WeightMin = WeightMinFemale
470     End Select
480     If WeightMin <> 0 Then
490         If CInt(Weight) < WeightMin Then
500             Call AppendBypassableErrorMessage(strBypassableErr, 56, CStr(WeightMin))
510             GoTo Return_label
520         End If
530     End If
540     If WeightMax <> 0 Then
550         If CInt(Weight) > WeightMax Then
560             Call AppendBypassableErrorMessage(strBypassableErr, 58, CStr(WeightMax))
570             GoTo Return_label
580         End If
590     End If
600       End If
           
610   End If

Return_label:
620       IsWeightValid = (strNotBypassableErr = "") And (strBypassableErr = "")

      'DD Error Handler Start
Exit_label:
630        Exit Function
Err_label:
640        Select Case Err.Number
           Case Else
650             Call LogError("basValidations", "IsWeightValid")
660        End Select
670        Resume Exit_label
      'DD Error Handler End

End Function

' Bypassable errors
' 29 = Time is required (format HHM)

' ---------------------------------------------------------------------------
' IsWeightTimeValid      HHM
'
' Required
' 3 digits
' CInt(all except rightmost digit) between 0 and 23
' CInt(rightmost digit) between 0 and 5
' Time has been trimmed
' ---------------------------------------------------------------------------

Public Function IsWeightTimeValid( _
    ByVal TimeWeighed As String, _
    ByRef strNotBypassableErr As String, _
    ByRef strBypassableErr As String) As Boolean
          
10    On Error GoTo Err_label

20    strNotBypassableErr = ""
30    strBypassableErr = ""

      Dim intLen As Integer
40    intLen = Len(TimeWeighed)

50    If intLen = 0 Then
60        Call AppendBypassableErrorMessage(strBypassableErr, 29)
70        GoTo Return_label
80    End If

90    If intLen <> 3 Then
100       strNotBypassableErr = strNotBypassableErr & "Time must be in the format HHM" & vbCrLf
110       GoTo Return_label
120   End If

      Dim i As Integer
130   For i = 1 To intLen
          Dim chr As String
140       chr = Mid(TimeWeighed, i, 1)
150       If chr < "0" Or chr > "9" Then
160           strNotBypassableErr = strNotBypassableErr & "Time must be in the format HHM" & vbCrLf
170           GoTo Return_label
180       End If
190   Next i

200   If CInt(Left(TimeWeighed, 2)) > 23 Then
210       strNotBypassableErr = strNotBypassableErr & "Hour must be between 00 and 23" & vbCrLf
220       GoTo Return_label
230   End If
240   If CInt(Right(TimeWeighed, 1)) > 5 Then
250       strNotBypassableErr = strNotBypassableErr & "Minutes must be between 0 and 5" & vbCrLf
260       GoTo Return_label
270   End If

Return_label:
280       IsWeightTimeValid = (strNotBypassableErr = "") And (strBypassableErr = "")

      'DD Error Handler Start
Exit_label:
290        Exit Function
Err_label:
300        Select Case Err.Number
           Case Else
310             Call LogError("basValidations", "IsWeightTimeValid")
320        End Select
330        Resume Exit_label
      'DD Error Handler End

End Function

' Bypassable errors
' 30 = Net is required
' 31 = Net is unknown

' ---------------------------------------------------------------------------
' IsNetValid(Net,IsCurrentNet)
'
' Required
' Validate in tblNets
'
' Assumptions
' Net has been trimmed
' ---------------------------------------------------------------------------

Public Function IsNetValid( _
    ByVal Net As String, _
    ByRef strNotBypassableErr As String, _
    ByRef strBypassableErr As String, _
    Optional ByRef fCurrentNet = True) As Boolean
          
10    On Error GoTo Err_label

20    strNotBypassableErr = ""
30    strBypassableErr = ""

40    If Len(Net) = 0 Then
50        Call AppendBypassableErrorMessage(strBypassableErr, 30)
60        GoTo Return_label
70    End If

80    If fCurrentNet Then
90        If DCount("*", "tblNets", "NetID = '" & Net & "' AND IsNetCurrent = True") = 0 Then
100           Call AppendBypassableErrorMessage(strBypassableErr, 31)
110           GoTo Return_label
120       End If
130   Else
140       If DCount("*", "tblNets", "NetID = '" & Net & "'") = 0 Then
150           Call AppendBypassableErrorMessage(strBypassableErr, 31)
160           GoTo Return_label
170       End If
180   End If

Return_label:
190       IsNetValid = (strNotBypassableErr = "") And (strBypassableErr = "")

      'DD Error Handler Start
Exit_label:
200        Exit Function
Err_label:
210        Select Case Err.Number
           Case Else
220             Call LogError("basValidations", "IsNetValid")
230        End Select
240        Resume Exit_label
      'DD Error Handler End

End Function

' Bypassable errors
' 32 = Scribe is required (2 to 3 letters)
' 33 = Scribe must be left justified (2 to 3 letters)
' 34 = Scribe must be 2 or 3 letters
' 59 = Scribe is unknown

' ---------------------------------------------------------------------------
' IsScribeValid
'
' Required
' 2 or 3 characters A..Z, left justified
'
' ASSUMPTIONS
'   0 to 3 characters
'   Uppercase
'   Scribe has been trimmed
' ---------------------------------------------------------------------------

Public Function IsScribeValid( _
    ByVal Scribe As String, _
    ByVal fCurrent As Boolean, _
    ByRef strNotBypassableErr As String, _
    ByRef strBypassableErr As String) As Boolean
          
10    On Error GoTo Err_label

20    strNotBypassableErr = ""
30    strBypassableErr = ""

      Dim intLen As String
40    intLen = Len(Scribe)

50    If intLen = 0 Then
60        Call AppendBypassableErrorMessage(strBypassableErr, 32)
70        GoTo Return_label
80    End If

90    If Left(Scribe, 1) = " " Then
100       Call AppendBypassableErrorMessage(strBypassableErr, 33)
110       GoTo Return_label
120   End If

      Dim strWhere As String
          
130   If fCurrent Then
140       strWhere = _
              "VolunteerCode = '" & Scribe & "' AND " & _
              "IsCurrent = True"
150   Else
160       strWhere = _
              "VolunteerCode = '" & Scribe & "'"
170   End If

180   If DCount("*", "tblVolunteers", strWhere) = 0 Then
190       Call AppendBypassableErrorMessage(strBypassableErr, 59)
200       GoTo Return_label
210   End If

Return_label:
220       IsScribeValid = (strNotBypassableErr = "") And (strBypassableErr = "")

      'DD Error Handler Start
Exit_label:
230        Exit Function
Err_label:
240        Select Case Err.Number
           Case Else
250             Call LogError("basValidations", "IsScribeValid")
260        End Select
270        Resume Exit_label
      'DD Error Handler End

End Function

' ---------------------------------------------------------------------------
' IsShortYearValid      YY
'
' Required
' All 2 characters are digits
'
' ASSUMPTIONS
' 0 to 2 digits
' ---------------------------------------------------------------------------

Public Function IsShortYearValid(YearBanded As String) As String

10    On Error GoTo Err_label

      Dim strErr As String
20    strErr = ""

30    If Len(YearBanded) = 0 Then
40        strErr = strErr & "Year is required (format YY)" & vbCrLf
50        GoTo Return_label
60    End If

70    If Len(YearBanded) <> 2 Then
80        strErr = strErr & "Enter Year as 2 digits" & vbCrLf
90        GoTo Return_label
100   End If

      Dim i As Integer
110   For i = 1 To 2
          Dim chr As String
120       chr = Mid(YearBanded, i, 1)
130       If chr < "0" Or chr > "9" Then
140           strErr = strErr & "Enter Year as 2 digits" & vbCrLf
150           GoTo Return_label
160       End If
170   Next i

Return_label:
180       IsShortYearValid = strErr

      'DD Error Handler Start
Exit_label:
190        Exit Function
Err_label:
200        Select Case Err.Number
           Case Else
210             Call LogError("basValidations", "IsShortYearValid")
220        End Select
230        Resume Exit_label
      'DD Error Handler End

End Function

' Bypassable errors
' 35 = Location is required
' 36 = Location is unknown

' ---------------------------------------------------------------------------
' IsLocationValid
'
' Assunptions:
' Location has been trimmed
' ---------------------------------------------------------------------------

Public Function IsLocationValid( _
    ByVal Location As String, _
    ByRef strNotBypassableErr As String, _
    ByRef strBypassableErr As String) As Boolean
          
10    On Error GoTo Err_label

20    strNotBypassableErr = ""
30    strBypassableErr = ""

      Dim intLen As String
40    intLen = Len(Location)

50    If intLen = 0 Then
60        Call AppendBypassableErrorMessage(strBypassableErr, 35)
70        GoTo Return_label
80    End If

90    If DCount("*", "tblLocations", "LocationID = '" & Location & "'") = 0 Then
100       Call AppendBypassableErrorMessage(strBypassableErr, 36)
110       GoTo Return_label
120   End If

Return_label:
130       IsLocationValid = (strNotBypassableErr = "") And (strBypassableErr = "")

      'DD Error Handler Start
Exit_label:
140        Exit Function
Err_label:
150        Select Case Err.Number
           Case Else
160             Call LogError("basValidations", "IsLocationValid")
170        End Select
180        Resume Exit_label
      'DD Error Handler End
End Function

' Bypassable errors
' 37 = Monitoring Program is required
' 38 = Monitoring Program is unknown

' ---------------------------------------------------------------------------
' IsProgramValid
'
' Assumptions:
' Program has been trimmed
' ---------------------------------------------------------------------------

Public Function IsProgramValid( _
    ByVal Program As String, _
    ByRef strNotBypassableErr As String, _
    ByRef strBypassableErr As String) As Boolean
          
10    On Error GoTo Err_label

20    strNotBypassableErr = ""
30    strBypassableErr = ""

      Dim intLen As String
40    intLen = Len(Program)

50    If intLen = 0 Then
60        Call AppendBypassableErrorMessage(strBypassableErr, 37)
70        GoTo Return_label
80    End If

90    If DCount("*", "tblPrograms", "Program = '" & Program & "'") = 0 Then
100       Call AppendBypassableErrorMessage(strBypassableErr, 38)
110       GoTo Return_label
120   End If

Return_label:
130       IsProgramValid = (strNotBypassableErr = "") And (strBypassableErr = "")

      'DD Error Handler Start
Exit_label:
140        Exit Function
Err_label:
150        Select Case Err.Number
           Case Else
160           Call LogError("basValidations", "IsProgramValid")
170        End Select
180        Resume Exit_label
      'DD Error Handler End

End Function

' Bypassable errors
' 39 = Probable Age is unknown

' ---------------------------------------------------------------------------
' IsProbableAgeValid
' ---------------------------------------------------------------------------

Public Function IsProbableAgeValid( _
    ByVal ProbableAge As String, _
    ByRef strNotBypassableErr As String, _
    ByRef strBypassableErr As String) As Boolean
          
10    On Error GoTo Err_label

20    strNotBypassableErr = ""
30    strBypassableErr = ""

40    If Len(ProbableAge) <> 0 Then
50        If DCount("*", "tblAge", "AgeID = '" & ProbableAge & "'") = 0 Then
60            Call AppendBypassableErrorMessage(strBypassableErr, 39)
70            GoTo Return_label
80        End If
90    End If

Return_label:
100       IsProbableAgeValid = (strNotBypassableErr = "") And (strBypassableErr = "")

      'DD Error Handler Start
Exit_label:
110        Exit Function
Err_label:
120        Select Case Err.Number
           Case Else
130           Call LogError("basValidations", "IsProbableAgeValid")
140        End Select
150        Resume Exit_label
      'DD Error Handler End

End Function

' Bypassable errors
' 40 = Probable Sex is unknown

' ---------------------------------------------------------------------------
' IsProbableSexValid
'
' Assumptions:
' ProbableSex has been trimmed
' ---------------------------------------------------------------------------

Public Function IsProbableSexValid( _
    ByVal ProbableSex As String, _
    ByRef strNotBypassableErr As String, _
    ByRef strBypassableErr As String) As Boolean
          
10    On Error GoTo Err_label

20    strNotBypassableErr = ""
30    strBypassableErr = ""

40    If Len(ProbableSex) <> 0 Then
50        If DCount("*", "tblSex", "SexID = '" & ProbableSex & "'") = 0 Then
60            Call AppendBypassableErrorMessage(strBypassableErr, 40)
70            GoTo Return_label
80        End If
90    End If

Return_label:
100       IsProbableSexValid = (strNotBypassableErr = "") And (strBypassableErr = "")

      'DD Error Handler Start
Exit_label:
110        Exit Function
Err_label:
120        Select Case Err.Number
           Case Else
130           Call LogError("basValidations", "IsProbableSexValid")
140        End Select
150        Resume Exit_label
      'DD Error Handler End

End Function

' Bypassable errors
' 41 = Bird Status is required
' 42 = Bird Status is unknown

' ---------------------------------------------------------------------------
' IsBirdStatusValid
'
' Assumptions:
' BirdStatus has been trimmed
' ---------------------------------------------------------------------------

Public Function IsBirdStatusValid( _
    ByVal BirdStatus As String, _
    ByRef strNotBypassableErr As String, _
    ByRef strBypassableErr As String) As Boolean
          
10    On Error GoTo Err_label

20    strNotBypassableErr = ""
30    strBypassableErr = ""

      Dim intLen As String
40    intLen = Len(BirdStatus)

50    If intLen = 0 Then
60        Call AppendBypassableErrorMessage(strBypassableErr, 41)
70        GoTo Return_label
80    End If

90    If DCount("*", "tblBirdStatus", "BirdStatus = '" & BirdStatus & "'") = 0 Then
100       Call AppendBypassableErrorMessage(strBypassableErr, 42)
110       GoTo Return_label
120   End If

Return_label:
130       IsBirdStatusValid = (strNotBypassableErr = "") And (strBypassableErr = "")

      'DD Error Handler Start
Exit_label:
140        Exit Function
Err_label:
150        Select Case Err.Number
           Case Else
160             Call LogError("basValidations", "IsBirdStatusValid")
170        End Select
180        Resume Exit_label
      'DD Error Handler End

End Function

' Bypassable errors
' 43 = Present Condition is required
' 44 = Present Condition is unknown

' ---------------------------------------------------------------------------
' IsPresentConditionValid
'
' Assumptions:
' PresentCondition has been trimmed
' ---------------------------------------------------------------------------

Public Function IsPresentConditionValid( _
    ByVal PresentCondition As String, _
    ByRef strNotBypassableErr As String, _
    ByRef strBypassableErr As String) As Boolean
          
10    On Error GoTo Err_label

20    strNotBypassableErr = ""
30    strBypassableErr = ""

      Dim intLen As String
40    intLen = Len(PresentCondition)

50    If intLen = 0 Then
60        Call AppendBypassableErrorMessage(strBypassableErr, 43)
70        GoTo Return_label
80    End If

90    If DCount("*", "tblPresentCondition", "PresentCondition = '" & PresentCondition & "'") = 0 Then
100       Call AppendBypassableErrorMessage(strBypassableErr, 44)
110       GoTo Return_label
120   End If

Return_label:
130       IsPresentConditionValid = (strNotBypassableErr = "") And (strBypassableErr = "")

      'DD Error Handler Start
Exit_label:
140        Exit Function
Err_label:
150        Select Case Err.Number
           Case Else
160             Call LogError("basValidations", "IsPresentConditionValid")
170        End Select
180        Resume Exit_label
      'DD Error Handler End

End Function

' Bypassable errors
' 45 = How Obtained Code is required
' 46 = How Obtained Code is unknown

' ---------------------------------------------------------------------------
' IsHowObtainedCodeValid
'
' Assumptions:
'   HowObtainedCode has been trimmed
' ---------------------------------------------------------------------------

Public Function IsHowObtainedCodeValid( _
    ByVal HowObtainedCode As String, _
    ByRef strNotBypassableErr As String, _
    ByRef strBypassableErr As String) As Boolean
          
10    On Error GoTo Err_label

20    strNotBypassableErr = ""
30    strBypassableErr = ""

      Dim intLen As String
40    intLen = Len(HowObtainedCode)

50    If intLen = 0 Then
60        Call AppendBypassableErrorMessage(strBypassableErr, 45)
70        GoTo Return_label
80    End If

90    If DCount("*", "tblHowObtainedCode", "HowObtainedCode = '" & HowObtainedCode & "'") = 0 Then
100       Call AppendBypassableErrorMessage(strBypassableErr, 46)
110       GoTo Return_label
120   End If

Return_label:
130       IsHowObtainedCodeValid = (strNotBypassableErr = "") And (strBypassableErr = "")

      'DD Error Handler Start
Exit_label:
140        Exit Function
Err_label:
150        Select Case Err.Number
           Case Else
160             Call LogError("basValidations", "IsHowObtainedCodeValid")
170        End Select
180        Resume Exit_label
      'DD Error Handler End

End Function

' Bypassable errors
' 47 = Weight must be > 0
' 56 - Weight out of range

' ---------------------------------------------------------------------------
' IsBandsTableWeightValid
'
' Validate tblCaptures.Weight
'
' N.B. tblCaptures.Weight is a Double
' ---------------------------------------------------------------------------

Public Function IsBandsTableWeightValid( _
    ByVal Weight As Double, _
    ByRef strNotBypassableErr As String, _
    ByRef strBypassableErr As String, _
    ByRef Species As String, _
    ByRef Sex As String _
    ) As Boolean
          
10    On Error GoTo Err_label

20    strNotBypassableErr = ""
30    strBypassableErr = ""

40    If Weight = 0 Then
50        Call AppendBypassableErrorMessage(strBypassableErr, 28)
60        GoTo Return_label
70    End If

80    If Weight < 0 Then
90        Call AppendBypassableErrorMessage(strBypassableErr, 47)
100       GoTo Return_label
110   End If

120   If Species <> "" Then
          Dim WeightMaxMale As Integer
          Dim WeightMinMale As Integer
          Dim WeightMaxFemale As Integer
          Dim WeightMinFemale As Integer
          Dim WeightMin As Integer
          Dim WeightMax As Integer
          Dim WeightValidate As Boolean
          
130       WeightValidate = Nz(DLookup("WeightValidate", "tblSpecies", "Species = '" & Species & "'"), False)
140       If WeightValidate Then
          
150           WeightMaxMale = Nz(DLookup("WeightMaxMale", "tblSpecies", "Species = '" & Species & "'"), 0)
160           WeightMaxFemale = Nz(DLookup("WeightMaxFemale", "tblSpecies", "Species = '" & Species & "'"), 0)
170           WeightMinMale = Nz(DLookup("WeightMinMale", "tblSpecies", "Species = '" & Species & "'"), 0)
180           WeightMinFemale = Nz(DLookup("WeightMinFemale", "tblSpecies", "Species = '" & Species & "'"), 0)
190           Select Case Sex
              Case "", "0" ' unknown or invalid
200               If WeightMinMale = 0 Then
210                   WeightMin = WeightMinFemale
220               ElseIf WeightMinFemale = 0 Then
230                   WeightMin = WeightMinMale
240               Else
250                   WeightMin = IIf(WeightMinMale < WeightMinFemale, WeightMinMale, WeightMinFemale)
260               End If
270               If WeightMaxMale = 0 Then
280                   WeightMax = WeightMaxFemale
290               ElseIf WeightMaxFemale = 0 Then
300                   WeightMax = WeightMaxMale
310               Else
320                   WeightMax = IIf(WeightMaxMale > WeightMaxFemale, WeightMaxMale, WeightMaxFemale)
330               End If
340           Case "4" ' Male
350               WeightMax = WeightMaxMale
360               WeightMin = WeightMinMale
370           Case "5" ' Female
380               WeightMax = WeightMaxFemale
390               WeightMin = WeightMinFemale
400           End Select
410           If WeightMin <> 0 Then
420               If CInt(Weight) < WeightMin Then
430                   Call AppendBypassableErrorMessage(strBypassableErr, 56, CStr(WeightMin))
440                   GoTo Return_label
450               End If
460           End If
470           If WeightMax <> 0 Then
480               If CInt(Weight) > WeightMax Then
490                   Call AppendBypassableErrorMessage(strBypassableErr, 58, CStr(WeightMax))
500                   GoTo Return_label
510               End If
520           End If
530       End If
540   End If

Return_label:
550       IsBandsTableWeightValid = (strNotBypassableErr = "") And (strBypassableErr = "")

      'DD Error Handler Start
Exit_label:
560        Exit Function
Err_label:
570        Select Case Err.Number
           Case Else
580             Call LogError("basValidations", "IsBandsTableWeightValid")
590        End Select
600        Resume Exit_label
      'DD Error Handler End

End Function

' Bypassable errors
' 48 = Wing must be > 0
' 55 = Wing Chord out of range

' ---------------------------------------------------------------------------
' IsBandsTableWingChordValid
'
' Validate tblCaptures.WingChord
'    WingChord > 0 (implies Required)
' ---------------------------------------------------------------------------

Public Function IsBandsTableWingChordValid( _
    ByVal WingChord As Long, _
    ByRef strNotBypassableErr As String, _
    ByRef strBypassableErr As String, _
    ByRef Species As String, _
    ByRef Sex As String _
    ) As Boolean
          
10    On Error GoTo Err_label

20    strNotBypassableErr = ""
30    strBypassableErr = ""

40    If WingChord <= 0 Then
50        Call AppendBypassableErrorMessage(strBypassableErr, 48)
60        GoTo Return_label
70    End If

80    If Species <> "" Then
          Dim WingMaxMale As Integer
          Dim WingMinMale As Integer
          Dim WingMaxFemale As Integer
          Dim WingMinFemale As Integer
          Dim WingMin As Integer
          Dim WingMax As Integer
          Dim WingValidate As Boolean
          
90        WingValidate = Nz(DLookup("WingValidate", "tblSpecies", "Species = '" & Species & "'"), False)
100       If WingValidate Then
          
110           WingMaxMale = Nz(DLookup("WingMaxMale", "tblSpecies", "Species = '" & Species & "'"), 0)
120           WingMaxFemale = Nz(DLookup("WingMaxFemale", "tblSpecies", "Species = '" & Species & "'"), 0)
130           WingMinMale = Nz(DLookup("WingMinMale", "tblSpecies", "Species = '" & Species & "'"), 0)
140           WingMinFemale = Nz(DLookup("WingMinFemale", "tblSpecies", "Species = '" & Species & "'"), 0)
150           Select Case Sex
              Case "", "0" ' unknown or invalid
160               If WingMinMale = 0 Then
170                   WingMin = WingMinFemale
180               ElseIf WingMinFemale = 0 Then
190                   WingMin = WingMinMale
200               Else
210                   WingMin = IIf(WingMinMale < WingMinFemale, WingMinMale, WingMinFemale)
220               End If
230               If WingMaxMale = 0 Then
240                   WingMax = WingMaxFemale
250               ElseIf WingMaxFemale = 0 Then
260                   WingMax = WingMaxMale
270               Else
280                   WingMax = IIf(WingMaxMale > WingMaxFemale, WingMaxMale, WingMaxFemale)
290               End If
300           Case "4" ' Male
310               WingMax = WingMaxMale
320               WingMin = WingMinMale
330           Case "5" ' Female
340               WingMax = WingMaxFemale
350               WingMin = WingMinFemale
360           End Select
              
370           If WingMin <> 0 Then
380               If CInt(WingChord) < WingMin Then
390                   Call AppendBypassableErrorMessage(strBypassableErr, 55, CStr(WingMin))
400                   GoTo Return_label
410               End If
420           End If
430           If WingMax <> 0 Then
440               If CInt(WingChord) > WingMax Then
450                   Call AppendBypassableErrorMessage(strBypassableErr, 57, CStr(WingMax))
460                   GoTo Return_label
470               End If
480           End If
490       End If
500   End If

Return_label:
510       IsBandsTableWingChordValid = (strNotBypassableErr = "") And (strBypassableErr = "")

      'DD Error Handler Start
Exit_label:
520        Exit Function
Err_label:
530        Select Case Err.Number
           Case Else
540             Call LogError("basValidations", "IsBandsTableWingChordValid")
550        End Select
560        Resume Exit_label
      'DD Error Handler End

End Function

' ---------------------------------------------------------------------------
' IsCapturesTableCaptureDateValid
'
' Validate tblCaptures.CaptureDate
'   Not required for Dispositions 4 8
'   Required for  Dispositions 1 5 R F
' ---------------------------------------------------------------------------

Public Function IsCapturesTableCaptureDateValid( _
   ByVal DateEx As Date, _
    ByRef strNotBypassableErr As String, _
    ByVal strDisposition As String) As Boolean
          
10    On Error GoTo Err_label

20    strNotBypassableErr = ""

30    Select Case strDisposition
      Case "4", "8"
40    Case Else
50        If DateEx = 0 Then
60            strNotBypassableErr = "Date is required"
70            GoTo Return_label
80        End If
90    End Select

Return_label:
100       IsCapturesTableCaptureDateValid = (strNotBypassableErr = "")

      'DD Error Handler Start
Exit_label:
110        Exit Function
Err_label:
120        Select Case Err.Number
           Case Else
130             Call LogError("basValidations", "IsCapturesTableCaptureDateValid")
140        End Select
150        Resume Exit_label
      'DD Error Handler End

End Function

' Bypassable errors
' 50 = Time is required (format hh:mm)

' ---------------------------------------------------------------------------
' IsBandsTableWeightTimeValid
'
' Validate tblCaptures.WeightTime
'    Required
' ---------------------------------------------------------------------------

Public Function IsBandsTableWeightTimeValid( _
    ByVal WeightTime As Date, _
    ByRef strNotBypassableErr As String, _
    ByRef strBypassableErr As String) As Boolean
          
10    On Error GoTo Err_label

20    strNotBypassableErr = ""
30    strBypassableErr = ""

40    If WeightTime = 0 Then
50        Call AppendBypassableErrorMessage(strBypassableErr, 50)
60        GoTo Return_label
70    End If

Return_label:
80        IsBandsTableWeightTimeValid = (strNotBypassableErr = "") And (strBypassableErr = "")

      'DD Error Handler Start
Exit_label:
90         Exit Function
Err_label:
100        Select Case Err.Number
           Case Else
110             Call LogError("basValidations", "IsBandsTableWeightTimeValid")
120        End Select
130        Resume Exit_label
      'DD Error Handler End

End Function

' ---------------------------------------------------------------------------
' IsNewBandDuplicate( ByVal BandPrefix as String, ByVal BandSuffix as String) as string
'
' Validate if there is a stored "new band" record for a given band number
' ---------------------------------------------------------------------------

Public Function IsNewBandDuplicate(ByVal BandPrefix As String, ByVal BandSuffix As String) As String

10    On Error GoTo Err_label

      Dim strErr As String
      Dim strCriteria As String

20    strErr = ""

30    strCriteria = "BandPrefix = '" & BandPrefix & "' AND " & _
          "BandSuffix = '" & BandSuffix & "' AND " & _
          "NOT (Disposition = 'R' OR Disposition = 'F')"
40    If DCount("*", "tblCaptures", strCriteria) <> 0 Then
50        strErr = "The band " & BandPrefix & "-" & BandSuffix & " already exists" & vbCrLf
60        GoTo Return_label
70    End If

Return_label:
80        IsNewBandDuplicate = strErr

      'DD Error Handler Start
Exit_label:
90         Exit Function
Err_label:
100        Select Case Err.Number
           Case Else
110           Call LogError("basValidations", "IsNewBandDuplicate")
120        End Select
130        Resume Exit_label
      'DD Error Handler End

End Function

' Bypassable errors
' 51 = Aux Marker Code must be 1 to 7 characters (or blank)

'---------------------------------------------------------------------------------------
' IsAuxMarkerCodeValid
'---------------------------------------------------------------------------------------
 
Public Function IsAuxMarkerCodeValid( _
    ByVal AuxMarkerCode As String, _
    ByRef strNotBypassableErr As String, _
    ByRef strBypassableErr As String) As Boolean
          
10    On Error GoTo Err_label

20    strNotBypassableErr = ""
30    strBypassableErr = ""

40    If Len(Trim(AuxMarkerCode)) > 7 Then
50        Call AppendBypassableErrorMessage(strBypassableErr, 51)
60        GoTo Return_label
70    End If

Return_label:
80        IsAuxMarkerCodeValid = (strNotBypassableErr = "") And (strBypassableErr = "")

      'DD Error Handler Start
Exit_label:
90         Exit Function
Err_label:
100        Select Case Err.Number
           Case Else
110             Call LogError("basValidations", "IsAuxMarkerCodeValid")
120        End Select
130        Resume Exit_label
      'DD Error Handler End

End Function

' Bypassable errors
' 52 = Aux Marker Type is unknown

' ---------------------------------------------------------------------------
' IsAuxMarkerTypeValid
' ---------------------------------------------------------------------------

Public Function IsAuxMarkerTypeValid( _
    ByVal AuxMarkerType As String, _
    ByRef strNotBypassableErr As String, _
    ByRef strBypassableErr As String) As Boolean
          
10    On Error GoTo Err_label

20    strNotBypassableErr = ""
30    strBypassableErr = ""

40    If AuxMarkerType <> "" Then
50        If DCount("*", "tblAuxMarkerType", "AuxMarkerType = '" & AuxMarkerType & "'") = 0 Then
60            Call AppendBypassableErrorMessage(strBypassableErr, 52)
70            GoTo Return_label
80        End If
90    End If

Return_label:
100       IsAuxMarkerTypeValid = (strNotBypassableErr = "") And (strBypassableErr = "")

      'DD Error Handler Start
Exit_label:
110        Exit Function
Err_label:
120        Select Case Err.Number
           Case Else
130           Call LogError("basValidations", "IsAuxMarkerTypeValid")
140        End Select
150        Resume Exit_label
      'DD Error Handler End
End Function

' Bypassable errors
' 53 = Aux Marker Band Color is unknown

' ---------------------------------------------------------------------------
' IsAuxMarkerBandColorValid
' The argument is a string
' Null/0 has been converted to ""
'
' ---------------------------------------------------------------------------

Public Function IsAuxMarkerBandColorValid( _
    ByVal AuxMarkerBandColor As String, _
    ByRef strNotBypassableErr As String, _
    ByRef strBypassableErr As String) As Boolean
          
10    On Error GoTo Err_label

20    strNotBypassableErr = ""
30    strBypassableErr = ""

      Dim intLen As Integer
40    intLen = Len(AuxMarkerBandColor)

50    If intLen = 0 Then
60        IsAuxMarkerBandColorValid = True
70        Exit Function
80    End If

      Dim i As Integer
90    For i = 1 To intLen
100       If Mid(AuxMarkerBandColor, i, 1) < "0" Or Mid(AuxMarkerBandColor, i, 1) > "9" Then
110           strNotBypassableErr = strNotBypassableErr & "Aux Marker Band Color must be between 1 and 99, or blank" & vbCrLf
120           GoTo Return_label
130       End If
140   Next i

150   If CInt(AuxMarkerBandColor) < 1 Or CInt(AuxMarkerBandColor) > 99 Then
160       strNotBypassableErr = strNotBypassableErr & "Aux Marker Band Color must be between 1 and 99, or blank" & vbCrLf
170       GoTo Return_label
180   End If

190   If AuxMarkerBandColor <> "" Then
200       If DCount("*", "tblColor", "Color = " & CInt(AuxMarkerBandColor)) = 0 Then
210           Call AppendBypassableErrorMessage(strBypassableErr, 53)
220           GoTo Return_label
230       End If
240   End If

Return_label:
250       IsAuxMarkerBandColorValid = (strNotBypassableErr = "") And (strBypassableErr = "")

      'DD Error Handler Start
Exit_label:
260        Exit Function
Err_label:
270        Select Case Err.Number
           Case Else
280           Call LogError("basValidations", "IsAuxMarkerBandColorValid")
290        End Select
300        Resume Exit_label
      'DD Error Handler End
End Function

' Bypassable errors
' 54 = Aux Marker Code Color is unknown

' ---------------------------------------------------------------------------
' IsAuxMarkerBandColorValid
' ---------------------------------------------------------------------------

Public Function IsAuxMarkerCodeColorValid( _
    ByVal AuxMarkerCodeColor As String, _
    ByRef strNotBypassableErr As String, _
    ByRef strBypassableErr As String) As Boolean
          
10    On Error GoTo Err_label

20    strNotBypassableErr = ""
30    strBypassableErr = ""

      Dim intLen As Integer
40    intLen = Len(AuxMarkerCodeColor)

50    If intLen = 0 Then
60        IsAuxMarkerCodeColorValid = True
70        Exit Function
80    End If

      Dim i As Integer
90    For i = 1 To intLen
100       If Mid(AuxMarkerCodeColor, i, 1) < "0" Or Mid(AuxMarkerCodeColor, i, 1) > "9" Then
110           strNotBypassableErr = strNotBypassableErr & "Aux Marker Code Color must be between 1 and 99, or blank" & vbCrLf
120           GoTo Return_label
130       End If
140   Next i

150   If CInt(AuxMarkerCodeColor) < 1 Or CInt(AuxMarkerCodeColor) > 99 Then
160       strNotBypassableErr = strNotBypassableErr & "Aux Marker Code Color must be between 1 and 99, or blank" & vbCrLf
170       GoTo Return_label
180   End If

190   If AuxMarkerCodeColor <> "" Then
200       If DCount("*", "tblColor", "Color = " & CInt(AuxMarkerCodeColor)) = 0 Then
210           Call AppendBypassableErrorMessage(strBypassableErr, 54)
220           GoTo Return_label
230       End If
240   End If

Return_label:
250       IsAuxMarkerCodeColorValid = (strNotBypassableErr = "") And (strBypassableErr = "")

      'DD Error Handler Start
Exit_label:
260        Exit Function
Err_label:
270        Select Case Err.Number
           Case Else
280           Call LogError("basValidations", "IsAuxMarkerCodeColorValid")
290        End Select
300        Resume Exit_label
      'DD Error Handler End
End Function

' ---------------------------------------------------------------------------
' Is_IsAuxMarkerCodedValid
' ---------------------------------------------------------------------------

Public Function Is_IsAuxMarkerCodedValid( _
    ByVal IsAuxMarkerCoded As String, _
    ByRef strNotBypassableErr As String, _
    ByRef strBypassableErr As String) As Boolean
          
10    On Error GoTo Err_label

20    strNotBypassableErr = ""
30    strBypassableErr = ""

40    If Not (IsAuxMarkerCoded = "Y" Or IsAuxMarkerCoded = "N" Or IsAuxMarkerCoded = "") Then
50        strNotBypassableErr = strNotBypassableErr & "Is Aux Marker Coded must be Y, N or blank" & vbCrLf
60        GoTo Return_label
70    End If

Return_label:
80        Is_IsAuxMarkerCodedValid = (strNotBypassableErr = "") And (strBypassableErr = "")

      'DD Error Handler Start
Exit_label:
90         Exit Function
Err_label:
100        Select Case Err.Number
           Case Else
110           Call LogError("basValidations", "Is_IsAuxMarkerCodedValid")
120        End Select
130        Resume Exit_label
      'DD Error Handler End
End Function

'Public Function IsAgeConsistent2( _
'    ByVal Prefix As String, ByVal Suffix As String, _
'    ByVal Age As String, ByVal CaptureDate As Date) As Boolean
'        IsAgeConsistent2 = IsAgeConsistent(Prefix, Suffix, Age, Year(CaptureDate))
'    End Function


'---------------------------------------------------------------------------------------
' IsAgeConsistent
'
' PRE Prefix, Suffix, Age, YearEx are valid
' Invalid and Null Ages should already be replaced by Age_U
'---------------------------------------------------------------------------------------
 
Public Function IsAgeConsistent( _
    ByVal Prefix As String, ByVal Suffix As String, _
    ByVal strAge As String, ByVal YearEx As Integer, _
    Optional ByVal IDBand As Long = -1) As Boolean
          
10    On Error GoTo Err_label

      Const Age_U   As Integer = 0
      Const Age_AHY As Integer = 1
      Const Age_HY  As Integer = 2
      Const Age_L   As Integer = 4
      Const Age_SY  As Integer = 5
      Const Age_ASY As Integer = 6
      Const Age_TY  As Integer = 7
      Const Age_ATY As Integer = 8

      Dim Code(8) As Integer
20    Code(Age_L) = 0
30    Code(Age_HY) = 0
40    Code(Age_SY) = 1
50    Code(Age_TY) = 2
60    Code(Age_AHY) = 0
70    Code(Age_ASY) = 1
80    Code(Age_ATY) = 2

90    IsAgeConsistent = True

      Dim intAge As Integer
100   If IsNumeric(strAge) Then
110       intAge = CInt(strAge)
120   Else
130       intAge = Age_U
140   End If
150   If intAge < Age_U Or intAge > Age_ATY Then
160       intAge = Age_U
170   End If
180   If intAge = 3 Then intAge = Age_U

      ' Loop over all (other) capture records for the specified band number

      Dim strSQL As String
190   strSQL = _
          "SELECT * FROM tblCaptures " & _
          "WHERE [BandPrefix] = '" & Prefix & "' AND " & _
          "      [BandSuffix] = '" & Suffix & "' AND " & _
          "      [IDBand] <> " & IDBand
      Dim rst As DAO.Recordset
200   Set rst = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)

210   Do While Not rst.EOF
          Dim strAge2 As String
          Dim Year2 As Integer
          Dim DateEx As Date
          
220       strAge2 = Nz(rst("Age"), "0") ' Null => Age_U
          
          Dim intAge2 As Integer
230       If IsNumeric(strAge2) Then
240           intAge2 = CInt(strAge2)
250       Else
260           intAge2 = Age_U
270       End If
280       If intAge2 < Age_U Or intAge2 > Age_ATY Then
290           intAge2 = Age_U
300       End If
310       If intAge2 = 3 Then intAge2 = Age_U
              
320       DateEx = Nz(rst("CaptureDate"), 0)
330       If DateEx = 0 Then GoTo label_loop  ' Capture Date is Null
340       Year2 = Year(DateEx)
          
350       Select Case intAge
          Case Age_U
360           Select Case Year2 - YearEx
              Case 1
370               If intAge2 = Age_L Or intAge2 = Age_HY Then
380                   IsAgeConsistent = False
390                   Exit Do
400               End If
410           Case 2
420               If intAge2 = Age_L Or intAge2 = Age_HY Or intAge2 = Age_SY Then
430                   IsAgeConsistent = False
440                   Exit Do
450               End If
460           Case Is >= 3
470                If intAge2 = Age_L Or intAge2 = Age_HY Or intAge2 = Age_SY Or intAge2 = Age_TY Then
480                   IsAgeConsistent = False
490                   Exit Do
500               End If
510           End Select
520       Case Age_L, Age_HY, Age_SY, Age_TY
530           Select Case Code(intAge) + Year2 - YearEx
              Case Is <= -1
540               IsAgeConsistent = False
550               Exit Do
560           Case 0
570               If Not (intAge2 = Age_U Or intAge2 = Age_L Or intAge2 = Age_HY) Then
580                 IsAgeConsistent = False
590                  Exit Do
600               End If
610           Case 1
620               If Not (intAge2 = Age_U Or intAge2 = Age_SY Or intAge2 = Age_AHY) Then
630                 IsAgeConsistent = False
640                  Exit Do
650               End If
660           Case 2:
670               If Not (intAge2 = Age_U Or intAge2 = Age_TY Or intAge2 = Age_AHY Or intAge2 = Age_ASY) Then
680                 IsAgeConsistent = False
690                  Exit Do
700               End If
710           Case Is >= 3:
720              If Not (intAge2 = Age_U Or intAge2 = Age_AHY Or intAge2 = Age_ASY Or intAge2 = Age_ATY) Then
730                   IsAgeConsistent = False
740                   Exit Do
750               End If
760           End Select
770       Case Age_AHY, Age_ASY, Age_ATY:
780           Select Case (Code(intAge) + Year2 - YearEx)
              Case 0:
790               If intAge2 = Age_L Or intAge2 = Age_HY Then
800                   IsAgeConsistent = False
810                   Exit Do
820               End If
830           Case 1:
840               If intAge2 = Age_L Or intAge2 = Age_HY Or intAge2 = Age_SY Then
850                   IsAgeConsistent = False
860                   Exit Do
870               End If
880           Case Is >= 2:
890               If intAge2 = Age_L Or intAge2 = Age_HY Or intAge2 = Age_SY Or intAge2 = Age_TY Then
900                   IsAgeConsistent = False
910                   Exit Do
920               End If
930           End Select
940       End Select

label_loop:
950       rst.MoveNext
960   Loop
970   rst.Close

      'DD Error Handler Start
Exit_label:
980        Exit Function
Err_label:
990        Select Case Err.Number
           Case Else
1000            Call LogError("basValidations", "IsAgeConsistent")
1010       End Select
1020       Resume Exit_label
      'DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' IsSexConsistent
'---------------------------------------------------------------------------------------
 
Public Function IsSexConsistent( _
    ByVal Prefix As String, ByVal Suffix As String, _
    ByVal strSex As String, ByVal IDBand As Long) As Boolean
         
10    On Error GoTo Err_label

      Const Sex_U As String = "0"
      Const Sex_M As String = "4"
      Const Sex_F As String = "5"

20    IsSexConsistent = True

30    If strSex <> Sex_M And strSex <> Sex_F Then
40        strSex = Sex_U
50    End If

      ' Loop over all (other) capture records for the specified band number

      Dim strSQL As String
60    strSQL = _
          "SELECT * FROM tblCaptures " & _
          "WHERE [BandPrefix] = '" & Prefix & "' AND " & _
          "      [BandSuffix] = '" & Suffix & "' AND " & _
          "      [IDBand] <> " & IDBand
      Dim rst As DAO.Recordset
70    Set rst = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)

80    Do While Not rst.EOF
          Dim strSex2 As String
        
90        strSex2 = Nz(rst("Sex"), Sex_U) ' Null => Sex_U
          
100       If strSex2 <> Sex_M And strSex2 <> Sex_F Then
110           strSex2 = Sex_U
120       End If
                     
130       Select Case strSex
          Case Sex_U

140       Case Sex_M
150           If strSex2 = Sex_F Then
160               IsSexConsistent = False
170               Exit Do
180           End If
190       Case Sex_F
200           If strSex2 = Sex_M Then
210               IsSexConsistent = False
220               Exit Do
230           End If
240       End Select

label_loop:
250       rst.MoveNext
260   Loop
270   rst.Close

      'DD Error Handler Start
Exit_label:
280        Exit Function
Err_label:
290        Select Case Err.Number
           Case Else
300             Call LogError("basValidations", "IsSexConsistent")
310        End Select
320        Resume Exit_label
      'DD Error Handler End
          
End Function

'---------------------------------------------------------------------------------------
' IsSpeciesConsistent
'---------------------------------------------------------------------------------------
 
Public Function IsSpeciesConsistent( _
    ByVal Prefix As String, ByVal Suffix As String, _
    ByVal strSpecies As String, ByVal IDBand As Long) As Boolean
         
10    On Error GoTo Err_label

20    IsSpeciesConsistent = True

      ' Loop over all (other) capture records for the specified band number

      Dim strSQL As String
30    strSQL = _
          "SELECT * FROM tblCaptures " & _
          "WHERE [BandPrefix] = '" & Prefix & "' AND " & _
          "      [BandSuffix] = '" & Suffix & "' AND " & _
          "      [IDBand] <> " & IDBand
      Dim rst As DAO.Recordset
40    Set rst = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)

50    Do While Not rst.EOF
          Dim strSpecies2 As String
        
60        strSpecies2 = Nz(rst("Species"), "")
          
70        If strSpecies <> "" And strSpecies2 <> "" And strSpecies <> strSpecies2 Then
80            IsSpeciesConsistent = False
90            Exit Do
100       End If
                     
label_loop:
110       rst.MoveNext
120   Loop
130   rst.Close

      'DD Error Handler Start
Exit_label:
140        Exit Function
Err_label:
150        Select Case Err.Number
           Case Else
160             Call LogError("basValidations", "IsSpeciesConsistent")
170        End Select
180        Resume Exit_label
      'DD Error Handler End
          
End Function


'---------------------------------------------------------------------------------------
' SexToString
'---------------------------------------------------------------------------------------

Public Function SexToString(ByVal Sex As Integer) As String

    Const Sex_U As Integer = 0
    Const Sex_M As Integer = 4
    Const Sex_F As Integer = 5
    Const Sex_6 As Integer = 6
    Const Sex_7 As Integer = 7
    
   On Error GoTo Err_label

20      Select Case Sex
      Case Sex_U:
30        SexToString = "U"
40    Case Sex_M:
50        SexToString = "M"
60    Case Sex_F:
70        SexToString = "F"
80    Case Sex_6:
90        SexToString = "6"
100   Case Sex_7:
110       SexToString = "7"
180   End Select

    'DD Error Handler Start
Exit_label:
    Exit Function
Err_label:
    Select Case Err.Number
    Case Else
         Call LogError("basValidations", "SexToString")
    End Select
    Resume Exit_label
    ' DD Error Handler End

End Function




Public Function AgeToString(ByVal Age As Integer) As String

      Const Age_U   As Integer = 0
      Const Age_AHY As Integer = 1
      Const Age_HY  As Integer = 2
      Const Age_L   As Integer = 4
      Const Age_SY  As Integer = 5
      Const Age_ASY As Integer = 6
      Const Age_TY  As Integer = 7
      Const Age_ATY As Integer = 8

10    On Error GoTo Err_label

20    Select Case Age
      Case Age_U:
30        AgeToString = "U"
40    Case Age_L:
50        AgeToString = "L"
60    Case Age_HY:
70        AgeToString = "HY"
80    Case Age_SY:
90        AgeToString = "SY"
100   Case Age_TY:
110       AgeToString = "TY"
120   Case Age_AHY:
130       AgeToString = "AHY"
140   Case Age_ASY:
150       AgeToString = "ASY"
160   Case Age_ATY:
170       AgeToString = "ATY"
180   End Select


      'DD Error Handler Start
Exit_label:
190        Exit Function
Err_label:
200        Select Case Err.Number
           Case Else
210       Call LogError("basValidations", "AgeToString")
220        End Select
230        Resume Exit_label
      'DD Error Handler End

End Function

' ============================= tblCapturesEditOrDelete ============================================

' Bypassable errors
' 62 = Weight Time is required

' ---------------------------------------------------------------------------
' IsWeightTimeValidEx
'
' Validate tblCaptures.WeightTime
'    Required
' ---------------------------------------------------------------------------

Public Function IsWeightTimeValidEx( _
    ByVal WeightTime As Variant, _
    ByRef strNotBypassableErr As String, _
    ByRef strBypassableErr As String) As Boolean
          
10    On Error GoTo Err_label

20    strNotBypassableErr = ""
30    strBypassableErr = ""

40    If IsNull(WeightTime) Then
50        Call AppendBypassableErrorMessage(strBypassableErr, 62)
60        GoTo Return_label
70    End If

Return_label:
80        IsWeightTimeValidEx = (strNotBypassableErr = "") And (strBypassableErr = "")

      'DD Error Handler Start
Exit_label:
90         Exit Function
Err_label:
100        Select Case Err.Number
           Case Else
110             Call LogError("basValidations", "IsBandsTableWeightTimeValid")
120        End Select
130        Resume Exit_label
      'DD Error Handler End

End Function


'---------------------------------------------------------------------------------------
' IsDayMonthYearValid
'
' Day, Month and Year are integers
'---------------------------------------------------------------------------------------

Public Function IsYearMonthDayValid(intYear As Integer, intMonth As Integer, intDay As Integer) As Boolean

10       On Error GoTo Err_label

Dim datDate As Date

20        If intYear < 1900 Or intYear >= 3000 Then
30            IsYearMonthDayValid = False
40            GoTo Exit_label
50        End If
          
60        If intMonth < 1 Or intMonth > 12 Then
70            IsYearMonthDayValid = False
80            GoTo Exit_label
90        End If
          
100       If intDay < 1 Or intDay > 31 Then
110           IsYearMonthDayValid = False
120           GoTo Exit_label
130       End If
          
140       datDate = DateSerial(intYear, intMonth, intDay)
150       IsYearMonthDayValid = (Year(datDate) = intYear) And (Month(datDate) = intMonth) And (Day(datDate) = intDay)
    
          'DD Error Handler Start
Exit_label:
160       Exit Function
Err_label:
170       Select Case Err.Number
          Case Else
180            Call LogError("basValidations", "IsDayMonthYearValid")
190       End Select
200       Resume Exit_label
          ' DD Error Handler End
End Function
