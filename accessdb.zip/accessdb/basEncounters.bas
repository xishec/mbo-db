'Option Compare Database
'Option Explicit
'

Public Sub EncountersExport()

10    On Error GoTo Err_label

      Dim strExportFolder As String
      Dim strFilename As String
      Dim strFilepath As String
      Dim strFolderpath As String

20    strExportFolder = GetExportFolder()

30    strFilename = Format(Now, "yyyy-mm-dd hh\hnn") & _
          " Foreign Bands " & _
          ".xls"

40    strFilepath = TrailingSlash(strExportFolder) & strFilename

50    strFilepath = FileSaveDialogExcel(strFilename, strExportFolder, "")

60    If strFilepath <> "" Then
70        strFolderpath = FolderFromPath(strFilepath)
80        Call PutExportFolder(strFolderpath)


' qryEncountersExport_BandedByMBO
' -------------------------------------------------------
' tblEncounters x tblCaptures x tblSpecies x tblLocations
'
' WHERE BANDED_BY_MBO = True
' WHERE Disposition IN ("1","5")
'
'SELECT tblCaptures.Age AS B_AGE_CODE, tblCaptures.HowAged AS B_HOW_AGED_CODE, tblCaptures.Sex AS B_SEX_CODE,
'tblCaptures.HowSexed AS B_HOW_SEXED_CODE, tblCaptures.Species AS B_SPECIES, tblSpecies.AOSCode AS B_SPECIES_ID,
'tblSpecies.SpeciesDescriptionMBO AS B_SPECIES_NAME, [B_BAND_PREFIX] & "-" & [B_BAND_SUFFIX] AS B_BAND,
'tblCaptures.CaptureDate AS BANDING_DATE, Day([CaptureDate]) AS BANDING_DAY, Month([CaptureDate]) AS BANDING_MONTH, Year([CaptureDate]) AS BANDING_YEAR,
'tblCaptures.BirdStatus AS B_BIRD_STATUS, tblCaptures.Location AS B_LOCATION,
'[LocationDescription] & " " & [PlaceName] & " " & [State] & " " & [Country] AS B_LOCATION_DESCRIPTION,
' tblLocations.Region AS B_REGION,
'tblEncounters.B_COMMENTS, tblLocations.CoordPrecision AS B_COORD_PRECISION, tblLocations.DirectionCode AS B_DIRECTION_CODE,
'tblEncounters.B_EXTRA_INFO_CODE,
'tblLocations.FlywayCode AS B_FLYWAY_CODE, tblLocations.Lat10MinBlock AS B_LAT_10_MIN_BLK, tblLocations.LatDecimalDegrees AS B_LAT_DECIMAL_DEGREES,
'tblLocations.Long10MinBlock AS B_LON_10_MIN_BLK, tblLocations.L
'ongDecimalDegrees AS B_LON_DECIMAL_DEGREES, tblEncounters.B_PERMIT_NUM, "" AS B_AUX_MARKER,
'EncounterMarkerLongDesc([D3],[D5],[D6],[D7],[D8],[D9],[D10]) AS B_MARKER_LONG_DESC, tblEncounters.B_REMARKS,
'tblEncounters.BEARING , tblEncounters.DISTANCE, tblEncounters.DAYS,
'tblEncounters.E_AGE_CODE, tblEncouters.E_SEX_CODE,
'tblEncounters.E_SPECIES, tblEncounters.E_SPECIES_NAME,
'tblEncounters.ENCOUNTER_DATE, tblEncounters.ENCOUNTER_DAY, tblEncounters.ENCOUNTER_MONTH, tblEncounters.ENCOUNTER_YEAR,
'tblEncounters.E_PRESENT_CONDITION_CODE , tblEncounters.E_LOCATION, tblEncounters.E_LOCATION_DESCRIPTION, tblEncounters.E_COUNTRY_CODE,
'tblEncounters.E_STATE_CODE , tblEncounters.E_REGION, tblEncounters.E_PLACE_NAME, tblEncounters.E_COMMENTS, tblEncounters.E_COORD_PRECISION,
'tblEncounters.E_COUNTY_CODE, tblEncounters.E_DIRECTION_CODE, tblEncounters.E_ENC_COUNTY_ORIGINAL, tblEncounters.E_FLYWAY_CODE,
'tblEncounters.E_HOW_OBTAINED_CODE, tblEncounters.E_HOW_OBTAINED_DESC, tblEncounters.E_WHO_OBTAINED_CODE, tblEncounters.E_WHY_REPORTED_CODE,
'tblEncounters.E_LAT_10_MIN_BLK, tblEncounters.E_LAT_DECIMAL_DEGREES, tblEncounters.E_LON_10_MIN_BLK, tblEncounters.E_LON_DECIMAL_DEGREES,
'tblEncounters.E_PERMIT_NUM, tblEncounters.HSS, tblEncounters.[MIN AGE AT ENC], tblEncounters.ORIGINAL_BAND, tblEncounters.OTHER_BANDS,
'tblEncounters.REC_SOURCE, tblEncounters.SAME_10_MIN_BLOCK, tblEncounters.[WAS STATUS CHANGED], tblEncounters.E_AUX_MARKER, tblEncounters.E_AUX_MARKER_CODE,
'tblEncounters.E_MARKER_CODE_COLOR_ID, tblEncounters.E_MARKER_COLOR_ID, tblEncounters.E_MARKER_DESC, tblEncounters.E_MARKER_LONG_DESC, tblEncounters.E_MARKER_REF_ID,
'tblEncounters.E_REMARKS, tblEncounters.ENC_ERROR, tblCaptures.NotesForMBO AS NOTES_BY_MBO_AT_BANDING


90        DoCmd.TransferSpreadsheet acExport, acSpreadsheetTypeExcel8, "qryEncountersExport_BandedByMBO", strFilepath, True, "Birds banded at MBO"

' qryEncounter_Alien_AllSites_A
' -----------------------------
' List of the BandPrefix, BandSufffix, CaptureDate of the first "F" capture record at any "By MBO" site
' tblCaptures
'
' WHERE Disposition = "F"
' GROUP BY BandPrefix, BandSuffix
' MIN CaptureDate

' qryEncounter_Alien_AllSites_B
' -----------------------------
' The tblCapture records for first "F" captures at any "By MBO" site
'
' qryEncounter_Alien_AllSites_A x tblCaptures      --- for some reason this only works if I make it an OUTER LEFT JOIN ---
'
' tblCaptures.*
'

' qryEncountersExport_EncounteredByMBO
' -------------------------------------------------------------------------
' tblEncounters x qryEncounter_Alien_AllSites_B x tblSpecies x tblLocations
'
' WHERE BANDED_BY_MBO = False
'
'SELECT tblEncounters.B_AGE_CODE, tblEncounters.B_HOW_AGED_CODE, tblEncounters.B_SEX_CODE, tblEncounters.B_HOW_SEXED_CODE,
'tblEncounters.B_SPECIES, tblEncounters.B_SPECIES_ID, tblEncounters.B_SPECIES_NAME, [B_BAND_PREFIX] & "-" & [B_BAND_SUFFIX] AS B_BAND,
'DateSerialEx(Nz([BANDING_YEAR]),Nz([BANDING_MONTH]),Nz([BANDING_DAY])) AS BANDING_DATE, tblEncounters.BANDING_DAY, tblEncounters.BANDING_MONTH,
'tblEncounters.BANDING_YEAR, tblEncounters.B_BIRD_STATUS, tblEncounters.B_LOCATION, tblEncounters.B_LOCATION_DESCRIPTION, tblEncounters.B_REGION,
'tblEncounters.B_COMMENTS, tblEncounters.B_COORD_PRECISION, tblEncounters.B_DIRECTION_CODE, tblEncounters.B_EXTRA_INFO_CODE,
'tblEncounters.B_FLYWAY_CODE, tblEncounters.B_LAT_10_MIN_BLK, tblEncounters.B_LAT_DECIMAL_DEGREES, tblEncounters.B_LON_10_MIN_BLK,
'tblEncounters.B_LON_DECIMAL_DEGREES, tblEncounters.B_PERMIT_NUM, tblEncounters.B_AUX_MARKER, tblEncounters.B_MARKER_LONG_DESC,
'tblEncounters.B_REMARKS , tblEncounters.BEARING, tblEncounters.DISTANCE, tblEncounters.DAYS,
'qryEncounter_Alien_AllSites_B.[Age] AS E_AGE_CODE,
'qryEncounter_Alien_AllSites_B.[Sex] AS E_SEX_CODE,
'qryEncounter_Alien_AllSites_B.[Species] AS E_SPECIES, tblSpecies.[SpeciesDescriptionMBO] AS E_SPECIES_NAME,
'qryEncounter_Alien_AllSites_B.[Capturedate] AS ENCOUNTER_DATE, Day([CaptureDate]) AS ENCOUNTER_DAY, Month([CaptureDate]) AS ENCOUNTER_MONTH,
'Year([CaptureDate]) AS ENCOUNTER_YEAR,
'qryEncounter_Alien_AllSites_B.[PresentCondition] AS E_PRESENT_CONDITION_CODE, qryEncounter_Alien_AllSites_B.[Location] AS E_LOCATION,
'tblLocations.[CountryCode] AS E_COUNTRY_CODE,
'tblLocations.[StateCode] AS E_STATE_CODE, tblLocations.[Region] AS E_REGION, tblLocations.[PlaceName] AS E_PLACE_NAME, tblEncounters.E_COMMENTS,
'tblLocations.[CoordPrecision] AS E_COORD_PRECISION, tblLocations.[CountyCode] AS E_COUNTY_CODE, tblLocations.[DirectionCode] AS E_DIRECTION_CODE,
'tblEncounters.E_ENC_COUNTY_ORIGINAL, tblLocations.[FlywayCode] AS E_FLYWAY_CODE, qryEncounter_Alien_AllSites_B.[HowObtainedCode] AS E_HOW_OBTAINED_CODE,
'tblEncounters.E_HOW_OBTAINED_DESC, tblEncounters.E_WHO_OBTAINED_CODE, tblEncounters.E_WHY_REPORTED_CODE,
'tblLocations.[Lat10MinBlock] AS E_LAT_10_MIN_BLK, tblLocations.[LatDecimalDegrees] AS E_LAT_DECIMAL_DEGREES, tblLocations.[Long10MinBlock] AS E_LON_10_MIN_BLK,
'tblLocations.[LongDecimalDegrees] AS E_LON_DECIMAL_DEGREES,
'tblEncounters.E_PERMIT_NUM, tblEncounters.HSS,
'tblEncounters.[MIN AGE AT ENC],
'tblEncounters.ORIGINAL_BAND, tblEncounters.OTHER_BANDS, tblEncounters.REC_SOURCE, tblEncounters.SAME_10_MIN_BLOCK,
'tblEncounters.[WAS STATUS CHANGED], Null AS E_AUX_MARKER, qryEncounter_Alien_AllSites_B.[D5] AS E_AUX_MARKER_CODE,
'qryEncounter_Alien_AllSites_B.[D7] AS E_MARKER_CODE_COLOR_ID, qryEncounter_Alien_AllSites_B.[D6] AS E_MARKER_COLOR_ID, Null AS E_MARKER_DESC,
'EncounterMarkerLongDesc([D3],[D5],[D6],[D7],[D8],[D9],[D10]) AS E_MARKER_LONG_DESC, Null AS E_MARKER_REF_ID, tblEncounters.E_REMARKS,
'tblEncounters.ENC_ERROR, qryEncounter_Alien_AllSites_B.[Age] AS E_AGE_CODE, qryEncounter_Alien_AllSites_B.[Sex] AS E_SEX_CODE,
'qryEncounter_Alien_AllSites_B.NotesForMBO AS NOTES_BY_MBO_AT_ENCOUNTER


100       DoCmd.TransferSpreadsheet acExport, acSpreadsheetTypeExcel8, "qryEncountersExport_EncounteredByMBO", strFilepath, True, "Birds captured at MBO"
110   End If

      ' Open the Excel workbook
      ' For some reason, Excel has to be visible - I don't care

      Dim oExcel As Excel.Application
      Dim oBook As Excel.Workbook
      Dim oSheet As Excel.Worksheet

120   Set oExcel = New Excel.Application
130   oExcel.Visible = True

140   On Error Resume Next
150   Set oBook = oExcel.Workbooks.Open(strFilepath)
160   If Err.Number <> 0 Then
170       oExcel.Quit
180       Set oExcel = Nothing
190       GoTo Exit_label
200   End If

      ' Open the "Birds banded at MBO" worksheet

      Dim intSheet As Integer
      Dim fSheetExists As Boolean

210   fSheetExists = False
220   For intSheet = 1 To oBook.Sheets.count
230       If oBook.Sheets(intSheet).Name = "Birds_banded_at_MBO" Then
240           Set oSheet = oBook.Sheets(intSheet)
250           fSheetExists = True
260           Exit For
270       End If
280   Next

290   If Not fSheetExists Then
300       oExcel.Quit
310       Set oExcel = Nothing
320       GoTo Exit_label
330   End If


340   With oSheet

350      .Activate

          ' How many rows and columns
          
          Dim rowLast As Long
          Dim colLast As Long
          Dim strHeader As String
          
360       rowLast = oSheet.UsedRange.Rows.count
370       colLast = oSheet.UsedRange.columns.count
          
380       oSheet.range(.columns(1), .columns(colLast)).AutoFit

          Dim col As Long
          
390       For col = 1 To colLast
400           strHeader = oSheet.Cells(1, col)
              
410           Select Case strHeader
              Case "BANDING_DATE", "ENCOUNTER_DATE"
420               oSheet.columns(col).NumberFormat = "dd mmm yyyy"
430           End Select
              
440           Select Case strHeader
              Case "B_AGE_CODE", "B_SEX_CODE", "B_SPECIES", "B_SPECIES_NAME", "B_BAND", "BANDING_DATE", "BANDING_YEAR", "BEARING", _
                    "DISTANCE", "DAYS", "E_SPECIES", "E_SPECIES_NAME", "ENC_DATE", "ENCOUNTER_DAY", "ENCOUNTER_MONTH", "ENCOUNTER_YEAR", "E_PRESENT_CONDITION_CODE", "E_LOCATION_DESCRIPTION", "E_STATE_CODE", _
                    "E_PLACE_NAME", _
                    "E_HOW_OBTAINED_CODE", "E_WHO_OBTAINED_CODE", "E_WHY_REPORTED_CODE", "E_LAT_DECIMAL_DEGREES", "E_LON_DECIMAL_DEGREES", "MIN_AGE_AT_ENC", "E_REMARKS", "NOTES_BY_MBO_AT_BANDING"
450           Case Else
460               oSheet.columns(col).Hidden = True
470           End Select


480       Next
          
490       .range("I1").Select
500       oExcel.ActiveWindow.FreezePanes = True

510   End With

      ' Open the "Birds captured at MBO" worksheet
      '
      'Dim intSheet As Integer
      'Dim fSheetExists As Boolean

520   fSheetExists = False
530   For intSheet = 1 To oBook.Sheets.count
540       If oBook.Sheets(intSheet).Name = "Birds_captured_at_MBO" Then
550           Set oSheet = oBook.Sheets(intSheet)
560           fSheetExists = True
570           Exit For
580       End If
590   Next

600   If Not fSheetExists Then
610       oExcel.Quit
620       Set oExcel = Nothing
630       GoTo Exit_label
640   End If


650   With oSheet

660       .Activate

          ' How many rows and columns
          
      '    Dim rowLast As Long
      '    Dim colLast As Long
      '    Dim strHeader As String
          
670       rowLast = oSheet.UsedRange.Rows.count
680       colLast = oSheet.UsedRange.columns.count
          
690       oSheet.range(.columns(1), .columns(colLast)).AutoFit

      '    Dim col As Long
          
700       For col = 1 To colLast
710           strHeader = oSheet.Cells(1, col)
720           Select Case strHeader
              Case "BANDING_DATE", "ENCOUNTER_DATE"
730               oSheet.columns(col).NumberFormat = "dd mmm yyyy"
740           End Select
              
750           Select Case strHeader
              Case "B_AGE_CODE", "B_SEX_CODE", "B_SPECIES", "B_SPECIES_NAME", "B_BAND", "BANDING_DATE", "BANDING_DAY", "BANDING_MONTH", "BANDING_YEAR", "B_BIRD_STATUS", "B_LOCATION_DESCRIPTION", "B_REGION", _
                    "B_LAT_DECIMAL_DEGREES", "B_LON_DECIMAL_DEGREES", "B_PERMIT_NUM", _
                    "BEARING", "DISTANCE", "ENCOUNTER_DATE", "ENCOUNTER_YEAR", "HSS", "E_SPECIES", "E_LOCATION", "E_REMARKS", "NOTES_BY_MBO_AT_ENCOUNTER"
760           Case Else
770               oSheet.columns(col).Hidden = True
780           End Select
790       Next
          
800       .range("I1").Select
810       oExcel.ActiveWindow.FreezePanes = True

820   End With

830   oExcel.DisplayAlerts = False
840   oBook.Close saveChanges:=True, FileName:=strFilepath
850   oExcel.DisplayAlerts = True

860   oExcel.Quit
870   Set oSheet = Nothing
880   Set oBook = Nothing
890   Set oExcel = Nothing

          'DD Error Handler Start
Exit_label:
900       Exit Sub
Err_label:
910       Select Case Err.Number
          Case Else
920      Call LogError("Form_frmEncounters", "cmdExport_Click")
930       End Select
940       Resume Exit_label
          ' DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' EncounterMarkerLongDesc
'---------------------------------------------------------------------------------------

Public Function EncounterMarkerLongDesc(ByVal D3 As Variant, ByVal D5 As Variant, ByVal D6 As Variant, ByVal D7 As Variant, ByVal D8 As Variant, ByVal dD As Variant, ByVal D10 As Variant) As String
10       On Error GoTo Err_label

20        EncounterMarkerLongDesc = Trim( _
              IIf(Nz(D3) <> "", "Type=" & Nz(D3), "") & _
              IIf(Nz(D5) <> "", " Code=" & Nz(D5), "") & _
              IIf(Nz(D6) <> "", " Band Colour=" & Nz(D6), "") & _
              IIf(Nz(D7) <> "", " Code Colour=" & Nz(D7), "") & _
              IIf(Nz(D8) <> "", " Left Leg Colour 1=" & Nz(D8), "") & _
              IIf(Nz(D9) <> "", " Left Leg Colour 2=" & Nz(D9), "") & _
              IIf(Nz(D10) <> "", " Left Leg Colour 3=" & Nz(D10), "") & _
              IIf(Nz(D11) <> "", " Right Leg Colour 1=" & Nz(D11), "") & _
              IIf(Nz(D12) <> "", " Right Leg Colour 2=" & Nz(D12), "") & _
              IIf(Nz(D13) <> "", " Right Leg Colour 3=" & Nz(D13), ""))

          'DD Error Handler Start
Exit_label:
30        Exit Function
Err_label:
40        Select Case Err.Number
          Case Else
50             Call LogError("basEncounters", "EncounterMarkerLongDesc")
60        End Select
70        Resume Exit_label
          ' DD Error Handler End
End Function
