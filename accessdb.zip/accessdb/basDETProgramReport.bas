Option Compare Database
Option Explicit

Private colPeriod As Integer
Private colDateEx As Integer
Private colSpecies As Integer
Private colObserved As Integer
Private colCensus As Integer
Private colBanded As Integer
Private colRepeats As Integer
Private colReturns As Integer
Private colAlien As Integer
Private colReplacement As Integer
Private colDET As Integer
Private colObserverHours As Integer
Private colNetHours As Integer
Private colCoverageCode As Integer
Private colHummingbirdEffort As Integer
Private colEnd As Integer


Private conEffortStart As Integer
Private conObserverHours As Integer
Private conNetHours As Integer
Private conCoverageCode As Integer
Private conHummingbirdEffort As Integer
Private conEffortEnd As Integer

Const conObserved As Integer = 0
Const conCensus As Integer = 1
Const conBanded As Integer = 2
Const conReturns As Integer = 3
Const conRepeats As Integer = 4
Const conAlien As Integer = 5
Const conReplacement As Integer = 6
Const conDET As Integer = 7

Private lngStatBirds() As Long
Private dblStatDaily() As Double
Private lngStatBirdsCumulative() As Long
Private lngStatPseudoSpecies() As Long
Private dicStatSpecies() As Scripting.Dictionary

Private strLocation As String
Private strProgram As String

Private rowStartDate As Long
Private rowStartPeriod As Long

Private rowDailyStartPeriod As Long

'---------------------------------------------------------------------------------------
' DETPeriodReport
'---------------------------------------------------------------------------------------
 
Public Sub DETPeriodReport( _
    ByVal intYear As Integer, _
    ByVal argLocation As String, _
    ByVal argProgram As String, _
    ByVal strSeason As String, _
    ByRef oExcel As Excel.Application, _
    ByRef oBook As Excel.Workbook)

10    On Error GoTo Err_label

      Dim col As Long

20    col = 1
30    colPeriod = col
40    col = col + 1
50    colDateEx = col
60    col = col + 1
70    colSpecies = col
80    col = col + 1
90    colObserved = col
100   col = col + 1
110   colCensus = col
120   col = col + 1
130   colBanded = col
140   col = col + 1
150   colRepeats = col
160   col = col + 1
170   colReturns = col
180   col = col + 1
190   colAlien = col
200   col = col + 1
210   colReplacement = col
220   col = col + 1
230   colDET = col
240   col = col + 1
250   colObserverHours = col
260   col = col + 1
270   colNetHours = col
280   col = col + 1
290   colCoverageCode = col
300   col = col + 1
310   colHummingbirdEffort = col
320   colEnd = col

      Dim intEffort As Integer

330   intEffort = 1
340   conEffortStart = intEffort
350   conObserverHours = intEffort
360   intEffort = intEffort + 1
370   conNetHours = intEffort
380   intEffort = intEffort + 1
390   conCoverageCode = intEffort
400   intEffort = intEffort + 1
410   conHummingbirdEffort = intEffort
420   conEffortEnd = intEffort

430   ReDim lngStatBirds(conObserved To conDET) As Long
440   ReDim dblStatDaily(conEffortStart To conEffortEnd) As Double
450   ReDim lngStatBirdsCumulative(conObserved To conDET) As Long
460   ReDim lngStatPseudoSpecies(conObserved To conDET) As Long
470   ReDim dicStatSpecies(conObserved To conDET) As Scripting.Dictionary

480   strLocation = argLocation
490   strProgram = argProgram

      Dim lngPeriod As Long
      Dim datDateEx As Date
      Dim fFirstRowForDate As Boolean
      Dim stat As Integer
      Dim dblObserverHours As Double
      Dim dblNetHours As Double
      Dim dblCoverageCode As Double
      Dim dblHummingbirdEffort As Double
      Dim strSpecies As String

      Dim oSheetSpecies As Excel.Worksheet
      Dim oSheetDaily As Excel.Worksheet
      Dim rowSpecies As Long
      Dim rowDaily As Long

500   For stat = conObserved To conDET
510       Set dicStatSpecies(stat) = New Scripting.Dictionary
520   Next

530   Set oSheetSpecies = oBook.Worksheets.Add(After:=oBook.Worksheets(oBook.Worksheets.count))
540   oSheetSpecies.Name = intYear & " " & strSeason & " Species"

550   Set oSheetDaily = oBook.Worksheets.Add(After:=oBook.Worksheets(oBook.Worksheets.count))
560   oSheetDaily.Name = intYear & " " & strSeason & " Daily"

      ' Initialise Daily worksheet

570   rowDaily = 2

580   With oSheetDaily
590       .Cells(rowDaily, colPeriod) = "Period"
600       .Cells(rowDaily, colDateEx) = "Date"
610       .Cells(rowDaily, colSpecies) = "Species"
620       .Cells(rowDaily, colObserved) = "Observed"
630       .Cells(rowDaily, colCensus) = "Census"
640       .Cells(rowDaily, colBanded) = "Banded"
650       .Cells(rowDaily, colRepeats) = "Repeats"
660       .Cells(rowDaily, colReturns) = "Returns"
670       .Cells(rowDaily, colAlien) = "Alien"
680       .Cells(rowDaily, colReplacement) = "Repl."
690       .Cells(rowDaily, colDET) = "DET"
700       .Cells(rowDaily - 1, colObserverHours) = "Observer"
710       .Cells(rowDaily, colObserverHours) = "Hours"
720       .Cells(rowDaily - 1, colNetHours) = "Net"
730       .Cells(rowDaily, colNetHours) = "Hours"
740       .Cells(rowDaily - 1, colCoverageCode) = "Coverage"
750       .Cells(rowDaily, colCoverageCode) = "Code"
760       .Cells(rowDaily - 1, colHummingbirdEffort) = "Hummingbird"
770       .Cells(rowDaily, colHummingbirdEffort) = "Effort"
780   End With

790   rowDaily = 3

800   With oSheetSpecies

          ' Fill in headers

810       rowSpecies = 2

820       .Cells(rowSpecies, colPeriod) = "Period"
830       .Cells(rowSpecies, colDateEx) = "Date"
840       .Cells(rowSpecies, colSpecies) = "Species"
850       .Cells(rowSpecies, colObserved) = "Observed"
860       .Cells(rowSpecies, colCensus) = "Census"
870       .Cells(rowSpecies, colBanded) = "Banded"
880       .Cells(rowSpecies, colRepeats) = "Repeats"
890       .Cells(rowSpecies, colReturns) = "Returns"
900       .Cells(rowSpecies, colAlien) = "Alien"
910       .Cells(rowSpecies, colReplacement) = "Repl."
920       .Cells(rowSpecies, colDET) = "DET"
930       .Cells(rowSpecies - 1, colObserverHours) = "Observer"
940       .Cells(rowSpecies, colObserverHours) = "Hours"
950       .Cells(rowSpecies - 1, colNetHours) = "Net"
960       .Cells(rowSpecies, colNetHours) = "Hours"
970       .Cells(rowSpecies - 1, colCoverageCode) = "Coverage"
980       .Cells(rowSpecies, colCoverageCode) = "Code"
990       .Cells(rowSpecies - 1, colHummingbirdEffort) = "Hummingbird"
1000      .Cells(rowSpecies, colHummingbirdEffort) = "Effort"
1010      rowSpecies = 3
          
          Dim qdf As DAO.QueryDef
          Dim rst As DAO.Recordset
1020      Set qdf = CurrentDb.QueryDefs("qryDETPeriodReport")
1030      qdf.Parameters("argProgram").value = strProgram
1040      qdf.Parameters("argLocation").value = strLocation
1050      Set rst = qdf.OpenRecordset
          
1060      rowSpecies = 3
          
          Dim datDateEx_previous As Date
          Dim lngPeriod_previous As Long
          
1070      datDateEx_previous = 0
1080      lngPeriod_previous = -99

1090      Do While Not rst.EOF
        
1100          lngPeriod = Nz(rst("Period"))
1110          datDateEx = Nz(rst("DateEx"))
1120          strSpecies = Nz(rst("Species"))
1130          lngStatBirds(conObserved) = Nz(rst("Observed"))
1140          lngStatBirds(conCensus) = Nz(rst("Census"))
1150          lngStatBirds(conBanded) = Nz(rst("Banded"))
1160          lngStatBirds(conReturns) = Nz(rst("Returns"))
1170          lngStatBirds(conRepeats) = Nz(rst("Repeats"))
1180          lngStatBirds(conAlien) = Nz(rst("Alien"))
1190          lngStatBirds(conReplacement) = Nz(rst("Replacement"))
1200          lngStatBirds(conDET) = Nz(rst("DET"))
        
1210          If (datDateEx = datDateEx_previous And lngPeriod = lngPeriod_previous) Then GoTo Detail_label
1220              If datDateEx_previous > 0 Then
                  
                      ' F2 -- footer day
                      
1230                  Call F2(lngPeriod_previous, Format(datDateEx_previous, "d mmm yyyy"), oSheetSpecies, rowSpecies, oSheetDaily, rowDaily)
1240              End If
1250              If lngPeriod = lngPeriod_previous Then GoTo header2_label
1260              If datDateEx_previous > 0 Then
                  
                      ' F1 -- footer period
                      
1270                  oSheetSpecies.Activate
1280                  oSheetSpecies.range(oSheetSpecies.Cells(rowStartPeriod, 1), oSheetSpecies.Cells(rowSpecies - 1, 1)).Rows.Group
1290                  oSheetDaily.Activate
1300                  oSheetDaily.range(oSheetDaily.Cells(rowDailyStartPeriod, 1), oSheetDaily.Cells(rowDaily - 1, 1)).Rows.Group
1310                  oSheetSpecies.Activate
1320                  Call F1(lngPeriod_previous, datDateEx_previous, oSheetSpecies, rowSpecies, oSheetDaily, rowDaily)
1330              End If
                  
                  ' H1 - new period
                  
1340               rowStartPeriod = rowSpecies
1350               rowDailyStartPeriod = rowDaily
1360               lngPeriod_previous = lngPeriod
             
header2_label:

                  ' H2 - new day
                   
1370               SysCmd acSysCmdSetStatus, "Daily " & Format(datDateEx, "yyyy-mm-dd")
            
1380               dblObserverHours = Nz(rst("Observers"))
1390               dblNetHours = Nz(rst("SongBirdNets"))
1400               dblCoverageCode = Nz(rst("CoverageCode"))
1410               dblHummingbirdEffort = Nz(rst("OtherTrap"))
                  
1420               dblStatDaily(conObserverHours) = dblObserverHours
1430               dblStatDaily(conNetHours) = dblNetHours
1440               dblStatDaily(conCoverageCode) = dblCoverageCode
1450               dblStatDaily(conHummingbirdEffort) = dblHummingbirdEffort
1460                rowStartDate = rowSpecies
                    
1470                For stat = conObserved To conDET
1480                    lngStatBirdsCumulative(stat) = 0
1490                    lngStatPseudoSpecies(stat) = 0
1500                    dicStatSpecies(stat).RemoveAll
1510                Next
                    
1520                fFirstRowForDate = True
                        
1530                datDateEx_previous = datDateEx
           
Detail_label:
            
1540                .Cells(rowSpecies, colPeriod) = lngPeriod
1550                .Cells(rowSpecies, colDateEx) = datDateEx
1560                If Not fFirstRowForDate Then
1570                    .Cells(rowSpecies, colPeriod).Font.Color = RGB(165, 165, 165)
1580                    .Cells(rowSpecies, colDateEx).Font.Color = RGB(165, 165, 165)
1590                Else
1600                    fFirstRowForDate = False
1610                End If
1620                .Cells(rowSpecies, colDateEx).NumberFormat = "d mmm yyyy"
1630                .Cells(rowSpecies, colSpecies) = strSpecies
                    
                  
1640                For stat = conObserved To conDET
1650                    col = colObserved + (stat - conObserved)
1660                    If lngStatBirds(stat) > 0 Then
1670                        .Cells(rowSpecies, col) = lngStatBirds(stat)
                            
1680                        lngStatBirdsCumulative(stat) = lngStatBirdsCumulative(stat) + lngStatBirds(stat)
1690                        lngStatPseudoSpecies(stat) = lngStatPseudoSpecies(stat) + 1
                            
1700                        If Not dicStatSpecies(stat).Exists(strSpecies) Then
1710                            dicStatSpecies(stat).Add strSpecies, strSpecies
1720                        End If
                            
1730                    End If
1740                Next
                  
1750                rowSpecies = rowSpecies + 1
                    
1760                rst.MoveNext
1770      Loop
1780      rst.Close
1790      Set rst = Nothing
1800  End With

      ' F2

1810  Call F2(lngPeriod_previous, Format(datDateEx_previous, "d mmm yyyy"), oSheetSpecies, rowSpecies, oSheetDaily, rowDaily)

      ' F1

1820  oSheetSpecies.Activate
1830  oSheetSpecies.range(oSheetSpecies.Cells(rowStartPeriod, 1), oSheetSpecies.Cells(rowSpecies - 1, 1)).Rows.Group

1840  oSheetDaily.Activate
1850  oSheetDaily.range(oSheetDaily.Cells(rowDailyStartPeriod, 1), oSheetDaily.Cells(rowDaily - 1, 1)).Rows.Group
        
1860  oSheetSpecies.Activate
1870  Call F1(lngPeriod_previous, datDateEx_previous, oSheetSpecies, rowSpecies, oSheetDaily, rowDaily)
        
      ' FR
          
1880  oSheetSpecies.range(oSheetSpecies.Cells(3, 1), oSheetSpecies.Cells(rowSpecies - 1, 1)).Rows.Group

1890  oSheetDaily.Activate
1900  oSheetDaily.range(oSheetDaily.Cells(3, 1), oSheetDaily.Cells(rowDaily - 1, 1)).Rows.Group

1910  oSheetSpecies.Activate
1920  Call FR(oSheetSpecies, rowSpecies, oSheetDaily, rowDaily)
        
1930  oSheetDaily.Activate
1940  With oSheetDaily
1950      .range(.columns(1), .columns(colEnd)).HorizontalAlignment = xlCenter
1960      .range(.columns(1), .columns(colEnd)).AutoFit

          
1970      .Cells(1, 1) = "DET " & strProgram & " (" & intYear & " " & strSeason & ") at " & strLocation
1980      .Cells(1, 1).Font.Size = 14
1990      .Cells(1, 1).Font.Bold = True
2000      .Cells(1, 1).HorizontalAlignment = xlLeft

2010      If strSeason <> "RTHU" Then
2020          .columns(colHummingbirdEffort).Hidden = True
2030      End If

2040      .range("D3").Select
2050       oExcel.ActiveWindow.FreezePanes = True
2060  End With
        
2070  oSheetSpecies.Activate
2080  With oSheetSpecies
2090      .range(.columns(1), .columns(colEnd)).HorizontalAlignment = xlCenter
2100      .range(.columns(1), .columns(colEnd)).AutoFit
          
2110      .Cells(1, 1) = "DET " & strProgram & " (" & intYear & " " & strSeason & ") at " & strLocation
2120      .Cells(1, 1).Font.Size = 14
2130      .Cells(1, 1).Font.Bold = True
2140      .Cells(1, 1).HorizontalAlignment = xlLeft
          
2150      If strSeason <> "RTHU" Then
2160          .columns(colHummingbirdEffort).Hidden = True
2170      End If

2180      .range("D3").Select
2190       oExcel.ActiveWindow.FreezePanes = True
2200  End With

      'DD Error Handler Start
Exit_label:
2210       Exit Sub
Err_label:
2220       Select Case Err.Number
           Case Else
2230      Call LogError("basDETProgramReport", "DETPeriodReport")
2240       End Select
2250       Resume Exit_label
      'DD Error Handler End

    End Sub

'---------------------------------------------------------------------------------------
' F2 -- control break in date
'---------------------------------------------------------------------------------------
 
Private Sub F2(ByVal strPeriod As String, ByVal strDate As String, _
               ByRef oSheetSpecies As Excel.Worksheet, ByRef rowSpecies As Long, _
               ByRef oSheetDaily As Excel.Worksheet, ByRef rowDaily As Long)

      Dim stat As Integer
      Dim col As Integer
      Dim lngCountSpecies As Long
      Dim rowSpeciesStart As Long
      Dim rowDailyStart As Long

10    On Error GoTo Err_label

20    rowSpeciesStart = rowSpecies
30    rowDailyStart = rowDaily

40    With oSheetSpecies

50         .Cells(rowSpecies, colPeriod) = strPeriod
60         .Cells(rowSpecies, colDateEx) = strDate
70         .Cells(rowSpecies, colSpecies) = "Birds"
           
80         oSheetDaily.Cells(rowDaily, colPeriod) = strPeriod
90         oSheetDaily.Cells(rowDaily, colDateEx) = strDate
100        oSheetDaily.Cells(rowDaily, colSpecies) = "Birds"
           
110        For stat = conObserved To conDET
120            col = colObserved + (stat - conObserved)
130            If lngStatBirdsCumulative(stat) > 0 Then
140                .Cells(rowSpecies, col) = lngStatBirdsCumulative(stat)
150                oSheetDaily.Cells(rowDaily, col) = lngStatBirdsCumulative(stat)
160            End If
170        Next

180        For stat = conEffortStart To conEffortEnd
190            col = colObserverHours + (stat - conObserverHours)
200            If dblStatDaily(stat) > 0 Then
210                .Cells(rowSpecies, col) = dblStatDaily(stat)
220                .Cells(rowSpecies, col).NumberFormat = "#0.0"
230                oSheetDaily.Cells(rowDaily, col) = dblStatDaily(stat)
240                oSheetDaily.Cells(rowDaily, col).NumberFormat = "#0.0"
                   
250            End If
260        Next
           
270        rowSpecies = rowSpecies + 1
280        rowDaily = rowDaily + 1
           
290        .Cells(rowSpecies, colPeriod) = strPeriod
300        .Cells(rowSpecies, colDateEx) = strDate
310        .Cells(rowSpecies, colSpecies) = "Pseudospecies"
           
320        oSheetDaily.Cells(rowDaily, colPeriod) = strPeriod
330        oSheetDaily.Cells(rowDaily, colDateEx) = strDate
340        oSheetDaily.Cells(rowDaily, colSpecies) = "Pseudospecies"
                           
350        For stat = conObserved To conDET
360            col = colObserved + (stat - conObserved)
370            If lngStatPseudoSpecies(stat) > 0 Then
380                .Cells(rowSpecies, col) = lngStatPseudoSpecies(stat)
390                oSheetDaily.Cells(rowDaily, col) = lngStatPseudoSpecies(stat)
400            End If
410        Next

420        rowSpecies = rowSpecies + 1
430        rowDaily = rowDaily + 1
           
440        .Cells(rowSpecies, colPeriod) = strPeriod
450        .Cells(rowSpecies, colDateEx) = strDate
460        .Cells(rowSpecies, colSpecies) = "Species"
           
470        oSheetDaily.Cells(rowDaily, colPeriod) = strPeriod
480        oSheetDaily.Cells(rowDaily, colDateEx) = strDate
490        oSheetDaily.Cells(rowDaily, colSpecies) = "Species"
           
500        For stat = conObserved To conDET
510            col = colObserved + (stat - conObserved)
520            lngCountSpecies = CountSpeciesInDictionary(dicStatSpecies(stat))
530            If lngCountSpecies > 0 Then
540                .Cells(rowSpecies, col) = lngCountSpecies
550                oSheetDaily.Cells(rowDaily, col) = lngCountSpecies
560            End If
570        Next

580        rowSpecies = rowSpecies + 2
590        rowDaily = rowDaily + 2
           
600        .range(.Cells(rowSpeciesStart, 1), .Cells(rowSpecies - 1, colEnd)).Font.Bold = True
610        .range(.Cells(rowSpeciesStart + 1, 1), .Cells(rowSpeciesStart + 2, 2)).Font.Bold = False
620        With .range(.Cells(rowSpecies, 1), .Cells(rowSpecies, colEnd)).Borders(xlEdgeTop)
630           .LineStyle = xlContinuous
640           .Weight = xlThin
650        End With
           
660   End With

670   With oSheetDaily
680        .range(.Cells(rowDailyStart, 1), .Cells(rowDaily - 1, colEnd)).Font.Bold = True
690        .range(.Cells(rowDailyStart + 1, 1), .Cells(rowDailyStart + 2, 2)).Font.Bold = False
700        With .range(.Cells(rowDaily, 1), .Cells(rowDaily, colEnd)).Borders(xlEdgeTop)
710           .LineStyle = xlContinuous
720           .Weight = xlThin
730        End With
740   End With

      'DD Error Handler Start
Exit_label:
750        Exit Sub
Err_label:
760        Select Case Err.Number
           Case Else
770             Call LogError("basDETProgramReport", "F2")
780        End Select
790        Resume Exit_label
      'DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' F1 - control break in period
'---------------------------------------------------------------------------------------
 
Private Sub F1(ByVal lngPeriod As Long, ByVal datDateEx As Date, _
               ByRef oSheetSpecies As Excel.Worksheet, ByRef rowSpecies As Long, _
               ByRef oSheetDaily As Excel.Worksheet, ByRef rowDaily As Long)
               
10    On Error GoTo Err_label

      Dim strSpecies As String

      Dim stat As Integer
      Dim col As Long
      Dim rowSpeciesStart As Long
      Dim rowDailyStart As Long

      Dim datDateFrom As Date
      Dim datPeriodStart As Date
      Dim strDate As String

20    datDateFrom = Nz(DLookup("DateFrom", "tblPrograms", "[Program] = '" & strProgram & "'"))
30    datPeriodStart = datDateFrom + (lngPeriod - 1) * 7
40    If datDateFrom > 0 Then
50      strDate = Format(datPeriodStart, "d mmm") & " - " & Format(datPeriodStart + 6, "d mmm yyyy")
60    Else
70      strDate = ""
80    End If

90    rowSpeciesStart = rowSpecies
100   rowDailyStart = rowDaily

110   With oSheetSpecies

' qryDETPeriodReport_Period_B
' ---------------------------
' tblDETDaily x tblPrograms
' = [argProgram]
' = [argLocation]
' = [argPeriod]
' SUM Observers
' SUM SongbirdNets
' SUM CoverageCode
' SUM OtherTrap
' Report: Program, Location, Period, Observers,SongbirdNets,CoverageCode,OtherTrap



' qryDETPeriodReport_Period
' -------------------------
' qryDETPeriodReport_Period_A x qryDETPeriodReport_Period_B x tblSpecies
' ORDER BY DETOrder
' Report Program, Location, Period, Species, Observed, Census, Banded, Repeats, Returns, DET, Alien, Replacement, Observers, SongbirdNets, CoverageCode, OtherTrap, DETOrder



















          Dim qdf As DAO.QueryDef
          Dim rst As DAO.Recordset
120       Set qdf = CurrentDb.QueryDefs("qryDETPeriodReport_Period")
130       qdf.Parameters("argProgram").value = strProgram
140       qdf.Parameters("argLocation").value = strLocation
150       qdf.Parameters("argPeriod").value = lngPeriod
160       Set rst = qdf.OpenRecordset
          
170       For stat = conObserved To conDET
180           lngStatBirdsCumulative(stat) = 0
190           lngStatPseudoSpecies(stat) = 0
200           dicStatSpecies(stat).RemoveAll
210       Next

          Dim fFirst As Boolean
220       fFirst = True

230       Do While Not rst.EOF
        
240           strSpecies = Nz(rst("Species"))
250           lngStatBirds(conObserved) = Nz(rst("Observed"))
260           lngStatBirds(conCensus) = Nz(rst("Census"))
270           lngStatBirds(conBanded) = Nz(rst("Banded"))
280           lngStatBirds(conReturns) = Nz(rst("Returns"))
290           lngStatBirds(conRepeats) = Nz(rst("Repeats"))
300           lngStatBirds(conAlien) = Nz(rst("Alien"))
310           lngStatBirds(conReplacement) = Nz(rst("Replacement"))
320           lngStatBirds(conDET) = Nz(rst("DET"))
330           dblStatDaily(conObserverHours) = Nz(rst("Observers"))
340           dblStatDaily(conNetHours) = Nz(rst("SongBirdNets"))
350           dblStatDaily(conCoverageCode) = Nz(rst("CoverageCode"))
360           dblStatDaily(conHummingbirdEffort) = Nz(rst("OtherTrap"))
370           .Cells(rowSpecies, colPeriod) = lngPeriod
380           .Cells(rowSpecies, colDateEx) = strDate
390           If Not fFirst Then
400               .Cells(rowSpecies, colPeriod).Font.Color = RGB(127, 127, 127)
410               .Cells(rowSpecies, colDateEx).Font.Color = RGB(127, 127, 127)
420           Else
430               fFirst = False
440           End If
450           .Cells(rowSpecies, colSpecies) = strSpecies
              
460           For stat = conObserved To conDET
470               col = colObserved + (stat - conObserved)
480               If lngStatBirds(stat) > 0 Then
490                   .Cells(rowSpecies, col) = lngStatBirds(stat)
                      
500                   lngStatBirdsCumulative(stat) = lngStatBirdsCumulative(stat) + lngStatBirds(stat)
510                   lngStatPseudoSpecies(stat) = lngStatPseudoSpecies(stat) + 1
                      
520                   If Not dicStatSpecies(stat).Exists(strSpecies) Then
530                       dicStatSpecies(stat).Add strSpecies, strSpecies
540                   End If
                      
550               End If
560           Next
570           rowSpecies = rowSpecies + 1
580             rst.MoveNext
590       Loop
600       rst.Close
610       Set rst = Nothing
620       Call F2(lngPeriod, strDate, oSheetSpecies, rowSpecies, oSheetDaily, rowDaily)

630       .range(.Cells(rowSpeciesStart, 1), .Cells(rowSpecies - 1, colEnd)).Interior.Color = RGB(219, 238, 243) ' light blue
640   End With
650   oSheetDaily.range(oSheetDaily.Cells(rowDailyStart, 1), oSheetDaily.Cells(rowDaily - 1, colEnd)).Interior.Color = RGB(219, 238, 243) ' light b


      'DD Error Handler Start
Exit_label:
660        Exit Sub
Err_label:
670        Select Case Err.Number
           Case Else
680             Call LogError("basDETProgramReport", "F1")
690        End Select
700        Resume Exit_label
      'DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' FR - final footer for program
'---------------------------------------------------------------------------------------
 
Private Sub FR(ByRef oSheetSpecies As Excel.Worksheet, ByRef rowSpecies As Long, _
               ByRef oSheetDaily As Excel.Worksheet, ByRef rowDaily As Long)
               
10    On Error GoTo Err_label

      Dim strSpecies As String

      Dim stat As Integer
      Dim col As Long
      Dim rowSpeciesStart As Long
      Dim rowDailyStart As Long

      Dim datProgramStart
      Dim datProgramEnd
      Dim strDate As String
20    datProgramStart = Nz(DMin("DateEx", "tblDETDaily", "[Program] = '" & strProgram & "' AND [Location] = '" & [strLocation] & "'"))
30    datProgramEnd = Nz(DMax("DateEx", "tblDETDaily", "[Program] = '" & strProgram & "' AND [Location] = '" & [strLocation] & "'"))
40    If datProgramStart > 0 And datProgramEnd > 0 Then
50      strDate = Format(datProgramStart, "d mmm") & " - " & Format(datProgramEnd, "d mmm yyyy")
60    Else
70      strDate = ""
80    End If

90    rowSpeciesStart = rowSpecies
100   rowDailyStart = rowDaily
       
110   With oSheetSpecies


' qryDETPeriodReport_Program_B
' ----------------------------
' tblDETDaily
' Program = [argProgram]
' Location = [argLocation]
' Observers = SUM Observers
' SongbirdNets = SUM SongbirdNets
' CoverageCode = SUM CoverageCode
' OtherTrap = SUM OtherTrap
' Report: Program, Location,Observers, SongbirdNets, CoverageCode, OtherTrap


' qryDETPeriodReport_Program
' --------------------------
' qryDETPeriodReport_Program_A x qryDETPeriodReport_Program_B x tblSpecies
' Report: Program, Location, Species, Observed, Census, Banded, Repeats, Returns, DET, Alien, replacement, Observers, SongbirdNets, CoverageCode, DETOrder ASC

          Dim qdf As DAO.QueryDef
          Dim rst As DAO.Recordset
120       Set qdf = CurrentDb.QueryDefs("qryDETPeriodReport_Program")
130       qdf.Parameters("argProgram").value = strProgram
140       qdf.Parameters("argLocation").value = strLocation
150       Set rst = qdf.OpenRecordset
          
160       For stat = conObserved To conDET
170           lngStatBirdsCumulative(stat) = 0
180           lngStatPseudoSpecies(stat) = 0
190           dicStatSpecies(stat).RemoveAll
200       Next

          Dim fFirst As Boolean
210       fFirst = True

220       Do While Not rst.EOF
        
230           strSpecies = Nz(rst("Species"))
240           lngStatBirds(conObserved) = Nz(rst("Observed"))
250           lngStatBirds(conCensus) = Nz(rst("Census"))
260           lngStatBirds(conBanded) = Nz(rst("Banded"))
270           lngStatBirds(conReturns) = Nz(rst("Returns"))
280           lngStatBirds(conRepeats) = Nz(rst("Repeats"))
290           lngStatBirds(conAlien) = Nz(rst("Alien"))
300           lngStatBirds(conReplacement) = Nz(rst("Replacement"))
310           lngStatBirds(conDET) = Nz(rst("DET"))
320           dblStatDaily(conObserverHours) = Nz(rst("Observers"))
330           dblStatDaily(conNetHours) = Nz(rst("SongBirdNets"))
340           dblStatDaily(conCoverageCode) = Nz(rst("CoverageCode"))
350           dblStatDaily(conHummingbirdEffort) = Nz(rst("OtherTrap"))
        
360           .Cells(rowSpecies, colPeriod) = "MP"
370           .Cells(rowSpecies, colDateEx) = strDate
380           If Not fFirst Then
390               .Cells(rowSpecies, colDateEx).Font.Color = RGB(127, 127, 127)
400           Else
410               fFirst = False
420           End If
430           .Cells(rowSpecies, colSpecies) = strSpecies
              
440           For stat = conObserved To conDET
450               col = colObserved + (stat - conObserved)
460               If lngStatBirds(stat) > 0 Then
470                   .Cells(rowSpecies, col) = lngStatBirds(stat)
                      
480                   lngStatBirdsCumulative(stat) = lngStatBirdsCumulative(stat) + lngStatBirds(stat)
490                   lngStatPseudoSpecies(stat) = lngStatPseudoSpecies(stat) + 1
                      
500                   If Not dicStatSpecies(stat).Exists(strSpecies) Then
510                       dicStatSpecies(stat).Add strSpecies, strSpecies
520                   End If
                      
530               End If
540           Next
550           rowSpecies = rowSpecies + 1
560             rst.MoveNext
570       Loop
580       rst.Close
590       Set rst = Nothing

600       Call F2("MP", strDate, oSheetSpecies, rowSpecies, oSheetDaily, rowDaily)

610       .range(.Cells(rowSpeciesStart, 1), .Cells(rowSpecies - 1, colEnd)).Interior.Color = RGB(215, 228, 188) ' light green
620   End With
630   oSheetDaily.range(oSheetDaily.Cells(rowDailyStart, 1), oSheetDaily.Cells(rowDaily - 1, colEnd)).Interior.Color = RGB(215, 228, 188) ' light green

      'DD Error Handler Start
Exit_label:
640        Exit Sub
Err_label:
650        Select Case Err.Number
           Case Else
660             Call LogError("basDETProgramReport", "FR")
670        End Select
680        Resume Exit_label
      'DD Error Handler End
End Sub
