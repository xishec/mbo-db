Option Compare Database
Option Explicit

'Public Function SendEMail(Subject As String, _
'        FromAddress As String, _
'        ToAddress As String, _
'        MailBody As String, _
'        SMTP_Server As String, _
'        BodyFileName As String, _
'        ByRef strError As String, _
'        Optional Attachments As Variant = Empty) As Boolean
'      '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
'      ' SendEmail Function
'      ' By Chip Pearson, chip@cpearson.com www.cpearson.com 28-June-2012
'      '
'      ' This function sends an email to the specified user.
'      ' Parameters:
'      '   Subject:        The subject of the email.
'      '   FromAddress:    The sender's email address
'      '   ToAddress:      The recipient's email address or addresses.
'      '   MailBody:       The body of the email.
'      '   SMTP_Server:    The SMTP-Server name for outgoing mail.
'      '   BodyFileName:   A text file containing the body of the email.
'      '   Attachments     A single file name or an array of file names to
'      '                   attach to the message. The files must exist.
'      ' Return Value:
'      '   True if successful.
'      '   False if failure.
'      '
'      ' Subject may not be an empty string.
'      ' FromAddress must be a valid email address.
'      ' ToAddress must be a valid email address. To send to multiple recipients,
'      ' use a semi-colon to separate the individual addresses. If there is a
'      ' failure in one address, processing terminates and messages are not
'      ' send to the rest of the recipients.
'      ' If MailBody is vbNullString and BodyFileName is an existing text file, the content
'      ' of the file named by BodyFileName is put into the body of the email. If
'      ' BodyFileName does not exist, the function returns False. The content of
'      ' the message body is created by a line-by-line import from BodyFileName.
'      ' If MailBody is not vbNullString, then BodyFileName is ignored and the body
'      ' is not created from the file.
'      ' SMTP_Server must be a valid accessable SMTP server name.
'      ' If both MailBody and BodyFileName are vbNullString, the mail message is
'      ' sent with no body content.
'      ' Attachments can be either a single file name as a String or an array of
'      ' file names. If an attachment file does not exist, it is skipped but
'      ' does not cause the procedure to terminate.
'      '
'      ' If you want to send ThisWorkbook as an attachment to the message, use code
'      ' like the following:
'      '    ThisWorkbook.Save
'      '    ThisWorkbook.ChangeFileAccess xlReadOnly
'      '    B = SendEmail( _
'      '        ... parameters ...
'      '        Attachments:=ThisWorkbook.FullName)
'      '    ThisWorkbook.ChangeFileAccess xlReadWrite
'      '
'      '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
'      ' Required References:
'      ' --------------------
'      '   Microsoft CDO for Windows 2000 Library
'      '       Typical File Location: C:\Windows\system32\cdosys.dll
'      '       GUID: {CD000000-8B95-11D1-82DB-00C04FB1625D}
'      '       Major: 1    Minor: 0
'      '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
'
'      Dim MailMessage As CDO.Message
'      Dim n As Long
'      Dim FNum As Integer
'      Dim s As String
'      Dim Body As String
'      Dim Recips() As String
'      Dim Recip As String
'      Dim NRecip As Long
'
'20        strError = ""
'
'      ' ensure required parameters are present and valid.
'30    If Len(Trim(Subject)) = 0 Then
'40        SendEMail = False
'50        Exit Function
'60    End If
'
'70    If Len(Trim(FromAddress)) = 0 Then
'80        SendEMail = False
'90        Exit Function
'100   End If
'
'110   If Len(Trim(SMTP_Server)) = 0 Then
'120       SendEMail = False
'130       Exit Function
'140   End If
'
'      ' Clean up the addresses
'150   Recip = Replace(ToAddress, Space(1), vbNullString)
'160   Recips = Split(Recip, ";")
'
'170   For NRecip = LBound(Recips) To UBound(Recips)
'180       On Error Resume Next
'          ' Create a CDO Message object.
'190       Set MailMessage = CreateObject("CDO.Message")
'200       If Err.Number <> 0 Then
'210           SendEMail = False
'220           Exit Function
'230       End If
'240       Err.Clear
'250       On Error GoTo 0
'260       With MailMessage
'270           .Subject = Subject
'280           .From = FromAddress
'290           .To = Recips(NRecip)
'300           If MailBody <> vbNullString Then
'310               .TextBody = MailBody
'320           Else
'330               If BodyFileName <> vbNullString Then
'340                   If Dir(BodyFileName, vbNormal) <> vbNullString Then
'                          ' import the text of the body from file BodyFileName
'350                       FNum = FreeFile
'360                       s = vbNullString
'370                       Body = vbNullString
'380                       Open BodyFileName For Input Access Read As #FNum
'390                       Do Until EOF(FNum)
'400                           Line Input #FNum, s
'410                           Body = Body & vbNewLine & s
'420                       Loop
'430                       Close #FNum
'440                       .TextBody = Body
'450                   Else
'                          ' BodyFileName not found.
'460                       SendEMail = False
'470                       Exit Function
'480                   End If
'490               End If ' MailBody and BodyFileName are both vbNullString.
'500           End If
'
'510           If IsArray(Attachments) = True Then
'                  ' attach all the files in the array.
'520               For n = LBound(Attachments) To UBound(Attachments)
'                      ' ensure the attachment file exists and attach it.
'530                   If Attachments(n) <> vbNullString Then
'540                       If Dir(Attachments(n), vbNormal) <> vbNullString Then
'550                           .AddAttachment Attachments(n)
'560                       End If
'570                   End If
'580               Next n
'590           Else
'                  ' ensure the file exists and if so, attach it to the message.
'600               If Attachments <> vbNullString Then
'610                   If Dir(CStr(Attachments), vbNormal) <> vbNullString Then
'620                       .AddAttachment Attachments
'630                   End If
'640               End If
'650           End If
'660           With .Configuration.Fields
'                  ' set up the SMTP configuration
''650               .item("http://schemas.microsoft.com/cdo/configuration/sendusing") = 2
''660               .item("http://schemas.microsoft.com/cdo/configuration/smtpserver") = SMTP_Server
''670               .item("http://schemas.microsoft.com/cdo/configuration/smtpserverport") = 25
'
'670     .item("http://schemas.microsoft.com/cdo/configuration/smtpusessl") = True
'680     .item("http://schemas.microsoft.com/cdo/configuration/smtpauthenticate") = 1
'690     .item("http://schemas.microsoft.com/cdo/configuration/smtpserver") = "smtp.gmail.com" 'smtp mail server
'700     .item("http://schemas.microsoft.com/cdo/configuration/sendusing") = 2
'710     .item("http://schemas.microsoft.com/cdo/configuration/smtpserverport") = 465 'stmp server
'720   .item("http://schemas.microsoft.com/cdo/configuration/sendusername") = "mbo.dell.dataentry@gmail.com"
'730   .item("http://schemas.microsoft.com/cdo/configuration/sendpassword") = "yellowwarbler"
'740               .Update
'750           End With
'
'760           On Error Resume Next
'770           Err.Clear
'              ' Send the message
'780           .Send
'790           If Err.Number = 0 Then
'800               SendEMail = True
'810           Else
'820               SendEMail = False
'830   strError = Err.Number & " " & Err.Description
'840               Exit Function
'850           End If
'860       End With
'870   Next NRecip
'
'End Function


Public Function SendEMail(Subject As String, _
        FromAddress As String, _
        FromMotDePasse As String, _
        ToAddress As String, _
        MailBody As String, _
        SMTP_Server As String, _
        SMTP_Server_Port As Integer, _
        BodyFileName As String, _
        ByRef strError As String, _
        Optional Attachments As Variant = Empty) As Boolean
        
      '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
      ' SendEmail Function
      ' By Chip Pearson, chip@cpearson.com www.cpearson.com 28-June-2012
      '
      ' This function sends an email to the specified user.
      ' Parameters:
      '   Subject:        The subject of the email.
      '   FromAddress:    The sender's email address
      '   ToAddress:      The recipient's email address or addresses.
      '   MailBody:       The body of the email.
      '   SMTP_Server:    The SMTP-Server name for outgoing mail.
      '   BodyFileName:   A text file containing the body of the email.
      '   Attachments     A single file name or an array of file names to
      '                   attach to the message. The files must exist.
      ' Return Value:
      '   True if successful.
      '   False if failure.
      '
      ' Subject may not be an empty string.
      ' FromAddress must be a valid email address.
      ' ToAddress must be a valid email address. To send to multiple recipients,
      ' use a semi-colon to separate the individual addresses. If there is a
      ' failure in one address, processing terminates and messages are not
      ' send to the rest of the recipients.
      ' If MailBody is vbNullString and BodyFileName is an existing text file, the content
      ' of the file named by BodyFileName is put into the body of the email. If
      ' BodyFileName does not exist, the function returns False. The content of
      ' the message body is created by a line-by-line import from BodyFileName.
      ' If MailBody is not vbNullString, then BodyFileName is ignored and the body
      ' is not created from the file.
      ' SMTP_Server must be a valid accessable SMTP server name.
      ' If both MailBody and BodyFileName are vbNullString, the mail message is
      ' sent with no body content.
      ' Attachments can be either a single file name as a String or an array of
      ' file names. If an attachment file does not exist, it is skipped but
      ' does not cause the procedure to terminate.
      '
      ' If you want to send ThisWorkbook as an attachment to the message, use code
      ' like the following:
      '    ThisWorkbook.Save
      '    ThisWorkbook.ChangeFileAccess xlReadOnly
      '    B = SendEmail( _
      '        ... parameters ...
      '        Attachments:=ThisWorkbook.FullName)
      '    ThisWorkbook.ChangeFileAccess xlReadWrite
      '
      '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
      ' Required References:
      ' --------------------
      '   Microsoft CDO for Windows 2000 Library
      '       Typical File Location: C:\Windows\system32\cdosys.dll
      '       GUID: {CD000000-8B95-11D1-82DB-00C04FB1625D}
      '       Major: 1    Minor: 0
      '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

      Dim MailMessage As CDO.Message
      Dim n As Long
      Dim FNum As Integer
      Dim s As String
      Dim Body As String
      Dim Recips() As String
      Dim Recip As String
      Dim NRecip As Long
           
10       On Error GoTo Err_label

20        strError = ""

      ' ensure required parameters are present and valid.
30    If Len(Trim(Subject)) = 0 Then
40        SendEMail = False
50        Exit Function
60    End If

70    If Len(Trim(FromAddress)) = 0 Then
80        SendEMail = False
90        Exit Function
100   End If

110   If Len(Trim(SMTP_Server)) = 0 Then
120       SendEMail = False
130       Exit Function
140   End If

      ' Clean up the addresses
150   Recip = Replace(ToAddress, Space(1), vbNullString)
160   Recips = Split(Recip, ";")

170   For NRecip = LBound(Recips) To UBound(Recips)
180       On Error Resume Next
          ' Create a CDO Message object.
190       Set MailMessage = CreateObject("CDO.Message")
200       If Err.Number <> 0 Then
210           SendEMail = False
220           Exit Function
230       End If
240       Err.Clear
250       On Error GoTo 0
260       With MailMessage
270           .Subject = Subject
280           .From = FromAddress
290           .To = Recips(NRecip)
300           If MailBody <> vbNullString Then
310               .TextBody = MailBody
320           Else
330               If BodyFileName <> vbNullString Then
340                   If Dir(BodyFileName, vbNormal) <> vbNullString Then
                          ' import the text of the body from file BodyFileName
350                       FNum = FreeFile
360                       s = vbNullString
370                       Body = vbNullString
380                       Open BodyFileName For Input Access Read As #FNum
390                       Do Until EOF(FNum)
400                           Line Input #FNum, s
410                           Body = Body & vbNewLine & s
420                       Loop
430                       Close #FNum
440                       .TextBody = Body
450                   Else
                          ' BodyFileName not found.
460                       SendEMail = False
470                       Exit Function
480                   End If
490               End If ' MailBody and BodyFileName are both vbNullString.
500           End If
              
510           If IsArray(Attachments) = True Then
                  ' attach all the files in the array.
520               For n = LBound(Attachments) To UBound(Attachments)
                      ' ensure the attachment file exists and attach it.
530                   If Attachments(n) <> vbNullString Then
540                       If Dir(Attachments(n), vbNormal) <> vbNullString Then
550                           .AddAttachment Attachments(n)
560                       End If
570                   End If
580               Next n
590           Else
                  ' ensure the file exists and if so, attach it to the message.
600               If Attachments <> vbNullString Then
610                   If Dir(CStr(Attachments), vbNormal) <> vbNullString Then
620                       .AddAttachment Attachments
630                   End If
640               End If
650           End If
660           With .Configuration.Fields
                  ' set up the SMTP configuration
'650               .item("http://schemas.microsoft.com/cdo/configuration/sendusing") = 2
'660               .item("http://schemas.microsoft.com/cdo/configuration/smtpserver") = SMTP_Server
'670               .item("http://schemas.microsoft.com/cdo/configuration/smtpserverport") = 25

670     .Item("http://schemas.microsoft.com/cdo/configuration/smtpusessl") = True
680     .Item("http://schemas.microsoft.com/cdo/configuration/smtpauthenticate") = 1
690     .Item("http://schemas.microsoft.com/cdo/configuration/smtpserver") = SMTP_Server
700     .Item("http://schemas.microsoft.com/cdo/configuration/sendusing") = 2
710     .Item("http://schemas.microsoft.com/cdo/configuration/smtpserverport") = SMTP_Server_Port    ' 457 for gmail
720   .Item("http://schemas.microsoft.com/cdo/configuration/sendusername") = FromAddress
730   .Item("http://schemas.microsoft.com/cdo/configuration/sendpassword") = FromMotDePasse    '  "twdg2437T"         '  "yellowwarbler"
740               .Update
750           End With
              
760           On Error Resume Next
770           Err.Clear
              ' Send the message
780           .Send
790           If Err.Number = 0 Then
800               SendEMail = True
810           Else
820               SendEMail = False
830   strError = Err.Number & " " & Err.Description
840               Exit Function
850           End If
860       End With
870   Next NRecip

    'DD Error Handler Start
Exit_label:
880       Exit Function
Err_label:
890       Select Case Err.Number
    Case Else
900      Call LogError("basEmail", "SendEMail")
910       End Select
920       Resume Exit_label
    ' DD Error Handler End

End Function
