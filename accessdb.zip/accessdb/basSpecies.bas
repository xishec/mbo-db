Option Compare Database
Option Explicit

'---------------------------------------------------------------------------------------
' UpdateSpan
'---------------------------------------------------------------------------------------
 
Public Sub UpdateSpan(ByRef fSuccess As Boolean)
10    On Error GoTo Err_label

20    fSuccess = False

      Dim cntRetry As Integer
30    For cntRetry = 1 To 5
40        Call UpdateSpan_Retry(fSuccess)
50        If fSuccess Then Exit For
60        Sleep 1000
70    Next cntRetry

      'DD Error Handler Start
Exit_label:
80         Exit Sub
Err_label:
90         Select Case Err.Number
           Case Else
100             Call LogError("Form_frmSpecies", "UpdateSpan")
110        End Select
120        Resume Exit_label
      'DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' UpdateSpan_Retry
'
' qryMaxMultiCaptureSpan1 = Summary: Band Number Min and Max Species, for "1","R',"F"
' qryMaxMultiCaptureSpan2 = Bands Numbers excluding multi-species birds
' qryMaxMultiCaptureSpan3 = Captures excluding multi-species birds, for "1","R',"F"
' qryMaxMultiCaptureSpan4 = Summary: Species, Band Number, Max CaptureDate - Min CaptureDate
'                 "1","R","F" only; excluding multi-species birds
' qryMaxMultiCaptureSpan5_AppendTable = Summary: Species , MaxMultiCaptureSpan
' qryMaxMultiCaptureSpan5_Update = Updates tblSpecies. MaxMultiCaptureSpan

'---------------------------------------------------------------------------------------
 
Private Sub UpdateSpan_Retry(ByRef fSuccess As Boolean)
          
10    On Error GoTo Err_label

20    fSuccess = False
          
      Dim strSQL As String

      ' Null the MaxMultiCaptureSpan column

30    strSQL = "UPDATE tblSpecies SET MaxMultiCaptureSpan = Null"
      Dim cmd As New ADODB.Command
40    cmd.ActiveConnection = CurrentProject.Connection
50    cmd.CommandText = strSQL
60    cmd.Execute

      ' ZAP tblMaxMultiCaptureSpan

70    strSQL = "DELETE * FROM tblMaxMultiCaptureSpan"
80    cmd.CommandText = strSQL
90    cmd.Execute

      ' Fill in tblMaxMultiCaptureSpan
      ' Copy data to tblSpecies.MaxMultiCaptureSpan

100   CurrentDb.Execute "qryMaxMultiCaptureSpan5_AppendTable"
110   CurrentDb.Execute "qryMaxMultiCaptureSpan6_Update"

120   fSuccess = True

      'DD Error Handler Start
Exit_label:
130        Exit Sub
Err_label:
140        Select Case Err.Number
           Case Else
150           Call LogError( _
                      "basSpecies", _
                      "UpdateSpan_Retry", _
                      "Update span has failed", _
                      Silent:=True)
160        End Select
170        Resume Exit_label
      'DD Error Handler End
          
End Sub

'---------------------------------------------------------------------------------------
' UpdateSpanSpecies
'---------------------------------------------------------------------------------------
 
Public Sub UpdateSpanSpecies(ByVal Species As String, ByRef fSuccess As Boolean, Optional fLog As Boolean = False)
10    On Error GoTo Err_label

20    fSuccess = False

      Dim cntRetry As Integer
30    For cntRetry = 1 To 5
40        Call UpdateSpanSpecies_Retry(Species, fSuccess, fLog)
50        If fSuccess Then Exit For
60        Sleep 1000
70    Next cntRetry

      'DD Error Handler Start
Exit_label:
80         Exit Sub
Err_label:
90         Select Case Err.Number
           Case Else
100             Call LogError("Form_frmSpecies", "UpdateSpanSpecies")
110        End Select
120        Resume Exit_label
      'DD Error Handler End
End Sub


'---------------------------------------------------------------------------------------
' UpdateSpanSpecies_Retry
'
' qryMaxMultiCaptureSpan1 = Summary: Band Number Min and Max Species, for "1","R',"F"
' qryMaxMultiCaptureSpan2 = Bands Numbers excluding multi-species birds
' qryMaxMultiCaptureSpan3 = Captures excluding multi-species birds, for "1","R',"F"
' qryMaxMultiCaptureSpan4 = Summary: Species, Band Number, Max CaptureDate - Min CaptureDate
'                 "1","R","F" only; excluding multi-species birds
'---------------------------------------------------------------------------------------
'
' tblMaxMultiCaptureSpan
' ----------------------
' Species
' MaxMultiCaptureSpan
'

Private Sub UpdateSpanSpecies_Retry(ByVal Species As String, ByRef fSuccess As Boolean, Optional fLog As Boolean = False)
          
      Dim MaxMultiCaptureSpan_old As Long
          
          
10    On Error GoTo Err_label

20    fSuccess = False

      ' If logging, get the old span

30    If fLog Then
40        MaxMultiCaptureSpan_old = Nz(DLookup("MaxMultiCaptureSpan", "tblSpecies", "Species = '" & Species & "'"))
50    End If

      ' ZAP tblMaxMultiCaptureSpan

      Dim strSQL As String
60    strSQL = "DELETE * FROM tblMaxMultiCaptureSpan"
      Dim cmd As New ADODB.Command
70    cmd.ActiveConnection = CurrentProject.Connection
80    cmd.CommandText = strSQL
90    cmd.Execute

      ' Fill in tblMaxMultiCaptureSpan

100   strSQL = _
          "INSERT INTO tblMaxMultiCaptureSpan " & _
          "( Species, MaxMultiCaptureSpan ) " & _
          "SELECT Species, Max(Span) AS MaxMultiCaptureSpan " & _
          "From qryMaxMultiCaptureSpan4 " & _
          "WHERE Species = '" & Species & "'" & _
          "GROUP BY Species "

110   cmd.ActiveConnection = CurrentProject.Connection
120   cmd.CommandText = strSQL
130   cmd.Execute

      ' Copy data to tblSpecies.MaxMultiCaptureSpan

      Dim MaxMultiCaptureSpan As Long
140   MaxMultiCaptureSpan = Nz(DLookup("MaxMultiCaptureSpan", "tblMaxMultiCaptureSpan", "Species = '" & Species & "'"))

150   If MaxMultiCaptureSpan = 0 Then
160       strSQL = _
              "UPDATE tblSpecies " & _
              "SET MaxMultiCaptureSpan = Null " & _
              "WHERE Species = '" & Species & "'"
170   Else
180       strSQL = _
              "UPDATE tblSpecies " & _
              "SET MaxMultiCaptureSpan = " & MaxMultiCaptureSpan & " " & _
              "WHERE Species = '" & Species & "'"
190   End If
200   cmd.CommandText = strSQL
210   cmd.Execute

220   If fLog Then
230      If MaxMultiCaptureSpan_old <> MaxMultiCaptureSpan Then
240         log ("Edit span " & Species & " : " & ZLng(MaxMultiCaptureSpan_old) & " > " & ZLng(MaxMultiCaptureSpan))
250      Else
260          log ("Edit span " & Species & " : No change " & ZLng(MaxMultiCaptureSpan))
270      End If
280   End If

290   fSuccess = True

      'DD Error Handler Start
Exit_label:
300        Exit Sub
Err_label:
310        Select Case Err.Number
           Case Else
320           Call LogError( _
                      "basSpecies", _
                      "UpdateSpanSpecies_Retry", _
                      "Update span species has failed", _
                      Silent:=True)
330        End Select
340        Resume Exit_label
      'DD Error Handler End
          
End Sub
