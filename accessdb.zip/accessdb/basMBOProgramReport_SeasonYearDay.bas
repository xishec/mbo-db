'---------------------------------------------------------------------------------------
' Module    : basMBOProgramReport_SeasonYearDay
' Author    : David Davey
'---------------------------------------------------------------------------------------

Option Compare Database
Option Explicit

' Seasons

Const conNonSeason As Integer = -1
Const conWinter  As Integer = 0
Const conSpring  As Integer = 1
Const conSummer  As Integer = 2
Const conFall    As Integer = 3
Const conOwling  As Integer = 4
Const conRTHU    As Integer = 5
Const conNestbox As Integer = 6
Const conSummerNestbox As Integer = 7

Const intSeasonFirst As Integer = -1
Const intSeasonLast  As Integer = 7


'Public datProgramDateFirst()          As Date           ' Date of the first DET sheet for a program
'Public datProgramDateLast()           As Date           ' Date of the last DET sheet for a program

'Public intDayLast As Integer
'Public intDayLast_SeasonYear() ' intSeasonFirst to intSeasonLast, intYearFirst to intYearLast
'Public intDayLast_Season()     ' intSeasonFirst to intSeasonLast

Const intStatSeasonYearDay_BandedBirds As Integer = 0
Const dblStatSeasonYearDay_BandedSpecies As Integer = 1
Const intStatSeasonYearDay_DETSpecies As Integer = 2

Const intStatSeasonYearDay_First As Integer = 0
Const intStatSeasonYearDay_Last As Integer = 2

Dim dblStatSeasonYearDay() ' (intStatSeasonYearDay_First To intStatSeasonYearDay_Last, _
                       ' intSeasonFirst To intSeasonLast, _
                       ' intYearFirst To intYearLast, _
                       ' 0 To intDayLast)


Public Sub MBOProgramReport_SeasonYearDay( _
    ByVal intYearFirst As Integer, _
    ByVal intYearLast As Integer, _
    ByVal strLocation As String, _
    ByRef oBook As Excel.Workbook)

10    On Error GoTo Err_label

20    ReDim dblStatSeasonYearDay(intStatSeasonYearDay_First To intStatSeasonYearDay_Last, _
          intSeasonFirst To intSeasonLast, _
          intYearFirst To intYearLast, _
          0 To intDayLast)

      Dim intSeason As Integer
      Dim strSeason As String
      Dim intYear As Integer
      Dim intDay As Integer
      Dim oSheet As Excel.Worksheet
      Dim rowBase As Long
      Dim intStat As Integer

30    SysCmd acSysCmdSetStatus, "Season Year x Day"

40    For intStat = intStatSeasonYearDay_First To intStatSeasonYearDay_Last
50        For intSeason = intSeasonFirst To intSeasonLast
60            For intYear = intYearFirst To intYearLast
70                  For intDay = 0 To intDayLast
80                        dblStatSeasonYearDay(intStat, intSeason, intYear, intDay) = 0
90                  Next
100           Next
110       Next
120   Next

130   Call MBOProgramReport_SeasonYearDay_BandedBirds(intYearFirst, intYearLast, strLocation)
140   Call MBOProgramReport_SeasonYearDay_Species(intYearFirst, intYearLast, strLocation)

150   For intSeason = intSeasonFirst To intSeasonLast
160       strSeason = toStrSeasonFromIntSeason(intSeason)

170       Set oSheet = InsertSheet(oBook, strSeason)
180       oSheet.Name = strSeason & " Year x Day"
190       With oSheet
          
200       rowBase = 1
          
210       Call MBOProgramReport_SeasonYearDay_Excel(intSeason, strSeason, intYearFirst, intYearLast, intStatSeasonYearDay_BandedBirds, "Banded birds", oBook, oSheet, rowBase)
220       Call MBOProgramReport_SeasonYearDay_Excel(intSeason, strSeason, intYearFirst, intYearLast, dblStatSeasonYearDay_BandedSpecies, "Banded species", oBook, oSheet, rowBase)
230       Call MBOProgramReport_SeasonYearDay_Excel(intSeason, strSeason, intYearFirst, intYearLast, intStatSeasonYearDay_DETSpecies, "DET species", oBook, oSheet, rowBase)
           
240       .columns(2).NumberFormat = "dd mmm"
250       .range(.columns(1), .columns(4 + intYearLast - intYearFirst)).AutoFit
260       .range("A2").Select
270       oBook.Application.ActiveWindow.FreezePanes = True
          
280       End With
290   Next

      'DD Error Handler Start
Exit_label:
300        Exit Sub
Err_label:
310        Select Case Err.Number
           Case Else
320       Call LogError("basMBOProgramReport_SeasonYearDay", "MBOProgramReport_SeasonYearDay")
330        End Select
340        Resume Exit_label
      'DD Error Handler End

End Sub

Private Sub MBOProgramReport_SeasonYearDay_Excel(ByVal intSeason As Integer, ByVal strSeason As String, _
        ByVal intYearFirst As Integer, ByVal intYearLast As Integer, _
        ByVal intStatSeasonYearDay As Integer, ByVal strStat As String, _
        ByRef oBook As Excel.Workbook, ByRef oSheet As Excel.Worksheet, ByRef rowBase As Long)

      Const colSeason As Long = 1
      Const colDate As Long = 2
      Const colDataFirst As Long = 3
      Dim colDataLast As Long
      Dim colPeriod As Long

10    On Error GoTo Err_label

20    SysCmd acSysCmdSetStatus, strSeason & " Year x Day : " & strStat & " => Excel"

30    colDataLast = colDataFirst + intYearLast - intYearFirst
40    colPeriod = colDataLast + 1

      Dim row As Long
      Dim col As Long
      Dim intYear As Integer
      Dim intDay As Integer
      Dim datDate As Date
      Dim dblValue As Double
      Dim rowDataFirst As Long
      Dim rowDataLast As Long

50    row = rowBase

60    With oSheet

70    .Cells(row, colSeason) = "Season"
80    .Cells(row, colDate) = "Date"
90    For intYear = intYearFirst To intYearLast
100       col = colDataFirst + intYear - intYearFirst
110       .Cells(row, col) = intYear
120   Next
130   .Cells(row, colPeriod) = "Period"
140   .Rows(row).Font.Bold = True
150   row = row + 1

160   .Cells(row, 3) = strStat
170   .Cells(row, 3).HorizontalAlignment = xlCenter
180   .range(.Cells(row, colDataFirst), .Cells(row, colDataLast)).Merge
190   .Rows(row).Font.Bold = True
200   row = row + 1

      ' The dates in the A column are standardised to the year 2000 for Spring, Summer, Fall, Owling, Nestbox and to 1999/2000 for Winter
      ' The tricky case is 29th Feb (Winter only) - but it is easy since the periods in Winter are a function of Month
      ' For non-Winter, the true date is the standardised date, with 2000 replaced by the true year
      ' For Winter, compute the period based on the month of the standardised date
      ' May as well process Summer, Nestbox, etc here too


      Dim datProgramDateFrom As Date
      Dim datSheetDateFrom As Date      ' true date
210   datProgramDateFrom = Nz(DLookup("[DateFrom]", "tblPrograms", "[MonitoringProgramSeason] = '" & strSeason & "' AND [YearEx] = " & intYearLast))
220   datSheetDateFrom = DateSerial(intYearLast, Month(datProgramDateFirst_Season(intSeason)), Day(datProgramDateFirst_Season(intSeason)))

230   rowDataFirst = row
240   For intDay = 0 To intDayLast_Season(intSeason)
250       datDate = toDateFromIntDay(intSeason, intDay)
260       .Cells(row, colSeason) = strSeason
270       .Cells(row, colDate) = datDate
280       For intYear = intYearFirst To intYearLast
290     col = colDataFirst + intYear - intYearFirst
300     dblValue = dblStatSeasonYearDay(intStatSeasonYearDay, intSeason, intYear, intDay)
310     If dblValue > 0 Then
320         .Cells(row, col) = dblValue
330     End If
340       Next
          
          Dim intPeriod As Integer
350       Select Case strSeason
          Case "Spring", "Fall", "Owling"
360           If datProgramDateFrom <> 0 And datSheetDateFrom + intDay >= datProgramDateFrom Then
370                 intPeriod = toPeriod(strSeason, datSheetDateFrom + intDay, datProgramDateFrom)
380                 .Cells(row, colPeriod) = intPeriod
390                 If strSeason = "Owling" Then
400                   .Cells(row, colPeriod + 1) = "F" & 8 + intPeriod
410                 End If
420           End If
430       Case "Winter"
440           Select Case Month(datDate)
              Case 7 To 11                          ' Jul - Nov
450               intPeriod = 1
460           Case 12
470               intPeriod = 2                      ' Dec
480           Case 1 To 3
490               intPeriod = 2 + Month(datDate)   ' Jan, Feb, Mar
500           Case Else
510               intPeriod = 5                      ' Apr - Jun
520           End Select
530           .Cells(row, colPeriod) = intPeriod
540       Case "Summer", "Nestbox", "SummerNestbox"
550           Select Case Month(datDate)
              Case 1 To 6
560               intPeriod = 1
570           Case 7 To 12
580               intPeriod = 2
590           End Select
600           .Cells(row, colPeriod) = intPeriod
610       End Select

620       row = row + 1
630   Next

640   rowDataLast = row - 1
650   .Cells(rowDataLast + 1, 2) = "max"
      ' .Cells(rowDataLast + 2, 2) = "min"

      ' Highlight maximums for each year

      Dim dblMax As Double

660   For col = colDataFirst To colDataLast
670       dblMax = 0
680       For row = rowDataFirst To rowDataLast
690     If dblMax < .Cells(row, col) Then
700   dblMax = .Cells(row, col)
710     End If
720       Next
730       If dblMax > 0 Then
740     For row = rowDataFirst To rowDataLast
750   If dblMax = .Cells(row, col) Then
760       .Cells(row, col).Interior.Color = vbYellow
770   End If
780     Next
790     .Cells(rowDataLast + 1, col) = dblMax
800       End If
810   Next

      '      ' Highlight minimums for each year
      '
      '      Dim dblMin As Double
      '
      '590   For col = colDataFirst To colDataLast
      '600       dblMin = 99999
      '610       For row = rowDataFirst To rowDataLast
      '620           If dblMin > .Cells(row, col) Then
      '630               dblMin = .Cells(row, col)
      '640           End If
      '650       Next
      '660       If dblMin < 99999 Then
      '670           For row = rowDataFirst To rowDataLast
      '680               If dblMin = .Cells(row, col) Then
      '690                   .Cells(row, col).Interior.color = RGB(128, 255, 128)
      '700               End If
      '710           Next
      '720           .Cells(rowDataLast + 2, col) = dblMin
      '730       End If
      '740   Next

820   rowBase = rowDataLast + 4

830   End With

840   SysCmd acSysCmdClearStatus

      'DD Error Handler Start
Exit_label:
850        Exit Sub
Err_label:
860        Select Case Err.Number
           Case Else
870       Call LogError("basMBOProgramReport_SeasonYearDay", "MBOProgramReport_SeasonYearDay_Excel")
880        End Select
890        Resume Exit_label
      'DD Error Handler End

        End Sub


'---------------------------------------------------------------------------------------
' MBOProgramReport_SeasonYearDay_BandedBirds
'---------------------------------------------------------------------------------------
 
Private Sub MBOProgramReport_SeasonYearDay_BandedBirds( _
        ByVal intYearFirst As Integer, ByVal intYearLast As Integer, _
        ByVal strLocation As String)
        
10    On Error GoTo Err_label

20    SysCmd acSysCmdSetStatus, "Season Year x Day: Banded Birds"

      Dim intSeason As Integer
      Dim intDay As Integer
      Dim strSQL As String
      Dim qdf As DAO.QueryDef
      Dim rst As DAO.Recordset
      Dim intYear As Integer
      Dim datDate As Date

      ' Season x Year x Day

30    strSQL = "qryMBOProgramReport_SeasonYearDay_Birds"
40    Set qdf = CurrentDb.QueryDefs(strSQL)
50    qdf("argLocation") = "MBO"          ' defensive
60    qdf("argYearFirst") = intYearFirst
70    qdf("argYearLast") = intYearLast
80    Set rst = qdf.OpenRecordset

90    Do While Not rst.EOF
100       intSeason = toIntSeasonFromStrSeason(Nz(rst("Season")))
110       intYear = Nz(rst("YearEx"))
120       datDate = Nz(rst("DateEx"))
130       intDay = toIntDayFromDate(intSeason, datDate)
140       If intDay >= 0 Then
150           dblStatSeasonYearDay(intStatSeasonYearDay_BandedBirds, intSeason, intYear, intDay) = Nz(rst("Banded")) ' Loading zeros is harmless
160       End If
170       rst.MoveNext
180   Loop
190   rst.Close
200   Set rst = Nothing

      'DD Error Handler Start
Exit_label:
210        Exit Sub
Err_label:
220        Select Case Err.Number
           Case Else
230             Call LogError("basMBOProgramReport_SeasonYearDay", "MBOProgramReport_SeasonYearDay_BandedBirds")
240        End Select
250        Resume Exit_label
      'DD Error Handler End
        
End Sub

'---------------------------------------------------------------------------------------
' MBOProgramReport_SeasonYearPeriod_Species
'---------------------------------------------------------------------------------------
' Count the species for various statistics

Private Sub MBOProgramReport_SeasonYearDay_Species( _
    ByVal intYearFirst As Integer, _
    ByVal intYearLast As Integer, _
    ByVal strLocation As String)

10    On Error GoTo Err_label

20    On Error GoTo Err_label
          
      Dim strSQL As String
      Dim qdf As DAO.QueryDef
      Dim rst As DAO.Recordset
      Dim intYear As Integer
      Dim intDay As Integer
      Dim intSeason As Integer
      Dim strSeason As String
      Dim strSpecies As String
      Dim stat As Integer                          ' 0 to 1
      Dim lngStat(0 To 1) As Long
      Dim dicStatSpecies(0 To 1) As Scripting.Dictionary
      Dim intSeason_Previous As Integer
      Dim intYear_previous As Integer
      Dim intDay_previous As Integer
      Dim datDate As Date

30    SysCmd acSysCmdSetStatus, "Season Year x Day : Species"

40    For stat = 0 To 1
50       Set dicStatSpecies(stat) = New Scripting.Dictionary
60    Next

70    intSeason_Previous = -99
80    intYear_previous = 0
90    intDay_previous = -99

100   strSQL = "qryMBOProgramReport_SeasonYearDay_Species"
          
110   Set qdf = CurrentDb.QueryDefs(strSQL)
120   qdf.Parameters("argLocation").value = strLocation
130   qdf.Parameters("argYearFirst").value = intYearFirst
140   qdf.Parameters("argYearLast").value = intYearLast
150   Set rst = qdf.OpenRecordset

160   Do While Not rst.EOF
170       intSeason = toIntSeasonFromStrSeason(Nz(rst("Season")))
180       intYear = Nz(rst("YearEx"))
190       datDate = Nz(rst("DateEx"))
200       intDay = toIntDayFromDate(intSeason, datDate)
210       If intDay < 0 Then GoTo Continue_label
220       strSpecies = Nz(rst("Species"))
230       lngStat(0) = Nz(rst("Banded"))
240       lngStat(1) = Nz(rst("DET"))
          
250       If intSeason <> intSeason_Previous Or intYear <> intYear_previous Then
        
              ' L1 control break OR first record
        
260           If intSeason_Previous <> -99 Then
                         
                  ' F2 then F1 (N.B. F1 is empty)
                  
270               dblStatSeasonYearDay(dblStatSeasonYearDay_BandedSpecies, intSeason_Previous, intYear_previous, intDay_previous) = CountSpeciesInDictionary(dicStatSpecies(0))
280               dblStatSeasonYearDay(intStatSeasonYearDay_DETSpecies, intSeason_Previous, intYear_previous, intDay_previous) = CountSpeciesInDictionary(dicStatSpecies(1))
        
290           End If
                  
              ' H2 then H1
              
300           For stat = 0 To 1
310               dicStatSpecies(stat).RemoveAll
320           Next
              
330      ElseIf intDay <> intDay_previous Then
         
              ' L2 control break
              
              ' F2
              
340           dblStatSeasonYearDay(dblStatSeasonYearDay_BandedSpecies, intSeason_Previous, intYear_previous, intDay_previous) = CountSpeciesInDictionary(dicStatSpecies(0))
350           dblStatSeasonYearDay(intStatSeasonYearDay_DETSpecies, intSeason_Previous, intYear_previous, intDay_previous) = CountSpeciesInDictionary(dicStatSpecies(1))
            
              ' H2
              
360           For stat = 0 To 1
370               dicStatSpecies(stat).RemoveAll
380           Next
              
390      End If
         
         ' Detail
                    
400       For stat = 0 To 1
410           If lngStat(stat) > 0 Then
420               If Not dicStatSpecies(stat).Exists(strSpecies) Then
430                   Call dicStatSpecies(stat).Add(strSpecies, strSpecies)
440               End If
450           End If
460       Next
          
470       intSeason_Previous = intSeason
480       intYear_previous = intYear
490       intDay_previous = intDay

Continue_label:
500       rst.MoveNext
510   Loop

520   If intDay_previous <> 0 Then
          
          ' F2 then F1 (N.B. F1 is empty)
          
530       dblStatSeasonYearDay(dblStatSeasonYearDay_BandedSpecies, intSeason_Previous, intYear_previous, intDay_previous) = CountSpeciesInDictionary(dicStatSpecies(0))
540       dblStatSeasonYearDay(intStatSeasonYearDay_DETSpecies, intSeason_Previous, intYear_previous, intDay_previous) = CountSpeciesInDictionary(dicStatSpecies(1))

550   End If

560   rst.Close
570   Set rst = Nothing
                   
580   SysCmd acSysCmdClearStatus
          
      'DD Error Handler Start
Exit_label:
590        Exit Sub
Err_label:
600        Select Case Err.Number
           Case Else
610       Call LogError("basMBOProgramReport_SeasonYearDay", "MBOProgramReport_SeasonYearDay_Species")
620        End Select
630        Resume Exit_label
      'DD Error Handler End
          
    End Sub
