Option Compare Database
Option Explicit

'---------------------------------------------------------------------------------------
' MultiImport
'---------------------------------------------------------------------------------------

Public Sub MultiPCImport()
10    On Error GoTo Err_label

      Dim oExcel As Excel.Application
      Dim oBook As Excel.Workbook

      Dim strReport As String
20    strReport = ""

      Dim strSetting_Filepath As String             ' Input
      Dim strFilepath As String                     ' Returns

      ' Browse for the MultiPC Excel file

30    strSetting_Filepath = "MultiPC_Filepath"
40    Call MultiPC_BrowseForExcelFile(strSetting_Filepath, strFilepath)
50    If strFilepath = "" Then GoTo Exit_label

      ' Open the Excel workbook

60    Set oExcel = New Excel.Application
70    oExcel.Visible = False

80    Set oBook = oExcel.Workbooks.Open(strFilepath)

      ' Captures

      Dim strReport_Captures As String
90    Call multiPCImport_Captures(oBook, strReport_Captures)
100   strReport = strReport & IIf(strReport_Captures = "", "", vbCrLf & vbCrLf) & strReport_Captures

      ' DET Daily

      Dim strReport_DETDaily As String
110   Call multiPCImport_DETDaily(oBook, strReport_DETDaily)
120   strReport = strReport & IIf(strReport_DETDaily = "", "", vbCrLf & vbCrLf) & strReport_DETDaily

      ' DET Species

      Dim strReport_DETSpecies As String
130   Call multiPCImport_DETSpecies(oBook, strReport_DETSpecies)
140   strReport = strReport & IIf(strReport_DETSpecies = "", "", vbCrLf & vbCrLf) & strReport_DETSpecies

      ' DET Net Hours

      Dim strReport_DETNetHours As String
150   Call multiPCImport_DETNetHours(oBook, strReport_DETNetHours)
160   strReport = strReport & IIf(strReport_DETNetHours = "", "", vbCrLf & vbCrLf) & strReport_DETNetHours

170   oBook.Close
180   oExcel.Quit

190   If strReport <> "" Then
200       Call MsgBox(strReport, vbOKOnly)
210   End If

          'DD Error Handler Start
Exit_label:
220       Exit Sub
Err_label:
230       Select Case Err.Number
          Case Else
240      Call LogError("basMultiPC", "MultiImport")
250       End Select
260       Resume Exit_label
          ' DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' multiPCImport_Captures
'---------------------------------------------------------------------------------------
' Call multiPCImport_Captures()

Private Sub multiPCImport_Captures(ByRef oBook As Excel.Workbook, ByRef strReport As String)
10    On Error GoTo Err_label

      Dim lngCountBandings As Long
      Dim lngCountRecaps As Long
      Dim lngCountDuplicateNewBands_InCaptures As Long
      Dim lngCountDuplicateNewBands_InBandings As Long
      Dim lngCountDuplicateRecaps_InCaptures   As Long
      Dim lngCountDuplicateRecaps_InRecaps  As Long

20    lngCountBandings = 0
30     lngCountRecaps = 0
40     lngCountDuplicateNewBands_InCaptures = 0
50     lngCountDuplicateNewBands_InBandings = 0
60     lngCountDuplicateRecaps_InCaptures = 0
70     lngCountDuplicateRecaps_InRecaps = 0

      ' Open the "Captures" worksheet

      Dim oSheet As Excel.Worksheet
      Dim intSheet As Integer
      Dim fMBOSheetExists As Boolean

80    fMBOSheetExists = False
90    For intSheet = 1 To oBook.Sheets.count
100       If oBook.Sheets(intSheet).Name = "Captures" Then
110     Set oSheet = oBook.Sheets(intSheet)
120     fMBOSheetExists = True
130       End If
140   Next
150   If Not fMBOSheetExists Then
160       MsgBox "The Excel workbook does not have an Captures worksheet", vbExclamation, "MultiPC"
170       GoTo Exit_label
180   End If

      ' Load dicFieldnames with the field names in qryMultiPC_Captures

      Dim qdf As DAO.QueryDef
      Dim rst As DAO.Recordset

190   Set qdf = CurrentDb.QueryDefs("qryMultiPC_Captures")
200   qdf.Parameters("argFrom") = DateSerial(1950, 1, 1)
210   qdf.Parameters("argTo") = DateSerial(3000, 1, 1)
220   Set rst = qdf.OpenRecordset

      Dim dicFieldnames As Scripting.Dictionary
      Dim i As Integer

230   Set dicFieldnames = New Scripting.Dictionary

240   For i = 0 To rst.Fields.count - 1
250       dicFieldnames.Add rst.Fields(i).Name, 0
260   Next

      ' Load the dicColumns with key=fieldname,  value=Excel column

      Dim dicColumns As Scripting.Dictionary
270   Set dicColumns = New Scripting.Dictionary

      Dim colEnd As Long
280   colEnd = oSheet.Cells(1, oSheet.columns.count).End(xlToLeft).column

      Dim strFieldname As String

      Dim col As Integer
290   For col = 1 To colEnd
300       strFieldname = oSheet.Cells(1, col)
310       If strFieldname <> "" Then
320     If dicFieldnames.Exists(strFieldname) Then
330         dicColumns.Add strFieldname, col
340     End If
350       End If
360   Next

      ' Verify we have the columns:  Disposition   BandPrefix   BandSuffix   CaptureDate   Program

370   If Not (dicColumns.Exists("Disposition") And dicColumns.Exists("BandPrefix") And dicColumns.Exists("BandSuffix") And dicColumns.Exists("CaptureDate") And dicColumns.Exists("Program")) Then
380       Call MsgBox("Error:  One or more of the following columns is missing" & vbCrLf & _
                " Disposition  BandPrefix  BandSuffix  CaptureDate  Program ", vbOKOnly)
390       GoTo Exit_label
400   End If


      Dim colDisposition As Integer
410   colDisposition = dicColumns("Disposition")

      Dim rstSheetNewBands As DAO.Recordset
      Dim rstSheetRecaps As DAO.Recordset
      ' Dim rst As DAO.Recordset
      Dim intCountDuplicateNewBands As Integer
      Dim intCountDuplicateRecaps   As Integer

420   Set rstSheetNewBands = CurrentDb.OpenRecordset("tblSheetNewBandsMultiSize_v2", dbOpenDynaset)
430   Set rstSheetRecaps = CurrentDb.OpenRecordset("tblSheetRecaps_v2", dbOpenDynaset)

      Dim row As Long
440   row = 2

      Dim strWhere As String
      Dim strDisposition As String
      Dim strBandPrefix As String
      Dim strBandSuffix As String
      Dim strCaptureDate As String           ' format   mm/dd/yyyy
      Dim strProgram As String

      ' Process the records from the Excel worksheet

450   Do
460       strDisposition = Nz(oSheet.Cells(row, colDisposition))
470       If strDisposition = "" Then Exit Do
480       strBandPrefix = Nz(oSheet.Cells(row, dicColumns("BandPrefix")))
490       strBandSuffix = Nz(oSheet.Cells(row, dicColumns("BandSuffix")))
500       SysCmd acSysCmdSetStatus, row
510       Select Case strDisposition
          Case "1", "4", "8"
520           strWhere = "[BandPrefix] = '" & strBandPrefix & "' AND " & _
                  " [BandSuffix] = '" & strBandSuffix & "'"
          
530           Set rst = rstSheetNewBands
540           If DCount("*", "tblCaptures", strWhere) > 0 Then
550               lngCountDuplicateNewBands_InCaptures = lngCountDuplicateNewBands_InCaptures + 1
560               GoTo Continue_label
570           End If
580           If DCount("*", "tblSheetNewBandsMultiSize_v2", strWhere) > 0 Then
590               lngCountDuplicateNewBands_InBandings = lngCountDuplicateNewBands_InBandings + 1
600               GoTo Continue_label
610           End If
620           lngCountBandings = lngCountBandings + 1
630        Case "R", "F"
640           strCaptureDate = Nz(oSheet.Cells(row, dicColumns("CaptureDate")))  ' format yyyy-mm-dd
650           strProgram = Nz(oSheet.Cells(row, dicColumns("Program")))
              
660           Set rst = rstSheetRecaps
          
670           strWhere = "[BandPrefix] = '" & strBandPrefix & "' AND " & _
                         " [BandSuffix] = '" & strBandSuffix & "' AND " & _
                         " [CaptureDate] = #" & strCaptureDate & "# AND " & _
                         " [Program] = '" & strProgram & "'"
680           If DCount("*", "tblCaptures", strWhere) > 0 Then
690               lngCountDuplicateRecaps_InCaptures = lngCountDuplicateRecaps_InCaptures + 1
700               GoTo Continue_label
710           End If
        
              Dim strMMDD As String
              Dim strYYYY As String
        
720           strMMDD = Mid(strCaptureDate, 6, 2) & Right(strCaptureDate, 2)
730           strYYYY = Left(strCaptureDate, 4)
740           strWhere = "[BandPrefix] = '" & strBandPrefix & "' AND " & _
                         " [BandSuffix] = '" & strBandSuffix & "' AND " & _
                         " [CaptureDate] = '" & strMMDD & "' AND " & _
                         " [CaptureYear] = '" & strYYYY & "' AND " & _
                         " [Program] = '" & strProgram & "'"
750           If DCount("*", "tblSheetRecaps_v2", strWhere) > 0 Then
760               lngCountDuplicateRecaps_InRecaps = lngCountDuplicateRecaps_InRecaps + 1
770               GoTo Continue_label
780           End If
790           lngCountRecaps = lngCountRecaps + 1
800       End Select

810       rst.AddNew
         
          Dim key As Variant
820       For Each key In dicColumns.Keys
830           strFieldname = CStr(key)
840           col = dicColumns(key)
        
850           Select Case strFieldname
              Case "CaptureDate"
860               rst.Fields("CaptureDate") = Format(Nz(oSheet.Cells(row, col)), "mmdd")
870               rst.Fields("CaptureYear") = Format(Nz(oSheet.Cells(row, col)), "yyyy")
880           Case "WeightTime"
890               rst.Fields("WeightTime") = Left(Format(Nz(oSheet.Cells(row, col)), "hhnn"), 3)
900           Case "PresentCondition", "HowObtainedCode"
910               If strDisposition = "R" Or strDisposition = "F" Then
920                   rst.Fields(strFieldname) = Nz(oSheet.Cells(row, col))
930               End If
940           Case Else
950               rst.Fields(strFieldname) = Nz(oSheet.Cells(row, col))
960           End Select
970       Next
        
980       rst.Update
Continue_label:
990       row = row + 1

1000  Loop
1010  rstSheetNewBands.Close
1020  rstSheetRecaps.Close
1030  SysCmd acSysCmdClearStatus


1040  strReport = lngCountBandings & " bandings imported" & vbCrLf & _
      lngCountRecaps & " recaps imported" & vbCrLf
1050  If lngCountDuplicateNewBands_InCaptures <> 0 Then
1060      strReport = strReport & lngCountDuplicateNewBands_InCaptures & " duplicate bandings already in the Captures table not imported" & vbCrLf
1070  End If
1080  If lngCountDuplicateNewBands_InBandings <> 0 Then
1090      strReport = strReport & lngCountDuplicateNewBands_InBandings & " duplicate bandings already in the Bandings sheet not imported" & vbCrLf
1100  End If
1110  If lngCountDuplicateRecaps_InCaptures <> 0 Then
1120      strReport = strReport & lngCountDuplicateRecaps_InCaptures & " duplicate bandings already in the Captures table not imported" & vbCrLf
1130  End If
1140  If lngCountDuplicateRecaps_InRecaps <> 0 Then
1150      strReport = strReport & lngCountDuplicateRecaps_InRecaps & " duplicate recaps already in the Recaps sheet not imported"
1160  End If

1170  If IsLoaded("frmSheetNewBandsMultiSize_v2") Then
1180      Forms("frmSheetNewBandsMultiSize_v2").Requery
1190  End If

1200  If IsLoaded("frmSheetRecaps_v2") Then
1210      Forms("frmSheetRecaps_v2").Requery
1220  End If

          'DD Error Handler Start
Exit_label:
1230      Exit Sub
Err_label:
1240      Select Case Err.Number
          Case Else
1250     Call LogError("basMultiPC", "multiPCImport_Captures")
1260      End Select
1270      Resume Exit_label
          ' DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' multiPCImport_DETDaily
'---------------------------------------------------------------------------------------
' Dim oBook as Excel.workbook                ' input
' Dim strReport as string                    ' returns
' Call multiPCImport_DETDaily( oBook, strReport)

Private Sub multiPCImport_DETDaily(ByRef oBook As Excel.Workbook, ByRef strReport)
10    On Error GoTo Err_label


      Dim lngCountDETDaily_Imported As Long
      Dim lngCountDETDaily_NotImported As Long

20    lngCountDETDaily_Imported = 0
30    lngCountDETDaily_NotImported = 0

      ' Open the "DETDaily" worksheet

      Dim oSheet As Excel.Worksheet
      Dim intSheet As Integer
      Dim fMBOSheetExists As Boolean

40    fMBOSheetExists = False
50    For intSheet = 1 To oBook.Sheets.count
60        If oBook.Sheets(intSheet).Name = "DETDaily" Then
70      Set oSheet = oBook.Sheets(intSheet)
80      fMBOSheetExists = True
90        End If
100   Next
110   If Not fMBOSheetExists Then
120       MsgBox "The Excel workbook does not have a DETDaily worksheet", vbExclamation, "MultiPC"
130       GoTo Exit_label
140   End If

      ' Load dicFieldnames with the field names in qryMultiPC_DETDaily

      Dim qdf As DAO.QueryDef
      Dim rst As DAO.Recordset

150   Set qdf = CurrentDb.QueryDefs("qryMultiPC_DETDaily")
160   qdf.Parameters("argFrom") = DateSerial(1950, 1, 1)
170   qdf.Parameters("argTo") = DateSerial(3000, 1, 1)
180   Set rst = qdf.OpenRecordset

      Dim dicFieldnames As Scripting.Dictionary
      Dim i As Integer

190   Set dicFieldnames = New Scripting.Dictionary
200   For i = 0 To rst.Fields.count - 1
210       dicFieldnames.Add rst.Fields(i).Name, 0
220   Next

      ' Load the dicColumns with key=fieldname,  value=Excel column

      Dim dicColumns As Scripting.Dictionary
230   Set dicColumns = New Scripting.Dictionary

      Dim colEnd As Long
240   colEnd = oSheet.Cells(1, oSheet.columns.count).End(xlToLeft).column

      Dim strFieldname As String

      Dim col As Integer
250   For col = 1 To colEnd
260       strFieldname = oSheet.Cells(1, col)
270       If strFieldname <> "" Then
280       If dicFieldnames.Exists(strFieldname) Then
290           dicColumns.Add strFieldname, col
300       End If
310       End If
320   Next

      ' Verify we have the columns:  Location   Program   DateEx

330   If Not (dicColumns.Exists("Location") And dicColumns.Exists("Location") And dicColumns.Exists("DateEx")) Then
340       Call MsgBox("Error:  One or more of the following columns is missing" & vbCrLf & _
                      " Disposition  Location   Program   DateEx ", vbOKOnly)
350       GoTo Exit_label
360   End If

      Dim row As Long
370   row = 2

      Dim strWhere As String
      Dim strLocation As String
      Dim strProgram As String
      Dim strDateEx As String           ' format   yyyy-mm-dd
      Dim datDateEx As Date
      Dim key As Variant

      ' Process the records from the Excel worksheet

380   Do
390       strLocation = Nz(oSheet.Cells(row, dicColumns("Location")))
400       If strLocation = "" Then Exit Do
410       strProgram = Nz(oSheet.Cells(row, dicColumns("Program")))
420       datDateEx = Nz(oSheet.Cells(row, dicColumns("DateEx")))

430       strWhere = "[Location] = '" & strLocation & "' AND " & _
                     " [Program] = '" & strProgram & "' AND " & _
                     " [DateEx] = #" & Format(datDateEx, "mm/dd/yyyy") & "#"
          Dim strSQL As String
440       strSQL = "SELECT * FROM tblDETDaily WHERE " & strWhere
                     
450       Set rst = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)
460       If rst.EOF Then
470           rst.AddNew
480           For Each key In dicColumns.Keys
490               strFieldname = CStr(key)
500               col = dicColumns(key)
510               rst.Fields(strFieldname) = Nz(oSheet.Cells(row, col))
520           Next
530           rst.Update
                      
              
540           lngCountDETDaily_Imported = lngCountDETDaily_Imported + 1
550       Else

              Dim fNonKeyFieldsAllEmpty As Boolean
560           fNonKeyFieldsAllEmpty = True
570           For Each key In dicColumns.Keys
580               strFieldname = CStr(key)
590               Select Case strFieldname
                  Case "Location", "Program", "DateEx"
600               Case Else
                      Dim lngValue As Long
610                   lngValue = Nz(rst(strFieldname), 0)
620                   If lngValue <> 0 Then fNonKeyFieldsAllEmpty = False
630               End Select
640           Next
         
650           If fNonKeyFieldsAllEmpty Then
660               rst.Edit
670               For Each key In dicColumns.Keys
680                   strFieldname = CStr(key)
690                   col = dicColumns(key)
        
700                   Select Case strFieldname
                      Case "Location", "Program", "DateEx"
710                   Case Else
720                       rst.Fields(strFieldname) = Nz(oSheet.Cells(row, col))
730                   End Select
740               Next
750               rst.Update
760               lngCountDETDaily_Imported = lngCountDETDaily_Imported + 1
770           Else
780               lngCountDETDaily_NotImported = lngCountDETDaily_NotImported + 1
790           End If
800       End If

810   rst.Close
820       row = row + 1
830   Loop

840   strReport = lngCountDETDaily_Imported & " DET Daily records imported"
850   If lngCountDETDaily_NotImported <> 0 Then
860       strReport = strReport & vbCrLf & lngCountDETDaily_NotImported & " DET Daily records not imported"
870   End If

880   If IsLoaded("frmDETViewDaily2") Then
890       Forms("frmDETViewDaily2").Requery
900   End If

          'DD Error Handler Start
Exit_label:
910       Exit Sub
Err_label:
920       Select Case Err.Number
          Case Else
930      Call LogError("basMultiPC", "multiPCImport_DETDaily")
940       End Select
950       Resume Exit_label
          ' DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' multiPCImport_DETSpecies
'---------------------------------------------------------------------------------------
' Dim oBook as Excel.workbook                ' input
' Dim strReport as string                    ' returns
' Call multiPCImport_DETSpecies( oBook, strReport)

Private Sub multiPCImport_DETSpecies(ByRef oBook As Excel.Workbook, ByRef strReport)
10    On Error GoTo Err_label

      Dim lngCountImported As Long
      Dim lngCountNotImported As Long

20    lngCountImported = 0
30    lngCountNotImported = 0

      ' Open the "DETSpecies" worksheet

      Dim oSheet As Excel.Worksheet
      Dim intSheet As Integer
      Dim fMBOSheetExists As Boolean

40    fMBOSheetExists = False
50    For intSheet = 1 To oBook.Sheets.count
60        If oBook.Sheets(intSheet).Name = "DETSpecies" Then
70            Set oSheet = oBook.Sheets(intSheet)
80            fMBOSheetExists = True
90        End If
100   Next
110   If Not fMBOSheetExists Then
120       MsgBox "The Excel workbook does not have a DETSpecies worksheet", vbExclamation, "MultiPC"
130       GoTo Exit_label
140   End If

      ' Load dicFieldnames with the field names in qryMultiPC_DETSpecies

      Dim qdf As DAO.QueryDef
      Dim rst As DAO.Recordset

150   Set qdf = CurrentDb.QueryDefs("qryMultiPC_DETSpecies")
160   qdf.Parameters("argFrom") = DateSerial(1950, 1, 1)
170   qdf.Parameters("argTo") = DateSerial(3000, 1, 1)
180   Set rst = qdf.OpenRecordset

      Dim dicFieldnames As Scripting.Dictionary
      Dim i As Integer

190   Set dicFieldnames = New Scripting.Dictionary
200   For i = 0 To rst.Fields.count - 1
210       dicFieldnames.Add rst.Fields(i).Name, 0
220   Next

      ' Load the dicColumns with key=fieldname,  value=Excel column

      Dim dicColumns As Scripting.Dictionary
230   Set dicColumns = New Scripting.Dictionary

      Dim colEnd As Long
240   colEnd = oSheet.Cells(1, oSheet.columns.count).End(xlToLeft).column

      Dim strFieldname As String

      Dim col As Integer
250   For col = 1 To colEnd
260       strFieldname = oSheet.Cells(1, col)
270       If strFieldname <> "" Then
280           If dicFieldnames.Exists(strFieldname) Then
290               dicColumns.Add strFieldname, col
300           End If
310       End If
320   Next

      ' Verify we have the columns:  Location   Program   DateEx   Species

330   If Not (dicColumns.Exists("Location") And dicColumns.Exists("Program") And dicColumns.Exists("DateEx") And dicColumns.Exists("Species")) Then
340       Call MsgBox("Error:  One or more of the following columns is missing" & vbCrLf & _
                      " Location   Program   DateEx   Species", vbOKOnly)
350       GoTo Exit_label
360   End If

      Dim row As Long
370   row = 2

      Dim strWhere As String
      Dim strLocation As String
      Dim strProgram As String
      ' Dim strDateEx As String
      Dim datDateEx As Date
      Dim strSpecies As String
      Dim key As Variant

      ' Process the records from the Excel worksheet

380   Do
390       strLocation = Nz(oSheet.Cells(row, dicColumns("Location")))
400       If strLocation = "" Then Exit Do
410       strProgram = Nz(oSheet.Cells(row, dicColumns("Program")))
420       datDateEx = Nz(oSheet.Cells(row, dicColumns("DateEx")))
430       strSpecies = Nz(oSheet.Cells(row, dicColumns("Species")))

440       strWhere = "[Location] = '" & strLocation & "' AND " & _
                     " [Program] = '" & strProgram & "' AND " & _
                     " [DateEx] = #" & Format(datDateEx, "mm/dd/yyyy") & "# AND " & _
                     " [Species] = '" & strSpecies & "'"
          Dim strSQL As String
450       strSQL = "SELECT * FROM tblDETSpecies WHERE " & strWhere
                     
460       Set rst = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)
470       If rst.EOF Then
480           rst.AddNew
490           For Each key In dicColumns.Keys
500               strFieldname = CStr(key)
510               col = dicColumns(key)
520               rst.Fields(strFieldname) = Nz(oSheet.Cells(row, col))
530           Next
540           rst.Update
              
              ' Referential Integrity
              
550           strWhere = "[Location] = '" & strLocation & "' AND " & _
                     " [Program] = '" & strProgram & "' AND " & _
                     " [DateEx] = #" & Format(datDateEx, "mm/dd/yyyy") & "#"
560           If DCount("*", "tblDETDaily", strWhere) = 0 Then

570               strSQL = "INSERT INTO tblDETDaily (Location, Program, DateEx) VALUES ( " & _
                      "'" & strLocation & "','" & strProgram & "',#" & Format(datDateEx, "mm/dd/yyyy") & "#"
580               CurrentDb.Execute strSQL
590           End If
                      
600           lngCountImported = lngCountImported + 1
610       Else
              Dim fNonKeyFieldsAllEmpty As Boolean
620           fNonKeyFieldsAllEmpty = True
630           For Each key In dicColumns.Keys
640               strFieldname = CStr(key)
650               Select Case strFieldname
                  Case "Location", "Program", "DateEx", "Species"
660               Case "Banded", "Repeats", "Returns", "Observed3", "Observed4"
670               Case Else
                      Dim lngValue As Long
680                   lngValue = Nz(rst(strFieldname), 0)
690                   If lngValue <> 0 Then fNonKeyFieldsAllEmpty = False
700               End Select
710           Next
              
720           If fNonKeyFieldsAllEmpty Then
730               rst.Edit
740               For Each key In dicColumns.Keys
750                   strFieldname = CStr(key)
760                   col = dicColumns(key)
        
770                   Select Case strFieldname
                      Case "Location", "Program", "DateEx", "Species"
                      
780                   Case Else
790                       rst.Fields(strFieldname) = Nz(oSheet.Cells(row, col))
800                   End Select
810               Next
820               rst.Update
830               lngCountImported = lngCountImported + 1
840           Else
850               lngCountNotImported = lngCountNotImported + 1
860           End If
870       End If

880   rst.Close
890       row = row + 1
900   Loop

910   strReport = lngCountImported & " DET Species records imported"
920   If lngCountNotImported <> 0 Then
930       strReport = strReport & vbCrLf & lngCountNotImported & " DET Species records not imported"
940   End If

950   If IsLoaded("frmDETViewDaily2") Then
960       Forms("frmDETViewDaily2").Requery
970   End If

          'DD Error Handler Start
Exit_label:
980       Exit Sub
Err_label:
990       Select Case Err.Number
          Case Else
1000     Call LogError("basMultiPC", "multiPCImport_DETSpecies")
1010      End Select
1020      Resume Exit_label
          ' DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' multiPCImport_DETNetHours
'---------------------------------------------------------------------------------------
' Dim oBook as Excel.workbook                ' input
' Dim strReport as string                    ' returns
' Call multiPCImport_DETNetHours( oBook, strReport)
'
' tblDETHours
' ----------------------------
' IDDETNetHours     AutoNumber
' Program    String  PK
' Location   String  PK
' DateEx     Date    PK
' NetID      String  PK
' NetHours   Long    there is only one non-key field

Private Sub multiPCImport_DETNetHours(ByRef oBook As Excel.Workbook, ByRef strReport)
10    On Error GoTo Err_label

      Dim lngCountImported As Long
      Dim lngCountNotImported As Long

20    lngCountImported = 0
30    lngCountNotImported = 0

      ' Open the "DETNetHours" worksheet

      Dim oSheet As Excel.Worksheet
      Dim intSheet As Integer
      Dim fMBOSheetExists As Boolean

40    fMBOSheetExists = False
50    For intSheet = 1 To oBook.Sheets.count
60        If oBook.Sheets(intSheet).Name = "DETNetHours" Then
70            Set oSheet = oBook.Sheets(intSheet)
80            fMBOSheetExists = True
90        End If
100   Next
110   If Not fMBOSheetExists Then
120       MsgBox "The Excel workbook does not have a DETNetHours worksheet", vbExclamation, "MultiPC"
130       GoTo Exit_label
140   End If

      ' Load dicFieldnames with the field names in qryMultiPC_DETSpecies

      Dim qdf As DAO.QueryDef
      Dim rst As DAO.Recordset

150   Set qdf = CurrentDb.QueryDefs("qryMultiPC_DETNetHours")
160   qdf.Parameters("argFrom") = DateSerial(1950, 1, 1)
170   qdf.Parameters("argTo") = DateSerial(3000, 1, 1)
180   Set rst = qdf.OpenRecordset

      Dim dicFieldnames As Scripting.Dictionary
      Dim i As Integer

190   Set dicFieldnames = New Scripting.Dictionary
200   For i = 0 To rst.Fields.count - 1
210       dicFieldnames.Add rst.Fields(i).Name, 0
220   Next

      ' Load the dicColumns with key=fieldname,  value=Excel column

      Dim dicColumns As Scripting.Dictionary
230   Set dicColumns = New Scripting.Dictionary

      Dim colEnd As Long
240   colEnd = oSheet.Cells(1, oSheet.columns.count).End(xlToLeft).column

      Dim strFieldname As String

      Dim col As Integer
250   For col = 1 To colEnd
260       strFieldname = oSheet.Cells(1, col)
270       If strFieldname <> "" Then
280           If dicFieldnames.Exists(strFieldname) Then
290               dicColumns.Add strFieldname, col
300           End If
310       End If
320   Next

      ' Verify we have the columns:  Location   Program   DateEx   NetID

330   If Not (dicColumns.Exists("Location") And dicColumns.Exists("Program") And dicColumns.Exists("DateEx") And dicColumns.Exists("NetID")) Then
340       Call MsgBox("Error:  One or more of the following columns is missing" & vbCrLf & _
                      " Disposition  Location   Program   DateEx   NetID", vbOKOnly)
350       GoTo Exit_label
360   End If

      Dim row As Long
370   row = 2

      Dim strWhere As String
      Dim strLocation As String
      Dim strProgram As String
      ' Dim strDateEx As String
      Dim datDateEx As Date
      Dim strNetID As String
      Dim key As Variant

      ' Process the records from the Excel worksheet

380   Do
390       strLocation = Nz(oSheet.Cells(row, dicColumns("Location")))
400       If strLocation = "" Then Exit Do
410       strProgram = Nz(oSheet.Cells(row, dicColumns("Program")))
420       datDateEx = Nz(oSheet.Cells(row, dicColumns("DateEx")))
430       strNetID = Nz(oSheet.Cells(row, dicColumns("NetID")))

440       strWhere = "[Location] = '" & strLocation & "' AND " & _
                     " [Program] = '" & strProgram & "' AND " & _
                     " [DateEx] = #" & Format(datDateEx, "mm/dd/yyyy") & "# AND " & _
                     " [NetID] = '" & strNetID & "'"
          Dim strSQL As String
450       strSQL = "SELECT * FROM tblDETNetHours WHERE " & strWhere
                     
460       Set rst = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)
470       If rst.EOF Then
480           rst.AddNew
490           For Each key In dicColumns.Keys
500               strFieldname = CStr(key)
510               col = dicColumns(key)
520               rst.Fields(strFieldname) = Nz(oSheet.Cells(row, col))
530           Next
540           rst.Update
              
              ' Referential Integrity
              
550           strWhere = "[Location] = '" & strLocation & "' AND " & _
                     " [Program] = '" & strProgram & "' AND " & _
                     " [DateEx] = #" & Format(datDateEx, "mm/dd/yyyy") & "#"
560           If DCount("*", "tblDETDaily", strWhere) = 0 Then

570               strSQL = "INSERT INTO tblDETDaily (Location, Program, DateEx) VALUES ( " & _
                      "'" & strLocation & "','" & strProgram & "',#" & Format(datDateEx, "mm/dd/yyyy") & "#"
580               CurrentDb.Execute strSQL
590           End If
                      
600           lngCountImported = lngCountImported + 1
610       Else
          
              ' There is only one non-key field
          
620           If Nz(rst.Fields("NetHours"), 0) = 0 Then
630               rst.Edit
640               col = dicColumns("NetHours")
650               rst.Fields("NetHours") = Nz(oSheet.Cells(row, col))
660               rst.Update
670               lngCountImported = lngCountImported + 1
680           Else
690               lngCountNotImported = lngCountNotImported + 1
700           End If
710       End If

720   rst.Close
730       row = row + 1
740   Loop

750   strReport = lngCountImported & " DET Net Hours records imported"
760   If lngCountNotImported <> 0 Then
770       strReport = strReport & vbCrLf & lngCountNotImported & " DET Net Hours records not imported"
780   End If

790   If IsLoaded("frmDETViewDaily2") Then
800       Forms("frmDETViewDaily2").Requery
810   End If

          'DD Error Handler Start
Exit_label:
820       Exit Sub
Err_label:
830       Select Case Err.Number
          Case Else
840      Call LogError("basMultiPC", "multiPCImport_DETNetHours")
850       End Select
860       Resume Exit_label
          ' DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' MultiPC_BrowseForExcelFile
'---------------------------------------------------------------------------------------
' Dim strSetting_Filepath As String             ' Input
' Dim strFilepath As String                     ' Returns
' Call MultiPC_BrowseForExcelFile( strSetting_Filepath, strFilepath )



Private Sub MultiPC_BrowseForExcelFile(ByVal strSetting_Filepath As String, ByRef strFilepath As String)
10    On Error GoTo Err_label

      Dim strInputFileFolder As String
      Dim strInputFileName As String
      Dim fDialog As FileDialog

      ' Get the initial folderpath

20    If strSetting_Filepath <> "" Then
30        strInputFileFolder = GetSettingEx(strSetting_Filepath)
40    Else
50        strInputFileFolder = Rep_Documents()
60    End If

70    strFilepath = FileOpenDialogExcel(strInputFileFolder, "Select the MultiPC Excel File")

      ' Verify that the file exists
80    If Not FileExists(strFilepath) Then
90        MsgBox "The selected file does not exist " & strFilepath, vbExclamation, "MultiPC"
100       Exit Sub
110   End If

120   Call PutSettingEx(strSetting_Filepath, strFilepath)

          'DD Error Handler Start
Exit_label:
130       Exit Sub
Err_label:
140       Select Case Err.Number
          Case Else
150            Call LogError("basMultiPC", "MultiPC_BrowseForExcelFile")
160       End Select
170       Resume Exit_label
          ' DD Error Handler End

End Sub


'---------------------------------------------------------------------------------------
' MultiPCExport
'---------------------------------------------------------------------------------------
' PRE datFromDate and datToDate contain valid dates.  datFromDate <= datToDate

Public Sub MultiPCExport(ByVal datFromDate As Date, ByVal datToDate As Date)
10    On Error GoTo Err_label

      Dim lngCountCaptureRecords As Long
      Dim lngCountDETDailyRecords As Long
      Dim lngCountDETSpeciesRecords As Long
      Dim lngCountDETNetHoursRecords As Long

      Dim oExcel As Excel.Application
      Dim oBook  As Excel.Workbook

20    lngCountCaptureRecords = 0
30    lngCountDETDailyRecords = 0
40    lngCountDETSpeciesRecords = 0
50    lngCountDETNetHoursRecords = 0

60    Set oExcel = New Excel.Application
70    Set oBook = oExcel.Workbooks.Add

      '     oExcel.Visible = True

      Dim qdf As DAO.QueryDef
      Dim rst As DAO.Recordset

      ' Export tblCaptures

80    Set qdf = CurrentDb.QueryDefs("qryMultiPC_Captures")
90    qdf.Parameters("argFrom") = datFromDate
100   qdf.Parameters("argTo") = datToDate
110   Set rst = qdf.OpenRecordset
120   Call Export(oBook, "Captures", rst, lngCountCaptureRecords)
130   rst.Close
140   Set rst = Nothing

      ' Export tblDETDaily

150   Set qdf = CurrentDb.QueryDefs("qryMultiPC_DETDaily")
160   qdf.Parameters("argFrom") = datFromDate
170   qdf.Parameters("argTo") = datToDate
180   Set rst = qdf.OpenRecordset
190   Call Export(oBook, "DETDaily", rst, lngCountDETDailyRecords)
200   rst.Close
210   Set rst = Nothing

      ' Export tblDETSpecies

220   Set qdf = CurrentDb.QueryDefs("qryMultiPC_DETSpecies")
230   qdf.Parameters("argFrom") = datFromDate
240   qdf.Parameters("argTo") = datToDate
250   Set rst = qdf.OpenRecordset
260   Call Export(oBook, "DETSpecies", rst, lngCountDETSpeciesRecords)
270   rst.Close
280   Set rst = Nothing

      ' Export tblDETNetHours

290   Set qdf = CurrentDb.QueryDefs("qryMultiPC_DETNetHours")
300   qdf.Parameters("argFrom") = datFromDate
310   qdf.Parameters("argTo") = datToDate
320   Set rst = qdf.OpenRecordset
330   Call Export(oBook, "DETNetHours", rst, lngCountDETNetHoursRecords)
340   rst.Close
350   Set rst = Nothing

360   If lngCountCaptureRecords + lngCountDETDailyRecords + lngCountDETSpeciesRecords + lngCountDETNetHoursRecords = 0 Then
370       Call MsgBox("There are no records to export", vbOKOnly)
380       GoTo Exit_label
390   End If

      ' Save the Excel Workbook

      Dim strBaseFilename As String
400   strBaseFilename = "MultiPC Export " & Format(datFromDate, "dd mmm yyyy") & " to " & Format(datToDate, "dd mmm yyyy")

      Dim strSaveFilepath As String
      Dim fUserCancelled As Boolean
410   Call SaveAndCloseExcelWorkbookEx(oExcel, oBook, strBaseFilename, strSaveFilepath, fUserCancelled)

420   If fUserCancelled Then
430       GoTo Exit_label
440   End If



      Dim strReport As String
450   strReport = ""
460   If lngCountCaptureRecords > 0 Then
470       If strReport <> "" Then
480           strReport = strReport & vbCrLf
490       End If
500       strReport = strReport & lngCountCaptureRecords & " Capture records exported"
510   End If
520   If lngCountDETDailyRecords > 0 Then
530       If strReport <> "" Then
540           strReport = strReport & vbCrLf
550       End If
560       strReport = strReport & lngCountDETDailyRecords & " DET Daily records exported"
570   End If
580   If lngCountDETSpeciesRecords > 0 Then
590       If strReport <> "" Then
600           strReport = strReport & vbCrLf
610       End If
620       strReport = strReport & lngCountDETSpeciesRecords & " DET Species records exported"
630   End If
640   If lngCountDETNetHoursRecords > 0 Then
650       If strReport <> "" Then
660           strReport = strReport & vbCrLf
670       End If
680       strReport = strReport & lngCountDETNetHoursRecords & " DET Net Hours records exported"
690   End If
700   Call MsgBox(strReport, vbOKOnly)



710   Call OpenExcelWorkbook(strSaveFilepath)


      ' report lngCountCaptureRecords etc

          'DD Error Handler Start
Exit_label:
720       Exit Sub
Err_label:
730       Select Case Err.Number
          Case Else
740            Call LogError("basMultiPC", "MultiPCExport")
750       End Select
760       Resume Exit_label
          ' DD Error Handler End
End Sub


'---------------------------------------------------------------------------------------
' Export
'---------------------------------------------------------------------------------------
' Call Export(oBook, strSheetName, rst, lngCountRecords)
'
' CaptureDate and DateEx are exported as Excel Dates
' WeightTime is exported as a string in the format hh:mm:ss
'
' Create a sheet in the Excel workbook
' Name it strSheetName
' Fill in row 1 with the fieldnames from the DAO.Recordet rst
' Fill in rows 2, 3, ... with date from rst
' Autofit all the columns in the sheet
' Return the number of records written

Private Sub Export(ByRef oBook As Excel.Workbook, ByVal strSheetName As String, ByRef rst As DAO.Recordset, ByRef lngCountRecords)
10    On Error GoTo Err_label

      Dim oSheet As Excel.Worksheet

20    Set oSheet = oBook.Sheets.Add
30    oSheet.Name = strSheetName

      ' Get the fieldnames and load them into a dictionary
      ' The key is the field name, the value is the Excel column

      Dim db As Database
      Dim columns As Scripting.Dictionary
      Dim i As Integer
      Dim col As Integer

40    Set db = CurrentDb
50    Set columns = New Scripting.Dictionary

60    col = 1
70    For i = 0 To rst.Fields.count - 1
80        columns.Add rst.Fields(i).Name, col
90        col = col + 1
100   Next

      Dim colLast As Integer
110   colLast = col - 1

      ' Fill in row 1 with the field names

      Dim key As Variant
120   For Each key In columns
130       col = columns(key)
140       oSheet.Cells(1, col) = CStr(key)
150   Next

      ' Copy the data from tblCaptures to the worksheet

160   lngCountRecords = 0
      Dim row As Long
170   row = 2
      Dim strValue As String
      Dim strFieldname As String
180   Do While Not rst.EOF

190       If row Mod 10 = 0 Then
200           SysCmd acSysCmdSetStatus, CStr(row) & " " & strSheetName & "  records"
210       End If
          
          Dim datDate As Date
          
220       For Each key In columns
230           col = columns(key)
240           strFieldname = CStr(key)

320           strValue = Nz(rst.Fields(strFieldname))

340           oSheet.Cells(row, col) = strValue
350       Next
360       row = row + 1
370       lngCountRecords = lngCountRecords + 1
380       rst.MoveNext
390   Loop


400   SysCmd acSysCmdClearStatus

410   oSheet.range(oSheet.columns(1), oSheet.columns(colLast)).AutoFit

          'DD Error Handler Start
Exit_label:
420       Exit Sub
Err_label:
430       Select Case Err.Number
          Case Else
440            Call LogError("basMultiPC", "Export")
450       End Select
460       Resume Exit_label
          ' DD Error Handler End
End Sub


'---------------------------------------------------------------------------------------
' ImportCaptureAndDETRecordsFromAnotherMBODataEntryDatabase
'---------------------------------------------------------------------------------------
' Not used
'
' Browse for the other MBO Data Entry Database
' Verify the other database has a tblCaptures table
'
' We need a query that returns the capture records that are in the other databaase but not in this databaee
' we want the PC that created the record, the date the record was created, anything else Band Prefix Band Suffix  Disposition Species maybe
' Can we show them and pause here?

' Prompt Do we import ?
' Import

' Repeat for DET redords




Private Sub ImportCaptureAndDETRecordsFromAnotherMBODataEntryDatabase()


Dim strFilepath As String
Dim strFolderpath As String
Dim dbOther As DAO.Database
Dim strPermit As String
Dim rstOther As DAO.Recordset
Dim strSQL As String

   On Error GoTo Err_label

strFilepath = GetSettingEx("Filepath to a database with capture and DET records to be imported into this database")
strFilepath = FileOpenDialogAccess(strFilepath, "Browse for another MBO Data Entry Database")
If strFilepath <> "" Then
    Call PutSettingEx("Filepath to a database with capture and DET records to be imported into this database", strFilepath)
    
'    On Error GoTo Not_a_MBO_Database_label
'    Set dbOther = OpenDatabase(strFilepath)
'    strSQL = "SELECT ValueEx FROM tblUtilityBackend WHERE [Name] = 'Permit'"
'    Set rstOther = dbOther.OpenRecordset(strSQL)
'    Do While Not rstOther.EOF
'        If Nz(rstOther("ValueEx")) <> Nz(DLookup("ValueEx", "tblUtilityBackend", "[Name] = 'Permit'")) Then
'            rstOther.Close
'            Set rstOther = Nothing
'            GoTo Not_a_MBO_Database_label
'        End If
'        rstOther.MoveNext
'    Loop
'    rstOther.Close
'    Set rstOther = Nothing
'    On Error GoTo Err_label
'
    On Error Resume Next
    Set dbOther = OpenDatabase(strFilepath)
    If Err.Number <> 0 Then
        Call MsgBox("Failed to open the other database", vbOKOnly)
        GoTo Exit_label
     End If
     Set rstOther = dbOther.OpenRecordset("tblCaptures")
     If Err.Number <> 0 Then
        Call MsgBox("Failed to find a Captures table in the other database.  It is not an MBO Data Entry Database", vbOKOnly)
        GoTo Exit_label
     End If
    
End If


    'DD Error Handler Start
Exit_label:
    Exit Sub
'Not_a_MBO_Database_label:
'    Call MsgBox("Please verify the file is a valid MBO Data Entry Database")
'    Resume Exit_label
Err_label:
    Select Case Err.Number
    Case Else
         Call LogError("basMultiPC", "ImportCaptureAndDETRecordsFromAnotherMBODataEntryDatabase")
    End Select
    Resume Exit_label
    ' DD Error Handler End

End Sub
