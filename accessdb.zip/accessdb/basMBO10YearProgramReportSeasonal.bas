'---------------------------------------------------------------------------------------
' Module    : basMBO10YearProgramReportSeasonal
' Author    : David Davey
'---------------------------------------------------------------------------------------
'
' There is no longer a seasonal table 5.3 in the report.
' So I no longer generate it.
' Nevertheless, I continue to generate the corresponding Excel worksheets
'
' Table 5.3
'
' For each Season + Period
'   Number of species observed
'   Dominant species observed
'   Species peaking this week           Fall, Spring only
'   Dominant species banded
'   Birds banded
'   Weather                             not filled in
'   Notes                               not filled in

Option Compare Database
Option Explicit

' A species is included in the list of Dominant species observed (or banded)
' if it is in the Top 10 for a certain fraction ( 60% ) of the years

Const conThresholdFractionYearsDET    As Double = 0.6
Const conThresholdFractionYearsBanded As Double = 0.6

' Statistics

Const conDET As Integer = 0
Const conBND As Integer = 1
Const conRET As Integer = 2
Const conREP As Integer = 3
Const conCNS As Integer = 4

Private intYearFirst As Integer
Private intYearLast As Integer
Private strLocation As String
Private strSeason As String
Private intSeason As Integer
Private wd As Word.Application
Private doc As Word.Document
Private oExcel As Excel.Application
Private oBook As Excel.Workbook
Private intFld As Integer
Private strStat As String ' "Species", "Top10"
Private fDebug As Boolean

Private dblStatAllYears() As Double
Private dblStatMax() As Double
Private dblStatMin() As Double
Private dblStatMean() As Double
Private intDETCountYears() As Integer

'---------------------------------------------------------------------------------------
' MBO10YearProgramReportSeasonal
'---------------------------------------------------------------------------------------
 
Public Sub MBO10YearProgramReportSeasonal( _
    ByRef fValid As Boolean, _
    ByVal argYearFirst As Integer, _
    ByVal argYearLast As Integer, _
    ByVal argLocation As String, _
    ByVal argSeason As String, _
    ByRef arg_wd As Word.Application, _
    ByRef arg_doc As Word.Document, _
    ByRef arg_excel As Excel.Application, _
    ByRef arg_book As Excel.Workbook, _
    ByVal arg_debug As Boolean)
           
      ' Save parameters

10    On Error GoTo Err_label

20    intYearFirst = argYearFirst
30    intYearLast = argYearLast
40    strLocation = argLocation
50    strSeason = argSeason
60    Set wd = arg_wd
70    Set doc = arg_doc
80    Set oExcel = arg_excel
90    Set oBook = arg_book
100   fDebug = arg_debug

'=======================================================================================
' load_tbl10YearProgramReportSpecies_Classic
'---------------------------------------------------------------------------------------
' This is the "classic" load of tbl10YearProgramReportSpecies
' Null DET values from Owling, Nestbox, RTHU_Spring, RTHU_Fall remain Null
' Seasons are not merged.
'
' tblMBO10YearProgramReportSpecies
' --------------------------------
' same as tblDETSpecies, except
' SNGO GSGO LSGO merged into SNGO
' TRFL ALFL WIFL merged into TRFL
' The records for ("UNSG","UNAC","UNEM","UNGU","UNSC","PAWA","UNPW") are excluded
' -------------------------------
' WHERE YearEx BETWEEN intYearFrom AND intYearTo
' WHERE Location = "MBO"
'
' Season
' YearEx
' Period            filled in using Period: toPeriod([MonitoringProgramSeason],[DateEx],[DateFrom])
' DateEx
' Species
' Banded
' Returns
' Repeats
' DET
' ======================================================================================

110   Call load_tbl10YearProgramReportSpecies_Classic(intYearFirst, intYearLast)

Dim local_intPeriodLast_Season As Integer

120   local_intPeriodLast_Season = getPeriodLast_Season(strSeason)       ' Given the season, this is the number of periods


130   intSeason = toIntSeasonFromStrSeason(strSeason)

140   If strSeason = "Spring" Or strSeason = "Fall" Then
150     Call CommonAndUncommonSpecies(strSeason, intYearFirst, intYearLast, oExcel, oBook)
160   End If

      ' Generate tables and export to Excel

170   Call MBO10YearProgramReportSeasonalDETorBandedSpecies(conDET, local_intPeriodLast_Season)
180   Call MBO10YearProgramReportSeasonalTop10_DET(strSeason)
190   Call MBO10YearProgramReportSeasonalTop10_Banded(strSeason)
200   If strSeason = "Spring" Or strSeason = "Fall" Then
210       Call MBO10YearProgramReportSeasonalPeak
220   End If
' 230   Call MBO10YearProgramReportSeasonalBandedBirds
240   Call MBO10YearProgramReportSeasonalDETorBandedSpecies(conBND, local_intPeriodLast_Season)

      ' =============================================================
      ' I no longer export to Word, but I'm keeping the code
      ' =============================================================
     
250   If False Then

      Dim range As Word.range
      Dim Period As Integer
      Dim lngLabelStart As Long
      Dim lngLabelEnd As Long

260   For Period = 1 To local_intPeriodLast_Season

270       Set range = MoveInsertionPointToEndOfDocument(wd, doc)
280       range.InsertAfter toPeriodTitle(strSeason, Period)
290       range.InsertParagraphAfter
300       range.Style = "ddMultiYearSeasonalPeriod"
                    
          ' Number of species observed
          
310       Set range = MoveInsertionPointToEndOfDocument(wd, doc)
320       lngLabelStart = range.End
330       range.InsertAfter "Species observed: "
340       lngLabelEnd = range.End
          
          Dim lngStat As Long
          Dim dblStat As Double
          
350       lngStat = Nz(DLookup("DETSpeciesCumulativeTotal", "tblMBO10YearProgramReportSeasonalDETSpecies", "[Period] = " & Period))
360       Set range = MoveInsertionPointToEndOfDocument(wd, doc)
370       range.InsertAfter lngStat
380       range.InsertAfter " (low "
390       lngStat = Nz(DLookup("DETSpeciesMinimum", "tblMBO10YearProgramReportSeasonalDETSpecies", "[Period] = " & Period))
400       range.InsertAfter lngStat
410       range.InsertAfter ", mean "
420       dblStat = Nz(DLookup("DETSpeciesMean", "tblMBO10YearProgramReportSeasonalDETSpecies", "[Period] = " & Period))
430       range.InsertAfter Format(dblStat, "#0")
440       range.InsertAfter ", high "
450       lngStat = Nz(DLookup("DETSpeciesMaximum", "tblMBO10YearProgramReportSeasonalDETSpecies", "[Period] = " & Period))
460       range.InsertAfter lngStat
470       range.InsertAfter ") "
480       range.InsertParagraphAfter
490       range.Style = "ddMultiYearSeasonalData"

500       doc.range(lngLabelStart, lngLabelEnd).ParagraphFormat.Style = "ddMultiYearSeasonalSpeciesObserved"

'470       With doc.range(lngLabelStart, lngLabelEnd).Font
'480           .Bold = True
'490           .Italic = True
'500           .color = RGB(128, 128, 128)
'510       End With
          
          ' Dominant species observed
          
510       Set range = MoveInsertionPointToEndOfDocument(wd, doc)
520       lngLabelStart = range.End
530       range.InsertAfter "Dominant species observed: "
540       lngLabelEnd = range.End
          
          Dim strSpecies As String
          Dim strSpeciesEnglish As String
          Dim fFirst As Boolean
550       fFirst = True
          Dim strWhere As String
          
560       Set range = MoveInsertionPointToEndOfDocument(wd, doc)
          Dim rst As DAO.Recordset
          Dim strSQL As String
570       strSQL = _
              "SELECT * FROM tblMBO10YearProgramReportSeasonal_Top10_DET " & _
              "WHERE [Period] = " & Period
580       Set rst = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)
590       Do While Not rst.EOF
600           strSpecies = rst("Species")
              
610           strWhere = _
                  "[DETorBanded] = 'DET' AND " & _
                  "[Period] = " & Period & " AND " & _
                  "[Species] = '" & strSpecies & "' AND " & _
                  "[Season] = '" & strSeason & "'"

              Dim lngCountYears As Long
620           lngCountYears = DCount("*", "tblMBO10YearProgramReport_Top10", strWhere)

              Dim intDETYears As Long
630           intDETYears = getDETPeriods_SeasonPeriod(toIntSeasonFromStrSeason(strSeason), Period)
         
640           If lngCountYears >= Round(conThresholdFractionYearsDET * intDETYears) Then
650               dblStat = rst("DETMeanBirds")
660               strSpeciesEnglish = DLookup("SpeciesDescriptionMBO", "tblSpecies", "[Species] = '" & strSpecies & "'")
670               If Not fFirst Then
680                  range.InsertAfter ", "
690               Else
700                   range.InsertAfter " "
710                   fFirst = False
720               End If
730               range.InsertAfter strSpeciesEnglish & " (" & Format(dblStat, "#0") & ")"
740               End If
750           rst.MoveNext
760       Loop
770       rst.Close
780       Set rst = Nothing
790       range.InsertParagraphAfter
800       range.Style = "ddMultiYearSeasonalData"
          
810       With doc.range(lngLabelStart, lngLabelEnd).Font
820           .Bold = True
830           .Italic = True
840           .Color = RGB(128, 128, 128)
850       End With

          ' Species peaking this week ( Spring and Fall only)

860       If strSeason = "Spring" Or strSeason = "Fall" Then
          
870           Set range = MoveInsertionPointToEndOfDocument(wd, doc)
880           lngLabelStart = range.End
890           range.InsertAfter "Species peaking this week: "
900           lngLabelEnd = range.End
          
910           Set range = MoveInsertionPointToEndOfDocument(wd, doc)
          
              ' qryMBO10YearProgramReportSeasonal_Peak_C
              ' --------------------------------------------------------------------------------------------
              ' tblMBO10YearProgramReportSeasonal_Peak_B x qryMBO10YearProgramReportSeasonal_CommonSpecies_B
              ' --------------------------------------------------------------------------------------------
              ' Period = [argPeriod]
              ' AOU
              ' SpeciesEnglish
              ' Common
              ' ORDER BY AOU
              ' Report, AOU, SpeciesEnglish, Common
              
              Dim intCommon As Integer
              
              Dim qdf As QueryDef
920           Set qdf = CurrentDb.QueryDefs("qryMBO10YearProgramReportSeasonal_Peak_C")
930           qdf.Parameters("argSeason").value = strSeason
940           qdf.Parameters("CountYears").value = intYearLast - intYearFirst + 1
950           qdf.Parameters("argPeriod").value = Period
              
960           Set rst = qdf.OpenRecordset

970           If Not rst.EOF Then

980               rst.MoveLast
                  Dim intRecordCount As Integer
990               intRecordCount = rst.RecordCount
1000              range.InsertAfter intRecordCount
                  
1010              rst.MoveFirst
1020              Do While Not rst.EOF
1030                  strSpeciesEnglish = Nz(rst("SpeciesEnglish"))
1040                  intCommon = Nz(rst("Common"))
1050                  If Not fFirst Then
1060                     range.InsertAfter ", "
1070                  Else
1080                      range.InsertAfter " - "
1090                      fFirst = False
1100                  End If
1110                  range.InsertAfter strSpeciesEnglish
1120                  If intCommon = 0 Then
1130                      range.InsertAfter "*"
1140                  End If
1150                  rst.MoveNext
1160              Loop

1170          End If ' NOT rst.EOF

1180          rst.Close
1190          Set rst = Nothing
1200          range.InsertParagraphAfter
1210          range.Style = "ddMultiYearSeasonalData"

1220      With doc.range(lngLabelStart, lngLabelEnd).Font
1230          .Bold = True
1240          .Italic = True
1250          .Color = RGB(128, 128, 128)
1260      End With
          
1270      End If

          ' Birds banded - individuals
          
1280      strWhere = _
              "[Season] = '" & strSeason & "' AND " & _
              "[Period] = " & Period & " AND " & _
              "[TotalCaptureSeasonYearPeriod] = 1"
            
          Dim lngBirdsBandedTotal  As Long
          Dim lngBirdsBandedMin  As Long
          Dim lngBirdsBandedMax  As Long
          Dim intCaptureYears As Integer
          Dim lngBirdsBandedMean As Long

1290      lngBirdsBandedTotal = Nz(DSum("Banded", "tblMBO10YearProgramReportSeasonalBandedBirds", strWhere))
1300      lngBirdsBandedMin = Nz(DMin("Banded", "tblMBO10YearProgramReportSeasonalBandedBirds", strWhere))
1310      lngBirdsBandedMax = Nz(DMax("Banded", "tblMBO10YearProgramReportSeasonalBandedBirds", strWhere))
1320      intCaptureYears = Nz(DCount("*", "tblMBO10YearProgramReportSeasonalBandedBirds", strWhere))
1330      If intCaptureYears > 0 Then
1340          lngBirdsBandedMean = Round(CDbl(lngBirdsBandedTotal) / intCaptureYears, 0)
1350      Else
1360          lngBirdsBandedMean = 0
1370      End If

1380      Set range = MoveInsertionPointToEndOfDocument(wd, doc)
1390      lngLabelStart = range.End
1400      range.InsertAfter "Birds banded: "
1410      lngLabelEnd = range.End

1420      Set range = MoveInsertionPointToEndOfDocument(wd, doc)
1430      range.InsertAfter lngBirdsBandedTotal
1440      range.InsertAfter " individuals"
          
1450      If lngBirdsBandedTotal > 0 Then
1460          range.InsertAfter " (low "
1470          range.InsertAfter lngBirdsBandedMin
1480          If intCaptureYears > 0 Then
1490              range.InsertAfter ", mean "
1500              range.InsertAfter lngBirdsBandedMean
1510          End If
1520          range.InsertAfter ", high "
1530          range.InsertAfter lngBirdsBandedMax
1540          range.InsertAfter "); "
          
              ' Birds banded - species
          
1550          lngStat = Nz(DLookup("DETSpeciesCumulativeTotal", "tblMBO10YearProgramReportSeasonalBandedSpecies", "[Period] = " & Period))
1560          range.InsertAfter lngStat
1570          range.InsertAfter " species (low "
1580          lngStat = Nz(DLookup("DETSpeciesMinimum", "tblMBO10YearProgramReportSeasonalBandedSpecies", "[Period] = " & Period))
1590          range.InsertAfter lngStat
1600          range.InsertAfter ", mean "
1610          dblStat = Nz(DLookup("DETSpeciesMean", "tblMBO10YearProgramReportSeasonalBandedSpecies", "[Period] = " & Period))
1620          range.InsertAfter Format(dblStat, "#0")
1630          range.InsertAfter ", high "
1640          lngStat = Nz(DLookup("DETSpeciesMaximum", "tblMBO10YearProgramReportSeasonalBandedSpecies", "[Period] = " & Period))
1650          range.InsertAfter lngStat
1660          range.InsertAfter ") "
1670      End If

1680      range.InsertParagraphAfter
1690      range.Style = "ddMultiYearSeasonalData"

1700      With doc.range(lngLabelStart, lngLabelEnd).Font
1710          .Bold = True
1720          .Italic = True
1730          .Color = RGB(128, 128, 128)
1740      End With

          ' Dominant species banded
          
1750      If lngBirdsBandedTotal > 0 Then
1760          Set range = MoveInsertionPointToEndOfDocument(wd, doc)
1770      lngLabelStart = range.End
1780          range.InsertAfter "Dominant species banded: "
1790      lngLabelEnd = range.End
         
1800          fFirst = True
              
1810          Set range = MoveInsertionPointToEndOfDocument(wd, doc)
          
1820          strSQL = _
                  "SELECT * FROM tblMBO10YearProgramReportSeasonal_Top10_Banded " & _
                  "WHERE [Period] = " & Period
1830          Set rst = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)
1840          Do While Not rst.EOF
          
1850              dblStat = rst("BandedMeanBirds")
1860              If dblStat >= 0.1 Then
1870                  strSpecies = rst("Species")
          
1880              strWhere = _
                      "[DETorBanded] = 'Banded' AND " & _
                      "[Period] = " & Period & " AND " & _
                      "[Species] = '" & strSpecies & "' AND " & _
                      "[Season] = '" & strSeason & "'"
          
1890              lngCountYears = DCount("*", "tblMBO10YearProgramReport_Top10", strWhere)
                      
                  Dim intCapturesYears As Long
1900              intCapturesYears = getCapturesYears_SeasonPeriod(toIntSeasonFromStrSeason(strSeason), Period)
          
1910              If lngCountYears >= Round(conThresholdFractionYearsBanded * intCapturesYears) Then
1920                      strSpeciesEnglish = DLookup("SpeciesDescriptionMBO", "tblSpecies", "[Species] = '" & strSpecies & "'")
1930                      If Not fFirst Then
1940                         range.InsertAfter ", "
1950                      Else
1960                          range.InsertAfter " "
1970                          fFirst = False
1980                      End If
1990                      range.InsertAfter strSpeciesEnglish & " (" & FormatNumberEnglish(dblStat, 1) & ")"
2000                  End If
2010              End If
2020              rst.MoveNext
2030          Loop
2040          rst.Close
2050          Set rst = Nothing
2060          range.InsertParagraphAfter
2070          range.Style = "ddMultiYearSeasonalData"

2080      With doc.range(lngLabelStart, lngLabelEnd).Font
2090          .Bold = True
2100          .Italic = True
2110          .Color = RGB(128, 128, 128)
2120      End With

2130      End If ' lngBirdsBandedTotal > 0
          
          ' Label: Weather:"

2140      Set range = MoveInsertionPointToEndOfDocument(wd, doc)
2150      lngLabelStart = range.End
2160      range.InsertAfter "Weather: "
2170      lngLabelEnd = range.End

2180      Set range = MoveInsertionPointToEndOfDocument(wd, doc)
2190      range.InsertParagraphAfter
2200      range.Style = "ddMultiYearSeasonalData"

2210      With doc.range(lngLabelStart, lngLabelEnd).Font
2220          .Bold = True
2230          .Italic = True
2240          .Color = RGB(128, 128, 128)
2250      End With
          
          ' Label: Notes:"

2260      Set range = MoveInsertionPointToEndOfDocument(wd, doc)
2270      lngLabelStart = range.End
2280      range.InsertAfter "Notes: "
2290      lngLabelEnd = range.End

2300      Set range = MoveInsertionPointToEndOfDocument(wd, doc)
2310      range.InsertParagraphAfter
2320      range.InsertParagraphAfter
2330      range.Style = "ddMultiYearSeasonalData"

2340      With doc.range(lngLabelStart, lngLabelEnd).Font
2350          .Bold = True
2360          .Italic = True
2370          .Color = RGB(128, 128, 128)
2380      End With

2390  Next
 
2400  End If ' Do not generate Word output
      


      'DD Error Handler Start
Exit_label:
2410       Exit Sub
Err_label:
2420       Select Case Err.Number
           Case Else
2430      Call LogError("basMBO10YearProgramReportSeasonal", "MBO10YearProgramReportSeasonal")
2440       End Select
2450       Resume Exit_label
      'DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' MBO10YearProgramReportSeasonalBandedBirds
'---------------------------------------------------------------------------------------
'
' Seasonal - Number of birds banded
'
' Generate tblMBO10YearProgramReportSeasonalBandedBirds
'
' tblMBO10YearProgramReportSeasonalBandedBirds
' Season
' YearEx
' Period
' Banded

Private Sub MBO10YearProgramReportSeasonalBandedBirds()

10    On Error GoTo Err_label

      Dim strSQL As String
      Dim qdf As DAO.QueryDef
      Dim rst As DAO.Recordset
      Dim intYearEx As Integer
      Dim intPeriod As Integer
      Dim lngBanded As Long
      Dim intCaptureYears As Integer
      Dim row As Long
      
      ' qryMBO10YearProgramReportSeasonalBandedBirds_A
      ' ----------------------------------------------
      ' tblDETSpecies x tblPrograms
      ' Location = [argLocation]
      ' Season = MonitoringProgramSeason = [argSeason]
      ' YearEx BETWEEN [argYearFirst] AND [argYearLast]
      ' Period: toPeriod([MonitoringProgramSeason],[DateEx],[DateFrom])
      '
      ' Report YearEx, Period, DateEx, Banded

      ' qryMBO10YearProgramReportSeasonalBandedBirds_MakeTable
      ' ----------------------------------------------
      ' qryMBO10YearProgramReportSeasonalBandedBirds_A
      '
      ' MAKE TABLE tblMBO10YearProgramReportSeasonalBandedBirds
      '
      ' GROUP BY YearEx, Period
      ' Banded = SUM Banded
      '
      ' Report YearEx, Period, Banded
      
      
      ' tblMBO10YearProgramReportSeasonalBandedBirds
      ' --------------------------------------------
      ' YearEx
      ' Period
      ' Banded

      ' Delete tblMBO10YearProgramReportSeasonalBandedBirds

20    DoCmd.SetWarnings False
30    On Error Resume Next
40    DoCmd.DeleteObject acTable = acDefault, "tblMBO10YearProgramReportSeasonalBandedBirds"
50    On Error GoTo Err_label
60    DoCmd.SetWarnings True

      ' Create and load tblMBO10YearProgramReportSeasonalBandedBirds

70    strSQL = "qryMBO10YearProgramReportSeasonalBandedBirds_MakeTable"
80    Set qdf = CurrentDb.QueryDefs(strSQL)
90    qdf.Parameters("argSeason").value = strSeason
100   qdf.Parameters("argLocation").value = strLocation
110   qdf.Parameters("argYearFirst").value = intYearFirst
120   qdf.Parameters("argYearLast").value = intYearLast
130   qdf.Execute

      ' Output to Excel
      
      oExcel.Visible = True

      Dim oSheet As Excel.Worksheet
140   Set oSheet = InsertSheet(oBook, strSeason)
150   oSheet.Name = strSeason & " Seasonal BND Birds"
160   With oSheet

170   row = 1

180   .Cells(row, 1) = "Season"
190   .Cells(row, 2) = "Period"
200   .Cells(row, 3) = "Year"
210   .Cells(row, 4) = "Banded"

230   row = 2

      Dim intTotalCaptureSeasonYearPeriod As Integer

240   Set rst = CurrentDb.OpenRecordset("tblMBO10YearProgramReportSeasonalBandedBirds", dbOpenDynaset)
250   Do While Not rst.EOF

260       intPeriod = Nz(rst("Period"))
270       intYearEx = Nz(rst("YearEx"))
280       lngBanded = Nz(rst("Banded"))

300       .Cells(row, 1) = strSeason
310       .Cells(row, 2) = intPeriod
320       .Cells(row, 3) = intYearEx
330       .Cells(row, 4) = lngBanded

350       row = row + 1

360       rst.MoveNext
370   Loop
380   rst.Close
390   Set rst = Nothing

      ' Subtotal

400   .range(.Cells(1, 1), .Cells(row - 1, 4)).Subtotal _
          GroupBy:=2, Function:=xlSum, TotalList:=Array(4, 4), _
          Replace:=True, PageBreaks:=False, SummaryBelowData:=True

410   End With

      'DD Error Handler Start
Exit_label:
420        Exit Sub
Err_label:
430        Select Case Err.Number
           Case Else
440       Call LogError("basMBO10YearProgramReportSeasonal", "MBO10YearProgramReportSeasonalBandedBirds")
450        End Select
460        Resume Exit_label
      'DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' MBO10YearProgramReportSeasonalPeak
'---------------------------------------------------------------------------------------
 
Private Sub MBO10YearProgramReportSeasonalPeak()

10    On Error GoTo Err_label

      Dim strSQL As String
      Dim qdf As DAO.QueryDef
      Dim rst As DAO.Recordset

      ' qryMBO10YearProgramReportSeasonal_Peak_CountDays_DET_A
      ' ---------------------------------------------------------
      ' For a given Season
      ' For each YearEx x Period, generate one record per DET-Day
      ' ---------------------------------------------------------
      ' tblMBO10YearReportSpecies
      ' WHERE Season = [argSeason]
      ' GROUP BY YearEx, Period, DateEx
      ' SumDET = Sum DET
      ' HAVING SumDET > 0
      ' Report YearEx, Period, DateEx, SumDET

      ' qryMBO10YearProgramReportSeasonal_Peak_CountDays_DET_B
      ' ------------------------------------------------------
      ' For a given Season
      ' For each Period, count up the DET-Days
      ' ------------------------------------------------------
      ' qryMBO10YearProgramReportSeasonal_Peak_CountDays_DET_A
      ' GROUP BY Period
      ' CountDays = Count 1
      ' Report Period, CountDays


      ' qryMBO10YearProgramReportSeasonal_TopTen_DET
      ' ------------------------------------------------
      ' For a given Season
      ' Count the DET values for each Period and Species
      ' ------------------------------------------------
      ' tblMBO10YearPrograReportSpecies x tblSpecies
      ' Season = argSeason
      ' WHERE DET > 0
      ' GROUP BY Period, Species
      ' CountBirds = Sum DET
      ' Sort by Period, CountBirds DESC , AOU

      ' qryMBO10YearProgramReportSeasonal_Peak_A
      ' --------------------------------------------------------------------------
      ' For a season
      ' For each species and period
      '   Report the total DET, count DET-Days, Mean =  total DET / count DET-Days
      '   Order by Species ASC, Mean DESC
      ' --------------------------------------------------------------------------
      ' qryMBO10YearProgramReportSeasonal_TopTen_DET x
      ' qryMBO10YearProgramReportSeasonal_Peak_CountDays_DET_B
      ' Period
      ' Species
      ' Mean = CountBirds / CountDays
      ' Sort on Species, Mean DESC
      ' Report Season, Period, Species, CountBirds, CountDays, Mean

      ' We need to extract the first record for each species
      ' i.e. the record with the highest mean

20    strSQL = "DELETE * FROM tblMBO10YearProgramReportSeasonal_Peak_A"
30    CurrentDb.Execute strSQL

      Dim rstPeak As DAO.Recordset
40    Set rstPeak = CurrentDb.OpenRecordset("tblMBO10YearProgramReportSeasonal_Peak_A", dbOpenDynaset)

50    strSQL = "qryMBO10YearProgramReportSeasonal_Peak_A"
60    Set qdf = CurrentDb.QueryDefs(strSQL)
70    qdf.Parameters("argSeason").value = strSeason
80    Set rst = qdf.OpenRecordset

      Dim strSpecies As String
      Dim strSpeciesPrevious As String

90    strSpeciesPrevious = ""
100   Do While Not rst.EOF
110       strSpecies = rst("Species")
120       If strSpecies <> strSpeciesPrevious Then
              ' copy this record
130           rstPeak.AddNew
140           rstPeak("Season") = rst("Season")
150           rstPeak("period") = rst("Period")
160           rstPeak("Species") = rst("Species")
170           rstPeak("CountBirds") = rst("CountBirds")
180           rstPeak("CountDays") = rst("CountDays")
190           rstPeak("Mean") = rst("Mean")
200           rstPeak.Update
210       End If
220       strSpeciesPrevious = strSpecies
230       rst.MoveNext
240   Loop
250   Set rst = Nothing
260   Set qdf = Nothing

      ' qryMBO10YearProgramReportSeasonal_Peak_B
      ' ----------------------------------------
      ' tblMBO10YearProgramReportSeasonal_Peak_A x tblSpecies
      ' Group by Species, AOUOrder
      ' First of Period
      ' First of Mean
      ' Sort on Mean DESC
      ' SpeciesDescriptionMBO
      ' Append to tblMBO10YearProgramReportSeasonal_Peak_B

270   strSQL = "DELETE * FROM tblMBO10YearProgramReportSeasonal_Peak_B"
280   CurrentDb.Execute strSQL

290   strSQL = "qryMBO10YearProgramReportSeasonal_Peak_B"

300   Set qdf = CurrentDb.QueryDefs(strSQL)
310   qdf.Execute

320   Set rst = CurrentDb.OpenRecordset("tblMBO10YearProgramReportSeasonal_Peak_B", dbOpenDynaset)

      Dim oSheet As Excel.Worksheet
330   Set oSheet = InsertSheet(oBook, strSeason)
340   oSheet.Name = strSeason & " Peak DET"
350   With oSheet

      Dim row As Long
360   row = 2

      Dim intPeriod As Integer
      ' Dim strSpecies As String
      Dim dblMean As Double
      Dim strSpeciesEnglish As String

370   Do While Not rst.EOF
380       intPeriod = Nz(rst("Period"))
390       strSpecies = Nz(rst("Species"))
400       dblMean = Nz(rst("Mean"))
410       strSpeciesEnglish = Nz(rst("SpeciesEnglish"))
          
420       .Cells(row, 1) = strSeason
430       .Cells(row, 2) = intPeriod
440       .Cells(row, 3) = strSpecies
450       .Cells(row, 4) = strSpeciesEnglish
460       .Cells(row, 5) = dblMean
          
470       row = row + 1
480       rst.MoveNext
490   Loop
500   rst.Close
510   Set rst = Nothing

520   .columns(5).NumberFormat = "#0.00"
530   .range(.columns(1), .columns(5)).AutoFit

540   End With

550   Set oSheet = Nothing


      'DD Error Handler Start
Exit_label:
560        Exit Sub
Err_label:
570        Select Case Err.Number
           Case Else
580       Call LogError("basMBO10YearProgramReportSeasonal", "MBO10YearProgramReportSeasonalPeak")
590        End Select
600        Resume Exit_label
      'DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' MBO10YearProgramReportSeasonalTop10_DET
'
' For a given season, generate the table tblMBO10YearProgramReportSeasonal_Top10_DET
'
' tblMBO10YearProgramReportSeasonal_Top10_DET
' -------------------------------------------
' Season
' Period        ASC
' Species
' DETMeanBirds  DESC
' YearsInTop10
'---------------------------------------------------------------------------------------
 
Private Sub MBO10YearProgramReportSeasonalTop10_DET(ByVal strSeason As String)

10    On Error GoTo Err_label

      Dim qdf As QueryDef
      Dim rst As DAO.Recordset
      Dim strSQL As String

      Dim intPeriod As Integer
      Dim intPeriod_1 As Integer
      Dim dblStat As Double
      Dim dblStat_1 As Double
      Dim strSpecies As String
      Dim count As Integer
      Dim Rank As Integer

      Dim Y As Integer
      Dim p As Integer

      ' =====================================================
      ' Output to Excel
      ' Output to tblMBO10YearProgramReportSeasonal_Top10_DET
      ' =====================================================

20    strSQL = "DELETE * FROM tblMBO10YearProgramReportSeasonal_Top10_DET"
30    CurrentDb.Execute strSQL
      Dim rstOutput As DAO.Recordset
40    Set rstOutput = CurrentDb.OpenRecordset("tblMBO10YearProgramReportSeasonal_Top10_DET", dbOpenDynaset)

      Dim oSheet As Excel.Worksheet
50    Set oSheet = InsertSheet(oBook, strSeason)
60    oSheet.Name = strSeason & " Top 10 DET"
70    With oSheet

80    .Cells(1, 1) = "Period"
90    .Cells(1, 2) = "Species"
100   .Cells(1, 3) = "# Birds"
110   .Cells(1, 4) = "Rank"
120   .Cells(1, 5) = "DET-Days"
130   .Cells(1, 6) = "Birds/DET-Days"
140   .Cells(1, 7) = "# Years in Top10"
150   .Cells(1, 8) = "DET Years"

      ' qryMBO10YearProgramReportSeasonal_TopTen_DET
      ' --------------------------------------------
      ' tblMBO10YearPrograReportSpecies x tblSpecies
      ' Season = argSeason
      ' DET > 0
      ' Group by Period, Species
      ' CountBirds = Sum DET
      ' Sort by Period, CountBirds, AOU

160   strSQL = "qryMBO10YearProgramReportSeasonal_TopTen_DET"
170   Set qdf = CurrentDb.QueryDefs(strSQL)
180   qdf.Parameters("argSeason").value = strSeason
190   Set rst = qdf.OpenRecordset

200   intPeriod_1 = Nz(rst("Period"))
210   dblStat_1 = Nz(rst("CountBirds"))
220   count = 1
230   Rank = 1

      Dim row As Long
240   row = 2

      Dim strWhere As String
      Dim lngCountYears As Long

250   Do While Not rst.EOF

260       intPeriod = Nz(rst("Period"))
270       dblStat = Nz(rst("CountBirds"))
280       strSpecies = Nz(rst("Species"))

290       If (intPeriod <> intPeriod_1) Then
300           dblStat_1 = -1
310           count = 1
320           Rank = 1
330       End If
          
340       If Rank <= 10 Then
350           If dblStat <> dblStat_1 Then
360               Rank = count
370           End If
380           If Rank <= 10 Then
390               .Cells(row, 1) = intPeriod
400               .Cells(row, 2) = strSpecies
410               .Cells(row, 3) = dblStat
420               .Cells(row, 4) = Rank
430               .Cells(row, 5) = getDETDays_SeasonPeriod(intSeason, intPeriod)
440               If getDETDays_SeasonPeriod(intSeason, intPeriod) <> 0 Then
450                   .Cells(row, 6) = Round(dblStat / getDETDays_SeasonPeriod(intSeason, intPeriod), 0)
460               End If
                  
470               strWhere = _
                      "[DETorBanded] = 'DET' AND " & _
                      "[Period] = " & intPeriod & " AND " & _
                      "[Species] = '" & strSpecies & "' AND " & _
                      "[Season] = '" & strSeason & "'"
                      
480               lngCountYears = Nz(DCount("*", "tblMBO10YearProgramReport_Top10", strWhere))
490               .Cells(row, 7) = lngCountYears

                  Dim intDETYears As Long
500               intDETYears = getDETPeriods_SeasonPeriod(toIntSeasonFromStrSeason(strSeason), intPeriod)
510               .Cells(row, 8) = intDETYears

520               If lngCountYears < Round(conThresholdFractionYearsDET * intDETYears) Then
530                 .range(.Cells(row, 1), .Cells(row, 8)).Interior.Color = RGB(242, 242, 242)
540               End If

550               row = row + 1
                  
560               rstOutput.AddNew
570               rstOutput("Season") = strSeason
580               rstOutput("Period") = intPeriod
590               rstOutput("Species") = strSpecies
                  
                  Dim lngStat As Long
600               If getDETDays_SeasonPeriod(intSeason, intPeriod) <> 0 Then
610                   lngStat = Round(dblStat / getDETDays_SeasonPeriod(intSeason, intPeriod), 0)
620                   If lngStat > 0 Then
630                       rstOutput("DETMeanBirds") = lngStat
640                   End If
650                   rstOutput("YearsInTop10") = lngCountYears
660                   rstOutput.Update
670               End If
                           
680           End If
690           count = count + 1
700           intPeriod_1 = intPeriod
710           dblStat_1 = dblStat
720       End If
730       rst.MoveNext
740   Loop
750   rst.Close
760   Set rst = Nothing

770   rstOutput.Close
780   Set rstOutput = Nothing

790   .range(.Cells(1, 1), .Cells(1, 8)).Font.Bold = True
800   .range(.columns(1), .columns(8)).AutoFit
          
810   End With

820   Set oSheet = Nothing


      'DD Error Handler Start
Exit_label:
830        Exit Sub
Err_label:
840        Select Case Err.Number
           Case Else
850       Call LogError("basMBO10YearProgramReportSeasonal", "MBO10YearProgramReportSeasonalTop10_DET")
860        End Select
870        Resume Exit_label
      'DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' MBO10YearProgramReportSeasonalTop10_Banded
'
' For a given season, generate the table tblMBO10YearProgramReportSeasonal_Top10_Banded
'
' tblMBO10YearProgramReportSeasonal_Top10_Banded
' ----------------------------------------------
' Season
' Period        ASC
' Species
' DETMeanBirds  DESC
' YearsInTop10
'---------------------------------------------------------------------------------------
 
Private Sub MBO10YearProgramReportSeasonalTop10_Banded(ByVal strSeason As String)

10    On Error GoTo Err_label

      Dim qdf As QueryDef
      Dim rst As DAO.Recordset
      Dim strSQL As String

      Dim intPeriod As Integer
      Dim intPeriod_1 As Integer
      Dim dblStat As Double
      Dim dblStat_1 As Double
      Dim strSpecies As String
      Dim count As Integer
      Dim Rank As Integer
      Dim strWhere As String
      Dim lngCountYears As Long

      Dim Y As Integer
      Dim p As Integer

      ' ========================================================
      ' Output to Excel
      ' Output to tblMBO10YearProgramReportSeasonal_Top10_Banded
      ' ========================================================

20    strSQL = "DELETE * FROM tblMBO10YearProgramReportSeasonal_Top10_Banded"
30    CurrentDb.Execute strSQL
      Dim rstOutput As DAO.Recordset
40    Set rstOutput = CurrentDb.OpenRecordset("tblMBO10YearProgramReportSeasonal_Top10_Banded", dbOpenDynaset)

      Dim oSheet As Excel.Worksheet
50    Set oSheet = InsertSheet(oBook, strSeason)
60    oSheet.Name = strSeason & " Top 10 Banded"
70    With oSheet

80    .Cells(1, 1) = "Period"
90    .Cells(1, 2) = "Species"
100   .Cells(1, 3) = "# Birds"
110   .Cells(1, 4) = "Rank"
120   .Cells(1, 5) = "DET-Days"
130   .Cells(1, 6) = "Birds/DET-Days"
140   .Cells(1, 7) = "# Years in Top10"
150   .Cells(1, 8) = "Capture Years"

      ' qryMBO10YearProgramReportSeasonal_TopTen_Banded
      ' -----------------------------------------------
      ' tblMBO10YearProgramReportSpecies x tblSpecies
      ' Season = argSeason
      ' Banded > 0
      ' Group by Period, Species
      ' CountBirds = Sum Banded
      ' Sort by Period, CountBirds, AOU

160   strSQL = "qryMBO10YearProgramReportSeasonal_TopTen_Banded"
170   Set qdf = CurrentDb.QueryDefs(strSQL)
180   qdf.Parameters("argSeason").value = strSeason
190   Set rst = qdf.OpenRecordset

200   intPeriod_1 = Nz(rst("Period"))
210   dblStat_1 = Nz(rst("CountBirds"))
220   count = 1
230   Rank = 1

      Dim row As Long
240   row = 2

250   Do While Not rst.EOF

260       intPeriod = Nz(rst("Period"))
270       dblStat = Nz(rst("CountBirds"))
280       strSpecies = Nz(rst("Species"))

290       If (intPeriod <> intPeriod_1) Then
300           dblStat_1 = -1
310           count = 1
320           Rank = 1
330       End If
        
340       If Rank <= 10 Then
350           If dblStat <> dblStat_1 Then
360               Rank = count
370           End If
380           If Rank <= 10 Then
390               .Cells(row, 1) = intPeriod
400               .Cells(row, 2) = strSpecies
410               .Cells(row, 3) = dblStat
420               .Cells(row, 4) = Rank
430               .Cells(row, 5) = getCapturesYears_SeasonPeriod(intSeason, intPeriod)
440               If getDETDays_SeasonPeriod(intSeason, intPeriod) <> 0 Then
450                   .Cells(row, 6) = Round(dblStat / getCapturesYears_SeasonPeriod(intSeason, intPeriod), 1)
460               End If
              
470               strWhere = _
                      "[DETorBanded] = 'Banded' AND " & _
                      "[Period] = " & intPeriod & " AND " & _
                      "[Species] = '" & strSpecies & "' AND " & _
                      "[Season] = '" & strSeason & "'"
                      
480               lngCountYears = Nz(DCount("*", "tblMBO10YearProgramReport_Top10", strWhere))
490               .Cells(row, 7) = lngCountYears
                  
                  Dim intCapturesYears As Long
500               intCapturesYears = getCapturesYears_SeasonPeriod(toIntSeasonFromStrSeason(strSeason), intPeriod)
510               .Cells(row, 8) = intCapturesYears
          
520               If lngCountYears < Round(conThresholdFractionYearsBanded * intCapturesYears) Then
530                 .range(.Cells(row, 1), .Cells(row, 8)).Interior.Color = RGB(242, 242, 242)
540               End If
             
550               row = row + 1
          
560               rstOutput.AddNew
570               rstOutput("Season") = strSeason
580               rstOutput("Period") = intPeriod
590               rstOutput("Species") = strSpecies
600               If getDETDays_SeasonPeriod(intSeason, intPeriod) <> 0 Then
610                   rstOutput("BandedMeanBirds") = Round(dblStat / getCapturesYears_SeasonPeriod(intSeason, intPeriod), 1)
620               Else
630                   rstOutput("BandedMeanBirds") = 0
640               End If

650               rstOutput("YearsInTop10") = lngCountYears
660               rstOutput.Update
                             
670           End If
680           count = count + 1
690           intPeriod_1 = intPeriod
700           dblStat_1 = dblStat
710       End If
720       rst.MoveNext
730   Loop
740   rst.Close
750   Set rst = Nothing

760   .range(.Cells(1, 1), .Cells(1, 8)).Font.Bold = True
770   .range(.columns(1), .columns(8)).AutoFit
780   .columns(6).NumberFormat = "#0.0;-#0.0;#"
          
790   End With

800   Set oSheet = Nothing

      'DD Error Handler Start
Exit_label:
810        Exit Sub
Err_label:
820        Select Case Err.Number
           Case Else
830       Call LogError("basMBO10YearProgramReportSeasonal", "MBO10YearProgramReportSeasonalTop10_Banded")
840        End Select
850        Resume Exit_label
      'DD Error Handler End

End Sub


'---------------------------------------------------------------------------------------
' toFieldnameFLD
'---------------------------------------------------------------------------------------
 
Private Function toFieldnameFLD(ByVal fld As Integer) As String
10    On Error GoTo Err_label

20        Select Case fld
          Case 0
30            toFieldnameFLD = "DET"
40        Case 1
50            toFieldnameFLD = "Banded"
60        Case 2
70            toFieldnameFLD = "Returns"
80        Case 3
90            toFieldnameFLD = "Repeats"
100       End Select

      'DD Error Handler Start
Exit_label:
110        Exit Function
Err_label:
120        Select Case Err.Number
           Case Else
130             Call LogError("basMBO10YearProgramReportSummary", "toFieldnameFLD")
140        End Select
150        Resume Exit_label
      'DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' MBO10YearProgramReportSeasonalDETorBandedSpecies
'---------------------------------------------------------------------------------------
 
Private Sub MBO10YearProgramReportSeasonalDETorBandedSpecies(ByVal intStat As Integer, ByVal local_intPeriodLast_Season As Integer)

      ' intStat = conDET or conBanded

10    On Error GoTo Err_label

      Dim qdf As QueryDef
      Dim rst As DAO.Recordset
      Dim strSQL As String

20    ReDim dblStat(intYearFirst To intYearLast, 1 To local_intPeriodLast_Season) As Double

      Dim intYear As Integer
      Dim intYear_1 As Integer
      Dim intPeriod As Integer
      Dim intPeriod_1 As Integer
      Dim strSpecies As String
      Dim dicSpecies As Scripting.Dictionary

      ' qryMBO10YearProgramReportSeasonal_DETSpecies
      ' --------------------------------------------------------------------------------
      ' For a given season, for each year x period, list the pseudospecies where DET > 0
      ' --------------------------------------------------------------------------------
      ' tblDETSpecies x tblPrograms
      ' WHERE Location = [argLocation]
      ' WHERE MonitoringProgramSeason = [argSeason]
      ' WHERE DET > 0
      ' WHERE YearEx BETWEEN [argYearFirst] AND [argYearLast]
      ' Period: toPeriod([MonitoringProgramSeason],[DateEx],[DateFrom])
      ' WHERE Period <> -1
      ' GROUP BY YearsEx, Period, Species
      ' ORDER BY YearEx,Period
      ' Report YearEx, Period, Species

      ' qryMBO10YearProgramReportSeasonal_BandedSpecies
      ' ===============================================
      ' Same as qryMBO10YearProgramReportSeasonal_DETSpecies
      ' except Banded > 0 instead of DET > 0

30    Select Case intStat
      Case conDET
40        strSQL = "qryMBO10YearProgramReportSeasonal_DETSpecies"
50    Case conBND
60        strSQL = "qryMBO10YearProgramReportSeasonal_BandedSpecies"
70    End Select

80    Set qdf = CurrentDb.QueryDefs(strSQL)
90    qdf.Parameters("argSeason").value = strSeason
100   qdf.Parameters("argLocation").value = strLocation
110   qdf.Parameters("argYearFirst").value = intYearFirst
120   qdf.Parameters("argYearLast").value = intYearLast
130   Set rst = qdf.OpenRecordset

' -----------------------------------------------------------------------------------------------------------------------------------------------------------
' For a given stat (BND or DET) and a given season, fill in dblStat(year, period) with the number of true species for which the stat > 0 in the year x period
' -----------------------------------------------------------------------------------------------------------------------------------------------------------

140   Set dicSpecies = New Scripting.Dictionary
150   intPeriod_1 = Nz(rst("Period"))
160   intYear_1 = Nz(rst("YearEx"))

170   Do While Not rst.EOF
180       intYear = Nz(rst("YearEx"))
190       intPeriod = Nz(rst("Period"))
200       strSpecies = Nz(rst("Species"))
          
210       If intPeriod > 0 Then
220           If (intYear <> intYear_1) Or (intPeriod <> intPeriod_1) Then
230               If dicSpecies.count <> 0 Then
                  
                      ' Process species for previous year and previous period
                      
240                   dblStat(intYear_1, intPeriod_1) = CountSpeciesInDictionary(dicSpecies)
250                   dicSpecies.RemoveAll
260               End If
270               intYear_1 = intYear
280               intPeriod_1 = intPeriod
290           End If
        
        ' Add the pseudo-species to the dictionary
        
300     If Not dicSpecies.Exists(strSpecies) Then
310         Call dicSpecies.Add(strSpecies, strSpecies)
320     End If
        
330       End If

340       rst.MoveNext
350   Loop
360   rst.Close
370   Set rst = Nothing

      ' Process final footer

380   If dicSpecies.count <> 0 Then

          ' Process species for previous year and previousperiod
          
390       dblStat(intYear_1, intPeriod_1) = CountSpeciesInDictionary(dicSpecies)
400       dicSpecies.RemoveAll
410   End If

      ' For each period, count the true species over all years

420   ReDim dblStatAllYears(1 To local_intPeriodLast_Season) As Double

      ' qryMBO10YearProgramReportSeasonal_DETSpeciesTotal
      ' -----------------------------------------------------------------------------------------------------------
      ' For a given season, for each period, list the pseudospecies where DET > 0 during at least one season x year
      ' -----------------------------------------------------------------------------------------------------------
      ' tblDETSpecies x tblPrograms
      ' WHERE Location = [argLocation]
      ' WHERE MonitoringProgramSeason = [argSeason]
      ' WHERE DET > 0
      ' WHERE YearEx BETWEEN [argYearFirst] AND [argYearLast]
      ' Period: toPeriod([MonitoringProgramSeason],[DateEx],[DateFrom])
      ' WHERE Period <> -1
      ' GROUP BY Period, Species
      ' ORDER BY Period
      ' Report Period, Species

      ' qryMBO10YearProgramReportSeasonal_BandedSpeciesTotal
      ' ====================================================
      ' Same as qryMBO10YearProgramReportSeasonal_DETSpeciesTotal
      ' except Banded > 0 instead of DET > 0

430   Select Case intStat
      Case conDET
440       strSQL = "qryMBO10YearProgramReportSeasonal_DETSpeciesTotal"
450   Case conBND
460       strSQL = "qryMBO10YearProgramReportSeasonal_BandedSpeciesTotal"
470   End Select

480   Set qdf = CurrentDb.QueryDefs(strSQL)
490   qdf.Parameters("argSeason").value = strSeason
500   qdf.Parameters("argLocation").value = strLocation
510   qdf.Parameters("argYearFirst").value = intYearFirst
520   qdf.Parameters("argYearLast").value = intYearLast
530   Set rst = qdf.OpenRecordset

' -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
' For a given stat (BND or DET) and a given season, fill in dblStatAllYears(period) with the number of true species for which the stat > 0 in the period for at least one season x year
' -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

540   dicSpecies.RemoveAll
550   intPeriod_1 = Nz(rst("Period"))

560   Do While Not rst.EOF
570       intPeriod = Nz(rst("Period"))
580       strSpecies = Nz(rst("Species"))
          
590       If intPeriod > 0 Then
600           If (intPeriod <> intPeriod_1) Then
610               If dicSpecies.count <> 0 Then
                  
                      ' Process species for previous period
                      
620                   dblStatAllYears(intPeriod_1) = CountSpeciesInDictionary(dicSpecies)
630                   dicSpecies.RemoveAll
640               End If
650               intPeriod_1 = intPeriod
660           End If
        
        ' Add the pseudo-species to the dictionary
        
670     If Not dicSpecies.Exists(strSpecies) Then
680         Call dicSpecies.Add(strSpecies, strSpecies)
690     End If
        
700       End If

710       rst.MoveNext
720   Loop
730   rst.Close
740   Set rst = Nothing

      ' Process final footer

750   If dicSpecies.count <> 0 Then

          ' Process species for previous period
          
760       dblStatAllYears(intPeriod_1) = CountSpeciesInDictionary(dicSpecies)
770       dicSpecies.RemoveAll
780   End If

      ' ===============
      ' Output to Excel
      ' ===============

790   ReDim dblStatMax(1 To local_intPeriodLast_Season) As Double
800   ReDim dblStatMin(1 To local_intPeriodLast_Season) As Double
810   ReDim dblStatMean(1 To local_intPeriodLast_Season) As Double

      Dim oSheet As Excel.Worksheet
820   Set oSheet = InsertSheet(oBook, strSeason)

830   Select Case intStat
      Case conDET
840       oSheet.Name = strSeason & " Seasonal DET Species"
850   Case conBND
860       oSheet.Name = strSeason & " Seasonal BND Species"
870   End Select

880   With oSheet

      Dim Y As Integer
      Dim p As Integer

890   .Cells(1, 1) = "Period"

900   For Y = intYearFirst To intYearLast
910       .Cells(1, toColFromYear(Y)) = Y
920   Next

930   For p = 1 To local_intPeriodLast_Season
940       .Cells(toRowFromPeriod(p), 1) = p
950   Next

960   For Y = intYearFirst To intYearLast
970       For p = 1 To local_intPeriodLast_Season
980           If dblStat(Y, p) <> 0 Then
990               .Cells(toRowFromPeriod(p), toColFromYear(Y)) = dblStat(Y, p)
1000          End If
1010      Next
1020  Next

1030  For p = 1 To local_intPeriodLast_Season
1040      .Cells(toRowFromPeriod(p), toColFromYear(intYearLast) + 1) = dblStatAllYears(p)
1050  Next
1060  .Cells(1, toColFromYear(intYearLast) + 1) = "All Years"

      ' Compute the maximums for each period

1070  For p = 1 To local_intPeriodLast_Season
1080      dblStatMax(p) = 0
1090      For Y = intYearFirst To intYearLast
1100          If dblStatMax(p) < dblStat(Y, p) Then
1110              dblStatMax(p) = dblStat(Y, p)
1120          End If
1130      Next
1140      .Cells(toRowFromPeriod(p), toColFromYear(intYearLast) + 2) = dblStatMax(p)
1150  Next
1160  .Cells(1, toColFromYear(intYearLast) + 2) = "Max"

      ' Compute the average for each period

1170  For p = 1 To local_intPeriodLast_Season
1180      dblStatMean(p) = 0
1190  Next

      Dim dblStatTotal As Double
      Dim intStatCount As Integer

1200  For p = 1 To local_intPeriodLast_Season
1210      dblStatTotal = 0
1220      For Y = intYearFirst To intYearLast
1230          If dblStat(Y, p) <> 0 Then
1240              dblStatTotal = dblStatTotal + dblStat(Y, p)
1250          End If
1260      Next
          
1270      Select Case intStat
          Case conDET
1280          intStatCount = getDETPeriods_SeasonPeriod(intSeason, p)
1290      Case conBND
1300          intStatCount = getCapturesYears_SeasonPeriod(intSeason, p)
1310      End Select
          
1320      If intStatCount <> 0 Then
1330          dblStatMean(p) = Round(dblStatTotal / intStatCount, 0)
1340          .Cells(toRowFromPeriod(p), toColFromYear(intYearLast) + 3) = dblStatMean(p)
1350      End If
1360  Next
1370  .Cells(1, toColFromYear(intYearLast) + 3) = "Mean"

      ' Compute the minimums for each period
      ' Ignore Season x Period x Year in which the stat was not collected

1380  For p = 1 To local_intPeriodLast_Season
1390      dblStatMin(p) = 10000 ' OK since we will never have 10000 species ...
1400      For Y = intYearFirst To intYearLast
          
1410          Select Case intStat
              Case conDET
1420              If getDETDays_SeasonYearPeriod(intSeason, Y, p) > 0 Then
1430                  If dblStatMin(p) > dblStat(Y, p) Then
1440                      dblStatMin(p) = dblStat(Y, p)
1450                  End If
1460              End If
1470          Case conBND
1480              If getCaptureDays_SeasonYearPeriod(intSeason, Y, p) > 0 Then
1490                  If dblStatMin(p) > dblStat(Y, p) Then
1500                      dblStatMin(p) = dblStat(Y, p)
1510                  End If
1520              End If
1530          End Select
              
1540      Next
1550      .Cells(toRowFromPeriod(p), toColFromYear(intYearLast) + 4) = dblStatMin(p)
1560  Next
1570  .Cells(1, toColFromYear(intYearLast) + 4) = "Min"

1580  .range(.Cells(1, toColFromYear(intYearLast) + 1), .Cells(1, toColFromYear(intYearLast) + 4)).HorizontalAlignment = xlRight

1590  End With

1600  Set oSheet = Nothing


      ' tblMBO10YearProgramReportSeasonalDETSpecies
      ' -------------------------------------------
      ' Season                       this table is recreated for each season, so this field will always have the same value
      ' Period
      ' DETSpeciesCumulativeTotal    the number of true species for which DET > 0 for at least one season x year in the period
      ' DETSpeciesMaximum            for the given season x period, max over all years of the number of true species for which DET > 0
      ' DETSpeciesMean                                              mean
      ' DETSpeciesMinimum                                           min
      
      ' tblMBO10YearProgramReportSeasonalBandedSpecies
      ' ------------------------------------------------------------------------------------
      ' Same as tblMBO10YearProgramReportSeasonalDETSpecies except for Banded instead of DET

      Dim strTable As String

1610  Select Case intStat
      Case conDET
1620      strTable = "tblMBO10YearProgramReportSeasonalDETSpecies"
1630  Case conBND
1640      strTable = "tblMBO10YearProgramReportSeasonalBandedSpecies"
1650  End Select

1660  strSQL = "DELETE * FROM " & strTable
1670  CurrentDb.Execute strSQL

1680  Set rst = CurrentDb.OpenRecordset(strTable, dbOpenDynaset)

1690  For p = 1 To local_intPeriodLast_Season
1700      rst.AddNew
1710      rst("Season") = strSeason
1720      rst("Period") = p
1730      rst("DETSpeciesCumulativeTotal") = dblStatAllYears(p)
1740      rst("DETSpeciesMaximum") = dblStatMax(p)
1750      rst("DETSpeciesMean") = dblStatMean(p)
1760      rst("DETSpeciesMinimum") = dblStatMin(p)
1770      rst.Update
1780  Next
1790  rst.Close
1800  Set rst = Nothing

    'DD Error Handler Start
Exit_label:
1810      Exit Sub
Err_label:
1820      Select Case Err.Number
    Case Else
1830     Call LogError("basMBO10YearProgramReportSeasonal", "MBO10YearProgramReportSeasonalDETorBandedSpecies")
1840      End Select
1850      Resume Exit_label
    ' DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' CommonAndUncommonSpecies
'---------------------------------------------------------------------------------------
 
Private Sub CommonAndUncommonSpecies( _
    ByVal strSeason As String, _
    ByVal intYearFirst As Integer, ByVal intYearLast As Integer, _
    ByRef oExcel As Excel.Application, _
    ByRef oBook As Excel.Workbook)

      Dim row As Long
10    On Error GoTo Err_label

20    row = 2
          
      Dim oSheet As Excel.Worksheet
30    Set oSheet = InsertSheet(oBook, strSeason)
40    oSheet.Name = strSeason & " Common Species"
50    With oSheet

      Dim strSQL As String
      Dim qdf As DAO.QueryDef
      Dim lngDET As Long
      Dim strSpeciesEnglish As String
      Dim rst As DAO.Recordset
      Dim intCountYears As Integer
      Dim intAOUOrder As Integer
      Dim dblMeanDET As Double
      Dim intCommon As Integer       '   1=Common     0=Uncommon

60    intCountYears = intYearLast - intYearFirst + 1
70    If intCountYears <= 0 Then GoTo Exit_label

      Dim strSpecies As String

80    .Cells(1, 1) = "Season"
90    .Cells(1, 2) = "AOU Order"
100   .Cells(1, 3) = "Species"
110   .Cells(1, 4) = "English"
120   .Cells(1, 5) = "DET"
130   .Cells(1, 6) = "Mean"
140   .Cells(1, 7) = "1 = Common"

      Dim countCommon As Integer
      Dim countUncommon As Integer

150    countCommon = 0
160    countUncommon = 0


      ' Dim stat As Integer
      ' Dim intYear As Integer
      ' Dim p As Integer

      ' qryMBO10YearProgramReportSeasonal_CommonSpecies
      ' -------------------------------------------------------------------------
      ' List of pseudo-species in tblMBOYearProgramReportSpecies with and DET > 0
      ' for a season (only for Spring and Fall)
      ' -------------------------------------------------------------------------
      ' tblMBO10YearProgramReportSpecies x tblSpecies
      ' Group By Species
      ' Season = [argSeason]
      ' Order By AOUOrder
      ' DET = SUM DET
      ' Having DET > 0
      ' Report Species, SpeciesEnglish, DET

      ' qryMBO10YearProgramReportSeasonal_CommonSpecies_B
      ' -------------------------------------------------------------------------
      ' List of pseudo-species in tblMBOYearProgramReportSpecies with and DET > 0
      ' for a season (only for Spring and Fall)
      ' Is the species common?
      ' -------------------------------------------------------------------------
      ' qryMBO10YearProgramReportSeasonal_CommonSpecies
      ' AOU
      ' Species
      ' SpeciesEnglish
      ' DET
      ' MeanDET: [DET]/[CountYears]
      ' Common: IIf([MeanDET]>=IIf([Season]="Spring",15,20),1,0)
      ' Season
      ' Report Season, AOU, Species, SpeciesEnglish, DET, MeanDET, Common


170   strSQL = "qryMBO10YearProgramReportSeasonal_CommonSpecies_B"

180   Set qdf = CurrentDb.QueryDefs(strSQL)
190   qdf.Parameters("argSeason") = strSeason
200   qdf.Parameters("CountYears") = intYearLast - intYearFirst + 1
210   Set rst = qdf.OpenRecordset

220   Do While Not rst.EOF
230       intAOUOrder = Nz(rst("AOUOrder"))
240       strSpecies = Nz(rst("Species"))
250       strSpeciesEnglish = Nz(rst("SpeciesEnglish"))
260       lngDET = Nz(rst("DET"))
270       dblMeanDET = Nz(rst("MeanDET"))
280       intCommon = Nz(rst("Common"))

290       .Cells(row, 1) = strSeason
300       .Cells(row, 2) = intAOUOrder
310       .Cells(row, 3) = strSpecies
320       .Cells(row, 4) = strSpeciesEnglish
330       .Cells(row, 5) = lngDET
340       .Cells(row, 6) = dblMeanDET
350       If intCommon = 1 Then
360           .Cells(row, 7) = 1
370           countCommon = countCommon + 1
380       Else
390           countUncommon = countUncommon + 1
400       End If

410       row = row + 1

420       rst.MoveNext
430   Loop
440   rst.Close
450   Set rst = Nothing

460   row = row + 1
470   .Cells(row, 6) = "Common pseudo-species"
480   .Cells(row + 1, 6) = "Uncommon pseudo-species"
490   .Cells(row + 2, 6) = "Total pseudo-species"

500   .Cells(row, 7) = countCommon
510   .Cells(row + 1, 7) = countUncommon
520   .Cells(row + 2, 7) = countCommon + countUncommon


530   .range(.columns(1), .columns(6)).AutoFit
540   .range(.columns(6), .columns(6)).NumberFormat = "#0.0"

550   End With

      'DD Error Handler Start
Exit_label:
560        Exit Sub
Err_label:
570        Select Case Err.Number
           Case Else
580             Call LogError("basMBO10YearProgramReportSeasonal", "CommonAndUncommonSpecies")
590        End Select
600        Resume Exit_label
      'DD Error Handler End

End Sub

Private Function toRowFromPeriod(ByVal intPeriod As Integer) As Integer
10        toRowFromPeriod = 1 + intPeriod
End Function

Private Function toColFromYear(ByVal intYear As Integer) As Integer
10        toColFromYear = 2 + intYear - intYearFirst
End Function
