'---------------------------------------------------------------------------------------
' Module: basWin32
' Author: David Davey
'---------------------------------------------------------------------------------------

Option Compare Database
Option Explicit


'Private Declare Function GetDesktopWindow Lib "USER32" () As Long
'
'Private Declare Function FindWindowEx Lib "USER32" Alias _
'  "FindWindowExA" (ByVal hWnd1 As Long, ByVal hWnd2 As Long, ByVal lpsz1 As String, ByVal lpsz2 As String) As Long

#If VBA7 Then
    Public Declare PtrSafe Function GetDesktopWindow Lib "USER32" () As LongPtr
#Else
    Public Declare Function GetDesktopWindow Lib "USER32" () As Long
#End If

#If VBA7 Then
    Public Declare PtrSafe Function FindWindowEx Lib "USER32" _
                                  Alias "FindWindowExA" (ByVal hWnd1 As LongPtr, ByVal hWnd2 As LongPtr, _
                                  ByVal lpsz1 As String, ByVal lpsz2 As String) As LongPtr
#Else
    Public Declare Function FindWindowEx Lib "USER32" _
                                  Alias "FindWindowExA" (ByVal hWnd1 As Long, ByVal hWnd2 As Long, _
                                  ByVal lpsz1 As String, ByVal lpsz2 As String) As Long
#End If

#If VBA7 Then
    Public Declare PtrSafe Function FindWindow Lib "USER32" Alias "FindWindowA" (ByVal lpClassName As String, ByVal lpWindowName As String) As LongPtr
#Else
    Public Declare Function FindWindow Lib "USER32" Alias "FindWindowA" (ByVal lpClassName As String, ByVal lpWindowName As String) As Long
#End If

#If VBA7 Then
    Public Declare PtrSafe Function GetTickCount Lib "kernel32.dll" () As Long
#Else
    Public Declare Function GetTickCount Lib "kernel32.dll" () As Long
#End If

#If VBA7 Then
    Public Declare PtrSafe Function MessageBoxTimeout Lib "user32.dll" Alias "MessageBoxTimeoutA" ( _
    ByVal hwnd As LongPtr, _
    ByVal lpText As String, _
    ByVal lpCaption As String, _
    ByVal uType As Long, _
    ByVal wLanguageID As Long, _
    ByVal lngMilliseconds As Long) As Long
#Else
    Public Declare Function MessageBoxTimeout Lib "user32.dll" Alias "MessageBoxTimeoutA" ( _
    ByVal hwnd As Long, _
    ByVal lpText As String, _
    ByVal lpCaption As String, _
    ByVal uType As Long, _
    ByVal wLanguageID As Long, _
    ByVal lngMilliseconds As Long) As Long
#End If

Sub GetTickCount_Test()
    Dim starttime As Long
    Dim timeelapsed As Long
    starttime = GetTickCount()
    Sleep (3)
    timeelapsed = (GetTickCount() - starttime)
    Call MsgBox(timeelapsed / 1000 & " seconds")
    Call MsgBox(timeelapsed / 60000 & " minutes")
    Call MsgBox(timeelapsed / 3600000 & " hours")
End Sub
