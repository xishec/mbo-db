'---------------------------------------------------------------------------------------
' Module: basSheetNewBandsImport
' Author: David Davey
'---------------------------------------------------------------------------------------

Option Compare Database
Option Explicit

' tblSheetNewBandsMultiSize_v2
' ----------------------------
' BandID                AutoNumber Not imported
' BandSizeID            Number     Not imported

' BandPrefix            Text(4)     Prefix
' BandSuffix            Text(5)     Suffix
' Species               Text(4)
' Age                   Text(1)
' HowAged               Text(1)
' Sex                   Text(1)
' HowSexed              Text(1)
' WingChord             Text(3)     Wing
' Fat                   Text(1)
' Weight                Text(4)                 weight in decigrams
' CaptureDate           Text(4)     MMDD
' WeightTime            Text(3)     HHM
' Bander                Text(3)
' Scribe                Text(3)
' CaptureYear           Text(4)     Year
' Location              Text(255)
' Program               Text(255)
' BirdStatus            Text(3)

' Net                   Text(2)
' ProbableAge           Text(1)
' ProbableSex           Text(1)
' NotesForMBO           Text(255)   Notes
' Valid                 Text(1)     Not imported
' Invalid               Text(1)     Not imported
' Duplicate             Text(1)     Not imported
' BypassErrors          Yes/No
' Disposition           Text(1)      Not imported, = 1

' RemarksForBBO         Text(250)    Not used
' AuxMarkerTYpe         Text(3)      Not used. Replaced by D3
' IsAuxMarkerCoded      Yes/No       Not used. Replaced by D4
' AuxMarkerCode         Text(255)    Not used. Replaced by D5
' AuxMarkerBandColor    Number(Long) Not used. Replaced by D6
' AuxMarkerCodeColor    Number(Long) Not used. Replaced by D7
' AutoHistory           Yes/No
' F                     Text(255)   Not imported
' F1                    Text(255)   Not imported
' ...
' F50                   Text(255)   Not imported
' Flags                 Text(255)   An optional description of why AutoHistory is turned on.
' D1                    Text(255)
' ...
' D40                   Text(255)

' List of the columns on the MBO worksheet

' Prefix                        => BandPrefix
' Suffix                        => BandSuffix
' Species
' Age
' HowAged
' Sex
' HowSexed
' Wing
' Fat
' Weight (in grams)             => Weight (integer in decigrams)
' Day 1-31                      => part of CaptureDate MMDD
' Month                         => part of CaptureDate MMDD
' Year                          => CaptureYear
' WeightTime (Excel date/time)  => WeightTime (HHM format)
' Bander
' Scribe
' Location                      Might have to be translated to an MBO location code
' Program
' BirdStatus

' Net
' ProableSex
' ProbableAge
' Notes                         => part of NotesForMBO
' AutoHistory ("Y" or blank)    => AutoHistory (Yes/No)
' Flags
' ReplacementBand                   => D1
' DETCategoryOverride               => D2
' AuxMarkerType                     => D3
' IsAuxMarkerCoded ("Y" or blank)   => D4 (? how is this stored ?)
' AuxMarkerCode                     => D5
' **** To Do


' D22
' D23
' ...
' D40



Const conFieldBandPrefix            As Integer = 1
Const conFieldBandSuffix            As Integer = 2
Const conFieldSpecies               As Integer = 3
Const conFieldAge                   As Integer = 4
Const conFieldHowAged               As Integer = 5
Const conFieldSex                   As Integer = 6
Const conFieldHowSexed              As Integer = 7
Const conFieldWingChord             As Integer = 8
Const conFieldFat                   As Integer = 9
Const conFieldWeight                As Integer = 10
Const conFieldCaptureDay            As Integer = 11
Const conFieldCaptureMonth          As Integer = 12
Const conFieldCaptureYear           As Integer = 13
Const conFieldWeightTime            As Integer = 14
Const conFieldBander                As Integer = 15
Const conFieldScribe                As Integer = 16
Const conFieldLocation              As Integer = 17
Const conFieldProgram               As Integer = 18
Const conFieldBirdStatus            As Integer = 19

Const conFieldNet                   As Integer = 20
Const conFieldProbableAge           As Integer = 21
Const conFieldProbableSex           As Integer = 22
Const conFieldNotesForMBO           As Integer = 23
Const conFieldAutoHistory           As Integer = 24
Const conFieldFlags                 As Integer = 25
Const conFieldD                    As Integer = 25 ' D1 => 26, D2 => 27, ... D40 => 65

Const conFieldEndObligatory As Integer = 19
Const conFieldEnd        As Integer = 25 + conMaxDataField

'---------------------------------------------------------------------------------------
' Import
'---------------------------------------------------------------------------------------

Public Sub Import(ByRef frm As Form)

      Dim strInputFileFolder As String
      Dim strInputFileName As String
      Dim fDialog As FileDialog
      Dim oExcel As Excel.Application
      Dim oBook As Excel.Workbook
      Dim oSheet As Excel.Worksheet

10    On Error GoTo Err_label

      ' Save the current record if it is dirty

20    frm.Dirty = False

      ' Get the initial folderpath

30    strInputFileFolder = GetSheetNewBandsImportFolder()
40    If strInputFileFolder = "" Then
50        strInputFileFolder = Rep_Documents()
60    End If
70    If Not FolderExists(strInputFileFolder) Then
80        strInputFileFolder = Rep_Documents()
90    End If

      ' Get the filepath from the user

100   Set fDialog = Application.FileDialog(msoFileDialogFilePicker)
110   fDialog.AllowMultiSelect = False
120   fDialog.Title = "Select the Excel New Bands File"
130   fDialog.InitialFileName = strInputFileFolder
140   fDialog.Filters.Clear
150   fDialog.Filters.Add "Excel files (*.xlsx,*xlsm, *xls)", "*.xlsx;*.xlsm;*.xls"
160   If fDialog.Show = -1 Then                                                  'Show the dialog. -1 means success!
170       strInputFileName = fDialog.SelectedItems(1)
180   Else
190       Exit Sub
200   End If

      ' Verify that the file exists
210   If Not FileExists(strInputFileName) Then
220       MsgBox "The selected file does not exist " & strInputFileName, vbExclamation, "Import New Bands"
230       Exit Sub
240   End If

250   PutSheetNewBandsImportFolder (FolderFromPath(strInputFileName))

      ' Open the Excel workbook

260   Set oExcel = New Excel.Application
270   oExcel.Visible = False

280   Set oBook = oExcel.Workbooks.Open(strInputFileName)

      ' Open the "MBO" worksheet

      Dim intSheet As Integer
      Dim fMBOSheetExists As Boolean

290   fMBOSheetExists = False
300   For intSheet = 1 To oBook.Sheets.count
310       If oBook.Sheets(intSheet).Name = "MBO" Then
320           Set oSheet = oBook.Sheets(intSheet)
330           fMBOSheetExists = True
340       End If
350   Next
360   If Not fMBOSheetExists Then
370       MsgBox "The Excel workbook does not have an MBO worksheet", vbExclamation, "Import New Bands"
380       GoTo Exit_label
390   End If

400   With oSheet

      Dim intFieldNumber As Integer

      Dim arrField(1 To conFieldEnd) As Integer
410   For intFieldNumber = 1 To conFieldEnd
420       arrField(intFieldNumber) = 0
430   Next

      ' What is the last column

      ' N.B. columns with blank or unrecognized headers will be ignored

      Dim colEnd As Long

440   colEnd = .Cells(1, .columns.count).End(xlToLeft).column

      Dim col As Long

      ' Fill in the array of field# => column

      Dim arrFieldName(1 To conFieldEnd) As String
      Dim arrFieldCol(1 To conFieldEnd) As Long
      Dim strFieldname As String

450   arrFieldName(conFieldBandPrefix) = "Prefix"
460   arrFieldName(conFieldBandSuffix) = "Suffix"
470   arrFieldName(conFieldSpecies) = "Species"
480   arrFieldName(conFieldAge) = "Age"
490   arrFieldName(conFieldHowAged) = "HowAged"
500   arrFieldName(conFieldSex) = "Sex"
510   arrFieldName(conFieldHowSexed) = "HowSexed"
520   arrFieldName(conFieldWingChord) = "Wing"
530   arrFieldName(conFieldFat) = "Fat"
540   arrFieldName(conFieldWeight) = "Weight"
550   arrFieldName(conFieldCaptureDay) = "Day"
560   arrFieldName(conFieldCaptureMonth) = "Month"
570   arrFieldName(conFieldCaptureYear) = "Year"
580   arrFieldName(conFieldWeightTime) = "WeightTime"
590   arrFieldName(conFieldBander) = "Bander"
600   arrFieldName(conFieldScribe) = "Scribe"
610   arrFieldName(conFieldLocation) = "Location"
620   arrFieldName(conFieldProgram) = "Program"
630   arrFieldName(conFieldBirdStatus) = "BirdStatus"
640   arrFieldName(conFieldNet) = "Net"
650   arrFieldName(conFieldProbableAge) = "ProbableAge"
660   arrFieldName(conFieldProbableSex) = "ProbableSex"
670   arrFieldName(conFieldNotesForMBO) = "Notes"
680   arrFieldName(conFieldAutoHistory) = "AutoHistory"
690   arrFieldName(conFieldFlags) = "Flags"
700   arrFieldName(conFieldD + 1) = "ReplacementBand"
710   arrFieldName(conFieldD + 2) = "DETCategoryOverride"
720   arrFieldName(conFieldD + 3) = "AUXMarkerType"
730   arrFieldName(conFieldD + 4) = "IsAuxMarkerCoded"
740   arrFieldName(conFieldD + 5) = "AuxMarkerCode"
750   arrFieldName(conFieldD + 6) = "AuxMarkerBandColor"
760   arrFieldName(conFieldD + 7) = "AuxMarkerCodeColor"
770   arrFieldName(conFieldD + 8) = "LeftLegColor1"
780   arrFieldName(conFieldD + 9) = "LeftLegColor2"
790   arrFieldName(conFieldD + 10) = "LeftLegColor3"
800   arrFieldName(conFieldD + 11) = "RightLegColor1"
810   arrFieldName(conFieldD + 12) = "RightLegColor2"
820   arrFieldName(conFieldD + 13) = "RightLegColor3"

      Dim D As Integer
830   For D = 22 To conMaxDataField
840       arrFieldName(conFieldD + D) = "D" & D
850   Next D

      Dim var As Variant

860   For intFieldNumber = 1 To conFieldEnd
870       strFieldname = arrFieldName(intFieldNumber)
880       var = oExcel.Match(strFieldname, .range(.Cells(1, 1), .Cells(1, colEnd)), 0)
890       If IsNumeric(var) Then
900           arrFieldCol(intFieldNumber) = var
910       End If
920   Next

      ' Are there any missing required fields

      Dim strErr As String
930   strErr = ""

940   For intFieldNumber = 1 To conFieldEndObligatory
950       If arrFieldCol(intFieldNumber) = 0 Then
960           strErr = strErr & vbCr & arrFieldName(intFieldNumber)
970       End If
980   Next
990   If strErr <> "" Then
1000      MsgBox "Missing fields:" & strErr
1010      GoTo Exit_label
1020  End If

      ' How many rows

      Dim rowEnd As Long
      Dim row As Long

1030  row = 2
1040  Do While True
1050      If .Cells(row, arrFieldCol(conFieldBandPrefix)) = "0000" Or Trim(.Cells(row, arrFieldCol(conFieldBandPrefix))) = "" Then
1060          Exit Do
1070      End If
1080      row = row + 1
1090  Loop
1100  rowEnd = row - 1

      ' Flag any rows that contain validation errors

1110  ReDim fRowHasValidationErrors(2 To rowEnd)

1120  For row = 2 To rowEnd
1130      fRowHasValidationErrors(row) = False
1140  Next

      Dim strErrGlobal As String

1150  strErrGlobal = ""

      ' Basic validation

      Dim strCaptureDay As String
      Dim intCaptureDay As Integer
      Dim strCaptureMonth As String
      Dim intCaptureMonth As Integer

      Dim strWeightFormatted As String
      Dim fWeightOK As Boolean
      Dim strPrefixWeight As String
      Dim strSuffixWeight As String
      Dim strChar As String
      Dim pos As Integer
      Dim i As Integer


1160  For row = 2 To rowEnd
          
1170      SysCmd acSysCmdSetStatus, "Validating row " & row

1180      strErr = ""
1190      For intFieldNumber = 1 To conFieldEnd
1200          col = arrFieldCol(intFieldNumber)
1210          If col <> 0 Then
1220              Select Case intFieldNumber
                  Case conFieldBandPrefix
                      ' Validate BandPrefix
1230                  If Len(.Cells(row, arrFieldCol(conFieldBandPrefix))) <> 4 Then
1240                      strErr = strErr & vbCrLf & "Prefix not 4 characters"
1250                  End If
1260              Case conFieldBandSuffix
                      ' Validate BandSuffix
1270                  If Len(.Cells(row, arrFieldCol(conFieldBandSuffix))) <> 5 Then
1280                      strErr = strErr & vbCrLf & "Suffix not 5 characters"
1290                  End If
1300              Case conFieldSpecies
                      ' Validate Species
1310                  If Len(.Cells(row, arrFieldCol(conFieldSpecies))) <> 4 Then
1320                      strErr = strErr & vbCrLf & "Species not 4 characters"
1330                  End If
1340              Case conFieldAge
                      ' Validate Age
1350                  If Len(.Cells(row, arrFieldCol(conFieldAge))) <> 0 Then
1360                      If Len(.Cells(row, arrFieldCol(conFieldAge))) <> 1 Then
1370                          strErr = strErr & vbCrLf & "Age not 1 character or blank"
1380                      End If
1390                  End If
1400              Case conFieldHowAged
                      ' Validate How Aged
1410                  If Len(.Cells(row, arrFieldCol(conFieldHowAged))) <> 0 Then
1420                      If Len(.Cells(row, arrFieldCol(conFieldHowAged))) <> 1 Then
1430                          strErr = strErr & vbCrLf & "How Aged not 1 character or blank"
1440                      End If
1450                  End If
1460              Case conFieldSex
                      ' Validate Sex
1470                  If Len(.Cells(row, arrFieldCol(conFieldSex))) <> 0 Then
1480                      If Len(.Cells(row, arrFieldCol(conFieldSex))) <> 1 Then
1490                          strErr = strErr & vbCrLf & "Sex not 1 character or blank"
1500                      End If
1510                  End If
1520              Case conFieldHowSexed
                      ' Validate How Sexed
1530                  If Len(.Cells(row, arrFieldCol(conFieldHowSexed))) <> 0 Then
1540                      If Len(.Cells(row, arrFieldCol(conFieldHowSexed))) <> 1 Then
1550                          strErr = strErr & vbCrLf & "How Sexed not 1 character or blank"
1560                      End If
1570                  End If
1580              Case conFieldWingChord
                      ' Validate Wing Chord
1590                  If Len(.Cells(row, arrFieldCol(conFieldWingChord))) <> 0 Then
1600                      If Len(.Cells(row, arrFieldCol(conFieldWingChord))) > 3 Then
1610                          strErr = strErr & vbCrLf & "Wing Chord not less than or equal to 3 characters or blank"
1620                      End If
1630                  End If
1640               Case conFieldFat
                      ' Validate Fat
1650                  If Len(.Cells(row, arrFieldCol(conFieldFat))) <> 0 Then
1660                      If Len(.Cells(row, arrFieldCol(conFieldFat))) <> 1 Then
1670                          strErr = strErr & vbCrLf & "Fat not 1 character or blank"
1680                      End If
1690                  End If
1700               Case conFieldWeight
                      ' Validate Weight [0 to 3 digits][.|,][0 to 1 digits]  but not [.|,]
1710                  fWeightOK = True
1720                  strPrefixWeight = "000"
1730                  strSuffixWeight = "0"
1740                  strWeightFormatted = .Cells(row, arrFieldCol(conFieldWeight))
                      
                      ' Only digits, period, comma
1750                  For i = 1 To Len(strWeightFormatted)
1760                      strChar = Mid(strWeightFormatted, i, 1)
1770                      If Not (strChar = "." Or strChar = "," Or (strChar >= "0" And strChar <= "9")) Then
1780                          fWeightOK = False
1790                      End If
1800                  Next i
1810                  If fWeightOK Then

1820                      pos = InStr(strWeightFormatted, ".")
1830                      If pos <> 0 Then
                              ' decimal point
                              ' get the digits in front of the decimal
1840                          If pos > 1 Then
1850                             strPrefixWeight = Left(strWeightFormatted, pos - 1)
1860                          End If
                              ' get the digit behind the decimal
1870                          If pos < Len(strWeightFormatted) Then
1880                              strSuffixWeight = Mid(strWeightFormatted, pos + 1, 1)
1890                              If pos + 1 < Len(strWeightFormatted) Then
1900                                  fWeightOK = False
1910                              End If
1920                          End If
                          
1930                      Else
1940                          pos = InStr(strWeightFormatted, ",")
1950                          If pos <> 0 Then
                                 ' decimal comma
1960                              If pos > 1 Then
1970                                  strPrefixWeight = Left(strWeightFormatted, pos - 1)
1980                              End If
1990                              If pos < Len(strWeightFormatted) Then
2000                                  strSuffixWeight = Mid(strWeightFormatted, pos + 1, 1)
2010                                  If pos + 1 < Len(strWeightFormatted) Then
2020                                      fWeightOK = False
2030                                  End If
2040                              End If
                          
2050                          Else
                                 ' no decimal    N.B.  empty string is OK
2060                              strPrefixWeight = strWeightFormatted
2070                          End If
2080                      End If
         
2090                      strWeightFormatted = strPrefixWeight & strSuffixWeight
2100                      If Len(strWeightFormatted) > 4 Then
2110                          fWeightOK = False
2120                      End If
2130                  End If
2140                  If Not fWeightOK Then
2150                      strErr = strErr & vbCrLf & "Invalid weight"
2160                  End If
                          
2170                Case conFieldCaptureDay
                          ' Validate Capture Day
2180                      strCaptureDay = .Cells(row, arrFieldCol(conFieldCaptureDay))
2190                      If strCaptureDay <> "" Then
2200                          If IsNumeric(strCaptureDay) Then
2210                              intCaptureDay = CInt(strCaptureDay)
2220                              If intCaptureDay < 0 Or intCaptureDay > 31 Then
2230                                  strErr = strErr & vbCrLf & "Day is not between 1 and 31 or blank"
2240                              End If
2250                          Else
2260                              strErr = strErr & vbCrLf & "Day is not between 1 and 31 or blank"
2270                          End If
2280                      End If
2290                Case conFieldCaptureMonth
                          ' Validate Capture Month
2300                      strCaptureMonth = .Cells(row, arrFieldCol(conFieldCaptureMonth))
2310                      If strCaptureMonth <> "" Then
2320                          If IsNumeric(strCaptureMonth) Then
2330                              intCaptureMonth = CInt(strCaptureMonth)
2340                              If intCaptureMonth < 0 Or intCaptureMonth > 12 Then
2350                                  strErr = strErr & vbCrLf & "Month is not between 1 and 12 or blank"
2360                              End If
2370                          Else
2380                              strErr = strErr & vbCrLf & "Month is not between 1 and 31 or blank"
2390                          End If
2400                      End If
2410                Case conFieldWeightTime
                          ' Validate Weight Time
2420                 Case conFieldBander
                          ' Validate Bander
                                              
2430                      If Len(.Cells(row, arrFieldCol(conFieldBander))) <> 0 Then
2440                          If Len(.Cells(row, arrFieldCol(conFieldBander))) > 3 Then
2450                              strErr = strErr & vbCrLf & "Bander not less than or equal to 3 characters or blank"
2460                          End If
2470                      End If
2480                 Case conFieldScribe
                          ' Validate Scribe
2490                      If Len(.Cells(row, arrFieldCol(conFieldScribe))) <> 0 Then
2500                          If Len(.Cells(row, arrFieldCol(conFieldScribe))) > 3 Then
2510                              strErr = strErr & vbCrLf & "Scribe not less than or equal to 3 characters or blank"
2520                          End If
2530                      End If
2540                 Case conFieldCaptureYear
                          ' Validate Capture Year
2550                      If Len(.Cells(row, arrFieldCol(conFieldCaptureYear))) <> 4 Then
2560                          strErr = strErr & vbCrLf & "Capture year not 4 characters"
2570                      End If
                          
                     ' The following fields can be blank
                          
2580                 Case conFieldNet
                          ' Validate Net
2590                      If Len(.Cells(row, arrFieldCol(conFieldNet))) > 2 Then
2600                          strErr = strErr & vbCrLf & "Net not less than or equal to 2 characters"
2610                      End If
2620                  Case conFieldProbableAge
                          ' Validate ProableAge
2630                      If Len(.Cells(row, arrFieldCol(conFieldProbableAge))) > 1 Then
2640                          strErr = strErr & vbCrLf & "Probable Age not 1 character or blank"
2650                      End If
2660                  Case conFieldProbableSex
                          ' Validate ProableSex
2670                      If Len(.Cells(row, arrFieldCol(conFieldProbableSex))) > 1 Then
2680                          strErr = strErr & vbCrLf & "Probable Sex not 1 character or blank"
2690                      End If
2700                  Case conFieldAutoHistory
                          ' Validate AutoHistory
                          Dim strAutoHistory As String
2710                      strAutoHistory = UCase(Trim(.Cells(row, arrFieldCol(conFieldAutoHistory))))
2720                      If Not (strAutoHistory = "Y" Or strAutoHistory = "") Then
2730                          strErr = strErr & vbCrLf & "AutoHistory is not Y or blank"
2740                      End If
                      
2750              End Select
2760          End If
2770      Next
2780      If strErr <> "" Then
2790          fRowHasValidationErrors(row) = True
2800          strErrGlobal = strErrGlobal & "Error(s) in row " & row & strErr & vbCrLf
2810      End If

2820  Next

2830  If strErrGlobal <> "" Then
2840      oExcel.Visible = False
2850      If vbYes <> MsgBox("The following records contain errors. Do you wish to import the rows that do not contain errors?" & vbCrLf & strErrGlobal, vbYesNo, "Import") Then
2860          GoTo Exit_label
2870      End If
2880  End If

      ' Import

      Dim MMDD As String
      Dim strWeight As String
      Dim strWingChord As String
      Dim lngWingChord As Long

      Dim rst As DAO.Recordset
2890  Set rst = CurrentDb.OpenRecordset("tblSheetNewBandsMultiSize_v2", dbOpenDynaset)

2900  For row = 2 To rowEnd
2910      If Not fRowHasValidationErrors(row) Then
          
2920          SysCmd acSysCmdSetStatus, "Importing row " & row
          
2930          rst.AddNew
2940          rst("BandPrefix") = .Cells(row, arrFieldCol(conFieldBandPrefix))
2950          rst("BandSuffix") = .Cells(row, arrFieldCol(conFieldBandSuffix))
2960          rst("Species") = .Cells(row, arrFieldCol(conFieldSpecies))
2970          rst("Age") = .Cells(row, arrFieldCol(conFieldAge))
2980          rst("HowAged") = .Cells(row, arrFieldCol(conFieldHowAged))
2990          rst("Sex") = .Cells(row, arrFieldCol(conFieldSex))
3000          rst("HowSexed") = .Cells(row, arrFieldCol(conFieldHowSexed))
          
3010          strWingChord = .Cells(row, arrFieldCol(conFieldWingChord))
3020          If IsNumeric(strWingChord) Then
3030              lngWingChord = CLng(strWingChord)
3040              If lngWingChord > 0 Then
3050                  rst("WingChord") = lngWingChord
3060              End If
3070          End If
          
3080          rst("Fat") = .Cells(row, arrFieldCol(conFieldFat))
          
3090          If .Cells(row, arrFieldCol(conFieldWeight)) = "" Then
3100              rst("Weight") = ""
3110          Else
                  ' Extract digits in front of either a decimal point or a decimal comma
                  ' Extract 1 digit after either a decimal point or a decimal comma
                  ' the prefix concat 1 digit suffix is the weight in decigrams to be stored
                  
3120              strWeightFormatted = .Cells(row, arrFieldCol(conFieldWeight))
3130              strPrefixWeight = "000"
3140              strSuffixWeight = "0"
3150              pos = InStr(strWeightFormatted, ".")
3160              If pos <> 0 Then
3170                  strPrefixWeight = Left(strWeightFormatted, pos - 1)
3180                  If Len(strWeightFormatted) > pos Then
3190                      strSuffixWeight = Mid(strWeightFormatted, pos + 1, 1)
3200                  End If
3210              Else
3220                 pos = InStr(strWeightFormatted, ",")
3230                 If pos <> 0 Then
3240                      strPrefixWeight = Left(strWeightFormatted, pos - 1)
3250                      If Len(strWeightFormatted) > pos Then
3260                          strSuffixWeight = Mid(strWeightFormatted, pos + 1, 1)
3270                      End If
3280                 Else
3290                      strPrefixWeight = strWeightFormatted
3300                 End If
3310              End If
3320              strWeight = strPrefixWeight & strSuffixWeight
3330              rst("Weight") = IIf(strWeight = "0000", "", strWeight)
3340          End If
              
3350          rst("CaptureDate") = Format(.Cells(row, arrFieldCol(conFieldCaptureMonth)), "00") & _
                                   Format(.Cells(row, arrFieldCol(conFieldCaptureDay)), "00")
                                   
3360          rst("WeightTime") = Left(Format(.Cells(row, arrFieldCol(conFieldWeightTime)), "HHMM"), 3)
              
3370          rst("Bander") = .Cells(row, arrFieldCol(conFieldBander))
3380          rst("Scribe") = .Cells(row, arrFieldCol(conFieldScribe))
3390          rst("CaptureYear") = .Cells(row, arrFieldCol(conFieldCaptureYear))
3400          rst("Location") = .Cells(row, arrFieldCol(conFieldLocation))
3410          rst("Program") = .Cells(row, arrFieldCol(conFieldProgram))
3420          rst("BirdStatus") = .Cells(row, arrFieldCol(conFieldBirdStatus))
             
3430          rst("Disposition") = "1"
          
3440          If arrFieldCol(conFieldNet) <> 0 Then
3450              rst("Net") = .Cells(row, arrFieldCol(conFieldNet))
3460          End If
          
3470          If arrFieldCol(conFieldProbableAge) <> 0 Then
3480              rst("ProbableAge") = .Cells(row, arrFieldCol(conFieldProbableAge))
3490          End If
          
3500          If arrFieldCol(conFieldProbableSex) <> 0 Then
3510              rst("ProbableSex") = .Cells(row, arrFieldCol(conFieldProbableSex))
3520          End If
          
3530          If arrFieldCol(conFieldNotesForMBO) <> 0 Then
3540              rst("NotesForMBO") = .Cells(row, arrFieldCol(conFieldNotesForMBO))
3550          End If
          
3560          If arrFieldCol(conFieldAutoHistory) <> 0 Then
3570              strAutoHistory = UCase(Trim(.Cells(row, arrFieldCol(conFieldAutoHistory))))
3580              rst("AutoHistory") = (strAutoHistory = "Y")
3590          End If
              
3600          If arrFieldCol(conFieldFlags) <> 0 Then
3610              rst("Flags") = .Cells(row, arrFieldCol(conFieldFlags))
3620          End If
              
3630          For D = 1 To 40
3640              If arrFieldCol(conFieldD + D) <> 0 Then
3650                  rst("D" & D) = .Cells(row, arrFieldCol(conFieldD + D))
3660              End If
3670          Next D
          
3680          rst.Update
             
              Dim strExternalLoggingError As String
             
              Dim lngBandID As Long
3690          rst.Move 0, rst.LastModified
3700          lngBandID = rst("BandID")
3710          Call Form_AfterUpdate_v2("tblSheetNewBandsMultiSize_v2", lngBandID, strExternalLoggingError)
3720      End If
          
3730  Next
3740  rst.Close
3750  Set rst = Nothing

3760  End With

3770  frm.Requery

          'DD Error Handler Start
Exit_label:

3780  SysCmd acSysCmdClearStatus
3790  oBook.Close saveChanges:=False
3800  oExcel.Quit
3810  Set oSheet = Nothing
3820  Set oBook = Nothing

3830  Set oExcel = Nothing

3840      Exit Sub
Err_label:
3850      Select Case Err.Number
          Case Else
3860           Call LogError("basSheetNewBandsImport", "Import")
3870      End Select
3880      Resume Exit_label
          ' DD Error Handler End

End Sub
