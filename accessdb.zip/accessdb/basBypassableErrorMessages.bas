'---------------------------------------------------------------------------------------
' Module    : basBypassableErrorMessages
' Author    : David Davey
'---------------------------------------------------------------------------------------

Option Compare Database
Option Explicit

' Private BypassableErrorMessage_m() As String
Private strBypassableErrorMessageCurrentProgram As String       ' "" if the current program is unknown
                                                      
''---------------------------------------------------------------------------------------
'' ListByPassableErrorMessages
''
'' Create a string. Each line of the string contains
'' an error# and and the currently allocated error message
''---------------------------------------------------------------------------------------
'
'Public Function ListByPassableErrorMessages() As String
'
'10    On Error GoTo Err_label
'
'      Dim intUBound As Integer
'      Dim msg As String
'
'20    msg = "Current Program = " & strBypassableErrorMessageCurrentProgram & vbCrLf & vbCrLf
'
'30    On Error Resume Next
'40    intUBound = UBound(BypassableErrorMessage_m)
'50    If Err.Number <> 0 Then
'60        msg = msg & "BypassableErrorMessage_m() has no upper bound"
'70    Else
'80        msg = msg & "Upper bound of BypassableErrorMessage_m array = " & intUBound & vbCrLf & vbCrLf
'          Dim i As Integer
'90        For i = 1 To UBound(BypassableErrorMessage_m)
'100           msg = msg & i & " " & BypassableErrorMessage_m(i) & vbCrLf
'110       Next i
'120   End If
'
'130   ListByPassableErrorMessages = msg
'
'      'DD Error Handler Start
'Exit_label:
'140        Exit Function
'Err_label:
'150        Select Case Err.Number
'           Case Else
'160             Call LogError("basBypassableErrorMessages", "ListByassableErrorMessages")
'170        End Select
'180        Resume Exit_label
'      'DD Error Handler End
'End Function
    
''---------------------------------------------------------------------------------------
'' IsBypassableErrorMessageAllocated
''---------------------------------------------------------------------------------------
'
'Public Function IsBypassableErrorMessageAllocated(ByRef strErrorMsg As String) As Boolean
'
'10    On Error GoTo Err_label
'
'      Dim intUBound As Integer
'
'20    strErrorMsg = ""
'
'30    On Error Resume Next
'40    intUBound = UBound(BypassableErrorMessage_m)
'50    If Err.Number <> 0 Then
'60        IsBypassableErrorMessageAllocated = False
'70        strErrorMsg = "BypassableErrorMessage_m has no upper bound"
'80    ElseIf intUBound = 0 Then
'90        IsBypassableErrorMessageAllocated = False
'100       strErrorMsg = "BypassableErrorMessage_m has an upper bound = 0 "
'110   Else
'120       IsBypassableErrorMessageAllocated = True
'130   End If
'
'140   If Not IsBypassableErrorMessageAllocated Then
'150       Call MBODataEntryRefreshTitleBar("Bypassable Error Message array not allocated")
'160   End If
'
'      'DD Error Handler Start
'Exit_label:
'170        Exit Function
'Err_label:
'180        Select Case Err.Number
'           Case Else
'190       Call LogError("basBypassableErrorMessages", "IsBypassableErrorMessageAllocated")
'200        End Select
'210        Resume Exit_label
'      'DD Error Handler End
'
'End Function
    
'---------------------------------------------------------------------------------------
' BypassableErrorMessage
'
' PRE: strBypassableErrorMessageCurrentProgram contains the current program or ""
'---------------------------------------------------------------------------------------
 
Public Function BypassableErrorMessage(ByVal intErrorMessageNumber As Integer) As String

10    On Error GoTo Err_label

      Dim strErrorMessage As String

      ' Get the bypassable error message from tblBypassableErrorMessage

20    strErrorMessage = Nz(DLookup("English", "tblBypassableErrorMessage", "[BypassableErrorMessageID] = " & intErrorMessageNumber))


      ' If this bypassable error message is suppressed for the current program, then suppress it

      Dim strWhere As String

30    strWhere = _
          "([BypassableErrorMessageID] = " & intErrorMessageNumber & ") AND " & _
          "([Program] = '" & strBypassableErrorMessageCurrentProgram & "')"
          
40    If 0 < DCount("*", "tblSuppressBypassableErrorMessageByProgram", strWhere) Then
50        strErrorMessage = ""
60    End If

70    BypassableErrorMessage = strErrorMessage

      '' Track down ByPassableErrorMessage_m allocation error
      '
      'Dim strBypassableErrorMessageAllocationErrorMessage As String
      'If Not IsBypassableErrorMessageAllocated(strBypassableErrorMessageAllocationErrorMessage) Then
      '    MsgBox "Lookup Bypassable Error Message: " & strBypassableErrorMessageAllocationErrorMessage
      'End If
      '
      'On Error Resume Next
      'strErrorMessage = BypassableErrorMessage_m(intErrorMessageNumber)
      'If Err.Number <> 0 Then
      '    Call LogError("basBypassableErrorMessages", "BypassableErrorMessage", "Index error looking up error message")
      '    Err.Clear
      'End If
      'On Error GoTo Err_label
      '
      'BypassableErrorMessage = strErrorMessage

      'DD Error Handler Start
Exit_label:
80         Exit Function
Err_label:
90         Select Case Err.Number
           Case Else
100             Call LogError("basBypassableErrorMessages", "BypassableErrorMessage")
110        End Select
120        Resume Exit_label
      'DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' SetBypassableErrorMessageCurrentProgram
'---------------------------------------------------------------------------------------
'
Public Sub SetBypassableErrorMessageCurrentProgram(ByVal strProgram As String)

10    On Error GoTo Err_label

20    strBypassableErrorMessageCurrentProgram = strProgram

'      Dim rst As DAO.Recordset
'      Dim strSQL As String
'      Dim intDimBypassableErrorMessage As Integer
'      Dim intBypassableErrorMessageID As Integer
'      Dim strEnglish As String
'
'      ' If necessary reload the ByPassableErrorMessage_m allocation error
'
'      Dim strBypassableErrorMessageAllocationErrorMessage As String
'20    If Not IsBypassableErrorMessageAllocated(strBypassableErrorMessageAllocationErrorMessage) Then
'30        Call AllocateAndSetBypassableErrorMessageCurrentProgram
'40    End If
'
'50    If strProgram <> strBypassableErrorMessageCurrentProgram Then
'
'60        strBypassableErrorMessageCurrentProgram = strProgram
'
'        ' Load the BypassableErrorMessage_m() array with all bypassable error messages
'
'70        Set rst = CurrentDb.OpenRecordset("tblBypassableErrorMessage", dbOpenDynaset)
'80        Do While Not rst.EOF
'90            intBypassableErrorMessageID = Nz(rst("BypassableErrorMessageID"))
'100           strEnglish = Nz(rst("English"))
'110           BypassableErrorMessage_m(intBypassableErrorMessageID) = strEnglish
'120           rst.MoveNext
'130       Loop
'140       rst.Close
'
'          ' Suppress any program specific suppressed messages
'
'150       If strProgram <> "" Then
'
'160     strSQL = _
'            "SELECT * FROM tblSuppressBypassableErrorMessageByProgram " & _
'            "WHERE [Program] = '" & strProgram & " '"
'
'170     Set rst = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)
'180     Do While Not rst.EOF
'190         intBypassableErrorMessageID = Nz(rst("BypassableErrorMessageID"))
'200         BypassableErrorMessage_m(intBypassableErrorMessageID) = ""
'210         rst.MoveNext
'220     Loop
'230     rst.Close
'240     Set rst = Nothing
'250       End If
'
'260   End If

      'DD Error Handler Start
Exit_label:
30         Exit Sub
Err_label:
40         Select Case Err.Number
           Case Else
50        Call LogError("basBypassableErrorMessages", "SetBypassableErrorMessageCurrentProgram")
60         End Select
70         Resume Exit_label
      'DD Error Handler End

End Sub

''---------------------------------------------------------------------------------------
'' AllocateAndSetBypassableErrorMessageCurrentProgram
''---------------------------------------------------------------------------------------
'
'Public Sub AllocateAndSetBypassableErrorMessageCurrentProgram()
'
'10    On Error GoTo Err_label
'
''      ' Allocate
''
''      Dim intDimBypassableErrorMessage As Integer
''
''20    intDimBypassableErrorMessage = DCount("*", "tblBypassableErrorMessage", True)
''30    ReDim BypassableErrorMessage_m(intDimBypassableErrorMessage)
''
''      ' Load the BypassableErrorMessage_m() array with all bypassable error messages
''
''      Dim rst As DAO.Recordset
''      Dim strSQL As String
'
'40    strBypassableErrorMessageCurrentProgram = ""
'
''50    Set rst = CurrentDb.OpenRecordset("tblBypassableErrorMessage", dbOpenDynaset)
''60    Do While Not rst.EOF
''70        BypassableErrorMessage_m(rst("BypassableErrorMessageID")) = _
''              Nz(rst("English"))
''80        rst.MoveNext
''90    Loop
''100   rst.Close
'
'      'DD Error Handler Start
'Exit_label:
'110        Exit Sub
'Err_label:
'120        Select Case Err.Number
'           Case Else
'130       Call LogError("basBypassableErrorMessages", "AllocateAndSetBypassableErrorMessageCurrentProgram")
'140        End Select
'150        Resume Exit_label
'      'DD Error Handler End
'
'End Sub
