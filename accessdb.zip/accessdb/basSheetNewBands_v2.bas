'---------------------------------------------------------------------------------------
' Module    : basSheetNewBands_v2
' Author    : David Davey
'---------------------------------------------------------------------------------------

Option Compare Database
Option Explicit

Const strTableStore As String = "tblCaptures"

'---------------------------------------------------------------------------------------
' Form_AfterUpdate_v2
'
' strTableSheet is  "tblSheetNewBandsMultiSize_v2"
'---------------------------------------------------------------------------------------
' PRE strExternalLoggingError = ""
'
' Called from frmSheetNewBandsMutiSize_v2.Form_AfterUpdate
'             basSheetNewBandsImport.Import

Public Sub Form_AfterUpdate_v2(ByVal strTableSheet As String, ByVal lngBandID As Long, ByRef strExternalLoggingError As String)

10    On Error GoTo Err_label

      Dim strNotBypassableMsg As String
      Dim strBypassableMsg As String
      Dim fDuplicateNewCapture As Boolean
      Dim fIsNewRecord As Boolean
      Dim B_typed As SheetNewBandRecordType
      Dim B_variant As SheetNewBandsType
      Dim rst As DAO.Recordset

          ' D16 (Creation Timestamp) is blank,  <=> this is a new recording

20    Call AnalyseNotesNewBands(strTableSheet, lngBandID)

30    Call basSheetNewBands_v2.GetRecord_v2(strTableSheet, lngBandID, B_typed)

      Dim IsValid As basTypes.IsValidType
40    Call ValidateRecord_SheetNewBand_v2(strTableSheet, B_typed, _
          strNotBypassableMsg, strBypassableMsg, _
          fDuplicateNewCapture, _
          False, IsValid)

50    If Not IsValid.IsBandValid Then GoTo Exit_label

60    Call ProcessAutoHistory("Bands", B_typed.BandPrefix, B_typed.BandSuffix, 0)

70    Set rst = CurrentDb.OpenRecordset("SELECT * FROM tblSheetNewBandsMultiSize_v2 WHERE [BandID] = " & lngBandID, dbOpenDynaset)

80    If rst.EOF Then
90        Call LogError("basSheetNewBands_v2", "Form_AfterUpdate", "ERROR - Did not get Band Sheet", True, 1)
100       On Error Resume Next
110       rst.Close
120       On Error GoTo Err_label
130       Set rst = Nothing
140       GoTo Exit_label
150   End If


160   fIsNewRecord = (Nz(rst("D16")) = "")

      ' Fill in the Creation Timestamp (D16) field, if it does not already have a value - i.e. this is a new record
      ' During an bulk import, this proc is called for each record
      ' thus every new record gets a different Creation timestamp.

      Dim strTimestamp As String
170   strTimestamp = GetTimestamp

      ' D16 = Creation timestamp for new records
      ' D17 = Modification timestamp

180   rst.Edit
190   If fIsNewRecord Then
200       rst("D16") = strTimestamp
210   End If
220   rst("D17") = strTimestamp
230   rst.Update

      '     Log to the data entry logs

240   Call GetNewBandsRecordFromRecordset(rst, B_variant)

250   B_variant.Command = IIf(fIsNewRecord, "Add", "Update")
260   B_variant.Source = "Bands"
270   Call Log_NewBandsSheet(B_variant, strExternalLoggingError)

280   rst.Close
290   Set rst = Nothing

          'DD Error Handler Start
Exit_label:
300       Exit Sub
Err_label:
310       Select Case Err.Number
          Case Else
320           Call LogError("basSheetNewBands_v2", "Form_AfterUpdate_v2")
330       End Select
340       Resume Exit_label
          ' DD Error Handler End
End Sub



''---------------------------------------------------------------------------------------
'' Form_AfterUpdate
''
'' strTableSheet is  "tblSheetNewBandsMultiSize_v2"
''---------------------------------------------------------------------------------------
'
'Public Sub Form_AfterUpdate_v2(ByRef strTableSheet As String, ByVal lngBandID As Long) ' , ByRef lngCountRecordsExportedToUSBFlashDriveBackupFolder As Long)
'
'10    On Error GoTo Err_label
'
'      Dim strNotBypassableMsg As String
'      Dim strBypassableMsg As String
'      Dim fIsLineBlank As Boolean
'      Dim fDuplicateNewCapture As Boolean
'      Dim fIsNewRecord As Boolean
'
'20    Call AnalyseNotesNewBands(strTableSheet, lngBandID)
'
'      Dim B As SheetNewCaptureRecordType
'
'30    Call basSheetNewBands_v2.GetRecord_v2(strTableSheet, lngBandID, B)
'
'      Dim IsValid As basTypes.IsValidType
'40    Call ValidateRecord_SheetNewBand_v2(strTableSheet, B, _
'          strNotBypassableMsg, strBypassableMsg, _
'          fIsLineBlank, fDuplicateNewCapture, _
'          False, IsValid)
'
'50    If Not IsValid.IsBandValid Then GoTo Exit_label
'
'60    Call ProcessAutoHistory("Bands", B.BandPrefix, B.BandSuffix, 0)
'
'      Dim rec As SheetNewBandsType
'      Dim i As Integer
'
'      Dim rst As DAO.Recordset
'70    Set rst = CurrentDb.OpenRecordset("SELECT * FROM tblSheetNewBandsMultiSize_v2 WHERE [BandID] = " & lngBandID, dbOpenDynaset)
'
'80    If rst.EOF Then
'90        Call LogError("basSheetNewBands_v2", "Form_AfterUpdate", "ERROR - Did not get Band Sheet", True, 1)
'100       GoTo Exit_label
'110   End If
'
'
'120   fIsNewRecord = (Nz(rst("D16")) = "")
'
'      ' Fill in the Creation Timestamp (D16) field, if it does not already have a value - i.e. this is a new record
'
'
'      Dim datTimestamp As Date
'
'130   datTimestamp = Now()
'
'140   If fIsNewRecord Then
'
'          Dim lngTimestampSuffix As Long
'150       lngTimestampSuffix = GetTimestampSuffix()
'160       lngTimestampSuffix = (lngTimestampSuffix + 1) Mod 10000
'170       Call PutTimestampSuffix(lngTimestampSuffix)
'
'180       rst.Edit
'190       rst("D16") = Format(datTimestamp, "yyyy-mm-dd hh:mm:ss") & " " & Format(lngTimestampSuffix, "0000")
'200       rst.Update
'
'210   End If
'
'220   Call GetNewBandsRecordFromRecordset(rst, rec)
'230   rec.Command = IIf(fIsNewRecord, "Add", "Edit")
'240   rec.Source = "Bands sheet"
'
'250   rst.Close
'260   Set rst = Nothing
'
'270   Call Log_NewBandsSheet(rec)
'
'          'DD Error Handler Start
'Exit_label:
'280       Exit Sub
'Err_label:
'290       Select Case Err.Number
'          Case Else
'300      Call LogError("basSheetNewBands_v2", "Form_AfterUpdate_v2")
'310       End Select
'320       Resume Exit_label
'          ' DD Error Handler End
'End Sub

''----------------------------------------------------------------------------------------------
'' Bands_LiveSnapshot
''
'' If data entry is Live, export the sheet to an Excel file on the USB flash drive backup folder
'' Each Excel file contains the Band and Recap snapshots for 1 day
'' Each export goes to a separate worksheet
''
'' Returns an error message if anyting goes wrong.  Otherwise returns strErr = ""
''---------------------------------------------------------------------------------------
'
'Private Sub Bands_LiveSnapshot(ByRef strErr As String)
'
'10    On Error GoTo Err_label
'
'20    strErr = ""
'
'30    If (GetDataEntrySource() = "Live") Then
'
'40        strErr = "FAILED to export a Live snapshot of Bands"
'
'          ' Export the sheet to the USB Flash Drive
'          ' --------------------------------------
'          ' LOOP
'          '   Get the USB Flash Drive Folder
'          '   Verify the USB Flash Drive Folder exists
'          '   If the  USB Flash Drive Folder exists
'          '      Export the sheet
'          '      If the copy succeeds, EXIT LOOP
'          '      If the copy fails, say so then EXIT LOOP
'          '   If the USB Flash Drive Folder does not exist
'          '      Prompt for a path
'          '      Cancel => EXIT LOOP
'          ' END LOOP
'
'          Dim strTargetFilename              As String
'          Dim strUSBFlashDriveBackupFolder   As String
'          Dim strUSBFlashDriveBackupFilepath As String
'
'50        strTargetFilename = Format(Now(), "yyyy-mm-dd") & " Captures "
'60        strUSBFlashDriveBackupFolder = GetUSBFlashDriveBackupFolder()
'70        strUSBFlashDriveBackupFilepath = TrailingSlash(strUSBFlashDriveBackupFolder) & strTargetFilename
'
'80        Do While True
'90            If FolderExists(strUSBFlashDriveBackupFolder) Then
'100               Call PutUSBFlashDriveBackupFolder(strUSBFlashDriveBackupFolder)
'
'110               On Error Resume Next
'120               DoCmd.TransferSpreadsheet acExport, acSpreadsheetTypeExcel8, "tblSheetNewBandsMultiSize_v2", strUSBFlashDriveBackupFilepath, HasFieldNames:=True, range:=Format(Now(), " Bands hh\hnn\sss")
'130               If Err.Number <> 0 Then
'140                   Call LogError("basSheetNewBands_v2", "Bands_LiveSnapshot", "TransferSpreadsheet failed", Silent:=True, DeveloperErrNumber:=1)
'150                   Err.Clear
'160                   On Error GoTo Err_label
'170                   Exit Do
'180               Else
'190                   strErr = ""
'200               End If
'210               Exit Do
'220           Else
'230               If vbOK <> MsgBox("The Live backup folder " & strUSBFlashDriveBackupFilepath & " does not exist" & vbCrLf & "Click OK if you would like to choose a USB flash drive backup folder" & vbCrLf & "Click Cancel if you do not want to copy the backup to a USB flash drive backup folder", vbOKCancel, "Backup") Then
'240                   Exit Do
'250               End If
'260               strUSBFlashDriveBackupFolder = GetFolder("C:")
'270               If strUSBFlashDriveBackupFolder = "" Then
'280                   Exit Do
'290               Else
'300                   strUSBFlashDriveBackupFilepath = TrailingSlash(strUSBFlashDriveBackupFolder) & strTargetFilename
'310               End If
'320           End If
'330       Loop
'
'340   End If
'
'          'DD Error Handler Start
'Exit_label:
'350       Exit Sub
'Err_label:
'360       Select Case Err.Number
'          Case Else
'370            Call LogError("basSheetNewBands_v2", "Bands_LiveSnapshot")
'380       End Select
'390       Resume Exit_label
'          ' DD Error Handler End
'End Sub
'



'---------------------------------------------------------------------------------------
' cmdVolunteers_Click
'---------------------------------------------------------------------------------------
 
Public Sub cmdVolunteers_Click_v2(ByVal strScribe As String)
10    On Error GoTo Err_label

20    DoCmd.Restore
30    DoCmd.OpenForm "frmVolunteers", OpenArgs:=strScribe

      'DD Error Handler Start
Exit_label:
40         Exit Sub
Err_label:
50         Select Case Err.Number
           Case Else
60        Call LogError("basSheetNewBands_v2", "cmdVolunteers_Click")
70         End Select
80         Resume Exit_label
      'DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' DuplicateBand
'---------------------------------------------------------------------------------------
 
Public Function IsBandDuplicate_v2(ByVal BandPrefix As String, ByVal BandSuffix As String) As Boolean
      Dim strCriterion As String


10    On Error GoTo Err_label

20    strCriterion = "BandPrefix = '" & BandPrefix & "' AND " & _
                     "BandSuffix = '" & BandSuffix & "' AND " & _
                     "not (Disposition = 'R' OR Disposition = 'F')  "

30    IsBandDuplicate_v2 = (DCount("*", "tblCaptures", strCriterion) <> 0)

      'DD Error Handler Start
Exit_label:
40         Exit Function
Err_label:
50         Select Case Err.Number
           Case Else
60        Call LogError("basSheetNewBands_v2", "IsBandDuplicate")
70         End Select
80         Resume Exit_label
      'DD Error Handler End

End Function

' ---------------------------------------------------------------------------
' IsLineBlank
' ---------------------------------------------------------------------------

Public Function IsLineBlank_v2(B As SheetNewBandRecordType) As Boolean

10    On Error GoTo Err_label

Dim IsLineBlank As Boolean

20    IsLineBlank = _
          (Trim(B.Species) = "") And (Trim(B.WingChord) = "") And _
          (Trim(B.Age) = "") And (Trim(B.HowAged) = "") And _
          (Trim(B.Sex) = "") And (Trim(B.HowSexed) = "") And _
          (Trim(B.Fat) = "") And (Trim(B.Weight) = "") And _
          (Trim(B.CaptureDate) = "") And (Trim(B.WeightTime) = "") And _
          (Trim(B.Bander) = "") And (Trim(B.Scribe) = "") And _
          (Trim(B.Net) = "") And (Trim(B.NotesForMBO) = "") And _
          (Trim(B.ProbableAge) = "") And (Trim(B.ProbableSex) = "") And _
          (Trim(B.CaptureYear) = "") And (Trim(B.Disposition) = "") And _
          (Trim(B.Location) = "") And (Trim(B.BirdStatus) = "") And _
          (Trim(B.Program) = "") And Not (B.AutoHistory)
          
30        IsLineBlank_v2 = IsLineBlank And Trim(B.NotesForMBO) = ""
          
40        If IsLineBlank_v2 Then
              Dim uf As Integer
50            For uf = 1 To conMaxUserField
60              If Trim(B.F(uf)) <> "" Then
70                  IsLineBlank_v2 = False
80                  Exit For
90              End If
100           Next uf
110       End If
          
120       If IsLineBlank_v2 Then
              Dim df As Integer
130           For df = 1 To conMaxDataField
140             If Trim(B.D(df)) <> "" Then
150                 IsLineBlank_v2 = False
160                 Exit For
170             End If
180           Next df
190       End If

200   IsLineBlank_v2 = IsLineBlank

      'DD Error Handler Start
Exit_label:
210        Exit Function
Err_label:
220        Select Case Err.Number
           Case Else
230       Call LogError("basSheetNewBands_v2", "IsLineBlank_v2")
240        End Select
250        Resume Exit_label
      'DD Error Handler End

End Function

'---------------------------------------------------------------------------------------
' GetNewBandsRecordFromBandID
'
' PRE: the record for lngBandID exists
'---------------------------------------------------------------------------------------

Public Sub GetNewBandsRecordFromBandID(ByVal lngBandID As Long, ByRef rec As SheetNewBandsType)

      Dim rst As DAO.Recordset
      Dim strSQL As String

10    On Error GoTo Err_label

20    strSQL = _
          " SELECT * " & _
          " FROM tblSheetNewBandsMultiSize_v2 " & _
          " WHERE BandID = " & lngBandID
30    Set rst = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)

40    If rst.EOF Then Exit Sub

50    Call GetNewBandsRecordFromRecordset(rst, rec)

60    rst.Close
70    Set rst = Nothing

          'DD Error Handler Start
Exit_label:
80        Exit Sub
Err_label:
90        Select Case Err.Number
          Case Else
100            Call LogError("basSheetNewBands_v2", "GetNewBandsRecordFromBandID")
110       End Select
120       Resume Exit_label
          ' DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' GetNewBandsRecordFromRecordset
'
' PRE: the record exists
'---------------------------------------------------------------------------------------

Public Sub GetNewBandsRecordFromRecordset(ByRef rst As DAO.Recordset, ByRef rec As SheetNewBandsType)
         
10    On Error GoTo Err_label

20    If rst.EOF Then Exit Sub

30    rec.BandID = rst("BandID")
40    rec.BandSizeID = rst("BandSizeID")
50    rec.BandPrefix = rst("BandPrefix")
60    rec.BandSuffix = rst("BandSuffix")
70    rec.Species = rst("Species")
80    rec.Age = rst("Age")
90    rec.HowAged = rst("HowAged")
100   rec.Sex = rst("Sex")
110   rec.HowSexed = rst("HowSexed")
120   rec.WingChord = rst("WingChord")
130   rec.Fat = rst("Fat")
140   rec.Weight = rst("Weight")
150   rec.CaptureDate = rst("CaptureDate")
160   rec.WeightTime = rst("WeightTime")
170   rec.Bander = rst("Bander")
180   rec.Net = rst("Net")
190   rec.ProbableAge = rst("ProbableAge")
200   rec.ProbableSex = rst("ProbableSex")
210   rec.Scribe = rst("Scribe")
220   rec.NotesForMBO = rst("NotesForMBO")
230   rec.Valid = rst("Valid")
240   rec.Invalid = rst("Invalid")
250   rec.Duplicate = rst("Duplicate")
260   rec.BypassErrors = rst("BypassErrors")
270   rec.CaptureYear = rst("CaptureYear")
280   rec.Disposition = rst("Disposition")
290   rec.Location = rst("Location")
300   rec.BirdStatus = rst("BirdStatus")
310   rec.Program = rst("Program")
320   rec.AutoHistory = rst("AutoHistory")
330   rec.FCombined = rst("F")

      Dim uf As Integer
340   For uf = 1 To conMaxUserField
350       rec.F(uf) = rst("F" & uf)
360   Next uf

370   rec.Flags = rst("Flags")

      Dim df As Integer
380   For df = 1 To conMaxDataField
390       rec.D(df) = rst("D" & df)
400   Next df

          'DD Error Handler Start
Exit_label:
410       Exit Sub
Err_label:
420       Select Case Err.Number
          Case Else
430      Call LogError("basSheetNewBands_v2", "GetNewBandsRecordFromRecordset")
440       End Select
450       Resume Exit_label
          ' DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' GetRecord_v2
'---------------------------------------------------------------------------------------
' Same as GetNewBandsRecordFromBandID, except returns SheetNewBandRecordType
' Easier to keep this sub than to rewrite the procedures that call it
 
Public Sub GetRecord_v2( _
    ByVal strTableSheet As String, _
    ByVal lngBandID As Long, _
    ByRef B As SheetNewBandRecordType)
    
      '  Open a recordset for the record

      Dim rst As DAO.Recordset
      Dim strSQL As String

10    On Error GoTo Err_label

20    strSQL = _
          "SELECT * " & _
          "FROM " & strTableSheet & " " & _
          "WHERE BandID = " & lngBandID
30    Set rst = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)
40    If rst.EOF Then Exit Sub

50    Call GetNewBandsRecordFromRecordset_Typed(rst, B)

      'DD Error Handler Start
Exit_label:
60         Exit Sub
Err_label:
70         Select Case Err.Number
           Case Else
80        Call LogError("basSheetNewBands_v2", "GetRecord_v2")
90         End Select
100        Resume Exit_label
      'DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' GetRecordFromSheetNewBandRecordset
'
' Fill in B from a NewBand record
'---------------------------------------------------------------------------------------
' Same as GetNewBandsRecordfromRecordset, except returns SheetNewBandRecordType (typed elements) instead of SheetNewBandType (variant elements)
' Easier to keep this sub than to rewrite the procedures that call it

'Public Type SheetNewBandRecordType
'    BandID         As Long
'    LineNumber     As String          No corresponding field in the Bands table
'    BandSizeID     As Long
'    BandPrefix     As String
'    BandSuffix     As String
'    Species        As String
'    WingChord      As String
'    Age            As String
'    HowAged        As String
'    Sex            As String
'    HowSexed       As String
'    Fat            As String
'    Weight         As String
'    CaptureDate    As String
'    WeightTime     As String
'    Bander         As String
'    Scribe         As String
'    Net            As String
'    NotesForMBO    As String
'    Valid          As String
'    Invalid        As String
'    Duplicate      As String
'    BypassErrors   As Boolean
'    ProbableAge    As String
'    ProbableSex    As String
'    CaptureYear    As String
'    Disposition    As String
'    Location       As String
'    BirdStatus     As String
'    Program        As String
'    AutoHistory        As Boolean
'    F(conMaxUserField) As String
'    D(conMaxDataField) As String
'    FCombined          As String
'    Flags              As String
'End Type

Public Sub GetNewBandsRecordFromRecordset_Typed( _
    ByRef rst As DAO.Recordset, _
    ByRef B As SheetNewBandRecordType)

10    On Error GoTo Err_label

20    If rst.EOF Then Exit Sub

      Dim rec As SheetNewBandsType
30    Call GetNewBandsRecordFromRecordset(rst, rec)

40    B.BandID = Nz(rec.BandID)
50    B.BandSizeID = Nz(rec.BandSizeID)
60    B.BandPrefix = Nz(rec.BandPrefix)
70    B.BandSuffix = Nz(rec.BandSuffix)
80    B.Species = Trim(Nz(rec.Species))
90    B.WingChord = Trim(Nz(rec.WingChord))
100   B.Age = Trim(Nz(rec.Age))
110   B.HowAged = Trim(Nz(rec.HowAged))
120   B.Sex = Trim(Nz(rec.Sex))
130   B.HowSexed = Trim(Nz(rec.HowSexed))
140   B.Fat = Trim(Nz(rec.Fat))
150   B.Weight = Trim(Nz(rec.Weight))
160   B.CaptureDate = Trim(Nz(rec.CaptureDate))
170   B.WeightTime = Trim(Nz(rec.WeightTime))
180   B.Bander = Trim(Nz(rec.Bander))
190   B.Scribe = Trim(Nz(rec.Scribe))
200   B.Net = Trim(Nz(rec.Net))
210   B.NotesForMBO = Trim(Nz(rec.NotesForMBO))
220   B.Valid = Trim(Nz(rec.Valid))
230   B.Invalid = Trim(Nz(rec.Invalid))
240   B.Duplicate = Trim(Nz(rec.Duplicate))
250   B.BypassErrors = Trim(Nz(rec.BypassErrors))
260   B.ProbableAge = Trim(Nz(rec.ProbableAge))
270   B.ProbableSex = Trim(Nz(rec.ProbableSex))
280   B.CaptureYear = Trim(Nz(rec.CaptureYear))
290   B.Disposition = Trim(Nz(rec.Disposition))
300   B.Location = Trim(Nz(rec.Location))
310   B.BirdStatus = Trim(Nz(rec.BirdStatus))
320   B.Program = Trim(Nz(rec.Program))
330   B.AutoHistory = Nz(rec.AutoHistory)

      Dim uf As Integer
340   For uf = 1 To conMaxUserField
350       B.F(uf) = Trim(Nz(rec.F(uf)))
360   Next uf

      Dim df As Integer
370   For df = 1 To conMaxDataField
380       B.D(df) = Trim(Nz(rec.D(df)))
390   Next df

400   B.FCombined = Trim(Nz(rec.FCombined))
410   B.Flags = Nz(rec.Flags)

          'DD Error Handler Start
Exit_label:
420       Exit Sub
Err_label:
430       Select Case Err.Number
          Case Else
440      Call LogError("basSheetNewBands_v2", "GetRecordFromSheetNewBandRecordset")
450       End Select
460       Resume Exit_label
          ' DD Error Handler End

End Sub

''---------------------------------------------------------------------------------------
'' GetRecord_v2
''---------------------------------------------------------------------------------------
'' Same as GetNewBandsRecordFromBandID, except returns SheetNewCaptureRecordType
'' Easier to keep this sub than to rewrite the procedures that call it
'
'Public Sub GetRecord_v2( _
'    ByVal strTableSheet As String, _
'    ByVal lngBandID As Long, _
'    ByRef B As SheetNewCaptureRecordType)
'
'      '  Open a recordset for the record
'
'      Dim rst As DAO.Recordset
'      Dim strSQL As String
'
'10    On Error GoTo Err_label
'
'20    strSQL = _
'          "SELECT * " & _
'          "FROM " & strTableSheet & " " & _
'          "WHERE BandID = " & lngBandID
'30    Set rst = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)
'40    If rst.EOF Then Exit Sub
'
'50    Call GetRecordFromSheetNewBandRecordset(rst, B)
'
''      ' Get the record
''
''      Dim rec As SheetNewBandsType
''      Call GetNewBandRecordFromRecordset(rst, rec)
''
''50    B.BandID = lngBandID
''60    B.BandSizeID = Nz(rec.BandSizeID)
''70    B.BandPrefix = Nz(rec.BandPrefix)
''80    B.BandSuffix = Nz(rec.BandSuffix)
''90    B.Species = Trim(Nz(rec.Species))
''100   B.WingChord = Trim(Nz(rec.WingChord))
''110   B.Age = Trim(Nz(rec.Age))
''120   B.HowAged = Trim(Nz(rec.HowAged))
''130   B.Sex = Trim(Nz(rec.Sex))
''140   B.HowSexed = Trim(Nz(rec.HowSexed))
''150   B.Fat = Trim(Nz(rec.Fat))
''160   B.Weight = Trim(Nz(rec.Weight))
''170   B.CaptureDate = Trim(Nz(rec.CaptureDate))
''180   B.WeightTime = Trim(Nz(rec.WeightTime))
''190   B.Bander = Trim(Nz(rec.Bander))
''200   B.Scribe = Trim(Nz(rec.Scribe))
''210   B.Net = Trim(Nz(rec.Net))
''220   B.NotesForMBO = Trim(Nz(rec.NotesForMBO))
''230   B.ProbableAge = Trim(Nz(rec.ProbableAge))
''240   B.ProbableSex = Trim(Nz(rec.ProbableSex))
''250   B.CaptureYear = Trim(Nz(rec.CaptureYear))
''260   B.Disposition = Trim(Nz(rec.Disposition))
''270   B.Location = Trim(Nz(rec.Location))
''280   B.Program = Trim(Nz(rec.Program))
''290   B.BirdStatus = Trim(Nz(rec.BirdStatus))
''
''300   B.AutoHistory = Nz(rec.AutoHistory)
''
''      Dim uf As Integer
''310   For uf = 1 To conMaxUserField
''320       B.F(uf) = Trim(Nz(rec.F(uf)))
''330   Next uf
''
''      Dim df As Integer
''340   For df = 1 To conMaxDataField
''350       B.D(df) = Trim(Nz(rec.D(df)))
''360   Next df
''
''370   B.FCombined = Trim(Nz(rst("FCombined")))
''380   B.Flags = Nz(rst("Flags"))
''390   rst.Close
'
'      'DD Error Handler Start
'Exit_label:
'60         Exit Sub
'Err_label:
'70         Select Case Err.Number
'           Case Else
'80        Call LogError("basSheetNewBands_v2", "GetRecord_v2")
'90         End Select
'100        Resume Exit_label
'      'DD Error Handler End
'
'End Sub


'---------------------------------------------------------------------------------------
' GetRecordFromSheetNewBandRecordset
'
' Fill in B from a NewBand record
'---------------------------------------------------------------------------------------
' Same as GetRecordFromSheetNewBandRecordset, except returns SheetNewCaptureRecordType
' Easier to keep this sub than to rewrite the procedures that call it

Public Sub GetRecordFromSheetNewBandRecordset( _
    ByRef rst As DAO.Recordset, _
    ByRef B As SheetNewBandRecordType)

10       On Error GoTo Err_label

20    If rst.EOF Then Exit Sub

      Dim rec As SheetNewBandsType
30    Call GetNewBandsRecordFromRecordset(rst, rec)

40    B.BandID = Nz(rec.BandID)
50    B.BandSizeID = Nz(rec.BandSizeID)
60    B.BandPrefix = Nz(rec.BandPrefix)
70    B.BandSuffix = Nz(rec.BandSuffix)
80    B.Species = Trim(Nz(rec.Species))
90    B.WingChord = Trim(Nz(rec.WingChord))
100   B.Age = Trim(Nz(rec.Age))
110   B.HowAged = Trim(Nz(rec.HowAged))
120   B.Sex = Trim(Nz(rec.Sex))
130   B.HowSexed = Trim(Nz(rec.HowSexed))
140   B.Fat = Trim(Nz(rec.Fat))
150   B.Weight = Trim(Nz(rec.Weight))
160   B.CaptureDate = Trim(Nz(rec.CaptureDate))
170   B.WeightTime = Trim(Nz(rec.WeightTime))
180   B.Bander = Trim(Nz(rec.Bander))
190   B.Scribe = Trim(Nz(rec.Scribe))
200   B.Net = Trim(Nz(rec.Net))
210   B.NotesForMBO = Trim(Nz(rec.NotesForMBO))
220   B.ProbableAge = Trim(Nz(rec.ProbableAge))
230   B.ProbableSex = Trim(Nz(rec.ProbableSex))
240   B.CaptureYear = Trim(Nz(rec.CaptureYear))
250   B.Disposition = Trim(Nz(rec.Disposition))
260   B.Location = Trim(Nz(rec.Location))
270   B.Program = Trim(Nz(rec.Program))
280   B.BirdStatus = Trim(Nz(rec.BirdStatus))

290   B.AutoHistory = Nz(rec.AutoHistory)

      Dim uf As Integer
300   For uf = 1 To conMaxUserField
310       B.F(uf) = Trim(Nz(rec.F(uf)))
320   Next uf

      Dim df As Integer
330   For df = 1 To conMaxDataField
340       B.D(df) = Trim(Nz(rec.D(df)))
350   Next df

360   B.FCombined = Trim(Nz(rec.FCombined))
370   B.Flags = Nz(rec.Flags)

      '' Get the record
      '
      'B.BandID = Nz(rst("BandID"))
      'B.BandSizeID = Nz(rst("BandSizeID"))
      'B.BandPrefix = Nz(rst("BandPrefix"))
      'B.BandSuffix = Nz(rst("BandSuffix"))
      'B.Species = Trim(Nz(rst("Species")))
      'B.WingChord = Trim(Nz(rst("WingChord")))
      'B.Age = Trim(Nz(rst("Age")))
      'B.HowAged = Trim(Nz(rst("HowAged")))
      'B.Sex = Trim(Nz(rst("Sex")))
      'B.HowSexed = Trim(Nz(rst("HowSexed")))
      'B.Fat = Trim(Nz(rst("Fat")))
      'B.Weight = Trim(Nz(rst("Weight")))
      'B.CaptureDate = Trim(Nz(rst("CaptureDate")))
      'B.WeightTime = Trim(Nz(rst("WeightTime")))
      'B.Bander = Trim(Nz(rst("Bander")))
      'B.Scribe = Trim(Nz(rst("Scribe")))
      'B.Net = Trim(Nz(rst("Net")))
      'B.NotesForMBO = Trim(Nz(rst("NotesForMBO")))
      'B.ProbableAge = Trim(Nz(rst("ProbableAge")))
      'B.ProbableSex = Trim(Nz(rst("ProbableSex")))
      'B.CaptureYear = Trim(Nz(rst("CaptureYear")))
      'B.Disposition = Trim(Nz(rst("Disposition")))
      'B.Location = Trim(Nz(rst("Location")))
      'B.Program = Trim(Nz(rst("Program")))
      'B.BirdStatus = Trim(Nz(rst("BirdStatus")))
      ''300   B.AuxMarkerType = Trim(Nz(rst("AuxMarkerType")))
      ''310   B.AuxMarkerCode = Trim(Nz(rst("AuxMarkerCode")))
      ''320   B.AuxMarkerBandColor = Trim(Nz(rst("AuxMarkerBandColor")))
      ''330   B.AuxMarkerCodeColor = Trim(Nz(rst("AuxMarkerCodeColor")))
      'B.AutoHistory = Nz(rst("AutoHistory"))
      '
      'Dim uf As Integer
      'For uf = 1 To conMaxUserField
      '    B.F(uf) = Trim(Nz(rst("F" & uf)))
      'Next uf
      '
      'Dim df As Integer
      'For df = 1 To conMaxDataField
      '    B.D(df) = Trim(Nz(rst("D" & df)))
      'Next df
      '
      'B.FCombined = Trim(Nz(rst("F")))
      'B.Flags = Nz(rst("Flags"))

          'DD Error Handler Start
Exit_label:
380       Exit Sub
Err_label:
390       Select Case Err.Number
          Case Else
400      Call LogError("basSheetNewBands_v2", "GetRecordFromSheetNewBandRecordset")
410       End Select
420       Resume Exit_label
          ' DD Error Handler End

End Sub



'---------------------------------------------------------------------------------------
' GetRecapturesRecordFromBandID
'
' PRE: the record for lngBandID exists
'---------------------------------------------------------------------------------------

Public Sub GetRecapturesRecordFromBandID(ByVal lngBandID As Long, ByRef rec As SheetRecapturesType)

      Dim rst As DAO.Recordset
      Dim strSQL As String

10    On Error GoTo Err_label

20    strSQL = _
          " SELECT * " & _
          " FROM tblSheetRecaps_v2 " & _
          " WHERE BandID = " & lngBandID
30    Set rst = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)

40    If rst.EOF Then Exit Sub

50    Call GetRecapturesRecordFromRecordset(rst, rec)

60    rst.Close
70    Set rst = Nothing

          'DD Error Handler Start
Exit_label:
80        Exit Sub
Err_label:
90        Select Case Err.Number
          Case Else
100            Call LogError("basSheetNewBands_v2", "GetRecapturesRecordFromBandID")
110       End Select
120       Resume Exit_label
          ' DD Error Handler End

End Sub


'---------------------------------------------------------------------------------------
' GetRecapturesRecordFromRecordset
'
' PRE: the record exists
'---------------------------------------------------------------------------------------

Public Sub GetRecapturesRecordFromRecordset(ByRef rst As DAO.Recordset, ByRef rec As SheetRecapturesType)
         
10    On Error GoTo Err_label

20    If rst.EOF Then Exit Sub

30    rec.BandID = rst("BandID")
40    rec.BandPrefix = rst("BandPrefix")
50    rec.BandSuffix = rst("BandSuffix")
60    rec.Species = rst("Species")
70    rec.WingChord = rst("WingChord")
80    rec.Age = rst("Age")
90    rec.HowAged = rst("HowAged")
100   rec.Sex = rst("Sex")
110   rec.HowSexed = rst("HowSexed")
120   rec.Fat = rst("Fat")
130   rec.Weight = rst("Weight")
140   rec.CaptureDate = rst("CaptureDate")
150   rec.WeightTime = rst("WeightTime")
160   rec.Bander = rst("Bander")
170   rec.Scribe = rst("Scribe")
180   rec.Net = rst("Net")
190   rec.NotesForMBO = rst("NotesForMBO")
200   rec.Valid = rst("Valid")
210   rec.Invalid = rst("Invalid")
220   rec.Duplicate = rst("Duplicate")
230   rec.BypassErrors = rst("BypassErrors")
240   rec.ProbableAge = rst("ProbableAge")
250   rec.ProbableSex = rst("ProbableSex")
260   rec.CaptureYear = rst("CaptureYear")
270   rec.Disposition = rst("Disposition")
280   rec.Location = rst("Location")
290   rec.BirdStatus = rst("BirdStatus")
300   rec.HowObtainedCode = rst("HowObtainedCode")
310   rec.PresentCondition = rst("PresentCondition")
320   rec.Program = rst("Program")
330   rec.AutoHistory = rst("AutoHistory")
340   rec.FCombined = rst("F")
      
      Dim uf As Integer
350   For uf = 1 To conMaxUserField
360       rec.F(uf) = rst("F" & uf)
370   Next uf

380   rec.Flags = rst("Flags")

      Dim df As Integer
390   For df = 1 To conMaxDataField
400       rec.D(df) = rst("D" & df)
410   Next df

          'DD Error Handler Start
Exit_label:
420       Exit Sub
Err_label:
430       Select Case Err.Number
          Case Else
440      Call LogError("basSheetNewBands_v2", "GetRecapturesRecordFromRecordset")
450       End Select
460       Resume Exit_label
          ' DD Error Handler End
End Sub

' ---------------------------------------------------------------------------
' ValidateRecord
'
' Validate a single record
'
' strTableSheet = "tblSheetNewBandsMultiSize_v2"
' ---------------------------------------------------------------------------
' Called from frmSheetNewBandsMultiSize_v2.cmdRevalidate_Click
'             frmSheetNewBandsMultiSize_v2.NewBands_Store_v2
'             basSheetNewBnds_v2.Form_AfterUpdate

Public Sub ValidateRecord_SheetNewBand_v2( _
    ByVal strTableSheet As String, _
    ByRef B As SheetNewBandRecordType, _
    ByRef strNotBypassableMsg As String, _
    ByRef strBypassableMsg As String, _
    ByRef fDuplicateNewCapture As Boolean, _
    ByVal fDisplayErrors As Boolean, _
    ByRef IsValid As basTypes.IsValidType)
          
10    On Error GoTo Err_label

      ' Validate the record

20    IsValid.IsBandValid = True

30    Call Validate_SheetNewBandRecord(B, strNotBypassableMsg, strBypassableMsg, fDuplicateNewCapture, IsValid)

Dim fIsLineBlank As Boolean
fIsLineBlank = False   '   Could it be blank ?
          
40    Call UpdateStatusFlags_InNewBandsTableRecord(strTableSheet, B.BandID, fIsLineBlank, fDuplicateNewCapture, strBypassableMsg, strNotBypassableMsg)

50    If fDisplayErrors Then
60        Call DisplayValidationErrors(strNotBypassableMsg, strBypassableMsg)
70    End If

      'DD Error Handler Start
Exit_label:
80         Exit Sub
Err_label:
90         Select Case Err.Number
           Case Else
100       Call LogError("basSheetNewBands_v2", "ValidateRecord")
110        End Select
120        Resume Exit_label
      'DD Error Handler End

End Sub

'------------------------------------------------------------
' UpdateStatusFlagsInNewBandsVariantRecord

' Priority 1 - Duplicate New Captures
'          3 - Not bypassable errors
'          4 - Bypassable errors
'          5 - Valid records
'------------------------------------------------------------
'
' Called from frmRestore.ActionAddBand

Public Sub UpdateStatusFlags_InNewBandsVariantRecord( _
    ByRef B As SheetNewBandsType, _
    ByVal fDuplicateNewCapture As Boolean, _
    ByVal strBypassableMsg As String, _
    ByVal strNotBypassableMsg As String)

10    On Error GoTo Err_label

20    If fDuplicateNewCapture Then
30        B.Valid = Null
40        B.Invalid = Null
50        B.Duplicate = "D"

60    ElseIf strNotBypassableMsg <> "" Then
70        B.Valid = Null
80        B.Invalid = "E"
90        B.Duplicate = Null
100   ElseIf strBypassableMsg <> "" Then
110       B.Valid = Null
120       B.Invalid = "x"
130       B.Duplicate = Null
140   Else
150       B.Valid = "v"
160       B.Invalid = Null
170       B.Duplicate = Null
180   End If

          'DD Error Handler Start
Exit_label:
190       Exit Sub
Err_label:
200       Select Case Err.Number
          Case Else
210            Call LogError("basSheetNewBands_v2", "UpdateStatusFlagsInNewBandsVariantRecord")
220       End Select
230       Resume Exit_label
          ' DD Error Handler End

End Sub

Private Sub UpdateStatusFlags_InNewBandsTableRecord( _
    ByVal strTableSheet As String, _
    ByVal lngBandID As Long, _
    ByVal fIsLineBlank As Boolean, _
    ByVal fDuplicateNewCapture As Boolean, _
    ByVal strBypassableMsg As String, _
    ByVal strNotBypassableMsg As String)
          
10    On Error GoTo Err_label

      '  Open a recordset for the record

      Dim rst As DAO.Recordset
      Dim strSQL As String
20    On Error GoTo Err_label

30    strSQL = _
          " SELECT * " & _
          " FROM " & strTableSheet & _
          " WHERE BandID = " & lngBandID
40    Set rst = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)
50    If rst.EOF Then Exit Sub

60    rst.Edit

      If fDuplicateNewCapture Then
        rst("Duplicate") = "D"
      End If

70    If fIsLineBlank Then
80        rst("Valid") = Null
90        rst("Invalid") = Null
100       rst("BypassErrors") = False
110   ElseIf strNotBypassableMsg <> "" Then
120       rst("Valid") = Null
130       rst("Invalid") = "E"
' 140       rst("Disposition") = Null
150   ElseIf strBypassableMsg <> "" Then
160       rst("Valid") = Null
170       rst("Invalid") = "x"
180   Else
190       rst("Valid") = "v"
200       rst("Invalid") = Null
210   End If

220   rst.Update
230   rst.Close

      'DD Error Handler Start
Exit_label:
240        Exit Sub
Err_label:
250        Select Case Err.Number
           Case Else
260       Call LogError("basSheetRecaps_v2", "UpdateStatusFlags")
270        End Select
280        Resume Exit_label
      'DD Error Handler End
End Sub


'---------------------------------------------------------------------------------------
' DisplayValidationErrors
'---------------------------------------------------------------------------------------
' Called from basSheetNewBands_v2.ValidateRecord_SheetNewBand_v2
' Called from basSheetRecaps_v2.ValidateRecord_SheetRecaps_v2

Public Sub DisplayValidationErrors(ByVal strNotBypassableMsg As String, ByVal strBypassableMsg As String)
                                    
      Dim strErr As String

10    On Error GoTo Err_label

20    If strNotBypassableMsg <> "" Then
30        strErr = strErr & _
              "Non-bypassable errors" & vbCrLf & _
              "---------------------" & vbCrLf & _
              strNotBypassableMsg & vbCrLf & vbCrLf
40    End If

50    If strBypassableMsg <> "" Then
60        strErr = strErr & _
              "Bypassable errors" & vbCrLf & _
              "-----------------" & vbCrLf & _
              strBypassableMsg
70    End If

80    If strErr <> "" Then
90        DoCmd.OpenForm "frmValidationErrors", OpenArgs:=strErr
100   Else
110       On Error Resume Next
120       DoCmd.Close acForm, "frmValidationErrors"
130       On Error GoTo Err_label
140   End If


          'DD Error Handler Start
Exit_label:
150       Exit Sub
Err_label:
160       Select Case Err.Number
          Case Else
170            Call LogError("basSheetNewBands_v2", "DisplayValidationErrors")
180       End Select
190       Resume Exit_label
          ' DD Error Handler End
          
End Sub

'---------------------------------------------------------------------------------------
' Validate_SheetNewBandRecord
'
' strTableSheet = "tblSheetNewBandsMultiSize_v2"
'
'---------------------------------------------------------------------------------------
' Called from frmRestore.ActionAddNewBand
'             basSheetNewBands_v2.Validate_SheetNewBandRecord
 
Public Sub Validate_SheetNewBandRecord( _
    ByRef B_typed As SheetNewBandRecordType, _
    ByRef strNotBypassableMsg As String, _
    ByRef strBypassableMsg As String, _
    ByRef fDuplicateNewCapture As Boolean, _
    ByRef IsValid As basTypes.IsValidType)
          
      ' IN:  B_typed
      ' OUT: strNotBypassableMsg
      ' OUT: strBypassableMsg
      ' OUT: fDuplicateNewCapture
      ' OUT: IsValid                                      (IsValidType)
      '           IsBandValid         is filled in
      '           IsDateValid         is filled in
      '           IsSpeciesValid      is filled in
      '           IsSexValid          is filled in
      '           IsDispositionValid  is filled in
      '           varValid A          is NOT filled in
      '           varInvalid          is NOT filled in
      '           IsMultiRecordError  is filled in
          

10    On Error GoTo Err_label

20    strNotBypassableMsg = ""
30    strBypassableMsg = ""
40    fDuplicateNewCapture = False
50    IsValid.IsBandValid = True

      Dim strNotBypassableErr As String
      Dim strBypassableErr    As String

      ' Validate the Prefix

60    If Not IsBandPrefixValid(B_typed.BandPrefix, strNotBypassableErr) Then
70        IsValid.IsBandValid = False
80        strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
90    End If

      ' Validate the Suffix

100   If Not IsBandSuffixValid(B_typed.BandSuffix, strNotBypassableErr) Then
110       IsValid.IsBandValid = False
120       strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
130   End If

      ' Validate the Disposition

140   IsValid.IsDispositionValid = True
150   If Not IsDispositionValid(B_typed.Disposition, strNotBypassableErr, strBypassableErr, "New Captures") Then
160       strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
170       strBypassableMsg = strBypassableMsg & strBypassableErr
180       IsValid.IsDispositionValid = False
190   End If

200   If Not (IsValid.IsDispositionValid And IsValid.IsBandValid) Then
210       Exit Sub
220   End If

      ' ====== From this point on, the Disposition and Band number are valid ====================

      ' Validate Disposition 4 and 8 recordings

230   If B_typed.Disposition = "4" Or B_typed.Disposition = "8" Then
          
240       Call Validate_SheetNewBandRecord_Disposition4or8(B_typed, strNotBypassableMsg, strBypassableMsg)
250       IsValid.IsSpeciesValid = True
260       IsValid.IsSexValid = True
270       IsValid.IsMultiRecordError = True
280       fDuplicateNewCapture = False
290       GoTo Exit_label
300   End If

      ' ======== From this point on, the Disposition is 1 or 5.  It might also be 6 9 D S   ===========

      ' Duplicate band number ?

310   fDuplicateNewCapture = IsBandDuplicate(B_typed.BandPrefix, B_typed.BandSuffix)
320   If fDuplicateNewCapture Then
330       strNotBypassableMsg = strNotBypassableMsg & "Duplicate Band Number" & vbCrLf
340       Exit Sub
350   End If

      ' Update the array of bypassable error messages

360   Call IsProgramValid(B_typed.Program, strNotBypassableErr, strBypassableErr)
370   strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
380   strBypassableMsg = strBypassableMsg & strBypassableErr

390   If strBypassableErr = "" And strNotBypassableErr = "" Then
400       Call SetBypassableErrorMessageCurrentProgram(B_typed.Program)
410   Else
420       Call SetBypassableErrorMessageCurrentProgram("")
430   End If

      ' Validate Capture Date

440   IsValid.IsDateValid = IsDateValid(B_typed.CaptureDate, B_typed.CaptureYear, B_typed.Program, strNotBypassableErr, strBypassableErr)
450   strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
460   strBypassableMsg = strBypassableMsg & strBypassableErr

470   If strNotBypassableErr = "" Then
          Dim strErr As String
          Dim datCaptureDate As Date
480       datCaptureDate = Nz(ConvertCaptureDateAndCaptureYearToVBADate(B_typed.CaptureDate, B_typed.CaptureYear))
          Dim varWeightTime As Variant
490       varWeightTime = ConvertWeightTimeToVBADate(B_typed.WeightTime)
          Dim fDuplicateRecapture As Boolean
500       Call DateAndTimeAnalysis(B_typed.Disposition, B_typed.BandPrefix, B_typed.BandSuffix, _
              datCaptureDate, varWeightTime, B_typed.Program, 0, strErr, fDuplicateRecapture)
510       strNotBypassableMsg = strErr
520   End If

      ' Validate Species

530   If IsValid.IsBandValid Then
540       IsValid.IsSpeciesValid = IsSpeciesValid(B_typed.Species, strNotBypassableErr, strBypassableErr, "", _
              B_typed.BandPrefix, B_typed.BandSuffix)
550   Else
560       IsValid.IsSpeciesValid = IsSpeciesValid(B_typed.Species, strNotBypassableErr, strBypassableErr, "")
570   End If
580   strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
590   strBypassableMsg = strBypassableMsg & strBypassableErr

600   IsValid.IsMultiRecordError = False

610   If IsValid.IsBandValid And IsValid.IsDateValid Then
620       Call IsAgeValid(B_typed.Age, B_typed.BandPrefix, B_typed.BandSuffix, B_typed.CaptureYear, _
              strNotBypassableErr, strBypassableErr, IsValid.IsMultiRecordError)
630       strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
640       strBypassableMsg = strBypassableMsg & strBypassableErr
650   End If

660   Call IsHowAgedValid(B_typed.HowAged, strBypassableErr)
670   strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
680   strBypassableMsg = strBypassableMsg & strBypassableErr

690   If IsValid.IsBandValid And IsValid.IsDispositionValid Then
700       IsValid.IsSexValid = IsSexValid(B_typed.Sex, strNotBypassableErr, strBypassableErr, _
              IsValid.IsMultiRecordError, _
              B_typed.BandPrefix, B_typed.BandSuffix, B_typed.Disposition)
710   Else
720       IsValid.IsSexValid = IsSexValid(B_typed.Sex, strNotBypassableErr, strBypassableErr, _
              IsValid.IsMultiRecordError)
730   End If
740   strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
750   strBypassableMsg = strBypassableMsg & strBypassableErr

      Dim argSpecies As String
      Dim argSex As String

760   argSpecies = IIf(IsValid.IsSpeciesValid, B_typed.Species, "")
770   argSex = IIf(IsValid.IsSexValid, B_typed.Sex, "")

780   Call IsWingChordValid(B_typed.WingChord, strNotBypassableErr, strBypassableErr, argSpecies, argSex)
790   strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
800   strBypassableMsg = strBypassableMsg & strBypassableErr

810   Call IsHowSexedValid(B_typed.HowSexed, strBypassableErr)
820   strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
830   strBypassableMsg = strBypassableMsg & strBypassableErr

840   Call IsFatValid(B_typed.Fat, strNotBypassableErr, strBypassableErr)
850   strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
860   strBypassableMsg = strBypassableMsg & strBypassableErr

870   Call IsWeightValid(B_typed.Weight, strNotBypassableErr, strBypassableErr, _
          argSpecies, argSex)
880   strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
890   strBypassableMsg = strBypassableMsg & strBypassableErr

900   Call IsWeightTimeValid(B_typed.WeightTime, strNotBypassableErr, strBypassableErr)
910   strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
920   strBypassableMsg = strBypassableMsg & strBypassableErr

930   Call IsBanderValid(B_typed.Bander, True, strNotBypassableErr, strBypassableErr) ' Current banders
940   strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
950   strBypassableMsg = strBypassableMsg & strBypassableErr

960   Call IsScribeValid(B_typed.Scribe, True, strNotBypassableErr, strBypassableErr)
970   strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
980   strBypassableMsg = strBypassableMsg & strBypassableErr

990   Call IsNetValid(B_typed.Net, strNotBypassableErr, strBypassableErr)
1000  strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
1010  strBypassableMsg = strBypassableMsg & strBypassableErr

1020  Call IsProbableAgeValid(B_typed.ProbableAge, strNotBypassableErr, strBypassableErr)
1030  strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
1040  strBypassableMsg = strBypassableMsg & strBypassableErr

1050  Call IsProbableSexValid(B_typed.ProbableSex, strNotBypassableErr, strBypassableErr)
1060  strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
1070  strBypassableMsg = strBypassableMsg & strBypassableErr

1080  Call IsLocationValid(B_typed.Location, strNotBypassableErr, strBypassableErr)
1090  strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
1100  strBypassableMsg = strBypassableMsg & strBypassableErr

1110  Call IsBirdStatusValid(B_typed.BirdStatus, strNotBypassableErr, strBypassableErr)
1120  strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
1130  strBypassableMsg = strBypassableMsg & strBypassableErr

      Dim D(conMaxDataField) As String
      Dim df As Integer
1140  For df = 1 To conMaxDataField
1150      D(df) = Nz(B_typed.D(df))
1160  Next df

      ' Validate D3 - Aux Marker Type

1170  Call IsAuxMarkerTypeValid(D(3), strNotBypassableErr, strBypassableErr)
1180  strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
1190  strBypassableMsg = strBypassableMsg & strBypassableErr

      ' Validate the user fields
          
      Dim F(conMaxUserField) As String

      Dim uf As Integer
1200  For uf = 1 To conMaxUserField
1210      F(uf) = B_typed.F(uf)
1220  Next uf
1230  strBypassableErr = ""
1240  If Not ValidateUserFields(B_typed.Species, F, strBypassableErr) Then
1250    strBypassableMsg = strBypassableMsg & strBypassableErr
1260  End If

          'DD Error Handler Start
Exit_label:
1270      Exit Sub
Err_label:
1280      Select Case Err.Number
          Case Else
1290     Call LogError("basSheetNewBands_v2", "Validate_SheetNewBandRecord")
1300      End Select
1310      Resume Exit_label
          ' DD Error Handler End

End Sub


'---------------------------------------------------------------------------------------
' Validate_SheetNewBandRecord_Disposition4or8
'---------------------------------------------------------------------------------------
' Call Validate_SheetNewBandRecord_Disposition4or8(B_typed, strNotBypassableMsg, strBypassableMsg)
'
' B_typed.BandPrefix and B_typed.BandSuffix are valid
' B_typed.Disposition is 4 or 8
'
' Non bypassable errors
' ---------------------
' A Disposition 4 record can only be used when the Species is  BADE
' A Disposition 8 record can only be used when the Species is  BALO
' There are other records for this lost band (Disposition 8)
' There are other records for this destroyed band (Disposition 4)



Private Sub Validate_SheetNewBandRecord_Disposition4or8( _
    ByRef B_typed As SheetNewBandRecordType, _
    ByRef strNotBypassableMsg As String, _
    ByRef strBypassableMsg As String)
          
10    On Error GoTo Err_label

      Dim strCriterion As String
20    strCriterion = _
          "BandPrefix = '" & B_typed.BandPrefix & "' AND " & _
          "BandSuffix = '" & B_typed.BandSuffix & "'"
          
30    If DCount("*", "tblCaptures", strCriterion) > 0 Then
40          If B_typed.Disposition = "4" Then
50            strNotBypassableMsg = strNotBypassableMsg & _
                  "There are other records for this destroyed band (Disposition 4)" & vbCrLf
60            Else ' B_typed.Disposition = "8"
70            strNotBypassableMsg = strNotBypassableMsg & _
                  "There are other records for this lost band (Disposition 8)" & vbCrLf
80            End If
90    End If

100   If B_typed.Disposition = "4" Then
110       If B_typed.Species <> "BADE" Then
120           strNotBypassableMsg = strNotBypassableMsg & _
                  "A Disposition 4 record can only be used when the Species is  BADE" & vbCrLf
130       End If
140   End If

150   If B_typed.Disposition = "8" Then
160       If B_typed.Species <> "BALO" Then
170           strNotBypassableMsg = strNotBypassableMsg & _
                  "A Disposition 8 record can only be used when the Species is  BALO" & vbCrLf
180       End If
190   End If
        

          'DD Error Handler Start
Exit_label:
200       Exit Sub
Err_label:
210       Select Case Err.Number
          Case Else
220            Call LogError("basSheetNewBands_v2", "Validate_SheetNewBandRecord_Disposition4or8")
230       End Select
240       Resume Exit_label
          ' DD Error Handler End
End Sub


'' ---------------------------------------------------------------------------
'' ValidateRecord
''
'' Validate a single record
''
'' strTableSheet = "tblSheetNewBandsMultiSize_v2"
'' ---------------------------------------------------------------------------
'
'Public Sub ValidateRecord_SheetNewBand_v2( _
'    ByVal strTableSheet As String, _
'    ByRef B As SheetNewCaptureRecordType, _
'    ByRef strNotBypassableMsg As String, _
'    ByRef strBypassableMsg As String, _
'    ByRef fIsLineBlank As Boolean, _
'    ByRef fDuplicateNewCapture As Boolean, _
'    ByVal fDisplayErrors As Boolean, _
'    ByRef IsValid As basTypes.IsValidType)
'
'10    On Error GoTo Err_label
'
'           ' Validate the record
'
'      Dim strBypassableErr As String
'
'20    IsValid.IsBandValid = True
'
'30    Call validate(strTableSheet, B, strNotBypassableMsg, strBypassableMsg, _
'          fIsLineBlank, fDuplicateNewCapture, IsValid)
'
'EndValidation_label:
'
'40    Call UpdateStatusFlags(strTableSheet, B.BandID, fDuplicateNewCapture, fIsLineBlank, strBypassableMsg, strNotBypassableMsg)
'
'50    If fDisplayErrors Then
'
'          Dim strErr As String
'
'60        If fDuplicateNewCapture Or fIsLineBlank Then
'70            If IsLoaded("frmValidationErrors") Then
'80                DoCmd.Close acForm, "frmValidationErrors"
'90            End If
'100       Else
'110           If strNotBypassableMsg <> "" Then
'120               strErr = strErr & _
'                      "Non-bypassable errors" & vbCrLf & _
'                      "---------------------" & vbCrLf & _
'                      strNotBypassableMsg & vbCrLf & vbCrLf
'130           End If
'
'140           If strBypassableMsg <> "" Then
'150               strErr = strErr & _
'                      "Bypassable errors" & vbCrLf & _
'                      "-----------------" & vbCrLf & _
'                      strBypassableMsg
'160           End If
'
'170           If strErr <> "" Then
'180               DoCmd.OpenForm "frmValidationErrors", OpenArgs:=strErr
'190           Else
'200               On Error Resume Next
'210               DoCmd.Close acForm, "frmValidationErrors"
'220               On Error GoTo Err_label
'230           End If
'240       End If
'
'250   End If
'
'      'DD Error Handler Start
'Exit_label:
'260        Exit Sub
'Err_label:
'270        Select Case Err.Number
'           Case Else
'280       Call LogError("basSheetNewBands_v2", "ValidateRecord")
'290        End Select
'300        Resume Exit_label
'      'DD Error Handler End
'
'End Sub


'---------------------------------------------------------------------------------------
' UpdateMaximumSpan
'
' Called from frmSheetNewBandsMultiSize_v2 and frmSheetRecaps_v2
'---------------------------------------------------------------------------------------
' A recap record might be entered before the corresponding (same band) banding record.


Public Sub UpdateMaximumSpan(ByRef strBandPrefix As String, ByRef strBandSuffix As String, ByRef strSpecies As String, ByRef IsRecordBroken As Boolean, ByRef lngMaxSpanSpecies As Long, ByRef lngMaxSpanBand As Long)

10       On Error GoTo Err_label

      Dim datDateFirst As Date
      Dim datDateLast As Date
      Dim strCriterion As String

      ' How many days between the first and last capture of this band

      ' Get the date of the first capture of this band

20    strCriterion = _
          "[BandPrefix] = '" & strBandPrefix & "' AND " & _
          "[BandSuffix] = '" & strBandSuffix & "' AND " & _
          "( Disposition <> '4' and Disposition <> '8' )"
30    datDateFirst = Nz(DMin("CaptureDate", "tblCaptures", strCriterion))
40    If datDateFirst = 0 Then GoTo Exit_label

      ' Get the date of the last capture of this band

50    datDateLast = Nz(DMax("CaptureDate", "tblCaptures", strCriterion))
60    If datDateLast = 0 Then GoTo Exit_label
         
       ' Calculate maximum span of this band

70    lngMaxSpanBand = datDateLast - datDateFirst
80    If lngMaxSpanBand <= 0 Then GoTo Exit_label
90    If lngMaxSpanBand < 0 Then
100       Call LogError("basSheetNewBands_v2", "UpdateMaximumSpan", "Date of first capture > date of last capture of Band = " & strBandPrefix & "-" & strBandSuffix, Silent:=False, DeveloperErrNumber:=1)
110       GoTo Exit_label
120   End If

      ' Get current record holder

130   lngMaxSpanSpecies = _
        Nz(DLookup("MaxMultiCaptureSpan", "tblSpecies", "Species='" & strSpecies & "'"), 0)

140   IsRecordBroken = (lngMaxSpanBand > lngMaxSpanSpecies)
         
          'DD Error Handler Start
Exit_label:
150       Exit Sub
Err_label:
160       Select Case Err.Number
          Case Else
170      Call LogError("basSheetNewBands_v2", "UpdateMaximumSpan")
180       End Select
190       Resume Exit_label
          ' DD Error Handler End
End Sub



'------------------------------------------------------------
' UpdateStatusFlags

' Priority 1 - Duplicate New Captures
'          2 - Blank record
'          3 - Not bypassable errors
'          4 - Bypassable errors
'          5 - Valid records
'------------------------------------------------------------
Private Sub UpdateStatusFlags( _
    ByVal strTableSheet As String, _
    ByVal lngBandID As Long, _
    ByVal fDuplicateNewCapture As Boolean, _
    ByVal fIsLineBlank As Boolean, _
    ByVal strBypassableMsg As String, _
    ByVal strNotBypassableMsg As String)

      '  Open a recordset for the record

      Dim rst As DAO.Recordset
      Dim strSQL As String

10    On Error GoTo Err_label

20    strSQL = _
          "SELECT * " & _
          "FROM " & strTableSheet & " " & _
          "WHERE BandID = " & lngBandID
30    Set rst = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)
40    If rst.EOF Then Exit Sub

50    rst.Edit

60    If fDuplicateNewCapture Then
70        rst("Valid") = Null
80        rst("Invalid") = Null
90        rst("Duplicate") = "D"
100   ElseIf fIsLineBlank Then
110       rst("Valid") = Null
120       rst("Invalid") = Null
130       rst("Duplicate") = Null
140       rst("BypassErrors") = False
150   ElseIf strNotBypassableMsg <> "" Then
160       rst("Valid") = Null
170       rst("Invalid") = "E"
180       rst("Duplicate") = Null
190   ElseIf strBypassableMsg <> "" Then
200       rst("Valid") = Null
210       rst("Invalid") = "x"
220       rst("Duplicate") = Null
230   Else
240       rst("Valid") = "v"
250       rst("Invalid") = Null
260       rst("Duplicate") = Null
270   End If

280   rst.Update
290   rst.Close

      'DD Error Handler Start
Exit_label:
300        Exit Sub
Err_label:
310        Select Case Err.Number
           Case Else
320       Call LogError("basSheetNewBands_v2", "UpdateStatusFlags")
330        End Select
340        Resume Exit_label
      'DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' AnalyseNotesNewBands
'---------------------------------------------------------------------------------------
 
Private Sub AnalyseNotesNewBands(ByVal strTableSheet As String, ByVal lngBandID As Long)

      Dim rst As DAO.Recordset
      Dim strSQL As String

10    On Error GoTo Err_label

20    strSQL = _
          "SELECT * " & _
          "FROM " & strTableSheet & " " & _
          "WHERE BandID = " & lngBandID
30    Set rst = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)
40    If Not rst.EOF Then

50        rst.Edit
          Dim uf As Integer
60        For uf = 1 To conMaxUserField
70            rst("F" & uf) = Null
80        Next uf
90        rst("F") = Null
100       rst.Update
            
110       Call AnalyseNotes(rst)
120   End If

      'DD Error Handler Start
Exit_label:
130        Exit Sub
Err_label:
140        Select Case Err.Number
           Case Else
150       Call LogError("basSheetNewBands_v2", "AnalyseNotesNewBands")
160        End Select
170        Resume Exit_label
      'DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' Validate
'
' strTableSheet = "tblSheetNewBandsMultiSize_v2"
'
'---------------------------------------------------------------------------------------
 
Private Sub validate( _
    ByVal strTableSheet As String, _
    ByRef B As SheetNewBandRecordType, _
    ByRef strNotBypassableMsg As String, _
    ByRef strBypassableMsg As String, _
    ByRef fIsLineBlank As Boolean, _
    ByRef fDuplicateNewCapture As Boolean, _
    ByRef IsValid As basTypes.IsValidType)

10    On Error GoTo Err_label

20    strNotBypassableMsg = ""
30    strBypassableMsg = ""
40    fIsLineBlank = False
50    fDuplicateNewCapture = False

      ' For tblSheetNewBands, fDuplicateNewCapture can always be calculated
      ' and it has priority over everything else including fIsLineBlank


60    fDuplicateNewCapture = IsBandDuplicate(B.BandPrefix, B.BandSuffix)
70    If fDuplicateNewCapture Then
80        Exit Sub
90    End If

      ' Skip blank records

100   If IsLineBlank_v2(B) Then
110       fIsLineBlank = True
120       Exit Sub
130   End If

      Dim strNotBypassableErr As String

140   IsValid.IsBandValid = True

      ' Validate the Prefix

150   If Not IsBandPrefixValid(B.BandPrefix, strNotBypassableErr) Then
160       IsValid.IsBandValid = False
170       strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
180   End If

      ' Validate the Suffix

190   If Not IsBandSuffixValid(B.BandSuffix, strNotBypassableErr) Then
200       IsValid.IsBandValid = False
210       strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
220   End If

      ' Validate the Disposition

230   IsValid.IsDispositionValid = True
240   If Not IsDispositionValid(B.Disposition, strNotBypassableErr, "New Captures") Then
250       strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
260       IsValid.IsDispositionValid = False
270   End If

280   If Not (IsValid.IsDispositionValid And IsValid.IsBandValid) Then
290       Exit Sub
300   End If

      ' Validate Band Lost and Band Destroyed records
      ' Don't search for non R/F records since they will be flagged as duplicates

310   If B.Disposition = "4" Or B.Disposition = "8" Then
          Dim strCriterion As String
320       strCriterion = _
        "BandPrefix = '" & B.BandPrefix & "' AND " & _
        "BandSuffix = '" & B.BandSuffix & "' AND " & _
        "Disposition in ('R','F')"
330       If DCount("*", "tblCaptures", strCriterion) > 0 Then
340     If B.Disposition = "4" Then
350         strNotBypassableMsg = strNotBypassableMsg & _
                "There are recapture records for this destroyed band (Disposition 4)" & vbCrLf
360     Else ' b.Disposition = "8"
370         strNotBypassableMsg = strNotBypassableMsg & _
                "There are recapture records for this lost band (Disposition 8)" & vbCrLf
380     End If
390       End If
          
          ' Nothing else to validate
          
400       Exit Sub
410   End If

      Dim strBypassableErr As String

      ' Update the array of bypassable error messages

420   Call IsProgramValid(B.Program, strNotBypassableErr, strBypassableErr)
430   strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
440   strBypassableMsg = strBypassableMsg & strBypassableErr

450   If strBypassableErr = "" And strNotBypassableErr = "" Then
460       Call SetBypassableErrorMessageCurrentProgram(B.Program)
470   Else
480       Call SetBypassableErrorMessageCurrentProgram("")
490   End If
        
500   If IsValid.IsBandValid And IsValid.IsDispositionValid Then
510       fDuplicateNewCapture = IsBandDuplicate(B.BandPrefix, B.BandSuffix)
520   Else
530       fDuplicateNewCapture = False
540   End If

      ' Validate Capture Date

550   IsValid.IsDateValid = IsDateValid(B.CaptureDate, B.CaptureYear, B.Program, strNotBypassableErr, strBypassableErr)
560   strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
570   strBypassableMsg = strBypassableMsg & strBypassableErr

580   If strNotBypassableErr = "" Then
          Dim strErr As String
          Dim datCaptureDate As Date
590       datCaptureDate = Nz(ConvertCaptureDateAndCaptureYearToVBADate(B.CaptureDate, B.CaptureYear))
          Dim varWeightTime As Variant
600       varWeightTime = ConvertWeightTimeToVBADate(B.WeightTime)
          Dim fDuplicateRecapture As Boolean
610       Call DateAndTimeAnalysis(B.Disposition, B.BandPrefix, B.BandSuffix, _
        datCaptureDate, varWeightTime, B.Program, 0, strErr, fDuplicateRecapture)
620       strNotBypassableMsg = strErr
630   End If

640   If IsValid.IsBandValid Then
650       IsValid.IsSpeciesValid = IsSpeciesValid(B.Species, strNotBypassableErr, strBypassableErr, "", _
        B.BandPrefix, B.BandSuffix)
660   Else
670       IsValid.IsSpeciesValid = IsSpeciesValid(B.Species, strNotBypassableErr, strBypassableErr, "")
680   End If
690   strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
700   strBypassableMsg = strBypassableMsg & strBypassableErr

710   IsValid.IsMultiRecordError = False

720   If IsValid.IsBandValid And IsValid.IsDateValid Then
730       Call IsAgeValid(B.Age, B.BandPrefix, B.BandSuffix, B.CaptureYear, _
        strNotBypassableErr, strBypassableErr, IsValid.IsMultiRecordError)
740       strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
750       strBypassableMsg = strBypassableMsg & strBypassableErr
760   End If

770   Call IsHowAgedValid(B.HowAged, strBypassableErr)
780   strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
790   strBypassableMsg = strBypassableMsg & strBypassableErr

800   If IsValid.IsBandValid And IsValid.IsDispositionValid Then
810       IsValid.IsSexValid = IsSexValid(B.Sex, strNotBypassableErr, strBypassableErr, _
        IsValid.IsMultiRecordError, _
        B.BandPrefix, B.BandSuffix, B.Disposition)
820   Else
830       IsValid.IsSexValid = IsSexValid(B.Sex, strNotBypassableErr, strBypassableErr, _
        IsValid.IsMultiRecordError)
840   End If
850   strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
860   strBypassableMsg = strBypassableMsg & strBypassableErr

      Dim argSpecies As String
      Dim argSex As String

870   argSpecies = IIf(IsValid.IsSpeciesValid, B.Species, "")
880   argSex = IIf(IsValid.IsSexValid, B.Sex, "")

890   Call IsWingChordValid(B.WingChord, strNotBypassableErr, strBypassableErr, _
          argSpecies, argSex)
900   strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
910   strBypassableMsg = strBypassableMsg & strBypassableErr

920   Call IsHowSexedValid(B.HowSexed, strBypassableErr)
930   strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
940   strBypassableMsg = strBypassableMsg & strBypassableErr

950   Call IsFatValid(B.Fat, strNotBypassableErr, strBypassableErr)
960   strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
970   strBypassableMsg = strBypassableMsg & strBypassableErr

980   Call IsWeightValid(B.Weight, strNotBypassableErr, strBypassableErr, _
          argSpecies, argSex)
990   strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
1000  strBypassableMsg = strBypassableMsg & strBypassableErr

1010  Call IsWeightTimeValid(B.WeightTime, strNotBypassableErr, strBypassableErr)
1020  strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
1030  strBypassableMsg = strBypassableMsg & strBypassableErr

1040  Call IsBanderValid(B.Bander, True, strNotBypassableErr, strBypassableErr) ' Current banders
1050  strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
1060  strBypassableMsg = strBypassableMsg & strBypassableErr

1070  Call IsScribeValid(B.Scribe, True, strNotBypassableErr, strBypassableErr)
1080  strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
1090  strBypassableMsg = strBypassableMsg & strBypassableErr

1100  Call IsNetValid(B.Net, strNotBypassableErr, strBypassableErr)
1110  strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
1120  strBypassableMsg = strBypassableMsg & strBypassableErr

1130  Call IsProbableAgeValid(B.ProbableAge, strNotBypassableErr, strBypassableErr)
1140  strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
1150  strBypassableMsg = strBypassableMsg & strBypassableErr

1160  Call IsProbableSexValid(B.ProbableSex, strNotBypassableErr, strBypassableErr)
1170  strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
1180  strBypassableMsg = strBypassableMsg & strBypassableErr

1190  Call IsLocationValid(B.Location, strNotBypassableErr, strBypassableErr)
1200  strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
1210  strBypassableMsg = strBypassableMsg & strBypassableErr

1220  Call IsBirdStatusValid(B.BirdStatus, strNotBypassableErr, strBypassableErr)
1230  strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
1240  strBypassableMsg = strBypassableMsg & strBypassableErr

      Dim D(conMaxDataField) As String
      Dim df As Integer
1250  For df = 1 To conMaxDataField
1260      D(df) = Nz(B.D(df))
1270  Next df

      ' Validate D3 - Aux Marker Type

1280  Call IsAuxMarkerTypeValid(D(3), strNotBypassableErr, strBypassableErr)
1290  strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
1300  strBypassableMsg = strBypassableMsg & strBypassableErr

      ' Validate the user fields
          
      Dim F(conMaxUserField) As String

      Dim uf As Integer
1310  For uf = 1 To conMaxUserField
1320      F(uf) = B.F(uf)
1330  Next uf
1340  strBypassableErr = ""
1350  If Not ValidateUserFields(B.Species, F, strBypassableErr) Then
1360    strBypassableMsg = strBypassableMsg & strBypassableErr
1370  End If

      'DD Error Handler Start
Exit_label:
1380       Exit Sub
Err_label:
1390       Select Case Err.Number
           Case Else
1400      Call LogError("basSheetNewBands_v2", "Validate")
1410       End Select
1420       Resume Exit_label
      'DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' DuplicateBand
'---------------------------------------------------------------------------------------

Private Function IsBandDuplicate(ByVal BandPrefix As String, ByVal BandSuffix As String) As Boolean
      Dim strCriterion As String


10    On Error GoTo Err_label

20    strCriterion = "BandPrefix = '" & BandPrefix & "' AND " & _
                     "BandSuffix = '" & BandSuffix & "' AND " & _
                     "not (Disposition = 'R' OR Disposition = 'F')  "

30    IsBandDuplicate = (DCount("*", "tblCaptures", strCriterion) <> 0)

      'DD Error Handler Start
Exit_label:
40         Exit Function
Err_label:
50         Select Case Err.Number
           Case Else
60        Call LogError("basSheetNewBands", "IsBandDuplicate")
70         End Select
80         Resume Exit_label
      'DD Error Handler End

End Function
