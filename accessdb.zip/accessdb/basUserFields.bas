Option Compare Database
Option Explicit

'---------------------------------------------------------------------------------------
' ValidateUserFields
'---------------------------------------------------------------------------------------
 
 Const conText             As Integer = 1
 Const conInteger          As Integer = 2
 Const conDecimal          As Integer = 3
 Const conAllValuesInvalid As Integer = 4
 
'---------------------------------------------------------------------------------------
'ValidateUserFields
'---------------------------------------------------------------------------------------
' Some user field validations are for all species, others are species specific
' If we do not know the species ( Species = "" ) then skip the species specific validations


Public Function ValidateUserFields( _
    ByVal Species As String, _
    F() As String, _
    ByRef strBypassableErr As String) As Boolean

10    On Error GoTo Err_label

      Dim msg As String
20    msg = ""

      Dim df As Integer
30    For df = 1 To conMaxUserField

          Dim value  As String
40        value = F(df)
          
      '   Null values are always valid

50        If value = "" Then
60            GoTo Continue_label
70        End If
          
          Dim varMax As Variant
          Dim dblMax As Double
          Dim varMin As Variant
          Dim dblMin As Double
          
          Dim strUserFieldName As String
          Dim strUserFieldAbbreviation As String
80        strUserFieldName = Nz(DLookup("UserFieldName", "tblUserFields", "UserFieldID=" & df))
90        strUserFieldAbbreviation = _
              Nz(DLookup("UserFieldAbbreviation", "tblUserFields", "UserFieldID=" & df))
              
          Dim strLabel As String
100       If strUserFieldAbbreviation = "" Then
110           strLabel = "F" & df & " "
120       Else
130           strLabel = strUserFieldAbbreviation & " "
140       End If

150       If strUserFieldName <> "" Then
160           strLabel = strLabel & "(" & strUserFieldName & ")"
170       End If

180       strLabel = strLabel & " " & Species & ": "
          
          Dim strCondition As String
190       strCondition = "UserFieldID=" & df & " AND Species is Null"
          Dim strConditionSpecies As String
200       strConditionSpecies = "UserFieldID=" & df & " AND Species = '" & Species & "'"
        
          Dim strWhere As String
          
          ' If the species was invalid, then skip the species specific validations
          
210       If Species = "" Then
220           If DCount("*", "tblUserFieldValidations", strCondition) > 0 Then
230               strWhere = strCondition
240           Else
250               msg = msg & strLabel & "All values are invalid" & vbCrLf
260               GoTo Continue_label
270           End If
280       Else
290           If DCount("*", "tblUserFieldValidations", strConditionSpecies) > 0 Then
300               strWhere = strConditionSpecies
310           ElseIf DCount("*", "tblUserFieldValidations", strCondition) > 0 Then
320               strWhere = strCondition
330           Else
340               msg = msg & strLabel & "All values are invalid" & vbCrLf
350               GoTo Continue_label
360           End If
370       End If

          Dim DataType As Integer
380       DataType = Nz(DLookup("DataType", "tblUserFieldValidations", strWhere))

390       Select Case DataType

          Case conText
          
              Dim intWidth             As Integer
              Dim strValidationRule    As String

400           intWidth = Nz(DLookup("Width", "tblUserFieldValidations", strWhere), 0)
410           strValidationRule = Trim(Nz(DLookup("ValidationRule", "tblUserFieldValidations", strWhere), ""))
        
420           If Len(value) > intWidth And intWidth <> 0 Then
430               msg = msg & strLabel & "Maximum " & intWidth & " characters" & vbCrLf
440               GoTo Continue_label
450           End If

              Dim varValues As Variant
                     
460           If strValidationRule <> "" Then
470               varValues = Split(strValidationRule)
                  Dim R As Integer
                  Dim IsValid As Boolean
480               IsValid = False
490               For R = LBound(varValues) To UBound(varValues)
500                   If varValues(R) = value Then
510                       IsValid = True
520                       Exit For
530                   End If
540               Next R
550               If Not IsValid Then
560                   msg = msg & strLabel & strValidationRule
570                   GoTo Continue_label
580               End If
590           End If
          
600       Case conInteger

610           If IsNumeric(value) Then
620               If InStr(1, value, ".") = 0 Then
                  
                     Dim lngValue As Long
630                  lngValue = CInt(value)
                     
640                  varMax = DLookup("Maximum", "tblUserFieldValidations", strWhere)
650                  varMin = DLookup("Minimum", "tblUserFieldValidations", strWhere)

660                  dblMax = Nz(varMax, 0)
670                  dblMin = Nz(varMin, 0)
                                
680                  If Not IsNull(varMin) Then
690                      If lngValue < dblMin Then
700                           msg = msg & strLabel & "Minimum allowed is " & dblMin & vbCrLf
710                           GoTo Continue_label
720                      End If
730                  End If
                     
740                   If Not IsNull(varMax) Then
750                      If lngValue > dblMax Then
760                           msg = msg & strLabel & "Maximum  allowed is " & dblMax & vbCrLf
770                           GoTo Continue_label
780                      End If
790                  End If
                  
800               Else
810                   msg = msg & strLabel & "Decimal point not allowed" & vbCrLf
820                   GoTo Continue_label
830               End If
840           Else
850               msg = msg & strLabel & "Must be an integer" & vbCrLf
860               GoTo Continue_label
870           End If
              
880       Case conDecimal
              
890           If Not IsNumeric(value) Then
900               msg = msg & strLabel & "Must be a decimal number" & vbCrLf
910               GoTo Continue_label
920           Else
                  Dim dblValue As Double
930               dblValue = CDbl(value)
                  
940               varMax = DLookup("Maximum", "tblUserFieldValidations", strWhere)
950               varMin = DLookup("Minimum", "tblUserFieldValidations", strWhere)

960               dblMax = Nz(varMax, 0)
970               dblMin = Nz(varMin, 0)

980               If Not IsNull(varMin) Then
990                   If dblValue < dblMin Then
1000                       msg = msg & strLabel & "Minimum is " & dblMin & vbCrLf
1010                       GoTo Continue_label
1020                  End If
1030              End If
                  
1040               If Not IsNull(varMax) Then
1050                  If dblValue > dblMax Then
1060                       msg = msg & strLabel & "Maximum is " & dblMax & vbCrLf
1070                       GoTo Continue_label
1080                  End If
1090              End If
              
1100          End If
              
1110      Case conAllValuesInvalid
          
1120          msg = msg & strLabel & "All values are invalid" & vbCrLf
1130          GoTo Continue_label
                      
1140      End Select
          
Continue_label:
1150  Next df

1160  If msg <> "" Then
1170      ValidateUserFields = False
1180  Else
1190      ValidateUserFields = True
1200  End If
1210  strBypassableErr = msg

      'DD Error Handler Start
Exit_label:
1220       Exit Function
Err_label:
1230       Select Case Err.Number
           Case Else
1240      Call LogError("basUserFields", "ValidateUserFields")
1250       End Select
1260       Resume Exit_label
      'DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' ConvertUserFieldValueToUppercaseUnlessSuppressed
'---------------------------------------------------------------------------------------
 
Public Sub ConvertUserFieldValueToUppercaseUnlessSuppressed( _
    ByRef UserFieldValue As String, _
    ByVal UserFieldID As Long, _
    ByVal Species As String)
          
10    On Error GoTo Err_label

      Dim fSuppressToUppercase As Boolean
      Dim strWhere As String

20    If Species <> "" Then

30        strWhere = _
              "UserFieldID = " & UserFieldID & " AND " & _
              "Species = '" & Species & "'"
40        If DCount("*", "tblUserFieldValidations", strWhere) > 0 Then
50            fSuppressToUppercase = _
                  Nz(DLookup("SuppressToUppercase", "tblUserFieldValidations", strWhere))
60        Else
70            strWhere = _
                  "UserFieldID = " & UserFieldID & " AND " & _
                  "Species Is Null"
80            If DCount("*", "tblUserFieldValidations", strWhere) > 0 Then
90                fSuppressToUppercase = _
                      Nz(DLookup("SuppressToUppercase", "tblUserFieldValidations", strWhere))
100           Else
110               fSuppressToUppercase = False
120           End If
130       End If
          
140   Else

150       strWhere = _
              "UserFieldID = " & UserFieldID & " AND " & _
              "Species Is Null"
160       If DCount("*", "tblUserFieldValidations", strWhere) > 0 Then
170           fSuppressToUppercase = _
                  Nz(DLookup("SuppressToUppercase", "tblUserFieldValidations", strWhere))
180       Else
190           fSuppressToUppercase = False
200       End If

210   End If

220   If Not fSuppressToUppercase Then
230       UserFieldValue = UCase(UserFieldValue)
240   End If


      'DD Error Handler Start
Exit_label:
250        Exit Sub
Err_label:
260        Select Case Err.Number
           Case Else
270             Call LogError("basUserFields", "ConvertUserFieldValueToUppercaseUnlessSuppressed")
280        End Select
290        Resume Exit_label
      'DD Error Handler End

End Sub


'---------------------------------------------------------------------------------------
' TranslateUserFieldAlternateValuesToStandardValues
'---------------------------------------------------------------------------------------
 
Public Sub TranslateUserFieldAlternateValueToStandardValue( _
    ByRef UserFieldValue As String, _
    ByVal Species As String)
          
10    On Error GoTo Err_label

20    If Species <> "" Then

          ' Search for a species specific alternate value
          
          Dim val As String
          
30        val = Nz(DLookup("UserFieldValueStandard", _
              "tblUserFieldAlternateValues", _
              "UserFieldValueAlternate = '" & UserFieldValue & "' AND Species = '" & Species & "'"))
          
40        If val <> "" Then
50            UserFieldValue = val
60        Else
          
          '   Search for a generic alternate value
          
70            val = Nz(DLookup("UserFieldValueStandard", _
                  "tblUserFieldAlternateValues", _
                  "UserFieldValueAlternate = '" & UserFieldValue & "' AND Species is Null"))
80            If val <> "" Then
90                UserFieldValue = val
100           End If
110       End If

120   Else

      '   Search for a generic alternate value

130       val = Nz(DLookup("UserFieldValueStandard", _
              "tblUserFieldAlternateValues", _
              "UserFieldValueAlternate = '" & UserFieldValue & "' AND Species is Null"))
140       If val <> "" Then
150           UserFieldValue = val
160       End If
          
170   End If


      'DD Error Handler Start
Exit_label:
180        Exit Sub
Err_label:
190        Select Case Err.Number
           Case Else
200             Call LogError("basUserFields", "TranslateUserFieldAlternateValuesToStandardValues")
210        End Select
220        Resume Exit_label
      'DD Error Handler End
          
End Sub

'---------------------------------------------------------------------------------------
' GetUserFieldIDFromAbbreviation
'
' Returns 0 if the arg is neither an alternate abbreviation nor a standard abbreviation
'---------------------------------------------------------------------------------------
 
Public Function GetUserFieldIDFromAbbreviation( _
    ByVal UserFieldAbbreviation As String) As Long
          
      Dim strWhere As String
      Dim UserFieldID As Long

      ' Lookup the User Field Alternate Abbreviation

10    On Error GoTo Err_label

20    strWhere = "UserFieldAlternateAbbreviation = '" & UserFieldAbbreviation & "'"
30    If DCount("*", "tblUserFieldAlternateAbbreviations", strWhere) > 0 Then
40        UserFieldID = _
              Nz(DLookup("UserFieldID", "tblUserFieldAlternateAbbreviations", strWhere))
50    Else

          ' Lookup the User Field Standard Abbreviation

60        strWhere = "UserFieldAbbreviation = '" & UserFieldAbbreviation & "'"
70        If DCount("*", "tblUserFields", strWhere) > 0 Then
80            UserFieldID = _
                  Nz(DLookup("UserFieldID", "tblUserFields", strWhere))
90        End If
100   End If

110   GetUserFieldIDFromAbbreviation = UserFieldID

      'DD Error Handler Start
Exit_label:
120        Exit Function
Err_label:
130        Select Case Err.Number
           Case Else
140             Call LogError("basUserFields", "GetUserFieldIDFromAbbreviation")
150        End Select
160        Resume Exit_label
      'DD Error Handler End
          
End Function
