'---------------------------------------------------------------------------------------
' Module    : basSheetRecaps_v2
' Author    : David Davey
'---------------------------------------------------------------------------------------

Option Compare Database
Option Explicit

Const strTableSheet As String = "tblSheetRecaps_v2"
Const strTableStore As String = "tblCaptures"


' ---------------------------------------------------------------------------------------
' GetRecord_v2
' ---------------------------------------------------------------------------------------
' Fill in all the fields of B (type SheetRecaptureRecordType) from the IDBand = lngBandID record of tblSheetRecaps_v2

Public Sub GetRecord_v2( _
    ByVal lngBandID As Long, _
    ByRef B As SheetRecaptureRecordType)
          
10       On Error GoTo Err_label

20    On Error GoTo Err_label

      ' Open a recordset for the record

      Dim rst As DAO.Recordset
      Dim strSQL As String

30    strSQL = _
          " SELECT * " & _
          " FROM " & strTableSheet & _
          " WHERE BandID = " & lngBandID
40    Set rst = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)
50    If rst.EOF Then Exit Sub

       '      Get record

60    B.BandID = lngBandID
70    B.BandPrefix = Trim(Nz(rst("BandPrefix")))
80    B.BandSuffix = Trim(Nz(rst("BandSuffix")))
90    B.Species = Trim(Nz(rst("Species")))
100   B.WingChord = Trim(Nz(rst("WingChord")))
110   B.Age = Trim(Nz(rst("Age")))
120   B.HowAged = Trim(Nz(rst("HowAged")))
130   B.Sex = Trim(Nz(rst("Sex")))
140   B.HowSexed = Trim(Nz(rst("HowSexed")))
150   B.Fat = Trim(Nz(rst("Fat")))
160   B.Weight = Trim(Nz(rst("Weight")))
170   B.CaptureDate = Trim(Nz(rst("CaptureDate")))
180   B.WeightTime = Trim(Nz(rst("WeightTime")))
190   B.Bander = Trim(Nz(rst("Bander")))
200   B.Scribe = Trim(Nz(rst("Scribe")))
210   B.Net = Trim(Nz(rst("Net")))
220   B.NotesForMBO = Trim(Nz(rst("NotesForMBO")))
230   B.ProbableAge = Trim(Nz(rst("ProbableAge")))
240   B.ProbableSex = Trim(Nz(rst("ProbableSex")))
250   B.CaptureYear = Trim(Nz(rst("CaptureYear")))
260   B.Disposition = Trim(Nz(rst("Disposition")))
270   B.Location = Trim(Nz(rst("Location")))
280   B.Program = Trim(Nz(rst("Program")))
290   B.BirdStatus = Trim(Nz(rst("BirdStatus")))
300   B.AutoHistory = Nz(rst("AutoHistory"))

      Dim uf As Integer
310   For uf = 1 To conMaxUserField
320       B.F(uf) = Trim(Nz(rst("F" & uf)))
330   Next uf

      Dim df As Integer
340   For df = 1 To conMaxDataField
350       B.D(df) = Trim(Nz(rst("D" & df)))
360   Next df

370   B.FCombined = Trim(Nz(rst("F")))
380   B.Flags = Nz(rst("Flags"))

390   rst.Close

          'DD Error Handler Start
Exit_label:
400       Exit Sub
Err_label:
410       Select Case Err.Number
          Case Else
420      Call LogError("basSheetRecaps_v2", "GetRecord_v2")
430       End Select
440       Resume Exit_label
          ' DD Error Handler End

End Sub

' ---------------------------------------------------------------------------------------
' GetRecordFromSheetRecaptureRecordset
' ---------------------------------------------------------------------------------------
' Fill in all the fields of B (type SheetRecaptureRecordType) from a recapture sheet recordset

Public Sub GetRecordFromSheetRecaptureRecordset( _
    ByRef rst As DAO.Recordset, _
    ByRef B As SheetRecaptureRecordType)
          
10    On Error GoTo Err_label

20    If rst.EOF Then Exit Sub

       '      Get record

30    B.BandID = Trim(Nz(rst("BandID")))
40    B.BandPrefix = Trim(Nz(rst("BandPrefix")))
50    B.BandSuffix = Trim(Nz(rst("BandSuffix")))
60    B.Species = Trim(Nz(rst("Species")))
70    B.WingChord = Trim(Nz(rst("WingChord")))
80    B.Age = Trim(Nz(rst("Age")))
90    B.HowAged = Trim(Nz(rst("HowAged")))
100   B.Sex = Trim(Nz(rst("Sex")))
110   B.HowSexed = Trim(Nz(rst("HowSexed")))
120   B.Fat = Trim(Nz(rst("Fat")))
130   B.Weight = Trim(Nz(rst("Weight")))
140   B.CaptureDate = Trim(Nz(rst("CaptureDate")))
150   B.WeightTime = Trim(Nz(rst("WeightTime")))
160   B.Bander = Trim(Nz(rst("Bander")))
170   B.Scribe = Trim(Nz(rst("Scribe")))
180   B.Net = Trim(Nz(rst("Net")))
190   B.NotesForMBO = Trim(Nz(rst("NotesForMBO")))
200   B.ProbableAge = Trim(Nz(rst("ProbableAge")))
210   B.ProbableSex = Trim(Nz(rst("ProbableSex")))
220   B.CaptureYear = Trim(Nz(rst("CaptureYear")))
230   B.Disposition = Trim(Nz(rst("Disposition")))
240   B.Location = Trim(Nz(rst("Location")))
250   B.Program = Trim(Nz(rst("Program")))
260   B.BirdStatus = Trim(Nz(rst("BirdStatus")))
270   B.AutoHistory = Nz(rst("AutoHistory"))

      Dim uf As Integer
280   For uf = 1 To conMaxUserField
290       B.F(uf) = Trim(Nz(rst("F" & uf)))
300   Next uf

      Dim df As Integer
310   For df = 1 To conMaxDataField
320       B.D(df) = Trim(Nz(rst("D" & df)))
330   Next df

340   B.FCombined = Trim(Nz(rst("F")))
350   B.Flags = Nz(rst("Flags"))

      'DD Error Handler Start
Exit_label:
360        Exit Sub
Err_label:
370        Select Case Err.Number
           Case Else
380       Call LogError("basSheetRecaps_v2", "GetRecordFromSheetRecaptureRecordset")
390        End Select
400        Resume Exit_label
      'DD Error Handler End

End Sub


' ---------------------------------------------------------------------------
' ValidateRecord
'
' Validate a single recapture record
' ---------------------------------------------------------------------------

Public Sub ValidateRecord_SheetRecaps_v2( _
    ByRef B As SheetRecaptureRecordType, _
    ByRef strNotBypassableMsg As String, _
    ByRef strBypassableMsg As String, _
    ByRef fIsLineBlank As Boolean, _
    ByVal fDisplayErrors As Boolean, _
    ByRef IsValid As IsValidType)

10    On Error GoTo Err_label

      ' Validate

      Dim strBypassableErr As String

20    Call validate(B, strNotBypassableMsg, strBypassableMsg, fIsLineBlank, IsValid)
          
EndValidation_label:

      ' Update Status Flags

30    Call UpdateStatusFlags(B.BandID, fIsLineBlank, strBypassableMsg, strNotBypassableMsg)

40    If fDisplayErrors Then

          Dim strErr As String
          
50        If fIsLineBlank Then
60            If IsLoaded("frmValidationErrors") Then
70                DoCmd.Close acForm, "frmValidationErrors"
80            End If
90        Else
100           If strNotBypassableMsg <> "" Then
110               strErr = strErr & _
                      "Non-bypassable errors" & vbCrLf & _
                      "---------------------" & vbCrLf & _
                      strNotBypassableMsg & vbCrLf & vbCrLf
120           End If
              
130           If strBypassableMsg <> "" Then
140               strErr = strErr & _
                      "Bypassable errors" & vbCrLf & _
                      "-----------------" & vbCrLf & _
                      strBypassableMsg
150           End If
          
160           If strErr <> "" Then
170               DoCmd.OpenForm "frmValidationErrors", OpenArgs:=strErr
180           Else
190               On Error Resume Next
200               DoCmd.Close acForm, "frmValidationErrors"
210               On Error GoTo Err_label
220           End If
230       End If

240   End If


      'DD Error Handler Start
Exit_label:
250        Exit Sub
Err_label:
260        Select Case Err.Number
           Case Else
270       Call LogError("basSheetRecaps_v2", "ValidateRecord")
280        End Select
290        Resume Exit_label
      'DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' ProcessMultiCapture
'---------------------------------------------------------------------------------------

Public Sub ProcessMultiCapture( _
    ByRef B As SheetRecaptureRecordType, _
    ByVal fNotBypassableError As Boolean, _
    ByRef IsValid As basTypes.IsValidType, _
    ByRef IsRecordBroken As Boolean, _
    ByRef MaxSpanSpecies As Long, _
    ByRef MaxSpanBand As Long)
          
10    On Error GoTo Err_label

20    IsRecordBroken = False

      ' Skip records with non-bypassable errors
      ' Skip records with invalid capture dates
      ' Skip records with invalid species

30    If fNotBypassableError Then GoTo Exit_label
40    If Not IsValid.IsDateValid Then GoTo Exit_label
50    If Not IsValid.IsSpeciesValid Then GoTo Exit_label

      ' Extract date of this capture

      Dim datCaptureDate As Date
60    datCaptureDate = Nz(ConvertCaptureDateAndCaptureYearToVBADate(B.CaptureDate, B.CaptureYear))
70    If datCaptureDate = 0 Then GoTo Exit_label

      ' Get the date of the earliest capture of this band

      Dim datDateEarliest As Date
      Dim strCriterion As String
80    strCriterion = _
          "[BandPrefix] = '" & B.BandPrefix & "' AND " & _
          "[BandSuffix] = '" & B.BandSuffix & "' AND " & _
          "( Disposition <> '4' and Disposition <> '8' )"
90    datDateEarliest = Nz(DMin("CaptureDate", "tblCaptures", strCriterion))
100   If datDateEarliest = 0 Then GoTo Exit_label

      ' Calculate maximum span of this band

110   MaxSpanBand = datCaptureDate - datDateEarliest
120   If MaxSpanBand = 0 Then GoTo Exit_label

      ' Get current record holder

130   MaxSpanSpecies = _
          Nz(DLookup("MaxMultiCaptureSpan", "tblSpecies", "Species='" & B.Species & "'"), 0)

'130   If MaxSpanSpecies = 0 Then
'140       Exit Sub
'150   End If

140   IsRecordBroken = (MaxSpanBand > MaxSpanSpecies)

      'DD Error Handler Start
Exit_label:
150        Exit Sub
Err_label:
160        Select Case Err.Number
           Case Else
170             Call LogError("basSheetRecaps_v2", "ProcessMultiCapture")
180        End Select
190        Resume Exit_label
      'DD Error Handler End

End Sub


''---------------------------------------------------------------------------------------
'' UpdateMaximumSpan
''---------------------------------------------------------------------------------------
'
'Sub UpdateMaximumSpan(ByRef strBandPrefix As String, ByRef strBandSuffix As String, ByRef strSpecies As String, ByRef IsRecordBroken As Boolean, ByRef lngMaxSpanSpecies As Long, ByRef lngMaxSpanBand As Long)
'
'10       On Error GoTo Err_label
'
'      Dim datDateFirst As Date
'      Dim datDateLast As Date
'      Dim strCriterion As String
'
'      ' How many days between the first and last capture of this band
'
'      ' Get the date of the first capture of this band
'
'20    strCriterion = _
'          "[BandPrefix] = '" & strBandPrefix & "' AND " & _
'          "[BandSuffix] = '" & strBandSuffix & "' AND " & _
'          "( Disposition <> '4' and Disposition <> '8' )"
'30    datDateFirst = Nz(DMin("CaptureDate", "tblCaptures", strCriterion))
'40    If datDateFirst = 0 Then GoTo Exit_label
'
'      ' Get the date of the last capture of this band
'
'50    datDateLast = Nz(DMax("CaptureDate", "tblCaptures", strCriterion))
'60    If datDateLast = 0 Then GoTo Exit_label
'
'       ' Calculate maximum span of this band
'
'70    lngMaxSpanBand = datDateLast - datDateFirst
'80    If lngMaxSpanBand <= 0 Then GoTo Exit_label
'90    If lngMaxSpanBand < 0 Then
'100       Call LogError("basSheetNewBands_v2", "UpdateMaximumSpan", "Date of first capture > date of last capture of Band = " & strBandPrefix & "-" & strBandSuffix, Silent:=False, DeveloperErrNumber:=1)
'110       GoTo Exit_label
'120   End If
'
'      ' Get current record holder
'
'130   lngMaxSpanSpecies = _
'        Nz(DLookup("MaxMultiCaptureSpan", "tblSpecies", "Species='" & strSpecies & "'"), 0)
'
'140   IsRecordBroken = (lngMaxSpanBand > lngMaxSpanSpecies)
'
'          'DD Error Handler Start
'Exit_label:
'150       Exit Sub
'Err_label:
'160       Select Case Err.Number
'          Case Else
'170      Call LogError("basSheetNewBands_v2", "UpdateMaximumSpan")
'180       End Select
'190       Resume Exit_label
'          ' DD Error Handler End
'End Sub


' ---------------------------------------------------------------------------
' IsLineBlank
' ---------------------------------------------------------------------------

Private Function IsLineBlank(B As SheetRecaptureRecordType) As Boolean
10    On Error GoTo Err_label

20    IsLineBlank = _
          (Trim(B.BandPrefix) = "") And (Trim(B.BandSuffix) = "") And _
          (Trim(B.Species) = "") And (Trim(B.WingChord) = "") And _
          (Trim(B.Age) = "") And (Trim(B.HowAged) = "") And _
          (Trim(B.Sex) = "") And (Trim(B.HowSexed) = "") And _
          (Trim(B.Fat) = "") And (Trim(B.Weight) = "") And _
          (Trim(B.CaptureDate) = "") And (Trim(B.WeightTime) = "") And _
          (Trim(B.Bander) = "") And (Trim(B.Scribe) = "") And _
          (Trim(B.Net) = "") And (Trim(B.NotesForMBO) = "") And _
          (Trim(B.ProbableAge) = "") And (Trim(B.ProbableSex) = "") And _
          (Trim(B.CaptureYear) = "") And (Trim(B.Disposition) = "") And _
          (Trim(B.Location) = "") And (Trim(B.BirdStatus) = "") And _
          (Trim(B.Program) = "") And Not (B.AutoHistory)
          
30    IsLineBlank = IsLineBlank And Trim(B.NotesForMBO) = ""
          
40    If IsLineBlank Then
          Dim uf As Integer
50        For uf = 1 To conMaxUserField
60          If Trim(B.F(uf)) <> "" Then
70              IsLineBlank = False
80              Exit For
90          End If
100       Next uf
110   End If
          
      'DD Error Handler Start
Exit_label:
120        Exit Function
Err_label:
130        Select Case Err.Number
           Case Else
140       Call LogError("basSheetRecaps_v2", "IsLineBlank")
150        End Select
160        Resume Exit_label
      'DD Error Handler End
End Function

' ---------------------------------------------------------------------------
' Validate
' ---------------------------------------------------------------------------
' Validates a single recapture record

Private Sub validate( _
    ByRef B As SheetRecaptureRecordType, _
    ByRef strNotBypassableMsg As String, _
    ByRef strBypassableMsg As String, _
    ByRef fIsLineBlank As Boolean, _
    ByRef IsValid As basTypes.IsValidType)
          
10    On Error GoTo Err_label

20    strNotBypassableMsg = ""
30    strBypassableMsg = ""
40    fIsLineBlank = False

50    If IsLineBlank(B) Then
60        fIsLineBlank = True
70        Exit Sub
80    End If

      Dim strNotBypassableErr As String
      Dim strBypassableErr As String

      ' Validate Band Number

      Dim fBandPrefixValid As Boolean
      Dim fBandSuffixValid As Boolean
      Dim fDispositionValid As Boolean

90    fBandPrefixValid = IsBandPrefixValid(B.BandPrefix, strNotBypassableErr)
100   strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr

110   fBandSuffixValid = IsBandSuffixValid(B.BandSuffix, strNotBypassableErr)
120   strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr

130   IsValid.IsBandValid = fBandPrefixValid And fBandSuffixValid

      ' Set the Disposition

140   If IsValid.IsBandValid Then
150       Call UpdateDisposition(B.BandID, strNotBypassableErr, B.Disposition)
160       If strNotBypassableErr <> "" Then
170           strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
180       End If
190   End If

200   fDispositionValid = (B.Disposition = "R") Or (B.Disposition = "F")

      ' Update the array of bypassable error messages

210   Call IsProgramValid(B.Program, strNotBypassableErr, strBypassableErr)
220   strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
230   strBypassableMsg = strBypassableMsg & strBypassableErr

240   If strBypassableErr = "" And strNotBypassableErr = "" Then
250       Call SetBypassableErrorMessageCurrentProgram(B.Program)
260   Else
270       Call SetBypassableErrorMessageCurrentProgram("")
280   End If

290   IsValid.IsDateValid = IsDateValid(B.CaptureDate, B.CaptureYear, B.Program, strNotBypassableErr, strBypassableErr)
300   strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
310   strBypassableMsg = strBypassableMsg & strBypassableErr

320   If IsValid.IsBandValid And IsValid.IsDateValid And fDispositionValid Then
          Dim strErr As String
          Dim datCaptureDate As Date
330       datCaptureDate = Nz(ConvertCaptureDateAndCaptureYearToVBADate(B.CaptureDate, B.CaptureYear))
          Dim varWeightTime As Variant
340       varWeightTime = ConvertWeightTimeToVBADate(B.WeightTime)
          Dim fDuplicateRecapture As Boolean
350       Call DateAndTimeAnalysis(B.Disposition, B.BandPrefix, B.BandSuffix, _
              datCaptureDate, varWeightTime, B.Program, 0, strErr, fDuplicateRecapture)
360       strNotBypassableMsg = strNotBypassableMsg & strErr
370   End If

380   If IsValid.IsBandValid Then
390       IsValid.IsSpeciesValid = IsSpeciesValid(B.Species, strNotBypassableErr, strBypassableErr, "", _
              B.BandPrefix, B.BandSuffix)
400   Else
410       IsValid.IsSpeciesValid = IsSpeciesValid(B.Species, strNotBypassableErr, strBypassableErr, "")
420   End If
430   strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
440   strBypassableMsg = strBypassableMsg & strBypassableErr

450   IsValid.IsMultiRecordError = False

460   If IsValid.IsBandValid And IsValid.IsDateValid Then
470       Call IsAgeValid(B.Age, B.BandPrefix, B.BandSuffix, B.CaptureYear, _
              strNotBypassableErr, strBypassableErr, IsValid.IsMultiRecordError)
480       strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
490       strBypassableMsg = strBypassableMsg & strBypassableErr
500   End If

510   Call IsHowAgedValid(B.HowAged, strBypassableErr)
520   strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
530   strBypassableMsg = strBypassableMsg & strBypassableErr

540   If IsValid.IsBandValid Then
550       IsValid.IsSexValid = IsSexValid(B.Sex, strNotBypassableErr, strBypassableErr, _
              IsValid.IsMultiRecordError, _
              B.BandPrefix, B.BandSuffix, "R")
560   Else
570       IsValid.IsSexValid = IsSexValid(B.Sex, strNotBypassableErr, strBypassableErr, _
              IsValid.IsMultiRecordError)
580   End If
590   strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
600   strBypassableMsg = strBypassableMsg & strBypassableErr

      Dim argSpecies As String
      Dim argSex As String

610   argSpecies = IIf(IsValid.IsSpeciesValid, B.Species, "")
620   argSex = IIf(IsValid.IsSexValid, B.Sex, "")

630   Call IsWingChordValid(B.WingChord, strNotBypassableErr, strBypassableErr, _
          argSpecies, argSex)
640   strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
650   strBypassableMsg = strBypassableMsg & strBypassableErr

660   Call IsHowSexedValid(B.HowSexed, strBypassableErr)
670   strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
680   strBypassableMsg = strBypassableMsg & strBypassableErr

690   Call IsFatValid(B.Fat, strNotBypassableErr, strBypassableErr)
700   strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
710   strBypassableMsg = strBypassableMsg & strBypassableErr

720   Call IsWeightValid(B.Weight, strNotBypassableErr, strBypassableErr, _
          argSpecies, argSex)
730   strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
740   strBypassableMsg = strBypassableMsg & strBypassableErr

750   Call IsWeightTimeValid(B.WeightTime, strNotBypassableErr, strBypassableErr)
760   strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
770   strBypassableMsg = strBypassableMsg & strBypassableErr

780   Call IsBanderValid(B.Bander, True, strNotBypassableErr, strBypassableErr) ' Current banders
790   strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
800   strBypassableMsg = strBypassableMsg & strBypassableErr

810   Call IsScribeValid(B.Scribe, True, strNotBypassableErr, strBypassableErr)
820   strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
830   strBypassableMsg = strBypassableMsg & strBypassableErr

840   Call IsNetValid(B.Net, strNotBypassableErr, strBypassableErr)
850   strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
860   strBypassableMsg = strBypassableMsg & strBypassableErr

870   Call IsProbableAgeValid(B.ProbableAge, strNotBypassableErr, strBypassableErr)
880   strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
890   strBypassableMsg = strBypassableMsg & strBypassableErr

900   Call IsProbableSexValid(B.ProbableSex, strNotBypassableErr, strBypassableErr)
910   strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
920   strBypassableMsg = strBypassableMsg & strBypassableErr

930   Call IsLocationValid(B.Location, strNotBypassableErr, strBypassableErr)
940   strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
950   strBypassableMsg = strBypassableMsg & strBypassableErr

960   Call IsBirdStatusValid(B.BirdStatus, strNotBypassableErr, strBypassableErr)
970   strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
980   strBypassableMsg = strBypassableMsg & strBypassableErr

      Dim D(conMaxDataField) As String
      Dim df As Integer
990   For df = 1 To conMaxDataField
1000      D(df) = Nz(B.D(df))
1010  Next df

      ' Validate D3 - Aux Marker Type

1020  Call IsAuxMarkerTypeValid(D(3), strNotBypassableErr, strBypassableErr)
1030  strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
1040  strBypassableMsg = strBypassableMsg & strBypassableErr


      ' Validate the user fields
          
      Dim F(conMaxUserField) As String
      Dim uf As Integer
1050  For uf = 1 To conMaxUserField
1060      F(uf) = B.F(uf)
1070  Next uf
1080  strBypassableErr = ""
1090  If Not ValidateUserFields(B.Species, F, strBypassableErr) Then
1100    strBypassableMsg = strBypassableMsg & strBypassableErr
1110  End If




      'DD Error Handler Start
Exit_label:
1120       Exit Sub
Err_label:
1130       Select Case Err.Number
           Case Else
1140      Call LogError("basSheetRecaps_v2", "Validate")
1150       End Select
1160       Resume Exit_label
      'DD Error Handler End
End Sub

'------------------------------------------------------------
' UpdateStatusFlags

' Priority 1 - Duplicate New Captures
'          2 - Blank record
'          3 - Not bypassable errors
'          4 - Bypassable errors
'          5 - Valid records
'------------------------------------------------------------

Private Sub UpdateStatusFlags( _
    ByVal lngBandID As Long, _
    ByVal fIsLineBlank As Boolean, _
    ByVal strBypassableMsg As String, _
    ByVal strNotBypassableMsg As String)
          
10    On Error GoTo Err_label

      '  Open a recordset for the record

      Dim rst As DAO.Recordset
      Dim strSQL As String
20    On Error GoTo Err_label

30    strSQL = _
          " SELECT * " & _
          " FROM " & strTableSheet & _
          " WHERE BandID = " & lngBandID
40    Set rst = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)
50    If rst.EOF Then Exit Sub

60    rst.Edit

70    If fIsLineBlank Then
80        rst("Valid") = Null
90        rst("Invalid") = Null
100       rst("BypassErrors") = False
110   ElseIf strNotBypassableMsg <> "" Then
120       rst("Valid") = Null
130       rst("Invalid") = "E"
'140       rst("Disposition") = Null
150   ElseIf strBypassableMsg <> "" Then
160       rst("Valid") = Null
170       rst("Invalid") = "x"
180   Else
190       rst("Valid") = "v"
200       rst("Invalid") = Null
210   End If

220   rst.Update
230   rst.Close

      'DD Error Handler Start
Exit_label:
240        Exit Sub
Err_label:
250        Select Case Err.Number
           Case Else
260       Call LogError("basSheetRecaps_v2", "UpdateStatusFlags")
270        End Select
280        Resume Exit_label
      'DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' UpdateDisposition
'
' Called from
' basSheetRecaps_v2.validate
' frmRestore.ActionAddRecapture
'---------------------------------------------------------------------------------------
'
' If the BandID capture record is missing,
'    then log a silent error message. set the record's Disposition to Null, return Disposition = ""; strErr = an error message. Return.
' If either the Band Prefix or Band Suffix is invalid, set the record's Disposition to Null, return Disposition = ""; strErr = an error message. Return.
'
' If there are corresponding capture record with disposition 4, 8,
'    then set the record's Disposition to Null, return Disposition = ""; strErr = an error message. Return

' If there is a corresponding record with disposition 1 or 5,
'    then set the disposition to "R". Return Disposition = "R"; strErr = "",
'    else set the disposition to "F", Return Disposition = "F"; strErr = "".

 
Public Sub UpdateDisposition(ByVal lngBandID As Long, ByRef strErr As String, ByRef Disposition As String)
          
10    On Error GoTo Err_label
       
20    strErr = ""
30    Disposition = ""

      Dim Prefix       As String
      Dim Suffix       As String
      Dim rst          As DAO.Recordset
      Dim strSQL       As String
      Dim strCriterion As String

       '   Open a recordset for the record
       
40    strSQL = _
          " SELECT * " & _
          " FROM " & strTableSheet & _
          " WHERE BandID = " & lngBandID
50    Set rst = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)

60    If rst.EOF Then
70        Call LogError("basSheetRecaps_v2", "UpdateDisposition", "The recapture record for BandID = " & lngBandID & " is missing", Silent:=True, DeveloperErrNumber:=1)
80        rst("Disposition") = Null
90        Disposition = ""
100       strErr = "The recapture record for BandID = " & lngBandID & " is missing"
110       GoTo Update_label
120   End If

130   rst.Edit

140   Prefix = Trim(Nz(rst("BandPrefix")))
150   Suffix = Trim(Nz(rst("BandSuffix")))

      ' Validate the prefix and suffix

160   strErr = ""
      Dim strNotBypassableErr As String
170   If Not IsBandPrefixValid(Prefix, strNotBypassableErr) Then strErr = strErr & " Band prefix is invalid"
180   If Not IsBandSuffixValid(Suffix, strNotBypassableErr, False) Then strErr = strErr & " Band suffix is invalid"
190   strErr = Trim(strErr)
200   If strErr <> "" Then
210       rst("Disposition") = Null
220       Disposition = ""
230       GoTo Update_label
240   End If

      ' Is there any corresponding disposition 4 or 8 capture records?
         
250   strCriterion = _
          "[BandPrefix] = '" & Prefix & "' AND " & _
          "[BandSuffix] = '" & Suffix & "' AND " & _
          "Disposition  in ('4', '8')"
260   If DCount("*", "tblCaptures", strCriterion) > 0 Then
270       strErr = "This band has been destroyed or lost" & vbCrLf
280       rst("Disposition") = Null
290       Disposition = ""
300       GoTo Update_label
310   End If
          
      ' Is there is a corresponding disposition "1" or "5" capture record then disposition = "R",
      ' else, disposition = "F"
          
320   strCriterion = _
          "[BandPrefix] = '" & Prefix & "' AND " & _
          "[BandSuffix] = '" & Suffix & "' AND " & _
          "Disposition in ('1', '5')"
330   If DCount("*", "tblCaptures", strCriterion) > 0 Then
340       rst("Disposition") = "R"
350       Disposition = "R"
360   Else
370       rst("Disposition") = "F"
380       Disposition = "F"
390   End If

Update_label:

400   rst.Update
410   rst.Close

      'DD Error Handler Start
Exit_label:
420        Exit Sub
Err_label:
430        Select Case Err.Number
           Case Else
440             Call LogError("basSheetRecaps_v2", "UpdateDisposition")
450        End Select
460        Resume Exit_label
      'DD Error Handler End

End Sub


'---------------------------------------------------------------------------------------
' CalculateDispositionForRecapture
'---------------------------------------------------------------------------------------
' Given Band Prefix and Band Suffix, calculate the Dispositon of a recapture record

' If either the Band Prefix or Band Suffix is invalid:  Return strErr = an error message
'
' If there are corresponding capture record with disposition 4, 8,
'    then return strErr = an error message

' If there is a corresponding record with disposition 1 or 5,
'    then  return Disposition = "R"; strErr = "",
'    else  return Disposition = "F"; strErr = ""
'
' Call CalculateDispositionForRecapture( strBandPrefix,  strBandSuffix,  strNotBypassableMsg,  strDisposition)

 
Public Sub CalculateDispositionForRecapture(ByVal strBandPrefix As String, ByVal strBandSuffix As String, ByRef strNotBypassableMsg As String, ByRef strDisposition As String)
          
10    On Error GoTo Err_label
       
20    strNotBypassableMsg = ""
30    strDisposition = ""

      Dim strCriterion As String
      Dim strNotBypassableErr As String

      ' Validate the prefix and suffix

40    strNotBypassableMsg = ""
50    If Not IsBandPrefixValid(strBandPrefix, strNotBypassableErr) Then strNotBypassableMsg = strNotBypassableMsg & " Band prefix is invalid"
60    If Not IsBandSuffixValid(strBandSuffix, strNotBypassableErr) Then strNotBypassableMsg = strNotBypassableMsg & " Band suffix is invalid"
70    strNotBypassableMsg = Trim(strNotBypassableMsg)
80    If strNotBypassableMsg <> "" Then GoTo Exit_label

      ' Is there any corresponding disposition 4 or 8 capture records?
         
90    strCriterion = _
          "[BandPrefix] = '" & strBandPrefix & "' AND " & _
          "[BandSuffix] = '" & strBandSuffix & "' AND " & _
          "Disposition  in ('4', '8')"
100   If DCount("*", "tblCaptures", strCriterion) > 0 Then
110       strNotBypassableMsg = "This band has been destroyed or lost" & vbCrLf
120       strDisposition = ""
130       GoTo Exit_label
140   End If
          
      ' Is there is a corresponding disposition "1" or "5" capture record then disposition = "R",
      ' else, disposition = "F"
          
150   strCriterion = _
          "[BandPrefix] = '" & strBandPrefix & "' AND " & _
          "[BandSuffix] = '" & strBandSuffix & "' AND " & _
          "Disposition in ('1', '5')"
160   If DCount("*", "tblCaptures", strCriterion) > 0 Then
170       strDisposition = "R"
180   Else
190       strDisposition = "F"
200   End If


      'DD Error Handler Start
Exit_label:
210        Exit Sub
Err_label:
220        Select Case Err.Number
           Case Else
230             Call LogError("basSheetRecaps_v2", "CalculateDispositionForRecapture")
240        End Select
250        Resume Exit_label
      'DD Error Handler End

End Sub

' ---------------------------------------------------------------------------
' Validate_Recapture
' ---------------------------------------------------------------------------
' Validates a single recapture record
' ---------------------------------------------------------------------------
' Called from frmRestore,ActionAddRecapture
'
' Call Validate_Recapture(B, strNotBypassableMsg, strBypassableMsg, IsValid)

Public Sub Validate_Recapture( _
    ByRef B As SheetRecaptureRecordType, _
    ByRef strNotBypassableMsg As String, _
    ByRef strBypassableMsg As String, _
    ByRef IsValid As basTypes.IsValidType)
          
10    On Error GoTo Err_label

20    strNotBypassableMsg = ""
30    strBypassableMsg = ""

      Dim strNotBypassableErr As String
      Dim strBypassableErr As String

      ' Validate Band Number

      Dim fBandPrefixValid As Boolean
      Dim fBandSuffixValid As Boolean
      Dim fDispositionValid As Boolean

40    fBandPrefixValid = IsBandPrefixValid(B.BandPrefix, strNotBypassableErr)
50    strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr

60    fBandSuffixValid = IsBandSuffixValid(B.BandSuffix, strNotBypassableErr)
70    strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr

80    IsValid.IsBandValid = fBandPrefixValid And fBandSuffixValid

90    fDispositionValid = (B.Disposition = "R") Or (B.Disposition = "F")

100   If B.Species = "BADE" Then
110       strNotBypassableMsg = strNotBypassableMsg & "Recaptures cannot be BADE" & vbCrLf
120       Exit Sub ' Nothing else to validate
130   End If

140   If B.Species = "BALO" Then
150       strNotBypassableMsg = strNotBypassableMsg & "Recaptures cannot be BALO" & vbCrLf
160       Exit Sub ' Nothing else to validate
170   End If

      ' Update the array of bypassable error messages

180   Call IsProgramValid(B.Program, strNotBypassableErr, strBypassableErr)
190   strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
200   strBypassableMsg = strBypassableMsg & strBypassableErr

210   If strBypassableErr = "" And strNotBypassableErr = "" Then
220       Call SetBypassableErrorMessageCurrentProgram(B.Program)
230   Else
240       Call SetBypassableErrorMessageCurrentProgram("")
250   End If

260   IsValid.IsDateValid = IsDateValid(B.CaptureDate, B.CaptureYear, B.Program, strNotBypassableErr, strBypassableErr)
270   strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
280   strBypassableMsg = strBypassableMsg & strBypassableErr

290   If IsValid.IsBandValid And IsValid.IsDateValid And fDispositionValid Then
          Dim strErr As String
          Dim datCaptureDate As Date
300       datCaptureDate = Nz(ConvertCaptureDateAndCaptureYearToVBADate(B.CaptureDate, B.CaptureYear))
          Dim varWeightTime As Variant
310       varWeightTime = ConvertWeightTimeToVBADate(B.WeightTime)
          Dim fDuplicateRecapture As Boolean
320       Call DateAndTimeAnalysis(B.Disposition, B.BandPrefix, B.BandSuffix, _
              datCaptureDate, varWeightTime, B.Program, 0, strErr, fDuplicateRecapture)
330       strNotBypassableMsg = strNotBypassableMsg & strErr
340   End If

350   If IsValid.IsBandValid Then
360       IsValid.IsSpeciesValid = IsSpeciesValid(B.Species, strNotBypassableErr, strBypassableErr, "", _
              B.BandPrefix, B.BandSuffix)
370   Else
380       IsValid.IsSpeciesValid = IsSpeciesValid(B.Species, strNotBypassableErr, strBypassableErr, "")
390   End If
400   strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
410   strBypassableMsg = strBypassableMsg & strBypassableErr

420   IsValid.IsMultiRecordError = False

430   If IsValid.IsBandValid And IsValid.IsDateValid Then
440       Call IsAgeValid(B.Age, B.BandPrefix, B.BandSuffix, B.CaptureYear, _
              strNotBypassableErr, strBypassableErr, IsValid.IsMultiRecordError)
450       strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
460       strBypassableMsg = strBypassableMsg & strBypassableErr
470   End If

480   Call IsHowAgedValid(B.HowAged, strBypassableErr)
490   strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
500   strBypassableMsg = strBypassableMsg & strBypassableErr

510   If IsValid.IsBandValid Then
520       IsValid.IsSexValid = IsSexValid(B.Sex, strNotBypassableErr, strBypassableErr, _
              IsValid.IsMultiRecordError, _
              B.BandPrefix, B.BandSuffix, "R")
530   Else
540       IsValid.IsSexValid = IsSexValid(B.Sex, strNotBypassableErr, strBypassableErr, _
              IsValid.IsMultiRecordError)
550   End If
560   strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
570   strBypassableMsg = strBypassableMsg & strBypassableErr

      Dim argSpecies As String
      Dim argSex As String

580   argSpecies = IIf(IsValid.IsSpeciesValid, B.Species, "")
590   argSex = IIf(IsValid.IsSexValid, B.Sex, "")

600   Call IsWingChordValid(B.WingChord, strNotBypassableErr, strBypassableErr, _
          argSpecies, argSex)
610   strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
620   strBypassableMsg = strBypassableMsg & strBypassableErr

630   Call IsHowSexedValid(B.HowSexed, strBypassableErr)
640   strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
650   strBypassableMsg = strBypassableMsg & strBypassableErr

660   Call IsFatValid(B.Fat, strNotBypassableErr, strBypassableErr)
670   strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
680   strBypassableMsg = strBypassableMsg & strBypassableErr

690   Call IsWeightValid(B.Weight, strNotBypassableErr, strBypassableErr, _
          argSpecies, argSex)
700   strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
710   strBypassableMsg = strBypassableMsg & strBypassableErr

720   Call IsWeightTimeValid(B.WeightTime, strNotBypassableErr, strBypassableErr)
730   strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
740   strBypassableMsg = strBypassableMsg & strBypassableErr

750   Call IsBanderValid(B.Bander, True, strNotBypassableErr, strBypassableErr) ' Current banders
760   strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
770   strBypassableMsg = strBypassableMsg & strBypassableErr

780   Call IsScribeValid(B.Scribe, True, strNotBypassableErr, strBypassableErr)
790   strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
800   strBypassableMsg = strBypassableMsg & strBypassableErr

810   Call IsNetValid(B.Net, strNotBypassableErr, strBypassableErr)
820   strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
830   strBypassableMsg = strBypassableMsg & strBypassableErr

840   Call IsProbableAgeValid(B.ProbableAge, strNotBypassableErr, strBypassableErr)
850   strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
860   strBypassableMsg = strBypassableMsg & strBypassableErr

870   Call IsProbableSexValid(B.ProbableSex, strNotBypassableErr, strBypassableErr)
880   strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
890   strBypassableMsg = strBypassableMsg & strBypassableErr

900   Call IsLocationValid(B.Location, strNotBypassableErr, strBypassableErr)
910   strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
920   strBypassableMsg = strBypassableMsg & strBypassableErr

930   Call IsBirdStatusValid(B.BirdStatus, strNotBypassableErr, strBypassableErr)
940   strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
950   strBypassableMsg = strBypassableMsg & strBypassableErr

      Dim D(conMaxDataField) As String
      Dim df As Integer
960   For df = 1 To conMaxDataField
970       D(df) = Nz(B.D(df))
980   Next df

      ' Validate D3 - Aux Marker Type

990   Call IsAuxMarkerTypeValid(D(3), strNotBypassableErr, strBypassableErr)
1000  strNotBypassableMsg = strNotBypassableMsg & strNotBypassableErr
1010  strBypassableMsg = strBypassableMsg & strBypassableErr

      ' Validate the user fields
          
      Dim F(conMaxUserField) As String
      Dim uf As Integer
1020  For uf = 1 To conMaxUserField
1030      F(uf) = B.F(uf)
1040  Next uf
1050  strBypassableErr = ""
1060  If Not ValidateUserFields(B.Species, F, strBypassableErr) Then
1070    strBypassableMsg = strBypassableMsg & strBypassableErr
1080  End If


      'DD Error Handler Start
Exit_label:
1090       Exit Sub
Err_label:
1100       Select Case Err.Number
           Case Else
1110      Call LogError("basSheetRecaps_v2", "Validate_Recapture")
1120       End Select
1130       Resume Exit_label
      'DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' CountCaptureRecords
'
' PRE: Band# is valid
'---------------------------------------------------------------------------------------
 
Public Function CountCaptureRecords(ByVal Prefix As String, ByVal Suffix As String)

Dim strCriterion As String
      
10    On Error GoTo Err_label

20    On Error GoTo Err_label

30    strCriterion = _
          "BandPrefix = '" & Prefix & "' AND BandSuffix = '" & Suffix & "'"
40        CountCaptureRecords = Nz(DCount("*", strTableStore, strCriterion))

    'DD Error Handler Start
Exit_label:
50        Exit Function
Err_label:
60        Select Case Err.Number
    Case Else
70       Call LogError("basSheetRecaps_v2", "CountCaptureRecords")
80        End Select
90        Resume Exit_label
    ' DD Error Handler End
End Function
