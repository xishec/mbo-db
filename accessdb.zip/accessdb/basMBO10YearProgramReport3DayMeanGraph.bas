'---------------------------------------------------------------------------------------
' Module    : basMBO10YearProgramReport3DayMeanGraph
' Author    : David Davey
'---------------------------------------------------------------------------------------
Option Explicit
Option Compare Database

' Statistics

Private Const conBND As Integer = 1
Private Const conCNS As Integer = 2
Private Const conDET As Integer = 3

Private Const conSpring As Integer = 1
Private Const conFall As Integer = 2

' ====================================================================================================================================
' The following instance variables are reinitialised for each chart: "Banded Birds", "Banded Species", "Census Species", "DET Species"
' ====================================================================================================================================
'
' A standardized date is a date in which the year has ben replaced by 2000.
' N.B. Here I am only dealing with Spring and Fall so the programs start and end in the same calendar year

Private intYearFirst As Integer     ' First report year (2005)
Private intYearLast As Integer      ' Last report year
Private strLocation As String       ' MBO
Private strSeason As String         ' "Spring" or "Fall"
Private wd As Word.Application
Private doc As Word.Document
Private oExcel As Excel.Application
Private oBook As Excel.Workbook
Private strChart As String          ' "Banded Birds", "Banded Species", "Census Species", "DET Species"
Private fDebug As Boolean

Private m_intSeason As Integer      ' conSpring for Spring; conFall for Fall
Private m_intStat As Integer        ' conBND, conCNS, conDET

Private dblStat() As Double         ' dblStat(datDayFirst(intStat, m_intSeason) To datDayLast(intStat, intSeason), intYearFirst To intYearLast+1)
                                    ' dblStat(datDayFirst(intStat, m_intSeason) To datDayLast(intStat,intYearLast+1) contains the per day means over all years

' ====================================================================================================================================
' The following instance variables are initialised on the first call all of MBO10YearProgramReport3DayMeanGraph()
' ====================================================================================================================================

Public fDayFirstLastInitialised As Boolean     ' True iff the DayFirst and DayLast varables and arrays have been initialised
                                               ' Set to false when the user clicks the generate 5x year report command button

Private datDayFirstTable() As Date  ' datDayFirstTable(conBND TO conDET, conSpring .. conFall,intFirstYear .. intLastYear+1)
                                    '       the standardised earliest date that the stat
                                    '       is 2001-01-01 if stat was never recorded for the season x year
                                    ' datDayFirstTable(intStat, intSeason, intLastYear+1) is the min from datDayFirstTable(intStat, intSeason, intFirstYear .. intLastYear)

Private datDayLastTable() As Date   ' datDayLastTable(conBND TO conDET, conSpring .. conFall, intFirstYear .. intLastYear+1)
                                    '       the standardised eariest date for the stat
                                    '       is 1999-12-31 if stat was never recorded for the season x year
                                    ' datDayLastTable(intStat, intSeason, intLastYear+1) is the max from datDayLastTable(intStat, intSeason, intFirstYear .. intLastYear)

Private datDayFirst(conBND To conDET, conSpring To conFall) As Date         ' Same as datDayFirstTable(intStat, intSeason, intLastYear+1)             I use both, so I must ensure they are equal
Private datDayLast(conBND To conDET, conSpring To conFall) As Date         ' Same as datDayFirstTable(intStat, intSeason, intLastYear+1)

Private datDayFirstANY(conSpring To conFall) As Date    ' datDayFirstANY(conSpring .. conFall)
                                                        ' the first standardised date for ANY data (DET, Observed, Census, Banded, Alien, Replacement, DET)  in the season OR the nets were opened
                                                        ' the x-axis for all 4 graphs for a season start on the same day
Private datDayLastANY(conSpring To conFall) As Date     ' datDayLastANY(conSpring .. conFall)
                                                        ' the last standardised date for ANY data (DET, Observed, Census, Banded, Alien, Replacement, DET) in the season OR the nets were opened
                                                        ' the x-axis for all 4 graphs for a season end on the same day

'---------------------------------------------------------------------------------------
' MBO10YearProgramReport3DayMeanGraph
'---------------------------------------------------------------------------------------
 
Public Sub MBO10YearProgramReport3DayMeanGraph( _
    ByRef fValid As Boolean, _
    ByVal argYearFirst As Integer, _
    ByVal argYearLast As Integer, _
    ByVal argLocation As String, _
    ByVal argSeason As String, _
    ByRef arg_wd As Word.Application, _
    ByRef arg_doc As Word.Document, _
    ByRef arg_excel As Excel.Application, _
    ByRef arg_book As Excel.Workbook, _
    ByVal arg_chart As String, _
    ByVal arg_debug As Boolean)
           
      ' Save parameters

10    On Error GoTo Err_label

20    intYearFirst = argYearFirst
30    intYearLast = argYearLast
40    strLocation = argLocation
50    strSeason = argSeason
60    Set wd = arg_wd
70    Set doc = arg_doc
80    Set oExcel = arg_excel
90    Set oBook = arg_book
100   strChart = arg_chart
110   fDebug = arg_debug

120   If strSeason = "Spring" Then
130       m_intSeason = conSpring
140   Else
150       m_intSeason = conFall
160   End If

170   Select Case strChart
      Case "Banded Birds", "Banded Species"
180       m_intStat = conBND
190   Case "Census Species"
200       m_intStat = conCNS
210   Case "DET Species"
220       m_intStat = conDET
230   End Select

240   Call Load_datDayFirst_Last

250   Select Case strChart
      Case "Banded Birds"
260       Call BandedBirds
270   Case "Banded Species"
280       Call Species(conBND)
290   Case "Census Species"
300       Call Species(conCNS)
310   Case "DET Species"
320       Call Species(conDET)
330   End Select

      'DD Error Handler Start
Exit_label:
340        Exit Sub
Err_label:
350        Select Case Err.Number
           Case Else
360       Call LogError("basMBO10YearProgramReport3DayMeanGraph", "MBO10YearProgramReport3DayMeanGraph")
370        End Select
380        Resume Exit_label
      'DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' Load_datDayFirst_Last
'---------------------------------------------------------------------------------------
' Banded Birds and Banded Species are a pain since I take into account capture days with 0 bandings
' A capture day is any day in which the nets were opened OR at least one capture took place

' For census I assume a 0 census stat => cnsus did not take place (i.e. not a Census Day)
' For DET I assume a 0 DET stat => DET did not take place (i.e. not a DET Day)

Private Sub Load_datDayFirst_Last()

   On Error GoTo Err_label

10    On Error GoTo Err_label

      Dim intSeason As Integer
      Dim intYear As Integer
      Dim intStat As Integer

      ' Only load the First and Last Day variable and arrays once each time a 5x report is generate
      ' fDayFirstLastInitialised was set to False when the user pressed the generate the 5x report command button

20    If fDayFirstLastInitialised Then GoTo Exit_label
30    fDayFirstLastInitialised = True

40    ReDim datDayFirstTable(conBND To conDET, conSpring To conFall, intYearFirst To intYearLast + 1)
50    ReDim datDayLastTable(conBND To conDET, conSpring To conFall, intYearFirst To intYearLast + 1)

      ' Initialise the First Day arrays to the sentinel value 2001-01-01
      ' Initialise the Last Day arrays to the sentinel value Dec 1999-12-31

60    For intStat = conBND To conDET
70        For intSeason = conSpring To conFall
80            For intYear = intYearFirst To intYearLast + 1
90                datDayFirstTable(intStat, intSeason, intYear) = DateSerial(2001, 1, 1)
100               datDayLastTable(intStat, intSeason, intYear) = DateSerial(1999, 12, 31)
110           Next
120           datDayFirst(intStat, intSeason) = DateSerial(2001, 1, 1)
130           datDayLast(intStat, intSeason) = DateSerial(1999, 12, 31)
140           datDayFirstANY(intSeason) = DateSerial(2001, 1, 1)
150           datDayLastANY(intSeason) = DateSerial(1999, 12, 31)
160       Next
170   Next


180   Select Case strChart
      Case "Banded Birds", "Banded Species"

        ' qryMBO10YearProgramReport3DayMeanGraph_FirstLastCaptureDays_A
        ' -------------------------------------------------------------
        ' For each season x year, list the days with some captures
        ' -------------------------------------------------------------
        ' tblDETSpecies x tblPrograms
        '
        ' WHERE Season IN ("Spring", "Fall")
        ' WHERE Location = [argLocation]
        ' WHERE YearEx = BETWEEN [argYearFirst] AND [argYearLast]
        ' Captures =  SUM Nz([Banded])+Nz([Returns])+Nz([Repeats])+Nz([Observed3])+Nz([Observed4]))
        ' HAVING Captures > 0
        ' GROUP BY DateEx
        ' Report Season, YearEx, DateEx
        
        ' qryMBO10YearProgramReport3DayMeanGraph_FirstLastCaptureDays_B
        ' -------------------------------------------------------------
        ' For each season x year, list the days where SongbirdNets > 0
        ' -------------------------------------------------------------
        ' tblDETDaily x tblPrograms
        '
        ' WHERE Season IN ("Spring", "Fall")
        ' WHERE Location = [argLocation]
        ' WHERE YearEx = BETWEEN [argYearFirst] AND [argYearLast]
        ' WHERE SongbirdNets > 0
        ' Report Season, YearEx, DateEx
        
        ' qryMBO10YearProgramReport3DayMeanGraph_FirstLastCaptureDays_C
        ' -------------------------------------------------------------
        ' Capture Days
        ' -------------------------------------------------------------
        ' qryMBO10YearProgramReport3DayMeanGraph_FirstLastCaptureDays_A UNION qryMBO10YearProgramReport3DayMeanGraph_FirstLastCaptureDays_B
        '
        ' Report Season, YearEx, DateEx
        
        ' qryMBO10YearProgramReport3DayMeanGraph_FirstLastCaptureDays
        ' -----------------------------------------------------------
        ' First and last capture days for each year
        ' -----------------------------------------------------------
        ' qryMBO10YearProgramReport3DayMeanGraph_FirstLastCaptureDays_C
        '
        ' GROUP BY Season
        ' GROUP BY YearEx
        ' FirstCaptureDate = MIN DateEx
        ' LastCaptureDate = MAX DateEx
        '
        ' Returns a record for each season x year that had at least one capture day
        ' Returns Season, YearEx, FirstCaptureDay, LastCaptureDate
        
          Dim strSeason_local As String
          ' Dim intYear As Integer
          Dim datDate As Date
          Dim datDay As Date
          ' Dim intSeason As Integer
          Dim qdf As DAO.QueryDef
          Dim rst As DAO.Recordset

        
190       Set qdf = CurrentDb.QueryDefs("qryMBO10YearProgramReport3DayMeanGraph_FirstLastCaptureDays")
200       qdf.Parameters("argYearFirst").value = intYearFirst
210       qdf.Parameters("argYearLast").value = intYearLast
230       qdf.Parameters("argLocation").value = strLocation
          
240       Set rst = qdf.OpenRecordset
          
250       Do While Not rst.EOF
260           strSeason_local = Nz(rst("Season"))
270           intYear = Nz(rst("YearEx"))
              
280           datDate = Nz(rst("FirstCaptureDate"))
290           datDay = DateSerial(2000, Month(datDate), Day(datDate))
300           If strSeason_local = "Spring" Then
310               intSeason = conSpring
320           Else
330               intSeason = conFall
340           End If
350           datDayFirstTable(conBND, intSeason, intYear) = datDay
              
360           datDate = Nz(rst("LastCaptureDate"))
370           datDay = DateSerial(2000, Month(datDate), Day(datDate))
380           If strSeason_local = "Spring" Then
390               intSeason = conSpring
400           Else
410               intSeason = conFall
420           End If
430           datDayLastTable(conBND, intSeason, intYear) = datDay
              
440           rst.MoveNext
450       Loop
460       rst.Close
470       Set rst = Nothing
        
480   Case "Census Species", "DET SPecies"

490       Select Case strChart
              Case "Census Species"
500               Set qdf = CurrentDb.QueryDefs("qryMBO10YearProgramReport3DayMeanGraph_FirstLastCensusDays")
510               intStat = conCNS
520           Case "DET Species"
530               Set qdf = CurrentDb.QueryDefs("qryMBO10YearProgramReport3DayMeanGraph_FirstLastDETDays")
540               intStat = conDET
550       End Select
          
          ' qryMBO10YearProgramReport3DayMeanGraph_FirstLastCensusDays
          ' ----------------------------------------------------------------
          ' For each season x year determine the first and last census dates
          '
          ' tblDETSpecies x tblPrograms
          '
          ' WHERE YearEx BETWEEN [argYearFirst] AND [argYearLast]
          ' WHERE Season IN ("Spring", "Fall")
          ' WHERE Location = [argLocation]
          ' WHERE Census > 0
          ' DateFirst = MIN DateEx
          ' DateLast = MAX DateEx
          '
          ' Report: Season, YearEx, DateFirst, DateLast

          ' qryMBO10YearProgramReport3DayMeanGraph_FirstLastDETDays
          ' --------------------------------------------------------
          ' The same as qryMBO10YearProgramReport3DayMeanGraph_FirstLastCensusDays, but for DET instead of Census
              
560       qdf.Parameters("argYearFirst").value = intYearFirst
570       qdf.Parameters("argYearLast").value = intYearLast
580       qdf.Parameters("argLocation").value = strLocation
          
590       Set rst = qdf.OpenRecordset
          
600       Do While Not rst.EOF
610           strSeason_local = Nz(rst("Season"))
620           If strSeason_local = "Spring" Then
630               intSeason = conSpring
640           Else
650               intSeason = conFall
660           End If
670           intYear = Nz(rst("YearEx"))
680           datDate = Nz(rst("DateFirst"))
690           datDay = DateSerial(2000, Month(datDate), Day(datDate))
700           datDayFirstTable(intStat, intSeason, intYear) = datDay
              
710           datDate = Nz(rst("DateLast"))
720           datDay = DateSerial(2000, Month(datDate), Day(datDate))
730           datDayLastTable(intStat, intSeason, intYear) = datDay
740           rst.MoveNext
750       Loop
760       rst.Close
770       Set rst = Nothing

780   End Select

      ' For each season x stat, compute the first and last days over all years

      Dim datMinDay As Date
      Dim datMaxDay As Date

790   For intStat = conBND To conDET
800       For intSeason = conSpring To conFall
810           datMinDay = DateSerial(2001, 1, 1)
820           datMaxDay = DateSerial(1999, 12, 31)
830           For intYear = intYearFirst To intYearLast
840               If datDayFirstTable(intStat, intSeason, intYear) < datMinDay Then
850                   datMinDay = datDayFirstTable(intStat, intSeason, intYear)
860               End If
870               If datDayLastTable(intStat, intSeason, intYear) > datMaxDay Then
880                   datMaxDay = datDayLastTable(intStat, intSeason, intYear)
890               End If
900           Next
910           datDayFirstTable(intStat, intSeason, intYearLast + 1) = datMinDay
920           datDayFirst(intStat, intSeason) = datMinDay
930           datDayLastTable(intStat, intSeason, intYearLast + 1) = datMaxDay
940           datDayLast(intStat, intSeason) = datMaxDay
950       Next
960   Next

      ' For each season compute first and last days over all seasons and all stats (BND, CNS, DET)
      ' These days will be used as the first and days on the x-axis for all 4 graphs for each season

970   For intSeason = conSpring To conFall
980       datMinDay = DateSerial(2001, 1, 1)
990       datMaxDay = DateSerial(1999, 12, 31)
1000      For intStat = conBND To conDET
1010          If datDayFirst(intStat, intSeason) < datMinDay Then
1020              datMinDay = datDayFirst(intStat, intSeason)
1030          End If
1040          If datDayLast(intStat, intSeason) > datMaxDay Then
1050              datMaxDay = datDayLast(intStat, intSeason)
1060          End If
1070       Next
1080       datDayFirstANY(intSeason) = datMinDay
1090       datDayLastANY(intSeason) = datMaxDay
1100  Next


    'DD Error Handler Start
Exit_label:
    Exit Sub
Err_label:
    Select Case Err.Number
    Case Else
         Call LogError("basMBO10YearProgramReport3DayMeanGraph", "Load_datDayFirst_Last")
    End Select
    Resume Exit_label
    ' DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' BirdsBanded
'---------------------------------------------------------------------------------------
 
Private Sub BandedBirds()

10    On Error GoTo Err_label

      Dim qdf As QueryDef
      Dim rst As DAO.Recordset
      Dim datDate As Date
      Dim datDay As Date
      Dim intYear As Integer

20    ReDim dblStat(datDayFirst(conBND, m_intSeason) To datDayLast(conBND, m_intSeason), intYearFirst To intYearLast + 1)

      Dim D As Long
      Dim Y As Integer
30    For D = datDayFirst(conBND, m_intSeason) To datDayLast(conBND, m_intSeason)
40        For Y = intYearFirst To intYearLast + 1
50            dblStat(D, Y) = -1                            ' -1 for non capture days
                                                            ' 0 means a capture day with 0 birds banded
60        Next
70    Next

      ' Set dblStat( day, year ) to 0 for all capture days

      ' qryMBO10YearProgramReport3DayMeanGraph_CaptureDays_A
      ' -------------------------------------------------------------------
      ' For a given season, for each year, list the days with some captures
      ' -------------------------------------------------------------------
      ' tblDETSpecies x tblPrograms
      '
      ' WHERE Season = [argSeason]
      ' WHERE Location = [argLocation]
      ' WHERE YearEx = BETWEEN [argYearFirst] AND [argYearLast]
      ' HAVING Captures: Sum(Nz([Banded])+Nz([Returns])+Nz([Repeats])+Nz([Observed3])+Nz([Observed4])) > 0
      ' GROUP BY DateEx
      ' Report YearEx, DateEx

      ' qryMBO10YearProgramReport3DayMeanGraph_CaptureDays_B
      ' -----------------------------------------------------------------------
      ' For a given season, for each year, list the days where SongbirdNets > 0
      ' -----------------------------------------------------------------------
      ' tblDETDaily x tblPrograms
      '
      ' WHERE Season = [argSeason]
      ' WHERE Location = [argLocation]
      ' WHERE YearEx = BETWEEN [argYearFirst] AND [argYearLast]
      ' WHERE SongbirdNets > 0
      ' Report YearEx, DateEx

      ' qryMBO10YearProgramReport3DayMeanGraph_CaptureDays_C
      ' ---------------------------------------------------
      ' Capture Days
      ' ---------------------------------------------------
      ' qryMBO10YearProgramReport3DayMeanGraph_CaptureDays_A UNION qryMBO10YearProgramReport3DayMeanGraph_CaptureDays_B
      '
      ' Report YearEx, DateEx

      Dim intYearEx As Integer
      Dim datDateEx As Date
        
80    Set qdf = CurrentDb.QueryDefs("qryMBO10YearProgramReport3DayMeanGraph_CaptureDays_C")
90    qdf.Parameters("argSeason").value = strSeason
100   qdf.Parameters("argLocation").value = strLocation
110   qdf.Parameters("argYearFirst").value = intYearFirst
120   qdf.Parameters("argYearLast").value = intYearLast

130   Set rst = qdf.OpenRecordset

140   Do While Not rst.EOF
150       intYearEx = Nz(rst("YearEx"))
160       datDateEx = Nz(rst("DateEx"))
170       dblStat(DateSerial(2000, Month(datDateEx), Day(datDateEx)), intYearEx) = 0
180       rst.MoveNext
190   Loop
200   rst.Close
210   Set rst = Nothing


      ' Fill in dblStat(day) with the number of birds banded each day

      ' qryMBOAnnualProgramReport7DayMeanGraph_BandedBirds
      ' --------------------------------------------------
      ' tblDETSpecies x tblPrograms
      '
      ' WHERE YearEx BETWEEN [argYearFirst]and [argYearLast]      Report year
      ' WHERE Location = [argLocation]          MBO
      ' WHERE Season = [argSeason]              Spring or Fall
      ' WHERE Banded > 0
      ' GROUP BY DateEx
      ' CountBandedBirds = SUM Banded           we are summing over species
      ' HAVING CountBandedBirds > 0
      '
      ' Report DateEx, CountBandedBirds
      ' Given the season, there is a record for every day in each year, for which banding of any species > 0

220   Set qdf = CurrentDb.QueryDefs("qryMBO10YearProgramReport3DayMeanGraph_BandedBirds")
230   qdf.Parameters("argSeason").value = strSeason
240   qdf.Parameters("argLocation").value = strLocation
250   qdf.Parameters("argYearFirst").value = intYearFirst
260   qdf.Parameters("argYearLast").value = intYearLast

270   Set rst = qdf.OpenRecordset

      Dim CountBandedBirds As Integer

280   Do While Not rst.EOF
290       intYear = Nz(rst("YearEx"))
300       CountBandedBirds = Nz(rst("CountBandedBirds"))
310       datDate = Nz(rst("DateEx"))
320       datDay = DateSerial(2000, Month(datDate), Day(datDate))
330       dblStat(datDay, intYear) = CountBandedBirds
340       rst.MoveNext
350   Loop
360   rst.Close
370   Set rst = Nothing

      ' Quit if there is no data to plot

380   If datDayFirst(conBND, m_intSeason) = DateSerial(2001, 1, 1) Then GoTo Exit_label

      ' Compute stat averaged over years

390   Call MeanPerDayOverYears


      ' Output to Excel

400   ' oExcel.Visible = True

      Dim oSheet As Excel.Worksheet
410   Set oSheet = InsertSheet(oBook, strSeason)
420   oSheet.Name = strSeason & " 3 Day Mean Banded Birds"
430   With oSheet

      ' Write dates to column 1

440   For D = datDayFirst(conBND, m_intSeason) To datDayLast(conBND, m_intSeason)
450       .Cells(toRowFromDay(D), 1) = D
460   Next

      ' Write year headings to row 1

470   For Y = intYearFirst To intYearLast
480       .Cells(1, toColFromYear(Y)) = Y
490   Next

500   .Cells(1, toColFromYear(intYearLast) + 1) = "Average"

      ' Write the BND data
      ' -1 == not a capture day, do not write anything
      ' 0 == capture day, no birds banded
      ' > 0 == number of birds banded

510   For Y = intYearFirst To intYearLast
520       For D = datDayFirstTable(conBND, m_intSeason, Y) To datDayLastTable(conBND, m_intSeason, Y)
530           If dblStat(D, Y) >= 0 Then
540             .Cells(toRowFromDay(D), toColFromYear(Y)) = dblStat(D, Y)
550           End If
560       Next
570   Next

580   Call MeanPerDayOverYearsToExcel(oSheet)


      ' Format

590   .range(.Cells(1, 2), .Cells(2 + datDayLast(conBND, m_intSeason) - datDayFirst(conBND, m_intSeason), 2 + intYearLast - intYearFirst)).NumberFormat = "#0;-#0;0"
600   .range(.Cells(2, 2 + datDayLast(conBND, m_intSeason) - datDayFirst(conBND, m_intSeason) + 1), .Cells(2 + datDayLast(conBND, m_intSeason) - datDayFirst(conBND, m_intSeason), _
              2 + datDayLast(conBND, m_intSeason) - datDayFirst(conBND, m_intSeason) + 1)).NumberFormat = "#0.0;-#0.0;0"
610   .range(.Cells(2, 1), .Cells(2 + datDayLast(conBND, m_intSeason) - datDayFirst(conBND, m_intSeason), 1)).NumberFormat = "[$-1009]dd-mmm"

620   Call Means(oSheet)


630   Call Generate_Chart(oSheet)

    


640   End With ' oSheet

650   Set oSheet = Nothing

      Dim lngStart As Long
660   lngStart = doc.range.End

      'DD Error Handler Start
Exit_label:
670        Exit Sub
Err_label:
680        Select Case Err.Number
           Case Else
690       Call LogError("basMBO10YearProgramReport3DayMeanGraph", "BandedBirds")
700        End Select
710        Resume Exit_label
      'DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' Species
'---------------------------------------------------------------------------------------
 
Private Sub Species(ByVal intStat As Integer)                 ' intStat = conBND, cnCNS, conDET

      Dim qdf As QueryDef
      Dim rst As DAO.Recordset
      Dim strSQL As String

10    On Error GoTo Err_label

      '      Dim datDate As Date
      '      Dim datDay As Date
      Dim intYear As Integer
      Dim Y As Integer
      Dim D As Date


270   ReDim dblStat(datDayFirst(intStat, m_intSeason) To datDayLast(intStat, m_intSeason), intYearFirst To intYearLast + 1)

280   For D = datDayFirst(intStat, m_intSeason) To datDayLast(intStat, m_intSeason)
290       For Y = intYearFirst To intYearLast + 1
300           dblStat(D, Y) = -1
310       Next
320   Next

      ' For BND, set dblStat( day, year ) to 0 for all capture days
          
330   If intStat = conBND Then

          ' qryMBO10YearProgramReport3DayMeanGraph_CaptureDays_A
          ' ---------------------------------------------------
          ' For a given season, for each year, list the days with some captures
          ' -------------------------------------------------
          ' tblDETSpecies x tblPrograms
          '
          ' WHERE Season = [argSeason]
          ' WHERE Location = [argLocation]
          ' WHERE YearEx = BETWEEN [argYearFirst] AND [argYearLast]
          ' HAVING Captures: Sum(Nz([Banded])+Nz([Returns])+Nz([Repeats])+Nz([Observed3])+Nz([Observed4])) > 0
          ' GROUP BY DateEx
          ' Report YearEx, DateEx
          
          ' qryMBO10YearProgramReport3DayMeanGraph_CaptureDays_B
          ' ---------------------------------------------------
          ' For a given season, for each year, list the days where SongbirdNets > 0
          ' ----------------------------------------------------------
          ' tblDETDaily x tblPrograms
          '
          ' WHERE Season = [argSeason]
          ' WHERE Location = [argLocation]
          ' WHERE YearEx = BETWEEN [argYearFirst] AND [argYearLast]
          ' WHERE SongbirdNets > 0
          ' Report YearEx, DateEx
          
          ' qryMBO10YearProgramReport3DayMeanGraph_CaptureDays_C
          ' ---------------------------------------------------
          ' Capture Days
          ' ----------------------------------------
          ' qryMBO10YearProgramReport3DayMeanGraph_CaptureDays_A UNION qryMBO10YearProgramReport3DayMeanGraph_CaptureDays_B
          '
          ' Report YearEx, DateEx
              
              Dim intYearEx As Integer
              Dim datDateEx As Date
                
340           Set qdf = CurrentDb.QueryDefs("qryMBO10YearProgramReport3DayMeanGraph_CaptureDays_C")
350           qdf.Parameters("argSeason").value = strSeason
360           qdf.Parameters("argLocation").value = strLocation
370           qdf.Parameters("argYearFirst").value = intYearFirst
380           qdf.Parameters("argYearLast").value = intYearLast
              
390           Set rst = qdf.OpenRecordset
              
400           Do While Not rst.EOF
410               intYearEx = Nz(rst("YearEx"))
420               datDateEx = Nz(rst("DateEx"))
430               dblStat(DateSerial(2000, Month(datDateEx), Day(datDateEx)), intYearEx) = 0
440               rst.MoveNext
450           Loop
460           rst.Close
470           Set rst = Nothing

480   End If

      ' Calculate the number of true species for each day x year

      Dim dicSpecies As Scripting.Dictionary
490   Set dicSpecies = New Scripting.Dictionary
      Dim strSpecies As String

500   For Y = intYearFirst To intYearLast
510       For D = datDayFirstTable(intStat, m_intSeason, Y) To datDayLastTable(intStat, m_intSeason, Y)

520           Select Case intStat
              Case conCNS
530               strSQL = "qryMBO10YearProgramReport3DayMeanGraph_CensusSpecies"
540           Case conDET
550               strSQL = "qryMBO10YearProgramReport3DayMeanGraph_DETSpecies"
560           Case conBND
570               strSQL = "qryMBO10YearProgramReport3DayMeanGraph_BandedSpecies"
580           End Select
          
590           Set qdf = CurrentDb.QueryDefs(strSQL)
600           qdf.Parameters("argSeason").value = strSeason
610           qdf.Parameters("argLocation").value = strLocation
620           qdf.Parameters("argDateEx").value = DateSerial(Y, Month(D), Day(D))
              
630           Set rst = qdf.OpenRecordset
              
              ' Skip if the stat was not measured
          
640           If Not rst.EOF Then
650               Do While Not rst.EOF
660                   strSpecies = Nz(rst("Species"))
                       
                      ' Add the species + superspecies to the dictionary
                  
670                   If Not dicSpecies.Exists(strSpecies) Then
680                       Call dicSpecies.Add(strSpecies, strSpecies)
690                   End If
700                   rst.MoveNext
710               Loop
720               rst.Close
730               Set rst = Nothing
                  
                  ' How many true species are in the dictionary ?
                  
740               dblStat(D, Y) = CountSpeciesInDictionary(dicSpecies)
                       
                  ' Empty the dictionary
                  
750               Call dicSpecies.RemoveAll
760           End If
770       Next D
780   Next Y

790   Call MeanPerDayOverYears

      Dim oSheet As Excel.Worksheet
800   Set oSheet = InsertSheet(oBook, strSeason)
810   oSheet.Name = strSeason & toSheetname_FromFLD(intStat)
820   With oSheet

      ' Output to Excel

830   For D = datDayFirst(intStat, m_intSeason) To datDayLast(intStat, m_intSeason)
840       .Cells(toRowFromDay(D), 1) = D
850   Next

860   For Y = intYearFirst To intYearLast
870       .Cells(1, toColFromYear(Y)) = Y
880   Next

890   .Cells(1, toColFromYear(intYearLast) + 1) = "Average"

900   For Y = intYearFirst To intYearLast
910       For D = datDayFirstTable(intStat, m_intSeason, Y) To datDayLastTable(intStat, m_intSeason, Y)
920     If dblStat(D, Y) >= 0 Then
930         .Cells(toRowFromDay(D), toColFromYear(Y)) = dblStat(D, Y)
940     End If
950       Next
960   Next

970   Call MeanPerDayOverYearsToExcel(oSheet)

980   .range(.Cells(1, 2), .Cells(2 + datDayLast(intStat, m_intSeason) - datDayFirst(intStat, m_intSeason), 2 + intYearLast - intYearFirst)).NumberFormat = "#0;-#0;0"
990   .range(.Cells(2, 2 + datDayLast(intStat, m_intSeason) - datDayFirst(intStat, m_intSeason) + 1), .Cells(2 + datDayLast(intStat, m_intSeason) - datDayFirst(intStat, m_intSeason), _
          2 + datDayLast(intStat, m_intSeason) - datDayFirst(intStat, m_intSeason) + 1)).NumberFormat = "#0.0;-#0.0;0"
1000  .range(.Cells(2, 1), .Cells(2 + datDayLast(intStat, m_intSeason) - datDayFirst(intStat, m_intSeason), 1)).NumberFormat = "[$-1009]dd-mmm" ' English Canada


1010  Call Means(oSheet)

      ' Generate a chart

1020  Call Generate_Chart(oSheet)



1030  End With ' oSheet

1040  Set oSheet = Nothing

      'DD Error Handler Start
Exit_label:
1050       Exit Sub
Err_label:
1060       Select Case Err.Number
           Case Else
1070      Call LogError("basMBO10YearProgramReport3DayMeanGraph", "Species")
1080       End Select
1090       Resume Exit_label
      'DD Error Handler End

End Sub


'---------------------------------------------------------------------------------------
' Generate_Chart
'---------------------------------------------------------------------------------------

Private Sub Generate_Chart(ByRef oSheet As Excel.Worksheet)
          

      Dim oChart As Excel.Chart
      Dim ser As Excel.series

10       On Error GoTo Err_label

20    Set oChart = oSheet.Shapes.AddChart.Chart

30    With oChart
40        .ChartType = xlXYScatterLinesNoMarkers

          Dim rowDayFirst As Long
          Dim rowDayLast As Long
          Dim colYear As Integer
          Dim intYear As Integer
          
           
          ' There is at least one year with data
          ' intYearFirstWithData = the first year with data
          
          Dim intFirstYearWithData As Integer
50        For intYear = intYearFirst To intYearLast
60            If datDayFirstTable(m_intStat, m_intSeason, intYear) <> DateSerial(2001, 1, 1) Then
70                intFirstYearWithData = intYear
80                Exit For
90            End If
100       Next
              

110       rowDayFirst = toRowFromDay(datDayFirstTable(m_intStat, m_intSeason, intFirstYearWithData) + 1)
120       rowDayLast = toRowFromDay(datDayLastTable(m_intStat, m_intSeason, intFirstYearWithData) - 1)
130       colYear = toColMeanFromYear(intFirstYearWithData)

140       .SetSourceData Source:=oSheet.range(oSheet.Cells(rowDayFirst, colYear), oSheet.Cells(rowDayLast, colYear))

150       Set ser = .SeriesCollection(1)

160       ser.Name = "=""" & intFirstYearWithData & """"
170       ser.XValues = _
               oSheet.range(oSheet.Cells(rowDayFirst, 1), oSheet.Cells(rowDayLast, 1))
180       ser.Format.Line.Weight = 1.5

190       .Axes(xlCategory, xlPrimary).TickLabels.Orientation = 90
200       .Axes(xlCategory, xlPrimary).TickLabels.NumberFormat = "[$-1009]dd-mmm"

210       .HasTitle = False
220       .HasLegend = True
230       .Legend.Position = xlLegendPositionRight

240       .Axes(xlCategory, xlPrimary).HasTitle = False
'250       .Axes(xlCategory, xlPrimary).AxisTitle.Characters.Text = "Date (first day of each week shown)"
'260       .Axes(xlCategory, xlPrimary).AxisTitle.Top = 190

270       .Axes(xlValue, xlPrimary).HasTitle = True
280       .Axes(xlValue, xlPrimary).AxisTitle.Characters.Text = toYAxisTitle_FromFLD(m_intStat)

290       For intYear = intFirstYearWithData + 1 To intYearLast
          
              ' Skip years with no data
              
300           If datDayFirstTable(m_intStat, m_intSeason, intYear) <> DateSerial(2001, 1, 1) Then
          
310                 rowDayFirst = toRowFromDay(datDayFirstTable(m_intStat, m_intSeason, intYear) + 1)
320                 rowDayLast = toRowFromDay(datDayLastTable(m_intStat, m_intSeason, intYear) - 1)
330                 colYear = toColMeanFromYear(intYear)
                  
340                 Set ser = .SeriesCollection.NewSeries
350                 ser.Name = "=""" & intYear & """"
360                 ser.XValues = _
                          oSheet.range(oSheet.Cells(rowDayFirst, 1), oSheet.Cells(rowDayLast, 1))
370                 ser.Values = _
                          oSheet.range(oSheet.Cells(rowDayFirst, colYear), oSheet.Cells(rowDayLast, colYear))
380                 ser.Format.Line.Weight = 1.5
390           End If
              
400       Next

410       rowDayFirst = toRowFromDay(datDayFirst(m_intStat, m_intSeason) + 1)
420       rowDayLast = toRowFromDay(datDayLast(m_intStat, m_intSeason) - 1)
430       colYear = toColMeanFromYear(intYearLast + 1)


440       Set ser = .SeriesCollection.NewSeries
450       ser.Name = "=""" & "Mean" & """"
460       ser.XValues = _
              oSheet.range(oSheet.Cells(rowDayFirst, 1), oSheet.Cells(rowDayLast, 1))
470       ser.Values = _
              oSheet.range(oSheet.Cells(rowDayFirst, colYear), oSheet.Cells(rowDayLast, colYear))
480       ser.Format.Line.Visible = msoFalse
490       ser.Format.Line.Visible = msoTrue
500       ser.Format.Line.Weight = 3
510       ser.Format.Line.ForeColor.RGB = RGB(0, 0, 0)


520       oSheet.Shapes(1).Width = 500
530       oSheet.Shapes(1).Height = 220

540       oChart.Axes(xlCategory, xlPrimary).MajorUnit = 7
550       oChart.Axes(xlCategory, xlPrimary).MinimumScale = datDayFirstANY(m_intSeason)
560       oChart.Axes(xlCategory, xlPrimary).MaximumScale = datDayLastANY(m_intSeason)
570       oChart.ChartArea.Border.LineStyle = xlNone

580       .PlotArea.Height = 170

590   End With ' oChart

600   Set oChart = Nothing

      '600   End With ' oSheet
      '
      '610   Set oSheet = Nothing

          'DD Error Handler Start
Exit_label:
610       Exit Sub
Err_label:
620       Select Case Err.Number
          Case Else
630      Call LogError("basMBO10YearProgramReport3DayMeanGraph", "Generate_Chart")
640       End Select
650       Resume Exit_label
          ' DD Error Handler End

End Sub


'---------------------------------------------------------------------------------------
' toColMeanFromYear
'---------------------------------------------------------------------------------------

Private Function toColMeanFromYear(ByVal intYear As Integer) As Integer
10       On Error GoTo Err_label

20        toColMeanFromYear = 4 + (intYearLast - intYearFirst) + intYear - intYearFirst

    'DD Error Handler Start
Exit_label:
30        Exit Function
Err_label:
40        Select Case Err.Number
    Case Else
50       Call LogError("basMBO10YearProgramReport3DayMeanGraph", "toColMeanFromYear")
60        End Select
70        Resume Exit_label
    ' DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' toRowFromDay
'---------------------------------------------------------------------------------------

Private Function toRowFromDay(ByVal datDay As Date) As Integer
10       On Error GoTo Err_label

20        toRowFromDay = 2 + datDay - datDayFirst(m_intStat, m_intSeason)

    'DD Error Handler Start
Exit_label:
30        Exit Function
Err_label:
40        Select Case Err.Number
    Case Else
50       Call LogError("basMBO10YearProgramReport3DayMeanGraph", "toRowFromDay")
60        End Select
70        Resume Exit_label
    ' DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' toColFromYear
'---------------------------------------------------------------------------------------

Private Function toColFromYear(ByVal intYear As Integer) As Integer
10       On Error GoTo Err_label

20        toColFromYear = 2 + intYear - intYearFirst

    'DD Error Handler Start
Exit_label:
30        Exit Function
Err_label:
40        Select Case Err.Number
    Case Else
50       Call LogError("basMBO10YearProgramReport3DayMeanGraph", "toColFromYear")
60        End Select
70        Resume Exit_label
    ' DD Error Handler End
End Function

Private Function toSheetname_FromFLD(ByVal intStat As Integer) As String
10    Select Case intStat
      Case conCNS
20        toSheetname_FromFLD = " Mean CNS Sp"
30    Case conDET
40        toSheetname_FromFLD = " Mean DET Sp"
50    Case conBND
60        toSheetname_FromFLD = " Mean BND Sp"
70    End Select
End Function

Private Function toYAxisTitle_FromFLD(ByVal intStat As Integer) As String
10    Select Case intStat
      Case conCNS
20        toYAxisTitle_FromFLD = "# species observed daily on census"
30    Case conDET
40        toYAxisTitle_FromFLD = "# species observed daily"
50    Case conBND
60        toYAxisTitle_FromFLD = "# species banded daily"
70    End Select
End Function

'---------------------------------------------------------------------------------------
' Means
'---------------------------------------------------------------------------------------
' Calculate the means
'
' The 5x-year reports use 3-day means

Private Sub Means(ByRef oSheet As Excel.Worksheet)

10       On Error GoTo Err_label

         Dim lngCount As Long
         Dim dblSum As Double
         Dim dblValue As Double
         Dim Y As Integer
         Dim D As Date

20    With oSheet

      Dim intOffset As Integer

30    intOffset = 3

40    For Y = intYearFirst To intYearLast + 1
50        For D = datDayFirstTable(m_intStat, m_intSeason, Y) + 1 To datDayLastTable(m_intStat, m_intSeason, Y) - 1
60        lngCount = 0
70        dblSum = 0
80        For intOffset = -1 To 1
90            dblValue = dblStat(D + intOffset, Y)
100           If dblValue >= 0 Then
110               lngCount = lngCount + 1
120               dblSum = dblSum + dblValue
130           End If
140       Next
150       If lngCount > 0 Then
160           .Cells(toRowFromDay(D), toColMeanFromYear(Y)) = dblSum / lngCount
170       End If
180   Next
190   Next

' Write year headings above the 3-day runnimg means columns

200   For Y = intYearFirst To intYearLast
210       .Cells(1, toColMeanFromYear(Y)) = Y
220   Next

230   .Cells(1, toColMeanFromYear(intYearLast + 1)) = "Average"
          
240   End With

          'DD Error Handler Start
Exit_label:
250       Exit Sub
Err_label:
260       Select Case Err.Number
          Case Else
270      Call LogError("basMBOProgramReport_MeanGraphs", "Means")
280       End Select
290       Resume Exit_label
          ' DD Error Handler End
End Sub


'---------------------------------------------------------------------------------------
' MeanPerDayOverYears
'---------------------------------------------------------------------------------------
' For each day, calculate the mean from intYearFirst to intYearLast of dblStat(datDay, intYear)
' Store the mean in dbStat(datDay, intYearLast+1)
'
' PRE: dbStat(datDay, intYearLast+1) = -1 for every datDay between datDayFirst(m_intStat, m_intSeason) and datDayLast(m_intStat, m_intSeason)

Private Sub MeanPerDayOverYears()

10       On Error GoTo Err_label
         
        Dim intCount As Integer
        Dim dblSum As Double
        Dim intYear As Integer
        Dim dblValue As Double
        
        Dim datDay As Date
          
20        intCount = 0
30        dblSum = 0
40        For datDay = datDayFirst(m_intStat, m_intSeason) To datDayLast(m_intStat, m_intSeason)
50            intCount = 0
60            dblSum = 0
70            For intYear = intYearFirst To intYearLast
80                dblValue = dblStat(datDay, intYear)
90                If dblValue >= 0 Then
100                   intCount = intCount + 1
110                   dblSum = dblSum + dblValue
120               End If
130           Next
140           If intCount > 0 Then
150               dblStat(datDay, intYearLast + 1) = dblSum / intCount
180           End If
190       Next

          

          'DD Error Handler Start
Exit_label:
200       Exit Sub
Err_label:
210       Select Case Err.Number
          Case Else
220            Call LogError("basMBO10YearProgramReport3DayMeanGraph", "MeanPerDayOverYears")
230       End Select
240       Resume Exit_label
          ' DD Error Handler End
End Sub




'---------------------------------------------------------------------------------------
' MeanPerDayOverYearsToExcel
'---------------------------------------------------------------------------------------
' The per day means over years are stored in dblStat(datDay,intYearLast + 1)
' They are exported to column toColFromYear(intYearLast + 1)
' -1 values are not exported

Private Sub MeanPerDayOverYearsToExcel(ByRef oSheet As Excel.Worksheet)

10    On Error GoTo Err_label

      Dim datDay As Date
      Dim intYear As Integer
      Dim dblValue As Double


20    For datDay = datDayFirst(m_intStat, m_intSeason) To datDayLast(m_intStat, m_intSeason)
30       dblValue = dblStat(datDay, intYearLast + 1)
40       If dblValue > 0 Then ' skip -1 values
50           oSheet.Cells(toRowFromDay(datDay), toColFromYear(intYearLast + 1)) = dblValue
60       End If

70    Next
          
          

          'DD Error Handler Start
Exit_label:
80        Exit Sub
Err_label:
90        Select Case Err.Number
          Case Else
100            Call LogError("basMBO10YearProgramReport3DayMeanGraph", "MeanPerDayOverYearsToExcel")
110       End Select
120       Resume Exit_label
          ' DD Error Handler End
End Sub
