'---------------------------------------------------------------------------------------
' Module: basChecklist
' Author: David Davey
'---------------------------------------------------------------------------------------

Option Compare Database
Option Explicit

'---------------------------------------------------------------------------------------
' ExportChecklist_Formatted
'
' intFormat
' 0 = unformated table tbody tr th
' 1 = formatted as on web site
' 2 = unformatted table tbody tr td/th
'---------------------------------------------------------------------------------------

Public Sub ExportChecklist(ByVal intFormat As Long)

10    On Error GoTo Err_label

      '     I now always list the species in AOU order

      Dim qdf As QueryDef

      ' tblMBOChecklist          - a temporary table
      ' ---------------
      ' Species
      ' SpeciesEnglish
      ' SpeciesFrench
      ' SpeciesScientific
      ' SpeciesDescriptionMBOPrefix
      ' AOUOrder                        Double

      ' Zap tblMBOChecklist

      Dim strSQL As String
20    strSQL = "DELETE * FROM tblMBOChecklist"
30    CurrentDb.Execute strSQL


      ' qryMBOChecklist_SpeciesAtMBO_DET
      ' --------------------------------
      ' Soecies that have been DET'ed at the MBO site
      ' -------------------------------
      ' tblDETSpecies
      ' WHERE Location = "MBO"
      ' GROUP BY Species

      ' qryMBOChecklist_SpeciesAtMBO_Capture
      ' --------------------------------
      ' Soecies that have been DET'ed at the MBO site
      ' -------------------------------
      ' tblCaptures
      ' WHERE Location = "MBO"
      ' GROUP BY Species

      ' qryMBOChecklist_SpeciesAtMBO
      ' ----------------------------
      ' qryMBOChecklist_SpeciesAtMBO_DET
      ' UNION
      ' qryMBOChecklist_SpeciesAtMBO_Capture

      ' qryMBOChecklist_append
      ' ------------------------------------------
      ' tblSpecies x tblSpeciesGroups_MBOChecklist
      '
      ' append to tblMBOChecklist
      '
      ' Species
      ' SpeciesEnglish: IIf(Nz([SpeciesEnglish])="",[SpeciesDescriptionMBO],[SpeciesEnglish])
      ' SpeciesFrench: IIf(Nz([SpeciesFrenchEx])="",[SpeciesFrench],[SpeciesFrenchEx])
      ' SpeciesScientific: IIf(Nz([SpeciesScientificEx])="",[SpeciesScientific],[SpeciesScientificEx])
      ' SpeciesDescriptionMBOPrefix
      ' SpeciesGroupsMBOChecklist
      ' AOUOrder
      ' ORDER BY AOUOrder

40    Set qdf = CurrentDb.QueryDefs("qryMBOChecklist_append")
50    qdf.Execute

      Const conUnformatted_td As Integer = 0
      Const conFormatted As Integer = 1
      Const conUnformatted_th As Integer = 2

      ' Create the UTF-8 stream

      Dim ts As ADODB.Stream
60    Set ts = New ADODB.Stream
70    ts.Charset = "utf-8"
80    ts.Open

      ' Generate the checklist

90    Select Case intFormat
      Case conFormatted
100       ts.WriteText "<table class=""table"" cellspacing=""0"" cellpadding=""0"">"
110   Case conUnformatted_td, conUnformatted_th
120       ts.WriteText "<table>"
130   End Select

140   ts.WriteText "<tbody>"

      Dim strSpeciesEnglish As String
      Dim strSpeciesFrench As String
      Dim strSpeciesScientific As String
      Dim strSpeciesDescriptionMBOPrefix As String
      Dim strSpeciesGroupsMBOChecklist As String
      Dim strSpeciesGroupsMBOChecklist_previous As String

150   strSpeciesGroupsMBOChecklist_previous = ""

      Dim dicSpeciesCategory As Scripting.Dictionary
160   Set dicSpeciesCategory = New Scripting.Dictionary

      Dim strDuplicateSpeciesCategory As String
170   strDuplicateSpeciesCategory = ""

      Dim cntSpecies As Integer

180   cntSpecies = 0
      Dim rst As DAO.Recordset
190   Set rst = CurrentDb.OpenRecordset("SELECT * FROM tblMBOChecklist ORDER BY  AOUOrder")
200   Do While Not rst.EOF
            
210       strSpeciesEnglish = Nz(rst("SpeciesEnglish"))
220       strSpeciesFrench = Nz(rst("SpeciesFrench"))
230       strSpeciesScientific = Nz(rst("SpeciesScientific"))
          
          ' Breeding prefix
          
240       strSpeciesDescriptionMBOPrefix = Nz(rst("SpeciesDescriptionMBOPrefix"))
250       If strSpeciesDescriptionMBOPrefix = "*" Or strSpeciesDescriptionMBOPrefix = "**" Then
260           strSpeciesEnglish = strSpeciesDescriptionMBOPrefix & strSpeciesEnglish
270       End If
          
          ' Group
              
280       strSpeciesGroupsMBOChecklist = Nz(rst("SpeciesGroupsMBOChecklist"))
290       If strSpeciesGroupsMBOChecklist <> "" Then
300           If strSpeciesGroupsMBOChecklist <> strSpeciesGroupsMBOChecklist_previous Then

                  ' H1
                  
310               If dicSpeciesCategory.Exists(strSpeciesGroupsMBOChecklist) Then
320                   strDuplicateSpeciesCategory = strDuplicateSpeciesCategory & strSpeciesGroupsMBOChecklist & vbCrLf
330               Else
340                   Call dicSpeciesCategory.Add(strSpeciesGroupsMBOChecklist, strSpeciesGroupsMBOChecklist)
350               End If
                  
                  
                 
360               ts.WriteText "<tr>"
                  
370               Select Case intFormat
                  Case conFormatted
380                   ts.WriteText "<td valign=""bottom"">"
390                   ts.WriteText "<span style=""color: #000000; font-family: Calibri; font-size: medium;""><b>" & strSpeciesGroupsMBOChecklist & "</b></span>"
400                   ts.WriteText "</td>"
410                   ts.WriteText "<td valign=""bottom"">"
420                   ts.WriteText "</td>"
430                   ts.WriteText "<td valign=""bottom"">"
440                   ts.WriteText "</td>"
450               Case conUnformatted_td
460                 ts.WriteText "<td valign=""bottom""><b>"
470                   ts.WriteText strSpeciesGroupsMBOChecklist
480                   ts.WriteText "</b></td>"
490                   ts.WriteText "<td>"
500                   ts.WriteText "</td>"
510                   ts.WriteText "<td>"
520                   ts.WriteText "</td>"
530               Case conUnformatted_th
540                 ts.WriteText "<th>"
550                   ts.WriteText strSpeciesGroupsMBOChecklist
560                   ts.WriteText "</th>"
570                   ts.WriteText "<th>"
580                   ts.WriteText "</th>"
590                   ts.WriteText "<th>"
600                   ts.WriteText "</th>"
610               End Select

620               ts.WriteText vbCrLf
                  
630               strSpeciesGroupsMBOChecklist_previous = strSpeciesGroupsMBOChecklist
                  
640           End If
650           cntSpecies = cntSpecies + 1
660           ts.WriteText "<tr>"
                     
670           Select Case intFormat
              Case conUnformatted_td, conUnformatted_th
680               ts.WriteText "<td valign=""bottom"">" & strSpeciesEnglish & "</td>"
690               ts.WriteText "<td valign=""bottom"">" & strSpeciesFrench & "</td>"
700               ts.WriteText "<td valign=""bottom"">" & strSpeciesScientific & "</td>"
710           Case conFormatted
720               ts.WriteText "<td valign=""bottom""><span style=""color: #000000; font-family: Calibri; font-size: medium;"">" & strSpeciesEnglish & "</span></td>"
730               ts.WriteText "<td valign=""bottom""><span style=""color: #000000; font-family: Calibri; font-size: medium;"">" & strSpeciesFrench & "</span></td>"
740               ts.WriteText "<td valign=""bottom""><span style=""color: #000000; font-family: Calibri; font-size: medium;"">" & strSpeciesScientific & "</span></td>"
750           End Select

760           ts.WriteText vbCrLf
          
770       End If
780       rst.MoveNext
790   Loop
800   rst.Close
810   Set rst = Nothing

820   ts.WriteText "</tbody>"
830   ts.WriteText "</table>"

840   If strDuplicateSpeciesCategory <> "" Then
850       strDuplicateSpeciesCategory = "The following species categories appear more than once" & vbCrLf & strDuplicateSpeciesCategory
860       MsgBox strDuplicateSpeciesCategory, vbOKOnly, "Banding Summary"
870   End If


      Dim strBaseFilename As String
      Dim strSaveFilepath As String

880   strBaseFilename = "MBO Checklist"
890   strSaveFilepath = ""


900   Select Case intFormat
      Case conUnformatted_td
910       Call CloseAndSaveHTMLDocument(strBaseFilename & " without inline styles ", strSaveFilepath, ts)
920   Case conUnformatted_th
930       Call CloseAndSaveHTMLDocument(strBaseFilename & " Unformatted th td ", strSaveFilepath, ts)
940   Case conFormatted
950       Call CloseAndSaveHTMLDocument(strBaseFilename & " Formatted with inline styles ", strSaveFilepath, ts)
960   End Select

970   Set ts = Nothing

      '      ' Are the species in AOS order?
      '
      '1030  If DCount("*", "qryMBOChecklistNotInAOSOrder") > 0 Then
      '1040      DoCmd.OpenForm "frmReportNotInAOSOrder"
      '1050      With Forms("frmReportNotInAOSOrder")
      '1060          .lblReport.Caption = "Checklist"
      '1070          .RecordSource = "qryMBOChecklistNotInAOSOrder"
      '1080          .Requery
      '1090      End With
      '1100  End If


          'DD Error Handler Start
Exit_label:
980       Exit Sub
Err_label:
990       Select Case Err.Number
          Case Else
1000     Call LogError("basChecklist", "ExportChecklist")
1010      End Select
1020      Resume Exit_label
          ' DD Error Handler End
End Sub
