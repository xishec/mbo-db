'---------------------------------------------------------------------------------------
' Module: basBandingSummary
' Author: David Davey
'---------------------------------------------------------------------------------------

Option Compare Database
Option Explicit


'---------------------------------------------------------------------------------------
'strSeasonTointSeasonBandingSummary
'
' Winter => 0. Spring, Spring2004, RTHU_Spring => 1. Summer, Nestbox => 2. Fall, Fall2004, RTHU_Fall, Owling => 3, Otherwise => -1
'---------------------------------------------------------------------------------------
' Called from qryBandingSummary

Public Function strSeasonTointSeasonBandingSummary(ByVal strSeason As String) As Integer

10    On Error GoTo Err_label

      Dim intSeason As Integer

20    Select Case strSeason
      Case "Winter"
30        intSeason = 0
40    Case "Spring", "Spring2004", "RTHU_Spring"
50        intSeason = 1
60    Case "Summer", "Nestbox"
70        intSeason = 2
80    Case "Fall", "Fall2004", "RTHU_Fall", "Owling"
90        intSeason = 3
120   Case Else
130       intSeason = -1
140   End Select
150   strSeasonTointSeasonBandingSummary = intSeason

    'DD Error Handler Start
Exit_label:
160       Exit Function
Err_label:
170       Select Case Err.Number
    Case Else
180      Call LogError("Module1", "strSeasonTointSeasonBandingSummary")
190       End Select
200       Resume Exit_label
    ' DD Error Handler End
End Function
