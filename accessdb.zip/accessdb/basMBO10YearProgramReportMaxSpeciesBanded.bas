Option Compare Database
Option Explicit

Const conNonSeason As Integer = -1
Const conWinter  As Integer = 0
Const conSpring  As Integer = 1
Const conSummer  As Integer = 2
Const conFall    As Integer = 3
Const conOwling  As Integer = 4
Const conNestbox As Integer = 5

'---------------------------------------------------------------------------------------
' MBO10YearProgramReportMaxSpeciesDET
'---------------------------------------------------------------------------------------
' For each program:
' The maximum number of species DET each day + the days on which those maximums occurred
'

Public Sub MBO10YearProgramReportMaxSpeciesDET( _
    ByVal intYearFirst As Integer, _
    ByVal intYearLast As Integer, _
    ByVal strLocation As String, _
    ByRef wd As Word.Application, _
    ByRef doc As Word.Document, _
    ByRef oExcel As Excel.Application, _
    ByRef oBook As Excel.Workbook, _
    ByVal fDebug As Boolean)
          
10    On Error GoTo Err_label
          
      Dim strSpecies As String
      Dim intSeason As Integer
      Dim strSeason As String
      Dim intYear As Integer
      Dim dic As Scripting.Dictionary
      Dim row As Long
      Dim rowmax As Long
      Dim colEnd As Long

      Dim oSheet As Excel.Worksheet
20    Set oSheet = InsertSheet(oBook, "Global")
30    oSheet.Name = "Species Diversity"

40    With oSheet
          
          
50    Set dic = New Scripting.Dictionary
60    row = 2
70    rowmax = 2
80    colEnd = 10

90    .Cells(1, 1) = "Season"
100   .Cells(1, 2) = "Year"
110   .Cells(1, 3) = "Date"
120   .Cells(1, 4) = "Count DET Species"
130   .Cells(1, 7) = "Season"
140   .Cells(1, 8) = "Year"
150   .Cells(1, 9) = "Max Count DET Species"
160   .Cells(1, 10) = "Date(s) of Max Count DET Species"

      ' Loop over seasons

170   For intSeason = conWinter To conNestbox
          
180       strSeason = toStrSeasonFromIntSeason(intSeason)
          
          ' loop over each year
          
190       For intYear = intYearFirst To intYearLast
          
              ' Process the DET daily records for which Banded > 0
              
              
              ' tblMBO10YearProgramReportCountSpecies
              ' -------------------------------------
              ' Season
              ' YearEx
              ' DateEx
              ' CountSpecies
              ' CountBirds           (used for Banded birds)
              
              
              ' qryMBO10YearProgramReport_MaxDETSpecies
              ' ---------------------------------------------------------------------------------------------------------------------
              ' For a given season and year, lists the DET Species records where DETEx > 0
              ' Afterwards I count the species for the season and year, and store the result in tblMBO10YearProgramReportCountSpecies
              ' ---------------------------------------------------------------------------------------------------------------------
              ' tblDETSpecies x tblPrograms
              '
              ' WHERE Location = [argLocation]
              ' Season: MonitoringProgramSeason = [argSeason]
              ' YearEx = [argYear]
              ' DateEx
              ' Species
              ' WHERE DETEx: iif(Nz([DET])>0,[DET],Nz([Banded])+Nz([Returns])+Nz([Repeats])+Nz([Observed3])+Nz([Observed4])) > 0

              ' ORDER BY DateEx, Species
              ' Report Location, Season, YearEx, DateEx, Species, DETEx
              
              
              ' ZAP tblMBO10YearProgramReportCountSpecies
              
200           CurrentDb.Execute "DELETE * FROM tblMBO10YearProgramReport_CountSpecies"
              
              Dim rstCountSpecies As DAO.Recordset
210           Set rstCountSpecies = CurrentDb.OpenRecordset("tblMBO10YearProgramReport_CountSpecies", dbOpenDynaset)
              
              Dim qdf As QueryDef
220           Set qdf = CurrentDb.QueryDefs("qryMBO10YearProgramReport_MaxDETSpecies")
230           qdf.Parameters("argLocation").value = strLocation
240           qdf.Parameters("argSeason").value = strSeason
250           qdf.Parameters("argYear").value = intYear
              
              Dim rst As DAO.Recordset
260           Set rst = qdf.OpenRecordset
              
              Dim datDateEx As Date
              Dim datDateExPrevious As Date
              Dim lngCountSpecies As Long
              
270           datDateExPrevious = 0

280           Do While Not rst.EOF
              
290               datDateEx = Nz(rst("DateEx"))
300               strSpecies = Nz(rst("Species"))
310               If datDateEx = 0 Then GoTo Loop_continue
                  
                  ' Control level break (in Date)
                  
320               If datDateEx <> datDateExPrevious Then
                      
                      ' Finalize for previous date
                      
330                   If datDateExPrevious <> 0 Then
340                       lngCountSpecies = CountSpeciesInDictionary(dic)
350                       rstCountSpecies.AddNew
360                       rstCountSpecies("Season") = strSeason
370                       rstCountSpecies("YearEx") = intYear
380                       rstCountSpecies("DateEx") = datDateExPrevious
390                       rstCountSpecies("CountSpecies") = lngCountSpecies
400                       rstCountSpecies.Update
410                   End If
                      
                      ' Initialise for new date
                      
420                   dic.RemoveAll
430                   datDateExPrevious = datDateEx
                      
440               End If
                  
                  ' Add species
                  
450               If Not dic.Exists(strSpecies) Then
460                   Call dic.Add(strSpecies, strSpecies)
470               End If


Loop_continue:
480               rst.MoveNext
490           Loop
              
       ' Finalize for previous date

500           If datDateExPrevious <> 0 Then
510               lngCountSpecies = CountSpeciesInDictionary(dic)
520               rstCountSpecies.AddNew
530               rstCountSpecies("Season") = strSeason
540               rstCountSpecies("YearEx") = intYear
550               rstCountSpecies("DateEx") = datDateExPrevious
560               rstCountSpecies("CountSpecies") = lngCountSpecies
570               rstCountSpecies.Update
580           End If
              
590           rst.Close
600           Set rst = Nothing
              
610           Set rst = CurrentDb.OpenRecordset("tblMBO10YearProgramReport_CountSpecies")
         
620           Do While Not rst.EOF
              
630               strSeason = Nz(rst("Season"))
640               intYear = Nz(rst("YearEx"))
650               datDateEx = Nz(rst("DateEx"))
660               lngCountSpecies = Nz(rst("CountSpecies"))
              
670               .Cells(row, 1) = strSeason
680               .Cells(row, 2) = intYear
690               .Cells(row, 3) = datDateEx
700               .Cells(row, 4) = lngCountSpecies
710               row = row + 1
       
720               rst.MoveNext
730           Loop
740           rst.Close
750           Set rst = Nothing
          
              Dim col As Long
760           col = 10

              Dim lngMaxCountSpecies As Long
770           lngMaxCountSpecies = Nz(DMax("CountSpecies", "tblMBO10YearProgramReport_CountSpecies", "True"))
780           If lngMaxCountSpecies > 0 Then
              
790               .Cells(rowmax, 7) = strSeason
800               .Cells(rowmax, 8) = intYear
810               .Cells(rowmax, 9) = lngMaxCountSpecies
                  
                  Dim rstMaxCountSpecies As DAO.Recordset
820               Set rstMaxCountSpecies = CurrentDb.OpenRecordset("SELECT DateEx FROM tblMBO10YearProgramReport_CountSpecies WHERE CountSpecies = " & lngMaxCountSpecies)
830               Do While Not rstMaxCountSpecies.EOF
840                   datDateEx = Nz(rstMaxCountSpecies("DateEx"))
850                   .Cells(rowmax, col) = datDateEx
860                   If col > colEnd Then colEnd = col
870                   col = col + 1
880                   rstMaxCountSpecies.MoveNext
890               Loop
900               rstMaxCountSpecies.Close
910               Set rstMaxCountSpecies = Nothing
920               rowmax = rowmax + 1
930           End If

940       Next intYear
950   Next intSeason
          
960   .columns(3).NumberFormat = "dd mmm yyyy"
970   .range(.columns(10), .columns(colEnd)).NumberFormat = "dd mmm yyyy"

980   .range(.columns(1), .columns(colEnd)).AutoFit

990   End With

      'DD Error Handler Start
Exit_label:
1000       Exit Sub
Err_label:
1010       Select Case Err.Number
           Case Else
1020            Call LogError("basMBO10YearProgramReportMaxSpeciesBanded", "MBO10YearProgramReportMaxSpeciesDET")
1030       End Select
1040       Resume Exit_label
      'DD Error Handler End
 End Sub


Public Sub MBO10YearProgramReportMaxSpeciesBanded( _
    ByVal intYearFirst As Integer, _
    ByVal intYearLast As Integer, _
    ByVal strLocation As String, _
    ByRef wd As Word.Application, _
    ByRef doc As Word.Document, _
    ByRef oExcel As Excel.Application, _
    ByRef oBook As Excel.Workbook, _
    ByVal fDebug As Boolean)
          
10    On Error GoTo Err_label
          
      Dim strSpecies As String
      Dim intSeason As Integer
      Dim strSeason As String
      Dim intYear As Integer
      Dim dic As Scripting.Dictionary
      Dim row As Long
      Dim rowmax As Long
      Dim colEnd As Long
      Dim lngCountBirds As Long

      Const colSeason = 1
      Const colYear = 2
      Const colDateEx = 3
      Const colSpecies = 4
      Const colBirds = 5

      Const colSeason2 = 7
      Const colYear2 = 8
      Const colBirdsGt100 = 9
      Const colBirdsGt200 = 10
      Const colMaxBirds = 11
      Const colMaxBirdsDates = 12
      Const colMaxSpecies = 13
      Const colMaxSpeciesDates = 14

      Const colLast = 14

        Dim oSheet As Excel.Worksheet
20    Set oSheet = InsertSheet(oBook, "Global")
30    oSheet.Name = "Peak Banded Species"

40    With oSheet
          
          
50    Set dic = New Scripting.Dictionary
60    row = 2
70    rowmax = 2
80    colEnd = 10

90    .Cells(1, colSeason) = "Season"
100   .Cells(1, colYear) = "Year"
110   .Cells(1, colDateEx) = "Date"
120   .Cells(1, colSpecies) = "Species"
130   .Cells(1, colBirds) = "Birds"
140   .Cells(1, colSeason2) = "Season"
150   .Cells(1, colYear2) = "Year"
160   .Cells(1, colBirdsGt100) = "Birds > 100"
170   .Cells(1, colBirdsGt200) = "Birds > 200"
180   .Cells(1, colMaxBirds) = "Max Count Banded Birds"
190   .Cells(1, colMaxBirdsDates) = "Date(s) of Max Count Banded Birds"
200   .Cells(1, colMaxSpecies) = "Max Count Banded Species"
210   .Cells(1, colMaxSpeciesDates) = "Date(s) of Max Count Banded Species"

      ' Loop over seasons

220   For intSeason = conWinter To conNestbox
          
230       strSeason = toStrSeasonFromIntSeason(intSeason)
          
          ' loop over each year
          
240       For intYear = intYearFirst To intYearLast
          
              ' Process the DET daily records for which Banded > 0
              
              
              ' tblMBO10YearProgramReportCountSpecies
              ' -------------------------------------
              ' Season
              ' YearEx
              ' DateEx
              ' CountSpecies
              ' CountBirds           (used for Banded birds)
              
              
              ' qryMBO10YearProgramReport_MaxBandedSpecies
              ' ---------------------------------------------------------------------------------------------------------------------
              ' For a given season and year, lists the DET Species records where Banded > 0
              ' Afterwards I count the species for the season and year, and store the result in tblMBO10YearProgramReportCountSpecies
              ' ---------------------------------------------------------------------------------------------------------------------
              ' tblDETSpecies x tblPrograms
              '
              ' WHERE Location = [argLocation]
              ' Season: MonitoringProgramSeason = [argSeason]
              ' YearEx = [argYear]
              ' DateEx
              ' Species
              ' WHERE Banded > 0
              ' ORDER BY DateEx, Species
              ' Report Location, Season, YearEx, DateEx, Species, Banded
              
              ' ZAP tblMBO10YearProgramReportCountSpecies
              
250           CurrentDb.Execute "DELETE * FROM tblMBO10YearProgramReport_CountSpecies"
              
              Dim rstCountSpecies As DAO.Recordset
260           Set rstCountSpecies = CurrentDb.OpenRecordset("tblMBO10YearProgramReport_CountSpecies", dbOpenDynaset)
              
              Dim qdf As QueryDef
270           Set qdf = CurrentDb.QueryDefs("qryMBO10YearProgramReport_MaxBandedSpecies")
280           qdf.Parameters("argLocation").value = strLocation
290           qdf.Parameters("argSeason").value = strSeason
300           qdf.Parameters("argYear").value = intYear
              
              Dim rst As DAO.Recordset
310           Set rst = qdf.OpenRecordset
              
              Dim datDateEx As Date
              Dim datDateExPrevious As Date
              Dim lngCountSpecies As Long
              
320           datDateExPrevious = 0

330           Do While Not rst.EOF
              
340               datDateEx = Nz(rst("DateEx"))
350               strSpecies = Nz(rst("Species"))
360               If datDateEx = 0 Then GoTo Loop_continue
                  
                  ' Control level break (in Date)
                  
370               If datDateEx <> datDateExPrevious Then
                      
                      ' Finalize for previous date
                      
380                   If datDateExPrevious <> 0 Then
390                       lngCountSpecies = CountSpeciesInDictionary(dic)
400                       rstCountSpecies.AddNew
410                       rstCountSpecies("Season") = strSeason
420                       rstCountSpecies("YearEx") = intYear
430                       rstCountSpecies("DateEx") = datDateExPrevious
440                       rstCountSpecies("CountSpecies") = lngCountSpecies
450                       rstCountSpecies.Update
460                   End If
                      
                      ' Initialise for new date
                      
470                   dic.RemoveAll
480                   datDateExPrevious = datDateEx
                      
490               End If
                  
                  ' Add species
                  
500               If Not dic.Exists(strSpecies) Then
510                   Call dic.Add(strSpecies, strSpecies)
520               End If


Loop_continue:
530               rst.MoveNext
540           Loop
              
       ' Finalize for previous date

550           If datDateExPrevious <> 0 Then
560               lngCountSpecies = CountSpeciesInDictionary(dic)
570               rstCountSpecies.AddNew
580               rstCountSpecies("Season") = strSeason
590               rstCountSpecies("YearEx") = intYear
600               rstCountSpecies("DateEx") = datDateExPrevious
610               rstCountSpecies("CountSpecies") = lngCountSpecies
620               rstCountSpecies.Update
630           End If
              
640           rst.Close
650           Set rst = Nothing
              
              ' qryMBO10YearProgramReport_CountBandedBirds_MakeTable
              ' ---------------------------------------------------------------------------------------------------------------------
              ' For a given season and year, for each day count the banded birds
              ' Make Table tblMBO10YearProgramReport_CountBandedBirds
              ' ---------------------------------------------------------------------------------------------------------------------
              ' tblDETSpecies x tblPrograms
              '
              ' WHERE Location = [argLocation]
              ' Season: MonitoringProgramSeason = [argSeason]
              ' YearEx = [argYear]
              ' GROUP BY DateEx
              ' SUM Banded > 0
              ' ORDER BY DateEx
              ' Report Location, Season, YearEx, DateEx, Banded
              
660           On Error Resume Next
670           DoCmd.DeleteObject acTable, "tblMBO10YearProgramReport_CountBandedBirds"
680           On Error GoTo Err_label
       
690           Set qdf = CurrentDb.QueryDefs("qryMBO10YearProgramReport_CountBandedBirds_MakeTable")
700           qdf.Parameters("argLocation").value = strLocation
710           qdf.Parameters("argSeason").value = strSeason
720           qdf.Parameters("argYear").value = intYear
730           qdf.Execute
              
              ' qryMBO10YearProgramReport_CountBandedBirds_Update
              ' -------------------------------------------------
              ' tblMBO10YearProgramReport_CountSpecies x tblMBO10YearProgramReport_CountBandedBirds
              '
              ' SET CountBirds = Banded
              
              ' Fill in the CountBirds field
              
740           Set qdf = CurrentDb.QueryDefs("qryMBO10YearProgramReport_CountBandedBirds_Update")
750           qdf.Execute
              




760           Set rst = CurrentDb.OpenRecordset("tblMBO10YearProgramReport_CountSpecies")
         
770           Do While Not rst.EOF
              
780               strSeason = Nz(rst("Season"))
790               intYear = Nz(rst("YearEx"))
800               datDateEx = Nz(rst("DateEx"))
810               lngCountSpecies = Nz(rst("CountSpecies"))
820               lngCountBirds = Nz(rst("CountBirds"))
              
830               .Cells(row, colSeason) = strSeason
840               .Cells(row, colYear) = intYear
850               .Cells(row, colDateEx) = datDateEx
860               .Cells(row, colSpecies) = lngCountSpecies
870               .Cells(row, colBirds) = lngCountBirds
880               row = row + 1
       
890               rst.MoveNext
900           Loop
910           rst.Close
920           Set rst = Nothing
              
              ' Summary by year and season
              
930           .Cells(rowmax, colSeason2) = strSeason
940           .Cells(rowmax, colYear2) = intYear
              
              ' Peak Species Count
          
              Dim lngMaxCountSpecies As Long
950           lngMaxCountSpecies = Nz(DMax("CountSpecies", "tblMBO10YearProgramReport_CountSpecies", "True"))
              
960           .Cells(rowmax, colMaxSpecies) = lngMaxCountSpecies
              
              Dim strListOfDates As String
              
970           strListOfDates = ""
               
              Dim rstMaxCountSpecies As DAO.Recordset
980           Set rstMaxCountSpecies = CurrentDb.OpenRecordset("SELECT DateEx FROM tblMBO10YearProgramReport_CountSpecies WHERE CountSpecies = " & lngMaxCountSpecies)
990           Do While Not rstMaxCountSpecies.EOF
1000              datDateEx = Nz(rstMaxCountSpecies("DateEx"))
1010              strListOfDates = strListOfDates & Format(datDateEx, "dd mmm yyyy") & ",  "
1020              rstMaxCountSpecies.MoveNext
1030          Loop
1040          If Len(strListOfDates) >= 3 Then
1050              strListOfDates = Mid(strListOfDates, 1, Len(strListOfDates) - 3)
1060              .Cells(rowmax, colMaxSpeciesDates) = strListOfDates
1070          End If
1080          rstMaxCountSpecies.Close
1090          Set rstMaxCountSpecies = Nothing
              
              ' Peak Bird Count
          
              Dim lngMaxCountBirds As Long
1100          lngMaxCountBirds = Nz(DMax("CountBirds", "tblMBO10YearProgramReport_CountSpecies", "True"))
              
1110          .Cells(rowmax, colMaxBirds) = lngMaxCountBirds
                     
1120           strListOfDates = ""
               
              Dim rstMaxCountBirds As DAO.Recordset
1130          Set rstMaxCountBirds = CurrentDb.OpenRecordset("SELECT DateEx FROM tblMBO10YearProgramReport_CountSpecies WHERE CountBirds = " & lngMaxCountBirds)
1140          Do While Not rstMaxCountBirds.EOF
1150              datDateEx = Nz(rstMaxCountBirds("DateEx"))
1160              strListOfDates = strListOfDates & Format(datDateEx, "dd mmm yyyy") & ",  "
1170              rstMaxCountBirds.MoveNext
1180          Loop
1190          If Len(strListOfDates) >= 3 Then
1200              strListOfDates = Mid(strListOfDates, 1, Len(strListOfDates) - 3)
1210              .Cells(rowmax, colMaxBirdsDates) = strListOfDates
1220          End If
1230          rstMaxCountBirds.Close
1240          Set rstMaxCountBirds = Nothing
              
              ' > 100 birds
              
              Dim lngCountBandedBirdsGt100 As Long
              Dim lngCountBandedBirdsGt200 As Long
1250          lngCountBandedBirdsGt100 = Nz(DCount("*", "tblMBO10YearProgramReport_CountSpecies", "[CountBirds] > 100"))
1260          lngCountBandedBirdsGt200 = Nz(DCount("*", "tblMBO10YearProgramReport_CountSpecies", "[CountBirds] > 200"))
              
1270          If lngCountBandedBirdsGt100 > 0 Then
1280              .Cells(rowmax, colBirdsGt100) = lngCountBandedBirdsGt100
1290          End If
1300          If lngCountBandedBirdsGt200 > 0 Then
1310              .Cells(rowmax, colBirdsGt200) = lngCountBandedBirdsGt200
1320          End If
              
1330          rowmax = rowmax + 1
           
            
1340      Next intYear
1350  Next intSeason
          
1360  .columns(3).NumberFormat = "dd mmm yyyy"

1370  .range(.columns(1), .columns(colMaxSpecies)).HorizontalAlignment = xlCenter
1380  .range(.columns(1), .columns(colLast)).AutoFit

1390  End With

      'DD Error Handler Start
Exit_label:
1400       Exit Sub
Err_label:
1410       Select Case Err.Number
           Case Else
1420            Call LogError("basMBO10YearProgramReportMaxSpeciesBanded", "MBO10YearProgramReportMaxSpeciesDET")
1430       End Select
1440       Resume Exit_label
      'DD Error Handler End
 End Sub
