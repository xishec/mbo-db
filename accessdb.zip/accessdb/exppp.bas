Sub Export_All_Core_Tables_To_Excel()

    ExportTableToExcel "tblCaptures", _
        "C:\Users\Xi Chen\Documents\tblCaptures.xlsx"

    ExportTableToExcel "tblDETDaily", _
        "C:\Users\Xi Chen\Documents\tblDETDaily.xlsx"

    ExportTableToExcel "tblDETSpecies", _
        "C:\Users\Xi Chen\Documents\tblDETSpecies.xlsx"

    ExportTableToExcel "tblSpecies", _
        "C:\Users\Xi Chen\Documents\tblSpecies.xlsx"

    MsgBox "All tables exported successfully.", vbInformation

End Sub


Private Sub ExportTableToExcel(tableName As String, exportPath As String)

    Dim db As DAO.Database
    Dim rs As DAO.Recordset
    Dim xlApp As Object
    Dim xlWB As Object
    Dim xlWS As Object
    Dim i As Long

    Set db = CurrentDb

    On Error GoTo TableError
    Set rs = db.OpenRecordset(tableName, dbOpenSnapshot)
    On Error GoTo 0

    Set xlApp = CreateObject("Excel.Application")
    xlApp.Visible = False
    xlApp.DisplayAlerts = False

    Set xlWB = xlApp.Workbooks.Add
    Set xlWS = xlWB.Worksheets(1)

    ' Write headers
    For i = 0 To rs.Fields.count - 1
        xlWS.Cells(1, i + 1).value = rs.Fields(i).Name
    Next i

    ' Write data
    xlWS.range("A2").CopyFromRecordset rs
    xlWS.columns.AutoFit

    ' Save workbook
    xlWB.SaveAs exportPath, 51 ' 51 = xlsx
    xlWB.Close
    xlApp.Quit

    ' Cleanup
    rs.Close
    Set rs = Nothing
    Set db = Nothing
    Set xlWS = Nothing
    Set xlWB = Nothing
    Set xlApp = Nothing

    Exit Sub

TableError:
    MsgBox "Could not open table or query: " & tableName, vbCritical

End Sub
