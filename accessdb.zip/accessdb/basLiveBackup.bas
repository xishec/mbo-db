'---------------------------------------------------------------------------------------
' Module: basLiveBackup
' Author: David Davey
'---------------------------------------------------------------------------------------

Option Compare Database
Option Explicit

Const strTableStore As String = "tblCaptures"

' The following DET transactions are NOT (yet) logged. -- Move DET Sheet.  Delete DET Sheet.
' The logs are stored in the following tables in the the MBO Database
' During "live" data entry, the transactions are also logged to corresponding tables on an external drive (e.g. a USB flash drive)

Public Const strLiveDatabaseFilenamePrefix = "MBO Data Entry Logging Database"
Public Const strDETDailyLiveBackup = "tblDETDaily_Log"
Public Const strDETSpeciesLiveBackup = "tblDETSpecies_Log"
Public Const strDETNetHoursLiveBackup = "tblDETNetHours_Log"
'Public Const strBandsSheetLiveBackup = "tblSheetNewBands_Log"
'Public Const strRecapturesSheetLiveBackup = "tblSheetRecaptures_Log"
'Public Const strCapturesLiveBackup = "tblCaptures_Log"

Const conColorBackground_cbo_Logging_ON = &HB4FFB4    ' RGB(180,255,180)
Const conColorBackground_txt_Logging_ON = &H80FF80    ' RGB(128, 255, 128)
Const conColorBackground_cbo_Logging_OFF = &HB4B4FF   ' RGB(255,180,180)
Const conColorBackground_txt_Logging_OFF = &H8080FF   ' RGB(255, 128, 128)

Private strTimestampBands As String      ' "hh\hmm\mss
Private strTimestampRecaptures As String ' "hh\hmm\mss

'Const conBands As Integer = 0
'Const conRecaptures As Integer = 1
'Const conCaptures As Integer = 2

'---------------------------------------------------------------------------------------
' LoggingDatabaseFilename
'---------------------------------------------------------------------------------------

Private Function LoggingDatabaseFilename()
10    On Error GoTo Err_label

20    LoggingDatabaseFilename = strLiveDatabaseFilenamePrefix & " " & VBA.Environ$("computername") & " v" & GetSettingEx("LoggingDatabaseVersion") & ".accdb"

          'DD Error Handler Start
Exit_label:
30        Exit Function
Err_label:
40        Select Case Err.Number
          Case Else
50             Call LogError("basLiveBackup", "LoggingDatabaseFilename")
60        End Select
70        Resume Exit_label
          ' DD Error Handler End

End Function

'---------------------------------------------------------------------------------------
' LoggingDatabaseFilepath
'---------------------------------------------------------------------------------------

Public Function LoggingDatabaseFilepath()
10    On Error GoTo Err_label

20    LoggingDatabaseFilepath = TrailingSlash(GetSettingEx("USBFlashDriveBackupFolder")) & LoggingDatabaseFilename()

    'DD Error Handler Start
Exit_label:
30        Exit Function
Err_label:
40        Select Case Err.Number
    Case Else
50       Call LogError("basLiveBackup", "LoggingDatabaseFilepath")
60        End Select
70        Resume Exit_label
    ' DD Error Handler End
End Function

 ''----------------------------------------------------------------------------------------------
'' BandsOrRecaptures_LiveSnapshot
''
'' If data entry is Live, export the sheet to an Excel file on the USB flash drive backup folder
'' Each Excel file contains the Band and Recap snapshots for 1 day
'' Each export goes to a separate worksheet
''
'' Source = "Bands" or "Recaptures"
''
'' Returns an error message if anyting goes wrong.  Otherwise returns strErr = ""
''---------------------------------------------------------------------------------------

Public Sub BandsOrRecaptures_LiveSnapshot(ByVal strSource As String, ByRef strErr As String)

10    On Error GoTo Err_label

      Dim strTimestamp As String

20    strErr = ""

30    If (GetDataEntrySource() = "Live") Then

40        strErr = "FAILED to export a Live snapshot of " & strSource

          ' Export the sheet to the USB Flash Drive
          ' --------------------------------------
          ' LOOP
          '   Get the USB Flash Drive Folder
          '   Verify the USB Flash Drive Folder exists
          '   If the  USB Flash Drive Folder exists
          '      Export the sheet
          '      If the copy succeeds, EXIT LOOP
          '      If the copy fails, say so then EXIT LOOP
          '   If the USB Flash Drive Folder does not exist
          '      Prompt for a path
          '      Cancel => EXIT LOOP
          ' END LOOP

          Dim strTargetFilename              As String
          Dim strUSBFlashDriveBackupFolder   As String
          Dim strUSBFlashDriveBackupFilepath As String
          Dim strTable As String

50        strTable = IIf(strSource = "Bands", "tblSheetNewBandsMultiSize_v2", "tblSheetRecaps_v2")

60        strTargetFilename = Format(Now(), "yyyy-mm-dd") & " Captures"
70        strUSBFlashDriveBackupFolder = GetSettingEx("USBFlashDriveBackupFolder")
80        strUSBFlashDriveBackupFilepath = TrailingSlash(strUSBFlashDriveBackupFolder) & strTargetFilename

90        strTimestamp = Format(Now(), "yyyy-mm-dd hh\hnn\mss")
100       Select Case strSource
          Case "Bands"
110           If strTimestamp = strTimestampBands Then
120               strErr = "Failed to create Live snapshot - Please do not try to create more than 1 snapshot per second"
130               GoTo Exit_label
140           Else
150               strTimestampBands = strTimestamp
160           End If
170       Case "Captures"
180           If strTimestamp = strTimestampRecaptures Then
190               strErr = "Failed to create Live snapshot - Please do not try to create more than 1 snapshot per second"
200               GoTo Exit_label
210           Else
220               strTimestampRecaptures = strTimestamp
230           End If
240       End Select

250       Do While True
260           If FolderExists(strUSBFlashDriveBackupFolder) Then
270               Call PutSettingEx("USBFlashDriveBackupFolder", strUSBFlashDriveBackupFolder)
                  Dim strSheet As String
280               strSheet = strSource & " " & strTimestamp

290               On Error Resume Next
300               DoCmd.TransferSpreadsheet acExport, acSpreadsheetTypeExcel8, strTable, strUSBFlashDriveBackupFilepath, HasFieldNames:=True, range:=strSheet
310               If Err.Number <> 0 Then
320                   Call LogError("basSheetNewBands_v2", "BandsOrRecaptures_LiveSnapshot", "TransferSpreadsheet failed", Silent:=True, DeveloperErrNumber:=1)
330                   Err.Clear
340                   On Error GoTo Err_label
350                   Exit Do
360               Else
370                   strErr = ""
380               End If

390               Exit Do
400           Else
410               If vbOK <> MsgBox("The Live backup folder " & strUSBFlashDriveBackupFilepath & " does not exist" & vbCrLf & "Click OK if you would like to choose a USB flash drive backup folder" & vbCrLf & "Click Cancel if you do not want to copy the backup to a USB flash drive backup folder", vbOKCancel, "Backup") Then
420                   Exit Do
430               End If
440               strUSBFlashDriveBackupFolder = GetFolder("C:")
450               If strUSBFlashDriveBackupFolder = "" Then
460                   Exit Do
470               Else
480                   strUSBFlashDriveBackupFilepath = TrailingSlash(strUSBFlashDriveBackupFolder) & strTargetFilename
490               End If
500           End If
510       Loop

520   End If

          'DD Error Handler Start
Exit_label:
530       Exit Sub
Err_label:
540       Select Case Err.Number
          Case Else
550            Call LogError("basSheetNewBands_v2", "Bands_LiveSnapshot")
560       End Select
570       Resume Exit_label
          ' DD Error Handler End
End Sub
      
'---------------------------------------------------------------------------------------
' DataEntryLogsExport
'---------------------------------------------------------------------------------------
' Export the tblCaptures_Log data entry log since the last time it was exported
'
' I export tblCaptures_Log
' I allocate some arrays with 1 element, since I might some day also export tblCaptures, the DET Daily, DET Species, and NET Hours logs.
'
' Called when the database closes (frmMainMenu.Close event)

Public Sub DataEntryLogsExport()

      Dim strDataEntryLoggingExportFolder As String
      Dim strEmailListForDataEntryLogs As String
      Dim strTimestamp As String
      Dim strSQL As String
      Dim rst As DAO.Recordset
      Dim lngCountBandDataEntryLogRecords(0 To 0) As Long
      Dim strDataEntryLogTablenames(0 To 0)
      Dim i As Integer
      Dim strTitle(0 To 0) As String
      Dim strFilename(0 To 0) As String

10    On Error GoTo Err_label

20    For i = 0 To 0
30        lngCountBandDataEntryLogRecords(i) = 0
40        strFilename(i) = ""
50    Next

60    strTitle(0) = "Captures"
70    strDataEntryLogTablenames(0) = "tblCaptures_Log"

80    strDataEntryLoggingExportFolder = GetSettingEx("DataEntryLoggingExportFolder")
      '90    strEmailListForDataEntryLogs = SettingGet("EmailListForDataEntryLogs")

90    strTimestamp = GetTimestamp

      ' Verify the ExportDataEntryLogsFolder setting isn't blank

100   If strDataEntryLoggingExportFolder <> "" Then
         
          ' get the maximum Timestamp from tblDataEntryLogsExportHistory ("1900-01-01 00:00:00 0000" if tblDataEntryLogsExportHistory is empty)

          Dim strTimestamp_previous As String
110       strTimestamp_previous = Nz(DMax("Timestamp", "tblDataEntryLogsExportHistory", True), "1900-01-01 00:00:00 0000")

          Dim qdf As DAO.QueryDef
          
      'For each data entry log table -- curently there is only one
      '    lngCountBandDataEntryLogRecords = the number of log records with D17 timestamps >=  strTimestamp_previous
      '    strFilename = path to the file to be created.
      '        The file will be stored in the Data Entry Export Folder
      '        The filenames are Timestamp to Timestamp type Log.txt.
      '        type can be Bands, Recaptures
      '    The log records  are exported "delimited" to strFilename.  (If there are no log records, then the file is not generated)
      '    Warn Simon if the export failed, and RETURN

      Dim lngCountBandDataEntryLogRecords_Bandings As Long
      Dim lngCountBandDataEntryLogRecords_Recaps As Long
      Dim strFilename_Temp As String

      ' I have to work around a limitation of DoCmd.TransferText.  It does not work with long filepaths
      ' So I create the file with a short temporary name, then rename it

120       For i = 0 To 0
              
130           lngCountBandDataEntryLogRecords(i) = DCount("*", strDataEntryLogTablenames(i), "D17 >= '" & strTimestamp_previous & "'")
140           If i = 0 Then
150             lngCountBandDataEntryLogRecords_Bandings = DCount("*", strDataEntryLogTablenames(i), "D17 >= '" & strTimestamp_previous & "' AND [Source] = 'Bands'")
160             lngCountBandDataEntryLogRecords_Recaps = DCount("*", strDataEntryLogTablenames(i), "D17 >= '" & strTimestamp_previous & "' AND [Source] = 'Recaptures'")
170           End If
180           If lngCountBandDataEntryLogRecords(i) > 0 Then

                  Dim strTimestamp_previous_in_filename As String
                  Dim strTimestamp_in_filename As String
                  Dim strTemplate As String
                  
190               strTemplate = "1900-01-01 00:00:00 0000"

200               strTimestamp_previous_in_filename = strTimestamp_previous & Right(strTemplate, Len(strTemplate) - Len(strTimestamp_previous))  ' "1900-01-01 00:00:00 0000"
210               strTimestamp_previous_in_filename = Replace(strTimestamp_previous_in_filename, ":", "h", count:=1)
220               strTimestamp_previous_in_filename = Replace(strTimestamp_previous_in_filename, ":", "m", count:=1)
230               strTimestamp_previous_in_filename = Replace(strTimestamp_previous_in_filename, "/", "-")
                  
240               strTimestamp_in_filename = strTimestamp & Right(strTemplate, Len(strTemplate) - Len(strTimestamp))
250               strTimestamp_in_filename = Replace(strTimestamp_in_filename, ":", "h", count:=1)
260               strTimestamp_in_filename = Replace(strTimestamp_in_filename, ":", "m", count:=1)
270               strTimestamp_in_filename = Replace(strTimestamp_in_filename, "/", "-")
                  
280               strFilename(i) = strDataEntryLoggingExportFolder & "\" & strTimestamp_previous_in_filename & " to " & strTimestamp_in_filename & " " & VBA.Environ$("computername") & " " & strTitle(i) & " Log.xlsx"
290               strFilename_Temp = strDataEntryLoggingExportFolder & "\xxx.xlsx"
300               On Error Resume Next
310               CurrentDb.QueryDefs.Delete "TempQuery"
320               Err.Clear
330               strSQL = "SELECT * FROM " & strDataEntryLogTablenames(i) & " WHERE D17 >= '" & strTimestamp_previous & "'"
340               Set qdf = CurrentDb.CreateQueryDef("TempQuery", strSQL)
350               DoCmd.TransferSpreadsheet acExport, tableName:=qdf.Name, FileName:=strFilename_Temp, HasFieldNames:=True
360               If Err.Number <> 0 Then
370                   MsgBox "FAILED to export the data entry logs" & vbCrLf & Err.Description, vbExclamation, "Export Data Entry Logs"
380               End If
390               CurrentDb.QueryDefs.Delete "TempQuery"
400               qdf.Close
410               Set qdf = Nothing
420               On Error GoTo Err_label

430               Name strFilename_Temp As strFilename(i)
                  
                ' Append a record to  tblDataEntryLogsExportHistory

440               Set rst = CurrentDb.OpenRecordset("tblDataEntryLogsExportHistory", dbOpenDynaset)
450               rst.AddNew
460               rst("Timestamp") = strTimestamp
470               rst("CountDataEntryLogRecords_Bandings") = lngCountBandDataEntryLogRecords_Bandings
480               rst("CountDataEntryLogRecords_Recaps") = lngCountBandDataEntryLogRecords_Recaps
490                rst("Filepath") = strFilename(0)
500               rst.Update
510               rst.Close
520               Set rst = Nothing
                  
                  ' Display summary for 3 sec
                  
                  Dim strMessage As String
530               If i = 0 Then
540                   If lngCountBandDataEntryLogRecords_Bandings + lngCountBandDataEntryLogRecords_Recaps > 0 Then
550                       strMessage = CStr(lngCountBandDataEntryLogRecords_Bandings) & " Bandings log records exported" & vbCrLf & _
                                       CStr(lngCountBandDataEntryLogRecords_Recaps) & " Recaps log records exported"
560                       Call MessageBoxTimer(strMessage, "This message will automatically close in 3 seconds", 3)
570                   End If
580               Else
590                   strMessage = CStr(lngCountBandDataEntryLogRecords(0)) & " Data entry log records exported"
600                   Call MessageBoxTimer(strMessage, "This message will automatically close in 3 seconds", 3)
610               End If
              
      '          ' Email the exported logs
      '
      '450       If lngCountBandDataEntryLogRecords(0) > 0 Then
      '
      '            Dim varAttachments() As Variant
      '
      '460         varAttachments = Array(strFilename(0))
      '470         Call Email_ExportedDataEntryLogs(varAttachments, strTimestamp)
      '
      '480       End If
                  
                  
                  
620           End If
630       Next


          
640   End If

          'DD Error Handler Start
Exit_label:
650       Exit Sub
Err_label:
660       Select Case Err.Number
          Case Else
670           Call LogError("basDataEntryLogs", "DataEntryLogsExport")
680       End Select
690       Resume Exit_label
          ' DD Error Handler End
     End Sub

'Private Sub Email_ExportedDataEntryLogs(ByRef varAttachments As Variant, ByVal strTimestamp As String)
'
'      Const strFromAddress As String = "mbo.dell.dataentry@outlook.com"
'      Const strFromMotDePasse As String = "twdg2437T"
'      Const strSMTPServer As String = "smtp.office365.com"
'      Const intSMTPServer_Port As Integer = 25
'
'10    On Error GoTo Err_label
'
'      Dim strToAddress As String
'
'      ' Get the EmailListForDataEntryLogs setting
'      ' Verify it isn't blank
'
'20    strToAddress = SettingGet("EmailListForDataEntryLogs")
'30    If strToAddress = "" Then GoTo Exit_label
'
'      Dim strMessage As String
'40    strMessage = ""
'
'      Dim fSuccessEmail As Boolean
'      Dim strSubject As String
'      Dim strBodyHTML As String
'      Dim strError As String
'
'50    strSubject = "MBO Database Data Entry Logs " & strTimestamp
'60    strBodyHTML = ""
'
'70    fSuccessEmail = SendEMail( _
'          strSubject, _
'          strFromAddress, _
'          strFromMotDePasse, _
'          strToAddress, _
'          strBodyHTML, _
'          strSMTPServer, _
'          intSMTPServer_Port, _
'          "", strError, _
'          varAttachments)
'
'80    If Not fSuccessEmail Then
'
'90        strError = strError & _
'              "Subject = " & strSubject & _
'              ", From Address = " & strFromAddress & _
'              ", To Address =  " & strToAddress & _
'              ", SMTP Server = " & strSMTPServer
'
'100       Call LogError("basErrorLogging", "EmailError", Silent:=False, DeveloperMessage:="Email failure: " & strError, DeveloperErrNumber:=1, fEmailError:=False)
'110   End If
'
'          'DD Error Handler Start
'Exit_label:
'120       Exit Sub
'Err_label:
'130       Select Case Err.Number
'          Case Else
'140      Call LogError("basLiveBackup", "Email_ExportedDataEntryLogs")
'150       End Select
'160       Resume Exit_label
'          ' DD Error Handler End
'End Sub

'---------------------------------------------------------------------------------------
' ValidateExternalLogging_IfFailReportAndTurnOff
'---------------------------------------------------------------------------------------
' Called from basLiveBackup.chkDataEntrySource_AfterUpdate()
'
' Call ValidateExternalLogging_IfFailReportAndTurnOff(chkDataEntrySource, txtMsgLogging)

Public Sub ValidateExternalLogging_IfFailReportAndTurnOff(ByRef chkDataEntrySource As CheckBox, ByRef txtMsgLogging As TextBox)

      Dim strExternalDataEntryLoggingDatabaseFolder As String

10    On Error GoTo Err_label

20     strExternalDataEntryLoggingDatabaseFolder = GetSettingEx("USBFlashDriveBackupFolder")
       
       ' Verify that logging to an external USB Flash drive is possible
       
       Dim strExternalLoggingError As String
30     strExternalLoggingError = ""
       
40     Call ValidateExternalLogging(strExternalLoggingError)

50     If strExternalLoggingError <> "" Then
60         chkDataEntrySource = False
70         txtMsgLogging = "Data Entry Logging to an external drive is OFF"
80         txtMsgLogging.BackColor = conColorBackground_txt_Logging_OFF
90         Call PutDataEntrySource("FromSheets")
100        MsgBox strExternalLoggingError & vbCrLf & vbCrLf & _
                   "Logging to an external drive has been turned OFF", vbCritical + vbExclamation + vbOKOnly, "Logging to an external drive"
110        GoTo Exit_label
120    End If
       
130    txtMsgLogging = "Data Entry is logging to " & strExternalDataEntryLoggingDatabaseFolder
140    txtMsgLogging.BackColor = conColorBackground_txt_Logging_ON
150    Call PutDataEntrySource("Live")

          'DD Error Handler Start
Exit_label:
160       Exit Sub
Err_label:
170       Select Case Err.Number
          Case Else
180            Call LogError("basLiveBackup", "ValidateExternalLogging_IfFailReportAndTurnOff")
190       End Select
200       Resume Exit_label
          ' DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' ValidateExternalLogging
'---------------------------------------------------------------------------------------
' PRE: The setting ExternalDataEntryLoggingDatabaseFolder has been filled in (can be Null)
'
' Called From:
' <  basLiveBackup. ValidateExternalLogging_IfFailReportAndTurnOff
' <  <  Form_frmMainMenu. Form_Open
' <  <  basLiveBackup. chkDataEntrySource_AfterUpdate
' <  <  <   frmMainMenu.chkDataEntrySource_AfterUpdate
' "            frmSheetNewBandsMultiSize_v2,AfterUpdate
' "            frmSheetRecaps_v2.chkDataEntrySource_AfterUpdate
' "           frmCapturesEditOrDelete.chkDataEntrySource_AfterUpdate
' "             frmDataFields.chkDataEntrySource_AfterUpdate
' < basLiveBackup. Log_NewBandsSheet
' < basLiveBackup. Log_RecapturesSheet
' < Form_frmSettings. txtExternalDataEntryLoggingDatabaseFolder_MBO_AfterUpdate

' Validate that the external logging drive has a root folder
' If the external logging folder does not exist then create it
' Validate that the external logging folder exists
' If the external logging database  does not exist, create it
' Validate that the external logging database exists
' Validate I can connect to the external logging database
' Validate that the external logging database tables exist
' Validate one can write and read logging records
              
 
Public Sub ValidateExternalLogging(ByRef strExternalLoggingError As String)
           
10    On Error GoTo Err_label

      Dim strFolderpath As String
      Dim ws As DAO.Workspace
      Dim db As DAO.Database
      Dim strExternalLoggingDatabaseFilepath As String

20    strExternalLoggingError = ""

30    strFolderpath = GetSettingEx("USBFlashDriveBackupFolder")

40    strExternalLoggingDatabaseFilepath = LoggingDatabaseFilepath()

50    Set ws = DBEngine.Workspaces(0)
          
60    If Not ValidateExternalDriveHasARootFolder(strFolderpath) Then
70        strExternalLoggingError = "Failed to find a root folder on the external logging drive"
80        GoTo Exit_label
90    End If

100   If Not ValidateExternalDriveHasALoggingFolder(strFolderpath) Then
110       strExternalLoggingError = "The external logging folder does not exist - and the program failed to create it."
120       GoTo Exit_label
130   End If

140   If Not ValidateExternalLoggingDatabase(strFolderpath) Then
150       strExternalLoggingError = "The external logging database does not exist - and the program failed to create it."
160       GoTo Exit_label
170   End If

      ' Validate I can connect to the external logging database
          
180   Set ws = DBEngine.Workspaces(0)

190   Err.Clear
200   On Error Resume Next
210   Set db = ws.OpenDatabase(strExternalLoggingDatabaseFilepath)
220   If Err.Number <> 0 Then
230       strExternalLoggingError = "Failed to open a connection to the external logging database " & strExternalLoggingDatabaseFilepath
240       On Error GoTo Err_label
250       GoTo Exit_label
260   End If
          
      ' Validate the schema of the external loging database

270   Call ValidateExternalLoggingDatabaseSchema(db, strExternalLoggingDatabaseFilepath, strExternalLoggingError)
280   If strExternalLoggingError <> "" Then
290       On Error Resume Next
300       db.Close
310       On Error GoTo Err_label
320       GoTo Exit_label
330   End If

      ' Validate one can write and read logging records
          
340   Call ValidateExternalLoggingDatabaseTablesWriteRead(db, strExternalLoggingError)
350   If strExternalLoggingError <> "" Then
360       On Error Resume Next
370       db.Close
380       On Error GoTo Err_label
390       GoTo Exit_label
400   End If

          'DD Error Handler Start
Exit_label:
410       Exit Sub
Err_label:
420       Select Case Err.Number
          Case Else
430      Call LogError("basLiveBackup", "ValidateExternalLoggging")
440       End Select
450       Resume Exit_label
          ' DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' ValidateExternalDriveHasARootFolder
'---------------------------------------------------------------------------------------
' PRE strFolder begins with letter colon backslash

Public Function ValidateExternalDriveHasARootFolder(ByVal strFolder As String) As Boolean

10    On Error GoTo Err_label

      Dim strRootFolder As String

20    strRootFolder = Mid(strFolder, 1, 3)
30    ValidateExternalDriveHasARootFolder = FolderExists(strRootFolder)

    'DD Error Handler Start
Exit_label:
40        Exit Function
Err_label:
50        Select Case Err.Number
    Case Else
60       Call LogError("basLiveBackup", "ValidateExternalDriveHasARootFolder")
70        End Select
80        Resume Exit_label
    ' DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' Log_NewBandsSheet_Live
'---------------------------------------------------------------------------------------
'
' Open  connection to an external logging database
' Open a recordset to the tblCaptures_Log table
' Write a logging record rec to the recordset rst
'
' If anything goes wrong, return  fSuccess = False
'
' PRE:

'   D(17)       has been filled in        Modify Timestamp
'   Command     has been filled in
'   Source      has been filled in

Private Sub Log_NewBandsSheet_Live(ByRef rec As SheetNewBandsType, ByVal strLiveDatabaseFilepath As String, ByRef fSuccess As Boolean)

10    On Error GoTo Err_label

      Dim ws As DAO.Workspace
      Dim db As DAO.Database
      Dim rst As DAO.Recordset
      
20    fSuccess = True

30    Set ws = DBEngine.Workspaces(0)
40    Set db = ws.OpenDatabase(strLiveDatabaseFilepath)
50    Set rst = db.OpenRecordset("tblCaptures_Log")

60    Call Log_NewBandsSheet_rst(rec, rst, fSuccess) ' Write a logging record to the external database

Exit_label:

      ' Clean up

70        On Error Resume Next
80        db.Close
90        rst.Close
100       Set rst = Nothing
110       Set db = Nothing
          
120       Exit Sub
Err_label:
130       Select Case Err.Number
          Case Else
140            fSuccess = False  ' The caller will deal with this
150       End Select
160       Resume Exit_label
          ' DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' Log_RecapturesSheet_Live
'---------------------------------------------------------------------------------------
' Call Log_RecapturesSheet_Live(rec, strLiveDatabaseFilepath, fSuccess)
'
' Open  connection to an external logging database
' Open a recordset to the tblSheetRecaptures_Log table
' Write a logging record rec to the recordset rst
'
' If anything goes wrong, return  fSuccess = False

Private Sub Log_RecapturesSheet_Live(ByRef rec As SheetRecapturesType, ByVal strLiveDatabaseFilepath As String, ByRef fSuccess As Boolean)

10    On Error GoTo Err_label

      Dim ws As DAO.Workspace
      Dim db As DAO.Database
      Dim rst As DAO.Recordset
      
20    fSuccess = True

30    Set ws = DBEngine.Workspaces(0)
40    Set db = ws.OpenDatabase(strLiveDatabaseFilepath)
50    Set rst = db.OpenRecordset("tblCaptures_Log")

60    Call Log_RecapturesSheet_rst(rec, rst, fSuccess) ' Write a logging record to the external database

Exit_label:

      ' Clean up

70        On Error Resume Next
80        db.Close
90        rst.Close
100       Set rst = Nothing
110       Set db = Nothing
          
120       Exit Sub
Err_label:
130       Select Case Err.Number
          Case Else
140            fSuccess = False    ' The caller will deal with this
150       End Select
160       Resume Exit_label

End Sub

'---------------------------------------------------------------------------------------
' Log_NewBandsSheet_rst
'---------------------------------------------------------------------------------------
' Call Log_NewBandsSheet_rst(rec, rst, fSuccess)
'
' Write a logging record rec to a recordset rst
' rst will be a recordset for either the local tblCaptures_Log or the tblCaptures_Log in the logging database on an USB Flash Drive.
' If anything goes wrong, return  fSuccess = False
'
'
' Called from basLiveBackup.Log_NewBandsSheet_rst
'             basLiveBackup.Log_NewBandsSheet_Live
'
'PRE:
'
'   D(17)       has been filled in    Modify Timestamp
'   Command     has been filled in
'   Source      has been filled in

Private Sub Log_NewBandsSheet_rst(ByRef rec As SheetNewBandsType, ByRef rst As DAO.Recordset, ByRef fSuccess As Boolean)

10    On Error GoTo Err_label

      Dim i As Integer

20    fSuccess = True

30    rst.AddNew
40    rst("BandID_Sheets") = rec.BandID
50    rst("BandSizeID_NewBands") = rec.BandSizeID
60    rst("Disposition") = rec.Disposition
70    rst("BandPrefix") = rec.BandPrefix
80    rst("BandSuffix") = rec.BandSuffix
90    rst("Species") = rec.Species
100   rst("WingChord_Sheets") = rec.WingChord
110   rst("Age") = rec.Age
120   rst("HowAged") = rec.HowAged
130   rst("Sex") = rec.Sex
140   rst("HowSexed") = rec.HowSexed
150   rst("Fat") = rec.Fat
160   rst("Weight") = rec.Weight
170   rst("CaptureDate_Sheets") = rec.CaptureDate
180   rst("CaptureYear_Sheets") = rec.CaptureYear
190   rst("WeightTime_Sheets") = rec.WeightTime
200   rst("Bander") = rec.Bander
210   rst("Scribe") = rec.Scribe
220   rst("Net") = rec.Net
230   rst("NotesForMBO") = rec.NotesForMBO
240   rst("Valid") = rec.Valid
250   rst("Invalid") = rec.Invalid
260   rst("Duplicate_NewBands") = rec.Duplicate
270   rst("BypassErrors") = rec.BypassErrors
280   rst("AutoHistory") = rec.AutoHistory
290   rst("ProbableAge") = rec.ProbableAge
300   rst("ProbableSex") = rec.ProbableSex
310   rst("Location") = rec.Location
320   rst("BirdStatus") = rec.BirdStatus
330   rst("Program") = rec.Program
340   rst("F") = rec.FCombined
350   For i = 1 To conMaxUserField
360       rst("F" & i) = rec.F(i)
370   Next
380   rst("Flags") = rec.Flags
390   For i = 1 To conMaxDataField
400       rst("D" & i) = rec.D(i)
410   Next i

420   rst("Command") = rec.Command
430   rst("Source") = rec.Source

440   rst.Update

          'DD Error Handler Start
Exit_label:
450       Exit Sub
Err_label:
460       Select Case Err.Number
          Case Else
470           fSuccess = False  ' The caller will deal with this.
480       End Select
490       Resume Exit_label
          ' DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' Log_RecapturesSheet_rst
'---------------------------------------------------------------------------------------
' Call Log_RecapturesSheet_rst( rec, rst, fSuccess)
'
' Write a logging record rec to a recordset rst
'
' If anything goes wrong, return  fSuccess = False

Private Sub Log_RecapturesSheet_rst(ByRef rec As SheetRecapturesType, ByRef rst As DAO.Recordset, ByRef fSuccess As Boolean)

On Error GoTo Err_label

Dim i As Integer

fSuccess = True

rst.AddNew
rst("BandID_Sheets") = rec.BandID
rst("Disposition") = rec.Disposition
rst("BandPrefix") = rec.BandPrefix
rst("BandSuffix") = rec.BandSuffix
rst("Species") = rec.Species
rst("WingChord_Sheets") = rec.WingChord
rst("Age") = rec.Age
rst("HowAged") = rec.HowAged
rst("Sex") = rec.Sex
rst("HowSexed") = rec.HowSexed
rst("Fat") = rec.Fat
rst("Weight") = rec.Weight
rst("CaptureDate_Sheets") = rec.CaptureDate
rst("CaptureYear_Sheets") = rec.CaptureYear
rst("WeightTime_Sheets") = rec.WeightTime
rst("Bander") = rec.Bander
rst("Scribe") = rec.Scribe
rst("Net") = rec.Net
rst("NotesForMBO") = rec.NotesForMBO
rst("Valid") = rec.Valid
rst("Invalid") = rec.Invalid
rst("BypassErrors") = rec.BypassErrors
rst("AutoHistory") = rec.AutoHistory
rst("ProbableAge") = rec.ProbableAge
rst("ProbableSex") = rec.ProbableSex
rst("Location") = rec.Location
rst("BirdStatus") = rec.BirdStatus
rst("PresentCondition") = rec.PresentCondition
rst("HowObtainedCode") = rec.HowObtainedCode
rst("Program") = rec.Program
rst("F") = rec.FCombined
For i = 1 To conMaxUserField
    rst("F" & i) = rec.F(i)
Next
rst("Flags") = rec.Flags
For i = 1 To conMaxDataField
    rst("D" & i) = rec.D(i)
Next i

rst("Command") = rec.Command
rst("Source") = rec.Source

rst.Update

    'DD Error Handler Start
Exit_label:
    Exit Sub
Err_label:
    Select Case Err.Number
    Case Else
        fSuccess = False   ' The caller will deal with this
    End Select
    Resume Exit_label
    ' DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' ValidateExternalLoggingDatabase
'---------------------------------------------------------------------------------------

Private Function ValidateExternalLoggingDatabase(ByVal strFolder As String) As Boolean

10    On Error GoTo Err_label

      ' Verify if the external logging database file exists

      Dim strLiveDatabaseFilepath As String

20    strLiveDatabaseFilepath = LoggingDatabaseFilepath
30    If FileExists(strLiveDatabaseFilepath) Then
40        ValidateExternalLoggingDatabase = True
50    Else

          ' Create the external logging database

          Dim strError As String
60        Call CreateLoggingDatabase(strLiveDatabaseFilepath, strError)
70        ValidateExternalLoggingDatabase = (strError = "")

80    End If
          'DD Error Handler Start
Exit_label:
90        Exit Function
Err_label:
100       Select Case Err.Number
          Case Else
110      Call LogError("basLiveBackup", "ValidateExternalLoggingDatabase")
120       End Select
130       Resume Exit_label
          ' DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' ValidateExternalLoggingFolder
'---------------------------------------------------------------------------------------
' PRE: The utility variable ValidateExternalDriveHasARootFolder is not blank
'
' Returns False if the external logging folder does not exist AND I failed to create it
' Otherwise return True (the external logging folder exists)

Private Function ValidateExternalDriveHasALoggingFolder(ByVal strFolder As String) As Boolean

10    On Error GoTo Err_label

      Dim strError As String

      ' Verify if the external logging folder exists

20    If FolderExists(strFolder) Then
30        ValidateExternalDriveHasALoggingFolder = True
40    Else

          ' Create the external logging folder

50        strError = ""
60        Call CreateFolder(strFolder, strError)
70        ValidateExternalDriveHasALoggingFolder = (strError = "")
80    End If
              

          'DD Error Handler Start
Exit_label:
90        Exit Function
Err_label:
100       Select Case Err.Number
          Case Else
110      Call LogError("basLiveBackup", "ValidateExternalLoggingFolder")
120       End Select
130       Resume Exit_label
          ' DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' ValidatePath_StartsWithLetterColonBackslash
'---------------------------------------------------------------------------------------

Public Function ValidatePath_StartsWithLetterColonBackslash(ByVal strPath As String) As Boolean

10       On Error GoTo Err_label

      ' Validate path starts with letter colon backslash

      Dim strChar As String
      Dim fValid As Boolean

20    fValid = True
30    If Len(strPath) < 3 Then
40        fValid = False
50    Else
60        strChar = UCase(Mid(strPath, 1, 1))
70        If strChar < "A" Or strChar > "Z" Then
80            fValid = False
90        Else
          
100           strChar = Mid(strPath, 2, 2)
110           If strChar <> ":\" Then
120               fValid = False
130           End If
140       End If
150   End If

160   ValidatePath_StartsWithLetterColonBackslash = fValid

          'DD Error Handler Start
Exit_label:
170       Exit Function
Err_label:
180       Select Case Err.Number
          Case Else
190            Call LogError("basLiveBackup", "ValidatePath_StartsWithLetterColonBackslash")
200       End Select
210       Resume Exit_label
          ' DD Error Handler End

End Function

'---------------------------------------------------------------------------------------
' ValidatePath_IsNotBlank
'---------------------------------------------------------------------------------------

Public Function ValidatePath_IsNotBlank(ByVal strPath As String) As Boolean
10    On Error GoTo Err_label

20    ValidatePath_IsNotBlank = (strPath <> "")

          'DD Error Handler Start
Exit_label:
30        Exit Function
Err_label:
40        Select Case Err.Number
          Case Else
50             Call LogError("basLiveBackup", "ValidatePath_IsNotBlank")
60        End Select
70        Resume Exit_label
          ' DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' ExternalLogging_TurnOff
'---------------------------------------------------------------------------------------
' Set the DataEntrySource utility variable to "FromSheets"
' Update the Data Entry Source chk and txt

Public Sub ExternalLogging_TurnOff(ByRef chkDataEntrySource As CheckBox, ByRef txtMsgLogging As TextBox)

10    On Error GoTo Err_label

20    Call PutDataEntrySource("FromSheets")

30    chkDataEntrySource = False
40    txtMsgLogging = "Data Entry Logging to an external database is OFF"
50    txtMsgLogging.BackColor = conColorBackground_txt_Logging_OFF
         


    'DD Error Handler Start
Exit_label:
60        Exit Sub
Err_label:
70        Select Case Err.Number
    Case Else
80       Call LogError("basLiveBackup", "ExternalLogging_TurnOff")
90        End Select
100       Resume Exit_label
    ' DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' chkDataEntrySource_AfterUpdate
'---------------------------------------------------------------------------------------
' Called from frmMainMenu.chkDataEntrySource_AfterUpdate
'             frmSheetNewBandsMultiSize_v2 , AfterUpdate
'             frmSheetRecaps_v2.chkDataEntrySource_AfterUpdate
'             frmCapturesEditOrDelete.chkDataEntrySource_AfterUpdate
'             frmDataFields.chkDataEntrySource_AfterUpdate

Public Sub chkDataEntrySource_AfterUpdate(ByRef chkDataEntrySource As CheckBox, ByRef txtMsgLogging As TextBox)

10    On Error GoTo Err_label

      Dim fDataEntrySource As Boolean
      Dim strDataEntrySource As String
      Dim strExternalDataEntryLoggingDatabaseFolder As String

20    fDataEntrySource = Nz(chkDataEntrySource)

30    strDataEntrySource = IIf(fDataEntrySource, "Live", "FromSheets")
40    Call PutDataEntrySource(strDataEntrySource)

50    If Not fDataEntrySource Then
60        txtMsgLogging = "Data Entry Logging is OFF"
70        txtMsgLogging.BackColor = conColorBackground_txt_Logging_OFF
80    Else
90        Call ValidateExternalLogging_IfFailReportAndTurnOff(chkDataEntrySource, txtMsgLogging)
100   End If

          'DD Error Handler Start
Exit_label:
110       Exit Sub
Err_label:
120       Select Case Err.Number
          Case Else
130      Call LogError("basLiveBackup", "chkDataEntrySource_AfterUpdate")
140       End Select
150       Resume Exit_label
          ' DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' FillInDataSourceControls
'---------------------------------------------------------------------------------------
' Fill in the Data Entry Source controls.  If live logging is on, verify live logging is working
'
' Called from frmSheetNewBandsMultiSize_v2.Form_Activate
'             frmSheetRecaps_v2.Form_Activate
'             frmDataFields.Form_Activate

Public Sub FillInDataSourceControls(ByRef chkDataEntrySource As CheckBox, ByRef txtMsgLogging As TextBox)

      Dim strDataEntrySource As String
      Dim fDataEntrySource As Boolean
      Dim strExternalDataEntryLoggingDatabaseFolder As String

10    On Error GoTo Err_label

20    strDataEntrySource = GetDataEntrySource()
30    fDataEntrySource = (strDataEntrySource = "Live")
40    chkDataEntrySource = fDataEntrySource

50    If Not fDataEntrySource Then

60        txtMsgLogging = "Data Entry Logging is OFF"
70        txtMsgLogging.BackColor = conColorBackground_txt_Logging_OFF
80    Else
90        strExternalDataEntryLoggingDatabaseFolder = GetSettingEx("USBFlashDriveBackupFolder") ' GetSettingEx("USBFlashDriveBackupFolder")
100       txtMsgLogging = "Data Entry is logging to " & strExternalDataEntryLoggingDatabaseFolder
110       txtMsgLogging.BackColor = conColorBackground_txt_Logging_ON
120   End If


          'DD Error Handler Start
Exit_label:
130       Exit Sub
Err_label:
140       Select Case Err.Number
          Case Else
150            Call LogError("basLiveBackup", "FillInDataSourceControls")
160       End Select
170       Resume Exit_label
          ' DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' GetExternalLiveDataEntryDatabase
'---------------------------------------------------------------------------------------
' Returns a DAO.Database object
' If anything goes wrong, return Nothing and an error message in strError

Public Function GetExternalLiveDataEntryDatabase(ByRef strError As String) As DAO.Database

      ' If external logging isn't ON, we should not be here.  Return Nothing.  strError = ""
      ' Verify that the external backup folder exists
      '   If not, return with an error message
      ' Verify the external database and it tables exist; if not create them
      '   If anything goes wrong: return with an error message
      ' Return the database object


10    On Error GoTo Err_label

      Dim strDataEntrySource As String
      Dim strLiveBackupFolder As String
      Dim strLiveDatabaseFilepath As String
      Dim ws As DAO.Workspace
      Dim db As DAO.Database
      
20    Set db = Nothing

30    Set GetExternalLiveDataEntryDatabase = Nothing
40    strError = ""

50    Call getLiveBackupFolder(strDataEntrySource, strLiveBackupFolder)     ' Returns the data entry source "Live" or "FromSheet"
                                                                            ' If "Live", also returns the folderpath to the external Live backup folder

60    If strDataEntrySource <> "Live" Then GoTo Exit_label

      ' Verify the external logging folder is accessibe

70    If Not FolderExists(strLiveBackupFolder) Then
80        strError = "Failed to open the logging folder " & strLiveBackupFolder & vbCrLf & _
                     "Verify the USB Flash Drive installed" & vbCrLf & vbCrLf & _
                     "Logging to an external database has been turned OFF"
90        GoTo Exit_label
100   End If

      ' If the Live Backup database file does not exist then create it together with its (empty) tables

110   strLiveDatabaseFilepath = LoggingDatabaseFilepath

120   strError = ""
130   If Not FileExists(strLiveDatabaseFilepath) Then
140       Call CreateLoggingDatabase(strLiveDatabaseFilepath, strError)
150       GoTo Exit_label
160   End If

      ' Connect to the external logging database

170   Set ws = DBEngine.Workspaces(0)

180   Err.Clear
190   On Error Resume Next
200   Set db = ws.OpenDatabase(strLiveDatabaseFilepath)
210   If Err.Number <> 0 Then
220       strError = "Failed to open a connection to the external logging database " & strLiveDatabaseFilepath & vbCrLf & vbCrLf & _
                     "Logging to an external database has been turned OFF"
230       On Error GoTo Err_label
240       GoTo Exit_label
250   End If

      ' Validate the schema of the external loging database

260   strError = ""
270   Call ValidateExternalLoggingDatabaseSchema(db, strLiveDatabaseFilepath, strError)
280   If strError <> "" Then GoTo Exit_label


          'DD Error Handler Start
Exit_label:
290       Set GetExternalLiveDataEntryDatabase = db
300       Exit Function
Err_label:

310       Select Case Err.Number
          Case Else
320            strError = "Failed to open a connection to an external logging database " & strLiveDatabaseFilepath & vbCrLf & vbCrLf & _
                          "Logging to an external database has been turned OFF"

330       End Select
340       Resume Exit_label
          ' DD Error Handler End

End Function

'--------------------------------------------------------------------------------------------------------
' Log_NewBandsSheet
'
' Logs a single Bands Sheet Daily Add, Update and Delete transaction
' The caller must fill in all the data fields, Timestamp, Command, Source, LogID
' Transactions are logged to a local table - strBandsSheetLiveBackup
' During "live" data entry, the transactions are also logged to corresponding table on an external drive
'
' Dim ExternalLoggingError As String
' Call Log_NewBandsSheet(rec,  strExternalLoggingError)
'--------------------------------------------------------------------------------------------------------
' Copies all the fields from rec to tblCaptures_Log
'
'PRE:
'   strExternalLoggingError = ""
'
'   D(16)       has been filled in            Creation Timestamp
'   D(17)       has been filled in            Modify Timestamp
'   Command     has been filled in
'   Source      has been filled in
'
'Called from frmDataFields.Form_AfterUpdate
'            frmSheetNewBandsMultiSize_v2.Form_Delete
'            frmSheetNewBandsMultiSize_v2.cmdClearLine
'            frmSheetNewBandsMultiSize_v2.Log_NewBandsSheet
'            frmSheetNewBandsMultiSize_v2.ClearAll_Click
'            frmSheetNewBandsMultiSize_v2.NewBands_Store_v2
'            basSheetNewBands_v2.Form_AfterUpdate

Public Sub Log_NewBandsSheet(ByRef rec As SheetNewBandsType, ByRef strExternalLoggingError As String)

10    On Error GoTo Err_label

      Dim rst As DAO.Recordset
      Dim fSuccess As Boolean
      Dim strDataEntrySource As String

      ' Log to the local strBandsSheetLiveBackup

20    Set rst = CurrentDb.OpenRecordset("tblCaptures_Log")
30    fSuccess = True
40    Call Log_NewBandsSheet_rst(rec, rst, fSuccess)
50    rst.Close
60    Set rst = Nothing

70    strDataEntrySource = GetDataEntrySource()                  ' "Live" or "From Sheets"
80    If strDataEntrySource <> "Live" Then GoTo Exit_label

      ' If data entry logging is "Live" then, log to the external logging database

      Dim strLiveBackupFolder As String
      Dim strLiveDatabaseFilepath As String

90    strLiveBackupFolder = GetSettingEx("USBFlashDriveBackupFolder") ' GetSettingEx("USBFlashDriveBackupFolder")
100   strLiveDatabaseFilepath = LoggingDatabaseFilepath()

      Dim ws As DAO.Workspace
      Dim db As DAO.Database

110   fSuccess = True
120   Call Log_NewBandsSheet_Live(rec, strLiveDatabaseFilepath, fSuccess)

      ' If anything goes wrong, try once more to log, but this time step by step

130   If Not fSuccess Then

'           Validate that the utility variable USBFlashDriveBackupFolder isn't blank
'           Validate that the utility variable USBFlashDriveBackupFolder starts with letter : \
'           Validate that the external logging drive has a root folder
'           If the external logging folder does not exist then create it
'           Validate that the external logging folder exists
'           If the external logging database  does not exist, create it
'           Validate that the external logging database exists
'           Validate I can connect to the external logging database
'           Validate that the external logging database tables exist
'
'           Connect to the external logging database
'           Open a recordset to the logging table
'           Log the record


140       Call ValidateExternalLogging(strExternalLoggingError)
150           If strExternalLoggingError <> "" Then
160           GoTo Exit_label
170       End If
          
          ' Connect to the external logging database
              
180       Set ws = DBEngine.Workspaces(0)
          
190       Err.Clear
200       On Error Resume Next
210       Set db = ws.OpenDatabase(strLiveDatabaseFilepath)
220       If Err.Number <> 0 Then
230           strExternalLoggingError = "Failed to open a connection to the external logging database " & strLiveDatabaseFilepath
240           On Error GoTo Err_label
250           GoTo Exit_label
260       End If

          ' Open a recordset to the strBandsSheetLiveBackup table
          
270       On Error Resume Next
280       Set rst = db.OpenRecordset("tblCaptures_Log")
290       If Err.Number <> 0 Then
300           strExternalLoggingError = "Failed to connect to the " & "tblCaptures_Log" & " table in the external logging database"
310           db.Close
320           GoTo Exit_label
330       End If

          ' Log the banding record
          
340       fSuccess = True
350       Call Log_NewBandsSheet_rst(rec, rst, fSuccess) ' Write a logging record to the external database
360       If Not fSuccess Then
370           strExternalLoggingError = "Failed to write a logging record to the  " & "tblCaptures_Log" & " table in the external logging database"
380           On Error Resume Next
390           rst.Close
400           db.Close
410           On Error GoTo Err_label
420           GoTo Exit_label
430       End If
            
440       rst.Close
450       db.Close
          
460       Set rst = Nothing
470       Set db = Nothing
          
480   End If

          'DD Error Handler Start
Exit_label:
490       Exit Sub
Err_label:
500       Select Case Err.Number
          Case Else
510           Call LogError("basLiveBackup", "Log_NewBandsSheet")
520       End Select
530       Resume Exit_label
          ' DD Error Handler End

End Sub

'--------------------------------------------------------------------------------------------------------
' Log_RecapturesSheet
'
' Logs a single recaptures Sheet Daily Add, Update and Delete transaction
' The caller must fill in all the data fields, Timestap, Command, Source, IDLog
' Transactions are logged to a local table - tblSheetRecaptures_Log
' During "live" data entry, the transactions are also logged to corresponding table on an external drive
'--------------------------------------------------------------------------------------------------------
' Copies all the fields from rec to tblCaptures_Log
'
' PRE
' rec.D16 and rec.D17 have been filled in
'
' Called From
' frmSheetRecaps_v2.Form_AfterUpdate
' frmSheetRecaps_v2.cmdClearAll_Click
' frmSheetRecaps_v2.Form_Delete
' frmDataFields.Form_AfterUpdate

Public Sub Log_RecapturesSheet(ByRef rec As SheetRecapturesType, ByRef strExternalLoggingError As String, Optional ByVal fSkipExternalLogging = False)

      Dim rst As DAO.Recordset
      Dim db As DAO.Database
      Dim strDataEntrySource As String
      Dim fSuccess As Boolean

10    On Error GoTo Err_label

      '     Sync the Bands form to the Bands table

20    strExternalLoggingError = ""

      ' Log to the local tblSheetRecaptures_Log

30    Set rst = CurrentDb.OpenRecordset("tblCaptures_Log")
40    fSuccess = True
50    Call Log_RecapturesSheet_rst(rec, rst, fSuccess)
60    rst.Close
70    Set rst = Nothing

80    strDataEntrySource = GetDataEntrySource()
90    If strDataEntrySource <> "Live" Or fSkipExternalLogging Then GoTo Exit_label

      ' Log to the external strBandsSheetLiveBackup table in the live backup database

      Dim strLiveBackupFolder As String
      Dim strLiveDatabaseFilepath As String

100   strLiveBackupFolder = GetSettingEx("USBFlashDriveBackupFolder")
110   strLiveDatabaseFilepath = LoggingDatabaseFilepath()

      Dim ws As DAO.Workspace
      'Dim db As Dao.database


120   fSuccess = True
130   Call Log_RecapturesSheet_Live(rec, strLiveDatabaseFilepath, fSuccess)

      ' If anything goes wrong, try once more to log, but this time step by step

140   If Not fSuccess Then

'           Validate that the utility variable USBFlashDriveBackupFolder isn't blank
'           Validate that the utility variable USBFlashDriveBackupFolder starts with letter : \
'           Validate that the external logging drive has a root folder
'           If the external logging folder does not exist then create it
'           Validate that the external logging folder exists
'           If the external logging database  does not exist, create it
'           Validate that the external logging database exists
'           Validate I can connect to the external logging database
'           Validate that the external logging database tables exist
'
'           Connect to the external logging database
'           Open a recordset to the logging table
'           Log the record


150       Call ValidateExternalLogging(strExternalLoggingError)
160           If strExternalLoggingError <> "" Then
170           GoTo Exit_label
180       End If
          
          ' Connect to the external logging database
              
190       Set ws = DBEngine.Workspaces(0)
          
200       Err.Clear
210       On Error Resume Next
220       Set db = ws.OpenDatabase(strLiveDatabaseFilepath)
230       If Err.Number <> 0 Then
240           strExternalLoggingError = "Failed to open a connection to the external logging database " & strLiveDatabaseFilepath
250           On Error GoTo Err_label
260           GoTo Exit_label
270       End If

          ' Open a recordset to the strBandsSheetLiveBackup table
          
280       On Error Resume Next
290       Set rst = db.OpenRecordset("tblCaptures_Log")
300       If Err.Number <> 0 Then
310           strExternalLoggingError = "Failed to connect to the " & "tblCaptures_Log" & " table in the external logging database"
320           db.Close
330           GoTo Exit_label
340       End If

          ' Log the recapture record
          
350       fSuccess = True
360       Call Log_RecapturesSheet_Live(rec, strLiveDatabaseFilepath, fSuccess) ' Write a logging record to the external database
370       If Not fSuccess Then
380           strExternalLoggingError = "Failed to write a logging record to the  " & "tblCaptures_Log" & " table in the external logging database"
390           On Error Resume Next
400           rst.Close
410           db.Close
420           On Error GoTo Err_label
430           GoTo Exit_label
440       End If
            
450       rst.Close
460       db.Close
          
470       Set rst = Nothing
480       Set db = Nothing
          
490   End If


          'DD Error Handler Start
Exit_label:
500       Exit Sub
Err_label:
510       Select Case Err.Number
          Case Else
520           Call LogError("basLiveBackup", "Log_RecapturesSheet")
530       End Select
540       Resume Exit_label
          ' DD Error Handler End
          
Err_live_label:
550       Select Case Err.Number
          Case Else
560           Call LogError("basLiveBackup", "Log_RecapturesSheet", Silent:=True)
570           MsgBox "Failed to write to the Live Data Entry database on a USB flash drive" & vbCrLf & vbCrLf & _
              CStr(Err.Number) & " " & Err.Description, vbOK + vbCritical, "Live Backup"

580       End Select
590       Resume Exit_label

End Sub

'---------------------------------------------------------------------------------------
' Log_Captures
'---------------------------------------------------------------------------------------
' DOES NOTHING
' --------------------------------------------------------------------------------------
' Log to the local tblCaptures_Log
' If external logging is on, log to tblCaptures_Log in the external logging database
'
' Called from
' frmCapturesEditOrDelete.UpdateCaptureRecord
' frmCapturesEditOrDelete.Store
' frmCapturesEditOrDelete.DeleteCapturesRecord
' frmSheetNewBandsMultiSize.NewBands_Store_v2
' frmSheetRecaps_v2.Recaps_Store_v2
'
' PRE:

' B.D(16)       has been filled in     Creation Timestamp
' B.D(17)       has been filled in     Modify Timestamp
' B.Command     has been filled in
' B.Source      has been filled in

Public Sub Log_Captures(ByRef B As CapturesType)
10     On Error GoTo Err_label

    GoTo Exit_label
    
      Dim rstCapturesLog As DAO.Recordset
      Dim uf As Integer
      Dim df As Integer

      ' Log to the local tblCaptures_Log


20    Set rstCapturesLog = CurrentDb.OpenRecordset("tblCaptures_Log", dbOpenDynaset)
         
30    rstCapturesLog.AddNew

40    rstCapturesLog("IDBand") = B.IDBand
50    rstCapturesLog("Disposition") = B.Disposition
60    rstCapturesLog("BandPrefix") = B.BandPrefix
70    rstCapturesLog("BandSuffix") = B.BandSuffix
80    rstCapturesLog("Species") = B.Species
90    rstCapturesLog("WingChord") = B.WingChord
100   rstCapturesLog("Age") = B.Age
110   rstCapturesLog("HowAged") = B.HowAged
120   rstCapturesLog("Sex") = B.Sex
130   rstCapturesLog("HowSexed") = B.HowSexed
140   rstCapturesLog("Fat") = B.Fat
150   rstCapturesLog("Weight") = B.Weight
160   rstCapturesLog("CaptureDate") = B.CaptureDate
170   rstCapturesLog("WeightTime") = B.WeightTime
180   rstCapturesLog("Bander") = B.Bander
190   rstCapturesLog("Scribe") = B.Scribe
200   rstCapturesLog("Net") = B.Net
210   rstCapturesLog("NotesForMBO") = B.NotesForMBO

220   rstCapturesLog("ToBeExported") = B.ToBeExported
230   rstCapturesLog("Valid") = B.Valid
240   rstCapturesLog("Invalid") = B.Invalid
250   rstCapturesLog("BypassErrors") = B.BypassErrors
260   rstCapturesLog("AutoHistory") = B.AutoHistory

270   rstCapturesLog("ProbableAge") = B.ProbableAge
280   rstCapturesLog("ProbableSex") = B.ProbableSex
290   rstCapturesLog("Location") = B.Location
300   rstCapturesLog("BirdStatus") = B.BirdStatus
310   rstCapturesLog("PresentCondition") = B.PresentCondition
320   rstCapturesLog("HowObtainedCode") = B.HowObtainedCode
330   rstCapturesLog("F") = B.FCombined
340   rstCapturesLog("Program") = B.Program

350   For uf = 1 To conMaxUserField
360       rstCapturesLog("F" & uf) = B.F(uf)
370   Next uf

380   rstCapturesLog("Flags") = B.Flags

390   For df = 1 To conMaxDataField
400       rstCapturesLog("D" & df) = B.D(df)
410   Next df

420   rstCapturesLog("Command") = B.Command
430   rstCapturesLog("Source") = B.Source

440   rstCapturesLog.Update

      Dim strLog As String

450   strLog = "tblCaptures #1: " & _
        " Command=" & B.Command & ", Source=" & B.Source & _
        ", Disposition=" & B.Disposition & ", Band=" & B.BandPrefix & "-" & B.BandSuffix & ", Species=" & B.Species & _
        ", CaptureDate=" & B.CaptureDate & _
        ", WeightTime=" & B.WeightTime & _
        ", Net=" & B.Net & _
        ", ToBeExported=" & B.ToBeExported & ", Valid=" & B.Valid & ", Invalid=" & B.Invalid
460   log (strLog)
470   strLog = "tblCaptures #2: " & _
        " BypassErrors=" & B.BypassErrors & ", AutoHistory=" & B.AutoHistory & _
        ", Location=" & B.Location & _
        ", D18 (DET Category)=" & B.D(18) & _
        ", D20 (Days since most recent prior capture)=" & B.D(20) & ", D21 (DET Date)=" & B.D(21)
480   log (strLog)
490   strLog = "tblCaptures #3: " & _
        " WingChord=" & B.WingChord & ", Age=" & B.Age & ", HowAged=" & B.HowAged & ", Sex=" & B.Sex & _
        ", HowSexed=" & B.HowSexed & ", Fat=" & B.Fat & ", Weight=" & B.Weight & _
        ", Bander=" & B.Bander & ", Scribe=" & B.Scribe & _
        ", NotesForMBO=" & B.NotesForMBO & ", ToBeExported=" & B.ToBeExported & ", Valid=" & B.Valid & ", Invalid=" & B.Invalid
500   log (strLog)
510   strLog = "tblCaptures #4: " & _
        " BypassErrors=" & B.BypassErrors & ", AutoHistory=" & B.AutoHistory & ", ProbableAge=" & B.ProbableAge & ", ProbableSex=" & B.ProbableSex & _
        ", BirdStatus=" & B.BirdStatus & ", PresentCondition=" & B.PresentCondition & ", HowObtainedCode=" & B.HowObtainedCode
520   log (strLog)
530   strLog = "tblCaptures #5: " & _
        " FCombined=" & B.FCombined & ", Program=" & B.Program & ", F1(Tail Length in mm)=" & B.F(1) & ", F2 (R2)=" & B.F(2) & _
        ", F3 (Eye Colour)=" & B.F(3) & ", F4 (R4)=" & B.F(4) & ", F5 (R5)=" & B.F(5) & ", F6 (R6)=" & B.F(6)
540   log (strLog)
550   strLog = "tblCaptures #6: " & _
        " F7 (Mouth Lining)=" & B.F(7) & ", F8 (Uppertail Covets)=" & B.F(8) & ", F9 (Skull) =" & B.F(9) & ", F10 (Spot length in mm)=" & B.F(10) & _
        ", F11 (Tail Colour)=" & B.F(11) & ", F12 (Spot Colour)=" & B.F(12) & ", F13 (Spot Designation)=" & B.F(13) & ", F14 (Covet Edging)=" & B.F(14)
560   log (strLog)
570   strLog = "tblCaptures #7: " & _
        " F15 (Tip R6 to brown flare)=" & B.F(15) & ", F16 (Orange Tips)=" & B.F(16) & ", F17 (Alula bars)=" & B.F(17) & ", F18 (Tarsus)=" & B.F(18) & ", F19 (Hummingbird band size)=" & B.F(19)
580   log (strLog)
590   strLog = "tblCaptures #8: " & _
        " D1 (Replacement Band Number for Disposition 5 captures)=" & B.D(1) & ", D2 (DET Category Override)=" & B.D(2)
600   log (strLog)
610   strLog = "tblCaptures #9: " & _
        " D3 (Aux Marker Type)=" & B.D(3) & ", D4 (Is Aux Marker Coded?)=" & B.D(4) & ", D5 (Aux Marker Code)=" & B.D(5) & ", D6 (Aux Marker Band Color)=" & B.D(6) & _
        ", D7 (Aux Marker Code Color)=" & B.D(7) & ", D8 (Left Leg Color 1)=" & B.D(8)
620   log (strLog)
630   strLog = "tblCaptures #10: " & _
        " D9 (xx)=" & B.D(9) & ", D10 (xx)=" & B.D(10) & _
        ", D11 (R Leg Color 1)=" & B.D(11) & ", D12 (R Leg Color 2)=" & B.D(12) & ", D13 (R Leg Color 3)=" & B.D(13) & ", D14 (Last Bandit Export Timestamp)=" & B.D(14)
640   log (strLog)
650   strLog = "tblCaptures #11: " & _
        " D15 (Count Bandit Exports)=" & B.D(15) & ", D16 (Creation Timestamp)=" & B.D(16) & ", D17(Modify Timestamp)=" & B.D(17) & _
        ", D18 (DET Category)=" & B.D(18)
660   log (strLog)
670   strLog = "tblCaptures #12: " & _
        " D19 (To Be Deleted) =" & B.D(19) & ", D20 (Days since most recent prior capture) =" & B.D(20) & ", D21(DET Date)=" & B.D(21)
680   log (strLog)

      ' Log to the external strBandsSheetLiveBackup

      Dim strDataEntrySource As String
      Dim db As DAO.Database

690   strDataEntrySource = GetDataEntrySource()
700   If strDataEntrySource <> "Live" Then GoTo Exit_label

      Dim strError As String

710   Set db = GetExternalLiveDataEntryDatabase(strError)
720   If db Is Nothing Then GoTo Exit_label

730   On Error GoTo Err_live_label

740   Set rstCapturesLog = db.OpenRecordset("tblCaptures_Log", dbOpenDynaset)
750   rstCapturesLog.AddNew
760   rstCapturesLog("IDBand") = B.IDBand
770   rstCapturesLog("Disposition") = B.Disposition
780   rstCapturesLog("BandPrefix") = B.BandPrefix
790   rstCapturesLog("BandSuffix") = B.BandSuffix
800   rstCapturesLog("Species") = B.Species
810   rstCapturesLog("WingChord") = B.WingChord
820   rstCapturesLog("Age") = B.Age
830   rstCapturesLog("HowAged") = B.HowAged
840   rstCapturesLog("Sex") = B.Sex
850   rstCapturesLog("HowSexed") = B.HowSexed
860   rstCapturesLog("Fat") = B.Fat
870   rstCapturesLog("Weight") = B.Weight
880   rstCapturesLog("CaptureDate") = B.CaptureDate
890   rstCapturesLog("WeightTime") = B.WeightTime
900   rstCapturesLog("Bander") = B.Bander
910   rstCapturesLog("Scribe") = B.Scribe
920   rstCapturesLog("Net") = B.Net
930   rstCapturesLog("NotesForMBO") = B.NotesForMBO

940   rstCapturesLog("ToBeExported") = B.ToBeExported
950   rstCapturesLog("Valid") = B.Valid
960   rstCapturesLog("Invalid") = B.Invalid
970   rstCapturesLog("BypassErrors") = B.BypassErrors
980   rstCapturesLog("AutoHistory") = B.AutoHistory

990   rstCapturesLog("ProbableAge") = B.ProbableAge
1000  rstCapturesLog("ProbableSex") = B.ProbableSex
1010  rstCapturesLog("Location") = B.Location
1020  rstCapturesLog("BirdStatus") = B.BirdStatus
1030  rstCapturesLog("PresentCondition") = B.PresentCondition
1040  rstCapturesLog("HowObtainedCode") = B.HowObtainedCode
1050  rstCapturesLog("F") = B.FCombined
1060  rstCapturesLog("Program") = B.Program

1070  For uf = 1 To conMaxUserField
1080      rstCapturesLog("F" & uf) = B.F(uf)
1090  Next uf

1100  rstCapturesLog("Flags") = B.Flags

1110  For df = 1 To conMaxDataField
1120      rstCapturesLog("D" & df) = B.D(df)
1130  Next df

1140  rstCapturesLog("Command") = B.Command
1150  rstCapturesLog("Source") = B.Source

1160  rstCapturesLog.Update
1170  rstCapturesLog.Close
1180  Set rstCapturesLog = Nothing

      'If IsLoaded("frmSheetRecaps_v2") Then
      'On Error Resume Next
      '    Forms("frmSheetRecaps_v2").Controls("txtCountLiveBackupDatabaseTransactions") = Forms("frmSheetRecaps_v2").Controls("txtCountLiveBackupDatabaseTransactions") + 1
      'On Error GoTo Err_label
      'End If

1190  db.Close
1200  Set db = Nothing

          'DD Error Handler Start
Exit_label:
1210      Exit Sub
Err_label:
1220      Select Case Err.Number
          Case Else
1230     Call LogError("basLiveBackup", "Log_Captures")
1240      End Select
1250      Resume Exit_label
          ' DD Error Handler End
          
Err_live_label:
1260      Select Case Err.Number
          Case Else
1270    Call LogError("basLiveBackup", "Log_Captures", Silent:=False)
1280    MsgBox "Failed to write to the Live Data Entry database on a USB flash drive" & vbCrLf & vbCrLf & _
      CStr(Err.Number) & " " & Err.Description, vbOK + vbCritical, "Live Backup"

1290      End Select
1300      Resume Exit_label

End Sub

'--------------------------------------------------------------------------------------------------------
' Log_DETDaily
'
' Logs a single DET Daily Add, Update and Delete transaction
' The caller must fill in all the data fields, Command, and Source. This procedure fills in the Timestamp
' Transactions are logged to a local table - strDETDailyLiveBackup
' During "live" data entry, the transactions are also logged to corresponding table on an external drive


'Public Type DETDailyType
'    Program          As String
'    Location         As String
'    DateEx           As Date
'    Observers        As Variant     ' Observer effort
'    SongbirdNets     As Variant
'    NonSongbirdNets  As Variant
'    JTrap            As Variant
'    OtherTrap        As Variant     ' Hummingbird effort
'    Heliogoland      As Variant
'    VisibleMigration As Variant
'    CoverageCode     As Variant
'    Timestamp        As Date
'    Command          As String
'    Source           As String
'End Type


'--------------------------------------------------------------------------------------------------------

'---------------------------------------------------------------------------------------
' Log_DETDaily
'---------------------------------------------------------------------------------------
' Currently not used

Public Sub Log_DETDaily(ByRef rec As DETDailyType)

10    GoTo Exit_label

Dim rst As DAO.Recordset
Dim db As DAO.Database
Dim datTimestamp As Date
Dim strDataEntrySource As String

20    On Error GoTo Err_label

30    GoTo Exit_label

40    datTimestamp = Now()

' Log to the local tblDETDaily_Log

50    Set rst = CurrentDb.OpenRecordset(strDETDailyLiveBackup)
60    rst.AddNew
70    rst("Program") = rec.Program
80    rst("Location") = rec.Location
90    rst("DateEx") = rec.DateEx
100   rst("Observers") = rec.Observers
110   rst("SongbirdNets") = rec.SongbirdNets
120   rst("NonSongbirdNets") = rec.NonSongbirdNets
130   rst("JTrap") = rec.JTrap
140   rst("OtherTrap") = rec.OtherTrap
150   rst("Heliogoland") = rec.Heliogoland
160   rst("VisibleMigration") = rec.VisibleMigration
170   rst("CoverageCode") = rec.CoverageCode
180   rst("Timestamp") = datTimestamp
190   rst("Command") = rec.Command
200   rst("Source") = rec.Source
210   rst("IDLog") = rec.IDLog
220   rst.Update
230   rst.Close
240   Set rst = Nothing

Dim strLog As String

250   strLog = "tblDETDaily: Command=" & rec.Command & ", Source=" & rec.Source & ", Program=" & rec.Program & ", Location=" & rec.Location & _
        ", DETDate=" & rec.DateEx & ", Observers=" & rec.Observers & ", SongbirdNets=" & rec.SongbirdNets & ", OtherTrap(Hummingbird)=" & rec.OtherTrap & _
        ", CoverageCode=" & rec.CoverageCode
260   log (strLog)

' Log to the external tblDETDaily_Log

270   strDataEntrySource = GetDataEntrySource()
280   If strDataEntrySource <> "Live" Then GoTo Exit_label
      Dim strError As String

290   Set db = GetExternalLiveDataEntryDatabase(strError)
300   If db Is Nothing Then GoTo Exit_label

310   On Error GoTo Err_live_label

320   Set rst = db.OpenRecordset(strDETDailyLiveBackup)
330   rst.AddNew
340   rst("Program") = rec.Program
350   rst("Location") = rec.Location
360   rst("DateEx") = rec.DateEx
370   rst("Observers") = rec.Observers
380   rst("SongbirdNets") = rec.SongbirdNets
390   rst("NonSongbirdNets") = rec.NonSongbirdNets
400   rst("JTrap") = rec.JTrap
410   rst("OtherTrap") = rec.OtherTrap
420   rst("Heliogoland") = rec.Heliogoland
430   rst("VisibleMigration") = rec.VisibleMigration
440   rst("CoverageCode") = rec.CoverageCode
450   rst("Timestamp") = datTimestamp
460   rst("Command") = rec.Command
470   rst("Source") = rec.Source
480   rst("IDLog") = rec.IDLog
490   rst.Update
500   rst.Close
510   Set rst = Nothing


520   db.Close

530   Set db = Nothing



    
Err_live_label:
540       Select Case Err.Number
    Case Else
550      Call LogError("basLiveBackup", "Log_DETSpecies", Silent:=True)
560      MsgBox "Failed to connect to the Live Data Entry database a USB flash drive" & vbCrLf & vbCrLf & _
            "Please use the Summary command button to save the whole DET sheet to a USB flash drive" & vbCrLf & vbCrLf & _
            CStr(Err.Number) & " " & Err.Description, vbOK + vbCritical, "Live Backup"

570       End Select
580       Resume Exit_label

    'DD Error Handler Start
Exit_label:
590       Exit Sub
Err_label:
600       Select Case Err.Number
    Case Else
610      Call LogError("basLiveBackup", "Log_DETDaily")
620       End Select
630       Resume Exit_label
    ' DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' Log_DETSpecies
'---------------------------------------------------------------------------------------
' Currently not used

' Logs a single DET Species Add, Update and Delete ALL transaction.
' The caller must fill in all the data fields, Command, and Source. This procedure fills in the Timestamp
' Transactions are logged to a local table - strDETDailyLiveBackup
' During "live" data entry, the transactions are also logged to corresponding table on an external drive

Public Sub Log_DETSpecies(ByRef rec As DETSpeciesType)

10    GoTo Exit_label

Dim rst As DAO.Recordset
Dim db As DAO.Database
Dim datTimestamp As Date
Dim strDataEntrySource As String

20    On Error GoTo Err_label



30    datTimestamp = Now()

' Log to the local tblDETSpecies_log

40    Set rst = CurrentDb.OpenRecordset(strDETSpeciesLiveBackup)
50    rst.AddNew
60    rst("Program") = rec.Program
70    rst("Location") = rec.Location
80    rst("DateEx") = rec.DateEx
90    rst("Species") = rec.Species
100   rst("Observed") = rec.Observed
110   rst("Census") = rec.Census
120   rst("Banded") = rec.Banded
130   rst("Repeats") = rec.Repeats
140   rst("Returns") = rec.Returns
150   rst("PKS") = rec.PKS
160   rst("DET") = rec.DET
170   rst("VisibleEx") = rec.VisibleEx
180   rst("Casual") = rec.Casual
190   rst("Observed3") = rec.Observed3
200   rst("Observed4") = rec.Observed4
210   rst("NonStandardBanded") = rec.NonStandardBanded
220   rst("NonStandardRecaps") = rec.NonStandardRecaps
230   rst("DailySpeciesTotal") = rec.DailySpeciesTotal
240   rst("Timestamp") = datTimestamp
250   rst("Command") = rec.Command
260   rst("Source") = rec.Source
270   rst("IDLog") = rec.IDLog
280   rst.Update
290   rst.Close
300   Set rst = Nothing

Dim strLog As String

310   strLog = "tblDETSpecies: Command=" & rec.Command & ", Source=" & rec.Source & ", Program=" & rec.Program & ", Location=" & rec.Location & _
        ", DETDate=" & rec.DateEx & ", Observed=" & rec.Observed & ", Census=" & rec.Census & ", Banded=" & rec.Banded & _
        ", Repeats=" & rec.Repeats & ", Returns=" & rec.Returns & ", DET=" & rec.DET & ", Observed3(Alien)=" & rec.Observed3 & _
        ", Observed4(Replacement)=" & rec.Observed4
320   log (strLog)

' Log to the external tblDETSpecies_Log

330   strDataEntrySource = GetDataEntrySource()
340   If strDataEntrySource <> "Live" Then GoTo Exit_label
      Dim strError As String

350   Set db = GetExternalLiveDataEntryDatabase(strError)
360   If db Is Nothing Then GoTo Exit_label

370   On Error GoTo Err_live_label

380   Set rst = db.OpenRecordset(strDETSpeciesLiveBackup)
390   rst.AddNew
400   rst("Program") = rec.Program
410   rst("Location") = rec.Location
420   rst("DateEx") = rec.DateEx
430   rst("Species") = rec.Species
440   rst("Observed") = rec.Observed
450   rst("Census") = rec.Census
460   rst("Banded") = rec.Banded
470   rst("Repeats") = rec.Repeats
480   rst("Returns") = rec.Returns
490   rst("PKS") = rec.PKS
500   rst("DET") = rec.DET
510   rst("VisibleEx") = rec.VisibleEx
520   rst("Casual") = rec.Casual
530   rst("Observed3") = rec.Observed3
540   rst("Observed4") = rec.Observed4
550   rst("NonStandardBanded") = rec.NonStandardBanded
560   rst("NonStandardRecaps") = rec.NonStandardRecaps
570   rst("DailySpeciesTotal") = rec.DailySpeciesTotal
580   rst("Timestamp") = datTimestamp
590   rst("Command") = rec.Command
600   rst("Source") = rec.Source
610   rst("IDLog") = rec.IDLog
620   rst.Update
630   rst.Close
640   Set rst = Nothing


650   db.Close

660   Set db = Nothing

    'DD Error Handler Start
Exit_label:
670       Exit Sub
Err_label:
680       Select Case Err.Number
    Case Else
690      Call LogError("basLiveBackup", "Log_DETSpecies")
700       End Select
710       Resume Exit_label
    ' DD Error Handler End
    
Err_live_label:
720       Select Case Err.Number
    Case Else
730      Call LogError("basLiveBackup", "Log_AddDETSpecies", Silent:=True)
740      MsgBox "Failed to connect to the Live Data Entry database ono a USB flash drive" & vbCrLf & vbCrLf & _
            "Please use the Summary command button to save the whole DET sheet to a USB flash drive" & vbCrLf & vbCrLf & _
            CStr(Err.Number) & " " & Err.Description, vbOK + vbCritical, "Live Backup"

750       End Select
760       Resume Exit_label

End Sub

'---------------------------------------------------------------------------------------
' Log_DETNetHours
'
' db is the external database
' Logs a single DET Net Hours Add, Update and Delete transaction.
' The caller must fill in all the data fields, Command, and Source. This procedure fills in the Timestamp
' Transactions are logged to a local table - strDETDailyLiveBackup
' During "live" data entry, the transactions are also logged to corresponding table on an external drive
'------------------------------------------------------------------------------------------------------
' Curently not used

Public Sub Log_DETNetHours(ByRef recNetHours As DETNetHoursType)

10    GoTo Exit_label

      Dim strDataEntrySource As String
      Dim rst As DAO.Recordset
      Dim db As DAO.Database
      
20    On Error GoTo Err_label

30    recNetHours.Timestamp = Now()

' Log to the local tblDETNetHours_Log

40    Set rst = CurrentDb.OpenRecordset(strDETNetHoursLiveBackup)
50    rst.AddNew
60    rst("Program") = recNetHours.Program
70    rst("Location") = recNetHours.Location
80    rst("DateEx") = recNetHours.DateEx
90    rst("NetID") = recNetHours.NetID
100   rst("NetHours") = recNetHours.NetHours
110   rst("Timestamp") = recNetHours.Timestamp
120   rst("Command") = recNetHours.Command
130   rst("Source") = recNetHours.Source
140   rst("IDLog") = recNetHours.IDLog
150   rst.Update
160   rst.Close
170   Set rst = Nothing

Dim strLog As String

180   strLog = "tblDETNetHours: Command=" & recNetHours.Command & ", Source=" & recNetHours.Source & ", Program=" & recNetHours.Program & ", Location=" & recNetHours.Location & _
        ", DETDate=" & recNetHours.DateEx & ", NetID=" & recNetHours.NetID & ", NetHours=" & recNetHours.NetHours
190   log (strLog)
    

' Log to the external tblDETNetHours_Log

200   strDataEntrySource = GetDataEntrySource()
210   If strDataEntrySource <> "Live" Then GoTo Exit_label

      Dim strError As String

220   Set db = GetExternalLiveDataEntryDatabase(strError)
230   If db Is Nothing Then GoTo Exit_label


240   On Error GoTo Err_live_label

250   Set rst = db.OpenRecordset(strDETNetHoursLiveBackup)
260   rst.AddNew
270   rst("Program") = recNetHours.Program
280   rst("Location") = recNetHours.Location
290   rst("DateEx") = recNetHours.DateEx
300   rst("NetID") = recNetHours.NetID
310   rst("NetHours") = recNetHours.NetHours
320   rst("Timestamp") = recNetHours.Timestamp
330   rst("Command") = recNetHours.Command
340   rst("Source") = recNetHours.Source
350   rst("IDLog") = recNetHours.IDLog
360   rst.Update
370   rst.Close
380   Set rst = Nothing

390   db.Close

400   Set db = Nothing

    'DD Error Handler Start
Exit_label:
410       Exit Sub
Err_label:
420       Select Case Err.Number
    Case Else
430      Call LogError("basLiveBackup", "Log_DETNetHours")
440       End Select
450       Resume Exit_label
    ' DD Error Handler End
    
Err_live_label:
460       Select Case Err.Number
          Case Else
470            Call LogError("basLiveBackup", "Log_DETNetHours", Silent:=True)
480            MsgBox "Failed to connect to the Live Data Entry database on a USB flash drive" & vbCrLf & vbCrLf & _
                  "Please use the Summary command button to save the whole DET sheet to a USB flash drive" & vbCrLf & vbCrLf & _
                  CStr(Err.Number) & " " & Err.Description, vbOK + vbCritical, "Live Backup"

490       End Select
500       Resume Exit_label

End Sub

'---------------------------------------------------------------------------------------
' getLiveBackupFolder
'---------------------------------------------------------------------------------------
' Returns the data entry source "Live" or "FromSheet"
' If "Live", also returns the folderpath to the external Live backup folder

Private Sub getLiveBackupFolder(ByRef strDataEntrySource As String, ByRef strLiveBackupFolder As String)

10    On Error GoTo Err_label

      ' Loop until data entry source is not Live OR
      '            ( data entry source is Live AND the Live backup folder is found )


20    strDataEntrySource = GetDataEntrySource()
30    If strDataEntrySource <> "Live" Then GoTo Exit_label
40    strLiveBackupFolder = GetSettingEx("USBFlashDriveBackupFolder")


50    Do While Not FolderExists(strLiveBackupFolder)
          
60        DoCmd.OpenForm "frmLiveBackupFolderpath", acNormal, , , , acDialog

70        strDataEntrySource = GetDataEntrySource()
80        If strDataEntrySource <> "Live" Then
              
              ' Update the cboDataEntrySource on frmDETViewDaily2
              
90            If IsLoaded("frmDETViewDaily2") Then
100               Forms("frmDETViewDaily2").Controls("cboDataEntrySource") = "FromSheets"
110           End If
              
120           GoTo Exit_label
130       End If
140       strLiveBackupFolder = GetSettingEx("USBFlashDriveBackupFolder")
          
150   Loop

          'DD Error Handler Start
Exit_label:
160       Exit Sub
Err_label:
170       Select Case Err.Number
          Case Else
180            Call LogError("basLiveBackup", "getLiveBackupFolder")
190       End Select
200       Resume Exit_label
          ' DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' ValidateExternalLoggingDatabaseTablesWriteRead
'---------------------------------------------------------------------------------------

Private Sub ValidateExternalLoggingDatabaseTablesWriteRead(ByRef db As DAO.Database, ByRef strError As String)

      Dim rst As DAO.Recordset
      Dim strLiveBackup(0 To 0) As String
      Dim i As Integer
      Dim strSQL As String

10    On Error GoTo Err_label

20    strError = ""

30    strLiveBackup(0) = "tblCaptures_Log"


40    For i = 0 To 0

          ' Write a test log record
          Dim strModifyTimestamp As String
50        strModifyTimestamp = GetTimestamp
          
60        Set rst = db.OpenRecordset(strLiveBackup(i), dbOpenDynaset)
70        rst.AddNew
80        rst("Command") = "Test"
90        rst("D17") = strModifyTimestamp
100       rst.Update
110       rst.Close
120       Set rst = Nothing
          
          ' Read the test log record
          
130       strSQL = _
              "SELECT * FROM " & strLiveBackup(i) & " WHERE D17 = '" & strModifyTimestamp & "'"
              
140       Set rst = db.OpenRecordset(strSQL, dbOpenDynaset)
          
150       If rst.EOF Then
160           If Len(strError) <> 0 Then
170               strError = strError & vbCrLf
180           End If
190           strError = strError & "Failed to write to " & strLiveBackup(i)
200       End If
          
210       rst.Close
220       Set rst = Nothing
          
230   Next
          
          'DD Error Handler Start
Exit_label:
240       Exit Sub
Err_label:
250       Select Case Err.Number
          Case Else
260            Call LogError("basLiveBackup", "ValidateExternalLoggingDatabaseTablesWriteRead")
270       End Select
280       Resume Exit_label
          ' DD Error Handler End

End Sub

Private Sub CreateLoggingDatabase(ByVal strLiveDatabaseFilepath As String, ByRef strError As String)

      Dim ws As DAO.Workspace
      Dim db As DAO.Database

10    On Error GoTo Err_label

20    strError = ""

30    Set ws = DBEngine.Workspaces(0)

40    If Not FileExists(strLiveDatabaseFilepath) Then

50        Err.Clear
60        On Error Resume Next
70        Set db = ws.CreateDatabase(strLiveDatabaseFilepath, dbLangGeneral)
80        If Err.Number <> 0 Then
90             strError = "Failed to create the external logging database " & strLiveDatabaseFilepath

100            GoTo Exit_label
110       End If
120       On Error Resume Next
          

130       DoCmd.TransferDatabase acExport, "Microsoft Access", strLiveDatabaseFilepath, acTable, "tblCaptures_Log", "tblCaptures_Log", StructureOnly:=True

140       db.Close
150       Set db = Nothing
160   End If

          'DD Error Handler Start
Exit_label:
170       Exit Sub
Err_label:
180       Select Case Err.Number
          Case Else
190           strError = "Failed to create all the tables in the external logging database " & strLiveDatabaseFilepath

200            GoTo Exit_label
210       End Select
220       Resume Exit_label
          ' DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' TurnOffExternalLogging
'---------------------------------------------------------------------------------------

Public Sub TurnOffExternalLogging()

10    On Error GoTo Err_label

      Dim strDataEntrySource As String

20    strDataEntrySource = "FromSheets"
30    Call PutDataEntrySource(strDataEntrySource)

          'DD Error Handler Start
Exit_label:
40        Exit Sub
Err_label:
50        Select Case Err.Number
          Case Else
60       Call LogError("basLiveBackup", "TurnOffExternalLogging")
70        End Select
80        Resume Exit_label
          ' DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' ValidateExternalLoggingDatabaseSchema
'---------------------------------------------------------------------------------------
' Called from:
' bas.LiveBackup.GetExternalLiveDataEntryDatabase
' basLiveBackup.ValidateExternalLoging
' frmDataEntryLogsRepair.cmdDeleteOldDataEntryLoggingRecords_Click()

' I check that the tables exist
' I do not check if the tables have the correct fields ...

Public Sub ValidateExternalLoggingDatabaseSchema(ByRef db As DAO.Database, ByVal strLiveDatabaseFilepath As String, ByRef strError As String)

10    On Error GoTo Err_label

      ' verify the tables exist

20    strError = ""
      Dim td As DAO.TableDef

30    Set td = db.TableDefs("tblCaptures_Log")
          
          'DD Error Handler Start
Exit_label:
40        Exit Sub
Err_label:
50        Select Case Err.Number
          Case Else
60        strError = "The external logging database is missing one or more tables " & strLiveDatabaseFilepath & vbCrLf & _
                     "If you think the external logging database might have useful data in it, then rename it." & vbCrLf & _
                     "If you are certain it doesn't, them simply delete it." & vbCrLf & _
                     "Either way, the MBO Database program will create a new empty logging database the next time you turn on logging to an external database." & vbCrLf & _
                     "External logging has been turned OFF"
70        GoTo Exit_label
80        End Select
90        Resume Exit_label
          ' DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' GetDriveLetterFromPath
'---------------------------------------------------------------------------------------
' Returns the drive letter in upper case
' If the path does not begin with a valid drive prefix, return ""                 Valid drive prefix:  letter ":"
' The path can be a folderpath or a filepath
' Returns "" for share names or network paths


Public Function GetDriveLetterFromPath(ByVal strPath) As String

      Dim strDriveLetter As String
      
10    On Error GoTo Err_label

20    GetDriveLetterFromPath = ""

      ' Validate drive prefix:    letter ":"
      ' Extract drive letter

30    If Len(strPath) < 2 Then GoTo Exit_label
40    strDriveLetter = UCase(Left(strPath, 1))
50    If strDriveLetter < "A" Or strDriveLetter > "Z" Then GoTo Exit_label
60    If Mid(strPath, 2, 1) <> ":" Then GoTo Exit_label

70    GetDriveLetterFromPath = strDriveLetter

    'DD Error Handler Start
Exit_label:
80        Exit Function
Err_label:
90        Select Case Err.Number
    Case Else
100      Call LogError("basLiveBackup", "GetDriveLetterFromPath")
110       End Select
120       Resume Exit_label
    ' DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' IsFolderOnRemovableDrive
'---------------------------------------------------------------------------------------
' Returns true if the folderpath begins with a valid drive prefix AND the drive is removable

Public Function IsFolderOnRemovableDrive(ByVal strFolderpath As String, ByRef fValidDrivePrefix As Boolean) As Boolean

      Dim strDriveLetter As String
      Dim fso As Scripting.FileSystemObject
      Dim drive As Scripting.drive

10    On Error GoTo Err_label

20    strDriveLetter = GetDriveLetterFromPath(strFolderpath)
30    If strDriveLetter = "" Then
40        fValidDrivePrefix = False
50        IsFolderOnRemovableDrive = False
60    Else

          ' Is the drive removable?
          
70        fValidDrivePrefix = True
80        Set fso = New Scripting.FileSystemObject
90        Set drive = fso.GetDrive(strDriveLetter)
100       IsFolderOnRemovableDrive = (drive.DriveType = 1)   ' 1 = removable

110   End If

      'DD Error Handler Start
Exit_label:
120       Exit Function
Err_label:
130       Select Case Err.Number
          Case Else
140            Call LogError("basLiveBackup", "IsFolderOnRemovableDrive")
150       End Select
160       Resume Exit_label
          ' DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' ValidateExternalBackupFolder
'---------------------------------------------------------------------------------------
' Dim strError As String)
' Call ValidateExternalBackupFolder( strFolderpath, strError)

Public Sub ValidateExternalBackupFolder(ByRef strFolderpath As String, ByRef strError As String)

10    On Error GoTo Err_label

      '     Validate that the external backup drive has a root folder
      '     If the external backup folder does not exist then create it
          
20    If Not ValidateExternalDriveHasARootFolder(strFolderpath) Then
30        strError = "Failed to find a root folder on the external backup drive"
40        GoTo Exit_label
50    End If

60    If Not ValidateExternalDriveHasALoggingFolder(strFolderpath) Then
70        strError = "Failed to create  the external logging folder"
80        GoTo Exit_label
90    End If

          'DD Error Handler Start
Exit_label:
100       Exit Sub
Err_label:
110       Select Case Err.Number
          Case Else
120            Call LogError("basLiveBackup", "ValidateExternalBackupFolder")
130       End Select
140       Resume Exit_label
          ' DD Error Handler End

End Sub
