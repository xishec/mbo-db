Option Compare Database
Option Explicit

' Parameters that are passed when forms are opened from openform
' Access only allows one 'OpenArg' parameter, so I shall
' pass multiple parameters via these global variables

' frmTop10DETReport
' -----------------
' argProgram
' argLocation


Public argDETReports_Program  As String
Public argDETReports_Location As String
Public argDETReports_Date     As Date

' Parameters when opening frmDETHours

Public argDETNetHours_Program As String
Public argDETNetHours_Location As String
Public argDETNetHours_DateEx As Date

' Parameters when opening frmVolunteeersByWeekFrame_v2

Public argVolunteersByWeek_Program As String
Public argVolunteersByWeek_Year As Integer
Public argVolunteersByWeek_Season As String
Public argVolunteersByWeek_Location As String
Public argVolunteersByWeek_Period As Integer
Public argVolunteersByWeek_FromDate As Date
Public argVolunteersByWeek_ToDate As Date

' Parameters when opening frmDeleteSheet, frmMoveSheet

Public argDET_Program As String
Public argDET_Location As String
Public argDET_DateEx As Date
