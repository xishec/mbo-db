'---------------------------------------------------------------------------------------
' Module    : basExport
' Author    : David Davey
'---------------------------------------------------------------------------------------

Option Compare Database
Option Explicit

Public Sub SaveCloseQuit( _
    ByVal strLocation As String, _
    ByVal intYear As Integer, _
    ByVal strSeason As String, _
    ByVal strFilename As String, _
    ByRef oExcel As Excel.Application, _
    ByRef oBook As Excel.Workbook)
        
      ' Construct the filepath

      Dim strFolder As String
10    On Error GoTo Err_label

20    strFolder = GetExportFolder()
30    If strFolder = "" Then
40        strFolder = Rep_Documents()
50    End If

      Dim strSaveFilename As String
60    strSaveFilename = _
          strLocation & " " & Format(intYear, "0000") & " " & strSeason & " " & _
          strFilename
           Dim strSaveFilepath As String
      Dim fValid As Boolean
70    fValid = True
80    Call SaveAndCloseExcelWorkbook(oExcel, oBook, strSaveFilename, fValid, strSaveFilepath)
90    Call OpenExcelWorkbook(strSaveFilepath)


      'DD Error Handler Start
Exit_label:
100        Exit Sub
Err_label:
110        Select Case Err.Number
           Case Else
120       Call LogError("basExport", "SaveCloseQuit")
130        End Select
140        Resume Exit_label
      'DD Error Handler End
          
End Sub


'---------------------------------------------------------------------------------------
' GeneralExport( ByVal fCapturesOnly := False )
'---------------------------------------------------------------------------------------
' Called from frmMainMenu.cmdGeneralExport_Click
'
' Call GeneralExport(fCapturesOnly:= True)
' Call GeneralExport()
'
' Export tblCaptures, DET, Encounters, Volunteers to Excel

Public Sub GeneralExport(Optional ByVal fCapturesOnly As Boolean = False)

10    On Error GoTo Err_label

      Dim strExportFolder As String
      Dim strFilename As String
      Dim strFilepath As String
      Dim strFolderpath As String

20    strExportFolder = GetExportFolder()

30    strFilename = Format(Now, "yyyy-mm-dd hh\hnn\mss") & " General Export" & ".xlsx"
40    strFilepath = TrailingSlash(strExportFolder) & strFilename
50    strFilepath = FileSaveDialogExcel(strFilename, strExportFolder, "")
60    If strFilepath <> "" Then
70        strFolderpath = FolderFromPath(strFilepath)
80        Call PutExportFolder(strFolderpath)
90    Else
100       GoTo Exit_label
110   End If

      Dim strSQL As String
      Dim lngErrNumber As Long
      Dim strErrDescription As String
      Dim strSheetName As String

120   SysCmd acSysCmdSetStatus, "Exporting Captures to Excel ..."
130   DoEvents

140   strSQL = "tblCaptures"
150   strSheetName = "Captures"
160   Call Export2ExcelA(strFilepath, strSQL, strSheetName, lngErrNumber, strErrDescription)
170   If lngErrNumber <> 0 Or strErrDescription <> "" Then
180       MsgBox "FAILED to export the captures table" & vbCrLf & strErrDescription, vbExclamation, "General Export"
190       GoTo Exit_label
200   End If

210   If Not fCapturesOnly Then

220       SysCmd acSysCmdSetStatus, "Exporting DET Daily to Excel ..."
230       DoEvents
          
240       strSQL = "tblDETDaily"
250       strSheetName = "DETDaily"
260       Call Export2ExcelA(strFilepath, strSQL, strSheetName, lngErrNumber, strErrDescription)
270       If lngErrNumber <> 0 Or strErrDescription <> "" Then
280           MsgBox "FAILED to export the DET Daily table" & vbCrLf & strErrDescription, vbExclamation, "General Export"
290           GoTo Exit_label
300       End If
          
310       SysCmd acSysCmdSetStatus, "Exporting DET Species to Excel ..."
320       DoEvents
          
330       strSQL = "tblDETSpecies"
340       strSheetName = "DETSpecies"
350       Call Export2ExcelA(strFilepath, strSQL, strSheetName, lngErrNumber, strErrDescription)
360       If lngErrNumber <> 0 Or strErrDescription <> "" Then
370           MsgBox "FAILED to export the DET Daily table" & vbCrLf & strErrDescription, vbExclamation, "General Export"
380           GoTo Exit_label
390       End If
          
400       SysCmd acSysCmdSetStatus, "Exporting DET Net Hours to Excel ..."
410       DoEvents
          
420       strSQL = "tblDETNetHours"
430       strSheetName = "DETNETHours"
440       Call Export2ExcelA(strFilepath, strSQL, strSheetName, lngErrNumber, strErrDescription)
450       If lngErrNumber <> 0 Or strErrDescription <> "" Then
460           MsgBox "FAILED to export the DET Daily table" & vbCrLf & strErrDescription, vbExclamation, "General Export"
470           GoTo Exit_label
480       End If

490       SysCmd acSysCmdSetStatus, "Exporting Encounters to Excel ..."
500       DoEvents
          
510       strSQL = "tblEncounters"
520       strSheetName = "Encounters"
530       Call Export2ExcelA(strFilepath, strSQL, strSheetName, lngErrNumber, strErrDescription)
540       If lngErrNumber <> 0 Or strErrDescription <> "" Then
550           MsgBox "FAILED to export the DET Daily table" & vbCrLf & strErrDescription, vbExclamation, "General Export"
560           GoTo Exit_label
570       End If
          
580       SysCmd acSysCmdSetStatus, "Exporting Volunteers to Excel ..."
590       DoEvents
          
600       strSQL = "tblVolunteers"
610       strSheetName = "Volunteers"
620       Call Export2ExcelA(strFilepath, strSQL, strSheetName, lngErrNumber, strErrDescription)
630       If lngErrNumber <> 0 Or strErrDescription <> "" Then
640           MsgBox "FAILED to export the DET Daily table" & vbCrLf & strErrDescription, vbExclamation, "General Export"
650           GoTo Exit_label
660       End If
          
670       strSQL = "tblVolunteers_x_Years_Overrides"
680       strSheetName = "Volunteers_x_Years_Overrides"
690       Call Export2ExcelA(strFilepath, strSQL, strSheetName, lngErrNumber, strErrDescription)
700       If lngErrNumber <> 0 Or strErrDescription <> "" Then
710           MsgBox "FAILED to export the DET Daily table" & vbCrLf & strErrDescription, vbExclamation, "General Export"
720           GoTo Exit_label
730       End If
          
740       strSQL = "tblVolunteersByWeek"
750       strSheetName = "VolunteersByWeek"
760       Call Export2ExcelA(strFilepath, strSQL, strSheetName, lngErrNumber, strErrDescription)
770       If lngErrNumber <> 0 Or strErrDescription <> "" Then
780           MsgBox "FAILED to export the DET Daily table" & vbCrLf & strErrDescription, vbExclamation, "General Export"
790           GoTo Exit_label
800       End If

810   End If

820   SysCmd acSysCmdClearStatus
830   DoEvents

840   Call OpenExcelWorkbook(strFilepath)

      '      ' Open the Excel workbook
      '      ' For some reason, Excel has to be visible - I don't care
      '
      '      Dim oExcel As Excel.Application
      '      Dim oBook As Excel.Workbook
      '      Dim oSheet As Excel.Worksheet
      '
      '210   Set oExcel = New Excel.Application
      '220   oExcel.Visible = True
      '
      '230   On Error Resume Next
      '240   Set oBook = oExcel.Workbooks.Open(strFilepath)
      '250   If Err.Number <> 0 Then
      '260       oExcel.Quit
      '270       Set oExcel = Nothing
      '280       GoTo Exit_label
      '290   End If
      '
      '      ' Open the "Captures" worksheet
      '
      '      Dim intSheet As Integer
      '      Dim fSheetExists As Boolean
      '
      '300   fSheetExists = False
      '310   For intSheet = 1 To oBook.Sheets.count
      '320       If oBook.Sheets(intSheet).Name = "Captures" Then
      '330           Set oSheet = oBook.Sheets(intSheet)
      '340           fSheetExists = True
      '350           Exit For
      '360       End If
      '370   Next
      '
      '380   If Not fSheetExists Then
      '390       oExcel.Quit
      '400       Set oExcel = Nothing
      '410       GoTo Exit_label
      '420   End If
      '
      '      ' Save the Excel Workbook
      '
      '430   oBook.Close saveChanges:=True, FileName:=strFilepath
      '
      '440   Set oBook = Nothing
      '450   oExcel.Quit
      '460   Set oExcel = Nothing

          'DD Error Handler Start
Exit_label:
850       Exit Sub
Err_label:
860       Select Case Err.Number
          Case Else
870      Call LogError("basExport", "GeneralExport")
880       End Select
890       Resume Exit_label
          ' DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' Export2ExcelA
'---------------------------------------------------------------------------------------
' Dim lngErrNumber as long
' Dim strErrDescription as string
' Call Export2ExcelA(strFilepath, strSQL, strSheetName, ErrNumber, ErrDescription, strSheetName)

Public Sub Export2ExcelA(ByVal strFilepath As String, ByVal strSQL As String, strSheetName As String, lngErrNumber As Long, strErrDescription As String)
10    On Error GoTo Err_label

      Dim oBook As Excel.Workbook

20    lngErrNumber = 0
30    strErrDescription = ""

40    If Len(Dir(strFilepath)) = 0 Then

50        Set oBook = Excel.Workbooks.Add
60        Call ExcelDeleteAllButFirstWorksheet(oBook)
70        oBook.SaveAs strFilepath
80        oBook.Close
90    End If

110   DoCmd.TransferSpreadsheet acExport, acSpreadsheetTypeExcel12Xml, strSQL, strFilepath, True
120   lngErrNumber = Err.Number
130   If lngErrNumber <> 0 Then
140       strErrDescription = Err.Description
150       GoTo Exit_label
160   End If
         

          'DD Error Handler Start
Exit_label:
180       Exit Sub
Err_label:
190       Select Case Err.Number
          Case Else
200         lngErrNumber = Err.Number
210         strErrDescription = Err.Description
      ' 200      Call LogError("basExport", "GeneralExport")
220       End Select
230       Resume Exit_label
          ' DD Error Handler End
End Sub
