'---------------------------------------------------------------------------------------
' Module    : basMBOAnnualProgramReport_Top10SpeciesBanded
' Author    : David Davey
'---------------------------------------------------------------------------------------

Option Compare Database
Option Explicit

Const maxData As Integer = 39
Const intYearFirst As Integer = 2005

'---------------------------------------------------------------------------------------
' MBOAnnualProgramReport_Top10SpeciesBanded
'---------------------------------------------------------------------------------------
' Top 10 species banded  (Tables 3.3, 4.3, 5.3, 6.3)

Public Sub MBOAnnualProgramReport_Top10SpeciesBanded( _
    ByRef fValid As Boolean, _
    ByVal argYear As Integer, _
    ByVal argLocation As String, _
    ByVal argCurrentProgram As String, _
    ByVal argSeason As String, _
    ByRef wd As Word.Application, _
    ByRef doc As Word.Document, _
    ByRef oExcel As Excel.Application, _
    ByRef oBook As Excel.Workbook, _
    ByVal strTableCaptionHeading As String)

10    On Error GoTo Err_label

      Dim intYear As Integer
      Dim strLocation As String
      Dim strCurrentProgram As String
      Dim strSeason As String

20    SysCmd acSysCmdSetStatus, strSeason & " Top 10 banded"

      ' Save parameters

30    intYear = argYear
40    strLocation = argLocation
50    strCurrentProgram = argCurrentProgram
60    strSeason = argSeason

70    fValid = True

      ' Quit if there were no bandings

80    If 0 = DCount("*", "tblDETSpecies", "[Program]='" & strCurrentProgram & "' AND [Location]='" & strLocation & "' AND [Banded] > 0") Then
90        GoTo Exit_label
100   End If

      ' The first step is to make a list of the program and all prior programs for the season

      Dim maxCol As Integer ' the number of programs for the season, prior or equal to the specified year

      Dim strSQL As String
110   strSQL = _
          "SELECT Program, YearEx" & _
          " From tblPrograms" & _
          " WHERE (MonitoringProgramSeason = '" & strSeason & "') AND YearEx <= " & intYear & _
          " ORDER BY YearEx DESC;"

      ' Count the prior (inclusive) monitoring programs

      Dim qdf As DAO.QueryDef
120   Set qdf = CurrentDb.CreateQueryDef("qryTemp", strSQL)
130   maxCol = Nz(DCount("*", qdf.Name, "True"))
140   CurrentDb.QueryDefs.Delete qdf.Name
150   Set qdf = Nothing

      ' Fill in 1-dim tables, one row per year. Sorted by year DESC
      ' top10Year(...) = year
      ' top10Program(...) = name/id of the monitoring program
      ' top10AnyDETData(...) = any banding records (Dispsition=1)during the monitoring program at the location

160   ReDim top10Year(1 To maxCol) As Integer
170   ReDim top10Program(1 To maxCol) As String
180   ReDim top10AnyDETData(1 To maxCol) As Boolean

      Dim col As Integer
      Dim rst As Recordset

190   Set rst = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)
200   col = 1
210   Do While Not rst.EOF
          Dim strProgram As String
          Dim intYearPrevious As Integer

220       strProgram = Nz(rst("Program"))
230       intYearPrevious = Nz(rst("YearEx"))
240       top10Program(col) = strProgram
250       top10Year(col) = intYearPrevious
          
          Dim strWhere As String
260       strWhere = "[Program]='" & strProgram & "' AND " & _
              "[Location]='" & strLocation & "' AND " & _
              "[Disposition] = '1'"
270       top10AnyDETData(col) = (0 < DCount("*", "tblCaptures", strWhere))

280       col = col + 1
290       rst.MoveNext
300   Loop
310   rst.Close

      ' Generate Top 10 rankings for each year

      ' tblMBOAnnualProgramReportTable3_4_Top10
      ' Column
      ' Program
      ' Location
      ' YearEx
      ' Species
      ' Banded
      ' Rank

      ' ZAP tblMBOAnnualProgramReportTable3_4_Top10

320   CurrentDb.Execute "DELETE * FROM tblMBOAnnualProgramReportTable3_4_Top10"

      Dim rstTop10 As DAO.Recordset
330   Set rstTop10 = CurrentDb.OpenRecordset("tblMBOAnnualProgramReportTable3_4_Top10")

      Dim CountSpecies As Integer
      Dim lngBandedPrevious As Long
      Dim Species As String
      Dim Banded As Long
      Dim BandedSaved As Long
      Dim Rank As Integer
      Dim RankPrevious As Integer

340   For col = 1 To maxCol

      '    Dim qdf As QueryDef
350       Set qdf = CurrentDb.QueryDefs("qryMBOAnnualProgramReportTable3_4B")
360       qdf.Parameters("argProgram").value = top10Program(col)
370       qdf.Parameters("argLocation").value = strLocation

      '    Dim rst As DAO.Recordset
380       Set rst = qdf.OpenRecordset

390       CountSpecies = 1
400       BandedSaved = -1
410       Do While Not rst.EOF

          '   Get record

420     Species = Nz(rst("Species"), 0)
430     Banded = Nz(rst("Banded"), 0)

          ' Pause the ranking when two records have the same number of banded
          ' Catch up the ranking when two records do not have the same number of banded

440       If Banded <> BandedSaved Then
450         Rank = CountSpecies
460         RankPrevious = Rank
470       Else
480         Rank = RankPrevious
490       End If
      ' 530     If Rank > 10 Then Exit Do
500         CountSpecies = CountSpecies + 1
          
510         rstTop10.AddNew
520         rstTop10("Column") = col
530         rstTop10("Program") = top10Program(col)
540         rstTop10("Location") = strLocation
550         rstTop10("YearEx") = top10Year(col)
560         rstTop10("Species") = Species
570         rstTop10("Banded") = Banded
580         rstTop10("Rank") = Rank
590         rstTop10.Update
          
600         BandedSaved = Banded
610         rst.MoveNext
620       Loop
630       rst.Close

640   Next col
650   rstTop10.Close

      ' Fill in the tables

      ' Dim strWhere As String
660   strWhere = "[Program] = '" & strCurrentProgram & "' AND " & _
          "[Location] = '" & strLocation & "' AND [Rank] <= 10"
      Dim maxRow As Integer
670   maxRow = Nz(DCount("*", "tblMBOAnnualProgramReportTable3_4_Top10", strWhere))

680   ReDim top10Rank(1 To maxRow) As Integer
690   ReDim Top10Species(1 To maxRow) As String
700   ReDim top10English(1 To maxRow) As String
710   ReDim Top10Banded(1 To maxRow) As Long
      Dim strEnglish As String

720   strSQL = "SELECT * FROM tblMBOAnnualProgramReportTable3_4_Top10 WHERE " & strWhere & " ORDER BY Rank"
730   Set rst = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)
      Dim row As Integer
740   row = 1
750   Do While Not rst.EOF
760       top10Rank(row) = Nz(rst("Rank"))
770       Top10Species(row) = Nz(rst("Species"))
780       Top10Banded(row) = Nz(rst("Banded"))
790       If Top10Banded(row) = 0 Then
800           maxRow = row - 1
810           Exit Do
820       End If
830       strEnglish = Nz(DLookup("SpeciesEnglish", "tblSpecies", "[Species] = '" & Top10Species(row) & "'"))
840       If strEnglish = "" Then
850           top10English(row) = DLookup("SpeciesDescriptionMBO", "tblSpecies", "[Species] = '" & Top10Species(row) & "'")
860       Else
870           top10English(row) = strEnglish
880       End If
890       row = row + 1
900       rst.MoveNext
910   Loop
920   rst.Close

930   ReDim Top10BandedPrevious(1 To maxRow, 1 To maxCol) As Integer
940   ReDim top10RankPrevious(1 To maxRow, 1 To maxCol) As Integer

      Dim strSpecies As String

950   For col = 2 To maxCol
960       For row = 1 To maxRow
970           strSpecies = Top10Species(row)
980           strWhere = "[Column]=" & col & " AND [Species] = '" & strSpecies & "'"
990           Top10BandedPrevious(row, col) = Nz(DLookup("Banded", "tblMBOAnnualProgramReportTable3_4_Top10", strWhere))
1000          top10RankPrevious(row, col) = Nz(DLookup("Rank", "tblMBOAnnualProgramReportTable3_4_Top10", strWhere))
1010      Next row
1020  Next col

      ' Append the caption for table: Top 10 species banded

      Dim range As Word.range
1030  Set range = doc.Characters.Last


      Dim strTableArg2 As String
      Dim strTableArg3 As String
      Dim strTableArg4 As String
      Dim strTableCaptionBody As String
      Dim strTableCaptionTC As String

1040  Select Case strSeason
      Case "Winter"
          Dim strWinterPeriod As String
1050      strWinterPeriod = intYear - 1 & "-" & intYear

1060      strTableCaptionBody = _
              "Top " & maxRow & " species banded at MBO during the " & strWinterPeriod & " winter population monitoring program, " & _
              "with comparison " & _
              "to the numbers banded in previous winters " & _
              "(rank in other years in parentheses).  " & _
              "Dashes represent species not banded during a " & _
              "particular winter season."
1070      strTableCaptionTC = _
              "Top " & maxRow & " species banded at MBO during the " & strWinterPeriod & " winter population monitoring program"
1080  Case "Spring"

1090      strTableCaptionBody = _
              "Top " & maxRow & " species banded at MBO during the " & intYear & " SMMP " & _
              ", with comparison " & _
              "to the numbers banded in " & intYearFirst & "-" & intYear - 1 & _
              " (rank in other years in parentheses)."
1100      strTableCaptionTC = _
              "Top " & maxRow & " species banded at MBO during the " & intYear & " SMMP"
1110  Case "Summer"
1120      strTableArg2 = "MAPS " & intYear
1130      strTableArg3 = intYearFirst & "-" & intYear - 1
1140      strTableArg4 = "year"
1150      strTableCaptionBody = _
              "Top " & maxRow & " species banded at MBO during the " & intYear & " MAPS program, " & _
              " with comparison " & _
              "to the numbers banded in " & intYearFirst & "-" & intYear - 1 & _
              " (rank in other years in parentheses).  " & _
              "Dashes represent species not banded during a " & _
              "particular year."
1160      strTableCaptionTC = _
              "Top " & maxRow & " species banded at MBO during the " & intYear & " MAPS program "
1170  Case "Fall"
1180      strTableArg2 = "FMMP " & intYear
1190      strTableArg3 = intYearFirst & "-" & intYear - 1
1200      strTableArg4 = "year"
1210      strTableCaptionBody = _
              "Top " & maxRow & " species banded at MBO during the " & intYear & " FMMP " & _
              ", with comparison " & _
              "to the numbers banded in " & intYearFirst & "-" & intYear - 1 & _
              " (rank in other years in parentheses)."
1220      strTableCaptionTC = _
              "Top " & maxRow & " species banded at MBO during the " & intYear & " FMMP "
1230  End Select

1240  Set range = MoveInsertionPointToEndOfDocument(wd, doc)
1250  range.InsertParagraphAfter
           
1260  Call InsertTableCaptionXX(wd, doc, "Table", _
          strTableCaptionHeading, _
          strTableCaptionBody, _
          strTableCaptionTC)
        
      ' Append table: Top 10 species banded

      ' NB the Winter table has 2 header rows.  All other seasons have 1 header rows

      Dim rowDataFirst As Long                              ' row in the table that stores the first data row
1270  rowDataFirst = IIf(strSeason = "Winter", 3, 2)

1280  Set range = doc.Characters.Last
1290  Call WordGenerateTableTop10SpeciesBanded(doc, range, strSeason, 2005, intYear)

      ' Append maxRow -1 rows and maxCol -1 columns

      Dim dataRow As Long       ' number the data rows from 1 to maxRow
      Dim dataCol As Long       ' number the data columns from 1

1300  For dataRow = 2 To maxRow
1310      range.Tables(1).Rows.Add
1320  Next

1330  For dataCol = 2 To maxCol
1340      range.Tables(1).columns.Add
1350  Next

1360  range.Tables(1).Rows(range.Tables(1).Rows.count).Cells.Borders(wdBorderBottom).LineStyle = wdLineStyleSingle

      ' Fill in the labels and the first data column

1370  For dataRow = 1 To maxRow
1380      row = rowDataFirst + dataRow - 1                       ' rowDataFirst .. rowDataFirst + maxRow - 1
1390      range.Tables(1).Cell(row, 1).range.Text = top10Rank(dataRow) & "."
1400      range.Tables(1).Cell(row, 2).range.Text = top10English(dataRow)
1410      range.Tables(1).Cell(row, 3).range.Text = Top10Banded(dataRow)
1420  Next

      ' Fill in the headers

1430  For dataCol = 1 To maxCol
1440      col = dataCol + 2
1450      Select Case strSeason
          Case "Winter"
1460          range.Tables(1).Cell(1, col).range.Text = Format(top10Year(dataCol) - 1, "0000") & "-"
1470          range.Tables(1).Cell(2, col).range.Text = Format(top10Year(dataCol), "0000")
1480      Case "Spring", "Summer", "Fall"
1490          range.Tables(1).Cell(1, col).range.Text = Format(top10Year(dataCol), "0000")
1500      End Select
1510  Next

      ' Fill in the detail for data columns 2 to maxCol (table columns 4 to maxCol + 2)

1520  For dataCol = 2 To maxCol
1530      col = dataCol + 2                                           ' 4 to maxCol + 2
1540      If top10AnyDETData(dataCol) Then
1550          For dataRow = 1 To maxRow
1560              row = rowDataFirst + dataRow - 1                     ' rowDataFirst .. rowDataFirst + maxRows - 1
1570              If Top10BandedPrevious(dataRow, dataCol) > 0 Then
1580                  range.Tables(1).Cell(row, col).range.Text = _
                      Top10BandedPrevious(dataRow, dataCol) & "(" & top10RankPrevious(dataRow, dataCol) & ")"
1590              Else
1600                  range.Tables(1).Cell(row, col).range.Text = "--"
1610              End If
1620           Next dataRow
1630      End If
1640  Next

      ' Delete empty data columns

      Dim intMaxNonEmptyDataColumns As Integer
1650  intMaxNonEmptyDataColumns = maxCol

1660  For dataCol = maxCol To 2 Step -1
1670      col = dataCol + 2
1680      If Not top10AnyDETData(dataCol) Then
1690          range.Tables(1).columns(col).Delete
1700          intMaxNonEmptyDataColumns = intMaxNonEmptyDataColumns - 1
1710      End If
1720  Next

1730  range.Tables(1).PreferredWidthType = wdPreferredWidthPoints
1740  range.Tables(1).PreferredWidth = wd.InchesToPoints(6.92)

1750  Select Case argSeason
      Case "Winter", "Spring", "Summer"
1760      range.Tables(1).columns(1).PreferredWidthType = wdPreferredWidthPoints
1770      range.Tables(1).columns(1).PreferredWidth = wd.InchesToPoints(0.3)
1780      range.Tables(1).columns(2).PreferredWidthType = wdPreferredWidthPoints
1790      range.Tables(1).columns(2).PreferredWidth = wd.InchesToPoints(1.6)
1800      For col = 1 To intMaxNonEmptyDataColumns
1810          range.Tables(1).columns(2 + col).PreferredWidthType = wdPreferredWidthPoints
1820          range.Tables(1).columns(2 + col).PreferredWidth = wd.InchesToPoints((6.92 - 0.3 - 1.6) / intMaxNonEmptyDataColumns)
1830      Next
1840  Case "Fall"
1850      range.Tables(1).columns(1).PreferredWidthType = wdPreferredWidthPoints
1860      range.Tables(1).columns(1).PreferredWidth = wd.InchesToPoints(0.27)
1870      range.Tables(1).columns(2).PreferredWidthType = wdPreferredWidthPoints
1880      range.Tables(1).columns(2).PreferredWidth = wd.InchesToPoints(1.45)
1890      For col = 1 To intMaxNonEmptyDataColumns
1900          range.Tables(1).columns(2 + col).PreferredWidthType = wdPreferredWidthPoints
1910          range.Tables(1).columns(2 + col).PreferredWidth = wd.InchesToPoints((6.92 - 0.27 - 1.45) / intMaxNonEmptyDataColumns)
1920      Next
1930  End Select

1940  range.Tables(1).range.Cells.VerticalAlignment = wdCellAlignVerticalCenter

1950      range.Tables(1).AllowAutoFit = True
1960      range.Tables(1).AutoFitBehavior wdAutoFitContent
1970      range.Tables(1).AutoFitBehavior wdAutoFitWindow

1980  Set range = doc.Characters.Last
1990  range.InsertParagraphAfter

2000  SysCmd acSysCmdClearStatus

      'DD Error Handler Start
Exit_label:
2010       Exit Sub
Err_label:
2020       Select Case Err.Number
           Case Else
2030      Call LogError("basMBOAnnualProgramReport_Top10SpeciesBanded", "MBOAnnualProgramReport_Top10SpeciesBanded")
2040       End Select
2050       Resume Exit_label
      'DD Error Handler End

End Sub


'---------------------------------------------------------------------------------------
' WordGenerateTableTop10SpeciesBanded
'---------------------------------------------------------------------------------------
' For any season except winter, generate a table with 2 rows and 3 columns
'     Row 1 is a header row
'     Row 2 is a detail row (for a species)
' For winter, generate a table with 3 rows and 3 columns
'     Rows 1 and 2 are header rows
'     Row 3 is a detail row (for a species)
' Column 1 is the top 10 rank
' Column 2 is the species name
' Column 3 is a data column (for a year)
' The range returned contains the table

Private Sub WordGenerateTableTop10SpeciesBanded( _
    ByRef doc As Word.Document, _
    ByRef range As Word.range, _
    ByVal strSeason As String, _
    ByVal intFirstReportYear As Integer, _
    ByVal intLastReportYear As Integer)
                    
      Dim intNumberOfYears As Integer
10    On Error GoTo Err_label



30    intNumberOfYears = intLastReportYear - intFirstReportYear + 1
40    If strSeason = "Winter" Then
50      doc.Tables.Add range:=range, NumRows:=3, NumColumns:=3
60    Else
70      doc.Tables.Add range:=range, NumRows:=2, NumColumns:=3
80    End If
          
90    range.Expand (wdTable)
100   With range.Tables(1)

110       .range.Style = "ddTop10SpeciesBandedData"

120       .LeftPadding = doc.Application.InchesToPoints(0.02)
130       .RightPadding = doc.Application.InchesToPoints(0.02)
140       .TopPadding = doc.Application.InchesToPoints(0.02)

150     .Rows.Alignment = wdAlignRowCenter
160     .Rows.WrapAroundText = False
          
      ' The following widths are changed later in the calling procedure -- to take into account deleted columns
          
170       .columns(1).Width = doc.Application.InchesToPoints(0.3)
180       .columns(2).Width = doc.Application.InchesToPoints(1.4)
190       .columns(3).Width = doc.Application.InchesToPoints(4.8 / intNumberOfYears)
          
200       .range.ParagraphFormat.Alignment = wdAlignParagraphCenter
          
'160       .Cell(2, 1).range.Font.Size = 10
'170       .Cell(2, 2).range.Font.Size = 10
210       .Cell(2, 1).range.ParagraphFormat.Alignment = wdAlignParagraphCenter
220       .Cell(2, 2).range.ParagraphFormat.Alignment = wdAlignParagraphLeft

          ' Format Header Row
          
230       Select Case strSeason
          Case "Winter"
240           Call FormatWordTableRowAsHeader(.Rows(1), "ddHeaderRowTop10SpeciesBandedWinterRow1")
250           Call FormatWordTableRowAsHeader(.Rows(2), "ddHeaderRowTop10SpeciesBandedWinterRow2")
260       Case Else
270           Call FormatWordTableRowAsHeader(.Rows(1), "ddHeaderRow")
280       End Select

      ' Repeat heading row at the top of subsequent pages


290   .Rows(1).HeadingFormat = True
300   .Rows(2).HeadingFormat = True
310   .Rows.WrapAroundText = False


320   End With

      'DD Error Handler Start
Exit_label:
330        Exit Sub
Err_label:
340        Select Case Err.Number
           Case Else
350       Call LogError("basMBOAnnualProgramReport_Top10SpeciesBanded", "WordGenerateTableTop10SpeciesBanded")
360        End Select
370        Resume Exit_label
      'DD Error Handler End

End Sub
