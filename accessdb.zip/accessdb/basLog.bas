Option Compare Database
Option Explicit


'---------------------------------------------------------------------------------------
'log
'---------------------------------------------------------------------------------------
' Append a record to the Debbuging Log tblLog

Public Sub log(ByVal strLog As String)

      Dim strSQL As String
10    On Error GoTo Err_label

      Dim datExportTimestamp As Date
      Dim strExportTimestamp As String

20    If GetSettingEx("DebuggingLoggingOn") = "True" Then
30        datExportTimestamp = Now()
40        strExportTimestamp = Format(datExportTimestamp, "YYYY-MM-DD HH:NN:SS")
          
50        strSQL = "INSERT INTO " & "tblLog" & "(TimestampEx, Log) VALUES('" & strExportTimestamp & "',""" & strLog & """)"
60        CurrentDb.Execute (strSQL)
70    End If

      'DD Error Handler Start
Exit_label:
80         Exit Sub
Err_label:
90         Select Case Err.Number
           Case Else
100             Call LogError("Module1", "log")
110        End Select
120        Resume Exit_label
      'DD Error Handler End


End Sub

'---------------------------------------------------------------------------------------
'LogCapture
'
' Called from NewBands_Store_v2, Recaps_Store_v2, UpdateCaptureRecord
'---------------------------------------------------------------------------------------
' IsValid is not used (yet)

Public Sub LogValidationInfoTo_tblLog(ByVal strBandPrefix As String, ByVal strBandSuffix As String, _
    ByVal strSpecies As String, ByVal datCaptureDate As Date, _
    ByVal fDuplicateNewCapture As Boolean, ByVal fNotBypassableMsg As Boolean, ByVal fBypassableMsg As Boolean, ByVal fBypassErrors, _
    ByRef IsValid As basTypes.IsValidType)
          
10    On Error GoTo Err_label

      Dim strMessage As String
20    strMessage = "Validation " & strBandPrefix & "-" & strBandSuffix & " " & strSpecies & " " & Format(datCaptureDate, "d-mmm-yyyy")

30    If fDuplicateNewCapture Then
40        strMessage = strMessage & " Duplicate new banding"
50    ElseIf fNotBypassableMsg Then
60        strMessage = strMessage & " Non-bypassable error(s)"
70    ElseIf fBypassableMsg Then
80        If Not fBypassErrors Then
90            strMessage = strMessage & " Bypassable error(s) : Not bypassed"
100       Else
110           strMessage = strMessage & " Bypassable error(s) : Bypassed"
120       End If
130   Else
140       strMessage = strMessage & " No errors"
150   End If

160   Call log(strMessage)

      'DD Error Handler Start
Exit_label:
170        Exit Sub
Err_label:
180        Select Case Err.Number
           Case Else
190             Call LogError("basLog", "LogCapture")
200        End Select
210        Resume Exit_label
      'DD Error Handler End


End Sub

'---------------------------------------------------------------------------------------
' ExportDebuggingLog
'
' Export the debugging log to a text file "log.txt" in the replication folder
'
' Deletes any older log file
'
'---------------------------------------------------------------------------------------

Public Sub ExportDebuggingLog()

On Error GoTo Err_label

Dim strTargetFolderpath As String
Dim strTargetFilename As String
Dim strTargetFilepath As String

If isDavidPC() Then
    strTargetFolderpath = CurrentProject.path
Else
    strTargetFolderpath = GetMBODataEntryReplicationFolder()
End If

If strTargetFolderpath = "" Then
    Call LogError("basLog", "ExportDebuggingLog", "The target foldername is null", Silent:=True)
    GoTo Exit_label
End If

If Not FolderExists(strTargetFolderpath) Then
    Call LogError("basLog", "ExportDebuggingLog", strTargetFolderpath & " - Target folder does not exist", Silent:=True)
    GoTo Exit_label
End If

strTargetFilename = "log.txt"
strTargetFilepath = strTargetFolderpath & "\" & strTargetFilename

' If the target file exists then delete it

If FileExists(strTargetFilepath) Then
    On Error Resume Next
    Kill strTargetFilepath
    On Error GoTo Exit_label
End If

On Error Resume Next
DoCmd.TransferText acExportDelim, , "qryLog_Export", strTargetFilepath
If Err.Number <> 0 Then
     Call LogError("basLog", "Export", "Failed to export the debugging log", Silent:=True)
    GoTo Exit_label
End If

    'DD Error Handler Start
Exit_label:
    Exit Sub
Err_label:
    Select Case Err.Number
    Case Else
         Call LogError("basLog", "ExportDebuggingLog")
    End Select
    Resume Exit_label
    ' DD Error Handler End

End Sub
