Option Compare Database
Option Explicit
' BandID                AutoNumber Not imported
' BandSizeID            Number     Not imported

' BandPrefix            Text(4)     Prefix
' BandSuffix            Text(5)     Suffix
' Species               Text(4)
' Age                   Text(1)
' HowAged               Text(1)
' Sex                   Text(1)
' HowSexed              Text(1)
' WingChord             Text(3)     Wing
' Fat                   Text(1)
' Weight                Text(4)                 weight in decigrams
' CaptureDate           Text(4)     MMDD
' WeightTime            Text(3)     HHM
' Bander                Text(3)
' Scribe                Text(3)
' CaptureYear           Text(4)     Year
' Location              Text(255)
' Program               Text(255)
' BirdStatus            Text(3)

' Net                   Text(2)
' ProbableAge           Text(1)
' ProbableSex           Text(1)
' NotesForMBO           Text(255)   Notes
' Valid                 Text(1)     Not imported
' Invalid               Text(1)     Not imported
' Duplicate             Text(1)     Not imported
' BypassErrors          Yes/No
' Disposition           Text(1)      Not imported, = 1

' RemarksForBBO         Text(250)    Not used
' AuxMarkerTYpe         Text(3)      Not used. Replaced by D3
' IsAuxMarkerCoded      Yes/No       Not used. Replaced by D4
' AuxMarkerCode         Text(255)    Not used. Replaced by D5
' AuxMarkerBandColor    Number(Long) Not used. Replaced by D6
' AuxMarkerCodeColor    Number(Long) Not used. Replaced by D7
' AutoHistory           Yes/No
' F                     Text(255)   Not imported
' F1                    Text(255)   Not imported
' ...
' F50                   Text(255)   Not imported
' Flags                 Text(255)   An optional description of why AutoHistory is turned on.
' D1                    Text(255)
' ...
' D40                   Text(255)

' List of the columns on the MBO worksheet

' Prefix                        => BandPrefix
' Suffix                        => BandSuffix
' Species
' Age
' HowAged
' Sex
' HowSexed
' Wing
' Fat
' Weight (in grams)             => Weight (integer in decigrams)
' Day 1-31                      => part of CaptureDate MMDD
' Month                         => part of CaptureDate MMDD
' Year                          => CaptureYear
' WeightTime (Excel date/time)  => WeightTime (HHM format)
' Bander
' Scribe
' Location                      Might have to be translated to an MBO location code
' Program
' BirdStatus

' Net
' ProableSex
' ProbableAge
' Notes                         => part of NotesForMBO
' AutoHistory ("Y" or blank)    => AutoHistory (Yes/No)
' Flags
' ReplacementBand                   => D1
' DETCategoryOverride               => D2
' AuxMarkerType                     => D3
' IsAuxMarkerCoded ("Y" or blank)   => D4 (? how is this stored ?)
' AuxMarkerCode                     => D5
' **** To Do


' D22
' D23
' ...
' D40


Const conFieldDisposition           As Integer = 0
Const conFieldBandPrefix            As Integer = 1
Const conFieldBandSuffix            As Integer = 2
Const conFieldSpecies               As Integer = 3
Const conFieldAge                   As Integer = 4
Const conFieldHowAged               As Integer = 5
Const conFieldSex                   As Integer = 6
Const conFieldHowSexed              As Integer = 7
Const conFieldWingChord             As Integer = 8
Const conFieldFat                   As Integer = 9
Const conFieldWeight                As Integer = 10
Const conFieldCaptureDay            As Integer = 11
Const conFieldCaptureMonth          As Integer = 12
Const conFieldCaptureYear           As Integer = 13
Const conFieldWeightTime            As Integer = 14
Const conFieldBander                As Integer = 15
Const conFieldScribe                As Integer = 16
Const conFieldLocation              As Integer = 17
Const conFieldProgram               As Integer = 18
Const conFieldBirdStatus            As Integer = 19

Const conFieldNet                   As Integer = 20
Const conFieldProbableAge           As Integer = 21
Const conFieldProbableSex           As Integer = 22
Const conFieldNotesForMBO           As Integer = 23
Const conFieldAutoHistory           As Integer = 24
Const conFieldFlags                 As Integer = 25
Const conFieldD                    As Integer = 25 ' D1 => 26, D2 => 27, ... D40 => 65

Const conFieldEndObligatory As Integer = 19
Const conFieldEnd        As Integer = 25 + conMaxDataField
'---------------------------------------------------------------------------------------
' Import
'---------------------------------------------------------------------------------------

Public Sub ImportTestDataFromExcel()

      Dim strInputFileFolder As String
      Dim strInputFileName As String
      Dim fDialog As FileDialog
      Dim oExcel As Excel.Application
      Dim oBook As Excel.Workbook
      Dim oSheet As Excel.Worksheet


10    On Error GoTo Err_label

      ' Get the initial folderpath

20    strInputFileFolder = GetSettingEx("TestDataExcelFilepath")

      ' Get the filepath from the user

30    Set fDialog = Application.FileDialog(msoFileDialogFilePicker)
40    fDialog.AllowMultiSelect = False
50    fDialog.Title = "Select the Excel Test Data File"
60    fDialog.InitialFileName = strInputFileFolder
70    fDialog.Filters.Clear
80    fDialog.Filters.Add "Excel files (*.xlsx,*xlsm, *xls)", "*.xlsx;*.xlsm;*.xls"
90    If fDialog.Show = -1 Then                                                  'Show the dialog. -1 means success!
100       strInputFileName = fDialog.SelectedItems(1)
110   Else
120       Exit Sub
130   End If

      ' Verify that the file exists
140   If Not FileExists(strInputFileName) Then
150       MsgBox "The selected file does not exist " & strInputFileName, vbExclamation, "Import Test Data"
160       Exit Sub
170   End If

180   Call PutSettingEx("TestDataExcelFilepath", strInputFileName)

      ' Open the Excel workbook

190   Set oExcel = New Excel.Application
200   oExcel.Visible = False

210   Set oBook = oExcel.Workbooks.Open(strInputFileName)

      ' Open the "MBO" worksheet

      Dim intSheet As Integer
      Dim fMBOSheetExists As Boolean

220   fMBOSheetExists = False
230   For intSheet = 1 To oBook.Sheets.count
240       If oBook.Sheets(intSheet).Name = "MBO" Then
250           Set oSheet = oBook.Sheets(intSheet)
260           fMBOSheetExists = True
270       End If
280   Next
290   If Not fMBOSheetExists Then
300       MsgBox "The Excel workbook does not have an MBO worksheet", vbExclamation, "Import New Bands"
310       GoTo Exit_label
320   End If

330   With oSheet

      Dim intFieldNumber As Integer

      Dim arrField(0 To conFieldEnd) As Integer
340   For intFieldNumber = 0 To conFieldEnd
350       arrField(intFieldNumber) = 0
360   Next

      ' What is the last column

      ' N.B. columns with blank or unrecognized headers will be ignored

      Dim colEnd As Long

370   colEnd = .Cells(1, .columns.count).End(xlToLeft).column

      Dim col As Long

      ' Fill in the array of field# => column

      Dim arrFieldName(0 To conFieldEnd) As String
      Dim arrFieldCol(0 To conFieldEnd) As Long
      Dim strFieldname As String

380   arrFieldName(conFieldDisposition) = "Disposition"
390   arrFieldName(conFieldBandPrefix) = "Prefix"
400   arrFieldName(conFieldBandSuffix) = "Suffix"
410   arrFieldName(conFieldSpecies) = "Species"
420   arrFieldName(conFieldAge) = "Age"
430   arrFieldName(conFieldHowAged) = "HowAged"
440   arrFieldName(conFieldSex) = "Sex"
450   arrFieldName(conFieldHowSexed) = "HowSexed"
460   arrFieldName(conFieldWingChord) = "Wing"
470   arrFieldName(conFieldFat) = "Fat"
480   arrFieldName(conFieldWeight) = "Weight"
490   arrFieldName(conFieldCaptureDay) = "Day"
500   arrFieldName(conFieldCaptureMonth) = "Month"
510   arrFieldName(conFieldCaptureYear) = "Year"
520   arrFieldName(conFieldWeightTime) = "WeightTime"
530   arrFieldName(conFieldBander) = "Bander"
540   arrFieldName(conFieldScribe) = "Scribe"
550   arrFieldName(conFieldLocation) = "Location"
560   arrFieldName(conFieldProgram) = "Program"
570   arrFieldName(conFieldBirdStatus) = "BirdStatus"
580   arrFieldName(conFieldNet) = "Net"
590   arrFieldName(conFieldProbableAge) = "ProbableAge"
600   arrFieldName(conFieldProbableSex) = "ProbableSex"
610   arrFieldName(conFieldNotesForMBO) = "Notes"
620   arrFieldName(conFieldAutoHistory) = "AutoHistory"
630   arrFieldName(conFieldFlags) = "Flags"
640   arrFieldName(conFieldD + 1) = "ReplacementBand"
650   arrFieldName(conFieldD + 2) = "DETCategoryOverride"
660   arrFieldName(conFieldD + 3) = "AUXMarkerType"
670   arrFieldName(conFieldD + 4) = "IsAuxMarkerCoded"
680   arrFieldName(conFieldD + 5) = "AuxMarkerCode"
690   arrFieldName(conFieldD + 6) = "AuxMarkerBandColor"
700   arrFieldName(conFieldD + 7) = "AuxMarkerCodeColor"
710   arrFieldName(conFieldD + 8) = "LeftLegColor1"
720   arrFieldName(conFieldD + 9) = "LeftLegColor2"
730   arrFieldName(conFieldD + 10) = "LeftLegColor3"
740   arrFieldName(conFieldD + 11) = "RightLegColor1"
750   arrFieldName(conFieldD + 12) = "RightLegColor2"
760   arrFieldName(conFieldD + 13) = "RightLegColor3"

      Dim D As Integer
770   For D = 22 To conMaxDataField
780       arrFieldName(conFieldD + D) = "D" & D
790   Next D

      Dim var As Variant

800   For intFieldNumber = 0 To conFieldEnd
810       strFieldname = arrFieldName(intFieldNumber)
820       var = oExcel.Match(strFieldname, .range(.Cells(1, 1), .Cells(1, colEnd)), 0)
830       If IsNumeric(var) Then
840           arrFieldCol(intFieldNumber) = var
850       End If
860   Next

      ' Are there any missing required fields

      Dim strErr As String
870   strErr = ""

880   For intFieldNumber = 0 To conFieldEndObligatory
890       If arrFieldCol(intFieldNumber) = 0 Then
900           strErr = strErr & vbCr & arrFieldName(intFieldNumber)
910       End If
920   Next
930   If strErr <> "" Then
940       MsgBox "Missing fields:" & strErr
950       GoTo Exit_label
960   End If

      ' How many rows

      Dim rowEnd As Long
      Dim row As Long

970   row = 2
980   Do While True
990       If .Cells(row, arrFieldCol(conFieldBandPrefix)) = "0000" Or Trim(.Cells(row, arrFieldCol(conFieldBandPrefix))) = "" Then
1000          Exit Do
1010      End If
1020      row = row + 1
1030  Loop
1040  rowEnd = row - 1

      ' Flag any rows that contain validation errors

1050  ReDim fRowHasValidationErrors(2 To rowEnd)

1060  For row = 2 To rowEnd
1070      fRowHasValidationErrors(row) = False
1080  Next

      Dim strErrGlobal As String

1090  strErrGlobal = ""

      ' Basic validation

      Dim strCaptureDay As String
      Dim intCaptureDay As Integer
      Dim strCaptureMonth As String
      Dim intCaptureMonth As Integer

1100  For row = 2 To rowEnd
          
1110      SysCmd acSysCmdSetStatus, "Validating row " & row

1120      strErr = ""
1130      For intFieldNumber = 0 To conFieldEnd
1140          col = arrFieldCol(intFieldNumber)
1150          If col <> 0 Then
1160              Select Case intFieldNumber
                  Case conFieldDisposition
                      ' Validate Disposition
1170                  Select Case .Cells(row, arrFieldCol(conFieldDisposition))
                      Case "1", "5", "R", "F", "5"
1180                  Case "X"
1190                      strErr = strErr & vbCrLf & "Cannot input a deleted record"
1200                  Case Else
1210                      strErr = strErr & vbCrLf & "Unrecognized Disposition"
1220                  End Select
1230              Case conFieldBandPrefix
                      ' Validate BandPrefix
1240                  If Len(.Cells(row, arrFieldCol(conFieldBandPrefix))) <> 4 Then
1250                      strErr = strErr & vbCrLf & "Prefix not 4 characters"
1260                  End If
1270              Case conFieldBandSuffix
                      ' Validate BandSuffix
1280                  If Len(.Cells(row, arrFieldCol(conFieldBandSuffix))) <> 5 Then
1290                      strErr = strErr & vbCrLf & "Suffix not 5 characters"
1300                  End If
1310              Case conFieldSpecies
                      ' Validate Species
1320                  If Len(.Cells(row, arrFieldCol(conFieldSpecies))) <> 4 Then
1330                      strErr = strErr & vbCrLf & "Species not 4 characters"
1340                  End If
1350              Case conFieldAge
                      ' Validate Age
1360                  If Len(.Cells(row, arrFieldCol(conFieldAge))) <> 0 Then
1370                      If Len(.Cells(row, arrFieldCol(conFieldAge))) <> 1 Then
1380                          strErr = strErr & vbCrLf & "Age not 1 character or blank"
1390                      End If
1400                  End If
1410              Case conFieldHowAged
                      ' Validate How Aged
1420                  If Len(.Cells(row, arrFieldCol(conFieldHowAged))) <> 0 Then
1430                      If Len(.Cells(row, arrFieldCol(conFieldHowAged))) <> 1 Then
1440                          strErr = strErr & vbCrLf & "How Aged not 1 character or blank"
1450                      End If
1460                  End If
1470              Case conFieldSex
                      ' Validate Sex
1480                  If Len(.Cells(row, arrFieldCol(conFieldSex))) <> 0 Then
1490                      If Len(.Cells(row, arrFieldCol(conFieldSex))) <> 1 Then
1500                          strErr = strErr & vbCrLf & "Sex not 1 character or blank"
1510                      End If
1520                  End If
1530              Case conFieldHowSexed
                      ' Validate How Sexed
1540                  If Len(.Cells(row, arrFieldCol(conFieldHowSexed))) <> 0 Then
1550                      If Len(.Cells(row, arrFieldCol(conFieldHowSexed))) <> 1 Then
1560                          strErr = strErr & vbCrLf & "How Sexed not 1 character or blank"
1570                      End If
1580                  End If
1590              Case conFieldWingChord
                      ' Validate Wing Chord
1600                  If Len(.Cells(row, arrFieldCol(conFieldWingChord))) <> 0 Then
1610                      If Len(.Cells(row, arrFieldCol(conFieldWingChord))) > 3 Then
1620                          strErr = strErr & vbCrLf & "Wing Chord not less than or equal to 3 characters or blank"
1630                      End If
1640                  End If
1650               Case conFieldFat
                      ' Validate Fat
1660                  If Len(.Cells(row, arrFieldCol(conFieldFat))) <> 0 Then
1670                      If Len(.Cells(row, arrFieldCol(conFieldFat))) <> 1 Then
1680                          strErr = strErr & vbCrLf & "Fat not 1 character or blank"
1690                      End If
1700                  End If
1710               Case conFieldWeight
                      ' Validate Weight
1720                Case conFieldCaptureDay
                          ' Validate Capture Day
1730                      strCaptureDay = .Cells(row, arrFieldCol(conFieldCaptureDay))
1740                      If strCaptureDay <> "" Then
1750                          If IsNumeric(strCaptureDay) Then
1760                              intCaptureDay = CInt(strCaptureDay)
1770                              If intCaptureDay < 0 Or intCaptureDay > 31 Then
1780                                  strErr = strErr & vbCrLf & "Day is not between 1 and 31 or blank"
1790                              End If
1800                          Else
1810                              strErr = strErr & vbCrLf & "Day is not between 1 and 31 or blank"
1820                          End If
1830                      End If
1840                Case conFieldCaptureMonth
                          ' Validate Capture Month
1850                      strCaptureMonth = .Cells(row, arrFieldCol(conFieldCaptureMonth))
1860                      If strCaptureMonth <> "" Then
1870                          If IsNumeric(strCaptureMonth) Then
1880                              intCaptureMonth = CInt(strCaptureMonth)
1890                              If intCaptureMonth < 0 Or intCaptureMonth > 12 Then
1900                                  strErr = strErr & vbCrLf & "Month is not between 1 and 12 or blank"
1910                              End If
1920                          Else
1930                              strErr = strErr & vbCrLf & "Month is not between 1 and 31 or blank"
1940                          End If
1950                      End If
1960                Case conFieldWeightTime
                          ' Validate Weight Time
1970                 Case conFieldBander
                          ' Validate Bander
                                              
1980                      If Len(.Cells(row, arrFieldCol(conFieldBander))) <> 0 Then
1990                          If Len(.Cells(row, arrFieldCol(conFieldBander))) > 3 Then
2000                              strErr = strErr & vbCrLf & "Bander not less than or equal to 3 characters or blank"
2010                          End If
2020                      End If
2030                 Case conFieldScribe
                          ' Validate Scribe
2040                      If Len(.Cells(row, arrFieldCol(conFieldScribe))) <> 0 Then
2050                          If Len(.Cells(row, arrFieldCol(conFieldScribe))) > 3 Then
2060                              strErr = strErr & vbCrLf & "Scribe not less than or equal to 3 characters or blank"
2070                          End If
2080                      End If
2090                 Case conFieldCaptureYear
                          ' Validate Capture Year
2100                      If Len(.Cells(row, arrFieldCol(conFieldCaptureYear))) <> 4 Then
2110                          strErr = strErr & vbCrLf & "Capture year not 4 characters"
2120                      End If
                          
                     ' The following fields can be blank
                          
2130                 Case conFieldNet
                          ' Validate Net
2140                      If Len(.Cells(row, arrFieldCol(conFieldNet))) > 2 Then
2150                          strErr = strErr & vbCrLf & "Net not less than or equal to 2 characters"
2160                      End If
2170                  Case conFieldProbableAge
                          ' Validate ProableAge
2180                      If Len(.Cells(row, arrFieldCol(conFieldProbableAge))) > 1 Then
2190                          strErr = strErr & vbCrLf & "Probable Age not 1 character or blank"
2200                      End If
2210                  Case conFieldProbableSex
                          ' Validate ProableSex
2220                      If Len(.Cells(row, arrFieldCol(conFieldProbableSex))) > 1 Then
2230                          strErr = strErr & vbCrLf & "Probable Sex not 1 character or blank"
2240                      End If
2250                  Case conFieldAutoHistory
                          ' Validate AutoHistory
                          Dim strAutoHistory As String
2260                      strAutoHistory = UCase(Trim(.Cells(row, arrFieldCol(conFieldAutoHistory))))
2270                      If Not (strAutoHistory = "Y" Or strAutoHistory = "") Then
2280                          strErr = strErr & vbCrLf & "AutoHistory is not Y or blank"
2290                      End If
                      
2300              End Select
2310          End If
2320      Next
2330      If strErr <> "" Then
2340          fRowHasValidationErrors(row) = True
2350          strErrGlobal = strErrGlobal & "Error(s) in row " & row & strErr & vbCrLf
2360      End If

2370  Next

2380  If strErrGlobal <> "" Then
2390      oExcel.Visible = False
2400      If vbYes <> MsgBox("The following records contain errors. Do you wish to import the rows that do not contain errors?" & vbCrLf & strErrGlobal, vbYesNo, "Import") Then
2410          GoTo Exit_label
2420      End If
2430  End If

      ' Import

      Dim MMDD As String
      Dim strWeight As String
      Dim strWingChord As String
      Dim lngWingChord As Long

      Dim rst As DAO.Recordset
2440  Set rst = CurrentDb.OpenRecordset("tblSheetNewBandsMultiSize_v2", dbOpenDynaset)

      Dim rstRecaps As DAO.Recordset
2450  Set rstRecaps = CurrentDb.OpenRecordset("tblSheetRecaps_v2", dbOpenDynaset)

2460  For row = 2 To rowEnd
2470      If Not fRowHasValidationErrors(row) Then
          
2480          SysCmd acSysCmdSetStatus, "Importing row " & row
              Dim strDisposition As String
2490          strDisposition = .Cells(row, arrFieldCol(conFieldDisposition))
2500          Select Case strDisposition
              Case "1", "4", "8", "5"
2510              rst.AddNew
2520              rst("BandPrefix") = .Cells(row, arrFieldCol(conFieldBandPrefix))
2530              rst("BandSuffix") = .Cells(row, arrFieldCol(conFieldBandSuffix))
2540              rst("Species") = .Cells(row, arrFieldCol(conFieldSpecies))
2550              rst("Age") = .Cells(row, arrFieldCol(conFieldAge))
2560              rst("HowAged") = .Cells(row, arrFieldCol(conFieldHowAged))
2570              rst("Sex") = .Cells(row, arrFieldCol(conFieldSex))
2580              rst("HowSexed") = .Cells(row, arrFieldCol(conFieldHowSexed))
              
2590              strWingChord = .Cells(row, arrFieldCol(conFieldWingChord))
2600              If IsNumeric(strWingChord) Then
2610                  lngWingChord = CLng(strWingChord)
2620                  If lngWingChord > 0 Then
2630                      rst("WingChord") = lngWingChord
2640                  End If
2650              End If
              
2660              rst("Fat") = .Cells(row, arrFieldCol(conFieldFat))
              
2670              If .Cells(row, arrFieldCol(conFieldWeight)) = "" Then
2680                  rst("Weight") = ""
2690              Else
2700                  strWeight = Format(CInt(.Cells(row, arrFieldCol(conFieldWeight)) * 10), "0000")
2710                  rst("Weight") = IIf(strWeight = "0000", "", strWeight)
2720              End If
                  
2730              rst("CaptureDate") = Format(.Cells(row, arrFieldCol(conFieldCaptureMonth)), "00") & _
                                       Format(.Cells(row, arrFieldCol(conFieldCaptureDay)), "00")
                                       
2740              rst("WeightTime") = Left(Format(.Cells(row, arrFieldCol(conFieldWeightTime)), "HHMM"), 3)
                  
2750              rst("Bander") = .Cells(row, arrFieldCol(conFieldBander))
2760              rst("Scribe") = .Cells(row, arrFieldCol(conFieldScribe))
2770              rst("CaptureYear") = .Cells(row, arrFieldCol(conFieldCaptureYear))
2780              rst("Location") = .Cells(row, arrFieldCol(conFieldLocation))
2790              rst("Program") = .Cells(row, arrFieldCol(conFieldProgram))
2800              rst("BirdStatus") = .Cells(row, arrFieldCol(conFieldBirdStatus))
                 
2810              rst("Disposition") = "1"
              
2820              If arrFieldCol(conFieldNet) <> 0 Then
2830                  rst("Net") = .Cells(row, arrFieldCol(conFieldNet))
2840              End If
              
2850              If arrFieldCol(conFieldProbableAge) <> 0 Then
2860                  rst("ProbableAge") = .Cells(row, arrFieldCol(conFieldProbableAge))
2870              End If
              
2880              If arrFieldCol(conFieldProbableSex) <> 0 Then
2890                  rst("ProbableSex") = .Cells(row, arrFieldCol(conFieldProbableSex))
2900              End If
              
2910              If arrFieldCol(conFieldNotesForMBO) <> 0 Then
2920                  rst("NotesForMBO") = .Cells(row, arrFieldCol(conFieldNotesForMBO))
2930              End If
              
2940              If arrFieldCol(conFieldAutoHistory) <> 0 Then
2950                  strAutoHistory = UCase(Trim(.Cells(row, arrFieldCol(conFieldAutoHistory))))
2960                  rst("AutoHistory") = (strAutoHistory = "Y")
2970              End If
                  
2980              If arrFieldCol(conFieldFlags) <> 0 Then
2990                  rst("Flags") = .Cells(row, arrFieldCol(conFieldFlags))
3000              End If
                  
3010              For D = 1 To 40
3020                  If arrFieldCol(conFieldD + D) <> 0 Then
3030                      rst("D" & D) = .Cells(row, arrFieldCol(conFieldD + D))
3040                  End If
3050              Next D
              
3060              rst.Update
                 
                  Dim lngBandID As Long
3070              rst.Move 0, rst.LastModified
3080              lngBandID = rst("BandID")

3090          Case "R", "F"
3100              rstRecaps.AddNew
3110              rstRecaps("BandPrefix") = .Cells(row, arrFieldCol(conFieldBandPrefix))
3120              rstRecaps("BandSuffix") = .Cells(row, arrFieldCol(conFieldBandSuffix))
3130              rstRecaps("Species") = .Cells(row, arrFieldCol(conFieldSpecies))
3140              rstRecaps("Age") = .Cells(row, arrFieldCol(conFieldAge))
3150              rstRecaps("HowAged") = .Cells(row, arrFieldCol(conFieldHowAged))
3160              rstRecaps("Sex") = .Cells(row, arrFieldCol(conFieldSex))
3170              rstRecaps("HowSexed") = .Cells(row, arrFieldCol(conFieldHowSexed))
              
3180              strWingChord = .Cells(row, arrFieldCol(conFieldWingChord))
3190              If IsNumeric(strWingChord) Then
3200                  lngWingChord = CLng(strWingChord)
3210                  If lngWingChord > 0 Then
3220                      rstRecaps("WingChord") = lngWingChord
3230                  End If
3240              End If
              
3250              rstRecaps("Fat") = .Cells(row, arrFieldCol(conFieldFat))
              
3260              If .Cells(row, arrFieldCol(conFieldWeight)) = "" Then
3270                  rstRecaps("Weight") = ""
3280              Else
3290                  strWeight = Format(CInt(.Cells(row, arrFieldCol(conFieldWeight)) * 10), "0000")
3300                  rstRecaps("Weight") = IIf(strWeight = "0000", "", strWeight)
3310              End If
                  
3320              rstRecaps("CaptureDate") = Format(.Cells(row, arrFieldCol(conFieldCaptureMonth)), "00") & _
                                       Format(.Cells(row, arrFieldCol(conFieldCaptureDay)), "00")
                                       
3330              rstRecaps("WeightTime") = Left(Format(.Cells(row, arrFieldCol(conFieldWeightTime)), "HHMM"), 3)
                  
3340              rstRecaps("Bander") = .Cells(row, arrFieldCol(conFieldBander))
3350              rstRecaps("Scribe") = .Cells(row, arrFieldCol(conFieldScribe))
3360              rstRecaps("CaptureYear") = .Cells(row, arrFieldCol(conFieldCaptureYear))
3370              rstRecaps("Location") = .Cells(row, arrFieldCol(conFieldLocation))
3380              rstRecaps("Program") = .Cells(row, arrFieldCol(conFieldProgram))
3390              rstRecaps("BirdStatus") = .Cells(row, arrFieldCol(conFieldBirdStatus))
                 
3400              rstRecaps("Disposition") = "1"
              
3410              If arrFieldCol(conFieldNet) <> 0 Then
3420                  rstRecaps("Net") = .Cells(row, arrFieldCol(conFieldNet))
3430              End If
              
3440              If arrFieldCol(conFieldProbableAge) <> 0 Then
3450                  rstRecaps("ProbableAge") = .Cells(row, arrFieldCol(conFieldProbableAge))
3460              End If
              
3470              If arrFieldCol(conFieldProbableSex) <> 0 Then
3480                  rstRecaps("ProbableSex") = .Cells(row, arrFieldCol(conFieldProbableSex))
3490              End If
              
3500              If arrFieldCol(conFieldNotesForMBO) <> 0 Then
3510                  rstRecaps("NotesForMBO") = .Cells(row, arrFieldCol(conFieldNotesForMBO))
3520              End If
              
3530              If arrFieldCol(conFieldAutoHistory) <> 0 Then
3540                  strAutoHistory = UCase(Trim(.Cells(row, arrFieldCol(conFieldAutoHistory))))
3550                  rstRecaps("AutoHistory") = (strAutoHistory = "Y")
3560              End If
                  
3570              If arrFieldCol(conFieldFlags) <> 0 Then
3580                  rstRecaps("Flags") = .Cells(row, arrFieldCol(conFieldFlags))
3590              End If
                  
3600              For D = 1 To 40
3610                  If arrFieldCol(conFieldD + D) <> 0 Then
3620                      rstRecaps("D" & D) = .Cells(row, arrFieldCol(conFieldD + D))
3630                  End If
3640              Next D
              
3650              rstRecaps.Update
                 

3660              rstRecaps.Move 0, rstRecaps.LastModified
3670              lngBandID = rstRecaps("BandID")
              
              
3680          End Select
3690      End If
          
3700  Next
3710  rst.Close
3720  rstRecaps.Close
3730  Set rst = Nothing
3740  Set rstRecaps = Nothing
3750  End With



          'DD Error Handler Start
Exit_label:

3760  SysCmd acSysCmdClearStatus
3770  oBook.Close saveChanges:=False
3780  oExcel.Quit
3790  Set oSheet = Nothing
3800  Set oBook = Nothing

3810  Set oExcel = Nothing

3820      Exit Sub
Err_label:
3830      Select Case Err.Number
          Case Else
3840           Call LogError("basImportTestData", "ImportTestDataFromExcel")
3850      End Select
3860      Resume Exit_label
          ' DD Error Handler End


End Sub
