'---------------------------------------------------------------------------------------
' Module    : basCountSpeciesInDictionary
' Author    : David Davey
'---------------------------------------------------------------------------------------

Option Compare Database
Option Explicit

'---------------------------------------------------------------------------------------
' CountSpeciesInDictionary
'---------------------------------------------------------------------------------------

Public Function CountSpeciesInDictionary( _
    ByRef dicPseudospecies As Scripting.Dictionary) As Integer

10    On Error GoTo Err_label

      Dim intCountSpecies As Integer
      Dim strSQL As String
      Dim rstSpecies As DAO.Recordset
      Dim rstSubSpecies As DAO.Recordset
      Dim rstSuperSpecies As DAO.Recordset
      Dim strSpecies As String
      Dim strSubSpecies As String
      Dim strSuperSpecies As String

      ' Count the superspecies + species + subspecies + hybrid species in the dictionary

20    intCountSpecies = dicPseudospecies.count

      ' Adjust the count for subspecies
      ' -------------------------------
      ' For each species that has subspecies
      '   c = 0
      '   For each subspecies of the species
      '      If the subspecies is in the dictionary
      '          c = c + 1
      '   If the species is in the dictionary
      '      c = c + 1
      '   If c > 1, reduce the count by c-1
           
30    strSQL = _
          "SELECT Species " & _
          "FROM tblSubspecies " & _
          "GROUP BY Species"

40    Set rstSpecies = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)
50    Do While Not rstSpecies.EOF
60        strSpecies = rstSpecies("Species")
          
          Dim c As Integer
70        c = 0
          
80        strSQL = _
              "SELECT SubSpecies " & _
              "FROM tblSubspecies " & _
              "WHERE [Species] = '" & strSpecies & "'"
90        Set rstSubSpecies = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)
100       Do While Not rstSubSpecies.EOF
110           strSubSpecies = rstSubSpecies("SubSpecies")
120           If dicPseudospecies.Exists(UCase(strSubSpecies)) Then
130               c = c + 1
140           End If
150           rstSubSpecies.MoveNext
160       Loop
170       rstSubSpecies.Close
180       Set rstSubSpecies = Nothing

190       If dicPseudospecies.Exists(UCase(strSpecies)) Then
200           c = c + 1
210       End If
220       If c > 1 Then
230           intCountSpecies = intCountSpecies - (c - 1)
240       End If

250       rstSpecies.MoveNext
260   Loop
270   rstSpecies.Close
280   Set rstSpecies = Nothing

      ' Adjust the count for superspecies
      ' ---------------------------------
      ' For each superspecies that has subspecies
      '   If the superspecies is in the dictionary
      '     For each species in the superspecies
      '       If the species is in the dictionary
      '         Reduce the count by 1
      '         Exit the inner For
                                  
290   strSQL = _
          "SELECT SuperSpecies " & _
          "FROM tblSuperSpecies " & _
          "GROUP BY SuperSpecies"
          
300   Set rstSuperSpecies = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)
310   Do While Not rstSuperSpecies.EOF
320       strSuperSpecies = rstSuperSpecies("SuperSpecies")
330       If dicPseudospecies.Exists(UCase(strSuperSpecies)) Then
340           strSQL = _
                  "SELECT * " & _
                  "FROM tblSuperSpecies " & _
                  "WHERE SuperSpecies = '" & strSuperSpecies & "'"
                  
350           Set rstSpecies = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)
360           Do While Not rstSpecies.EOF
370               strSpecies = rstSpecies("Species")
380               If dicPseudospecies.Exists(UCase(strSpecies)) Then
390                   intCountSpecies = intCountSpecies - 1
400                   Exit Do
410               End If
420               rstSpecies.MoveNext
430           Loop
440           rstSpecies.Close
450           Set rstSpecies = Nothing
460       End If
470       rstSuperSpecies.MoveNext
480   Loop
490   rstSuperSpecies.Close
500   Set rstSuperSpecies = Nothing

      ' Adjust the count for hybrid species
      ' -----------------------------------
      ' For each hybrid species
      '   If the hybrid species is in the dictionary
      '       Reduce the count by 1

      Dim rstHybridSpecies As DAO.Recordset
      Dim strHybridSpecies As String

510   strSQL = "SELECT Species FROM tblSpecies WHERE PseudoSpeciesType = 'Hybrid'"
520   Set rstHybridSpecies = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)
530   Do While Not rstHybridSpecies.EOF
540       strHybridSpecies = Nz(rstHybridSpecies("Species"))
550       If dicPseudospecies.Exists(UCase(strHybridSpecies)) Then
560           intCountSpecies = intCountSpecies - 1
570       End If
580       rstHybridSpecies.MoveNext
590   Loop
600   rstHybridSpecies.Close
610   Set rstHybridSpecies = Nothing

620   CountSpeciesInDictionary = intCountSpecies

      'DD Error Handler Start
Exit_label:
630        Exit Function
Err_label:
640        Select Case Err.Number
           Case Else
650             Call LogError("basCountSpeciesInDictionary", "CountSpeciesInDictionary")
660        End Select
670        Resume Exit_label
      'DD Error Handler End



End Function

Public Sub Test_CountSpeciesInDictionary()
      Dim dicPseudospecies As New Scripting.Dictionary
          
      ' 1
10    Call dicPseudospecies.Add("PAWA", "PAWA")
20    Debug.Print CountSpeciesInDictionary(dicPseudospecies)
30    dicPseudospecies.RemoveAll

      ' 1
40    Call dicPseudospecies.Add("WPWA", "WPWA")
50    Debug.Print CountSpeciesInDictionary(dicPseudospecies)
60    dicPseudospecies.RemoveAll

      ' 1
70    Call dicPseudospecies.Add("YPWA", "YPWA")
80    Debug.Print CountSpeciesInDictionary(dicPseudospecies)
90    dicPseudospecies.RemoveAll

      ' 1
100   Call dicPseudospecies.Add("PAWA", "PAWA")
110   Call dicPseudospecies.Add("WPWA", "WPWA")
120   Debug.Print CountSpeciesInDictionary(dicPseudospecies)
130   dicPseudospecies.RemoveAll

      ' 1
140   Call dicPseudospecies.Add("PAWA", "PAWA")
150   Call dicPseudospecies.Add("YPWA", "YPWA")
160   Debug.Print CountSpeciesInDictionary(dicPseudospecies)
170   dicPseudospecies.RemoveAll

      ' 1
180   Call dicPseudospecies.Add("WPWA", "WPWA")
190   Call dicPseudospecies.Add("YPWA", "YPWA")
200   Debug.Print CountSpeciesInDictionary(dicPseudospecies)
210   dicPseudospecies.RemoveAll

      ' 1
220   Call dicPseudospecies.Add("PAWA", "PAWA")
230   Call dicPseudospecies.Add("WPWA", "WPWA")
240   Call dicPseudospecies.Add("YPWA", "YPWA")
250   Debug.Print CountSpeciesInDictionary(dicPseudospecies)
260   dicPseudospecies.RemoveAll

270   Debug.Print

      ' 1
280   Call dicPseudospecies.Add("SNGO", "SNGO")
290   Debug.Print CountSpeciesInDictionary(dicPseudospecies)
300   dicPseudospecies.RemoveAll

      ' 1
310   Call dicPseudospecies.Add("GSGO", "GSGO")
320   Debug.Print CountSpeciesInDictionary(dicPseudospecies)
330   dicPseudospecies.RemoveAll

      ' 1
340   Call dicPseudospecies.Add("LSGO", "LSGO")
350   Debug.Print CountSpeciesInDictionary(dicPseudospecies)
360   dicPseudospecies.RemoveAll

      ' 1
370   Call dicPseudospecies.Add("SNGO", "SNGO")
380   Call dicPseudospecies.Add("GSGO", "GSGO")
390   Debug.Print CountSpeciesInDictionary(dicPseudospecies)
400   dicPseudospecies.RemoveAll

      ' 1
410   Call dicPseudospecies.Add("SNGO", "SNGO")
420   Call dicPseudospecies.Add("LSGO", "LSGO")
430   Debug.Print CountSpeciesInDictionary(dicPseudospecies)
440   dicPseudospecies.RemoveAll

      ' 1
450   Call dicPseudospecies.Add("GSGO", "GSGO")
460   Call dicPseudospecies.Add("LSGO", "LSGO")
470   Debug.Print CountSpeciesInDictionary(dicPseudospecies)
480   dicPseudospecies.RemoveAll

      ' 1
490   Call dicPseudospecies.Add("SNGO", "SNGO")
500   Call dicPseudospecies.Add("GSGO", "GSGO")
510   Call dicPseudospecies.Add("LSGO", "LSGO")
520   Debug.Print CountSpeciesInDictionary(dicPseudospecies)
530   dicPseudospecies.RemoveAll

540   Debug.Print

      ' 1
550   Call dicPseudospecies.Add("UNGU", "UNGU")
560   Debug.Print CountSpeciesInDictionary(dicPseudospecies)
570   dicPseudospecies.RemoveAll

      ' 1
580   Call dicPseudospecies.Add("UNGU", "UNGU")
590   Call dicPseudospecies.Add("RBGU", "RBGU")
600   Debug.Print CountSpeciesInDictionary(dicPseudospecies)
610   dicPseudospecies.RemoveAll

      ' 2
620   Call dicPseudospecies.Add("UNGU", "UNGU")
630   Call dicPseudospecies.Add("RBGU", "RBGU")
640   Call dicPseudospecies.Add("HERG", "HERG")
650   Debug.Print CountSpeciesInDictionary(dicPseudospecies)
660   dicPseudospecies.RemoveAll

      ' 3
670   Call dicPseudospecies.Add("UNGU", "UNGU")
680   Call dicPseudospecies.Add("RBGU", "RBGU")
690   Call dicPseudospecies.Add("HERG", "HERG")
700   Call dicPseudospecies.Add("GBBG", "GBBG")
710   Debug.Print CountSpeciesInDictionary(dicPseudospecies)
720   dicPseudospecies.RemoveAll

      ' 1
730   Call dicPseudospecies.Add("RBGU", "RBGU")
740   Debug.Print CountSpeciesInDictionary(dicPseudospecies)
750   dicPseudospecies.RemoveAll

      ' 2
760   Call dicPseudospecies.Add("RBGU", "RBGU")
770   Call dicPseudospecies.Add("HERG", "HERG")
780   Debug.Print CountSpeciesInDictionary(dicPseudospecies)
790   dicPseudospecies.RemoveAll

      ' 3
800   Call dicPseudospecies.Add("RBGU", "RBGU")
810   Call dicPseudospecies.Add("HERG", "HERG")
820   Call dicPseudospecies.Add("GBBG", "GBBG")
830   Debug.Print CountSpeciesInDictionary(dicPseudospecies)
840   dicPseudospecies.RemoveAll

850   Debug.Print

      ' 1
860   Call dicPseudospecies.Add("UNEM", "UNEM")
870   Debug.Print CountSpeciesInDictionary(dicPseudospecies)
880   dicPseudospecies.RemoveAll

      ' 1
890   Call dicPseudospecies.Add("UNEM", "UNEM")
900   Call dicPseudospecies.Add("TRFL", "TRFL")
910   Debug.Print CountSpeciesInDictionary(dicPseudospecies)
920   dicPseudospecies.RemoveAll

      ' 1
930   Call dicPseudospecies.Add("UNEM", "UNEM")
940   Call dicPseudospecies.Add("TRFL", "TRFL")
950   Call dicPseudospecies.Add("ALFL", "ALFL")
960   Debug.Print CountSpeciesInDictionary(dicPseudospecies)
970   dicPseudospecies.RemoveAll

      ' 1
980   Call dicPseudospecies.Add("UNEM", "UNEM")
990   Call dicPseudospecies.Add("TRFL", "TRFL")
1000  Call dicPseudospecies.Add("WIFL", "WIFL")
1010  Debug.Print CountSpeciesInDictionary(dicPseudospecies)
1020  dicPseudospecies.RemoveAll

      ' 2
1030  Call dicPseudospecies.Add("UNEM", "UNEM")
1040  Call dicPseudospecies.Add("TRFL", "TRFL")
1050  Call dicPseudospecies.Add("WIFL", "WIFL")
1060  Call dicPseudospecies.Add("ALFL", "ALFL")
1070  Debug.Print CountSpeciesInDictionary(dicPseudospecies)
1080  dicPseudospecies.RemoveAll

      ' 1
1090  Call dicPseudospecies.Add("TRFL", "TRFL")
1100  Debug.Print CountSpeciesInDictionary(dicPseudospecies)
1110  dicPseudospecies.RemoveAll

      ' 1
1120  Call dicPseudospecies.Add("TRFL", "TRFL")
1130  Call dicPseudospecies.Add("ALFL", "ALFL")
1140  Debug.Print CountSpeciesInDictionary(dicPseudospecies)
1150  dicPseudospecies.RemoveAll

      ' 1
1160  Call dicPseudospecies.Add("TRFL", "TRFL")
1170  Call dicPseudospecies.Add("WIFL", "WIFL")
1180  Debug.Print CountSpeciesInDictionary(dicPseudospecies)
1190  dicPseudospecies.RemoveAll

      ' 2
1200  Call dicPseudospecies.Add("TRFL", "TRFL")
1210  Call dicPseudospecies.Add("WIFL", "WIFL")
1220  Call dicPseudospecies.Add("ALFL", "ALFL")
1230  Debug.Print CountSpeciesInDictionary(dicPseudospecies)
1240  dicPseudospecies.RemoveAll

1250  Call dicPseudospecies.Add("COYE", "COYE")
1260  Call dicPseudospecies.Add("HYWA", "HYWA")
1270  Debug.Print "COYE, HYWA " & CountSpeciesInDictionary(dicPseudospecies)
1280  dicPseudospecies.RemoveAll
    
1290  Call dicPseudospecies.Add("COYE", "COYE")
1300  Call dicPseudospecies.Add("BRWA", "BRWA")
1310  Debug.Print "COYE, BRWA " & CountSpeciesInDictionary(dicPseudospecies)
1320  dicPseudospecies.RemoveAll
          
1330  Call dicPseudospecies.Add("COYE", "COYE")
1340  Call dicPseudospecies.Add("LAWA", "LAWA")
1350  Debug.Print "COYE, LAWA " & CountSpeciesInDictionary(dicPseudospecies)
1360  dicPseudospecies.RemoveAll
          
End Sub
