Option Compare Database
Option Explicit


'---------------------------------------------------------------------------------------
' DisplayImportErrorTables
'---------------------------------------------------------------------------------------
 
'Public Sub DisplayImportErrorTables()
'On Error GoTo Err_label
'
'Dim oTable As TableDef
'Dim fImportErrors As Boolean
'fImportErrors = False
'
'For Each oTable In CurrentDb.TableDefs
'If oTable.Name Like "*ImportErrors*" Then
'    DoCmd.OpenTable oTable.Name, acViewNormal, acReadOnly
'    fImportErrors = True
'End If
'Next oTable
'
'If fImportErrors Then
'    MsgBox "Access detected errors when importing records from Excel", vbOKOnly, "Import"
'End If
'
''DD Error Handler Start
'Exit_label:
'     Exit Sub
'Err_label:
'     Select Case err.Number
'     Case Else
'    Call LogError("basBandsTable", "DisplayImportErrorTables")
'     End Select
'     Resume Exit_label
''DD Error Handler End
'End Sub

'---------------------------------------------------------------------------------------
' DeleteImportErrorTables
'---------------------------------------------------------------------------------------
 
'Public Sub DeleteImportErrorTables()
'On Error GoTo Err_label
'Dim oTable As TableDef
'
'For Each oTable In CurrentDb.TableDefs
'If oTable.Name Like "*ImportErrors*" Then
'    CurrentDb.TableDefs.Delete oTable.Name
'End If
'Next oTable
'
''DD Error Handler Start
'Exit_label:
'     Exit Sub
'Err_label:
'     Select Case err.Number
'     Case Else
'    Call LogError("basBandsTable", "DeleteImportErrorTables")
'     End Select
'     Resume Exit_label
''DD Error Handler End
'
'End Sub

'---------------------------------------------------------------------------------------
' IsRecaptureDuplicate
'
' if duplicate, returns the key (IDBand)
'
' Assumptions:
'   BandPrefix, BandSuffix and CaptureDate exist and are valid
'---------------------------------------------------------------------------------------
'
'Private Function IsRecaptureDuplicate( _
'    ByVal strBandPrefix As String, _
'    ByVal strBandSuffix As String, _
'    ByVal datCaptureDate As Date, _
'    ByRef strNotBypassableErr As String, _
'    ByRef strBypassableErr As String, _
'    ByRef lngIDBand As Long) As Boolean
'
'On Error GoTo Err_label
'
'strNotBypassableErr = ""
'strBypassableErr = ""
'lngIDBand = 0
'
'Dim strCriterion As String
'
'strCriterion = "BandPrefix = '" & strBandPrefix & "' AND " & _
'               "BandSuffix = '" & strBandSuffix & "' AND " & _
'               "(Disposition = 'R' OR Disposition = 'F') AND " & _
'               "CaptureDate = #" & Format(datCaptureDate, "mm/dd/yyyy") & "#"
'
'If (DCount("*", "tblCaptures", strCriterion) <> 0) Then
'    strNotBypassableErr = strNotBypassableErr & _
'        strBandPrefix & "-" & strBandSuffix & " on " & _
'        Format(datCaptureDate, "mm/dd/yyyy") & " is a duplicate recapture" & vbCrLf
'    lngIDBand = Nz(DLookup("IDBand", "tblCaptures", strCriterion))
'End If
'
'IsRecaptureDuplicate = (strNotBypassableErr <> "") Or (strBypassableErr <> "")
'
''DD Error Handler Start
'Exit_label:
'     Exit Function
'Err_label:
'     Select Case err.Number
'     Case Else
'    Call LogError("basBandsTable", "IsRecaptureDuplicate")
'     End Select
'     Resume Exit_label
''DD Error Handler End
'
'End Function

'---------------------------------------------------------------------------------------
' IsNewCaptureDuplicate
'
' if duplicate, returns the key (IDBand)
'
' Assumptions:
'   BandPrefix, BandSuffix exist in the imported Excel file and are valid
'   BandPrefix, BandSuffix exist in tblCaptures and are valid
'---------------------------------------------------------------------------------------
'
'Private Function IsNewCaptureDuplicate( _
'    ByVal strBandPrefix As String, _
'    ByVal strBandSuffix As String, _
'    ByRef strNotBypassableErr As String, _
'    ByRef strBypassableErr As String, _
'    ByRef lngIDBand As Long) As Boolean
'On Error GoTo Err_label
'
'strNotBypassableErr = ""
'strBypassableErr = ""
'lngIDBand = 0
'
'Dim strCriterion As String
'strCriterion = "BandPrefix = '" & strBandPrefix & "' AND " & _
'    "BandSuffix = '" & strBandSuffix & "' AND " & _
'    " NOT (Disposition = 'F' or Disposition = 'R')"
'
'If (DCount("*", "tblCaptures", strCriterion) <> 0) Then
'    lngIDBand = Nz(DLookup("IDBand", "tblCaptures", strCriterion))
'    strNotBypassableErr = "Duplicate New Capture " & strBandPrefix & "-" & strBandSuffix
'End If
'
'IsNewCaptureDuplicate = (strNotBypassableErr <> "") Or (strBypassableErr <> "")
'
''DD Error Handler Start
'Exit_label:
'     Exit Function
'Err_label:
'     Select Case err.Number
'     Case Else
'    Call LogError("basBandsTable", "IsNewCaptureDuplicate")
'     End Select
'     Resume Exit_label
''DD Error Handler End
'
'End Function


'---------------------------------------------------------------------------------------
' GetTypedCapturesRecordFromVariantCapturesRecord
'---------------------------------------------------------------------------------------
'
'Public Sub GetTypedCapturesRecordFromVariantCapturesRecord( _
'    ByRef v As CapturesType, ByRef B As BandsType)
'On Error GoTo Err_label
'
'B.BandPrefix = Trim(Nz(v.BandPrefix))
'B.BandSuffix = Trim(Nz(v.BandSuffix))
'B.Disposition = UCase(Trim(Nz(v.Disposition)))
'B.Species = Nz(v.Species)
'B.Age = Nz(v.Age)
'B.HowAged = Nz(v.HowAged)
'B.Sex = Nz(v.Sex)
'B.HowSexed = Nz(v.HowSexed)
'
'If IsNumeric(Nz(v.WingChord)) Then
'    B.WingChord = Round(Nz(v.WingChord), 0)
'Else
'    B.WingChord = 0
'End If
'
'B.Fat = Nz(v.Fat)
'
'If IsNumeric(Nz(v.Weight)) Then
'    B.Weight = CDbl(Nz(v.Weight))
'Else
'    B.Weight = 0
'End If
'
'If IsDate(Nz(v.CaptureDate)) Then
'    B.CaptureDate = CDate(Nz(v.CaptureDate))
'Else
'    B.CaptureDate = 0
'End If
'
'If IsTime(Nz(v.WeightTime)) Then
'    B.WeightTime = CDate(Nz(v.WeightTime))
'Else
'    B.WeightTime = 0
'End If
'
'B.Bander = Nz(v.Bander)
'B.Net = Nz(v.Net)
'B.Scribe = Nz(v.Scribe)
'B.BirdStatus = Nz(v.BirdStatus)
'B.Location = Nz(v.Location)
'B.Program = Nz(v.Program)
'
'
'B.ProbableAge = Nz(v.ProbableAge)
'B.ProbableSex = Nz(v.ProbableSex)
'B.NotesForMBO = Nz(v.NotesForMBO)
'B.PresentCondition = Nz(v.PresentCondition)
'B.HowObtainedCode = Nz(v.HowObtainedCode)
'
'Dim i As Integer
'For i = 1 To conMaxUserField
'    B.F(i) = Nz(v.F(i), "")
'Next i
'
''DD Error Handler Start
'Exit_label:
'     Exit Sub
'Err_label:
'     Select Case err.Number
'     Case Else
'          Call LogError("basBandsTable", "GetTypedCapturesRecordFromVariantCapturesRecord")
'     End Select
'     Resume Exit_label
''DD Error Handler End
'
'End Sub

'---------------------------------------------------------------------------------------
' RejectRecord
'
' Add rejected records to tblRejected
'---------------------------------------------------------------------------------------
'
'Private Sub RejectRecord(ByVal rstRejected As DAO.Recordset, _
'    ByRef v As CapturesType, ByRef ReasonForRejection As String)
'
'On Error GoTo Err_label
'
'rstRejected.AddNew
'
'rstRejected.Fields("BandPrefix") = v.BandPrefix
'rstRejected.Fields("BandSuffix") = v.BandSuffix
'rstRejected.Fields("Disposition") = v.Disposition
'rstRejected.Fields("Species") = v.Species
'rstRejected.Fields("Age") = v.Age
'rstRejected.Fields("HowAged") = v.HowAged
'rstRejected.Fields("Sex") = v.Sex
'rstRejected.Fields("HowSexed") = v.HowSexed
'rstRejected.Fields("WingChord") = v.WingChord
'rstRejected.Fields("Fat") = v.Fat
'rstRejected.Fields("Weight") = v.Weight
'rstRejected.Fields("CaptureDate") = v.CaptureDate
'rstRejected.Fields("WeightTime") = v.WeightTime
'rstRejected.Fields("Bander") = v.Bander
'rstRejected.Fields("Net") = v.Net
'rstRejected.Fields("Scribe") = v.Scribe
'rstRejected.Fields("BirdStatus") = v.BirdStatus
'rstRejected.Fields("Location") = v.Location
'rstRejected.Fields("ProbableAge") = v.ProbableAge
'rstRejected.Fields("ProbableSex") = v.ProbableSex
'rstRejected.Fields("NotesForMBO") = v.NotesForMBO
'rstRejected.Fields("PresentCondition") = v.PresentCondition
'rstRejected.Fields("HowObtainedCode") = v.HowObtainedCode
''260   rstRejected.Fields("IsAuxMarkerCoded") = v.IsAuxMarkerCoded
''270   rstRejected.Fields("AuxMarkerType") = v.AuxMarkerType
''280   rstRejected.Fields("AuxMarkerCode") = v.AuxMarkerCode
''290   rstRejected.Fields("AuxMarkerBandColor") = v.AuxMarkerBandColor
''300   rstRejected.Fields("AuxMarkerCodeColor") = v.AuxMarkerCodeColor
'rstRejected.Fields("Program") = v.Program
'
'rstRejected.Fields("ReasonForRejection") = Left(ReasonForRejection, 255)
'
'rstRejected.Update
'
''DD Error Handler Start
'Exit_label:
'     Exit Sub
'Err_label:
'     Select Case err.Number
'     Case Else
'          Call LogError("basBandsTable", "RejectRecord")
'     End Select
'     Resume Exit_label
''DD Error Handler End
'
'End Sub

'---------------------------------------------------------------------------------------
' OverwriteRecord
'---------------------------------------------------------------------------------------
'
'Private Sub OverwriteRecord( _
'    ByVal IDBand As Long, ByRef stats As CapturesImportStatistics, _
'    rstCaptures As DAO.Recordset, v As CapturesType, _
'    B As BandsType, SpecialImport As Boolean)
'
'On Error GoTo Err_label
'
'CurrentDb.Execute _
'    "INSERT INTO tblOverwritten " & _
'    "SELECT * FROM tblCaptures WHERE IDBand = " & IDBand
'
'If SpecialImport Then
'    CurrentDb.Execute _
'        "DELETE * FROM tblCaptures WHERE IDBand = " & IDBand
'    Call StoreBandsRecord(rstCaptures, v, B, SpecialImport)
'Else
'
'    ' Store only the fields that are imported from Bandit
'    ' The following fields are not changed
'    '   AutoHistory
'    '   Program
'    '   F1, F2, etc
'    ' ToBeValidated, Valid and Invalid are assigned Null
'
'    rstCaptures.FindFirst "IDBand = " & IDBand
'    If rstCaptures.NoMatch Then
'        LogError "basBandsTable", "OverwriteRecord", "FindFirst failed to find a record", True
'        GoTo Exit_label
'    End If
'
'    rstCaptures.Edit
'    rstCaptures.Fields("BandPrefix") = B.BandPrefix
'    rstCaptures.Fields("BandSuffix") = B.BandSuffix
'    rstCaptures.Fields("Disposition") = B.Disposition
'    rstCaptures.Fields("Species") = IIf(IsNull(v.Species), Null, B.Species)
'    rstCaptures.Fields("Age") = IIf(IsNull(v.Age), Null, B.Age)
'    rstCaptures.Fields("HowAged") = IIf(IsNull(v.HowAged), Null, B.HowAged)
'    rstCaptures.Fields("Sex") = IIf(IsNull(v.Sex), Null, B.Sex)
'    rstCaptures.Fields("HowSexed") = IIf(IsNull(v.HowSexed), Null, B.HowSexed)
'    rstCaptures.Fields("WingChord") = IIf(IsNull(v.WingChord), Null, B.WingChord)
'    rstCaptures.Fields("Fat") = IIf(IsNull(v.Fat), Null, B.Fat)
'    rstCaptures.Fields("Weight") = IIf(IsNull(v.Weight), Null, B.Weight)
'    If B.CaptureDate = 0 Then
'        rstCaptures.Fields("CaptureDate") = Null
'    Else
'        rstCaptures.Fields("CaptureDate") = IIf(IsNull(v.CaptureDate), Null, B.CaptureDate)
'    End If
'    rstCaptures.Fields("WeightTime") = IIf(IsNull(v.WeightTime), Null, B.WeightTime)
'    rstCaptures.Fields("Bander") = IIf(IsNull(v.Bander), Null, B.Bander)
'    rstCaptures.Fields("Net") = IIf(IsNull(v.Net), Null, B.Net)
'    rstCaptures.Fields("Scribe") = IIf(IsNull(v.Scribe), Null, B.Scribe)
'    rstCaptures.Fields("BirdStatus") = IIf(IsNull(v.BirdStatus), Null, B.BirdStatus)
'    rstCaptures.Fields("Location") = IIf(IsNull(v.Location), Null, B.Location)
'    rstCaptures.Fields("ProbableAge") = IIf(IsNull(v.ProbableAge), Null, B.ProbableAge)
'    rstCaptures.Fields("ProbableSex") = IIf(IsNull(v.ProbableSex), Null, B.ProbableSex)
'    rstCaptures.Fields("NotesForMBO") = IIf(IsNull(v.NotesForMBO), Null, B.NotesForMBO)
'    rstCaptures.Fields("PresentCondition") = IIf(IsNull(v.PresentCondition), Null, B.PresentCondition)
'    rstCaptures.Fields("HowObtainedCode") = IIf(IsNull(v.HowObtainedCode), Null, B.HowObtainedCode)
''400       rstCaptures.Fields("IsAuxMarkerCoded") = IIf(IsNull(v.IsAuxMarkerCoded), Null, B.IsAuxMarkerCoded)
''410       rstCaptures.Fields("AuxMarkerType") = IIf(IsNull(v.AuxMarkerType), Null, B.AuxMarkerType)
''420       rstCaptures.Fields("AuxMarkerCode") = IIf(IsNull(v.AuxMarkerCode), Null, B.AuxMarkerCode)
''430       rstCaptures.Fields("AuxMarkerBandColor") = IIf(IsNull(v.AuxMarkerBandColor), Null, B.AuxMarkerBandColor)
''440       rstCaptures.Fields("AuxMarkerCodeColor") = IIf(IsNull(v.AuxMarkerCodeColor), Null, B.AuxMarkerCodeColor)
''
'    ' ToBeExported, Valid, Invalid
'
'    rstCaptures.Fields("ToBeExported") = False
'    rstCaptures.Fields("Valid") = Null
'    rstCaptures.Fields("Invalid") = Null
'
'    rstCaptures.Update
'
'End If
'
'If B.Disposition = "R" Or B.Disposition = "F" Then
'    stats.countDuplicateRecaptureRecords = stats.countDuplicateRecaptureRecords + 1
'Else
'    stats.countDuplicateNewCaptureRecords = stats.countDuplicateNewCaptureRecords + 1
'End If
'
''DD Error Handler Start
'Exit_label:
'     Exit Sub
'Err_label:
'     Select Case err.Number
'     Case Else
'    Call LogError("basBandsTable", "OverwriteRecord")
'     End Select
'     Resume Exit_label
''DD Error Handler End
'End Sub

'---------------------------------------------------------------------------------------
' StoreBandsRecord
'
' Store the record in tblCaptures
'---------------------------------------------------------------------------------------
'
'Private Sub StoreBandsRecord(rstCaptures As DAO.Recordset, v As CapturesType, _
'    B As BandsType, ByVal SpecialImport As Boolean)
'On Error GoTo Err_label
'
'rstCaptures.AddNew
'rstCaptures.Fields("Disposition") = B.Disposition
'rstCaptures.Fields("BandPrefix") = B.BandPrefix
'rstCaptures.Fields("BandSuffix") = B.BandSuffix
'rstCaptures.Fields("Species") = IIf(IsNull(v.Species), Null, B.Species)
'rstCaptures.Fields("Age") = IIf(IsNull(v.Age), Null, B.Age)
'rstCaptures.Fields("HowAged") = IIf(IsNull(v.HowAged), Null, B.HowAged)
'rstCaptures.Fields("Sex") = IIf(IsNull(v.Sex), Null, B.Sex)
'rstCaptures.Fields("HowSexed") = IIf(IsNull(v.HowSexed), Null, B.HowSexed)
'rstCaptures.Fields("WingChord") = IIf(IsNull(v.WingChord), Null, B.WingChord)
'rstCaptures.Fields("Fat") = IIf(IsNull(v.Fat), Null, B.Fat)
'rstCaptures.Fields("Weight") = IIf(IsNull(v.Weight), Null, B.Weight)
'If B.CaptureDate = 0 Then
'    rstCaptures.Fields("CaptureDate") = Null
'Else
'    rstCaptures.Fields("CaptureDate") = IIf(IsNull(v.CaptureDate), Null, B.CaptureDate)
'End If
'rstCaptures.Fields("WeightTime") = IIf(IsNull(v.WeightTime), Null, B.WeightTime)
'rstCaptures.Fields("Bander") = IIf(IsNull(v.Bander), Null, B.Bander)
'rstCaptures.Fields("Net") = IIf(IsNull(v.Net), Null, B.Net)
'rstCaptures.Fields("Scribe") = IIf(IsNull(v.Scribe), Null, B.Scribe)
'rstCaptures.Fields("BirdStatus") = IIf(IsNull(v.BirdStatus), Null, B.BirdStatus)
'rstCaptures.Fields("Location") = IIf(IsNull(v.Location), Null, B.Location)
'rstCaptures.Fields("Program") = IIf(IsNull(v.Program), Null, B.Program)
'
'
'rstCaptures.Fields("ProbableAge") = IIf(IsNull(v.ProbableAge), Null, B.ProbableAge)
'rstCaptures.Fields("ProbableSex") = IIf(IsNull(v.ProbableSex), Null, B.ProbableSex)
'rstCaptures.Fields("NotesForMBO") = IIf(IsNull(v.NotesForMBO), Null, B.NotesForMBO)
'rstCaptures.Fields("PresentCondition") = IIf(IsNull(v.PresentCondition), Null, B.PresentCondition)
'rstCaptures.Fields("HowObtainedCode") = IIf(IsNull(v.HowObtainedCode), Null, B.HowObtainedCode)
'rstCaptures.Fields("ToBeExported") = False
'rstCaptures.Fields("AutoHistory") = v.AutoHistory
'
'Dim i As Integer
'For i = 1 To conMaxUserField
'    rstCaptures("F" & i) = v.F(i)
'Next i
'
'' Update F
'
'Dim strF As String
'strF = ""
'
'Dim UserFieldAbbreviation As String
'Dim val As String
'Dim uf As Integer
'For uf = 1 To conMaxUserField
'    UserFieldAbbreviation = _
'        Nz(DLookup("UserFieldAbbreviation", _
'            "tblUserFields", _
'            "UserFieldID = " & uf))
'    val = Nz(rstCaptures("F" & uf))
'    If UserFieldAbbreviation <> "" And val <> "" Then
'        strF = strF & UserFieldAbbreviation & "=" & val & " "
'    End If
'Next uf
'rstCaptures("F") = strF
'
'' Update the Valid and Invalid fields
'
'Dim strNotBypassableMsg As String
'Dim strBypassableMsg As String
'Dim fIsLineBlank As Boolean
'
'If SpecialImport Then
'    rstCaptures.Fields("ToBeExported") = v.ToBeExported
'    rstCaptures.Fields("BypassErrors") = v.BypassErrors
'    If v.ToBeExported Then
'        Dim IsValid As basTypes.IsValidType
'        Call ValidateBandsRecord(B, strNotBypassableMsg, strBypassableMsg, fIsLineBlank, IsValid)
'        If strNotBypassableMsg <> "" Then
'            rstCaptures.Fields("Valid") = Null
'            rstCaptures.Fields("Invalid") = "E"
'        ElseIf strBypassableMsg <> "" Then
'            rstCaptures.Fields("Valid") = Null
'            rstCaptures.Fields("Invalid") = "x"
'        Else
'            rstCaptures.Fields("Valid") = "v"
'            rstCaptures.Fields("Invalid") = Null
'        End If
'    Else
'        rstCaptures.Fields("Valid") = Null
'        rstCaptures.Fields("Invalid") = Null
'        rstCaptures.Fields("BypassErrors") = False
'    End If
'Else
'    rstCaptures.Fields("Valid") = Null
'    rstCaptures.Fields("Invalid") = Null
'    rstCaptures.Fields("BypassErrors") = False
'End If
'
'rstCaptures.Update
'
''DD Error Handler Start
'Exit_label:
'     Exit Sub
'Err_label:
'     Select Case err.Number
'     Case Else
'          Call LogError("basBandsTable", "StoreBandsRecord")
'     End Select
'     Resume Exit_label
''DD Error Handler End
'
'End Sub

'---------------------------------------------------------------------------------------
' ProcessRecapture
'---------------------------------------------------------------------------------------
'
'Private Sub ProcessRecapture(ByRef B As BandsType, v As CapturesType, _
'    ByRef stats As CapturesImportStatistics, _
'    rstCaptures As DAO.Recordset, rstRejected As DAO.Recordset, ByRef SpecialImport As Boolean)
'On Error GoTo Err_label
'
'' === Determine the disposition R or F
'
'' If there is a banding record with the same band number
''   If the banding record has Disposition 4, 8 or 9
''       Reject the recapture record "Band BADE or BALO"
''       Exit
''   If the banding date > the recapture date
''      Reject the recapture record "Recapture before banding"
''      Exit
''   If the banding date = the recapture date
''      Reject the recapture record "Recapture on same day as banding"
''      Exit
''   Disposition = "R"
'' Else
''   Disposition = "F"
'
'Dim strCriterion As String
'strCriterion = _
'    "[BandPrefix] = '" & B.BandPrefix & "' AND " & _
'    "[BandSuffix] = '" & B.BandSuffix & "' AND " & _
'    "NOT ([Disposition] = 'R' OR [Disposition] = 'F')"
'
'If DCount("*", "tblCaptures", strCriterion) > 0 Then
'
'' There is a corresponding banding
'
'    Dim strDisposition As String
'    strDisposition = DLookup("[Disposition]", "tblCaptures", strCriterion)
'    If strDisposition = "4" Or strDisposition = "8" Or strDisposition = "9" Then
'        Call RejectRecord(rstRejected, v, "Recapture for a Disposition 4, 8 or 9 band")
'        stats.countRejectedRecords = stats.countRejectedRecords + 1
'        Exit Sub
'    End If
'
'    Dim datBandingDate As Date
'    datBandingDate = DLookup("[CaptureDate]", "tblCaptures", strCriterion)
'    If datBandingDate > B.CaptureDate Then
'        Call RejectRecord(rstRejected, v, "Recapture before banding")
'        stats.countRejectedRecords = stats.countRejectedRecords + 1
'        Exit Sub
'    ElseIf datBandingDate = B.CaptureDate Then
'        Call RejectRecord(rstRejected, v, "Recapture on same day as banding")
'        stats.countRejectedRecords = stats.countRejectedRecords + 1
'        Exit Sub
'    End If
'    B.Disposition = "R"
'    v.Disposition = "R"
'Else
'    B.Disposition = "F"
'    v.Disposition = "F"
'End If
'
'' === Process duplicate recapture records
'
'' If the recapture is a duplicate
''   If the recapture and its duplicate are identical
''     Exit
''   Store the duplicate in tblOverwritten
''   Delete the duplicate from tblCaptures
''   Store
''   countDuplicateRecaptureRecords++
'
'Dim strNotBypassableErr As String
'Dim strBypassableErr As String
'Dim lngBandID As Long
'Dim b2 As BandsType
'
'If IsRecaptureDuplicate(B.BandPrefix, B.BandSuffix, B.CaptureDate, _
'     strNotBypassableErr, strBypassableErr, _
'     lngBandID) Then
'     Call GetCaptureRecord(lngBandID, b2)
'     If AreTwoCaptureRecordsEqual(B, b2) Then
'         Exit Sub
'     Else
'         Call OverwriteRecord(lngBandID, stats, rstCaptures, v, B, SpecialImport)
'     End If
'Else
'
'    ' Store recapture record
'
'    Call StoreBandsRecord(rstCaptures, v, B, SpecialImport)
'    stats.countRecaptureRecords = stats.countRecaptureRecords + 1
'End If
'
'
''DD Error Handler Start
'Exit_label:
'     Exit Sub
'Err_label:
'     Select Case err.Number
'     Case Else
'          Call LogError("basBandsTable", "Processrecapture")
'     End Select
'     Resume Exit_label
''DD Error Handler End
'
'End Sub

'---------------------------------------------------------------------------------------
' ProcessBanding
'---------------------------------------------------------------------------------------
'
'Private Sub ProcessBanding(B As BandsType, v As CapturesType, _
'     stats As CapturesImportStatistics, _
'     rstCaptures As DAO.Recordset, rstRejected As DAO.Recordset, _
'     ByVal SpecialImport As Boolean)
'On Error GoTo Err_label
'
'Dim strNotBypassableErr As String
'Dim strBypassableErr As String
'Dim lngBandID As Long
'Dim b2 As BandsType
'
'' === Process Lost and Destroyed bands
'
'If B.Disposition = "4" Or B.Disposition = "8" Or B.Disposition = "9" Then
'
'' If there is a recapture records with the same band number
''   Reject the band record "Recapture for a destroyed or lost band"
''   countRejectedRecaptureRecords++
''   Exit Sub
'
'    Dim strCriterion As String
'    strCriterion = _
'        "([Disposition] = 'R' OR [Disposition] = 'F' ) AND " & _
'        " [BandPrefix] = '" & B.BandPrefix & "' AND " & _
'        " [BandSuffix] = '" & B.BandSuffix & "'"
'    If DCount("*", "tblCaptures", strCriterion) > 0 Then
'         Call RejectRecord(rstRejected, v, "Recapture for a destroyed or lost band")
'         stats.countRejectedRecords = stats.countRejectedRecords + 1
'         Exit Sub
'    End If
'End If
'
'' If there are any recapture records with the same band number AND recapture date <= banding date
''     Reject band record "Recapture before or on same day as banding"
''     countRejectedRecords++
''     Exit Sub
'
'strCriterion = _
'    " ([Disposition] = 'R' OR [Disposition] = 'F' ) AND " & _
'    "  [BandPrefix] = '" & B.BandPrefix & "' AND " & _
'    "  [BandSuffix] = '" & B.BandSuffix & "' AND " & _
'    "  [CaptureDate] <= #" & Format(B.CaptureDate, "mm/dd/yyyy") & "#"
'
'If DCount("*", "tblCaptures", strCriterion) > 0 Then
'    Call RejectRecord(rstRejected, v, "Recapture before or on same day as banding")
'    stats.countRejectedRecords = stats.countRejectedRecords + 1
'    Exit Sub
'End If
'
'' === Process duplicate banding records
''
'' If the banding record is a duplicate
''   If the banding record and its duplicate are identical
''      Exit
''   else
''      Store the duplicate in tblOverwritten
''      Delete the duplicate from tblCaptures
''      countDuplicateNewCaptureRecords++
'' Else
''   countNewCaptureRecords++
'
'If IsNewCaptureDuplicate(B.BandPrefix, B.BandSuffix, _
'    strNotBypassableErr, strBypassableErr, _
'    lngBandID) Then
'    Call GetCaptureRecord(lngBandID, b2)
'    If AreTwoCaptureRecordsEqual(B, b2) Then
'        Exit Sub
'    Else
'        Call OverwriteRecord(lngBandID, stats, rstCaptures, v, B, SpecialImport)
'    End If
'Else
'
'' Store band record
'
'Call StoreBandsRecord(rstCaptures, v, B, SpecialImport)
'stats.countNewCaptureRecords = stats.countNewCaptureRecords + 1
'
'End If
'
'' Change the Disposition of all recaptures with the same band number to "R"
'
'CurrentDb.Execute _
'    "UPDATE tblCaptures " & _
'    "SET Disposition = 'R' " & _
'    "WHERE [Disposition] = 'F'  AND " & _
'    "      [BandPrefix] = '" & B.BandPrefix & "' AND " & _
'    "      [BandSuffix] = '" & B.BandSuffix & "'"
'
''DD Error Handler Start
'Exit_label:
'     Exit Sub
'Err_label:
'     Select Case err.Number
'     Case Else
'          Call LogError("basBandsTable", "ProcessBanding")
'     End Select
'     Resume Exit_label
''DD Error Handler End
'End Sub

'---------------------------------------------------------------------------------------
' SaveRejectedRecordsToExcel
'---------------------------------------------------------------------------------------
'
'Public Sub SaveRejectedRecordsToExcel(ByRef strSaveFilename As String)
'On Error GoTo Err_label
'
'Dim strMyDocumentsPath As String
'
'strMyDocumentsPath = Rep_Documents()
'strSaveFilename = strMyDocumentsPath & "\" & _
'    Format(Now, "yyyy-mm-dd hh\hnn") & _
'    " MBO Data Entry rejected Excel records " & ".xls"
'
'If FileExists(strSaveFilename) Then
'    On Error Resume Next
'    SetAttr strSaveFilename, vbNormal
'    Kill strSaveFilename
'    On Error GoTo Err_label
'End If
'
'DoCmd.TransferSpreadsheet acExport, acSpreadsheetTypeExcel8, _
'"tblRejected", strSaveFilename, True
'
''DD Error Handler Start
'Exit_label:
'     Exit Sub
'Err_label:
'     Select Case err.Number
'     Case Else
'          Call LogError("basBandsTable", "SaveRejectedRecordsToExcel")
'     End Select
'     Resume Exit_label
''DD Error Handler End
'End Sub

'---------------------------------------------------------------------------------------
' SaveOverwrittenRecordsToExcel
'---------------------------------------------------------------------------------------
'
'Public Sub SaveOverwrittenRecordsToExcel(ByRef strSaveFilename As String)
'On Error GoTo Err_label
'
'Dim strMyDocumentsPath As String
'
'strMyDocumentsPath = Rep_Documents()
'strSaveFilename = strMyDocumentsPath & "\" & _
'    Format(Now, "yyyy-mm-dd hh\hnn") & _
'    " MBO Data Entry overwritten capture records " & ".xls"
'
'If FileExists(strSaveFilename) Then
'    On Error Resume Next
'    SetAttr strSaveFilename, vbNormal
'    Kill strSaveFilename
'    On Error GoTo Err_label
'End If
'
'DoCmd.TransferSpreadsheet acExport, acSpreadsheetTypeExcel8, _
'"tblOverwritten", strSaveFilename, True
'
''DD Error Handler Start
'Exit_label:
'     Exit Sub
'Err_label:
'     Select Case err.Number
'     Case Else
'          Call LogError("basBandsTable", "SaveOverwrittenRecordsToExcel")
'     End Select
'     Resume Exit_label
''DD Error Handler End
'End Sub

'---------------------------------------------------------------------------------------
' DisplaySummaryReport
'---------------------------------------------------------------------------------------
'
'Public Sub DisplaySummaryReport(stats As CapturesImportStatistics, _
'    strSaveFilenameRejected As String, _
'    strSaveFilenameOverwritten As String)
'On Error GoTo Err_label
'
'Dim strMessage As String
'
'strMessage = stats.countNewCaptureRecords & _
'   " band records added" & vbCrLf
'strMessage = strMessage & stats.countRecaptureRecords & _
'   " recapture records added" & vbCrLf & vbCrLf
'If stats.countRejectedRecords > 0 Then
'   strMessage = strMessage & stats.countRejectedRecords & " rejected" & vbCrLf & _
'   "Rejected records saved to " & strSaveFilenameRejected & vbCrLf & vbCrLf
'End If
'If stats.countDuplicateNewCaptureRecords + stats.countDuplicateRecaptureRecords > 0 Then
'   If stats.countDuplicateNewCaptureRecords > 0 Then
'        strMessage = strMessage & stats.countDuplicateNewCaptureRecords & _
'            " band records overwritten" & vbCrLf
'   End If
'   If stats.countDuplicateRecaptureRecords > 0 Then
'        strMessage = strMessage & stats.countDuplicateRecaptureRecords & _
'             " recapture records overwritten" & vbCrLf
'   End If
'   strMessage = strMessage & "Overwritten records saved to " & _
'       strSaveFilenameOverwritten & vbCrLf & vbCrLf
'End If
'
'MsgBox strMessage
'
''DD Error Handler Start
'Exit_label:
'     Exit Sub
'Err_label:
'     Select Case err.Number
'     Case Else
'          Call LogError("basBandsTable", "DisplaySummaryReport")
'     End Select
'     Resume Exit_label
''DD Error Handler End
'End Sub
