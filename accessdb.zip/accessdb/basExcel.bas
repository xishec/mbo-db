'---------------------------------------------------------------------------------------
' Module    : basExcel
' Author    : David Davey
'---------------------------------------------------------------------------------------

Option Compare Database
Option Explicit

'---------------------------------------------------------------------------------------
' ExcelDeleteAllButFirstWorksheet
'
' Deletes all but the first worksheet from an Excel workbook
'
' IN  oBook    reference to a workbook
'---------------------------------------------------------------------------------------
' Call ExcelDeleteAllButFirstWorksheet(oBook)

Public Sub ExcelDeleteAllButFirstWorksheet( _
    ByRef oBook As Excel.Workbook)
10    On Error GoTo Err_label

      Dim intNumberOfWorksheets As Integer
      Dim intSheet As Integer

20    intNumberOfWorksheets = oBook.Sheets.count

30    For intSheet = intNumberOfWorksheets To 2 Step -1
40      oBook.Worksheets(intSheet).Delete
50    Next intSheet

          'DD Error Handler Start
Exit_label:
70        Exit Sub
Err_label:
80        Select Case Err.Number
          Case Else
90             Call LogError("basExcel", "ExcelDeleteAllButFirstWorksheet")
100       End Select
110       Resume Exit_label
          ' DD Error Handler End
          
End Sub




'---------------------------------------------------------------------------------------
' SaveExcelWorkbook
'---------------------------------------------------------------------------------------
 
Public Sub SaveAndCloseExcelWorkbook( _
    ByRef oExcel As Excel.Application, _
    ByRef oBook As Excel.Workbook, _
    ByVal strBaseFilename As String, _
    ByVal fValid As Boolean, _
    Optional ByRef strSaveFilepath As String, _
    Optional ByVal fSeconds As Boolean = False)


10    On Error GoTo Err_label

      Dim strFolder As String
      Dim strSaveFilename As String

20    If fValid Then
          
30        strFolder = GetExportFolder()
          
40        If fSeconds Then
50            strSaveFilename = strBaseFilename & _
                  " generated " & _
                   Format(Now, "yyyy-mm-dd hh\hnn\mss") & _
                  ".xlsx"
60        Else
70            strSaveFilename = strBaseFilename & _
              " generated " & _
               Format(Now, "yyyy-mm-dd hh\hnn") & _
              ".xlsx"
80        End If
          
90        strSaveFilepath = FileSaveDialogExcel(strSaveFilename, strFolder, "")
          
100       If strSaveFilepath <> "" Then
110           strFolder = FolderFromPath(strSaveFilepath)
120           oBook.Close saveChanges:=True, FileName:=strSaveFilepath
            
130           Call PutExportFolder(strFolder)
          
140       Else
150           oBook.Close saveChanges:=False
160       End If
170   End If

      'DD Error Handler Start
Exit_label:

180       Exit Sub
Err_label:
190        Select Case Err.Number
           Case Else
200       Call LogError("basExcelExport", "SaveAndCloseExcelWorkbook")
210        End Select
220        Resume Exit_label
      'DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' SaveExcelWorkbookEx
'---------------------------------------------------------------------------------------
' Dim strBaseFilename as string
' Dim strSaveFilepath As String
' Dim fUserCancelled As Boolean
' Call SaveAndCloseExcelWorkbookEx(oExcel, oBook, strBaseFilename, strSaveFilepath, fUserCancelled)
 
Public Sub SaveAndCloseExcelWorkbookEx( _
    ByRef oExcel As Excel.Application, _
    ByRef oBook As Excel.Workbook, _
    ByVal strBaseFilename As String, _
    ByRef strSaveFilepath As String, _
    ByRef fUserCancelled As Boolean)

10    On Error GoTo Err_label

      Dim strFolder As String
      Dim strSaveFilename As String
      
20    fUserCancelled = False
          
30    strFolder = GetExportFolder()

40    strSaveFilename = strBaseFilename & _
          " generated " & _
           Format(Now, "yyyy-mm-dd hh\hnn\mss") & _
          ".xlsx"

50    strSaveFilepath = FileSaveDialogExcel(strSaveFilename, strFolder, "")

60    If strSaveFilepath <> "" Then
70        strFolder = FolderFromPath(strSaveFilepath)
80        oBook.Close saveChanges:=True, FileName:=strSaveFilepath
        
90        Call PutExportFolder(strFolder)


100   Else
110       oBook.Close saveChanges:=False
120       fUserCancelled = True
130   End If


      'DD Error Handler Start
Exit_label:

140       Exit Sub
Err_label:
150        Select Case Err.Number
           Case Else
160       Call LogError("basExcelExport", "SaveAndCloseExcelWorkbookEx")
170        End Select
180        Resume Exit_label
      'DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' SaveExcelWorkbookToReplicationFolder
'
' We do not prompt the user
'---------------------------------------------------------------------------------------
 
Public Sub SaveExcelWorkbookToReplicationFolder( _
    ByRef oExcel As Excel.Application, _
    ByRef oBook As Excel.Workbook, _
    ByVal strBaseFilename As String)

10    On Error GoTo Err_label

      Dim strFolder As String
      Dim strSaveFilename As String
      Dim strSaveFilepath As String
      Dim strDataEntryReplicationFolder As String
          
20    strSaveFilename = strBaseFilename & _
          " generated " & _
           Format(Now, "yyyy-mm-dd hh\hnn\mss ") & _
          ".xlsx"
          
      ' Get the replication folder

30    strDataEntryReplicationFolder = GetMBODataEntryReplicationFolder()
        
40    If strDataEntryReplicationFolder = "" Then
50        oBook.Close saveChanges:=False
60        Exit Sub
70    End If

80    If Not FolderExists(strDataEntryReplicationFolder) Then
90        oBook.Close saveChanges:=False
100       Exit Sub
110   End If

120   strSaveFilepath = strDataEntryReplicationFolder & "\" & strSaveFilename

130   If strSaveFilepath <> "" Then

140       If FileExists(strSaveFilepath, False) Then
150           On Error Resume Next
160           Kill strSaveFilepath
170           On Error GoTo Err_label
180       End If

190       oBook.Close saveChanges:=True, FileName:=strSaveFilepath
200   Else
210       oBook.Close saveChanges:=False
220   End If

      'DD Error Handler Start
Exit_label:

230       Exit Sub
Err_label:
240        Select Case Err.Number
           Case Else
250       Call LogError("basExcelExport", "SaveExcelWorkbookToReplicationFolder")
260        End Select
270        Resume Exit_label
      'DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' OpenExcelWorkbook
'---------------------------------------------------------------------------------------
' PRE strFilepath is a path to an Excel workbook
'
' Call openExcelWorkbook(strFilepath)
' Call openExcelWorkbook(strFilepath, fPrompt)
'
' In fact, if strFilepath is "" or is a path to a file that does not exist, this code does nothing.
' And if strFilepath is a path to a data file (.docx, .txt, ...) it will open that file in its app.
 
Public Sub OpenExcelWorkbook( _
    ByVal strFilepath As String, _
    Optional ByVal fPrompt As Boolean = True)

10    On Error GoTo Err_label

      Dim intResponse As Integer
      Dim fOpen As Boolean

20    If strFilepath = "" Then GoTo Exit_label

30    fOpen = True

40    If fPrompt Then
50        intResponse = MsgBox("Export completed" & vbCrLf & vbCrLf & _
                  strFilepath & vbCrLf & vbCrLf & _
                  "Do you wish to open the Excel file?", _
                  vbYesNo, "Excel Export")
60        fOpen = (intResponse = vbYes)
70    End If

80    If Not fOpen Then GoTo Exit_label

      ' Open Excel file

      Dim strShellCommand As String
90    strShellCommand = "cmd /c " & """" & strFilepath & """"

      'Call Shell(strShellCommand)   --- does not wait

      Dim objShell As WshShell
100   Set objShell = New WshShell
      Dim result As Integer
110   result = objShell.Run(strShellCommand, 0, True)

      'DD Error Handler Start
Exit_label:


120        Exit Sub
Err_label:
130        Select Case Err.Number
           Case Else
140       Call LogError("basExcelExport", "OpenExcelWorkbook")
150        End Select
160        Resume Exit_label
      'DD Error Handler End
          
End Sub

Public Sub OpenExcelWorkbook_Test()
Dim strFilepath As String
Dim fPrompt As Boolean

On Error GoTo Err_label
strFilepath = "R:\MBO Data Entry\2012-10-22 16h13 Exported bands from Bandit.xls"
fPrompt = True
Call OpenExcelWorkbook(strFilepath, fPrompt)
strFilepath = "D:\Desktop\NOEL AUS.docx"
fPrompt = False
Call OpenExcelWorkbook(strFilepath, fPrompt)

    'DD Error Handler Start
Exit_label:
    Exit Sub
Err_label:
    Select Case Err.Number
    Case Else
         Call LogError("basExcelExport", "OpenExcelWorkbook_Test")
    End Select
    Resume Exit_label
    ' DD Error Handler End

End Sub



'---------------------------------------------------------------------------------------
' ExcelInstances
'---------------------------------------------------------------------------------------
 
Public Function ExcelInstances() As Long
          Dim hWndDesk As Variant  ' Long on 32-bit; LongPtr on 64-bit
          Dim hWndXL As Variant    ' Long on 32-bit; LongPtr on 64-bit

          'Get a handle to the desktop
10    On Error GoTo Err_label

20        hWndDesk = GetDesktopWindow

30        Do
              'Get the next Excel window
40            hWndXL = FindWindowEx(GetDesktopWindow, hWndXL, _
                "XLMAIN", vbNullString)

              'If we got one, increment the count
50            If hWndXL > 0 Then
60                ExcelInstances = ExcelInstances + 1
70            End If

              'Loop until we've found them all
80        Loop Until hWndXL = 0

      'DD Error Handler Start
Exit_label:
90         Exit Function
Err_label:
100        Select Case Err.Number
           Case Else
110             Call LogError("Form_frmMaintenance", "ExcelInstances")
120        End Select
130        Resume Exit_label
      'DD Error Handler End
End Function
