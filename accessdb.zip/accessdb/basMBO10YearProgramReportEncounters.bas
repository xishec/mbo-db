'---------------------------------------------------------------------------------------
' Module: basMBO10YearProgramReportEncounters
' Author: David Davey
'---------------------------------------------------------------------------------------

Option Compare Database
Option Explicit

'---------------------------------------------------------------------------------------
' MBO10YearProgramReportEncounters
'---------------------------------------------------------------------------------------

Public Sub MBO10YearProgramReportEncounters( _
    ByVal intYearFirst As Integer, _
    ByVal intYearLast As Integer, _
    ByRef wd As Word.Application, _
    ByRef doc As Word.Document, _
    ByRef oExcel As Excel.Application, _
    ByRef oBook As Excel.Workbook, _
    ByVal fDebug As Boolean)

10    On Error GoTo Err_label

20    Call MBO10YearEncounters( _
        intYearFirst, intYearLast, _
        wd, doc, fBandedAtMBO:=True)
  
40    Call MBO10YearEncounters( _
        intYearFirst, intYearLast, _
        wd, doc, fBandedAtMBO:=False)

    'DD Error Handler Start
Exit_label:
50        Exit Sub
Err_label:
60        Select Case Err.Number
    Case Else
70       Call LogError("basMBO10YearProgramReportEncounters", "MBO10YearProgramReportEncounters")
80        End Select
90        Resume Exit_label
    ' DD Error Handler End
    
End Sub

'---------------------------------------------------------------------------------------
' ForeignBandingForeignEncounter
'---------------------------------------------------------------------------------------

Private Sub MBO10YearEncounters( _
    ByVal intYearFirst As Integer, _
    ByVal intYearLast As Integer, _
    ByRef wd As Word.Application, _
    ByRef doc As Word.Document, _
    ByVal fBandedAtMBO As Boolean)

10    On Error GoTo Err_label

      Dim qdf As QueryDef
            
      Dim range1 As Word.range











20    Set range1 = MoveInsertionPointToEndOfDocument(wd, doc)

30    If fBandedAtMBO Then
40        Call WordGenerateTable_Encounters_BandedMBO(doc, range1)


          ' tblMBO10YearEncounters_BandedMBO_Temp
          ' -------------------------------------
          ' Species
          ' Band_number
          ' Date_banded
          ' AgeEx
          ' SexEx
          ' Date_recovered
          ' Location_name
          ' Distance_and_Direction
          ' Time_elapsed
          ' Disposition
          ' Yearex
          ' AOUOrder
          ' CaptureDate
          
          ' qryMBO10YearEncounters_BandedMBO_Append
          ' ---------------------------------------
          ' tblEncounters x tblCaptures x tblSpecies
          '  APPEND TO tblMBO10YearEncounters_BandedMBO_Temp
          '
          ' Species: IIf(Nz([SpeciesEnglish])="",[SpeciesDescriptionMBO],[SpeciesEnglish])
          ' Band_number: [B_BAND_PREFIX] & "-" & [B_BAND_SUFFIX]
          ' Date_banded: CaptureDate
          ' AgeEx: AgeToString([Age])
          ' SexEx: SexToString([Sex])
          ' Date_recovered: DateSerial([ENCOUNTER_YEAR],[ENCOUNTER_MONTH],[ENCOUNTER_DAY])
          ' Location_name: E_PLACE_NAME
          ' Distance_and_Direction: CInt(nz([DISTANCE])) & " km " & Nz([BEARING])
          ' Time_elapsed: getTimeElapsedAsString([Date_recovered],[CaptureDate])
          ' Disposition
          ' YearEx
          ' AOUOrder
          ' CaptureDate
          ' ORDER BY AOUOrder, CaptureDate
          ' WHERE Disposition IN ('1','5')
          
          ' qryMBO10YearEncounters_BandedMBO
          ' --------------------------------
          ' tblMBO10YearEncounters_BandedMBO_Temp
          '
          ' SELECT tblMBO10YearEncounters_BandedMBO_Temp.Species, tblMBO10YearEncounters_BandedMBO_Temp.Band_number, tblMBO10YearEncounters_BandedMBO_Temp.Date_banded,
          '        tblMBO10YearEncounters_BandedMBO_Temp.AgeEx, tblMBO10YearEncounters_BandedMBO_Temp.SexEx, tblMBO10YearEncounters_BandedMBO_Temp.Date_recovered,
          '        tblMBO10YearEncounters_BandedMBO_Temp.Location_name, tblMBO10YearEncounters_BandedMBO_Temp.Distance_and_Direction,
          '        tblMBO10YearEncounters_BandedMBO_Temp.Time_elapsed, tblMBO10YearEncounters_BandedMBO_Temp.Disposition, tblMBO10YearEncounters_BandedMBO_Temp.YearEx,
          '        tblMBO10YearEncounters_BandedMBO_Temp.AOUOrder, tblMBO10YearEncounters_BandedMBO_Temp.CaptureDate
          ' From tblMBO10YearEncounters_BandedMBO_Temp
          ' ORDER BY tblMBO10YearEncounters_BandedMBO_Temp.AOUOrder, tblMBO10YearEncounters_BandedMBO_Temp.CaptureDate;
          ' Date_recovered BETWEEN [argDateFirst] AND [argDateLast]

50        CurrentDb.Execute "DELETE * FROM tblMBO10YearEncounters_BandedMBO_Temp"
60        Set qdf = CurrentDb.QueryDefs("qryMBO10YearEncounters_BandedMBO_Append")
70        qdf.Execute
80        Set qdf = CurrentDb.QueryDefs("qryMBO10YearEncounters_BandedMBO")
90        qdf.Parameters("argDateFirst") = DateSerial(2004, 10, 31)
100       qdf.Parameters("argDateLast") = ReportYear_EndDate(intYearLast)
110   Else

          Dim range2 As Word.range
120       Set range2 = MoveInsertionPointToEndOfDocument(wd, doc)
         ' range2.InsertAfter ""
130       range2.InsertParagraphAfter
140       range2.Style = "ddBody"

150       Set range1 = MoveInsertionPointToEndOfDocument(wd, doc)

160       Call WordGenerateTable_Encounters_EncounteredMBO(doc, range1)
170       Set qdf = CurrentDb.QueryDefs("qryMBO10YearEncounters_EncounteredMBO")
180       qdf.Parameters("argYearFirst") = intYearFirst
190       qdf.Parameters("argYearLast") = intYearLast
200   End If


      ' qryMBO10YearEncounters_BandedMBO
      ' ------------------------------------
      ' tblEncounters x tblCaptures x tblSpecies x tblPrograms
      '
      ' WHERE BANDED_BY_MBO = True
      ' WHERE LOCATION = "MBO"
      '
      ' Species: IIf(Nz([SpeciesEnglish])="",[SpeciesDescriptionMBO],[SpeciesEnglish])
      ' Band_number: [B_BAND_PREFIX] & "-" & [B_BAND_SUFFIX]
      ' Date_banded = CaptureDate
      ' AgeEx:  AgeToString ([Age])
      ' SexEx: SexToString([Sex])
      ' Date_recovered: DateSerial([ENCOUNTER_YEAR],[ENCOUNTER_MONTH],[ENCOUNTER_DAY])
      ' Location_name = E_PLACE_NAME
      ' Distance_and_Distance: CInt(nz([DISTANCE])) & " km " & Nz([BEARING])
      ' BEARING
      ' Time_elapsed: getTimeElapsedAsString([Date_recovered],[CaptureDate])
      ' ORDER BY AOUOrder, CaptureDate




      Dim rst As DAO.Recordset
210   Set rst = qdf.OpenRecordset

      Dim strSpecies As String
      Dim strBandNumber As String
      Dim datDate_banded As Date
      Dim strAgeEx As String
      Dim strSexEx As String
      Dim datDate_recovered As Date
      Dim strLocation_name As String
      Dim strDistance_and_Direction As String
      Dim strTime_elapsed As String


      Dim colSpecies As Integer
      Dim colBandNumber As Integer
      Dim colDate_banded As Integer
      Dim colAgeEx As Integer
      Dim colSexEx As Integer
      Dim colDate_recovered As Integer
      Dim colLocation_name As Integer
      Dim colDistance_and_Direction As Integer
      Dim colTime_elapsed As Integer

220   If fBandedAtMBO Then
230       colSpecies = 1
240       colBandNumber = 2
250       colDate_banded = 3
260       colAgeEx = 4
270       colSexEx = 5
280       colDate_recovered = 6
290       colLocation_name = 7
300       colDistance_and_Direction = 8
310       colTime_elapsed = 9
320   Else
330       colSpecies = 1
340       colBandNumber = 2
350       colDate_banded = 3
360       colLocation_name = 4
370       colAgeEx = 5
380       colSexEx = 6
390       colDate_recovered = 7
400       colDistance_and_Direction = 8
410       colTime_elapsed = 9
420   End If

      Dim row As Integer
430   row = 2

440   Do While Not rst.EOF

450       strSpecies = Nz(rst("Species"))
460       strBandNumber = Nz(rst("Band_number"))
470       datDate_banded = Nz(rst("Date_banded"))
480       strAgeEx = Nz(rst("AgeEx"))
490       strSexEx = Nz(rst("SexEx"))
500       datDate_recovered = Nz(rst("Date_recovered"))
510       strLocation_name = Nz(rst("Location_name"))
520       strDistance_and_Direction = Nz(rst("Distance_and_Direction"))
530       strTime_elapsed = Nz(rst("Time_elapsed"))
          
540       If row <> 2 Then
550           range1.Tables(1).Rows.Add
560       End If

570       range1.Tables(1).Cell(row, colSpecies).range.Text = strSpecies
580       range1.Tables(1).Cell(row, colBandNumber).range.Text = strBandNumber
590       range1.Tables(1).Cell(row, colDate_banded).range.Text = ConvertDateToEnglishString(datDate_banded, 6)
600       range1.Tables(1).Cell(row, colAgeEx).range.Text = strAgeEx
610       range1.Tables(1).Cell(row, colSexEx).range.Text = strSexEx
620       range1.Tables(1).Cell(row, colDate_recovered).range.Text = ConvertDateToEnglishString(datDate_recovered, 6)
630       range1.Tables(1).Cell(row, colLocation_name).range.Text = strLocation_name
640       range1.Tables(1).Cell(row, colDistance_and_Direction).range.Text = strDistance_and_Direction
650       range1.Tables(1).Cell(row, colTime_elapsed).range.Text = strTime_elapsed

660       row = row + 1

Next_record_label:
670       rst.MoveNext
680   Loop
690   rst.Close
700   Set rst = Nothing

          'DD Error Handler Start
Exit_label:
710       Exit Sub
Err_label:
720       Select Case Err.Number
          Case Else
730      Call LogError("basMBO10YearProgramReportEncounters", "MBO10YearEncounters_BandedMBO")
740       End Select
750       Resume Exit_label
          ' DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' WordGenerateTable_Encounters_BandedMBO
'---------------------------------------------------------------------------------------
' entry:  range = a collapsed range that is the insertion point for the table
' exit:   range = range that includes the table

Private Sub WordGenerateTable_Encounters_BandedMBO( _
    ByRef doc As Word.Document, _
    ByRef range1 As Word.range)

      Dim row As Integer
      Dim col As Integer

10    On Error GoTo Err_label

20    doc.Tables.Add range:=range1, NumRows:=2, NumColumns:=9
          
30    range1.Expand (wdTable)

50    With range1.Tables(1)

60        .range.Style = "ddMultiYearEncountersData"

70        .Rows.Alignment = wdAlignRowCenter
80        .Rows.WrapAroundText = False

90        .LeftPadding = doc.Application.InchesToPoints(0.02)
100       .RightPadding = doc.Application.InchesToPoints(0.02)
110       .TopPadding = doc.Application.InchesToPoints(0.02)
              
120       .columns(1).Width = doc.Application.CentimetersToPoints(3.4)
130       .columns(2).Width = doc.Application.CentimetersToPoints(1.99)
140       .columns(3).Width = doc.Application.CentimetersToPoints(1.5)
150       .columns(4).Width = doc.Application.CentimetersToPoints(0.64)
160       .columns(5).Width = doc.Application.CentimetersToPoints(0.56)
170       .columns(6).Width = doc.Application.CentimetersToPoints(1.62)
180       .columns(7).Width = doc.Application.CentimetersToPoints(4.35)
190       .columns(8).Width = doc.Application.CentimetersToPoints(1.75)
200       .columns(9).Width = doc.Application.CentimetersToPoints(3.35)
          
210       .Cell(1, 1).range.Text = "Species"
220       .Cell(1, 2).range.Text = "Band number"
230       .Cell(1, 3).range.Text = "Date banded"
240       .Cell(1, 4).range.Text = "Age"
250       .Cell(1, 5).range.Text = "Sex"
260       .Cell(1, 6).range.Text = "Date recovered"
270       .Cell(1, 7).range.Text = "Location recovered"
280       .Cell(1, 8).range.Text = "Distance & Direction"
290       .Cell(1, 9).range.Text = "Time elapsed"
          
          ' Format Header Row
          
300       Call FormatWordTableRowAsHeader(.Rows(1), "ddMultiYearEncountersHeaderRow")
          
          ' Center vertically row 1
          
310       .Rows(1).Cells.VerticalAlignment = wdCellAlignVerticalCenter
          
      ' Repeat heading row at the top of subsequent pages

320   .Rows(1).HeadingFormat = True
330   .Rows.WrapAroundText = False

340   End With

    'DD Error Handler Start
Exit_label:
350       Exit Sub
Err_label:
360       Select Case Err.Number
    Case Else
370      Call LogError("basMBO10YearProgramReportEncounters", "WordGenerateTable_Encounters_BandedMBO")
380       End Select
390       Resume Exit_label
    ' DD Error Handler End

End Sub


Private Sub WordGenerateTable_Encounters_EncounteredMBO( _
    ByRef doc As Word.Document, _
    ByRef range2 As Word.range)

      Dim row As Integer
      Dim col As Integer

10       On Error GoTo Err_label

20    On Error GoTo Err_label

30    doc.Tables.Add range:=range2, NumRows:=2, NumColumns:=9
          
40    range2.Expand (wdTable)

60    With range2.Tables(1)

70        .range.Style = "ddMultiYearEncountersData"

80        .Rows.Alignment = wdAlignRowCenter
90        .Rows.WrapAroundText = False

100       .LeftPadding = doc.Application.InchesToPoints(0.02)
110       .RightPadding = doc.Application.InchesToPoints(0.02)
120       .TopPadding = doc.Application.InchesToPoints(0.02)
              
130       .columns(1).Width = doc.Application.CentimetersToPoints(3.4)
140       .columns(2).Width = doc.Application.CentimetersToPoints(1.99)
150       .columns(3).Width = doc.Application.CentimetersToPoints(1.5)
160       .columns(4).Width = doc.Application.CentimetersToPoints(4.35)
170       .columns(5).Width = doc.Application.CentimetersToPoints(0.64)
180       .columns(6).Width = doc.Application.CentimetersToPoints(0.56)
190       .columns(7).Width = doc.Application.CentimetersToPoints(1.62)
200       .columns(8).Width = doc.Application.CentimetersToPoints(1.75)
210       .columns(9).Width = doc.Application.CentimetersToPoints(3.35)
          
220       .Cell(1, 1).range.Text = "Species"
230       .Cell(1, 2).range.Text = "Band number"
240       .Cell(1, 3).range.Text = "Date banded"
250       .Cell(1, 4).range.Text = "Location banded"
260       .Cell(1, 5).range.Text = "Age"
270       .Cell(1, 6).range.Text = "Sex"
280       .Cell(1, 7).range.Text = "Date recovered"
290       .Cell(1, 8).range.Text = "Distance & Direction"
300       .Cell(1, 9).range.Text = "Time elapsed"
          
          ' Format Header Row
          
310       Call FormatWordTableRowAsHeader(.Rows(1), "ddMultiYearEncountersHeaderRow")
          
          ' Center vertically row 1
          
320       .Rows(1).Cells.VerticalAlignment = wdCellAlignVerticalCenter
          
      ' Repeat heading row at the top of subsequent pages

330   .Rows(1).HeadingFormat = True
340   .Rows.WrapAroundText = False

350   End With

    'DD Error Handler Start
Exit_label:
360       Exit Sub
Err_label:
370       Select Case Err.Number
    Case Else
380      Call LogError("basMBO10YearProgramReportEncounters", "WordGenerateTable_Encounters_EncounteredMBO")
390       End Select
400       Resume Exit_label
    ' DD Error Handler End

End Sub


'---------------------------------------------------------------------------------------
' getTimeElapsedAsString
'
' Return a string representing the number of yeasr, months and daysbetween two dates
'---------------------------------------------------------------------------------------

Public Function getTimeElapsedAsString(ByVal datLater As Date, ByVal datEarlier As Date) As String

   On Error GoTo Err_label


    Dim intYears As Integer
    Dim intMonths As Integer
    Dim intDays As Integer
    
    Call getTimeElapsed(datLater, datEarlier, intYears, intMonths, intDays)
    
    Dim str As String
    
    str = ""
    
    If intYears = 0 Then
    ElseIf intYears = 1 Then
        str = "1 year"
    Else
        str = intYears & " years"
    End If
    
    If intMonths = 0 Then
    ElseIf intMonths = 1 Then
        If str = "" Then
            str = "1 month"
        Else
            str = str & ", 1 month"
        End If
    Else
        If str = "" Then
            str = intMonths & " months"
        Else
            str = str & ", " & intMonths & " months"
        End If
        
    End If
    
    If intDays = 0 Then
    ElseIf intDays = 1 Then
        If str = "" Then
            str = "1 day"
        Else
            str = str & ", 1 day"
        End If
    Else
        If str = "" Then
            str = intDays & " days"
        Else
            str = str & ", " & intDays & " days"
        End If
    End If

    getTimeElapsedAsString = str
 

    'DD Error Handler Start
Exit_label:
    Exit Function
Err_label:
    Select Case Err.Number
    Case Else
         Call LogError("basMBO10YearProgramReportEncounters", "getTimeElapsedAsString")
    End Select
    Resume Exit_label
    ' DD Error Handler End
End Function
