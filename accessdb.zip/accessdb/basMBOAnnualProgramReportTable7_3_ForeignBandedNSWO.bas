'---------------------------------------------------------------------------------------
' Module    : basMBOAnnualProgramReportTable7_3_ForeignBandedNSWO
' Author    : David Davey
'---------------------------------------------------------------------------------------


Option Compare Database
Option Explicit

'Private intYear As Integer
'Private strLocation As String
'Private strProgram As String
'Private strSeason As String


'---------------------------------------------------------------------------------------
' MBOAnnualProgramReport7-4
'---------------------------------------------------------------------------------------
 
Public Sub MBOAnnualProgramReport7_4( _
    ByVal intYearEx As Integer, _
    ByRef wd As Word.Application, _
    ByRef doc As Word.Document, _
    ByRef oExcel As Excel.Application, _
    ByRef oBook As Excel.Workbook, _
    ByVal strTableCaptionHeading As String)
    
10    On Error GoTo Err_label

Dim range As Word.range

' =============== to Word ==============================================================================

20    Set range = MoveInsertionPointToEndOfDocument(wd, doc)
30    range.InsertParagraphAfter

Dim strCaption As String
Dim strTC As String
40    strCaption = "MBO-banded Northern Saw-whet Owls captured elsewhere during " & intYearEx & ", sorted by time elapsed."
50    strTC = "MBO-banded Northern Saw-whet Owls captured elsewhere during " & intYearEx

60    Call InsertTableCaptionXX(wd, doc, "Table", "7.4", strCaption, strTC)
  
70    Set range = MoveInsertionPointToEndOfDocument(wd, doc)
80    range.InsertParagraphAfter

90    Call ForeignBandingForeignEncounter( _
        intYearEx, _
        wd, doc, range, _
        strTableCaptionHeading)

' ================ to Excel ==================================================================

Dim strSQL As String

' qryMBOAnnualProgram_Encounter_MBOBanded
' -----------------------------------------------------
' tblEncounters x tblCaptures (Band Prefix, Band Suffix)
' x tblPrograms
'
' WHERE Location = MBO
' WHERE BANDED_BY_MBO = True
' WHERE Disposition = "1" or "5"
' WHERE YearEx = argYearEx

' BandPrefix
' BandSuffix
' Season = MonitoringProgramSeason
' Species
' AgeBanding = Age
' SexBanding = Sex
' BandingDate = Capturedate
' EncounterDate = ENCOUNTER_DATE
' Days = EncounterDate - BandingDate      SORT DESC
' E_LOCATION
' E_LOCATION_DESCRIPTION
' DistanceMiles = DISTANCE


Dim qdf As QueryDef
100   Set qdf = CurrentDb.QueryDefs("qryMBOAnnualProgram_Encounter_MBOBanded")
110   qdf.Parameters("argYearEx") = intYearEx

Dim rst As DAO.Recordset
120   Set rst = qdf.OpenRecordset

Dim strSpecies As String
Dim strBandPrefix As String
Dim strBandSuffix As String
Dim strAgeBanding As String
Dim strSexBanding As String
Dim strAgeSexBanding As String
Dim datBandingDate As Date
Dim datEncounterDate As Date
Dim intDays As Integer
Dim strEncounterLocation As String
Dim strEncounterLocationDescription As String
Dim dblDistanceMiles As Double
Dim dblDistanceKm As Double

Dim strSeason As String
Dim colYearEx As Integer
Dim colSeason As Integer
Dim colSpecies As Integer
Dim colBand As Integer
Dim colAgeBanding As Integer
Dim colSexBanding As Integer
Dim colAgeSexBanding As Integer
Dim colBandingDate As Integer
Dim colEncounterDate As Integer
Dim colDays As Integer
Dim colEncounterLocation As Integer
Dim colEncounterLocationDescription As Integer
Dim colDistanceMiles As Integer
Dim colDistanceKm As Integer
Dim colEnd As Integer

Dim col As Integer

130   col = 1
140   colYearEx = col
150   col = col + 1
160   colSeason = col
170   col = col + 1
180   colSpecies = col
190   col = col + 1
200   colBand = col
210   col = col + 1
220   colAgeBanding = col
230   col = col + 1
240   colSexBanding = col
250   col = col + 1
260   colAgeSexBanding = col
270   col = col + 1
280   colBandingDate = col
290   col = col + 1
300   colEncounterDate = col
310   col = col + 1
320   colDays = col
330   col = col + 1
340   colEncounterLocation = col
350   col = col + 1
360   colEncounterLocationDescription = col
370   col = col + 1
380   colDistanceMiles = col
390   col = col + 1
400   colDistanceKm = col
410   colEnd = col


Dim oSheet As Excel.Worksheet
420   Set oSheet = InsertSheet(oBook, "Owling")
430   oSheet.Name = "Foreign Capture"

440   With oSheet

450   .Cells(1, colYearEx) = "Report Year"
460   .Cells(1, colSeason) = "Season"
470   .Cells(1, colSpecies) = "Species"
480   .Cells(1, colBand) = "Band"
490   .Cells(1, colAgeBanding) = "Age Banding"
500   .Cells(1, colSexBanding) = "Sex Banding"
510   .Cells(1, colAgeSexBanding) = "Age Sex Banding"
520   .Cells(1, colBandingDate) = "Banding Date"
530   .Cells(1, colEncounterDate) = "Encounter Date"
540   .Cells(1, colDays) = "Days"
550   .Cells(1, colEncounterLocation) = "Encounter Location"
560   .Cells(1, colEncounterLocationDescription) = "Encounter Location Description"
570   .Cells(1, colDistanceMiles) = "Distance in miles"
580   .Cells(1, colDistanceKm) = "Distance in km"

Dim row As Integer
Dim rowEnd As Integer
590   row = 2

600   Do While Not rst.EOF

610       strSeason = Nz(rst("Season"))
620       strSpecies = Nz(rst("Species"))
630       strBandPrefix = Nz(rst("BandPrefix"))
640       strBandSuffix = Nz(rst("BandSuffix"))
650       strAgeBanding = Nz(rst("AgeBanding"))
660       strSexBanding = Nz(rst("SexBanding"))
670       strAgeSexBanding = getAgeSex(strAgeBanding, strSexBanding)
680       datBandingDate = Nz(rst("BandingDate"))
690       datEncounterDate = Nz(rst("Encounterdate"))
700       intDays = Nz(rst("Days"))
710       strEncounterLocation = Nz(rst("E_LOCATION"))
720       strEncounterLocationDescription = Nz(rst("E_LOCATION_DESCRIPTION"))
730       dblDistanceMiles = Nz(rst("DistanceMiles"))
740       dblDistanceKm = dblDistanceMiles * 1.60934
    
750       .Cells(row, colYearEx) = intYearEx
760       .Cells(row, colSeason) = strSeason
770       .Cells(row, colSpecies) = strSpecies
780       .Cells(row, colBand) = strBandPrefix & "-" & strBandSuffix
790       .Cells(row, colAgeBanding) = strAgeBanding
800       .Cells(row, colSexBanding) = strSexBanding
810       .Cells(row, colAgeSexBanding) = strAgeSexBanding
820       .Cells(row, colBandingDate) = IIf(datBandingDate = 0, "", datBandingDate)
830       .Cells(row, colEncounterDate) = IIf(datEncounterDate = 0, "", datEncounterDate)
840       .Cells(row, colDays) = intDays
850       .Cells(row, colEncounterLocation) = strEncounterLocation
860       .Cells(row, colEncounterLocationDescription) = strEncounterLocationDescription
870       .Cells(row, colDistanceMiles) = dblDistanceMiles
880       .Cells(row, colDistanceKm) = dblDistanceKm
        
890       row = row + 1
900       rst.MoveNext
910   Loop
920   rst.Close
930   Set rst = Nothing

940   rowEnd = row - 1

950   .range(.columns(colAgeBanding), .columns(colAgeSexBanding)).HorizontalAlignment = xlCenter
960   .range(.columns(colBandingDate), .columns(colEncounterDate)).NumberFormat = "dd-mmm-yyyy"
970   .range(.columns(1), .columns(colEnd)).AutoFit


980   Set oSheet = Nothing

990   SysCmd acSysCmdClearStatus

1000  End With

    'DD Error Handler Start
Exit_label:
1010      Exit Sub
Err_label:
1020      Select Case Err.Number
    Case Else
1030     Call LogError("basMBOAnnualProgramReportTable7_3_ForeignBandedNSWO", "MBOAnnualProgramReport7_4")
1040      End Select
1050      Resume Exit_label
    ' DD Error Handler End

    End Sub

'---------------------------------------------------------------------------------------
' MBOAnnualProgramReportTable7_3
'
' I report ALL foreign banded MBO encountered (first encounter only) to Excel
' I report NSWO (all programs) foreign banded MBO encounstered (first encounter only) to Word
'---------------------------------------------------------------------------------------
' F-1st

Public Sub MBOAnnualProgramReportTable7_3( _
    ByRef fValid As Boolean, _
    ByVal intYearEx As Integer, _
    ByVal strLocation As String, _
    ByVal strProgram As String, _
    ByVal strSeason As String, _
    ByRef wd As Word.Application, _
    ByRef doc As Word.Document, _
    ByRef oExcel As Excel.Application, _
    ByRef oBook As Excel.Workbook, _
    ByVal strTableCaptionHeading As String)
          
10       On Error GoTo Err_label


    



20    SysCmd acSysCmdSetStatus, strSeason & "Foreign banded NSWO"
          
      Dim range As Word.range
          
30    Set range = MoveInsertionPointToEndOfDocument(wd, doc)
40    range.InsertParagraphAfter

      Dim strCaption As String
      Dim strTC As String
50    strCaption = "Foreign-banded Northern Saw-whet Owls captured at MBO during " & intYearEx & ", sorted by time elapsed."
60    strTC = "Foreign-banded Northern Saw-whet Owls captured at MBO during " & intYearEx

70    Call InsertTableCaptionXX(wd, doc, "Table", "7.3", strCaption, strTC)
        
80    Set range = MoveInsertionPointToEndOfDocument(wd, doc)
90    range.InsertParagraphAfter

100   Call ForeignBandingMBOEncounter( _
     intYearEx, _
     strLocation, _
     strProgram, _
     strSeason, _
     wd, doc, range, _
     strTableCaptionHeading)



      ' ================ to Excel ==================================================================

      Dim strSQL As String

      ' Save parameters

110   On Error GoTo Err_label


      ' qryMBOAnnualProgram_Alien
      ' -------------------------
      ' tblCaptures LEFT OUTER JOIN tblEncounters
      ' x tblPrograms
      '
      ' BandPrefix
      ' BandSuffix
      ' WHERE D18 = "Alien"
      ' WHERE argLocation = strLocation
      ' WHERE YearEx = argYearEx
      ' Season = MonitoringProgramSeason
      ' Species
      ' AgeEncounter = Age
      ' SexEncounter = Sex
      ' AgeBanding = B_AGE_CODE
      ' SexBanding = B_SEX_CODE
      ' BandingDate = BANDING_DATE
      ' EncounterDate = CaptureDate
      ' DAYS
      ' BandingLocation: B_LOCATION
      ' BandingLocationDescription: B_LOCATION_DESCRIPTION
      ' DISTANCE


      Dim qdf As QueryDef
210   Set qdf = CurrentDb.QueryDefs("qryMBOAnnualProgramReport_Alien")
220   qdf.Parameters("argLocation") = strLocation
230   qdf.Parameters("argYearEx") = intYearEx

      Dim rst As DAO.Recordset
240   Set rst = qdf.OpenRecordset

'      Dim strSeason As String
      Dim strSpecies As String
      Dim strBandPrefix As String
      Dim strBandSuffix As String
      Dim strAgeEncounter As String
      Dim strSexEncounter As String
      Dim strAgeSexEncounter As String
      Dim strAgeBanding As String
      Dim strSexBanding As String
      Dim strAgeSexBanding As String
      Dim datBandingDate As Date
      Dim datEncounterDate As Date
      Dim intDays As Integer
      Dim strBandingLocation As String
      Dim strBandingLocationDescription As String
      Dim dblDistanceMiles As Double
      Dim dblDistanceKm As Double

      Dim colYearEx As Integer
      Dim colSeason As Integer
      Dim colSpecies As Integer
      Dim colBand As Integer
      Dim colAgeEncounter As Integer
      Dim colSexEncounter As Integer
      Dim colAgeSexEncounter As Integer
      Dim colAgeBanding As Integer
      Dim colSexBanding As Integer
      Dim colAgeSexBanding As Integer
      Dim colBandingDate As Integer
      Dim colEncounterDate As Integer
      Dim colDays As Integer
      Dim colBandingLocation As Integer
      Dim colBandingLocationDescription As Integer
      Dim colDistanceMiles As Integer
      Dim colDistanceKm As Integer
      Dim colEnd As Integer
      
      Dim col As Integer

250   col = 1
260   colYearEx = col
270   col = col + 1
280   colSeason = col
290   col = col + 1
300   colSpecies = col
310   col = col + 1
320   colBand = col
330   col = col + 1
340   colAgeEncounter = col
350   col = col + 1
360   colSexEncounter = col
370   col = col + 1
380   colAgeSexEncounter = col
390   col = col + 1
400   colAgeBanding = col
410   col = col + 1
420   colSexBanding = col
430   col = col + 1
440   colAgeSexBanding = col
450   col = col + 1
460   colBandingDate = col
470   col = col + 1
480   colEncounterDate = col
490   col = col + 1
500   colDays = col
510   col = col + 1
520   colBandingLocation = col
530   col = col + 1
540   colBandingLocationDescription = col
550   col = col + 1
560   colDistanceMiles = col
570   col = col + 1
580   colDistanceKm = col
590   colEnd = col


      Dim oSheet As Excel.Worksheet
600   Set oSheet = InsertSheet(oBook, strSeason)
610   oSheet.Name = "Alien "

620   With oSheet

630   .Cells(1, colYearEx) = "Report Year"
640   .Cells(1, colSeason) = "Season"
650   .Cells(1, colSpecies) = "Species"
660   .Cells(1, colBand) = "Band"
670   .Cells(1, colAgeEncounter) = "Age Encounter"
680   .Cells(1, colSexEncounter) = "Sex Encounter"
690   .Cells(1, colAgeSexEncounter) = "Age Sex Encounter"
700   .Cells(1, colAgeBanding) = "Age Banding"
710   .Cells(1, colSexBanding) = "Sex Banding"
720   .Cells(1, colAgeSexBanding) = "Age Sex Banding"
730   .Cells(1, colBandingDate) = "Banding Date"
740   .Cells(1, colEncounterDate) = "Encounter Date"
750   .Cells(1, colDays) = "Days"
760   .Cells(1, colBandingLocation) = "Banding Location"
770   .Cells(1, colBandingLocationDescription) = "Banding Location Description"
780   .Cells(1, colDistanceMiles) = "Distance in miles"
790   .Cells(1, colDistanceKm) = "Distance in km"

      Dim row As Integer
      Dim rowEnd As Integer
800   row = 2

810   Do While Not rst.EOF

820       strSeason = Nz(rst("Season"))
830       strSpecies = Nz(rst("Species"))
840       strBandPrefix = Nz(rst("BandPrefix"))
850       strBandSuffix = Nz(rst("BandSuffix"))
860       strAgeEncounter = Nz(rst("AgeEncounter"))
870       strSexEncounter = Nz(rst("SexEncounter"))
880       strAgeSexEncounter = getAgeSex(strAgeEncounter, strSexEncounter)
890       strAgeBanding = Nz(rst("AgeBanding"))
900       strSexBanding = Nz(rst("SexBanding"))
910       strAgeSexBanding = getAgeSex(strAgeBanding, strSexBanding)
920       datBandingDate = Nz(rst("BandingDate"))
930       datEncounterDate = Nz(rst("Encounterdate"))
940       intDays = Nz(rst("Days"))
950       strBandingLocation = Nz(rst("BandingLocation"))
960       strBandingLocationDescription = Nz(rst("BandingLocationDescription"))
970       dblDistanceMiles = Nz(rst("Distance"))
980       dblDistanceKm = dblDistanceMiles * 1.60934
          
990       .Cells(row, colYearEx) = intYearEx
1000      .Cells(row, colSeason) = strSeason
1010      .Cells(row, colSpecies) = strSpecies
1020      .Cells(row, colBand) = strBandPrefix & "-" & strBandSuffix
1030      .Cells(row, colAgeEncounter) = strAgeEncounter
1040      .Cells(row, colSexEncounter) = strSexEncounter
1050      .Cells(row, colAgeSexEncounter) = strAgeSexEncounter
1060      .Cells(row, colAgeBanding) = strAgeBanding
1070      .Cells(row, colSexBanding) = strSexBanding
1080      .Cells(row, colAgeSexBanding) = strAgeSexBanding
1090      .Cells(row, colBandingDate) = IIf(datBandingDate = 0, "", datBandingDate)
1100      .Cells(row, colEncounterDate) = IIf(datEncounterDate = 0, "", datEncounterDate)
1110      .Cells(row, colDays) = intDays
1120      .Cells(row, colBandingLocation) = strBandingLocation
1130      .Cells(row, colBandingLocationDescription) = strBandingLocationDescription
1140      .Cells(row, colDistanceMiles) = dblDistanceMiles
1150      .Cells(row, colDistanceKm) = dblDistanceKm
              
1160      row = row + 1
1170      rst.MoveNext
1180  Loop
1190  rst.Close
1200  Set rst = Nothing

1210  rowEnd = row - 1

1220  .range(.columns(colAgeEncounter), .columns(colAgeSexBanding)).HorizontalAlignment = xlCenter
1230  .range(.columns(colBandingDate), .columns(colEncounterDate)).NumberFormat = "dd-mmm-yyyy"
1240  .range(.columns(1), .columns(colEnd)).AutoFit


1250  Set oSheet = Nothing

1260  SysCmd acSysCmdClearStatus

1270  End With

          'DD Error Handler Start
Exit_label:
1280      Exit Sub
Err_label:
1290      Select Case Err.Number
          Case Else
1300           Call LogError("basMBOAnnualProgramReportTable7_3_ForeignBandedNSWO", "MBOAnnualProgramReportTable7_3")
1310      End Select
1320      Resume Exit_label
          ' DD Error Handler End

End Sub


'---------------------------------------------------------------------------------------
' ForeignBandingMBOEncounter
'---------------------------------------------------------------------------------------

Private Sub ForeignBandingMBOEncounter( _
    ByVal intYearEx As Integer, _
    ByVal strLocation As String, _
    ByVal strProgram As String, _
    ByVal strSeason As String, _
    ByRef wd As Word.Application, _
    ByRef doc As Word.Document, _
    ByRef range As Word.range, _
    ByVal strTableCaptionHeading As String)

10    On Error GoTo Err_label

20    Call WordGenerateTableAlien(doc, range, intYearEx)




      ' qryMBOAnnualProgram_Alien
      ' -------------------------
      ' tblCaptures LEFT OUTER JOIN tblEncounters
      ' x tblPrograms
      '
      ' BandPrefix
      ' BandSuffix
      ' WHERE D18 = "Alien"
      ' WHERE argLocation = strLocation
      ' WHERE YearEx = argYearEx
      ' Season = MonitoringProgramSeason
      ' Species
      ' AgeEncounter = Age
      ' SexEncounter = Sex
      ' AgeBanding = B_AGE_CODE
      ' SexBanding = B_SEX_CODE
      ' BandingDate = BANDING_DATE
      ' EncounterDate = CaptureDate
      ' DAYS
      ' BandingLocation: B_LOCATION
      ' BandingLocationDescription: B_LOCATION_DESCRIPTION
      ' DISTANCE


      Dim qdf As QueryDef
70    Set qdf = CurrentDb.QueryDefs("qryMBOAnnualProgramReport_Alien")
80    qdf.Parameters("argLocation") = strLocation
90    qdf.Parameters("argYearEx") = intYearEx

      Dim rst As DAO.Recordset
100   Set rst = qdf.OpenRecordset

      ' Dim strSeason As String
      Dim strSpecies As String
      Dim strBandPrefix As String
      Dim strBandSuffix As String
      Dim strAgeEncounter As String
      Dim strSexEncounter As String
      Dim strAgeSexEncounter As String
      Dim strAgeBanding As String
      Dim strSexBanding As String
      Dim strAgeSexBanding As String
      Dim datBandingDate As Date
      Dim datEncounterDate As Date
      Dim intDays As Integer
      Dim strBandingLocation As String
      Dim strBandingLocationDescription As String
      Dim dblDistanceMiles As Double
      Dim intDistanceKm As Integer


      Dim colBand As Integer
      Dim colAgeSexEncounter As Integer
      Dim colAgeSexBanding As Integer
      Dim colBandingDate As Integer
      Dim colEncounterDate As Integer
      Dim colDays As Integer
      Dim colBandingLocationDescription As Integer
      Dim colDistanceKm As Integer


      Dim col As Integer

110   col = 1
120   colBand = col
130   col = col + 1
140   colAgeSexEncounter = col
150   col = col + 1
160   colAgeSexBanding = col
170   col = col + 1
180   colBandingDate = col
190   col = col + 1
200   colEncounterDate = col
210   col = col + 1
220   colDays = col
230   col = col + 1
240   colBandingLocationDescription = col
250   col = col + 1
260   colDistanceKm = col

      Dim row As Integer
270   row = 2

280   Do While Not rst.EOF

290       strSeason = Nz(rst("Season"))               '  Actually, I ignore the season
300       strSpecies = Nz(rst("Species"))
          
320       If strSpecies <> "NSWO" Then GoTo Next_record_label
          
330       strBandPrefix = Nz(rst("BandPrefix"))
340       strBandSuffix = Nz(rst("BandSuffix"))
350       strAgeEncounter = Nz(rst("AgeEncounter"))
360       strSexEncounter = Nz(rst("SexEncounter"))
370       strAgeSexEncounter = getAgeSex(strAgeEncounter, strSexEncounter)
380       strAgeBanding = Nz(rst("AgeBanding"))
390       strSexBanding = Nz(rst("SexBanding"))
400       strAgeSexBanding = getAgeSex(strAgeBanding, strSexBanding)
410       datBandingDate = Nz(rst("BandingDate"))
420       datEncounterDate = Nz(rst("Encounterdate"))
430       intDays = Nz(rst("Days"))
          
          Dim intYearsElapsed As Integer
          Dim intMonthsElapsed As Integer
          Dim intDaysElapsed As Integer
          
440       If datBandingDate = 0 Then
450           Call getTimeElapsed(datEncounterDate, datEncounterDate - intDays, intYearsElapsed, intMonthsElapsed, intDaysElapsed)
460       Else
470           Call getTimeElapsed(datEncounterDate, datBandingDate, intYearsElapsed, intMonthsElapsed, intDaysElapsed)
480       End If

          Dim strTimeElapsed As String
          
490       strTimeElapsed = ""
500       If intYearsElapsed > 0 Then
510           If intYearsElapsed = 1 Then
520               strTimeElapsed = "1 year"
530           Else
540               strTimeElapsed = CStr(intYearsElapsed) & " years"
550           End If
560       End If
570       If intMonthsElapsed > 0 Then
580           If strTimeElapsed <> "" Then
590               strTimeElapsed = strTimeElapsed & ", "
600           End If
610           If intMonthsElapsed = 1 Then
620               strTimeElapsed = strTimeElapsed & "1 month"
630           Else
640               strTimeElapsed = strTimeElapsed & CStr(intMonthsElapsed) & " months"
650           End If
660       End If
670       If intDaysElapsed > 0 Then
680           If strTimeElapsed <> "" Then
690               strTimeElapsed = strTimeElapsed & ", "
700           End If
710           If intDaysElapsed = 1 Then
720               strTimeElapsed = strTimeElapsed & "1 day"
730           Else
740               strTimeElapsed = strTimeElapsed & CStr(intDaysElapsed) & " days"
750           End If
760       End If
          
          
770       strBandingLocation = Nz(rst("BandingLocation"))
780       strBandingLocationDescription = Nz(rst("BandingLocationDescription"))
790       dblDistanceMiles = Nz(rst("Distance"))
800       intDistanceKm = Round(dblDistanceMiles * 1.60934, 0)
          
810       If row <> 2 Then
820           range.Tables(1).Rows.Add
830       End If
          
840       range.Tables(1).Cell(row, colBand).range.Text = strBandPrefix & "-" & strBandSuffix
850       range.Tables(1).Cell(row, colAgeSexEncounter).range.Text = strAgeSexEncounter
860       range.Tables(1).Cell(row, colAgeSexBanding).range.Text = strAgeSexBanding
870       range.Tables(1).Cell(row, colBandingDate).range.Text = ConvertDateToEnglishString(datBandingDate, 2)
880       range.Tables(1).Cell(row, colEncounterDate).range.Text = ConvertDateToEnglishString(datEncounterDate, 1)
890       range.Tables(1).Cell(row, colDays).range.Text = strTimeElapsed
900       If strBandingLocation <> "" Then
910           range.Tables(1).Cell(row, colBandingLocationDescription).range.Text = strBandingLocation
920       Else
930           range.Tables(1).Cell(row, colBandingLocationDescription).range.Text = strBandingLocationDescription
940       End If
950       range.Tables(1).Cell(row, colDistanceKm).range.Text = IIf(intDistanceKm = 0, "", CStr(intDistanceKm))
              
960       row = row + 1
          
Next_record_label:
970       rst.MoveNext
980   Loop
990   rst.Close
1000  Set rst = Nothing


          'DD Error Handler Start
Exit_label:
1010      Exit Sub
Err_label:
1020      Select Case Err.Number
          Case Else
1030     Call LogError("basMBOAnnualProgramReportTable7_3_ForeignBandedNSWO", "ForeignBandingMBOEncounter")
1040      End Select
1050      Resume Exit_label
          ' DD Error Handler End
End Sub


'---------------------------------------------------------------------------------------
' ForeignBandingForeignEncounter
'---------------------------------------------------------------------------------------

Private Sub ForeignBandingForeignEncounter( _
    ByVal intYearEx As Integer, _
    ByRef wd As Word.Application, _
    ByRef doc As Word.Document, _
    ByRef range As Word.range, _
    ByVal strTableCaptionHeading As String)


10    On Error GoTo Err_label

20    Call WordGenerateTableAlien(doc, range, intYearEx)
30    range.Tables(1).Cell(1, 7).range.Text = "Recapture Location"


      ' qryMBOAnnualProgram_Encounter_MBOBanded
      ' -----------------------------------------------------
      ' tblEncounters x tblCaptures (Band Prefix, Band Suffix)
      ' x tblPrograms
      '
      ' WHERE Location = MBO
      ' WHERE BANDED_BY_MBO = True
      ' WHERE Disposition = "1" or "5"
      ' WHERE YearEx = argYearEx

      ' BandPrefix
      ' BandSuffix
      ' Season = MonitoringProgramSeason
      ' Species
      ' AgeBanding = Age
      ' SexBanding = Sex
      ' BandingDate = Capturedate
      ' EncounterDate = ENCOUNTER_DATE
      ' Days = EncounterDate - BandingDate      SORT DESC
      ' E_LOCATION
      ' E_LOCATION_DESCRIPTION
      ' DistanceMiles = DISTANCE


      Dim qdf As QueryDef
40    Set qdf = CurrentDb.QueryDefs("qryMBOAnnualProgram_Encounter_MBOBanded")
50    qdf.Parameters("argYearEx") = intYearEx

      Dim rst As DAO.Recordset
60    Set rst = qdf.OpenRecordset

      Dim strSpecies As String
      Dim strBandPrefix As String
      Dim strBandSuffix As String
      Dim strAgeEncounter As String
      Dim strSexEncounter As String
      Dim strAgeSexEncounter As String
      Dim strAgeBanding As String
      Dim strSexBanding As String
      Dim strAgeSexBanding As String
      Dim datBandingDate As Date
      Dim datEncounterDate As Date
      Dim intDays As Integer
      Dim strEncounterLocation As String
      Dim strEncounterLocationDescription As String
      Dim dblDistanceMiles As Double
      Dim intDistanceKm As Integer

      Dim colBand As Integer
      Dim colAgeSexEncounter As Integer
      Dim colAgeSexBanding As Integer
      Dim colBandingDate As Integer
      Dim colEncounterDate As Integer
      Dim colDays As Integer
      Dim colEncounterLocation As Integer
      Dim colDistanceKm As Integer


      Dim col As Integer

70    col = 1
80    colBand = col
90    col = col + 1
100   colAgeSexEncounter = col
110   col = col + 1
120   colAgeSexBanding = col
130   col = col + 1
140   colBandingDate = col
150   col = col + 1
160   colEncounterDate = col
170   col = col + 1
180   colDays = col
190   col = col + 1
200   colEncounterLocation = col
210   col = col + 1
220   colDistanceKm = col


      Dim row As Integer
230   row = 2

240   Do While Not rst.EOF

'         strSeason = Nz(rst("Season"))
250       strSpecies = Nz(rst("Species"))
          
260       If strSpecies <> "NSWO" Then GoTo Next_record_label
          
270       strBandPrefix = Nz(rst("BandPrefix"))
280       strBandSuffix = Nz(rst("BandSuffix"))
          
      '    strAgeEncounter = Nz(rst("AgeEncounter"))
      '    strSexEncounter = Nz(rst("SexEncounter"))
      '    strAgeSexEncounter = getAgeSex(strAgeEncounter, strSexEncounter)
290       strAgeSexEncounter = ""
          
300       strAgeBanding = Nz(rst("AgeBanding"))
310       strSexBanding = Nz(rst("SexBanding"))
320       strAgeSexBanding = getAgeSex(strAgeBanding, strSexBanding)
330       datBandingDate = Nz(rst("BandingDate"))
340       datEncounterDate = Nz(rst("Encounterdate"))
350       intDays = Nz(rst("Days"))
          
          Dim intYearsElapsed As Integer
          Dim intMonthsElapsed As Integer
          Dim intDaysElapsed As Integer
          
360       If datBandingDate = 0 Then
370           Call getTimeElapsed(datEncounterDate, datEncounterDate - intDays, intYearsElapsed, intMonthsElapsed, intDaysElapsed)
380       Else
390           Call getTimeElapsed(datEncounterDate, datBandingDate, intYearsElapsed, intMonthsElapsed, intDaysElapsed)
400       End If

          Dim strTimeElapsed As String
          
410       strTimeElapsed = ""
420       If intYearsElapsed > 0 Then
430           If intYearsElapsed = 1 Then
440               strTimeElapsed = "1 year"
450           Else
460               strTimeElapsed = CStr(intYearsElapsed) & " years"
470           End If
480       End If
490       If intMonthsElapsed > 0 Then
500           If strTimeElapsed <> "" Then
510               strTimeElapsed = strTimeElapsed & ", "
520           End If
530           If intMonthsElapsed = 1 Then
540               strTimeElapsed = strTimeElapsed & "1 month"
550           Else
560               strTimeElapsed = strTimeElapsed & CStr(intMonthsElapsed) & " months"
570           End If
580       End If
590       If intDaysElapsed > 0 Then
600           If strTimeElapsed <> "" Then
610               strTimeElapsed = strTimeElapsed & ", "
620           End If
630           If intDaysElapsed = 1 Then
640               strTimeElapsed = strTimeElapsed & "1 day"
650           Else
660               strTimeElapsed = strTimeElapsed & CStr(intDaysElapsed) & " days"
670           End If
680       End If
          
          
690       strEncounterLocation = Nz(rst("E_LOCATION"))
700       strEncounterLocationDescription = Nz(rst("E_LOCATION_DESCRIPTION"))
710       dblDistanceMiles = Nz(rst("DistanceMiles"))
720       intDistanceKm = Round(dblDistanceMiles * 1.60934, 0)
          
730       If row <> 2 Then
740           range.Tables(1).Rows.Add
750       End If
          
760       range.Tables(1).Cell(row, colBand).range.Text = strBandPrefix & "-" & strBandSuffix
770       range.Tables(1).Cell(row, colAgeSexEncounter).range.Text = strAgeSexEncounter
780       range.Tables(1).Cell(row, colAgeSexBanding).range.Text = strAgeSexBanding
790       range.Tables(1).Cell(row, colBandingDate).range.Text = ConvertDateToEnglishString(datBandingDate, 2)
800       range.Tables(1).Cell(row, colEncounterDate).range.Text = ConvertDateToEnglishString(datEncounterDate, 1)
810       range.Tables(1).Cell(row, colDays).range.Text = strTimeElapsed
820       If strEncounterLocation <> "" Then
830           range.Tables(1).Cell(row, colEncounterLocation).range.Text = strEncounterLocation
840       Else
850           range.Tables(1).Cell(row, colEncounterLocation).range.Text = strEncounterLocationDescription
860       End If
870       range.Tables(1).Cell(row, colDistanceKm).range.Text = IIf(intDistanceKm = 0, "", CStr(intDistanceKm))
              
880       row = row + 1
          
Next_record_label:
890       rst.MoveNext
900   Loop
910   rst.Close
920   Set rst = Nothing


          'DD Error Handler Start
Exit_label:
930       Exit Sub
Err_label:
940       Select Case Err.Number
          Case Else
950      Call LogError("basMBOAnnualProgramReportTable7_3_ForeignBandedNSWO", "ForeignBandingForeignEncounter")
960       End Select
970       Resume Exit_label
          ' DD Error Handler End
End Sub


'---------------------------------------------------------------------------------------
' WordGenerateTableAlien
'---------------------------------------------------------------------------------------
' entry:  range = a collapsed range that is the insertion point for the table
' exit:   range = range that includes the table

Private Sub WordGenerateTableAlien( _
    ByRef doc As Word.Document, _
    ByRef range As Word.range, _
    ByVal intYear As Integer)

      Dim row As Integer
      Dim col As Integer

20    On Error GoTo Err_label

30    doc.Tables.Add range:=range, NumRows:=2, NumColumns:=8
          
40    range.Expand (wdTable)
50    With range.Tables(1)

60        .range.Style = "ddReturnsData"

70        .Rows.Alignment = wdAlignRowCenter
80        .Rows.WrapAroundText = False

90        .LeftPadding = doc.Application.InchesToPoints(0.02)
100       .RightPadding = doc.Application.InchesToPoints(0.02)
110       .TopPadding = doc.Application.InchesToPoints(0.02)
              
120       .columns(1).Width = doc.Application.InchesToPoints(0.73)
130       .columns(2).Width = doc.Application.InchesToPoints(0.59)
140       .columns(3).Width = doc.Application.InchesToPoints(0.69)
150       .columns(4).Width = doc.Application.InchesToPoints(0.72)
160       .columns(5).Width = doc.Application.InchesToPoints(0.49)
170       .columns(6).Width = doc.Application.InchesToPoints(1.64)
180       .columns(7).Width = doc.Application.InchesToPoints(1.5)
190       .columns(8).Width = doc.Application.InchesToPoints(0.52)
          
200       .Cell(1, 1).range.Text = "Band number"
210       .Cell(1, 2).range.Text = "Age/sex in " & intYear
220       .Cell(1, 3).range.Text = "Age/sex at banding"
230       .Cell(1, 4).range.Text = "Banding date"
240       .Cell(1, 5).range.Text = intYear & " capture"
250       .Cell(1, 6).range.Text = "Time Elapsed"
260       .Cell(1, 7).range.Text = "Banding Location"
270       .Cell(1, 8).range.Text = "Distance (km)"
          
          ' Format Header Row
          
280       Call FormatWordTableRowAsHeader(.Rows(1))
          
          ' Center vertically row 1
          
290       .Rows(1).Cells.VerticalAlignment = wdCellAlignVerticalCenter
          
      ' Repeat heading row at the top of subsequent pages

300   .Rows(1).HeadingFormat = True
310   .Rows.WrapAroundText = False

320   End With

          'DD Error Handler Start
Exit_label:
330       Exit Sub
Err_label:
340       Select Case Err.Number
          Case Else
350            Call LogError("basMBOAnnualProgramReportTable7_3_ForeignBandedNSWO", "WordGenerateTableAlien")
360       End Select
370       Resume Exit_label
          ' DD Error Handler End

End Sub
