'---------------------------------------------------------------------------------------
' Module: basDocumentor
' Author: David Davey
'---------------------------------------------------------------------------------------
' I put the code in a bas module so that it runs even if frmDocumentor gets closed as we document forms

Option Compare Database
Option Explicit

'---------------------------------------------------------------------------------------
' ListModules
'---------------------------------------------------------------------------------------

Public Sub ListModules(ByRef oBook As Excel.Workbook)

10    On Error GoTo Err_label

      Dim oSheet As Excel.Worksheet
      Dim row As Long
      Dim ctr As container
      Dim doc As Document

20    Set oSheet = oBook.Worksheets.Add(After:=oBook.Worksheets(oBook.Worksheets.count))
30    oSheet.Name = "Modules"
40    With oSheet

50    row = 1
60    For Each ctr In CurrentDb.Containers
70        If ctr.Name = "Modules" Then
80            For Each doc In ctr.Documents
90                .Cells(row, 1) = doc.Name
100               row = row + 1
110           Next
120       End If
130   Next

140   End With
          'DD Error Handler Start
Exit_label:
150       Exit Sub
Err_label:
160       Select Case Err.Number
          Case Else
170      Call LogError("Form_FrmDocumenter", "ListModules")
180       End Select
190       Resume Exit_label
          ' DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' ListProces
'---------------------------------------------------------------------------------------

Public Sub ListProcs(ByRef oBook As Excel.Workbook)

10    On Error GoTo Err_label

      Dim oSheet As Excel.Worksheet
      Dim row As Long
      Dim ctr As container
      Dim doc As Document

20    Set oSheet = oBook.Worksheets.Add(After:=oBook.Worksheets(oBook.Worksheets.count))
30    oSheet.Name = "Procs"
40    With oSheet

50    row = 1
60    For Each ctr In CurrentDb.Containers
70        If ctr.Name = "Modules" Then
80            For Each doc In ctr.Documents
90                Call AllProcs(oSheet, row, doc.Name)
100           Next
110       End If
120   Next

130   End With
          'DD Error Handler Start
Exit_label:
140       Exit Sub
Err_label:
150       Select Case Err.Number
          Case Else
160      Call LogError("Form_FrmDocumenter", "ListProcs")
170       End Select
180       Resume Exit_label
          ' DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' AllProcs
'---------------------------------------------------------------------------------------

Function AllProcs(ByRef oSheet As Excel.Worksheet, ByRef row As Long, ByVal strModuleName As String)

      Dim mdl As Module
      Dim lngCount As Long
      Dim lngCountDecl As Long
      Dim lngI As Long
      Dim strProcName As String
      Dim lngR As Long

10    On Error GoTo Err_label

20    With oSheet

      ' Open specified Module object.

30    DoCmd.OpenModule strModuleName

      ' Return reference to Module object.

40    Set mdl = Modules(strModuleName)

      ' Count lines in module.

50    lngCount = mdl.CountOfLines

      ' Count lines in Declaration section in module.

60    lngCountDecl = mdl.CountOfDeclarationLines

      ' Determine name of first procedure.

70    strProcName = mdl.ProcOfLine(lngCountDecl + 1, lngR)

80    .Cells(row, 1) = strModuleName
90    .Cells(row, 2) = strProcName
100   row = row + 1

      ' Determine procedure name for each line after declarations.

110   For lngI = lngCountDecl + 1 To lngCount
          
          ' Compare procedure name with ProcOfLine property value.
          
120       If strProcName <> mdl.ProcOfLine(lngI, lngR) Then
              
130           strProcName = mdl.ProcOfLine(lngI, lngR)
              
              ' Assign unique procedure names to array.

140           .Cells(row, 1) = strModuleName
150           .Cells(row, 2) = strProcName
160           row = row + 1
170       End If
180   Next lngI

190   End With

          'DD Error Handler Start
Exit_label:
200       Exit Function
Err_label:
210       Select Case Err.Number
          Case Else
220            Call LogError("basDocumentor", "AllProcs")
230       End Select
240       Resume Exit_label
          ' DD Error Handler End
End Function
 
Public Sub ShowTables()

Dim db As Database
Dim tdf As TableDef
Dim x As Integer

Set db = CurrentDb

For Each tdf In db.TableDefs
   If Left(tdf.Name, 4) <> "MSys" Then ' Don't enumerate the system tables

      Debug.Print tdf.Name

   End If
Next tdf
End Sub

Public Sub ShowTableFields(ByVal strTable As String)

Dim db As Database
Dim tdf As TableDef
Dim x As Integer

Set db = CurrentDb

Set tdf = db.TableDefs(strTable)

      For x = 0 To tdf.Fields.count - 1
      Debug.Print tdf.Fields(x).Name
      Next x

End Sub
