Option Compare Database
Option Explicit

Const conObserved As Integer = 0
Const conCensus As Integer = 1
Const conBanded As Integer = 2
Const conReturns As Integer = 3
Const conRepeats As Integer = 4
Const conAlien As Integer = 5
Const conReplacement As Integer = 6
Const conDET As Integer = 7
Const conStatFirst = 0
Const conStatLast = 7

Const conDateStatFirst = 1
Const conDateStatLast = 11

Const conStatExcelFirst = 0
Const conStatExcelLast = 15

Const colSeason = 1
Const colPeriod = 2
Const colDateEx = 3
Const colStatFirst = 4

Const conNonSeason As Integer = -1
Const conWinter  As Integer = 0
Const conSpring  As Integer = 1
Const conSummer  As Integer = 2
Const conFall    As Integer = 3
Const conOwling  As Integer = 4
Const conRTHU    As Integer = 5
Const conNestbox As Integer = 6
Const conSummerNestbox As Integer = 7

Const conDETSeasonFirst As Integer = -1
Const conDETSeasonLast  As Integer = 3

Const conCaptureSeasonFirst As Integer = -1
Const conCaptureSeasonLast As Integer = 7
Const conCaptureRealSeasonLast As Integer = 6 ' SummerNestbox is a synthetic season
'

'---------------------------------------------------------------------------------------
' MBOAnnualProgramReport_SeasonYear
'---------------------------------------------------------------------------------------
 
Public Sub MBOAnnualProgramReport_SeasonYear( _
    ByVal intYearFirst As Integer, _
    ByVal intYearLast As Integer, _
    ByVal strLocation As String, _
    ByRef oBook As Excel.Workbook)
          
      Dim oSheet As Excel.Worksheet

10    oSheet = InsertSheet(oBook, "Global")
20    oSheet.Name = "Season x Year"
          
      Dim rowBase As Long
30    rowBase = 1

40    Call MBOAnnualProgramReport_SeasonYear_BandedBirds(intYearFirst, intYearLast, strLocation, oBook, oSheet, rowBase)
50    Call MBOAnnualProgramReport_SeasonYear_Species(intYearFirst, intYearLast, strLocation, oBook, oSheet, rowBase, "BND")
60    Call MBOAnnualProgramReport_SeasonYear_Species(intYearFirst, intYearLast, strLocation, oBook, oSheet, rowBase, "DET")

70    oSheet.Cells(rowBase, 1) = "Please add 1 to Banded-Species : All years+seaons to account for ALFL"

End Sub
 
'---------------------------------------------------------------------------------------
' MBOAnnualProgramReport_SeasonYear_BandingsSpecies
' strStat = "BND" or "DET"
'---------------------------------------------------------------------------------------

Private Sub MBOAnnualProgramReport_SeasonYear_Species( _
    ByVal intYearFirst As Integer, _
    ByVal intYearLast As Integer, _
    ByVal strLocation As String, _
    ByRef oBook As Excel.Workbook, _
    ByRef oSheet As Excel.Worksheet, _
    ByRef rowBase As Long, _
    ByRef strStat As String)

10    On Error GoTo Err_label

      Dim strSeason As String
      Dim intSeason As Integer
      Dim intYear As Integer
      Dim lngStat As Long
      Dim strSpecies As String

20    ReDim dicSeasonYear(conCaptureSeasonFirst To conCaptureSeasonLast, intYearFirst To intYearLast) As Scripting.Dictionary
30    ReDim dicSeason(conCaptureSeasonFirst To conCaptureSeasonLast) As Scripting.Dictionary
40    ReDim dicYear(intYearFirst To intYearLast) As Scripting.Dictionary
      Dim dicGlobal As Scripting.Dictionary

50    Select Case strStat
      Case "BND"
60        SysCmd acSysCmdSetStatus, "Season x Year: Banded-Species"
70    Case "DET"
80        SysCmd acSysCmdSetStatus, "Season x Year: DET-Species"
90    End Select

100   ReDim lngSpeciesSeasonYear(conCaptureSeasonFirst To conCaptureSeasonLast, intYearFirst To intYearLast) As Long
110   ReDim lngSpeciesSeason(conCaptureSeasonFirst To conCaptureSeasonLast) As Long
120   ReDim lngSpeciesYear(intYearFirst To intYearLast) As Long
      Dim lngSpeciesGlobal As Long

130   For intSeason = conCaptureSeasonFirst To conCaptureSeasonLast
140       For intYear = intYearFirst To intYearLast
150           Set dicSeasonYear(intSeason, intYear) = New Scripting.Dictionary
160           lngSpeciesSeasonYear(intSeason, intYear) = 0
170       Next
180   Next

190   For intSeason = conCaptureSeasonFirst To conCaptureSeasonLast
200       Set dicSeason(intSeason) = New Scripting.Dictionary
210       lngSpeciesSeason(intSeason) = 0
220   Next

230   For intYear = intYearFirst To intYearLast
240       Set dicYear(intYear) = New Scripting.Dictionary
250       lngSpeciesYear(intYear) = 0
260   Next

270   Set dicGlobal = New Scripting.Dictionary
280   lngSpeciesGlobal = 0

      Dim strSQL As String
290   Select Case strStat
      Case "BND"
300       strSQL = "qryMBOAnnualProgramReport_SeasonYear_BandedSpecies"
310   Case "DET"
320       strSQL = "qryMBOAnnualProgramReport_SeasonYear_DETSpecies"
330   End Select

      Dim qdf As QueryDef
340   Set qdf = CurrentDb.QueryDefs(strSQL)
350   qdf.Parameters("argYearFirst").value = intYearFirst
360   qdf.Parameters("argYearLast").value = intYearLast
370   qdf.Parameters("argLocation").value = strLocation
      Dim rst As DAO.Recordset
380   Set rst = qdf.OpenRecordset
390   Do While Not rst.EOF
          
400       strSeason = Nz(rst("Season"))
410       intSeason = toIntSeasonFromStrSeason(strSeason)
420       intYear = Nz(rst("YearEx"))
430       strSpecies = Nz(rst("Species"))

440       Select Case strStat
          Case "BND"
450           lngStat = Nz(rst("Banded"))
460       Case "DET"
470           lngStat = Nz(rst("DET"))
480       End Select
       
490       If lngStat > 0 Then
500           If Not dicSeasonYear(intSeason, intYear).Exists(strSpecies) Then
510               dicSeasonYear(intSeason, intYear).Add strSpecies, strSpecies
520           End If
530           If Not dicSeason(intSeason).Exists(strSpecies) Then
540               dicSeason(intSeason).Add strSpecies, strSpecies
550           End If
560           If Not dicYear(intYear).Exists(strSpecies) Then
570               dicYear(intYear).Add strSpecies, strSpecies
580           End If
590           If Not dicGlobal.Exists(strSpecies) Then
600               dicGlobal.Add strSpecies, strSpecies
610           End If
620       End If
          
          ' Special case Summer+Nestbox
          
630       If strSeason = "Summer" Or strSeason = "Nestbox" Then
640           If lngStat > 0 Then
650               If Not dicSeasonYear(conSummerNestbox, intYear).Exists(strSpecies) Then
660                   dicSeasonYear(conSummerNestbox, intYear).Add strSpecies, strSpecies
670               End If
680               If Not dicSeason(conSummerNestbox).Exists(strSpecies) Then
690                   dicSeason(conSummerNestbox).Add strSpecies, strSpecies
700               End If
710           End If
720       End If
       
730       rst.MoveNext
740   Loop
750   rst.Close
760   Set rst = Nothing

770   For intSeason = conCaptureSeasonFirst To conCaptureSeasonLast
780       For intYear = intYearFirst To intYearLast
790         lngSpeciesSeasonYear(intSeason, intYear) = CountSpeciesInDictionary(dicSeasonYear(intSeason, intYear))
800       Next
810   Next

820   For intSeason = conCaptureSeasonFirst To conCaptureSeasonLast
830       lngSpeciesSeason(intSeason) = CountSpeciesInDictionary(dicSeason(intSeason))
840   Next

850   For intYear = intYearFirst To intYearLast
860       lngSpeciesYear(intYear) = CountSpeciesInDictionary(dicYear(intYear))
870   Next

880   lngSpeciesGlobal = CountSpeciesInDictionary(dicGlobal)

      ' --------------------------------------
      ' Season x Year: Banded-Species => Excel
      ' --------------------------------------
      
890   Select Case strStat
      Case "BND"
900       SysCmd acSysCmdSetStatus, "Season x Year: Banded-Species => Excel"
910   Case "DET"
920       SysCmd acSysCmdSetStatus, "Season x Year: DET-Species => Excel"
930   End Select

      Dim row As Long
      Dim col As Long

      Dim colTotal As Long
      Dim rowTotal As Long

940   colTotal = 3 + intYearLast - intYearFirst
950   rowTotal = 2 + rowBase + conCaptureSeasonLast - conCaptureSeasonFirst

960   With oSheet

970   Select Case strStat
      Case "BND"
980       .Cells(rowBase, 1) = "Banded-Species"
990   Case "DET"
1000      .Cells(rowBase, 1) = "DET-Species"
1010  End Select

1020  For intSeason = conCaptureSeasonFirst To conCaptureSeasonLast
1030      row = rowBase + 1 + intSeason - conCaptureSeasonFirst
1040      .Cells(row, 1) = toStrSeasonFromIntSeason(intSeason)
1050  Next

1060  For intYear = intYearFirst To intYearLast
1070      col = 2 + intYear - intYearFirst
1080      .Cells(rowBase, col) = intYear
1090  Next

1100  .Cells(rowBase, colTotal) = "All years"
1110  .Cells(rowBase, colTotal + 1) = "Capture Years"
1120  .Cells(rowBase, colTotal + 2) = "Mean"

1130  For intSeason = conCaptureSeasonFirst To conCaptureSeasonLast
1140      row = 1 + rowBase + intSeason - conCaptureSeasonFirst
1150      For intYear = intYearFirst To intYearLast
1160          col = 2 + intYear - intYearFirst
1170          If intCapturesYearsCountSeasonYear(intSeason, intYear) > 0 Then
1180              .Cells(row, col) = lngSpeciesSeasonYear(intSeason, intYear)
1190          End If
1200      Next
1210  Next

      ' Hard to imagine no captures at all during a year ... but just in case

1220  ReDim intCapturesYear(intYearFirst To intYearLast) As Integer
      Dim intCapturesYearCount As Integer

1230  For intYear = intYearFirst To intYearLast
1240      intCapturesYear(intYear) = 0
1250  Next

1260  For intYear = intYearFirst To intYearLast
1270      For intSeason = conCaptureSeasonFirst To conCaptureRealSeasonLast
1280          If intCapturesYearsCountSeasonYear(intSeason, intYear) > 0 Then
1290              intCapturesYear(intYear) = 1
1300              intCapturesYearCount = intCapturesYearCount + 1
1310          End If
1320      Next
1330  Next

1340  intCapturesYearCount = 0
1350  For intYear = intYearFirst To intYearLast
1360       intCapturesYearCount = intCapturesYearCount + intCapturesYear(intYear)
1370  Next

      ' For each year, total over seasons

1380  .Cells(rowTotal, 1) = "All Seasons"
1390  For intYear = intYearFirst To intYearLast
1400      col = 2 + intYearLast - intYear
1410      If intCapturesYear(intYear) > 0 Then
1420          .Cells(rowTotal, col) = lngSpeciesYear(intYear)
1430      End If
1440  Next

      Dim lngTotalOverAllYears As Long
1450  For intYear = intYearFirst To intYearLast
1460      lngTotalOverAllYears = lngTotalOverAllYears + lngSpeciesYear(intYear)
1470  Next

      ' Grand total - over seasons and years

1480  .Cells(rowTotal, colTotal) = lngSpeciesGlobal
1490  .Cells(rowTotal, colTotal + 1) = intCapturesYearCount
1500  If intCapturesYearCount > 0 Then
1510      .Cells(rowTotal, colTotal + 2) = lngTotalOverAllYears / intCapturesYearCount
1520  End If

1530   .Rows(rowTotal - 1).Font.Color = RGB(255, 102, 0) ' orange for Summer+Nestbox
1540  .Rows(rowTotal).Font.Color = RGB(0, 112, 192) ' blue

      ' Season banded species
      ' Mean (over years) of season x year banded species

      Dim lngTotal As Long ' Total for a sesaon of season x year banded species

1550  For intSeason = conCaptureSeasonFirst To conCaptureSeasonLast
1560      lngTotal = 0
1570      row = 1 + rowBase + intSeason - conCaptureSeasonFirst
1580      For intYear = intYearFirst To intYearLast
1590          lngTotal = lngTotal + lngSpeciesSeasonYear(intSeason, intYear)
1600      Next
1610      col = 1 + (intYearLast - intYearFirst + 1) + 1
1620      If intCapturesYearsCountSeason(intSeason) > 0 Then
1630          .Cells(row, col) = lngSpeciesSeason(intSeason)
1640          .Cells(row, col + 1) = intCapturesYearsCountSeason(intSeason)
1650          .Cells(row, col + 2) = lngTotal / intCapturesYearsCountSeason(intSeason)
1660      End If
1670  Next

1680  .range(.Cells(rowBase, 1), .Cells(rowBase, colTotal + 2)).Font.Bold = True
1690  col = (1 + (intYearLast - intYearFirst + 1) + 3)
1700  .range(.columns(col), .columns(col)).NumberFormat = "#0"
1710  .range(.Cells(rowBase, colTotal - 1), .Cells(1 + rowBase + conCaptureSeasonLast - conCaptureSeasonFirst, colTotal - 1)).Interior.Color = RGB(215, 228, 188)
1720  .range(.columns(2), .columns(colTotal + 2)).HorizontalAlignment = xlCenter
1730  .range(.columns(1), .columns(colTotal + 2)).AutoFit
1740  For col = 1 To colTotal + 2
1750      .columns(col).ColumnWidth = .columns(col).ColumnWidth + 2
1760  Next

1770  End With

1780  rowBase = rowTotal + 2

      'DD Error Handler Start
Exit_label:
1790       Exit Sub
Err_label:
1800       Select Case Err.Number
           Case Else
1810      Call LogError("basMBOAnnualProgramReportOtherStats", "MBOAnnualProgramReport_SeasonYear_Species")
1820       End Select
1830       Resume Exit_label
      'DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' MBOAnnualProgramReport_SeasonYear_BandedBirds
'---------------------------------------------------------------------------------------
 
Private Sub MBOAnnualProgramReport_SeasonYear_BandedBirds( _
    ByVal intYearFirst As Integer, _
    ByVal intYearLast As Integer, _
    ByVal strLocation As String, _
    ByRef oBook As Excel.Workbook, _
    ByRef oSheet As Excel.Worksheet, _
    ByRef rowBase As Long)
          
10    On Error GoTo Err_label

      Dim strSeason As String
      Dim intSeason As Integer
      Dim intYear As Integer
      Dim lngBanded As Long

20    SysCmd acSysCmdSetStatus, "Season x Year: Banded-Birds"

30    ReDim lngBandedSeasonYear(conCaptureSeasonFirst To conCaptureSeasonLast, intYearFirst To intYearLast) As Long
40    ReDim lngBandedYear(intYearFirst To intYearLast) As Long

50    For intSeason = conCaptureSeasonFirst To conCaptureSeasonLast
60        For intYear = intYearFirst To intYearLast
70            lngBandedSeasonYear(intSeason, intYear) = 0
80        Next
90    Next
          
100   For intYear = intYearFirst To intYearLast
110       lngBandedYear(intYear) = 0
120   Next
          
      Dim qdf As QueryDef
130   Set qdf = CurrentDb.QueryDefs("qryMBOAnnualProgramReport_BandingSeasonYear")
140   qdf.Parameters("argYearFirst").value = intYearFirst
150   qdf.Parameters("argYearLast").value = intYearLast
160   qdf.Parameters("argLocation").value = strLocation
      Dim rst As DAO.Recordset
170   Set rst = qdf.OpenRecordset
180   Do While Not rst.EOF
          
190       strSeason = Nz(rst("Season"))
200       intYear = Nz(rst("YearEx"))
210       lngBanded = Nz(rst("Banded"))

220       intSeason = toIntSeasonFromStringSeason(strSeason)
230       If intSeason >= conCaptureSeasonFirst And intSeason <= conCaptureSeasonLast And intYear >= intYearFirst And intYear <= intYearLast Then
240           lngBandedSeasonYear(toIntSeasonFromStringSeason(strSeason), intYear) = lngBanded
250           lngBandedYear(intYear) = lngBandedYear(intYear) + lngBanded
260       Else
270            MsgBox "MBOAnnualProgramReportBanding: intSeason out of bounds OR intYear out of bounds"
280       End If
          
290       rst.MoveNext
300   Loop
310   rst.Close
320   Set rst = Nothing

      ' Fill in Summer + Nestbox

330   For intYear = intYearFirst To intYearLast
340       lngBandedSeasonYear(conSummerNestbox, intYear) = lngBandedSeasonYear(conSummer, intYear) + lngBandedSeasonYear(conNestbox, intYear)
350   Next
          
      'ReDim DETSeasonYear(conCaptureSeasonFirst To conCaptureSeasonLast, intYearFirst To intYearLast) As Integer

      ' ------------------------------------
      ' Season x Year: Banded Birds => Excel
      ' ------------------------------------

360   SysCmd acSysCmdSetStatus, "Season x Year: Banded Birds => Excel"

      Dim row As Long
      Dim col As Long

      Dim colTotal As Long
      Dim rowTotal As Long

370   colTotal = 3 + intYearLast - intYearFirst
380   rowTotal = 2 + rowBase + conCaptureSeasonLast - conCaptureSeasonFirst

390   With oSheet

400   .Cells(rowBase, 1) = "Banded-Birds"

410   For intSeason = conCaptureSeasonFirst To conCaptureSeasonLast
420       row = rowBase + 1 + intSeason - conCaptureSeasonFirst
430       .Cells(row, 1) = toStrSeasonFromIntSeason(intSeason)
440   Next

450   For intYear = intYearFirst To intYearLast
460       col = 2 + intYear - intYearFirst
470       .Cells(rowBase, col) = intYear
480   Next

490   .Cells(rowBase, colTotal) = "Total"
500   .Cells(rowBase, colTotal + 1) = "Capture Years"
510   .Cells(rowBase, colTotal + 2) = "Mean"

520   For intSeason = conCaptureSeasonFirst To conCaptureSeasonLast
530       row = 1 + rowBase + intSeason - conCaptureSeasonFirst
540       For intYear = intYearFirst To intYearLast
550           col = 2 + intYear - intYearFirst
560           If intCapturesYearsCountSeasonYear(intSeason, intYear) > 0 Then
570               .Cells(row, col) = lngBandedSeasonYear(intSeason, intYear)
580           End If
590       Next
600   Next

      ' Hard to imagine no captures at all during a year ... but just in case

610   ReDim intCapturesYear(intYearFirst To intYearLast)
620   For intYear = intYearFirst To intYearLast
630       intCapturesYear(intYear) = 0
640   Next
650   For intYear = intYearFirst To intYearLast
660       For intSeason = conCaptureSeasonFirst To conCaptureRealSeasonLast
670           If intCapturesYearsCountSeasonYear(intSeason, intYear) > 0 Then
680               intCapturesYear(intYear) = 1
690           End If
700       Next
710   Next

720   Dim intCapturesYearCount As Integer
730   intCapturesYearCount = 0
740   For intYear = intYearFirst To intYearLast
750       intCapturesYearCount = intCapturesYearCount + intCapturesYear(intYear)
760   Next

770   .Cells(rowTotal, 1) = "Total"
780   For intYear = intYearFirst To intYearLast
790       col = 2 + intYearLast - intYear
800       If intCapturesYear(intYear) > 0 Then
810           .Cells(rowTotal, col) = lngBandedYear(intYear)
820       End If
830   Next

      Dim lngTotalOverAllYears As Long
840   For intYear = intYearFirst To intYearLast
850       lngTotalOverAllYears = lngTotalOverAllYears + lngBandedYear(intYear)
860   Next

      ' Grand total - over seasons and years

870   .Cells(rowTotal, colTotal) = lngTotalOverAllYears
880   .Cells(rowTotal, colTotal + 1) = intCapturesYearCount
890   If intCapturesYearCount > 0 Then
900       .Cells(rowTotal, colTotal + 2) = lngTotalOverAllYears / intCapturesYearCount
910   End If


920    .Rows(rowTotal - 1).Font.Color = RGB(255, 102, 0) ' orange for Summer+Nestbox
930   .Rows(rowTotal).Font.Color = RGB(0, 112, 192) ' blue

      ' Total
      ' Mean (divide by the number of Capture years in a season)

      Dim lngTotal As Long

940   For intSeason = conCaptureSeasonFirst To conCaptureSeasonLast
950       lngTotal = 0
960       row = 1 + rowBase + intSeason - conCaptureSeasonFirst
970       For intYear = intYearFirst To intYearLast
980           lngTotal = lngTotal + lngBandedSeasonYear(intSeason, intYear)
990       Next
1000      col = 1 + (intYearLast - intYearFirst + 1) + 1
1010      If intCapturesYearsCountSeason(intSeason) > 0 Then
1020          .Cells(row, col) = lngTotal
1030          .Cells(row, col + 1) = intCapturesYearsCountSeason(intSeason)
1040          .Cells(row, col + 2) = lngTotal / intCapturesYearsCountSeason(intSeason)
1050      End If
1060  Next

1070  .range(.Cells(rowBase, 1), .Cells(rowBase, colTotal + 2)).Font.Bold = True
1080
1090  col = (1 + (intYearLast - intYearFirst + 1) + 3)
1100  .range(.columns(col), .columns(col)).NumberFormat = "#0"
1110  .range(.Cells(rowBase, colTotal - 1), .Cells(1 + rowBase + conCaptureSeasonLast - conCaptureSeasonFirst, colTotal - 1)).Interior.Color = RGB(215, 228, 188)
1120  .range(.columns(2), .columns(colTotal + 2)).HorizontalAlignment = xlCenter
1130  .range(.columns(1), .columns(colTotal + 2)).AutoFit
1140  For col = 1 To colTotal + 2
1150      .columns(col).ColumnWidth = .columns(col).ColumnWidth + 2
1160  Next

1170  End With

1180  rowBase = 4 + rowBase + conCaptureSeasonLast - conCaptureSeasonFirst

      'DD Error Handler Start
Exit_label:
1190       Exit Sub
Err_label:
1200       Select Case Err.Number
           Case Else
1210      Call LogError("basMBOAnnualProgramReportOtherStats", "MBOAnnualProgramReport_SeasonYear_BandedBirds")
1220       End Select
1230       Resume Exit_label
      'DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' toIntSeasonFromStringSeason
'---------------------------------------------------------------------------------------
 
Public Function toIntSeasonFromStringSeason(ByVal strSeason As String) As Integer

10    On Error GoTo Err_label

20        Select Case strSeason
          Case "Winter"
30            toIntSeasonFromStringSeason = conWinter
40        Case "Spring"
50            toIntSeasonFromStringSeason = conSpring
60        Case "Summer"
70            toIntSeasonFromStringSeason = conSummer
80        Case "NestBox"
90            toIntSeasonFromStringSeason = conNestbox
100       Case "Fall"
110           toIntSeasonFromStringSeason = conFall
120       Case "Owling"
130           toIntSeasonFromStringSeason = conOwling
140       Case "Non Season"
150           toIntSeasonFromStringSeason = conNonSeason
160       End Select

      'DD Error Handler Start
Exit_label:
170        Exit Function
Err_label:
180        Select Case Err.Number
           Case Else
190             Call LogError("basMBOAnnualProgramReportOtherStats", "toIntSeasonFromStringSeason")
200        End Select
210        Resume Exit_label
      'DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' MBOAnnualReportDates
'---------------------------------------------------------------------------------------
 
Public Sub MBOAnnualProgramReportDates( _
    ByVal intYear As Integer, _
    ByVal strLocation As String, _
    ByRef oExcel As Excel.Application, _
    ByRef oBook As Excel.Workbook)

      Dim intSeason As Integer
      Dim strSeason As String
      Dim datDateFirst(conCaptureSeasonFirst To conCaptureSeasonLast, conDateStatFirst To conDateStatLast) As Date
      Dim datDateLast(conCaptureSeasonFirst To conCaptureSeasonLast, conDateStatFirst To conDateStatLast) As Date
      Dim stat As Integer
      Dim strWhere As String

      ' Loop over each season

10    On Error GoTo Err_label

20    For intSeason = conCaptureSeasonFirst To conCaptureSeasonLast
30        strSeason = toStrSeasonFromIntSeason(intSeason)
40        For stat = conDateStatFirst To conDateStatLast
50            strWhere = "[stat" & stat & "] > 0 AND [Season] = '" & strSeason & "' AND [YearEx] = " & intYear & " AND [Location] = '" & strLocation & "'"
60            datDateFirst(intSeason, stat) = Nz(DMin("[DateEx]", "qryMBOAnnualProgramReport_Dates", strWhere))
70            datDateLast(intSeason, stat) = Nz(DMax("[DateEx]", "qryMBOAnnualProgramReport_Dates", strWhere))
80        Next
90    Next

      ' Excel

      Dim oSheet As Excel.Worksheet

100     oSheet = InsertSheet(oBook, "Global")
110   oSheet.Name = "Dates"

120   With oSheet

      Dim row As Long
      Dim col As Long

130   For intSeason = conCaptureSeasonFirst To conCaptureSeasonLast
140       strSeason = toStrSeasonFromIntSeason(intSeason)
150       col = 2 + intSeason - conCaptureSeasonFirst
160       .Cells(1, col) = strSeason
170       .columns(col).NumberFormat = "dd mmm yyyy"
180       .columns(col).HorizontalAlignment = xlCenter
190       row = 2
200       For stat = conDateStatFirst To conDateStatLast
210           If datDateFirst(intSeason, stat) > 0 Then
220               .Cells(row, col) = datDateFirst(intSeason, stat)
230           End If
240           row = row + 1
250           If datDateFirst(intSeason, stat) > 0 Then
260               .Cells(row, col) = datDateLast(intSeason, stat)
270           End If
280           row = row + 2
290       Next
300   Next

      Dim datDateFrom As Date

310   For intSeason = conCaptureSeasonFirst To conCaptureSeasonLast
320       strSeason = toStrSeasonFromIntSeason(intSeason)
330       datDateFrom = Nz(DLookup("DateFrom", "tblPrograms", "[MonitoringprogramSeason] = '" & strSeason & "' AND YearEx = " & intYear))
340       col = 2 + intSeason - conCaptureSeasonFirst
350       If datDateFrom > 0 Then
360           .Cells(row, col) = datDateFrom
370       End If
380   Next

390   col = 1
400   row = 2

410   .Cells(2, 1) = "First OBS"
420   .Cells(3, 1) = "Last OBS"

430   .Cells(5, 1) = "First Census"
440   .Cells(6, 1) = "Last Census"

450   .Cells(8, 1) = "First Banded"
460   .Cells(9, 1) = "Last Banded"

470   .Cells(11, 1) = "First Return"
480   .Cells(12, 1) = "Last Return"

490   .Cells(14, 1) = "First Repeat"
500   .Cells(15, 1) = "Last Repeat"

510   .Cells(17, 1) = "First DET"
520   .Cells(18, 1) = "Last DET"

530   .Cells(20, 1) = "First Alien"
540   .Cells(21, 1) = "Last Alien"

550   .Cells(23, 1) = "First Replacment"
560   .Cells(24, 1) = "Last Replacement"

570   .Cells(26, 1) = "First Net Used"
580   .Cells(27, 1) = "Last Net Used"

590   .Cells(29, 1) = "First Banding Day"
600   .Cells(30, 1) = "Last Banding Day"

610   .Cells(32, 1) = "First DET Day"
620   .Cells(33, 1) = "Last DET Day"

630   .Cells(35, 1) = "Official First Day"

640   .range(.columns(1), .columns(2 + conCaptureSeasonLast - conCaptureSeasonFirst)).AutoFit

650   For col = 1 To 2 + conCaptureSeasonLast - conCaptureSeasonFirst
660       .columns(col).ColumnWidth = .columns(col).ColumnWidth + 5
670   Next

680   .range("B2").Select
690   oBook.Application.ActiveWindow.FreezePanes = True

700   End With

      'DD Error Handler Start
Exit_label:
710        Exit Sub
Err_label:
720        Select Case Err.Number
           Case Else
730             Call LogError("basMBOAnnualProgramReportOtherStats", "MBOAnnualReportDates")
740        End Select
750        Resume Exit_label
      'DD Error Handler End
          
End Sub

'---------------------------------------------------------------------------------------
' MBOAnnualProgramReportPeriodSeasonAnnual
'---------------------------------------------------------------------------------------
 
Public Sub MBOAnnualProgramReportPeriodSeasonAnnual( _
    ByVal intYearFirst As Integer, _
    ByVal intYearLast As Integer, _
    ByVal strLocation As String, _
    ByRef oExcel As Excel.Application, _
    ByRef oBook As Excel.Workbook)
    
10    On Error GoTo Err_label

Dim oSheet As Excel.Worksheet
Dim intYear As Integer

20    Set oSheet = InsertSheet(oBook, "Global")
30    oSheet.Name = "Year x Season"

Dim lngRowNext As Long
40    lngRowNext = 1

50    For intYear = intYearFirst To intYearLast

60        Call MBOAnnualProgramReportSeason(intYear, strLocation, oExcel, oBook, oSheet, lngRowNext)
70        Call MBOAnnualProgramReportAnnual(intYear, strLocation, oExcel, oBook, oSheet, lngRowNext)

80    Next

90    oSheet.range("A3").Select
100   oExcel.ActiveWindow.FreezePanes = True

'DD Error Handler Start
Exit_label:
110        Exit Sub
Err_label:
120        Select Case Err.Number
     Case Else
130       Call LogError("basMBOAnnualProgramReportOtherStats", "MBOAnnualProgramReportPeriodSeasonAnnual")
140        End Select
150        Resume Exit_label
'DD Error Handler End

End Sub

' ---------------------------------------------------------------------------------------
'  MBOAnnualProgramReportSeason
' ---------------------------------------------------------------------------------------
 
Public Sub MBOAnnualProgramReportSeason( _
    ByVal intYear As Integer, _
    ByVal strLocation As String, _
    ByRef oExcel As Excel.Application, _
    ByRef oBook As Excel.Workbook, _
    ByRef oSheet As Excel.Worksheet, _
    ByRef lngRowNext As Long)

      Dim strSeason As String
      Dim strSpecies As String
      Dim stat As Integer
      Dim lngStat(conStatFirst To conStatLast) As Long
      Dim lngStatBirds(conStatFirst To conStatLast) As Long
      Dim dicStatSpecies(conStatFirst To conStatLast) As Scripting.Dictionary
      Dim lngStatSpecies(conStatFirst To conStatLast) As Long

10    On Error GoTo Err_label

20    For stat = conStatFirst To conStatLast
30        lngStatBirds(stat) = 0
40        Set dicStatSpecies(stat) = New Scripting.Dictionary
50    Next

      Dim strSeason_previous As String

60    strSeason_previous = ""

70    CurrentDb.Execute "DELETE * FROM tblMBOAnnualProgramReportDaily"

      Dim rstDaily As DAO.Recordset
80    Set rstDaily = CurrentDb.OpenRecordset("tblMBOAnnualProgramReportDaily", dbOpenDynaset)

      Dim qdf As QueryDef
90    Set qdf = CurrentDb.QueryDefs("qryMBOAnnualProgramReport_Season")
100   qdf.Parameters("argYear").value = intYear
110   qdf.Parameters("argLocation").value = strLocation
      Dim rst As DAO.Recordset
120   Set rst = qdf.OpenRecordset
130   Do While Not rst.EOF

140       strSeason = Nz(rst("Season"))
150       strSpecies = Nz(rst("Species"))
160       lngStat(conObserved) = Nz(rst("Observed"))
170       lngStat(conCensus) = Nz(rst("Census"))
180       lngStat(conBanded) = Nz(rst("Banded"))
190       lngStat(conReturns) = Nz(rst("Returns"))
200       lngStat(conRepeats) = Nz(rst("Repeats"))
210       lngStat(conAlien) = Nz(rst("Alien"))
220       lngStat(conReplacement) = Nz(rst("Replacement"))
230       lngStat(conDET) = Nz(rst("DET"))

240       If strSeason <> strSeason_previous Then

        ' L1 control break

250     If strSeason_previous <> "" Then

            ' Footer

260         rstDaily.AddNew
270         rstDaily("intSeason") = toIntSeasonFromStrSeason(strSeason_previous)
280         rstDaily("Season") = strSeason_previous
290         For stat = conStatFirst To conStatLast
300             rstDaily(toStrStatFromIntStat(stat)) = lngStatBirds(stat)
310             rstDaily("Species" & toStrStatFromIntStat(stat)) = CountSpeciesInDictionary(dicStatSpecies(stat))
320         Next
330         rstDaily.Update

340         strSeason_previous = strSeason

            ' Header

350         For stat = conStatFirst To conStatLast
360             lngStatBirds(stat) = 0
370             dicStatSpecies(stat).RemoveAll
380         Next

390     End If

400     Call SysCmd(acSysCmdSetStatus, "Season: " & strSeason)
410     DoEvents

420      End If

         ' Detail

430       For stat = conStatFirst To conStatLast
440           lngStatBirds(stat) = lngStatBirds(stat) + lngStat(stat)
450           If lngStat(stat) > 0 Then
460               If Not dicStatSpecies(stat).Exists(strSpecies) Then
470                   Call dicStatSpecies(stat).Add(strSpecies, strSpecies)
480               End If
490           End If
500       Next

510       strSeason_previous = strSeason

520       rst.MoveNext
530   Loop

540   If strSeason_previous <> "" Then

          ' Footer

550       rstDaily.AddNew
560       rstDaily("intSeason") = toIntSeasonFromStrSeason(strSeason)
570       rstDaily("Season") = strSeason_previous
580       For stat = conStatFirst To conStatLast
590           rstDaily(toStrStatFromIntStat(stat)) = lngStatBirds(stat)
600           rstDaily("Species" & toStrStatFromIntStat(stat)) = CountSpeciesInDictionary(dicStatSpecies(stat))
610       Next
620       rstDaily.Update

630   End If

640   rst.Close
650   Set rst = Nothing

660   Call SysCmd(acSysCmdClearStatus)

670   rstDaily.Close
680   Set rstDaily = Nothing

      ' Excel

690   Set rst = CurrentDb.OpenRecordset("SELECT * FROM tblMBOAnnualProgramReportDaily ORDER BY intSeason", dbOpenDynaset)

700   With oSheet

      Dim row As Long
      Dim col As Long

      Dim rowSeasonFirst As Long
      Dim rowSeasonLast As Long

      Dim lngStatExcel(conStatExcelFirst To conStatExcelLast) As Long

710   rowSeasonFirst = lngRowNext + 2

720   row = lngRowNext + 1
730   .Cells(row, 1) = "Report Year"
740   .Cells(row, 2) = "Season"
750   .Cells(row, 4) = "OBS"
760   .Cells(row, 5) = "CNS"
770   .Cells(row, 6) = "BND"
780   .Cells(row, 7) = "RET"
790   .Cells(row, 8) = "REP"
800   .Cells(row, 9) = "Alien"
810   .Cells(row, 10) = "Repl"
820   .Cells(row, 11) = "DET"

830   .Cells(row, 13) = "OBS"
840   .Cells(row, 14) = "CNS"
850   .Cells(row, 15) = "BND"
860   .Cells(row, 16) = "RET"
870   .Cells(row, 17) = "REP"
880   .Cells(row, 18) = "Alien"
890   .Cells(row, 19) = "Repl"
900   .Cells(row, 20) = "DET"

910   row = lngRowNext + 2

920   Do While Not rst.EOF

930       strSeason = Nz(rst("Season"))
940       For stat = conStatFirst To conStatLast
950             lngStatExcel(stat) = Nz(rst(toStrStatFromIntStat(stat)))
960             lngStatExcel(stat + 8) = Nz(rst("Species" & toStrStatFromIntStat(stat)))
970       Next

980       .Cells(row, 1) = intYear
990       .Cells(row, 2) = strSeason
1000      col = colStatFirst
1010      For stat = conStatExcelFirst To conStatExcelLast
1020          col = colStatFirst + stat
1030              If lngStatExcel(stat) > 0 Then
1040              If col = 12 Then .Cells(row, col) = " "
1050              If col >= 12 Then col = col + 1
1060                   .Cells(row, col) = lngStatExcel(stat)
1070            End If
1080      Next

      '    strSeason_previous = strSeason

1090      row = row + 1
1100      rst.MoveNext
1110  Loop
1120  rst.Close
1130  Set rst = Nothing

      ' Footer

1140  rowSeasonLast = row - 1

1150  .columns(colDateEx).NumberFormat = "dd mmm yyyy"

1160  .range(.columns(1), .columns(19)).HorizontalAlignment = xlCenter
1170  .range(.columns(1), .columns(19)).AutoFit

1180  .Cells(lngRowNext, 4) = "Birds"
1190  .Cells(lngRowNext, 13) = "Species"
1200  .range(.Cells(lngRowNext, 4), .Cells(lngRowNext, 11)).Merge
1210  .range(.Cells(lngRowNext, 13), .Cells(lngRowNext, 20)).Merge

1220  End With

1230  lngRowNext = rowSeasonLast + 2


      'DD Error Handler Start
Exit_label:
1240       Exit Sub
Err_label:
1250       Select Case Err.Number
           Case Else
1260            Call LogError("basMBOAnnualProgramReportOtherStats", "MBOAnnualProgramReportSeason")
1270       End Select
1280       Resume Exit_label
      'DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' MBOAnnualProgramReportAnnual
'---------------------------------------------------------------------------------------
' Excel only - Year x Season worksheet
'
' Summary over a report year
  
Public Sub MBOAnnualProgramReportAnnual( _
    ByVal intYear As Integer, _
    ByVal strLocation As String, _
    ByRef oExcel As Excel.Application, _
    ByRef oBook As Excel.Workbook, _
    ByRef oSheet As Excel.Worksheet, _
    ByRef lngRowNext As Long)
       
      Dim strSeason As String
      Dim strSpecies As String
      Dim stat As Integer
      Dim lngStat(conStatFirst To conStatLast) As Long
      Dim lngStatBirds(conStatFirst To conStatLast) As Long
      Dim dicStatSpecies(conStatFirst To conStatLast) As Scripting.Dictionary
      Dim lngStatSpecies(conStatFirst To conStatLast) As Long

10    On Error GoTo Err_label

20    For stat = conStatFirst To conStatLast
30        lngStatBirds(stat) = 0
40        Set dicStatSpecies(stat) = New Scripting.Dictionary
50    Next

' tblMBOAnnualProgramReportDaily
' ------------------------------
' A temporary table
'
' intSeason
' Season
' Period
' DateEx
' Observed
' Census
' Banded
' Returns
' Repeats
' Alien
' Replacement
' DET
' SpeciesObserved
' SpeciesCensus
' SpeciesBanded
' SpeciesReturns
' SpeciesAlien
' SpeciesReplacement
' SpeciesDET

' Here,tblMBOAnnualProgramReportDaily will be loaded with only one record

60    CurrentDb.Execute "DELETE * FROM tblMBOAnnualProgramReportDaily"

      Dim rstDaily As DAO.Recordset
70    Set rstDaily = CurrentDb.OpenRecordset("tblMBOAnnualProgramReportDaily", dbOpenDynaset)

' qryMBOAnnualProgramReport_Annual
' --------------------------------------------------------------------------------------------------------
' For a given report year, contains one record per pseudospecies, containing the total over each statistic
' --------------------------------------------------------------------------------------------------------
' tblDETSpecies x tblPrograms
' WHERE Location = [argLocation]
' WHERE YearEx = [argYear]
' GROUP BY Species
' Observed: SUM Observed
' Census: SUM Census
' Banded: SUM Banded
' Repeats: SUM Repeats
' Returns: SUM Returns
' DET: SUM DET
' Alien: SUM Observed3
' Replacement: SUM Observed4
'
' I will be able to count individuals and count species over the year

      Dim qdf As QueryDef
80    Set qdf = CurrentDb.QueryDefs("qryMBOAnnualProgramReport_Annual")
90    qdf.Parameters("argYear").value = intYear
100   qdf.Parameters("argLocation").value = strLocation
      Dim rst As DAO.Recordset
110   Set rst = qdf.OpenRecordset
120   Do While Not rst.EOF

130       strSpecies = Nz(rst("Species"))
140       lngStat(conObserved) = Nz(rst("Observed"))
150       lngStat(conCensus) = Nz(rst("Census"))
160       lngStat(conBanded) = Nz(rst("Banded"))
170       lngStat(conReturns) = Nz(rst("Returns"))
180       lngStat(conRepeats) = Nz(rst("Repeats"))
190       lngStat(conAlien) = Nz(rst("Alien"))
200       lngStat(conReplacement) = Nz(rst("Replacement"))
210       lngStat(conDET) = Nz(rst("DET"))
                   
         ' Detail
                    
220       For stat = conStatFirst To conStatLast
230           lngStatBirds(stat) = lngStatBirds(stat) + lngStat(stat)
240           If lngStat(stat) > 0 Then
250               If Not dicStatSpecies(stat).Exists(strSpecies) Then
260                   Call dicStatSpecies(stat).Add(strSpecies, strSpecies)
270               End If
280           End If
290       Next

300       rst.MoveNext
310   Loop
          
          ' Footer
          
320       rstDaily.AddNew
330       For stat = conStatFirst To conStatLast
340           rstDaily(toStrStatFromIntStat(stat)) = lngStatBirds(stat)
350           rstDaily("Species" & toStrStatFromIntStat(stat)) = CountSpeciesInDictionary(dicStatSpecies(stat))
360       Next
370       rstDaily.Update

380   rst.Close
390   Set rst = Nothing

400   rstDaily.Close
410   Set rstDaily = Nothing

      ' Excel

420   Set rst = CurrentDb.OpenRecordset("SELECT * FROM tblMBOAnnualProgramReportDaily", dbOpenDynaset)

430   With oSheet

      Dim row As Long
      Dim col As Long

      Dim rowSeasonFirst As Long
      Dim rowSeasonLast As Long

      Dim lngStatExcel(conStatExcelFirst To conStatExcelLast) As Long

440   rowSeasonFirst = lngRowNext + 2

450   row = lngRowNext + 1
460   .Cells(row, 1) = "Report year"
470   .Cells(row, 1) = "Season"
480   .Cells(row, 4) = "OBS"
490   .Cells(row, 5) = "CNS"
500   .Cells(row, 6) = "BND"
510   .Cells(row, 7) = "RET"
520   .Cells(row, 8) = "REP"
530   .Cells(row, 9) = "Alien"
540   .Cells(row, 10) = "Repl"
550   .Cells(row, 11) = "DET"

560   .Cells(row, 13) = "OBS"
570   .Cells(row, 14) = "CNS"
580   .Cells(row, 15) = "BND"
590   .Cells(row, 16) = "RET"
600   .Cells(row, 17) = "REP"
610   .Cells(row, 18) = "Alien"
620   .Cells(row, 19) = "Repl"
630   .Cells(row, 20) = "DET"

640   row = lngRowNext + 2

650   If Not rst.EOF Then

660        For stat = conStatFirst To conStatLast
670             lngStatExcel(stat) = Nz(rst(toStrStatFromIntStat(stat)))
680             lngStatExcel(stat + 8) = Nz(rst("Species" & toStrStatFromIntStat(stat)))
690       Next
        

700       .Cells(row, 1) = intYear
710       .Cells(row, 2) = "All"
720       col = colStatFirst
730       For stat = conStatExcelFirst To conStatExcelLast
740           col = colStatFirst + stat
750           If col >= 12 Then col = col + 1
760               If lngStatExcel(stat) > 0 Then
770                    .Cells(row, col) = lngStatExcel(stat)
780             End If
790       Next
          
800       row = row + 1
810   End If
820   rst.Close
830   Set rst = Nothing

      ' Footer

840   rowSeasonLast = row - 1

850   .columns(colDateEx).NumberFormat = "dd mmm yyyy"

860   .range(.columns(1), .columns(20)).HorizontalAlignment = xlCenter
870   .range(.columns(1), .columns(20)).AutoFit

880   .Cells(lngRowNext, 4) = "Birds"
890   .Cells(lngRowNext, 13) = "Species"
900   .range(.Cells(lngRowNext, 4), .Cells(lngRowNext, 11)).Merge
910   .range(.Cells(lngRowNext, 13), .Cells(lngRowNext, 20)).Merge

920   End With

930   lngRowNext = rowSeasonLast + 2

      'DD Error Handler Start
Exit_label:
940        Exit Sub
Err_label:
950        Select Case Err.Number
           Case Else
960             Call LogError("basMBOAnnualProgramReportOtherStats", "MBOAnnualProgramReportAnnual")
970        End Select
980        Resume Exit_label
      'DD Error Handler End
       
End Sub

'---------------------------------------------------------------------------------------
' toStrStatFromIntStat
'---------------------------------------------------------------------------------------
 
Private Function toStrStatFromIntStat(ByVal stat As Integer)
10    On Error GoTo Err_label

20    Select Case stat
      Case conObserved
30        toStrStatFromIntStat = "Observed"
40    Case conCensus
50        toStrStatFromIntStat = "Census"
60    Case conBanded
70            toStrStatFromIntStat = "Banded"
80    Case conReturns
90        toStrStatFromIntStat = "Returns"
100   Case conRepeats
110       toStrStatFromIntStat = "Repeats"
120   Case conAlien
130       toStrStatFromIntStat = "Alien"
140   Case conReplacement
150       toStrStatFromIntStat = "Replacement"
160   Case conDET
170   toStrStatFromIntStat = "DET"
180   Case Else
190       toStrStatFromIntStat = ""
200   End Select

      'DD Error Handler Start
Exit_label:
210        Exit Function
Err_label:
220        Select Case Err.Number
           Case Else
230             Call LogError("basMBOAnnualProgramReportOtherStats", "toStrStatFromIntStat")
240        End Select
250        Resume Exit_label
      'DD Error Handler End
End Function
