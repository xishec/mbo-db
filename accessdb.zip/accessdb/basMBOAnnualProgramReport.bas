'---------------------------------------------------------------------------------------
' Module    : basMBOAnnualProgramReport
' Author    : David Davey
'---------------------------------------------------------------------------------------

Option Compare Database
Option Explicit

Public fStatSeasonYearPeriodHasBeenGenerated As Boolean

' Seasons

Const conNonSeason As Integer = -1
Const conWinter  As Integer = 0
Const conSpring  As Integer = 1
Const conSummer  As Integer = 2
Const conFall    As Integer = 3
Const conOwling  As Integer = 4
Const conRTHU    As Integer = 5
Const conNestbox As Integer = 6
Const conSummerNestbox As Integer = 7

Const conDETSeasonFirst As Integer = -1
Const conDETSeasonLast  As Integer = 3

Const intSeasonFirst As Integer = -1
Const intSeasonLast  As Integer = 7


'---------------------------------------------------------------------------------------
' MBOAnnualProgramReport
'---------------------------------------------------------------------------------------

Public Sub MBOAnnualProgramReport(ByVal intYear As Integer, ByVal strLocation As String, ByVal strListOfSpecies As String)

10    On Error GoTo Err_label

20    fStatSeasonYearPeriodHasBeenGenerated = False

      ' Years for comparisons

      Dim intYearFirst As Integer
      Dim intYearLast As Integer

30    intYearFirst = 2005
40    intYearLast = intYear

50    If Not fProgramOfficialStartDatesExist(intYearFirst, intYearLast) Then GoTo Exit_label

      ' Word

      Dim wd As Word.Application
      Dim doc As Word.Document

      ' 60    Set wd = New Word.Application

      ' wd.Visible = True

60    Call WordInitialise(wd, doc)

      ' Excel

      Dim oExcel As Excel.Application
      Dim oBook As Excel.Workbook

70    Set oExcel = New Excel.Application

      ' oExcel.Visible = True

80    Set oBook = oExcel.Workbooks.Add

90    Call MBOProgramReport_Initialise(intYearFirst, intYearLast, strLocation, oBook)

      Dim arr_strListOfSpecies() As String

100   If Len(strListOfSpecies) = 0 Then
110       ReDim arr_strListOfSpecies(0 To 0)
120       arr_strListOfSpecies(0) = ""
130   Else
140       arr_strListOfSpecies = Split(strListOfSpecies, " ")     ' indexed from 0
150   End If

      Dim intSpecies As Integer
      Dim strSpecies As String

      '110   For intSpecies = LBound(strListOfSpecies, 1) To UBound(arrListOfSpecies, 1)
      '120       strSpecies = Trim(Nz(strListOfSpecies(intSpecies)))
      '130       If Len(strSpecies) = 4 Then
      '140           If DCount("*", "tblSpecies", "[Species] = '" & strSpecies & "'") = 1 Then
      '150               Call MBOAnnualProgramReportTableA_BCCH(intYear, strLocation, oExcel, oBook, strSpecies)
      '160           End If
      '170       End If
      '180   Next

      Dim strWinter As String
      Dim strSpring As String
      Dim strSummer As String
      Dim strFall As String
      Dim strOwling As String
      Dim strNestbox As String
      '
160   strWinter = strProgram(conWinter, intYear)
170   strSpring = strProgram(conSpring, intYear)
180   strSummer = strProgram(conSummer, intYear)
190   strFall = strProgram(conFall, intYear)
200   strOwling = strProgram(conOwling, intYear)
210   strNestbox = strProgram(conNestbox, intYear)

      Dim fValid As Boolean
      Dim strSQL As String
      Dim fGenerate As Boolean
      Dim strID As String
      Dim rst As DAO.Recordset
      Dim strCaptionHeading As String
      Dim fDebug As Boolean

220   fDebug = False

230   fValid = True

240   strSQL = "SELECT * FROM tblMBOAnnualProgramReport ORDER BY [Order]"
250   Set rst = CurrentDb.OpenRecordset(strSQL, dbOpenDynaset)
260   Do While Not rst.EOF

270       strID = Nz(rst("ID"))
280       fGenerate = Nz(rst("Generate"))
290       strCaptionHeading = Nz(rst("CaptionHeading"), "9.9")
300       If fGenerate Then
310           Select Case strID
              Case "TC"
320               Call MBOProgramReportTC(wd, doc)
330           Case "Other Stats"
340               Call MBOAnnualProgramReportPeriodSeasonAnnual(2005, intYear, strLocation, oExcel, oBook)
350           Case "Season x Year x Day"
360             Call MBOProgramReport_SeasonYearDay(2005, intYear, strLocation, oBook)
370           Case "Season x Year x Period"
380               If Not fStatSeasonYearPeriodHasBeenGenerated Then
390                   Call MBOProgramReport_SeasonYearPeriod_Part_B(2005, intYear, strLocation, oBook)
400                   fStatSeasonYearPeriodHasBeenGenerated = True
410                End If
420           Case "Season x Year x Species"
430               Call MBOProgramReport_SeasonYearSpecies(2005, intYear, strLocation, oBook)
440           Case "New Species"
450               Call MBOProgramReport_NewSpecies(intYear, strLocation, oBook)
460            Case "Recaps"
470               Call MBOProgramReport_Recaps(2005, intYear, strLocation, oBook)
480           Case "Repeats"
490               Call MBOProgramReport_Repeats(2005, intYear, strLocation, oBook)
500           Case "Stopovers"
510               Call MBOProgramReport_Stopovers(2005, intYear, strLocation, oBook)

              ' Winter

520           Case "Winter Summary"
530               If strWinter <> "" Then
540                   If Not fStatSeasonYearPeriodHasBeenGenerated Then
550                       Call MBOProgramReport_SeasonYearPeriod_Part_B(2005, intYear, strLocation, oBook)
560                       fStatSeasonYearPeriodHasBeenGenerated = True
570                   End If
580                   Call MBOAnnualProgramReportTable_Summary(intYear, strLocation, strWinter, "Winter", wd, doc, oExcel, oBook, strCaptionHeading)
590               End If
600           Case "Winter Weather"
610               Call MBOAnnualProgramReport_Weather(intYear, "Winter", wd, doc, strCaptionHeading)
620           Case "Winter Top 10 Banded"
630               If strWinter <> "" Then
640                   Call MBOAnnualProgramReport_Top10SpeciesBanded(fValid, intYear, strLocation, strWinter, "Winter", wd, doc, oExcel, oBook, strCaptionHeading)
650               End If
660           Case "Winter Returns"
670                 If strWinter <> "" Then
680               Call MBOAnnualProgramReportTable3_5(fValid, intYear, strLocation, strWinter, "Winter", wd, doc, oExcel, oBook, strCaptionHeading)
690                 End If

              ' SMMP
              
700           Case "Spring Summary"
710               If strSpring <> "" Then
720                   If Not fStatSeasonYearPeriodHasBeenGenerated Then
730                       Call MBOProgramReport_SeasonYearPeriod_Part_B(2005, intYear, strLocation, oBook)
740                       fStatSeasonYearPeriodHasBeenGenerated = True
750                   End If
760                   Call MBOAnnualProgramReportTable_Summary(intYear, strLocation, strSpring, "Spring", wd, doc, oExcel, oBook, strCaptionHeading)
770               End If
780           Case "Spring Weather"
790               Call MBOAnnualProgramReport_Weather(intYear, "Spring", wd, doc, strCaptionHeading)
800           Case "4_1F"
810               If strSpring <> "" Then
820                   Call MBOAnnualProgramReportFigureBirds(intYear, "Spring", wd, doc)
830                   Call MBOAnnualProgramReport7DayMeanGraph(intYear, strLocation, "Spring", oExcel, oBook, "Banded Birds", fDebug)
840               End If
850           Case "4_2F"
860               If strSpring <> "" Then
870                   Call MBOAnnualProgramReportFigureSpecies(fValid, intYear, strLocation, strSpring, "Spring", wd, doc, oExcel, oBook, "Banded")
880                   Call MBOAnnualProgramReport7DayMeanGraph(intYear, strLocation, "Spring", oExcel, oBook, "Banded Species", fDebug)
890               End If
900           Case "Spring Top 10 Banded"
910               If strSpring <> "" Then
920                   Call MBOAnnualProgramReport_Top10SpeciesBanded(fValid, intYear, strLocation, strSpring, "Spring", wd, doc, oExcel, oBook, strCaptionHeading)
930               End If
940           Case "Spring Top 10 Repeats"
950               If strSpring <> "" Then
960                   Call MBOAnnualProgramReportTable4_3(fValid, intYear, strLocation, strSpring, "Spring", wd, doc, oExcel, oBook, strCaptionHeading)
970               End If
980           Case "Spring Returns"
990               If strSpring <> "" Then
1000                  Call MBOAnnualProgramReportTable3_5(fValid, intYear, strLocation, strSpring, "Spring", wd, doc, oExcel, oBook, strCaptionHeading)
1010              End If
1020          Case "4_3F"
1030              If strSpring <> "" Then
1040                  Call MBOAnnualProgramReportFigureSpecies(fValid, intYear, strLocation, strSpring, "Spring", wd, doc, oExcel, oBook, "Census")
1050                  Call MBOAnnualProgramReport7DayMeanGraph(intYear, strLocation, "Spring", oExcel, oBook, "Census Species", fDebug)
1060              End If
1070          Case "Spring Census Only Species"
1080              If strSpring <> "" Then
1090                  Call MBOAnnualProgramReportCensusOnlySpecies(intYear, strLocation, strSpring, "Spring", oExcel, oBook)
1100              End If
1110          Case "4_4F"
1120              If strSpring <> "" Then
1130                  Call MBOAnnualProgramReportFigureSpecies(fValid, intYear, strLocation, strSpring, "Spring", wd, doc, oExcel, oBook, "DET")
1140                  Call MBOAnnualProgramReport7DayMeanGraph(intYear, strLocation, "Spring", oExcel, oBook, "DET Species", fDebug)
1150              End If
1160           Case "Spring DET All Periods"
1170              If strSpring <> "" Then
1180                  Call MBOAnnualProgramReportDETAllPeriods(intYear, strLocation, "Spring", oExcel, oBook)
1190              End If
1200           Case "Spring DETDays Count"
1210              If strSpring <> "" Then
1220                  Call MBOAnnualProgramReportDETDaysCount(intYear, strLocation, "Spring", oExcel, oBook)
1230              End If
1240          Case "Spring Priority Species"
1250              If strSpring <> "" Then
1260                  Call MBOAnnualProgramReportTable4_5(fValid, intYear, strLocation, strSpring, "Spring", wd, doc, oExcel, oBook, strCaptionHeading)
1270              End If
1280          Case "Spring Net Usage"
1290              If strSpring <> "" Then
1300                  Call MBOAnnualProgramReport_NetUsage(fValid, intYear, strLocation, strSpring, "Spring", wd, doc, oExcel, oBook, strCaptionHeading)
1310              End If

              ' Summer

1320          Case "Summer Summary"
1330              If strSummer <> "" Then
1340                  If Not fStatSeasonYearPeriodHasBeenGenerated Then
1350                      Call MBOProgramReport_SeasonYearPeriod_Part_B(2005, intYear, strLocation, oBook)
1360                      fStatSeasonYearPeriodHasBeenGenerated = True
1370                  End If
1380                  Call MBOAnnualProgramReportTable_Summary(intYear, strLocation, strSummer, "Summer", wd, doc, oExcel, oBook, strCaptionHeading)
1390              End If
1400          Case "Summer Weather"
1410              Call MBOAnnualProgramReport_Weather(intYear, "Summer", wd, doc, strCaptionHeading)
      '        Case "Summer Individuals Banded"
      '             If strSummer <> "" Then
      '                Call MBOProgramReportMeanGraph(2005, intYear, strLocation, "Summer", oExcel, oBook, "Banded Birds", fDebug, 7)
      '            End If
      '        Case "Summer Species Banded"
      '            If strSummer <> "" Then
      '                Call MBOProgramReportMeanGraph(2005, intYear, strLocation, "Summer", oExcel, oBook, "Banded Species", fDebug, 7)
      '            End If
1420          Case "Summer Top 10 Banded"
1430              If strSummer <> "" Then
1440                  Call MBOAnnualProgramReport_Top10SpeciesBanded(fValid, intYear, strLocation, strSummer, "Summer", wd, doc, oExcel, oBook, strCaptionHeading)
1450              End If
      '        Case "Summer SpeciesObserved"
      '            If strSummer <> "" Then
      '                Call MBOProgramReportMeanGraph(2005, intYear, strLocation, "Summer", oExcel, oBook, "DET Species", fDebug, 7)
      '            End If
1460          Case "Summer Returns"
1470              If strSummer <> "" Then
1480                  Call MBOAnnualProgramReportTable3_5(fValid, intYear, strLocation, strSummer, "Summer", wd, doc, oExcel, oBook, strCaptionHeading)
1490              End If


              ' Nestbox

1500          Case "Nestbox Summary"
1510              If strNestbox <> "" Then
1520                  If Not fStatSeasonYearPeriodHasBeenGenerated Then
1530                      Call MBOProgramReport_SeasonYearPeriod_Part_B(2005, intYear, strLocation, oBook)
1540                      fStatSeasonYearPeriodHasBeenGenerated = True
1550                  End If
1560                  Call MBOAnnualProgramReportTable_Summary(intYear, strLocation, strNestbox, "Nestbox", wd, doc, oExcel, oBook, strCaptionHeading)
1570              End If

              ' FMMP

1580          Case "Fall Summary"
1590              If strFall <> "" Then
1600                  If Not fStatSeasonYearPeriodHasBeenGenerated Then
1610                      Call MBOProgramReport_SeasonYearPeriod_Part_B(2005, intYear, strLocation, oBook)
1620                      fStatSeasonYearPeriodHasBeenGenerated = True
1630                  End If
1640                  Call MBOAnnualProgramReportTable_Summary(intYear, strLocation, strFall, "Fall", wd, doc, oExcel, oBook, strCaptionHeading)
1650              End If
1660          Case "Fall Weather"
1670              Call MBOAnnualProgramReport_Weather(intYear, "Fall", wd, doc, strCaptionHeading)
1680          Case "6_1F"
1690              If strFall <> "" Then
1700                 Call MBOAnnualProgramReportFigureBirds(intYear, "Fall", wd, doc)
1710                 Call MBOAnnualProgramReport7DayMeanGraph(intYear, strLocation, "Fall", oExcel, oBook, "Banded Birds", fDebug)
1720              End If
1730          Case "6_2F"
1740              If strFall <> "" Then
1750                  Call MBOAnnualProgramReportFigureSpecies(fValid, intYear, strLocation, strFall, "Fall", wd, doc, oExcel, oBook, "Banded")
1760                  Call MBOAnnualProgramReport7DayMeanGraph(intYear, strLocation, "Fall", oExcel, oBook, "Banded Species", fDebug)
1770              End If
1780          Case "Fall Top 10 Banded"
1790                If strFall <> "" Then
1800                    Call MBOAnnualProgramReport_Top10SpeciesBanded(fValid, intYear, strLocation, strFall, "Fall", wd, doc, oExcel, oBook, strCaptionHeading)
1810                End If
1820          Case "Fall Top 10 Repeats"
1830                If strFall <> "" Then
1840                    Call MBOAnnualProgramReportTable4_3(fValid, intYear, strLocation, strFall, "Fall", wd, doc, oExcel, oBook, strCaptionHeading)
1850                End If
1860          Case "Fall Returns"
1870                If strSpring <> "" Then
1880                    Call MBOAnnualProgramReportTable3_5(fValid, intYear, strLocation, strFall, "Fall", wd, doc, oExcel, oBook, strCaptionHeading)
1890                End If

1900          Case "6_4"
1910                If strFall <> "" Then
1920                    Call MBOAnnualProgramReportTable3_5(fValid, intYear, strLocation, strFall, "Fall", wd, doc, oExcel, oBook, strCaptionHeading)

1930                End If
1940          Case "Fall Census Only Species"
1950                If strFall <> "" Then
1960                    Call MBOAnnualProgramReportCensusOnlySpecies(intYear, strLocation, strFall, "Fall", oExcel, oBook)
1970                End If
1980          Case "6_3F"
1990                If strFall <> "" Then
2000                      Call MBOAnnualProgramReportFigureSpecies(fValid, intYear, strLocation, strFall, "Fall", wd, doc, oExcel, oBook, "Census")
2010                      Call MBOAnnualProgramReport7DayMeanGraph(intYear, strLocation, "Fall", oExcel, oBook, "Census Species", fDebug)
2020                End If
2030          Case "6_4F"
2040                If strFall <> "" Then
2050                      Call MBOAnnualProgramReportFigureSpecies(fValid, intYear, strLocation, strFall, "Fall", wd, doc, oExcel, oBook, "DET")
2060                      Call MBOAnnualProgramReport7DayMeanGraph(intYear, strLocation, "Fall", oExcel, oBook, "DET Species", fDebug)
2070                End If
2080          Case "Fall DET All Periods"
2090                If strFall <> "" Then
2100                    Call MBOAnnualProgramReportDETAllPeriods(intYear, strLocation, "Fall", oExcel, oBook)
2110                End If
2120          Case "Fall DETDays Count"
2130                  If strFall <> "" Then
2140                      Call MBOAnnualProgramReportDETDaysCount(intYear, strLocation, "Fall", oExcel, oBook)
2150                  End If
2160          Case "Fall Priority Species"
2170                If strFall <> "" Then
2180                    Call MBOAnnualProgramReportTable4_5(fValid, intYear, strLocation, strFall, "Fall", wd, doc, oExcel, oBook, strCaptionHeading)
2190                End If
2200          Case "Fall Net Usage"
2210                If strFall <> "" Then
2220                    Call MBOAnnualProgramReport_NetUsage(fValid, intYear, strLocation, strFall, "Fall", wd, doc, oExcel, oBook, strCaptionHeading)
2230                End If

              ' Owling

2240          Case "Owling Summary"
2250              If strOwling <> "" Then
2260                  If Not fStatSeasonYearPeriodHasBeenGenerated Then
2270                      Call MBOProgramReport_SeasonYearPeriod_Part_B(2005, intYear, strLocation, oBook)
2280                      fStatSeasonYearPeriodHasBeenGenerated = True
2290                  End If
2300                  Call MBOAnnualProgramReportTable_Summary(intYear, strLocation, strOwling, "Owling", wd, doc, oExcel, oBook, strCaptionHeading)
2310              End If
2320          Case "Owling Weather"
2330              Call MBOAnnualProgramReport_Weather(intYear, "Owling", wd, doc, strCaptionHeading)
2340          Case "NSWO Age Sex"
2350              If strOwling <> "" Then
2360                  Call MBOAnnualProgramReport_NSWO_Age_Sex(intYear, strLocation, oExcel, oBook)
2370              End If

2380          Case "7_3"
2390              If strOwling <> "" Then
2400                  Call MBOAnnualProgramReportTable7_3(fValid, intYear, strLocation, strOwling, "Owling", wd, doc, oExcel, oBook, strCaptionHeading)
2410              End If
2420          Case "7_4"
2430              Call MBOAnnualProgramReport7_4(intYear, wd, doc, oExcel, oBook, strCaptionHeading)
2440          Case "Owling Net Usage"
2450              If strOwling <> "" Then
2460                  Call MBOAnnualProgramReport_NetUsage(fValid, intYear, strLocation, strOwling, "Owling", wd, doc, oExcel, oBook, strCaptionHeading)
2470              End If
2480          Case "A"
2490              Call MBOAnnualProgramReportTableA(fValid, intYear, strLocation, strSpring, strFall, wd, doc, oExcel, oBook, arr_strListOfSpecies)
2500          Case "A RTHU"
2510              Call MBOAnnualProgramReportTableA(fValid, intYear, strLocation, strSpring, strFall, wd, doc, oExcel, oBook, arr_strListOfSpecies, "RTHU")
2520          Case "A Owling"
2530              Call MBOAnnualProgramReportTableA(fValid, intYear, strLocation, strSpring, strFall, wd, doc, oExcel, oBook, arr_strListOfSpecies, "Owling")
2540          End Select
2550      End If
2560      rst.MoveNext
2570  Loop
2580  rst.Close
2590  Set rst = Nothing



2600  Call wordFinalise(wd, doc)

      '2450  wd.Options.CheckGrammarAsYouType = fCheckGrammarAsYouTypeSave
      '2460  wd.Options.CheckSpellingAsYouType = fCheckSpellingAsYouTypeSave

      ' Save the Word document

      Dim strSaveFilename As String
      Dim strSaveFilepath As String
2610  strSaveFilename = _
          "MBO Annual Program Report " & intYear
2620  Call SaveAndCloseWordDocument(wd, doc, strSaveFilename, fValid:=True, strSaveFilepath:=strSaveFilepath)

2630  Set doc = Nothing
2640  wd.Quit
2650  Set wd = Nothing

2660  On Error Resume Next
2670  Call ExcelDeleteAllButFirstWorksheet(oBook)
2690  oBook.Sheets("Sheet1").Delete
2700  On Error GoTo Err_label

2710  Call DeleteEndOfSeasonSheets(oExcel, oBook)

      ' Save the Excel Workbook
      '     Dim strSaveFilepath As String
2720  fValid = True

2730  Call SaveAndCloseExcelWorkbook(oExcel, oBook, strSaveFilename, fValid, strSaveFilepath)


2740  Set oBook = Nothing
2750  oExcel.Quit
2760  Set oExcel = Nothing

2770  Call OpenExcelWorkbook(strSaveFilepath)


      'DD Error Handler Start
Exit_label:

2780  On Error Resume Next
2790  wd.Quit
2800  Set wd = Nothing

2810       Exit Sub
Err_label:
2820      Select Case Err.Number
          Case Else
2830    Call LogError("basMBOAnnualProgramReport", "MBOAnnualProgramReport")
2840       End Select
2850       Resume Exit_label
      'DD Error Handler End

End Sub




'---------------------------------------------------------------------------------------
' MBOAnnualProgramReport_Weather
'---------------------------------------------------------------------------------------

Public Sub MBOAnnualProgramReport_Weather( _
    ByVal intYear As Integer, _
    ByVal strSeason As String, _
    ByRef wd As Word.Application, _
    ByRef doc As Word.Document, _
    ByVal strTableCaptionHeading As String)

      Dim range As Word.range

10    On Error GoTo Err_label

20    Set range = MoveInsertionPointToEndOfDocument(wd, doc)
30    range.InsertParagraphAfter

40    Select Case strSeason
      Case "Winter"
          Dim strYearsWinter As String
50        strYearsWinter = intYear - 1 & "-" & intYear
60        Call InsertTableCaptionXX(wd, doc, "Table", _
            strTableCaptionHeading, _
            "Weather conditions during the " & strYearsWinter & " winter population monitoring program, by month.", _
            "Weather conditions during the " & strYearsWinter & " winter population monitoring program, by month")
70    Case "Spring"
80        Call InsertTableCaptionXX(wd, doc, "Table", _
            strTableCaptionHeading, _
            "Weather conditions during the " & intYear & " SMMP, by week.", _
            "Weather conditions during the " & intYear & " SMMP, by week")
90    Case "Summer"
100       Call InsertTableCaptionXX(wd, doc, "Table", _
            strTableCaptionHeading, _
            "Weather conditions during the " & intYear & " MAPS program, by week.", _
            "Weather conditions during the " & intYear & " MAPS program, by week")
110   Case "Fall"
120       Call InsertTableCaptionXX(wd, doc, "Table", _
            strTableCaptionHeading, _
            "Weather conditions during the " & intYear & " FMMP, by week.", _
            "Weather conditions during the " & intYear & " FMMP, by week")
130   Case "Owling"
140       Call InsertTableCaptionXX(wd, doc, "Table", _
            strTableCaptionHeading, _
            "Weather conditions during the " & intYear & " Northern Saw-whet Owl Monitoring Program, by week.", _
            "Weather conditions during the " & intYear & " Northern Saw-whet Owl Monitoring Program, by week")
150   End Select

160   Set range = MoveInsertionPointToEndOfDocument(wd, doc)
170   range.InsertParagraphAfter


'DD Error Handler Start
Exit_label:
180        Exit Sub
Err_label:
190        Select Case Err.Number
     Case Else
200       Call LogError("basMBOAnnualProgramReport", "MBOAnnualProgramReport_Weather")
210        End Select
220        Resume Exit_label
'DD Error Handler End

    End Sub

'---------------------------------------------------------------------------------------
' FormatWordTableRowAsHeader
'---------------------------------------------------------------------------------------

Public Sub FormatWordTableRowAsHeader(ByRef row As Word.row, Optional ByVal strStyle As String = "ddHeaderRow")

10    On Error GoTo Err_label

20        row.range.Style = strStyle
30        row.Shading.BackgroundPatternColor = vbBlack
40        row.HeadingFormat = True
50        row.range.ParagraphFormat.KeepWithNext = True

      'DD Error Handler Start
Exit_label:
60         Exit Sub
Err_label:
70         Select Case Err.Number
           Case Else
80        Call LogError("basMBOAnnualProgramReport", "FormatWordTableRowAsHeader")
90         End Select
100        Resume Exit_label
      'DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' toPeriodMBOAnnualReport
'---------------------------------------------------------------------------------------

Public Function toPeriodMBOAnnualReport(ByVal strSeason As String, datDateEx As Date) As Integer

10    On Error GoTo Err_label

      Dim datDay   As Date
      Dim toPeriod As Integer

20    datDay = DateSerial(2000, Month(datDateEx), Day(datDateEx))

30    Select Case strSeason
      Case "Winter"
40        Select Case Month(datDateEx)
          Case 7 To 11                          ' Jul - Nov
50            toPeriod = 1
60        Case 12
70            toPeriod = 2                      ' Dec
80        Case 1 To 3
90            toPeriod = 2 + Month(datDateEx)   ' Jan, Feb, Mar
100       Case Else
110           toPeriod = 5                      ' Apr - Jun
120       End Select
130   Case "Spring"
140       toPeriod = Int((datDay - DateSerial(2000, 3, 28)) / 7) + 1
150       If toPeriod < 1 Then
160           toPeriod = 1
170       End If
180   Case "Summer", "Nestbox"

      ' Include 2009-08-04 in period 2
      ' Include 2012-05-05 in period 1

190       Select Case Month(datDateEx)
          Case 1 To 6
200           toPeriod = 1
210       Case 7 To 12
220           toPeriod = 2
230       Case Else
240           toPeriod = 1
250       End Select
260   Case "Fall"
270       toPeriod = Int((datDay - DateSerial(2000, 8, 1)) / 7) + 1
280       If toPeriod < 1 Then
290           toPeriod = 1
300       End If
310   Case "Owling"
320       If datDay < DateSerial(2000, 9, 26) Or datDay > DateSerial(2000, 11, 20) Then
330           toPeriod = 0
340       Else
350           toPeriod = Int((datDay - DateSerial(2000, 9, 26)) / 7) + 1
360       End If
370   Case Else           ' includes "NonSeason"
380       toPeriod = 1
390   End Select

400   toPeriodMBOAnnualReport = toPeriod

      'DD Error Handler Start
Exit_label:
410        Exit Function
Err_label:
420        Select Case Err.Number
           Case Else
430       Call LogError("basMBOAnnualProgramReport", "toPeriodMBOAnnualReport")
440        End Select
450        Resume Exit_label
      'DD Error Handler End

End Function
