'---------------------------------------------------------------------------------------
' Module    : basMBO10YearProgramReportSummary
' Author    : David Davey
'---------------------------------------------------------------------------------------

Option Compare Database
Option Explicit

' Statistics

' NB For Owling "days banding" means "nights banding"

Const conBirdsBanded As Integer = 0
Const conSpeciesBanded As Integer = 1
Const conBirdsReturns As Integer = 2
Const conSpeciesReturns As Integer = 3
Const conBirdsForeign As Integer = 4
Const conSpeciesForeign As Integer = 5
Const conBirdsRepeats As Integer = 6
Const conSpeciesRepeats As Integer = 7
Const conSpeciesDET As Integer = 8
Const conNetHours As Integer = 9
Const conBirdsPer100NetHours As Integer = 10
Const conDaysOperating As Integer = 11
Const conDaysBanding As Integer = 12
Const conDaysFullCoverage As Integer = 13
Const conStatLast As Integer = 13

Const conDET As Integer = 0
Const conBND As Integer = 1
Const conRET As Integer = 2
Const conREP As Integer = 3
Const conFRN As Integer = 4

Private dblStat() As Double                         ' stat x year
Private dicSpecies() As Scripting.Dictionary        ' stat x year

Private intCount(conStatLast) As Integer
Private dblTotal(conStatLast) As Double
Private dblAverage(conStatLast) As Double
Private dicSpeciesCumulative(conStatLast) As Scripting.Dictionary

'---------------------------------------------------------------------------------------
' MBO10YearProgramReportSummary
'---------------------------------------------------------------------------------------
'                              ============== row =============
'                              Spring+Fall Winter+Summer Owling
' # individuals banded       2        2          2           2
' # species banded           2        2          2           2
' # individuals return       3        3          3
' # species return           3        3          3
' # individuals repeat       4        4          4           3
' # species repeat           4        4          4           3
' # individuals foreign      5                               4
' # species foreign          5                               4
' # species observed (DET)   6        5          5
' # net hours                7        6          6           5
' # birds / 100 net hours    8        7          7           6
' # days operating           9        8          8
' # days (nights) banding   10        9          9           7
' # days with full coverage 11       10

 Public Sub MBO10YearProgramReportSummary( _
    ByRef fValid As Boolean, _
    ByVal intYearFirst As Integer, _
    ByVal intYearLast As Integer, _
    ByVal strLocation As String, _
    ByVal strSeason As String, _
    ByRef wd As Word.Application, _
    ByRef doc As Word.Document, _
    ByRef oExcel As Excel.Application, _
    ByRef oBook As Excel.Workbook)
           

10    On Error GoTo Err_label

      '    wd.Visible = True

      ' --------------------------------------
      ' Compute Information
      ' --------------------------------------

20    ReDim dblStat(conStatLast, intYearFirst To intYearLast) As Double

      Dim stat As Integer       ' 0 To conStatLast
      Dim Y As Integer          ' intYearFirst To intYearLast
      Dim fld As Integer        ' conDET To conFRN

30    For stat = 0 To conStatLast
40        For Y = intYearFirst To intYearLast
50            dblStat(stat, Y) = 0
60        Next
70    Next

      ' Birds Banded, Returns, Repeats, Foreign

      Dim qdf As QueryDef
80    Set qdf = CurrentDb.QueryDefs("qryMBO10YearProgramReportSummary")
90    qdf.Parameters("argSeason").value = strSeason
100   qdf.Parameters("argLocation").value = strLocation
110   qdf.Parameters("argYearFirst").value = intYearFirst
120   qdf.Parameters("argYearLast").value = intYearLast
      Dim rst As DAO.Recordset
130   Set rst = qdf.OpenRecordset

140   Do While Not rst.EOF
150       Y = Nz(rst("YearEx"))
160       dblStat(conBirdsBanded, Y) = Nz(rst("BirdsBanded"))
170       dblStat(conBirdsReturns, Y) = Nz(rst("BirdsReturns"))
180       dblStat(conBirdsRepeats, Y) = Nz(rst("BirdsRepeats"))
190       dblStat(conBirdsForeign, Y) = Nz(rst("BirdsForeign"))
200       rst.MoveNext
210   Loop
220   rst.Close
230   Set rst = Nothing

      ' Species DET, banded, Returns, Repeats

240   ReDim dicSpecies(conDET To conFRN, intYearFirst To intYearLast) As Scripting.Dictionary

250   For fld = conDET To conFRN
260       For Y = intYearFirst To intYearLast
270           Set dicSpecies(fld, Y) = New Scripting.Dictionary
280       Next
290       Set dicSpeciesCumulative(fld) = New Scripting.Dictionary
300   Next

      Dim strSQL As String
      Dim strFieldname As String
      Dim strSpecies As String
                
      ' fld x year

310   For fld = conDET To conFRN
320       strFieldname = toFieldnameFLD(fld)
          
330       strSQL = "qryMBO10YearProgramReportSummary_Species_" & strFieldname
340       Set qdf = CurrentDb.QueryDefs(strSQL)
350       qdf.Parameters("argSeason").value = strSeason
360       qdf.Parameters("argLocation").value = strLocation
370       qdf.Parameters("argYearFirst").value = intYearFirst
380       qdf.Parameters("argYearLast").value = intYearLast
390       Set rst = qdf.OpenRecordset
          
400       Do While Not rst.EOF
              
410             strSpecies = Nz(rst("Species"))
420             Y = Nz(rst("YearEx"))
                
430             If Not dicSpecies(fld, Y).Exists(strSpecies) Then
440                 Call dicSpecies(fld, Y).Add(strSpecies, strSpecies)
450             End If
             
460           rst.MoveNext
470       Loop
480       rst.Close
490       Set rst = Nothing
500   Next

      ' fld (all years)

510   For fld = conDET To conFRN
520       strFieldname = toFieldnameFLD(fld)
          
530       strSQL = "qryMBO10YearProgramReportSummary_Species_" & strFieldname & "_AllYears"
540       Set qdf = CurrentDb.QueryDefs(strSQL)
550       qdf.Parameters("argSeason").value = strSeason
560       qdf.Parameters("argLocation").value = strLocation
570       qdf.Parameters("argYearFirst").value = intYearFirst
580       qdf.Parameters("argYearLast").value = intYearLast
590       Set rst = qdf.OpenRecordset
          
600       Do While Not rst.EOF
              
610             strSpecies = Nz(rst("Species"))
               
620             If Not dicSpeciesCumulative(fld).Exists(strSpecies) Then
630                 Call dicSpeciesCumulative(fld).Add(strSpecies, strSpecies)
640             End If
              
650           rst.MoveNext
660       Loop
670       rst.Close
680       Set rst = Nothing
690   Next

      ' Process each fld x year

      ' Count true species

700       For Y = intYearFirst To intYearLast
710           dblStat(conSpeciesDET, Y) = CountSpeciesInDictionary(dicSpecies(conDET, Y))
720           dblStat(conSpeciesBanded, Y) = CountSpeciesInDictionary(dicSpecies(conBND, Y))
730           dblStat(conSpeciesReturns, Y) = CountSpeciesInDictionary(dicSpecies(conRET, Y))
740           dblStat(conSpeciesRepeats, Y) = CountSpeciesInDictionary(dicSpecies(conREP, Y))
750           dblStat(conSpeciesForeign, Y) = CountSpeciesInDictionary(dicSpecies(conFRN, Y))
760       Next

      ' Net Hours

770   Set qdf = CurrentDb.QueryDefs("qryMBO10YearProgramReportSummary_NetHours")
780   qdf.Parameters("argSeason").value = strSeason
790   qdf.Parameters("argLocation").value = strLocation
800   qdf.Parameters("argYearFirst").value = intYearFirst
810   qdf.Parameters("argYearLast").value = intYearLast
820   Set rst = qdf.OpenRecordset

830   Do While Not rst.EOF
840       Y = Nz(rst("YearEx"))
850       dblStat(conNetHours, Y) = Nz(rst("NetHours"))
860       rst.MoveNext
870   Loop
880   rst.Close
890   Set rst = Nothing

      ' Number of days operating
      ' (number of days with total DET > 0 or Net Hours > 0)

      ' qryMBO10YearProgramReportSummary_DaysOperating_A
      ' ------------------------------------------------
      ' tblDETSpecies x tblPrograms
      ' Location = [argLocation]
      ' MonitoringProgramSeason = [argSeason]
      ' YearEx BETWEEN [argYearFirst] AND argYearLast]
      ' GROUP BY YearEx, DateEx
      ' WHERE DET > 0
      ' Report YearEx, DateEx

      ' qryMBO10YearProgramReportSummary_DaysOperating_B
      ' ------------------------------------------------
      ' List of days for which Net Hours > 0
      ' ------------------------------------------------
      ' tblDETDaily x tblPrograms
      ' Location = [argLocation]
      ' MonitoringProgramSeason = [argSeason]
      ' YearEx BETWEEN [argYearFirst] AND argYearLast]
      ' GROUP BY YearEx
      ' WHERE SongBIrdHours > 0
      ' Report YearEx, DateEx

      ' qryMBO10YearProgramReportSummary_DaysOperating_C
      ' ------------------------------------------------
      ' qryMBO10YearProgramReportSummary_DaysOperating_A
      ' UNION
      ' qryMBO10YearProgramReportSummary_DaysOperating_B
        
      ' qryMBO10YearProgramReportSummary_DaysOperating_Summary
      ' ------------------------------------------------------
      ' qryMBO10YearProgramReportSummary_DaysOperating_C
      ' GROUP BY YearEx
      ' Report YearEx, count records


900   Set qdf = CurrentDb.QueryDefs("qryMBO10YearProgramReportSummary_DaysOperating_Summary")
910   qdf.Parameters("argSeason").value = strSeason
920   qdf.Parameters("argLocation").value = strLocation
930   qdf.Parameters("argYearFirst").value = intYearFirst
940   qdf.Parameters("argYearLast").value = intYearLast
950   Set rst = qdf.OpenRecordset

      Dim intCountDaysOperating As Integer
960   Do While Not rst.EOF
970       Y = Nz(rst("YearEx"))
980       intCountDaysOperating = Nz(rst("CountDaysOperating"))
990       If intCountDaysOperating = 0 Then
1000          intCountDaysOperating = -1
1010      End If
1020      dblStat(conDaysOperating, Y) = intCountDaysOperating
1030      rst.MoveNext
1040  Loop
1050  rst.Close
1060  Set rst = Nothing

      ' Number of days banding
      ' (number of days with Net Hours > 0)

      ' qryMBO10YearProgramReportSummary_DaysBanding
      ' --------------------------------------------
      ' tblDETDaily x tblPrograms
      ' Location = [argLocation]
      ' MonitoringProgramSeason = [argSeason]
      ' YearEx BETWEEN [argYearFirst] AND argYearLast]
      ' GROUP BY YearEx
      ' Report YearEx, count records

1070  Set qdf = CurrentDb.QueryDefs("qryMBO10YearProgramReportSummary_DaysBanding")
1080  qdf.Parameters("argSeason").value = strSeason
1090  qdf.Parameters("argLocation").value = strLocation
1100  qdf.Parameters("argYearFirst").value = intYearFirst
1110  qdf.Parameters("argYearLast").value = intYearLast
1120  Set rst = qdf.OpenRecordset

1130  Do While Not rst.EOF
1140      Y = Nz(rst("YearEx"))
1150      dblStat(conDaysBanding, Y) = Nz(rst("CountDaysBanding"))
1160      rst.MoveNext
1170  Loop
1180  rst.Close
1190  Set rst = Nothing

      ' Number of days with full coverage
      ' (number of days with Net Hours  >= FullNetCoverage(strSeason,intYear)

      ' qryMBO10YearProgramReportSummary_DaysFullCoverage
      ' -------------------------------------------------
      ' tblDETDaily x tblPrograms
      ' Season = [argSeason]
      ' Location = [argLocation]
      ' YearEx between [argYearsFirst] and [argYearLast]
      ' Group by YearEx
      ' Where SongbirdNets =FullNetCoverage([YearEx],[argSeason])
      ' Count DatEx (count the days)

1200  Set qdf = CurrentDb.QueryDefs("qryMBO10YearProgramReportSummary_DaysFullCoverage")
1210  qdf.Parameters("argSeason").value = strSeason
1220  qdf.Parameters("argLocation").value = strLocation
1230  qdf.Parameters("argYearFirst").value = intYearFirst
1240  qdf.Parameters("argYearLast").value = intYearLast
1250  Set rst = qdf.OpenRecordset

1260  Do While Not rst.EOF
1270      Y = Nz(rst("YearEx"))
1280      dblStat(conDaysFullCoverage, Y) = Nz(rst("CountDaysFullCoverage"))
1290      rst.MoveNext
1300  Loop
1310  rst.Close
1320  Set rst = Nothing

      ' Number of days census only
      ' (number of days with total census > 0 and total DET = 0 and Net Hours = 0)

      ' qryMBO10YearProgramReportSummary_CensusOnly_A
      ' ------------------------------------------------
      ' tblDETSpecies x tblPrograms
      ' Location = [argLocation]
      ' MonitoringProgramSeason = [argSeason]
      ' YearEx BETWEEN [argYearFirst] AND argYearLast]
      ' GROUP BY YearEx, DateEx
      ' HAVING Sum DET = 0 AND Sum CNS > 0
      ' Report YearEx, DateEx

      ' qryMBO10YearProgramReportSummary_CensusOnly_B
      ' ------------------------------------------------
      ' List of days for which sum CNS > 0 AND Sum DET = 0 less the days for which Net Hours > 0
      ' ------------------------------------------------
      ' qryMBO10YearProgramReportSummary_CensusOnly_A
      ' qryMBO10YearProgramReportSummary_DaysOperating_B
      ' Left outer join on DateEx
      ' qryMBO10YearProgramReportSummary_DaysOperating_B.DateEx Is Null
      ' List YearEx, DateEx

      ' qryMBO10YearProgramReportSummary_CensusOnly_C
      ' ------------------------------------------------------
      ' qryMBO10YearProgramReportSummary_CensusOnly_B
      ' GROUP BY YearEx
      ' Report YearEx, count records

      'Set qdf = CurrentDb.QueryDefs("qryMBO10YearProgramReportSummary_CensusOnly_C")
      'qdf.Parameters("argSeason").value = strSeason
      'qdf.Parameters("argLocation").value = strLocation
      'qdf.Parameters("argYearFirst").value = intYearFirst
      'qdf.Parameters("argYearLast").value = intYearLast
      'Set rst = qdf.OpenRecordset
      '
      'Do While Not rst.EOF
      '    y = Nz(rst("YearEx"))
      '    dblStat(conDaysCensusOnly, y) = Nz(rst("CountDaysCensusOnly"))
      '    rst.MoveNext
      'Loop
      'rst.Close
      'Set rst = Nothing

      ' Birds per 100 Net Hours

1330  For Y = intYearFirst To intYearLast
1340      If dblStat(conNetHours, Y) > 0 Then
1350          dblStat(conBirdsPer100NetHours, Y) = _
                  Round(100 * dblStat(conBirdsBanded, Y) / dblStat(conNetHours, Y), 1)
1360      End If
1370  Next

      ' Counts, Totals and Averages

      ' This  is tricky ...
      ' The total for # individuals banded, return, or repeat is the sum of the annual stats
      ' The total for # species banded, return, or repeat is NOT the sum of the annual stats
      ' The total for # species observed is NOT the sum of the annual stats
      ' The total for # net hours is the sum of the annual stats
      ' The total for # birds / 100 net hours is NOT the sum of the annual stats
      '               it is 100* the Total # individuals banded / total # net hours
      ' The total for # days operating and # days banding is the sum of the annual stats

      ' the average for # individuals banded, return, repeat, # species banded, return, repeat,
      '                 # net hours, # birds / 100 net hours are the totals divided by the number of years with # days banding > 0
      ' the average for # species observed is the totals divided by the number of years with # days operating > 0
      ' the average for # days operating and # days banding is the total / number of years

      ' NB In the following we first total the # birds / 100 net hours
      ' this isn't the correct total, but the need it to calculate the average
      ' We will calculate the correct total # birds / 100 net hours later

      ' Start by calculating the raw totals for everything
      ' We need these to calculate the averages

      Dim dblTotalTemp As Double

1380  For stat = 0 To conStatLast
1390      dblTotalTemp = 0
1400      For Y = intYearFirst To intYearLast
1410          dblTotalTemp = dblTotalTemp + dblStat(stat, Y)
1420      Next
1430      dblTotal(stat) = dblTotalTemp
1440  Next

      ' Now for the averages
      ' Some averages are over all years,
      ' Some over just banding years and
      ' Some over just DET years

      Dim countYearsBanding As Integer
      Dim countYearsOperating As Integer
      Dim countYears As Integer

1450  countYears = intYearLast - intYearFirst + 1

1460  countYearsBanding = 0
1470  countYearsOperating = 0
1480  For Y = intYearFirst To intYearLast
1490      If dblStat(conDaysBanding, Y) > 0 Then
1500        countYearsBanding = countYearsBanding + 1
1510      End If
1520      If dblStat(conDaysOperating, Y) > 0 Then
1530        countYearsOperating = countYearsOperating + 1
1540      End If
1550  Next

1560  For stat = 0 To conStatLast
1570      Select Case stat
          Case conBirdsBanded, conBirdsReturns, conBirdsRepeats, _
              conSpeciesBanded, conSpeciesReturns, conSpeciesRepeats, _
              conNetHours, conBirdsPer100NetHours, _
              conBirdsForeign, conSpeciesForeign
1580          intCount(stat) = countYearsBanding
1590      Case conSpeciesDET
1600          intCount(stat) = countYearsOperating
1610      Case conDaysOperating, conDaysBanding, conDaysFullCoverage
1620          intCount(stat) = countYears
1630      End Select
          
1640      If intCount(stat) <> 0 Then
1650          dblAverage(stat) = dblTotal(stat) / intCount(stat)
1660      Else
1670          dblAverage(stat) = 0
1680      End If
1690  Next
       
       ' Its time to calculate the real totals for # species banded, return, repeat, foreign and observed
       ' We already have the scripting dictionaries
                                
            ' Count true species
            
1700        dblTotal(conSpeciesDET) = CountSpeciesInDictionary(dicSpeciesCumulative(conDET))
1710        dblTotal(conSpeciesBanded) = CountSpeciesInDictionary(dicSpeciesCumulative(conBND))
1720        dblTotal(conSpeciesReturns) = CountSpeciesInDictionary(dicSpeciesCumulative(conRET))
1730        dblTotal(conSpeciesRepeats) = CountSpeciesInDictionary(dicSpeciesCumulative(conREP))
1740        dblTotal(conSpeciesForeign) = CountSpeciesInDictionary(dicSpeciesCumulative(conFRN))
            
      ' Correct the total # birds / 100 net hours

1750  If dblTotal(conNetHours) > 0 Then
1760      dblTotal(conBirdsPer100NetHours) = _
        Round(100 * dblTotal(conBirdsBanded) / dblTotal(conNetHours), 1)
1770  Else
1780      dblTotal(conBirdsPer100NetHours) = 0
1790  End If

1800  dblAverage(conBirdsBanded) = Round(dblAverage(conBirdsBanded), 0)
1810  If dblAverage(conSpeciesBanded) >= 4 Then
1820      dblAverage(conSpeciesBanded) = Round(dblAverage(conSpeciesBanded), 0)
1830  Else
1840      dblAverage(conSpeciesBanded) = Round(dblAverage(conSpeciesBanded), 1)
1850  End If
1860  dblAverage(conBirdsReturns) = Round(dblAverage(conBirdsReturns), 0)
1870  If dblAverage(conSpeciesReturns) >= 4 Then
1880      dblAverage(conSpeciesReturns) = Round(dblAverage(conSpeciesReturns), 0)
1890  Else
1900      dblAverage(conSpeciesReturns) = Round(dblAverage(conSpeciesReturns), 1)
1910  End If

1920  dblAverage(conBirdsForeign) = Round(dblAverage(conBirdsForeign), 0)
1930  If dblAverage(conSpeciesForeign) >= 4 Then
1940      dblAverage(conSpeciesForeign) = Round(dblAverage(conSpeciesForeign), 0)
1950  Else
1960      dblAverage(conSpeciesForeign) = Round(dblAverage(conSpeciesForeign), 1)
1970  End If

1980  dblAverage(conBirdsRepeats) = Round(dblAverage(conBirdsRepeats), 0)
1990  If dblAverage(conSpeciesRepeats) >= 4 Then
2000      dblAverage(conSpeciesRepeats) = Round(dblAverage(conSpeciesRepeats), 0)
2010  Else
2020      dblAverage(conSpeciesRepeats) = Round(dblAverage(conSpeciesRepeats), 1)
2030  End If

2040  If dblAverage(conSpeciesDET) >= 4 Then
2050      dblAverage(conSpeciesDET) = Round(dblAverage(conSpeciesDET), 0)
2060  Else
2070      dblAverage(conSpeciesDET) = Round(dblAverage(conSpeciesDET), 0)
2080  End If

2090  dblAverage(conNetHours) = Round(dblAverage(conNetHours), 1)
2100  dblAverage(conBirdsPer100NetHours) = Round(dblAverage(conBirdsPer100NetHours), 1)
2110  dblAverage(conDaysOperating) = Round(dblAverage(conDaysOperating), 1)
2120  dblAverage(conDaysBanding) = Round(dblAverage(conDaysBanding), 1)
2130  dblAverage(conDaysFullCoverage) = Round(dblAverage(conDaysFullCoverage), 1)

      ' --------------------------------------
      ' Output Excel Worksheet + Word Document
      ' --------------------------------------

      Dim oSheet As Excel.Worksheet
2140  Set oSheet = InsertSheet(oBook, strSeason)
2150  oSheet.Name = strSeason & " Summary"
2160  With oSheet

      Dim colLast As Integer
2170  colLast = toCol(intYearLast - intYearFirst)

2180  For Y = intYearFirst To intYearLast
2190      .Cells(1, Y + 2 - intYearFirst) = Y
2200  Next
2210   .Cells(1, colLast + 1) = "Average"
2220   .Cells(1, colLast + 2) = "Total"

2230  Select Case strSeason
      Case "Spring", "Fall"
2240      .Cells(toRow(conBirdsBanded), 1) = "# individuals banded"
2250      .Cells(toRow(conBirdsReturns), 1) = "# individuals return"
2260      .Cells(toRow(conBirdsRepeats), 1) = "# individuals repeat"
2270      .Cells(toRow(conSpeciesDET), 1) = "# species observed"
2280      .Cells(toRow(conSpeciesBanded), 1) = "# species banded"
2290      .Cells(toRow(conSpeciesReturns), 1) = "# species return"
2300      .Cells(toRow(conSpeciesRepeats), 1) = "# species repeat"
2310      .Cells(toRow(conNetHours), 1) = "# net hours"
2320      .Cells(toRow(conDaysOperating), 1) = "# days operating"
2330      .Cells(toRow(conDaysBanding), 1) = "# days banding"
2340      .Cells(toRow(conDaysFullCoverage), 1) = "# days full coverage"
2350      .Cells(toRow(conBirdsPer100NetHours), 1) = "# birds / 100 net hours"
2360  Case "Winter", "Summer"
2370      .Cells(toRow(conBirdsBanded), 1) = "# individuals banded"
2380      .Cells(toRow(conBirdsReturns), 1) = "# individuals return"
2390      .Cells(toRow(conBirdsRepeats), 1) = "# individuals repeat"
2400      .Cells(toRow(conSpeciesDET), 1) = "# species observed"
2410      .Cells(toRow(conSpeciesBanded), 1) = "# species banded"
2420      .Cells(toRow(conSpeciesReturns), 1) = "# species return"
2430      .Cells(toRow(conSpeciesRepeats), 1) = "# species repeat"
2440      .Cells(toRow(conNetHours), 1) = "# net hours"
2450      .Cells(toRow(conDaysOperating), 1) = "# days operating"
2460      .Cells(toRow(conDaysBanding), 1) = "# days banding"
2470      .Cells(toRow(conBirdsPer100NetHours), 1) = "# birds / 100 net hours"
      '    .Cells(toRow(conDaysCensusOnly), 1) = "# days census only"
2480  Case "Owling"
2490      .Cells(toRow(conBirdsBanded), 1) = "# individuals banded"
2500      .Cells(toRow(conBirdsRepeats), 1) = "# individuals repeat"
2510      .Cells(toRow(conSpeciesBanded), 1) = "# species banded"
2520      .Cells(toRow(conSpeciesRepeats), 1) = "# species repeat"
2530      .Cells(toRow(conBirdsForeign), 1) = "# individuals foreign"
2540      .Cells(toRow(conSpeciesForeign), 1) = "# species foreign"
2550      .Cells(toRow(conNetHours), 1) = "# net hours"
2560      .Cells(toRow(conDaysBanding), 1) = "# nights banding"
2570      .Cells(toRow(conBirdsPer100NetHours), 1) = "# birds / 100 net hours"
2580  End Select

      Dim lngStart As Long
      Dim range As Word.range
      Dim lngEnd As Long
        
2590  Set range = MoveInsertionPointToEndOfDocument(wd, doc)

2600  range.ParagraphFormat.SpaceAfter = 3

2610  For Y = intYearFirst To intYearLast

          Dim intYearIndex As Integer
          Dim intYearIndexMod5 As Integer
          
2620      intYearIndex = Y - intYearFirst
2630      intYearIndexMod5 = intYearIndex Mod 5
          
2640      If intYearIndexMod5 = 0 Then                                                 ' Every 5th year
        
          ' Delete colums we do not want from previous table, if any
          
2650          If intYearIndex <> 0 Then
2660              range.Tables(1).columns(8).Delete
2670              range.Tables(1).columns(7).Delete
2680          End If
        
2690          Set range = MoveInsertionPointToEndOfDocument(wd, doc)
              
              ' Insert a blank line between tables
              
2700          If intYearIndex <> 0 Then
2710              range.InsertParagraphAfter
2720              range.ParagraphFormat.Style = "ddBody"
2730              Set range = MoveInsertionPointToEndOfDocument(wd, doc)
2740          End If
              
2750          Call WordGenerateTableSummary(doc, range, strSeason)
               
'                Delete the rows we do not want
'
'2760           Select Case strSeason
'               Case "Winter", "Summer"
'2770               range.tables(1).Rows(11).Delete
'2780               range.tables(1).Rows(5).Delete
'2790           Case "Spring", "Fall"
'2800               range.tables(1).Rows(5).Delete
'2810           Case "Owling"
'2820               range.tables(1).Cell(10, 1).range.Text = "# nights banding"
'2830               range.tables(1).Rows(11).Delete
'2840               range.tables(1).Rows(9).Delete
'2850               range.tables(1).Rows(6).Delete
'2860               range.tables(1).Rows(3).Delete
'2870           End Select
         
2760      End If
          
          ' Fill in the header for this year y
        
2770      range.Tables(1).Cell(1, intYearIndexMod5 + 2).range.Text = Y
          
          ' Fill in the statistics for this year y
          
2780      For stat = 0 To conStatLast
2790          Select Case strSeason
              Case "Spring", "Fall"
2800              Select Case stat
                  Case conBirdsBanded, conSpeciesBanded, _
                      conBirdsReturns, conSpeciesReturns, _
                      conBirdsRepeats, conSpeciesRepeats, _
                      conSpeciesDET, _
                      conNetHours, conBirdsPer100NetHours
2810                  If dblStat(conDaysBanding, Y) > 0 Then
2820                      .Cells(toRow(stat), toCol(Y - intYearFirst)) = dblStat(stat, Y)
2830                  End If
2840              Case conDaysOperating, conDaysBanding, conDaysFullCoverage
2850                  .Cells(toRow(stat), toCol(Y - intYearFirst)) = dblStat(stat, Y)
2860              End Select
2870          Case "Winter", "Summer"
2880              Select Case stat
                  Case conBirdsBanded, conSpeciesBanded, _
                      conBirdsReturns, conSpeciesReturns, _
                      conBirdsRepeats, conSpeciesRepeats, _
                      conNetHours, conBirdsPer100NetHours
2890                  If dblStat(conDaysBanding, Y) > 0 Then
2900                      .Cells(toRow(stat), toCol(Y - intYearFirst)) = dblStat(stat, Y)
2910                  End If
2920              Case conSpeciesDET
2930                  If dblStat(conDaysOperating, Y) > 0 Then
2940                      .Cells(toRow(stat), toCol(Y - intYearFirst)) = dblStat(stat, Y)
2950                  End If
2960              Case conDaysOperating, conDaysBanding
2970                  .Cells(toRow(stat), toCol(Y - intYearFirst)) = dblStat(stat, Y)
2980              End Select
2990          Case "Owling"
3000              Select Case stat
                    Case conBirdsBanded, conSpeciesBanded, _
                        conBirdsRepeats, conSpeciesRepeats, _
                        conNetHours, conBirdsPer100NetHours, _
                        conBirdsForeign, conSpeciesForeign
3010                    If dblStat(conDaysBanding, Y) > 0 Then
3020                        .Cells(toRow(stat), toCol(Y - intYearFirst)) = dblStat(stat, Y)
3030                    End If
3040              Case conDaysBanding
3050                  .Cells(toRow(stat), toCol(Y - intYearFirst)) = dblStat(stat, Y)
3060                End Select
3070          End Select
3080      Next
          
          Dim tblRow As Integer
          
          ' # individuals (species) banded
          
3090      tblRow = toTableRow(conBirdsBanded, strSeason)
3100      If tblRow <> 0 Then
3110          If dblStat(conBirdsBanded, Y) > 0 Then
3120              range.Tables(1).Cell(tblRow, intYearIndexMod5 + 2).range.Text = _
                      dblStat(conBirdsBanded, Y) & " (" & dblStat(conSpeciesBanded, Y) & ")"
3130          Else
3140              If dblStat(conDaysBanding, Y) = 0 Then
3150                  With range.Tables(1).Cell(tblRow, intYearIndexMod5 + 2).range
3160                      .Text = "n/a"
3170                      .Font.Size = 8
3180                  End With
3190              Else
3200                  range.Tables(1).Cell(tblRow, intYearIndexMod5 + 2).range.Text = "0 (0)"
3210              End If
3220          End If
3230      End If
                  
          ' # individuals (species) return
              
3240      tblRow = toTableRow(conBirdsReturns, strSeason)
3250      If tblRow <> 0 Then
3260          If dblStat(conBirdsReturns, Y) > 0 Then
3270              range.Tables(1).Cell(tblRow, intYearIndexMod5 + 2).range.Text = _
                      dblStat(conBirdsReturns, Y) & " (" & dblStat(conSpeciesReturns, Y) & ")"
3280          Else
3290              If dblStat(conDaysBanding, Y) = 0 Then
3300                  With range.Tables(1).Cell(tblRow, intYearIndexMod5 + 2).range
3310                      .Text = "n/a"
3320                      .Font.Size = 8
3330                  End With
3340              Else
3350                  range.Tables(1).Cell(tblRow, intYearIndexMod5 + 2).range.Text = "0 (0)"
3360              End If
3370          End If
3380      End If
                  
          ' # individuals (species) repeat
            
3390      tblRow = toTableRow(conBirdsRepeats, strSeason)
3400      If tblRow <> 0 Then
3410          If dblStat(conBirdsRepeats, Y) > 0 Then
3420              range.Tables(1).Cell(tblRow, intYearIndexMod5 + 2).range.Text = _
                      dblStat(conBirdsRepeats, Y) & " (" & dblStat(conSpeciesRepeats, Y) & ")"
3430          Else
3440              If dblStat(conDaysBanding, Y) = 0 Then
3450                  With range.Tables(1).Cell(tblRow, intYearIndexMod5 + 2).range
3460                      .Text = "n/a"
3470                      .Font.Size = 8
3480                  End With
3490              Else
3500                  range.Tables(1).Cell(tblRow, intYearIndexMod5 + 2).range.Text = "0 (0)"
3510              End If
3520          End If
3530      End If
          
          ' # individuals (species) foreign
            
3540      tblRow = toTableRow(conBirdsForeign, strSeason)
3550      If tblRow <> 0 Then
3560          If dblStat(conBirdsForeign, Y) > 0 Then
3570              range.Tables(1).Cell(tblRow, intYearIndexMod5 + 2).range.Text = _
                      dblStat(conBirdsForeign, Y) & " (" & dblStat(conSpeciesForeign, Y) & ")"
3580          Else
3590              If dblStat(conDaysBanding, Y) = 0 Then
3600                  With range.Tables(1).Cell(tblRow, intYearIndexMod5 + 2).range
3610                      .Text = "n/a"
3620                      .Font.Size = 8
3630                  End With
3640              Else
3650                  range.Tables(1).Cell(tblRow, intYearIndexMod5 + 2).range.Text = "0 (0)"
3660              End If
3670          End If
3680      End If
              
          ' # species DET
            
3690      tblRow = toTableRow(conSpeciesDET, strSeason)
3700      If tblRow <> 0 Then
3710          If dblStat(conSpeciesDET, Y) > 0 Then
3720              range.Tables(1).Cell(tblRow, intYearIndexMod5 + 2).range.Text = _
                      dblStat(conSpeciesDET, Y)
3730          Else
3740              If dblStat(conDaysOperating, Y) = 0 Then
3750                  With range.Tables(1).Cell(tblRow, intYearIndexMod5 + 2).range
3760                      .Text = "n/a"
3770                      .Font.Size = 8
3780                  End With
3790              Else
3800                  range.Tables(1).Cell(tblRow, intYearIndexMod5 + 2).range.Text = "0"
3810              End If
3820          End If
3830      End If
          
          ' # net hours, # birds / 100 net hours

3840      For stat = conNetHours To conBirdsPer100NetHours
3850          tblRow = toTableRow(stat, strSeason)
3860          If tblRow <> 0 Then
3870              If dblStat(conNetHours, Y) > 0 Then
3880                  If dblStat(stat, Y) > 0 Then
3890                      range.Tables(1).Cell(tblRow, intYearIndexMod5 + 2).range.Text = _
                              FormatNumberEnglish(dblStat(stat, Y), 1)
3900                  Else
3910                      range.Tables(1).Cell(tblRow, intYearIndexMod5 + 2).range.Text = "0"
3920                  End If
3930              Else
3940                  With range.Tables(1).Cell(tblRow, intYearIndexMod5 + 2).range
3950                      .Text = "n/a"
3960                      .Font.Size = 8
3970                  End With
3980              End If
3990          End If
4000      Next
          
          ' # days operating, # days banding, # days full coverage
          
4010      For stat = conDaysOperating To conDaysFullCoverage
4020          tblRow = toTableRow(stat, strSeason)
4030          If tblRow <> 0 Then
4040              If dblStat(stat, Y) > 0 Then
4050                  range.Tables(1).Cell(tblRow, intYearIndexMod5 + 2).range.Text = _
                          dblStat(stat, Y)
4060              Else
4070                  range.Tables(1).Cell(tblRow, intYearIndexMod5 + 2).range.Text = "0"
4080              End If
4090          End If
4100      Next
          
4110  Next



      ' Averages, Totals

          Dim strExcelRange As String
          Dim strExcelFormula As String

4120      For stat = 0 To conStatLast
4130          Select Case strSeason
              Case "Spring", "Fall"
4140              Select Case stat
                  Case conBirdsBanded, conSpeciesBanded, _
                      conBirdsReturns, conSpeciesReturns, _
                      conBirdsRepeats, conSpeciesRepeats, _
                      conSpeciesDET
4150                  If dblTotal(stat) <> 0 Then
4160                      .Cells(toRow(stat), colLast + 2) = dblTotal(stat)
4170                  End If
4180                  strExcelRange = _
                          .Cells(toRow(stat), 2).Address & ":" & .Cells(toRow(stat), colLast).Address
4190                  strExcelFormula = _
                          "=if(Count(" & _
                          strExcelRange & _
                          ")>0,Average(" & _
                          strExcelRange & _
                          ")," & _
                          """" & """" & _
                          ")"
4200                  .Cells(toRow(stat), colLast + 1) = strExcelFormula
4210                  .range(.Cells(toRow(stat), colLast + 1), .Cells(toRow(stat), colLast + 1)).Interior.Color = RGB(240, 240, 240)
4220              Case conNetHours, _
                        conDaysOperating, conDaysBanding, _
                        conDaysFullCoverage
4230                        .Cells(toRow(stat), colLast + 2) = _
                                "=Sum(" & .Cells(toRow(stat), 2).Address & _
                                ":" & .Cells(toRow(stat), colLast).Address & ")"
4240                        .Cells(toRow(stat), colLast + 1) = _
                                "=Average(" & .Cells(toRow(stat), 2).Address & _
                                ":" & .Cells(toRow(stat), colLast).Address & ")"
4250                        .range(.Cells(toRow(stat), colLast + 1), .Cells(toRow(stat), colLast + 2)).Interior.Color = RGB(240, 240, 240)
4260              Case conBirdsPer100NetHours
4270                      .Cells(toRow(stat), colLast + 2) = _
                              "=100 * " & .Cells(toRow(conBirdsBanded), colLast + 2).Address & _
                              "/" & .Cells(toRow(conNetHours), colLast + 2).Address
4280                  strExcelRange = _
                          .Cells(toRow(stat), 2).Address & ":" & .Cells(toRow(stat), colLast).Address
4290                  strExcelFormula = _
                          "=if(Count(" & _
                          strExcelRange & _
                          ")>0,Average(" & _
                          strExcelRange & _
                          ")," & _
                          """" & """" & _
                          ")"
4300                  .Cells(toRow(stat), colLast + 1) = strExcelFormula
4310                  .range(.Cells(toRow(stat), colLast + 1), .Cells(toRow(stat), colLast + 2)).Interior.Color = RGB(240, 240, 240)
                             
4320              End Select
4330          Case "Winter", "Summer"
4340              Select Case stat
                  Case conBirdsBanded, conSpeciesBanded, _
                      conBirdsReturns, conSpeciesReturns, _
                      conBirdsRepeats, conSpeciesRepeats, _
                      conSpeciesDET
4350                  If dblTotal(stat) <> 0 Then
4360                      .Cells(toRow(stat), colLast + 2) = dblTotal(stat)
4370                  End If
4380                  strExcelRange = _
                          .Cells(toRow(stat), 2).Address & ":" & .Cells(toRow(stat), colLast).Address
4390                  strExcelFormula = _
                          "=if(Count(" & _
                          strExcelRange & _
                          ")>0,Average(" & _
                          strExcelRange & _
                          ")," & _
                          """" & """" & _
                          ")"
4400                  .Cells(toRow(stat), colLast + 1) = strExcelFormula
4410                  .range(.Cells(toRow(stat), colLast + 1), .Cells(toRow(stat), colLast + 1)).Interior.Color = RGB(240, 240, 240)

4420              Case conNetHours, _
                      conDaysOperating, conDaysBanding
4430                       .Cells(toRow(stat), colLast + 2) = _
                              "=Sum(" & .Cells(toRow(stat), 2).Address & _
                              ":" & .Cells(toRow(stat), colLast).Address & ")"
4440                  strExcelRange = _
                          .Cells(toRow(stat), 2).Address & ":" & .Cells(toRow(stat), colLast).Address
4450                  strExcelFormula = _
                          "=if(Count(" & _
                          strExcelRange & _
                          ")>0,Average(" & _
                          strExcelRange & _
                          ")," & _
                          """" & """" & _
                          ")"
4460                  .Cells(toRow(stat), colLast + 1) = strExcelFormula
4470                  .range(.Cells(toRow(stat), colLast + 1), .Cells(toRow(stat), colLast + 2)).Interior.Color = RGB(240, 240, 240)
4480              Case conBirdsPer100NetHours
4490                      .Cells(toRow(stat), colLast + 2) = _
                              "=100 * " & .Cells(toRow(conBirdsBanded), colLast + 2).Address & _
                              "/" & .Cells(toRow(conNetHours), colLast + 2).Address
4500                   strExcelRange = _
                          .Cells(toRow(stat), 2).Address & ":" & .Cells(toRow(stat), colLast).Address
4510                  strExcelFormula = _
                          "=if(Count(" & _
                          strExcelRange & _
                          ")>0,Average(" & _
                          strExcelRange & _
                          ")," & _
                          """" & """" & _
                          ")"
4520                  .Cells(toRow(stat), colLast + 1) = strExcelFormula
4530                  .range(.Cells(toRow(stat), colLast + 1), .Cells(toRow(stat), colLast + 2)).Interior.Color = RGB(240, 240, 240)
       
4540              End Select
4550          Case "Owling"
4560              Select Case stat
                  Case conBirdsBanded, conSpeciesBanded, _
                      conBirdsRepeats, conSpeciesRepeats, _
                      conBirdsForeign, conSpeciesForeign

4570                  If dblTotal(stat) <> 0 Then
4580                      .Cells(toRow(stat), colLast + 2) = dblTotal(stat)
4590                  End If
4600                  strExcelRange = _
                          .Cells(toRow(stat), 2).Address & ":" & .Cells(toRow(stat), colLast).Address
4610                  strExcelFormula = _
                          "=if(Count(" & _
                          strExcelRange & _
                          ")>0,Average(" & _
                          strExcelRange & _
                          ")," & _
                          """" & """" & _
                          ")"
4620                  .Cells(toRow(stat), colLast + 1) = strExcelFormula
4630                  .range(.Cells(toRow(stat), colLast + 1), .Cells(toRow(stat), colLast + 1)).Interior.Color = RGB(240, 240, 240)

4640              Case conNetHours, conDaysBanding
4650                       .Cells(toRow(stat), colLast + 2) = _
                              "=Sum(" & .Cells(toRow(stat), 2).Address & _
                              ":" & .Cells(toRow(stat), colLast).Address & ")"
4660                  strExcelRange = _
                          .Cells(toRow(stat), 2).Address & ":" & .Cells(toRow(stat), colLast).Address
4670                  strExcelFormula = _
                          "=if(Count(" & _
                          strExcelRange & _
                          ")>0,Average(" & _
                          strExcelRange & _
                          ")," & _
                          """" & """" & _
                          ")"
4680                  .Cells(toRow(stat), colLast + 1) = strExcelFormula
4690                  .range(.Cells(toRow(stat), colLast + 1), .Cells(toRow(stat), colLast + 2)).Interior.Color = RGB(240, 240, 240)
4700              Case conBirdsPer100NetHours

4710                  strExcelFormula = _
                           "=100 * (" & .Cells(toRow(conBirdsBanded), colLast + 2).Address & _
                           "/" & .Cells(toRow(conNetHours), colLast + 2).Address & ")"
4720                  .Cells(toRow(stat), colLast + 2) = strExcelFormula
                       
4730                  strExcelRange = _
                          .Cells(toRow(stat), 2).Address & ":" & .Cells(toRow(stat), colLast).Address
4740                  strExcelFormula = _
                          "=if(Count(" & _
                          strExcelRange & _
                          ")>0,Average(" & _
                          strExcelRange & _
                          ")," & _
                          """" & """" & _
                          ")"
4750                  .Cells(toRow(stat), colLast + 1) = strExcelFormula
4760                  .range(.Cells(toRow(stat), colLast + 1), .Cells(toRow(stat), colLast + 2)).Interior.Color = RGB(240, 240, 240)

4770                End Select
4780          End Select
4790      Next
          
          ' Fill in the header
          
          Dim strFormat As String
                 
4800      range.Tables(1).Cell(1, 7).range.Text = "Average"
4810      range.Tables(1).Cell(1, 8).range.Text = "Total"
          
          ' # individuals (species) banded

          Dim intDecimals As Integer

4820      tblRow = toTableRow(conBirdsBanded, strSeason)
4830      If tblRow <> 0 Then
4840          If dblAverage(conSpeciesBanded) >= 4 Then
      '            strFormat = "#0"
4850              intDecimals = 0
4860          Else
      '            strFormat = "#0.0"
4870              intDecimals = 1
4880          End If
4890          If dblTotal(conBirdsBanded) > 0 Then
4900              range.Tables(1).Cell(tblRow, 7).range.Text = _
                      Round(dblAverage(conBirdsBanded), 0) & " (" & _
                      FormatNumberEnglish(dblAverage(conSpeciesBanded), intDecimals) & ")"
4910              range.Tables(1).Cell(tblRow, 8).range.Text = _
                      dblTotal(conBirdsBanded) & " (" & dblTotal(conSpeciesBanded) & ")"
4920          Else
4930              range.Tables(1).Cell(tblRow, 7).range.Text = "0 (0)"
4940              range.Tables(1).Cell(tblRow, 8).range.Text = "0 (0)"
4950          End If
4960      End If
          
          ' # individuals (species) return
          
4970      tblRow = toTableRow(conBirdsReturns, strSeason)
4980      If tblRow <> 0 Then
4990          If dblAverage(conSpeciesReturns) >= 4 Then
      '            strFormat = "#0"
5000              intDecimals = 0
5010          Else
      '            strFormat = "#0.0"
5020              intDecimals = 1
5030          End If
5040          If dblTotal(conBirdsReturns) > 0 Then
5050              range.Tables(1).Cell(tblRow, 7).range.Text = _
                      Round(dblAverage(conBirdsReturns), 0) & " (" & _
                      FormatNumberEnglish(dblAverage(conSpeciesReturns), intDecimals) & ")"
5060              range.Tables(1).Cell(tblRow, 8).range.Text = _
                      dblTotal(conBirdsReturns) & " (" & dblTotal(conSpeciesReturns) & ")"
5070          Else
5080              range.Tables(1).Cell(tblRow, 7).range.Text = "0 (0)"
5090              range.Tables(1).Cell(tblRow, 8).range.Text = "0 (0)"
5100          End If
5110      End If

          ' # individuals (species) repeat

5120      tblRow = toTableRow(conBirdsRepeats, strSeason)
5130      If tblRow <> 0 Then
5140          If dblAverage(conSpeciesRepeats) >= 4 Then
5150              intDecimals = 0
      '            strFormat = "#0"
5160          Else
5170              intDecimals = 1
      '            strFormat = "#0.0"
5180          End If
5190          If dblTotal(conBirdsRepeats) > 0 Then
5200            range.Tables(1).Cell(tblRow, 7).range.Text = _
                    Round(dblAverage(conBirdsRepeats), 0) & " (" & _
                    FormatNumberEnglish(dblAverage(conSpeciesRepeats), intDecimals) & ")"
5210              range.Tables(1).Cell(tblRow, 8).range.Text = _
                    dblTotal(conBirdsRepeats) & " (" & dblTotal(conSpeciesRepeats) & ")"
5220          Else
5230              range.Tables(1).Cell(tblRow, 7).range.Text = "0 (0)"
5240              range.Tables(1).Cell(tblRow, 8).range.Text = "0 (0)"
5250          End If
5260      End If

          ' # individuals (species) foreign

5270      tblRow = toTableRow(conBirdsForeign, strSeason)
5280      If tblRow <> 0 Then
5290          If dblAverage(conSpeciesForeign) >= 4 Then
      '             strFormat = "#0"
5300              intDecimals = 0
5310          Else
      '             strFormat = "#0.0"
5320              intDecimals = 1
5330          End If
5340          If dblTotal(conBirdsForeign) > 0 Then
5350            range.Tables(1).Cell(tblRow, 7).range.Text = _
                    Round(dblAverage(conBirdsForeign), 0) & " (" & _
                    FormatNumberEnglish(dblAverage(conSpeciesForeign), intDecimals) & ")"
5360              range.Tables(1).Cell(tblRow, 8).range.Text = _
                    dblTotal(conBirdsForeign) & " (" & dblTotal(conSpeciesForeign) & ")"
5370          Else
5380              range.Tables(1).Cell(tblRow, 7).range.Text = "0 (0)"
5390              range.Tables(1).Cell(tblRow, 8).range.Text = "0 (0)"
5400          End If
5410      End If

          ' # species observed

5420      tblRow = toTableRow(conSpeciesDET, strSeason)
5430      If tblRow <> 0 Then
5440          If dblTotal(conSpeciesDET) > 0 Then
5450            range.Tables(1).Cell(tblRow, 7).range.Text = _
                    Round(dblAverage(conSpeciesDET), 0)
5460              range.Tables(1).Cell(tblRow, 8).range.Text = _
                    dblTotal(conSpeciesDET)
5470          Else
5480              range.Tables(1).Cell(tblRow, 7).range.Text = "0"
5490              range.Tables(1).Cell(tblRow, 8).range.Text = "0"
5500          End If
5510      End If
          
          ' all other stats
        
5520      For stat = conNetHours To conStatLast
5530          tblRow = toTableRow(stat, strSeason)
5540          If tblRow <> 0 Then
5550              If dblTotal(stat) > 0 Then
5560                  If stat = conNetHours Or stat = conBirdsPer100NetHours Then
5570                      range.Tables(1).Cell(tblRow, 7).range.Text = _
                              FormatNumberEnglish(dblAverage(stat), 1)
5580                      range.Tables(1).Cell(tblRow, 8).range.Text = _
                              FormatNumberEnglish(dblTotal(stat), 1)
5590                  Else
5600                      range.Tables(1).Cell(tblRow, 7).range.Text = _
                             dblAverage(stat)
5610                      range.Tables(1).Cell(tblRow, 8).range.Text = _
                             dblTotal(stat)
5620                  End If
5630              Else
5640              range.Tables(1).Cell(tblRow, 7).range.Text = "0"
5650              range.Tables(1).Cell(tblRow, 8).range.Text = "0"
5660              End If
5670          End If
5680      Next

5690  .range(.columns(1), .columns(1)).AutoFit
5700  .range(.Cells(toRow(0), toCol(0)), .Cells(toRow(conStatLast), colLast + 2)).NumberFormat = "#0;-#0;0"

5710  .range(.Cells(toRow(conNetHours), 2), .Cells(toRow(conNetHours), colLast + 2)).NumberFormat = "#0.0;-#0.0;#"
5720  .range(.Cells(toRow(conBirdsPer100NetHours), 2), _
        .Cells(toRow(conBirdsPer100NetHours), colLast + 2)).NumberFormat = "#0.0;-#0.0;#"
       
5730  .range(.Cells(1, colLast + 1), .Cells(1, colLast + 2)).HorizontalAlignment = xlRight

5740  End With

5750  Set oSheet = Nothing

      ' Add blank line after the tables

5760  Set range = MoveInsertionPointToEndOfDocument(wd, doc)
5770  range.InsertParagraphAfter
5780  range.Style = "ddBody"
5790  Set range = MoveInsertionPointToEndOfDocument(wd, doc)

      ' Details of Days Full Coverage => Excel

5800  Select Case strSeason
      Case "Spring", "Fall"
          
          Dim oSheetFC As Excel.Worksheet
5810      Set oSheetFC = InsertSheet(oBook, strSeason)
5820      oSheetFC.Name = strSeason & " Full Net Coverage"
5830      With oSheetFC
          
5840      strSQL = "qryMBO10YearProgramReportSummary_DaysFullCoverage_B"
5850      Set qdf = CurrentDb.QueryDefs(strSQL)
5860      qdf.Parameters("argSeason").value = strSeason
5870      qdf.Parameters("argLocation").value = strLocation
5880      qdf.Parameters("argYearFirst").value = intYearFirst
5890      qdf.Parameters("argYearLast").value = intYearLast
5900      Set rst = qdf.OpenRecordset
              
5910      .Cells(1, 1) = "Season"
5920      .Cells(1, 2) = "Year"
5930      .Cells(1, 3) = "Net Hours"
5940      .Cells(1, 4) = "# Days"
5950      .Cells(1, 5) = "Full Net Coverage Threshold"
5960      .Cells(1, 6) = "# Days with Full Net Coverage"
              
          Dim row As Long
5970      row = 2
          
          Dim intYear As Integer
          Dim dblNetHours As Double
          Dim lngCountDays As Long
          Dim lngFullNetCoverageThreshold As Long
          Dim lngCountDaysWithFullNetCoverage As Long
              
5980      Do While Not rst.EOF
          
5990          strSeason = Nz(rst("Season"))
6000          intYear = Nz(rst("YearEx"))
6010          dblNetHours = Nz(rst("NetHours"))
6020          lngCountDays = Nz(rst("CountDays"))
6030          lngFullNetCoverageThreshold = Nz(rst("FullNetCoverageThreshold"))
6040          lngCountDaysWithFullNetCoverage = Nz(rst("CountDaysWithFullNetCoverage"))
              
6050          .Cells(row, 1) = strSeason
6060          .Cells(row, 2) = intYear
6070          .Cells(row, 3) = Round(dblNetHours, 1)
6080          .Cells(row, 4) = lngCountDays
6090          .Cells(row, 5) = lngFullNetCoverageThreshold
6100          .Cells(row, 6) = lngCountDaysWithFullNetCoverage
6110          row = row + 1
          
6120          rst.MoveNext
6130      Loop
6140      rst.Close
6150      Set rst = Nothing
          
6160      .range(.columns(1), .columns(6)).AutoFit
6170      .range(.Cells(1, 1), .Cells(row - 1, 6)).Subtotal _
                    GroupBy:=2, Function:=xlSum, TotalList:=Array(6), _
                    Replace:=True, PageBreaks:=False, SummaryBelowData:=True
          
6180      End With
          
6190      Set oSheetFC = Nothing

6200  End Select

      ' Details of Species Banded, Returns, Repeats, Foreign, DET => Excel

      Dim oSheetSB As Excel.Worksheet

      Dim intStatFirst As Integer
6210  If strSeason = "Owling" Then
6220     intStatFirst = conBND
6230  Else
6240      intStatFirst = conDET
6250  End If

6260  For fld = intStatFirst To conFRN
6270      Set oSheetSB = InsertSheet(oBook, strSeason)
          
6280      Select Case fld
          Case conDET
6290              oSheetSB.Name = strSeason & " Species DET"
6300      Case conBND
6310              oSheetSB.Name = strSeason & " Species Banded"
6320      Case conRET
6330              oSheetSB.Name = strSeason & " Species Returns"
6340      Case conREP
6350              oSheetSB.Name = strSeason & " Species Repeats"
6360      Case conFRN
6370              oSheetSB.Name = strSeason & " Species Foreign"
6380      End Select
              
6390      With oSheetSB
          
6400      Select Case fld
          Case conDET
6410          strSQL = "qryMBO10YearProgramReportSummary_Species_DET_CrossTab"
6420      Case conBND
6430          strSQL = "qryMBO10YearProgramReportSummary_Species_Banded_CrossTab"
6440      Case conRET
6450          strSQL = "qryMBO10YearProgramReportSummary_Species_Returns_CrossTab"
6460      Case conREP
6470          strSQL = "qryMBO10YearProgramReportSummary_Species_Repeats_CrossTab"
6480      Case conFRN
6490          strSQL = "qryMBO10YearProgramReportSummary_Species_Foreign_CrossTab"
              
6500      End Select
          
6510      Set qdf = CurrentDb.QueryDefs(strSQL)
6520      qdf.Parameters("argSeason").value = strSeason
6530      qdf.Parameters("argLocation").value = strLocation
6540      qdf.Parameters("argYearFirst").value = intYearFirst
6550      qdf.Parameters("argYearLast").value = intYearLast
6560      Set rst = qdf.OpenRecordset
              
6570      Select Case fld
          Case conDET
6580              .Cells(1, 1) = strSeason & " Species DET"
6590      Case conBND
6600              .Cells(1, 1) = strSeason & " Species Banded"
6610      Case conRET
6620              .Cells(1, 1) = strSeason & " Species Returns"
6630      Case conREP
6640              .Cells(1, 1) = strSeason & " Species Repeats"
6650      Case conFRN
6660              .Cells(1, 1) = strSeason & " Species Foreign"
6670      End Select
              
6680      .Cells(2, 1) = "Pseudo-species"
6690      .Cells(2, 2) = "All Years"
          
6700      For intYear = intYearFirst To intYearLast
6710          .Cells(2, 3 + intYear - intYearFirst) = intYear
6720      Next
          
6730      row = 3
              
              Dim i As Integer
              
6740      Do While Not rst.EOF
          
6750          strSpecies = rst("Species")
          
6760          .Cells(row, 1) = strSpecies
6770          .Cells(row, 2) = 1
          
6780          If DCount("*", "tblSuperSpecies", "[Species] = '" & strSpecies & "'") > 0 Then
6790              .range(.Cells(row, 1), .Cells(row, intYearLast - intYearFirst + 3)).Interior.Color = RGB(240, 240, 240)
6800          End If
              
6810          If DCount("*", "tblSubSpecies", "[Species] = '" & strSpecies & "'") > 0 Then
6820              .range(.Cells(row, 1), .Cells(row, intYearLast - intYearFirst + 3)).Interior.Color = RGB(240, 240, 240)
6830          End If
              
6840          If DCount("*", "tblSuperSpecies", "[Superspecies] = '" & strSpecies & "'") > 0 Then
6850              .range(.Cells(row, 1), .Cells(row, intYearLast - intYearFirst + 3)).Interior.Color = vbYellow
6860          End If
          
6870          If DCount("*", "tblSubSpecies", "[SubSpecies] = '" & strSpecies & "'") > 0 Then
6880              .range(.Cells(row, 1), .Cells(row, intYearLast - intYearFirst + 3)).Interior.Color = RGB(255, 204, 153)
6890          End If
              
6900          On Error Resume Next
6910          For intYear = intYearFirst To intYearLast
6920              i = 0
6930              On Error Resume Next
6940              i = Nz(rst(CStr(intYear)))
6950              If i = 1 Then
6960                  .Cells(row, 3 + intYear - intYearFirst) = 1
6970              End If
6980          Next
6990          On Error GoTo Err_label
              
7000          row = row + 1
          
7010          rst.MoveNext
7020      Loop
7030      rst.Close
7040      Set rst = Nothing
          
          ' Add formulas to total columns when there is data
          
7050      If row > 3 Then
7060          .Cells(row, 2) = "=Sum(b3:b" & row - 1 & ")"
7070          .range(.Cells(row, 3), .Cells(row, 3 + intYearLast - intYearFirst)).FormulaR1C1 = _
              .range(.Cells(row, 2), .Cells(row, 2)).FormulaR1C1
7080      End If
          
7090      .range(.columns(1), .columns(3 + intYearLast - intYearFirst)).AutoFit
          
7100      End With
          
7110      Set oSheetSB = Nothing


7120  Next

      'DD Error Handler Start
Exit_label:
7130       Exit Sub
Err_label:
7140       Select Case Err.Number
           Case Else
7150      Call LogError("basMBO10YearProgramReportSummary", "MBO10YearProgramReportSummary")
7160       End Select
7170       Resume Exit_label
      'DD Error Handler End
          
End Sub
        
'---------------------------------------------------------------------------------------
' toFieldnameFLD
'---------------------------------------------------------------------------------------
 
Private Function toFieldnameFLD(ByVal fld As Integer) As String
10    On Error GoTo Err_label

20        Select Case fld
          Case 0
30            toFieldnameFLD = "DET"
40        Case 1
50            toFieldnameFLD = "Banded"
60        Case 2
70            toFieldnameFLD = "Returns"
80        Case 3
90            toFieldnameFLD = "Repeats"
100       Case 4
110            toFieldnameFLD = "Foreign"
120       End Select

      'DD Error Handler Start
Exit_label:
130        Exit Function
Err_label:
140        Select Case Err.Number
           Case Else
150             Call LogError("basMBO10YearProgramReportSummary", "toFieldnameFLD")
160        End Select
170        Resume Exit_label
      'DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' toRow
'---------------------------------------------------------------------------------------
 
Private Function toRow(ByVal stat As Integer)
10    On Error GoTo Err_label

20        toRow = stat + 2

'DD Error Handler Start
Exit_label:
30         Exit Function
Err_label:
40         Select Case Err.Number
     Case Else
50        Call LogError("basMBO10YearProgramReportSummary", "toRow")
60         End Select
70         Resume Exit_label
'DD Error Handler End
End Function

Private Function toCol(ByVal yearOffset As Integer) As Integer
10    toCol = yearOffset + 2
End Function

'---------------------------------------------------------------------------------------
' toTableRow
'---------------------------------------------------------------------------------------
' Returns 0 when a stat is not to be reported

Private Function toTableRow(ByVal stat As Integer, ByVal strSeason As String) As Integer
10    On Error GoTo Err_label

20    toTableRow = 0

30    Select Case strSeason
      Case "Winter", "Summer"
40        Select Case stat
          Case conBirdsBanded
50            toTableRow = 2
60        Case conSpeciesBanded
70            toTableRow = 2
80        Case conBirdsReturns
90            toTableRow = 3
100       Case conSpeciesReturns
110           toTableRow = 3
120       Case conBirdsRepeats
130           toTableRow = 4
140       Case conSpeciesRepeats
150           toTableRow = 4
160       Case conSpeciesDET
170           toTableRow = 5
180       Case conNetHours
190           toTableRow = 6
200       Case conBirdsPer100NetHours
210           toTableRow = 7
220       Case conDaysOperating
230           toTableRow = 8
240       Case conDaysBanding
250           toTableRow = 9
'260       Case conDaysCensusOnly
'270           toTableRow = 10
260       End Select
270   Case "Spring", "Fall"
280       Select Case stat
          Case conBirdsBanded
290           toTableRow = 2
300       Case conSpeciesBanded
310           toTableRow = 2
320       Case conBirdsReturns
330           toTableRow = 3
340       Case conSpeciesReturns
350           toTableRow = 3
360       Case conBirdsRepeats
370           toTableRow = 4
380       Case conSpeciesRepeats
390           toTableRow = 4
400       Case conSpeciesDET
410           toTableRow = 5
420       Case conNetHours
430           toTableRow = 6
440       Case conBirdsPer100NetHours
450           toTableRow = 7
460       Case conDaysOperating
470           toTableRow = 8
480       Case conDaysBanding
490           toTableRow = 9
500       Case conDaysFullCoverage
510           toTableRow = 10
520       End Select
530   Case "Owling"
540       Select Case stat
          Case conBirdsBanded
550           toTableRow = 2
560       Case conSpeciesBanded
570           toTableRow = 2
580       Case conBirdsRepeats
590           toTableRow = 3
600       Case conSpeciesRepeats
610           toTableRow = 3
620       Case conBirdsForeign
630           toTableRow = 4
640       Case conSpeciesForeign
650           toTableRow = 4
660       Case conNetHours
670           toTableRow = 5
680       Case conBirdsPer100NetHours
690           toTableRow = 6
700       Case conDaysBanding
710           toTableRow = 7
720       End Select
730   End Select

      'DD Error Handler Start
Exit_label:
740        Exit Function
Err_label:
750        Select Case Err.Number
           Case Else
760             Call LogError("basMBO10YearProgramReportSummary", "toTableRow")
770        End Select
780        Resume Exit_label
      'DD Error Handler End
End Function

'---------------------------------------------------------------------------------------
' WordGenerateTableSummary
'---------------------------------------------------------------------------------------
' entry:  range = a collapsed range that is the insertion point for the table
' exit:   range = range that includes the table

' Also called from basMBO10YearProgramReportNestlingSummary

Public Sub WordGenerateTableSummary( _
    ByRef doc As Word.Document, _
    ByRef range As Word.range, _
    ByRef strSeason As String)

10    On Error GoTo Err_label

      Dim row As Integer
      Dim col As Integer

      Dim intNumberRows As Integer

20    Select Case strSeason
      Case "Winter", "Summer"
30        intNumberRows = 9
40    Case "Spring", "Fall"
50        intNumberRows = 10
60    Case "Owling"
70        intNumberRows = 7
80    Case "NestBox"
90        intNumberRows = 2
100   End Select

110   doc.Tables.Add range:=range, NumRows:=intNumberRows, NumColumns:=8
          
120   range.Expand (wdTable)
130   With range.Tables(1)

140       .Borders.InsideLineStyle = wdLineStyleNone
150       .Borders.OutsideLineStyle = wdLineStyleNone
160       .Rows(intNumberRows).Borders(wdBorderBottom).LineStyle = wdLineStyleSingle
          
170       .range.Style = "ddData"
180       .LeftPadding = doc.Application.InchesToPoints(0#)
190       .RightPadding = doc.Application.InchesToPoints(0#)
200       .TopPadding = doc.Application.InchesToPoints(0.02)
          
          ' Left align the table
          
210       .Rows.Alignment = wdAlignRowLeft

          Dim dblTableWidth As Double
          Dim dblColumnWidth_Label As Double
          Dim dblColumnWidth_Year As Double
          Dim dblColumnWidth_Average As Double
          Dim dblColumnWidth_Total As Double
220       dblTableWidth = (8.5 - 2 * 0.75) * 2.54
230       dblColumnWidth_Label = 5.56
240       dblColumnWidth_Total = 2#
250       dblColumnWidth_Average = 2
260       dblColumnWidth_Year = (dblTableWidth - dblColumnWidth_Label - dblColumnWidth_Total - dblColumnWidth_Average) / 5
              
270       .columns(1).Width = doc.Application.CentimetersToPoints(dblColumnWidth_Label)
280       For col = 2 To 7
290           .columns(col).Width = doc.Application.CentimetersToPoints(dblColumnWidth_Year)
300       Next
310       .columns(8).Width = doc.Application.CentimetersToPoints(dblColumnWidth_Average)
320       .columns(8).Width = doc.Application.CentimetersToPoints(dblColumnWidth_Total)
          
330       Select Case strSeason
          Case "Winter", "Summer"
340           .Cell(2, 1).range.Text = "# individuals (species) banded"
350           .Cell(3, 1).range.Text = "# individuals (species) return"
360           .Cell(4, 1).range.Text = "# individuals (species) repeat"
370           .Cell(5, 1).range.Text = "# species observed"
380           .Cell(6, 1).range.Text = "# net hours"
390           .Cell(7, 1).range.Text = "# birds banded / 100 net hours"
400           .Cell(8, 1).range.Text = "# days operating"
410           .Cell(9, 1).range.Text = "# days banding"
420       Case "Spring", "Fall"
430           .Cell(2, 1).range.Text = "# individuals (species) banded"
440           .Cell(3, 1).range.Text = "# individuals (species) return"
450           .Cell(4, 1).range.Text = "# individuals (species) repeat"
460           .Cell(5, 1).range.Text = "# species observed"
470           .Cell(6, 1).range.Text = "# net hours"
480           .Cell(7, 1).range.Text = "# birds banded / 100 net hours"
490           .Cell(8, 1).range.Text = "# days operating"
500           .Cell(9, 1).range.Text = "# days banding"
510           .Cell(10, 1).range.Text = "# days with full net coverage"
520       Case "Owling"
530           .Cell(2, 1).range.Text = "# individuals (species) banded"
540           .Cell(3, 1).range.Text = "# individuals (species) return"
550           .Cell(4, 1).range.Text = "# individuals (species) repeat"
560           .Cell(5, 1).range.Text = "# net hours"
570           .Cell(6, 1).range.Text = "# birds banded / 100 net hours"
580           .Cell(7, 1).range.Text = "# nights banding"
590       Case "Nestbox"
600           .Cell(2, 1).range.Text = "# individuals (species) banded"
610       End Select

620       For row = 2 To intNumberRows
630           .Cell(row, 1).LeftPadding = doc.Application.CentimetersToPoints(0.2)
640       Next

      ' Background colour last 2 columns RGB(217, 217, 217)

650       For row = 2 To intNumberRows
660       .Cell(row, 7).Shading.BackgroundPatternColor = RGB(217, 217, 217)
670       .Cell(row, 8).Shading.BackgroundPatternColor = RGB(217, 217, 217)
680       Next

          ' Format Header Row
          
690       Call FormatWordTableRowAsHeader(.Rows(1), "ddHeaderRow")
700       .Rows(1).range.ParagraphFormat.Alignment = wdAlignParagraphCenter
          
          ' Format Labels Column
        
710       For row = 2 To intNumberRows
720         .Cell(row, 1).range.Style = "ddLabelsColumn"
730       Next
         
          ' Repeat heading row at the top of subsequent pages

740       .Rows.WrapAroundText = False

750   End With

          'DD Error Handler Start
Exit_label:
760       Exit Sub
Err_label:
770       Select Case Err.Number
          Case Else
780      Call LogError("basMBO10YearProgramReportSummary", "WordGenerateTableSummary")
790       End Select
800       Resume Exit_label
          ' DD Error Handler End

End Sub
