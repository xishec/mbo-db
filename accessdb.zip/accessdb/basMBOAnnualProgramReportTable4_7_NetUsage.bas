'---------------------------------------------------------------------------------------
' Module    : basMBOAnnualProgramReportTable4_7_NetUsage
' Author    : David Davey
'---------------------------------------------------------------------------------------

Option Compare Database
Option Explicit

'---------------------------------------------------------------------------------------
' MBOAnnualProgramReport_NetUsage
'---------------------------------------------------------------------------------------
' Net Usage
' Spring, Fall, Owling

Public Sub MBOAnnualProgramReport_NetUsage( _
    ByRef fValid As Boolean, _
    ByVal intYear As Integer, _
    ByVal strLocation As String, _
    ByVal strProgram As String, _
    ByVal strSeason As String, _
    ByRef wd As Word.Application, _
    ByRef doc As Word.Document, _
    ByRef oExcel As Excel.Application, _
    ByRef oBook As Excel.Workbook, _
    ByVal strTableCaptionHeading As String)

10    On Error GoTo Err_label

          '     tblCaptures
          '           |                         tblDETNetHours x tblNets
          '           v                              |
          '   qryMBOAnnualProgramReportTable4_7      v
          '                   |                   qryMBOAnnualProgramReportTable4_7B
          '                   |                      |
          '                   v                      v
          '                  qryMBOAnnualProgramReportTable4_7C                   Called from this code   => Excel (Net Usage: Detail)
          '                       |              |         |
          '                       v              |         |
          ' qryMBOAnnualProgramReportTable4_7D   |         |                      Called from this code   => Excel (Net Usage: Summary 1+R+F+5)
          '                                      v         |
          '          qryMBOAnnualProgramReportTable4_7E    |                      Called from this code   => Excel  Net Usage: Summary R+F+5)
          '                                                v
          '                    qryMBOAnnualProgramReportTable4_7A  (crosstab)     Called from this code.  => Word Table

20    SysCmd acSysCmdSetStatus, strSeason & " Net usage"

      Dim strSQL As String

30    fValid = True

40    If Not (strSeason = "Spring" Or strSeason = "Fall" Or strSeason = "Owling") Then GoTo Exit_label

      Dim range As Word.range

      ' Append the caption for Table Net Usage

      Dim strTableCaptionBody As String

50    Select Case strSeason
      Case "Spring"
60        strTableCaptionBody = _
        "Net usage and capture rates during the " & intYear & " SMMP"
70    Case "Fall"
80        strTableCaptionBody = _
        "Net usage and capture rates during the " & intYear & " FMMP"
90    Case "Owling"
100       strTableCaptionBody = _
       "Net usage and capture rates during the " & intYear & " Northern Saw-whet Owl Monitoring Program"
110   End Select

120   Set range = MoveInsertionPointToEndOfDocument(wd, doc)

130   Call WordGenerateCaption(wd, doc, "Table", strTableCaptionHeading, strTableCaptionBody)

140   If 0 = DCount("*", "tblDETDaily", "[Program]='" & strProgram & "' AND [Location]='" & strLocation & "'") Then
150       Set range = MoveInsertionPointToEndOfDocument(wd, doc)
160       range.InsertAfter "*** Marcel *** There were no DET sheets for the monitoring program " & strProgram & " at " & strLocation
170       range.InsertParagraphAfter
180       GoTo Exit_label
190   End If

      ' Append Table Net Usage

200   Set range = doc.Characters.Last
210   Call WordGenerateTableNetUsage(doc, range, strSeason)

      ' qryMBOAnnualProgramReportTable4_7
      ' ================================================================
      ' For each net, for each disposition, count the number of captures
      ' i.e. Count the number of bandings and recaps at each net
      ' ================================================================
      ' FROM tblCaptures
      ' Program = [argProgram]
      ' Location = [argLocation]
      ' Disposition   NOT IN ("4","8")
      ' Captures = Count of captures
      ' NetHours = Sum of net hours
      ' GROUP BY Disposition, Net, Program, Location
      ' Report Program, Location, Disposition, Net, Captures

      ' qryMBOAnnualProgramReportTable4_7B
      ' ==================================
      ' A summary of tblDETNetHours
      ' ==================================
      ' FROM tblDETNetHours x tblNets
      ' Program = [argProgram]
      ' Location = [argLocation]
      ' GROUP BY Net = NetID, NetGroup, Order
      ' NetHours = SUM NetHours
      ' Report Program, Location, Net, NetHours, NetGroup, Order

      ' qryMBOAnnualProgramReportTable4_7C
      ' ===============================================================
      ' Count the number of bandings and recaps at each net + net hours
      ' Nets with 0 captures, appear as a row with a null Disposition and null Captures
      ' ===============================================================
      ' qryMBOAnnualProgramReportTable4_7 x qryMBOAnnualProgramReportTable4_7B
      ' Program = [argProgram]
      ' Location = [argLocation]
      ' Net
      ' NetGroup
      ' Order
      ' Disposition
      ' Captures
      ' NetHours

      ' qryMBOAnnualProgramReportTable4_7A
      ' ===============================================
      ' A crosstab version of the above query
      ' ===============================================
      ' FROM qryMBOAnnualProgramReportTable4_7C
      ' Crosstab Net x Disposition
      ' SELECT
      '     Net, NetGroup, Order
      '     1, R, F, 5  (Dispositions)


      Dim qdf As QueryDef
220   Set qdf = CurrentDb.QueryDefs("qryMBOAnnualProgramReportTable4_7A")
230   qdf.Parameters("argProgram").value = strProgram
240   qdf.Parameters("argLocation").value = strLocation
      Dim rst As DAO.Recordset
250   Set rst = qdf.OpenRecordset

      Dim strNet As String
      Dim strNetGroup As String
      Dim lngCaptures1 As Long
      Dim lngCapturesR As Long
      Dim lngCapturesF As Long
      Dim lngCaptures5 As Long
      Dim dblNetHours As Double
      Dim strNetGroupPrevious As String
      Dim lngCaptures1SubTotal As Long
      Dim lngCapturesRSubTotal As Long
      Dim lngCapturesFSubTotal As Long
      Dim lngCaptures5SubTotal As Long
      Dim dblNetHoursSubtotal As Double
      Dim lngCaptures1GrandTotal As Long
      Dim lngCapturesRGrandTotal As Long
      Dim lngCapturesFGrandTotal As Long
      Dim lngCaptures5GrandTotal As Long
      Dim dblNetHoursGrandTotal As Double

260   lngCaptures1SubTotal = 0
270   lngCapturesRSubTotal = 0
280   lngCapturesFSubTotal = 0
290   lngCaptures5SubTotal = 0

300   dblNetHoursSubtotal = 0
310   lngCaptures1GrandTotal = 0
320   lngCapturesRGrandTotal = 0
330   lngCapturesFGrandTotal = 0
340   lngCaptures5GrandTotal = 0
350   dblNetHoursGrandTotal = 0

360   strNetGroupPrevious = "99999"

      Dim row As Integer
370   row = 3

380   Do While Not rst.EOF

390       strNet = Nz(rst("Net"))

          ' skip blank nets
400       If strNet = "" Then GoTo loop_label
          
410       strNetGroup = Nz(rst("NetGroup"))
          ' skip nets that are not in a net group
420       If strNetGroup = "" Then GoTo loop_label

430       lngCaptures1 = 0
440       lngCapturesR = 0
450       lngCapturesF = 0
460       lngCaptures5 = 0
          
470       On Error Resume Next
480       lngCaptures1 = Nz(rst("1"))
490       lngCapturesR = Nz(rst("R"))
500       lngCapturesF = Nz(rst("F"))
510       lngCaptures5 = Nz(rst("5"))
520       On Error GoTo Err_label

530       dblNetHours = Nz(rst("NetHours"))

540       If strNetGroup <> strNetGroupPrevious Then
550             If strNetGroupPrevious <> "99999" Then
560                 range.Tables(1).Cell(row, 1).range.Text = strNetGroupPrevious & " - TOTAL"
570                 range.Tables(1).Cell(row, 2).range.Text = _
                        FormatNumberEnglish(dblNetHoursSubtotal, 1)
580                 range.Tables(1).Cell(row, 3).range.Text = lngCaptures1SubTotal
590                 range.Tables(1).Cell(row, 4).range.Text = lngCapturesRSubTotal
600                 range.Tables(1).Cell(row, 5).range.Text = lngCaptures1SubTotal + lngCapturesRSubTotal + lngCapturesFSubTotal + lngCaptures5SubTotal
610                 If dblNetHoursSubtotal > 0 Then
620                     range.Tables(1).Cell(row, 6).range.Text = _
                            FormatNumberEnglish((100 * lngCaptures1SubTotal) / dblNetHoursSubtotal, 1)
630                     range.Tables(1).Cell(row, 7).range.Text = _
                            FormatNumberEnglish((100 * (lngCaptures1SubTotal + lngCapturesRSubTotal + lngCapturesFSubTotal + lngCaptures5SubTotal)) / (dblNetHoursSubtotal), 1)
640                 End If
                    
                    Dim col As Integer
650                 For col = 1 To 7
660                     range.Tables(1).Cell(row, col).range.Font.Bold = True
670                     range.Tables(1).Cell(row, col).range.Shading.BackgroundPatternColor = RGB(217, 217, 217)
680                 Next
690                 range.Tables(1).Rows.Add
700                 row = row + 1
710                 For col = 1 To 7
720                     range.Tables(1).Cell(row, col).range.Font.Bold = False
730                     range.Tables(1).Cell(row, col).range.Shading.BackgroundPatternColor = vbWhite
740                 Next
750             Else
760                 lngCaptures1SubTotal = 0
770                 lngCapturesRSubTotal = 0
780                 lngCapturesFSubTotal = 0
790                 lngCaptures5SubTotal = 0
800                 dblNetHoursSubtotal = 0
810                 lngCaptures1GrandTotal = 0
820                 lngCapturesRGrandTotal = 0
830                 lngCapturesFGrandTotal = 0
840                 lngCaptures5GrandTotal = 0
850                 dblNetHoursGrandTotal = 0
860             End If
870             lngCaptures1SubTotal = 0
880             lngCapturesRSubTotal = 0
890             lngCapturesFSubTotal = 0
900             lngCaptures5SubTotal = 0
910             dblNetHoursSubtotal = 0
920             strNetGroupPrevious = strNetGroup
930        End If
940       range.Tables(1).Cell(row, 1).range.Text = strNet
950       range.Tables(1).Cell(row, 2).range.Text = _
          FormatNumberEnglish(dblNetHours, 1)
960       range.Tables(1).Cell(row, 3).range.Text = lngCaptures1
970       range.Tables(1).Cell(row, 4).range.Text = lngCapturesR
980       range.Tables(1).Cell(row, 5).range.Text = lngCaptures1 + lngCapturesR + lngCapturesF + lngCaptures5
990       If dblNetHours > 0 Then
1000          range.Tables(1).Cell(row, 6).range.Text = _
                  FormatNumberEnglish((100 * lngCaptures1) / dblNetHours, 1)
1010          range.Tables(1).Cell(row, 7).range.Text = _
                FormatNumberEnglish((100 * (lngCaptures1 + lngCapturesR + lngCapturesF + lngCaptures5)) / dblNetHours, 1)
1020          End If
1030      lngCaptures1SubTotal = lngCaptures1SubTotal + lngCaptures1
1040      lngCapturesRSubTotal = lngCapturesRSubTotal + lngCapturesR
1050      lngCapturesFSubTotal = lngCapturesFSubTotal + lngCapturesF
1060      lngCaptures5SubTotal = lngCaptures5SubTotal + lngCaptures5
1070      dblNetHoursSubtotal = dblNetHoursSubtotal + dblNetHours
1080      lngCaptures1GrandTotal = lngCaptures1GrandTotal + lngCaptures1
1090      lngCapturesRGrandTotal = lngCapturesRGrandTotal + lngCapturesR
1100      lngCapturesFGrandTotal = lngCapturesFGrandTotal + lngCapturesF
1110      lngCaptures5GrandTotal = lngCaptures5GrandTotal + lngCaptures5
1120      dblNetHoursGrandTotal = dblNetHoursGrandTotal + dblNetHours
1130      range.Tables(1).Rows.Add
1140      row = row + 1
1150      For col = 1 To 7
1160          range.Tables(1).Cell(row, col).range.Font.Bold = False
1170          range.Tables(1).Cell(row, col).range.Shading.BackgroundPatternColor = vbWhite
1180      Next
loop_label:
1190      rst.MoveNext
1200  Loop

      ' Last subtotal

1210  If strNetGroupPrevious <> "99999" Then
1220      range.Tables(1).Cell(row, 1).range.Text = strNetGroupPrevious & " - TOTAL"
1230      range.Tables(1).Cell(row, 2).range.Text = _
            FormatNumberEnglish(dblNetHoursSubtotal, 1)
1240      range.Tables(1).Cell(row, 3).range.Text = lngCaptures1SubTotal
1250      range.Tables(1).Cell(row, 4).range.Text = lngCapturesRSubTotal
1260      range.Tables(1).Cell(row, 5).range.Text = lngCaptures1SubTotal + lngCapturesRSubTotal + lngCapturesFSubTotal + lngCaptures5SubTotal
1270      If dblNetHoursSubtotal > 0 Then
1280          range.Tables(1).Cell(row, 6).range.Text = _
                  FormatNumberEnglish((100 * lngCaptures1SubTotal) / dblNetHoursSubtotal, 1)
1290          range.Tables(1).Cell(row, 7).range.Text = _
                  FormatNumberEnglish((100 * (lngCaptures1SubTotal + lngCapturesRSubTotal + lngCapturesFSubTotal + lngCaptures5SubTotal)) / dblNetHoursSubtotal, 1)
1300      End If
          
1310      For col = 1 To 7
1320          range.Tables(1).Cell(row, col).range.Font.Bold = True
1330          range.Tables(1).Cell(row, col).range.Shading.BackgroundPatternColor = RGB(217, 217, 217)
1340      Next
1350      range.Tables(1).Rows.Add
1360      row = row + 1
1370      For col = 1 To 7
1380          range.Tables(1).Cell(row, col).range.Font.Bold = False
1390          range.Tables(1).Cell(row, col).range.Shading.BackgroundPatternColor = vbWhite
1400      Next
1410  Else
1420      lngCaptures1SubTotal = 0
1430      lngCapturesRSubTotal = 0
1440      lngCapturesFSubTotal = 0
1450      lngCaptures5SubTotal = 0

1460      dblNetHoursSubtotal = 0
1470      lngCaptures1GrandTotal = 0
1480      lngCapturesRGrandTotal = 0
1490      lngCapturesFGrandTotal = 0
1500      lngCaptures5GrandTotal = 0
1510      dblNetHoursGrandTotal = 0
1520  End If
1530  lngCaptures1SubTotal = 0
1540  lngCapturesRSubTotal = 0
1550  lngCapturesFSubTotal = 0
1560  lngCaptures5SubTotal = 0

1570  dblNetHoursSubtotal = 0
1580  strNetGroupPrevious = strNetGroup

      ' grand total

1590  range.Tables(1).Cell(row, 1).range.Text = "GRAND TOTAL"
1600  range.Tables(1).Cell(row, 2).range.Text = _
          FormatNumberEnglish(dblNetHoursGrandTotal, 1)
1610  range.Tables(1).Cell(row, 3).range.Text = lngCaptures1GrandTotal
1620  range.Tables(1).Cell(row, 4).range.Text = lngCapturesRGrandTotal
1630  range.Tables(1).Cell(row, 5).range.Text = lngCaptures1GrandTotal + lngCapturesRGrandTotal + lngCapturesFGrandTotal + lngCaptures5GrandTotal
1640  If dblNetHoursGrandTotal > 0 Then
1650      range.Tables(1).Cell(row, 6).range.Text = _
              FormatNumberEnglish((100 * lngCaptures1GrandTotal) / dblNetHoursGrandTotal, 1)
1660      range.Tables(1).Cell(row, 7).range.Text = _
              FormatNumberEnglish((100 * (lngCaptures1GrandTotal + lngCapturesRGrandTotal + lngCapturesFGrandTotal + lngCaptures5GrandTotal)) / dblNetHoursGrandTotal, 1)
1670  End If

1680  For col = 1 To 7
1690      range.Tables(1).Cell(row, col).range.Font.Bold = True
1700      range.Tables(1).Cell(row, col).range.Shading.BackgroundPatternColor = RGB(166, 166, 166)
1710  Next

1720  rst.Close
1730  Set rst = Nothing
1740  Set qdf = Nothing

1750  range.Tables(1).Rows.WrapAroundText = False
1760  range.InsertParagraphAfter

1770  If lngCapturesFGrandTotal > 0 Then
1780      Set range = doc.Characters.Last
1790      If lngCapturesFGrandTotal = 1 Then
1800          range.InsertAfter "*** Marcel *** There was 1 foreign capture in " & strSeason & ". Please add a table footnote."
1810      Else
1820          range.InsertAfter "*** Marcel *** There were " & lngCapturesFGrandTotal & " foreign captures in " & strSeason & ". Please add a table footnote."
1830      End If
1840      range.InsertParagraphAfter
1850  End If
1860  Set range = doc.Characters.Last
1870  If lngCaptures5GrandTotal > 0 Then
1880      Set range = doc.Characters.Last
1890      If lngCaptures5GrandTotal = 1 Then
1900          range.InsertAfter "*** Marcel *** There was 1 replacement capture in " & strSeason & ". Please add a table footnote."
1910      Else
1920          range.InsertAfter "*** Marcel *** There were " & lngCaptures5GrandTotal & " foreign captures in " & strSeason & ". Please add a table footnote."
1930      End If
1940      range.InsertParagraphAfter
1950  End If

      ' ----------------------------------------------------------------------------------------------
      ' Create an Excel Worksheet

      Dim oSheet As Excel.Worksheet
1960  Set oSheet = InsertSheet(oBook, strSeason)
1970  oSheet.Name = strSeason & " Net usage"

1980  With oSheet

          Dim colNetGroup As Integer
          Dim colNet As Integer
          Dim colNetHours As Integer
          Dim colNewCaptures As Integer
          Dim colRecaptures As Integer
          Dim colForeign As Integer
          Dim colReplacement As Integer
          Dim colCaptures As Integer
          Dim colNewCapturesPer100NetHours As Integer
          Dim colTotalCapturesPer100NetHours As Integer
          Dim colFirst As Integer
          Dim colLast As Integer
          
          Dim strDisposition As String
          Dim lngCaptures As Long
          Dim fUnknownNets As Boolean
          
1990      fUnknownNets = False

2000      If 0 = DCount("*", "tblDETNETHours", "[Program] = '" & strProgram & "' AND [Location] = '" & strLocation & "'") Then
2010          .Cells(1, 1) = "There are no net hours recorded for the monitoring program " & strProgram & " at the site " & strLocation
2015          .Cells(1, 1).Font.Color = vbRed
2020          GoTo Excel_summary_label
2030      End If

          
          ' Dim col As Long
          ' Dim row As Long
          
2040      col = 1
          
2050      colFirst = col
2060      colNetGroup = col
2070      col = col + 1
2080      colNet = col
2090      col = col + 1
2100      colNetHours = col
2110      col = col + 1
2120      colNewCaptures = col
2130      col = col + 1
2140      colRecaptures = col
2150      col = col + 1
2160      colForeign = col
2170      col = col + 1
2180      colReplacement = col
2190      col = col + 1
2200      colCaptures = col
2210      col = col + 1
2220      colNewCapturesPer100NetHours = col
2230      col = col + 1
2240      colTotalCapturesPer100NetHours = col
2250      colLast = col

          ' Fill in headers
          
2260      row = 2
2270      .Cells(row, colNetGroup) = "Net Group"
2280      .Cells(row, colNet) = "Net"
2290      .Cells(row, colNetHours) = "Hours open"
2300      .Cells(row, colNewCaptures) = "New Captures"
2310      .Cells(row, colRecaptures) = "Returns + Repeats"
2320      .Cells(row, colForeign) = "Foreign"
2330      .Cells(row, colReplacement) = "Replacement"
2340      .Cells(row, colCaptures) = "Total Captures"
2350      .Cells(row, colNewCapturesPer100NetHours) = "New Captures per 100 Net Hours"
2360      .Cells(row, colTotalCapturesPer100NetHours) = "Total Captures per 100 Net Hours"
2370      .range(.Cells(row, colFirst), .Cells(row, colLast)).VerticalAlignment = xlCenter
2380      .range(.Cells(row, colFirst), .Cells(row, colLast)).Orientation = 90
          
2390      .columns(colNetHours).NumberFormat = "#0.0"
2400      .columns(colNewCapturesPer100NetHours).NumberFormat = "#0.0"
2410      .columns(colTotalCapturesPer100NetHours).NumberFormat = "#0.0"
        
          ' How many nets were used during the given year x season (NB One can have nets with 0 captures; we can have captures with unknown net)
          '    So use tblDETNets and add 1 for an "unknown net"
          ' Allocate an array(net,statistics) of variants
          ' Create a dictionary to store net, array index pairs
          
          ' qryMBOAnnualProgramReport_NetUsage_A
          ' ------------------------------------
          ' tblDETNetHours x tblPrograms x tblNets
          ' WHERE [argYear] = intYear
          ' WHERE [argLocation] = strLocation
          ' WHERE [argSeason] = strSeason
          ' GROUP BY NetID
          ' GROUP BY NetGroup
          ' NetHours = SUM NetHours
          ' Order by [Order]

2420      Set qdf = CurrentDb.QueryDefs("qryMBOAnnualProgramReport_NetUsage_A")
2430      qdf.Parameters("argYear").value = intYear
2440      qdf.Parameters("argLocation").value = strLocation
2450      qdf.Parameters("argSeason").value = strSeason
          
2460      Set rst = qdf.OpenRecordset
          
          Dim intRecordCount As Long
          Dim strNetID As String
          ' Dim dblNetHours As Double
          ' Dim strNetGroup As String
          Dim iNet As Integer
          
2470      iNet = 0

2480      If Not rst.EOF Then
2490          rst.MoveLast
2500          intRecordCount = rst.RecordCount
2510          rst.MoveFirst
              
              ' Reserve row #0 for unknown net
              
2520          ReDim varNetUsage(0 To intRecordCount, colFirst To colLast) As Variant
          
2530          For iNet = 0 To intRecordCount
2540              varNetUsage(iNet, colCaptures) = 0
2550          Next
        
2560          iNet = 0
              
              Dim dicNetUsage As Scripting.Dictionary
2570          Set dicNetUsage = New Scripting.Dictionary
          
2580          Do While Not rst.EOF
2590              strNet = Nz(rst("NetID"))
2600              dblNetHours = Nz(rst("NetHours"))
2610              strNetGroup = Nz(rst("NetGroup"))
2620              iNet = iNet + 1
                  
2630              varNetUsage(iNet, colNet) = strNet
2640              varNetUsage(iNet, colNetGroup) = strNetGroup
2650              varNetUsage(iNet, colNetHours) = dblNetHours
        
2660              If Not dicNetUsage.Exists(strNet) Then
2670                  Call dicNetUsage.Add(strNet, iNet)
2680              End If

2690              rst.MoveNext
2700          Loop
2710          rst.Close
2720          Set rst = Nothing
          
              Dim iNetMax As Integer
2730          iNetMax = iNet
              
              ' qryMBOAnnualProgramReport_NetUsage_B
              ' ------------------------------------
              ' tblCaptures x tblPrograms
              ' WHERE [argYear] = intYear
              ' WHERE [argLocation] = strLocation
              ' WHERE [argSeason] = strSeason
              ' WHERE Disposition NOT IN ("4","8")
              ' GROUP BY Net
              ' Captures = Count records
              ' Report Disposition, Net, Captures
              
              '    Dim qdf As QueryDef
2740          Set qdf = CurrentDb.QueryDefs("qryMBOAnnualProgramReport_NetUsage_B")
2750          qdf.Parameters("argYear").value = intYear
2760          qdf.Parameters("argLocation").value = strLocation
2770          qdf.Parameters("argSeason").value = strSeason
              
              '    Dim rst As DAO.Recordset
2780          Set rst = qdf.OpenRecordset
              
              ' Dim lngCaptures As Long
          
2790          Do While Not rst.EOF
          
2800              strDisposition = Nz(rst("Disposition"))
2810              strNet = Nz(rst("Net"))
2820              lngCaptures = Nz(rst("Captures"))
                  
2830              If dicNetUsage.Exists(strNet) Then
2840                  iNet = dicNetUsage.Item(strNet)
2850              Else
2860                  iNet = 0
2870                  fUnknownNets = True
2880              End If
2890              Select Case strDisposition
                  Case "1"
2900                  varNetUsage(iNet, colNewCaptures) = lngCaptures
2910              Case "R"
2920                  varNetUsage(iNet, colRecaptures) = lngCaptures
2930              Case "F"
2940                  varNetUsage(iNet, colForeign) = lngCaptures
2950              Case "5"
2960                  varNetUsage(iNet, colReplacement) = lngCaptures
2970              End Select
2980              varNetUsage(iNet, colCaptures) = varNetUsage(iNet, colCaptures) + lngCaptures
2990              rst.MoveNext
3000          Loop
3010          rst.Close
3020          Set rst = Nothing
              
              ' Output Net statistics
              
              'Dim intCaptures As Integer
              
3030          row = 3
              
3040          If fUnknownNets Then
3050            .Cells(row, colNetGroup) = "Unknown"
3060            .range(.Cells(row, colNetGroup), .Cells(row, colNetHours)).Merge
3070            .range(.Cells(row, colFirst), .Cells(row, colLast)).Interior.Color = vbYellow
3080            .Cells(row, colNewCaptures) = varNetUsage(0, colNewCaptures)
3090            .Cells(row, colRecaptures) = varNetUsage(0, colRecaptures)
3100            If Nz(varNetUsage(0, colForeign)) > 0 Then
3110                .Cells(row, colForeign) = varNetUsage(0, colForeign)
3120                .Cells(row, colForeign).Interior.Color = vbYellow
3130            End If
3140            If Nz(varNetUsage(0, colReplacement)) > 0 Then
3150                .Cells(row, colReplacement) = varNetUsage(0, colReplacement)
3160                .Cells(row, colReplacement).Interior.Color = vbYellow
3170            End If
3180            .Cells(row, colCaptures) = varNetUsage(0, colCaptures)
3190            row = row + 1
3200      End If
          
3210      For iNet = 1 To iNetMax
3220          .Cells(row, colNetGroup) = varNetUsage(iNet, colNetGroup)
3230          .Cells(row, colNet) = varNetUsage(iNet, colNet)
3240          .Cells(row, colNetHours) = Round(varNetUsage(iNet, colNetHours), 1)
3250          .Cells(row, colNewCaptures) = varNetUsage(iNet, colNewCaptures)
3260          .Cells(row, colRecaptures) = varNetUsage(iNet, colRecaptures)
3270          If Nz(varNetUsage(iNet, colForeign)) > 0 Then
3280              .Cells(row, colForeign) = varNetUsage(iNet, colForeign)
3290              .Cells(row, colForeign).Interior.Color = vbYellow
3300          End If
3310          If Nz(varNetUsage(iNet, colReplacement)) > 0 Then
3320              .Cells(row, colReplacement) = varNetUsage(iNet, colReplacement)
3330              .Cells(row, colReplacement).Interior.Color = vbYellow
3340          End If
3350          .Cells(row, colCaptures) = varNetUsage(iNet, colCaptures)
3360          .Cells(row, colNewCapturesPer100NetHours) = Nz(varNetUsage(iNet, colNewCaptures)) * 100 / varNetUsage(iNet, colNetHours)
3370          .Cells(row, colTotalCapturesPer100NetHours) = Nz(varNetUsage(iNet, colCaptures)) * 100 / varNetUsage(iNet, colNetHours)
              
3380          row = row + 1
3390      Next

3400      dicNetUsage.RemoveAll
          
3410  End If

      ' Summary by Net Group

      ' qryMBOAnnualProgramReport_NetUsage_C
      ' ------------------------------------
      ' tblDETNetHours x tblPrograms x tblNets
      ' WHERE [argYear] = intYear
      ' WHERE [argLocation] = strLocation
      ' WHERE [argSeason] = strSeason
      ' GROUP BY NetGroup
      ' NetHours = SUM NetHours
      ' Order by First [Order]
      ' Report NetGroup, NetHours

3420  Set qdf = CurrentDb.QueryDefs("qryMBOAnnualProgramReport_NetUsage_C")
3430  qdf.Parameters("argYear").value = intYear
3440  qdf.Parameters("argLocation").value = strLocation
3450  qdf.Parameters("argSeason").value = strSeason

3460  Set rst = qdf.OpenRecordset

      ' Dim intRecordCount As Long
      ' Dim strNetID As String
      ' Dim dblNetHours As Double
      ' Dim strNetGroup As String
      ' Dim iNet As Integer

3470  iNet = 0

3480  If Not rst.EOF Then
3490      rst.MoveLast
3500      intRecordCount = rst.RecordCount
3510      rst.MoveFirst
          
3520      ReDim varNetUsage(0 To intRecordCount, colFirst To colLast) As Variant

3530      For iNet = 0 To intRecordCount
3540          varNetUsage(iNet, colCaptures) = 0
3550      Next
        
3560      iNet = 0
        
          ' Dim dicNetUsage As scripting.Dictionary
3570      Set dicNetUsage = New Scripting.Dictionary
          
3580      Do While Not rst.EOF
                '   strNet = Nz(rst("NetID"))
3590            dblNetHours = Nz(rst("NetHours"))
3600            strNetGroup = Nz(rst("NetGroup"))
3610            iNet = iNet + 1
              
                '    varNetUsage(iNet, colNet) = strNet
3620            varNetUsage(iNet, colNetGroup) = strNetGroup
3630            varNetUsage(iNet, colNetHours) = dblNetHours
                
3640            If Not dicNetUsage.Exists(strNetGroup) Then
3650                Call dicNetUsage.Add(strNetGroup, iNet)
3660            End If
              
3670            rst.MoveNext
3680      Loop
3690      rst.Close
3700      Set rst = Nothing
          
          ' Dim iNetMax As Integer
          
3710      iNetMax = iNet
          
          ' qryMBOAnnualProgramReport_NetUsage_
          ' ------------------------------------
          ' tblCaptures x tblPrograms x tblNets
          ' WHERE [argYear] = intYear
          ' WHERE [argLocation] = strLocation
          ' WHERE [argSeason] = strSeason
          ' WHERE Disposition NOT IN ("4","8")
          ' GROUP BY NetGroup
          ' Captures = Count records
          ' Report Disposition, NetGroup, Captures
          
          '    Dim qdf As QueryDef
3720      Set qdf = CurrentDb.QueryDefs("qryMBOAnnualProgramReport_NetUsage_D")
3730      qdf.Parameters("argYear").value = intYear
3740      qdf.Parameters("argLocation").value = strLocation
3750      qdf.Parameters("argSeason").value = strSeason
          
          '    Dim rst As DAO.Recordset
3760      Set rst = qdf.OpenRecordset
          
          ' Dim lngCaptures As Long
          
3770      Do While Not rst.EOF

3780          strDisposition = Nz(rst("Disposition"))
3790          strNetGroup = Nz(rst("NetGroup"))
3800          lngCaptures = Nz(rst("Captures"))
              
3810          iNet = dicNetUsage.Item(strNetGroup)
3820          Select Case strDisposition
              Case "1"
3830              varNetUsage(iNet, colNewCaptures) = lngCaptures
3840          Case "R"
3850              varNetUsage(iNet, colRecaptures) = lngCaptures
3860          Case "F"
3870              varNetUsage(iNet, colForeign) = lngCaptures
3880          Case "5"
3890              varNetUsage(iNet, colReplacement) = lngCaptures
3900          End Select
3910          varNetUsage(iNet, colCaptures) = varNetUsage(iNet, colCaptures) + lngCaptures
3920          rst.MoveNext
3930      Loop
3940      rst.Close
3950      Set rst = Nothing
          
          ' Output Net Group Summary Statistics

          Dim rowTitleNetGroup As Long
          
3960      row = row + 1
3970      rowTitleNetGroup = row
3980      row = row + 1
          
3990      For iNet = 1 To iNetMax
4000            .Cells(row, colNetGroup) = varNetUsage(iNet, colNetGroup)
              
              '        If Nz(varNetUsage(iNet, colNet)) = "" Then
              '            .Cells(row, colNetGroup) = "Unknown"
              '            .range(.Cells(row, colNetGroup), .Cells(row, colNet)).Merge
              '            .range(.Cells(row, colFirst), .Cells(row, colLast)).Interior.color = vbYellow
              '        Else
              '            .Cells(row, colNet) = varNetUsage(iNet, colNet)
              '        End If
4010            .Cells(row, colNetHours) = Round(varNetUsage(iNet, colNetHours), 1)
4020            .Cells(row, colNewCaptures) = varNetUsage(iNet, colNewCaptures)
4030            .Cells(row, colRecaptures) = varNetUsage(iNet, colRecaptures)
4040            If Nz(varNetUsage(iNet, colForeign)) > 0 Then
4050                .Cells(row, colForeign) = varNetUsage(iNet, colForeign)
4060                .Cells(row, colForeign).Interior.Color = vbYellow
4070            End If
4080            If Nz(varNetUsage(iNet, colReplacement)) > 0 Then
4090                .Cells(row, colReplacement) = varNetUsage(iNet, colReplacement)
4100                .Cells(row, colReplacement).Interior.Color = vbYellow
4110            End If
4120            .Cells(row, colCaptures) = varNetUsage(iNet, colCaptures)
4130            .Cells(row, colNewCapturesPer100NetHours) = Nz(varNetUsage(iNet, colNewCaptures)) * 100 / varNetUsage(iNet, colNetHours)
4140            .Cells(row, colTotalCapturesPer100NetHours) = Nz(varNetUsage(iNet, colCaptures)) * 100 / varNetUsage(iNet, colNetHours)
                
4150            row = row + 1
4160      Next
       
4170  End If

      ' Global Summary (exclude unknown nets)

      ' qryMBOAnnualProgramReport_NetUsage_E
      ' ------------------------------------
      ' tblDETNetHours x tblPrograms x tblNets
      ' WHERE [argYear] = intYear
      ' WHERE [argLocation] = strLocation
      ' WHERE [argSeason] = strSeason
      ' GROUP BY NetGroup
      ' NetHours = SUM NetHours
      ' Report  NetHours

4180  Set qdf = CurrentDb.QueryDefs("qryMBOAnnualProgramReport_NetUsage_E")
4190  qdf.Parameters("argYear").value = intYear
4200  qdf.Parameters("argLocation").value = strLocation
4210  qdf.Parameters("argSeason").value = strSeason

4220  Set rst = qdf.OpenRecordset

4230  If Not rst.EOF Then
4240      dblNetHours = Nz(rst("NetHours"))
4250  Else
4260      dblNetHours = 0
4270  End If

          ' qryMBOAnnualProgramReport_NetUsage_F
          ' ------------------------------------
          ' tblCaptures x tblPrograms x tblNets
          ' WHERE [argYear] = intYear
          ' WHERE [argLocation] = strLocation
          ' WHERE [argSeason] = strSeason
          ' WHERE Disposition NOT IN ("4","8")
          ' Captures = Count records
          ' Report Disposition, Captures
          
          '    Dim qdf As QueryDef
4280      Set qdf = CurrentDb.QueryDefs("qryMBOAnnualProgramReport_NetUsage_F")
4290      qdf.Parameters("argYear").value = intYear
4300      qdf.Parameters("argLocation").value = strLocation
4310      qdf.Parameters("argSeason").value = strSeason

4320  Set rst = qdf.OpenRecordset
          
      Dim lngNewCaptures As Long
      Dim lngRecaptures As Long
      Dim lngForeign As Long
      Dim lngReplacement As Long

4330  lngNewCaptures = 0
4340  lngRecaptures = 0
4350  lngForeign = 0
4360  lngReplacement = 0


4370  Do While Not rst.EOF
4380      strDisposition = Nz(rst("Disposition"))
4390      lngCaptures = Nz(rst("Captures"))
4400      Select Case strDisposition
          Case "1"
4410          lngNewCaptures = lngCaptures
4420      Case "R"
4430          lngRecaptures = lngCaptures
4440      Case "F"
4450          lngForeign = lngCaptures
4460      Case "5"
4470          lngReplacement = lngCaptures
4480      End Select
4490      rst.MoveNext
4500  Loop
4510  rst.Close
4520  Set rst = Nothing

4530  lngCaptures = lngNewCaptures + lngRecaptures + lngForeign + lngReplacement

4540  row = row + 2

4550  .Cells(row, colNetGroup) = "Total"
4560  .range(.Cells(row, colNetGroup), .Cells(row, colNet)).Merge

4570  .Cells(row, colNetHours) = Round(dblNetHours, 1)
4580  .Cells(row, colNewCaptures) = lngNewCaptures
4590  .Cells(row, colRecaptures) = lngRecaptures
4600  If lngForeign > 0 Then
4610      .Cells(row, colForeign) = lngForeign
4620      .Cells(row, colForeign).Interior.Color = vbYellow
4630  End If
4640  If lngReplacement > 0 Then
4650      .Cells(row, colReplacement) = lngReplacement
4660      .Cells(row, colReplacement).Interior.Color = vbYellow
4670  End If
4680  .Cells(row, colCaptures) = lngCaptures
4690  If dblNetHours > 0 Then
4700      .Cells(row, colNewCapturesPer100NetHours) = lngNewCaptures * 100 / dblNetHours
4710      .Cells(row, colTotalCapturesPer100NetHours) = lngCaptures * 100 / dblNetHours
4720  End If

4730  .range(.columns(1), .columns(colLast)).AutoFit

4740  row = row + 2
4750  .Cells(rowTitleNetGroup, 1) = "Subtotals - Net Group"
4760  If fUnknownNets Then
4770      .Cells(row, 1) = "Captures in unknown nets, are not includes in the Total row"
4780  End If


Excel_summary_label:

      ' Process Season x Year x Net: Number of captures

      ' Delete the temporary table

4790  DoCmd.SetWarnings False
4800  On Error Resume Next
4810  DoCmd.DeleteObject acTable = acDefault, "tblMBOProgramReport_SeasonYearNet_Captures"
4820  On Error GoTo Err_label
4830  DoCmd.SetWarnings True

      ' Create and load  the temporary table

      ' Dim qdf As QueryDef
4840  Set qdf = CurrentDb.QueryDefs("qryMBOProgramReport_SeasonYearNet_Captures")
4850  qdf.Parameters("argSeason").value = strSeason
4860  qdf.Parameters("argLocation").value = strLocation
4870  qdf.Execute

      ' Dim strNet As String
4880  ReDim intCaptures(2005 To intYear) As Long

      Dim colNet2 As Long
      Dim colYearFirst As Long
      Dim colYearLast As Long
      Dim Y As Integer

4890  colNet2 = colLast + 3
4900  colYearFirst = colNet2 + 1
4910  colYearLast = colYearFirst + (intYear - 2005)

4920  row = 3

4930  .Cells(row, colNet2) = "Net"
4940  For Y = 2005 To intYear
4950      .Cells(row, colYearFirst + (Y - 2005)) = Y
4960  Next
4970  row = row + 1

      ' Dim rst As dao.Recordset
4980  Set rst = CurrentDb.OpenRecordset("qryMBOProgramReport_SeasonYearNet_Captures_Crosstab")
4990  Do While Not rst.EOF

5000      strNet = Nz(rst("Net"))
5010      On Error Resume Next
5020      For Y = 2005 To intYear
5030          intCaptures(Y) = Nz(rst(CStr(Y)))
5040      Next
5050      If Err.Number <> 0 Then Err.Clear

5060      .Cells(row, colNet2) = strNet
5070      For Y = 2005 To intYear
5080          If intCaptures(Y) > 0 Then
5090              .Cells(row, colYearFirst + (Y - 2005)) = intCaptures(Y)
5100          End If
5110      Next
5120      row = row + 1

5130      rst.MoveNext
5140  Loop
5150  rst.Close
5160  Set rst = Nothing

      ' Sort decreasing by current year

          Dim rangeData As Excel.range
          Dim rangeKey As Excel.range

5170      Set rangeData = .range(.Cells(2, colNet2), .Cells(row - 1, colYearLast))
5180      Set rangeKey = .range(.Cells(2, colYearLast), .Cells(row - 1, colYearLast))
5190      rangeData.Sort key1:=rangeKey, Order1:=xlDescending, Header:=xlYes

5200      .range(.columns(colNet2), .columns(colYearLast)).AutoFit
5210      .Cells(2, colNet2) = "Number of " & strSeason & " captures for each Net x Year"

5220  End With

5230  Set oSheet = Nothing

      'DD Error Handler Start
Exit_label:
5240       SysCmd acSysCmdClearStatus
5250       Exit Sub
Err_label:
5260       Select Case Err.Number
           Case Else
5270           Call LogError("basMBOAnnualProgramReport_NetUsage", "MBOAnnualProgramReportTable4_7_NetUsage")
5280       End Select
5290       Resume Exit_label
      'DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' WordGenerateTableNetUsage
'---------------------------------------------------------------------------------------
' entry:  range = a collapsed range that is the insertion point for the table
' exit:   range = range that includes the table

Private Sub WordGenerateTableNetUsage( _
    ByRef doc As Word.Document, _
    ByRef range As Word.range, _
    ByVal strSeason As String)

10    On Error GoTo Err_label

Dim row As Integer
Dim col As Integer

20    doc.Tables.Add range:=range, NumRows:=3, NumColumns:=7
    
30    range.Expand (wdTable)
40    With range.Tables(1)
    
50        .range.Style = "ddNetUsageData"
60        .LeftPadding = doc.Application.InchesToPoints(0.08)
70        .RightPadding = doc.Application.InchesToPoints(0.08)
80        .TopPadding = doc.Application.InchesToPoints(0.02)
    
    ' Centre the table
    
90        .Rows.Alignment = wdAlignRowCenter
    
100       .columns(1).Width = doc.Application.InchesToPoints(1.11)
110       .columns(2).Width = doc.Application.InchesToPoints(0.76)
120       .columns(3).Width = doc.Application.InchesToPoints(1.03)
130       .columns(4).Width = doc.Application.InchesToPoints(0.74)
140       .columns(5).Width = doc.Application.InchesToPoints(0.86)
150       .columns(6).Width = doc.Application.InchesToPoints(0.73)
160       .columns(7).Width = doc.Application.InchesToPoints(0.73)
        
170       .Cell(1, 1).range.Text = "Net"
180       .Cell(1, 2).range.Text = "Hours"
190       .Cell(1, 3).range.Text = "New"
200       .Cell(1, 4).range.Text = "Returns +"
210       .Cell(1, 5).range.Text = "Total"
220       Select Case strSeason
    Case "Owling"
230     .Cell(1, 6).range.Text = "Owls / 100 net hours"
240       Case Else
250     .Cell(1, 6).range.Text = "Birds / 100 net hours"
260       End Select
 
270       .Cell(2, 2).range.Text = "open"
280       .Cell(2, 3).range.Text = "Captures"
290       .Cell(2, 4).range.Text = "Repeats"
300       .Cell(2, 5).range.Text = "Captures"
310       .Cell(2, 6).range.Text = "New"
320       .Cell(2, 7).range.Text = "Total"
    
          ' Format Header Row
          
330       Call FormatWordTableRowAsHeader(.Rows(1))
340       Call FormatWordTableRowAsHeader(.Rows(2))
        
    ' Format Column 1 - Left Alignment

350       .Cell(3, 1).range.ParagraphFormat.Alignment = wdAlignParagraphLeft

360   .Rows(1).HeadingFormat = True
370   .Rows(2).HeadingFormat = True

    ' Merge
    
380       .Cell(1, 1).Merge .Cell(2, 1)
390       .Cell(1, 6).Merge .Cell(1, 7)
400       .Cell(1, 1).VerticalAlignment = wdCellAlignVerticalCenter

' Repeat heading row at the top of subsequent pages


410   .Rows.WrapAroundText = False

420   End With

'DD Error Handler Start
Exit_label:



430        Exit Sub
Err_label:
440        Select Case Err.Number
     Case Else
450       Call LogError("basMBOAnnualProgramReport_NetUsage", "WordGenerateTableNetUsage")
460        End Select
470        Resume Exit_label
'DD Error Handler End

End Sub
