Option Compare Database
Option Explicit

'---------------------------------------------------------------------------------------
' MBOAnnualProgramReport_NSWO_Age_Sex
'---------------------------------------------------------------------------------------

Public Sub MBOAnnualProgramReport_NSWO_Age_Sex( _
    ByVal intYear As Integer, _
    ByVal strLocation As String, _
    ByRef oExcel As Excel.Application, _
    ByRef oBook As Excel.Workbook)

10       On Error GoTo Err_label

      ' Create an Excel Worksheet

      Dim oSheet As Excel.Worksheet
20    Set oSheet = InsertSheet(oBook, "Owling")
30    oSheet.Name = "Owling (NSWO only) Age Sex"

40    With oSheet

      ' Age

      Dim row As Long
      Dim col As Long
      Dim strAge As String
      Dim strAgeAlphaCode As String
      Dim strAgeDescription As String
      Dim intCountIndividuals As Integer
      Dim intYearEx As Integer
      Dim colYearFirst As Integer
      Dim colYearLast As Integer
50    ReDim intTotalIndividuals(2005 To intYear)

60    For intYearEx = 2005 To intYear
70        intTotalIndividuals(intYearEx) = 0
80    Next

90    .Cells(3, 1) = "Age"
100   For intYearEx = 2005 To intYear
110       col = intYearEx - 2005 + 4
120       .Cells(3, col) = intYearEx
130   Next

140   colYearFirst = 4
150   colYearLast = intYear - 2005 + colYearFirst

160   row = 4

      Dim rst As DAO.Recordset
170   Set rst = CurrentDb.OpenRecordset("qryMBOAnnualProgramReport_NSWOAge_B_Crosstab")
180   Do While Not rst.EOF
190       strAge = Nz(rst("Age"))
200       strAgeAlphaCode = Nz(rst("AgeAlphaCode"))
210       strAgeDescription = Nz(rst("AgeDescription"))
220       .Cells(row, 1) = strAge
230       .Cells(row, 2) = strAgeAlphaCode
240       .Cells(row, 3) = strAgeDescription
250       For intYearEx = 2005 To intYear
260           On Error Resume Next
270           intCountIndividuals = Nz(rst(CStr(intYearEx)))
280           If Err.Number <> 0 Then
290               Err.Clear
300           Else
310               col = intYearEx - 2005 + 4
320               If intCountIndividuals > 0 Then
330                   .Cells(row, col) = intCountIndividuals
340                   intTotalIndividuals(intYearEx) = intTotalIndividuals(intYearEx) + intCountIndividuals
350               End If
360           End If
370           On Error GoTo Err_label
380       Next
390       rst.MoveNext
400       row = row + 1
410   Loop
420   rst.Close
430   Set rst = Nothing

440   For intYearEx = 2005 To intYear
450       col = intYearEx - 2005 + 4
460       If intTotalIndividuals(intYearEx) > 0 Then
470           .Cells(row, col) = intTotalIndividuals(intYearEx)
480       End If
490   Next
500   .range(.Cells(row, colYearFirst), .Cells(row, colYearLast)).Font.Bold = True

510   row = row + 2

      'Dim rst As DAO.Recordset
520   Set rst = CurrentDb.OpenRecordset("qryMBOAnnualProgramReport_NSWOAge_B_Crosstab")
530   Do While Not rst.EOF
540       strAge = Nz(rst("Age"))
550       strAgeAlphaCode = Nz(rst("AgeAlphaCode"))
560       strAgeDescription = Nz(rst("AgeDescription"))
570       .Cells(row, 1) = strAge
580       .Cells(row, 2) = strAgeAlphaCode
590       .Cells(row, 3) = strAgeDescription
600       For intYearEx = 2005 To intYear
610           On Error Resume Next
620           intCountIndividuals = Nz(rst(CStr(intYearEx)))
630           If Err.Number <> 0 Then
640               Err.Clear
650           Else
660               col = intYearEx - 2005 + 4
670               If intCountIndividuals > 0 Then
680                   .Cells(row, col) = intCountIndividuals / intTotalIndividuals(intYearEx)
690               End If
700           End If
710           On Error GoTo Err_label
720       Next
730       rst.MoveNext
740       .range(.Cells(row, colYearFirst), .Cells(row, colYearLast)).NumberFormat = "0%"
750       row = row + 1
760   Loop
770   rst.Close
780   Set rst = Nothing

790   row = row + 2

      ' Sex

      Dim strSex As String
      Dim strSexDescription As String

800   For intYearEx = 2005 To intYear
810       intTotalIndividuals(intYearEx) = 0
820   Next

830   .Cells(row, 1) = "Sex"
840   For intYearEx = 2005 To intYear
850       col = intYearEx - 2005 + 4
860       .Cells(row, col) = intYearEx
870   Next

880   colYearFirst = 4
890   colYearLast = intYear - 2005 + colYearFirst

900   row = row + 1

      'Dim rst As DAO.Recordset
910   Set rst = CurrentDb.OpenRecordset("qryMBOAnnualProgramReport_NSWOSex_B_Crosstab")
920   Do While Not rst.EOF
930       strSex = Nz(rst("Sex"))
940       strSexDescription = Nz(rst("SexDescription"))
950       .Cells(row, 1) = strSex
960       .Cells(row, 3) = strSexDescription
970       For intYearEx = 2005 To intYear
980           On Error Resume Next
990           intCountIndividuals = Nz(rst(CStr(intYearEx)))
1000          If Err.Number <> 0 Then
1010              Err.Clear
1020          Else
1030              col = intYearEx - 2005 + 4
1040              If intCountIndividuals > 0 Then
1050                  .Cells(row, col) = intCountIndividuals
1060                  intTotalIndividuals(intYearEx) = intTotalIndividuals(intYearEx) + intCountIndividuals
1070              End If
1080          End If
1090      On Error GoTo Err_label
1100      Next
1110      rst.MoveNext
1120      row = row + 1
1130  Loop
1140  rst.Close
1150  Set rst = Nothing

1160  For intYearEx = 2005 To intYear
1170      col = intYearEx - 2005 + 4
1180      If intTotalIndividuals(intYearEx) > 0 Then
1190          .Cells(row, col) = intTotalIndividuals(intYearEx)
1200      End If
1210  Next
1220  .range(.Cells(row, colYearFirst), .Cells(row, colYearLast)).Font.Bold = True

1230  row = row + 2

      'Dim rst As DAO.Recordset
1240  Set rst = CurrentDb.OpenRecordset("qryMBOAnnualProgramReport_NSWOSex_B_Crosstab")
1250  Do While Not rst.EOF
1260      strSex = Nz(rst("Sex"))
1270      strSexDescription = Nz(rst("SexDescription"))
1280      .Cells(row, 1) = strSex
1290      .Cells(row, 3) = strSexDescription
1300      For intYearEx = 2005 To intYear
1310          On Error Resume Next
1320          intCountIndividuals = Nz(rst(CStr(intYearEx)))
1330          If Err.Number <> 0 Then
1340              Err.Clear
1350          Else
1360              col = intYearEx - 2005 + 4
1370              If intCountIndividuals > 0 Then
1380                  .Cells(row, col) = intCountIndividuals / intTotalIndividuals(intYearEx)
1390              End If
1400          End If
1410          On Error GoTo Err_label
1420      Next
1430      rst.MoveNext
1440      .range(.Cells(row, colYearFirst), .Cells(row, colYearLast)).NumberFormat = "0%"
1450      row = row + 1
1460  Loop
1470  rst.Close
1480  Set rst = Nothing







1490  .range(.columns(1), .columns(colYearLast)).AutoFit

1500  .Cells(1, 1) = "NSWO Age and Sex"
            
1510  End With
        
        
        
        

          
         

          'DD Error Handler Start
Exit_label:
1520      Exit Sub
Err_label:
1530      Select Case Err.Number
          Case Else
1540     Call LogError("Module1", "MBOAnnualProgramReport_NSWO_Age_Sex")
1550      End Select
1560      Resume Exit_label
          ' DD Error Handler End
    End Sub
