'---------------------------------------------------------------------------------------
' Module    : frmFormOperations
' Author    : David Davey
'---------------------------------------------------------------------------------------

Option Compare Database
Option Explicit

'---------------------------------------------------------------------------------------
' OpenForm
'
' Open a form in Form view
' The opened form becomes the active form
' If the form was already open and minimized, then it is restored
'
'---------------------------------------------------------------------------------------
 
Public Sub OpenForm(Formname As String)
10    On Error GoTo Err_label

20    On Error Resume Next
30    DoCmd.OpenForm Formname
40    On Error GoTo Err_label

      'DD Error Handler Start
Exit_label:
50         Exit Sub
Err_label:
60         Select Case Err.Number
           Case Else
70              Call LogError("basFormOperations", "OpenForm", Formname)
80         End Select
90         Resume Exit_label
      'DD Error Handler End
End Sub
