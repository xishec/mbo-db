Option Compare Database
Option Explicit

'Public Declare Sub sleep Lib "kernel32" Alias "Sleep" (ByVal dwMilliseconds As Long)


#If VBA7 Then
    Public Declare PtrSafe Sub Sleep Lib "kernel32" (ByVal Milliseconds As LongPtr)
#Else
    Public Declare Sub Sleep Lib "kernel32" (ByVal Milliseconds As Long)
#End If

Public Function Sleep_Test()
    Dim i As Integer
    For i = 1 To 5
        Sleep (2000)
        Debug.Print (i)
    Next
End Function
