Option Compare Database
Option Explicit

Private intYearFirst As Integer
Private intYearLast As Integer
Private strLocation As String
Private strSeason As String
Private wd As Word.Application
Private doc As Word.Document
Private oExcel As Excel.Application
Private oBook As Excel.Workbook
Private fld As Integer
Private strStat As String ' "Species", "Top10"
Private fDebug As Boolean

Private oSheet As Excel.Worksheet

'---------------------------------------------------------------------------------------
' MBO10YearProgramReportVolunteers
'---------------------------------------------------------------------------------------
 
Public Sub MBO10YearProgramReportVolunteers( _
    ByRef fValid As Boolean, _
    ByVal argYearFirst As Integer, _
    ByVal argYearLast As Integer, _
    ByVal argLocation As String, _
    ByRef arg_wd As Word.Application, _
    ByRef arg_doc As Word.Document, _
    ByRef arg_excel As Excel.Application, _
    ByRef arg_book As Excel.Workbook, _
    ByVal arg_debug As Boolean)
           
      ' Save parameters

10    On Error GoTo Err_label

20    intYearFirst = argYearFirst
30    intYearLast = argYearLast
40    strLocation = argLocation
50    Set wd = arg_wd
60    Set doc = arg_doc
70    Set oExcel = arg_excel
80    Set oBook = arg_book
90    fDebug = arg_debug

      Const colYearFirst As Long = 6

100   Set oSheet = InsertSheet(oBook, "Global")
110   oSheet.Name = "Volunteers"

      Dim lngVolunteerID As Long
      Dim strVolunteerCode As String
      Dim strVolunteerLastname As String
      Dim strVolunteerFirstnames As String
      Dim strVolunteerFullname As String
      Dim intYear As Integer
      Dim row As Long
      Dim strSQL As String
      Dim qdf As DAO.QueryDef
      Dim rst As DAO.Recordset
      Dim lngVolunteerID_Prior As Long

120   With oSheet

130   row = 1
140   .Cells(row, 1) = "ID"
150   .Cells(row, 2) = "Code"
160   .Cells(row, 3) = "Surname"
170   .Cells(row, 4) = "First Names"
180   .Cells(row, 5) = "Full Name"

190   For intYear = intYearFirst To intYearLast
200       .Cells(row, colYearFirst + intYear - intYearFirst) = intYear
210   Next

      ' qryMBO10YearProgramReportVolunteers_Banders
      ' -------------------------------------------
      ' tblCaptures x tblPrograms
      '
      ' WHERE Location = [argLocation]          "MBO"
      ' HAVING YearEx BETWEEN [argYearFirst] AND [argYearLast]
      ' VolunteerCode: Trim(nz([Bander]))     HAVING Not In ("","?","0")
      '
      ' GROUP BY VolunteerCode, YearEx
      '
      ' SELECT VolunteerCode, YearEx

      ' = = = = = = = = = =

      ' qryMBO10YearProgramReportVolunteers_Scribes
      ' -------------------------------------------
      ' tblCaptures x tblPrograms
      '
      ' WHERE Location = [argLocation]          "MBO"
      ' HAVING YearEx BETWEEN [argYearFirst] AND [argYearLast]
      ' VolunteerCode: Trim(nz([Scribe]))     HAVING Not In ("","?","0")
      '
      ' GROUP BY VolunteerCode, YearEx
      '
      ' SELECT VolunteerCode, YearEx

      ' = = = = = = = = = =

      ' qryMBO10YearProgramReportVolunteers_ByWeek
      ' -------------------------------------------------
      ' tblVolunteers x tblVolunteersByWeek x tblPrograms
      '
      ' HAVING YearEx BETWEEN [argYearFirst] AND [argYearLast]
      ' WHERE Location = [argLocation]          "MBO"
      '
      ' SELECT VolunteerCode, YearEx

      ' = = = = = = = = = =

      ' qryMBO10YearProgramReportVolunteers_Union
      ' -----------------------------------------
      ' SELECT * FROM qryMBO10YearProgramReportVolunteers_Banders
      ' Union
      ' SELECT * FROM  qryMBO10YearProgramReportVolunteers_ByWeek
      ' UNION
      ' SELECT * FROM qryMBO10YearProgramReportVolunteers_Scribes
      '
      ' SELECT VolunteerCode, YearEx

      ' = = = = = = = = = =

      ' tblMBO10YearProgramReportVolunteers_Temp
      ' ----------------------------------------
      ' VolunteerID
      ' YearEx

      ' qryMBO10YearProgramReportVolunteers_Append
      ' ---------------------------------------------------------
      ' qryMBO10YearProgramReportVolunteers_Union x tblVolunteers
      ' Append to tblMBO10YearProgramReportVolunteers_Temp

220   CurrentDb.Execute "DELETE * FROM tblMBO10YearProgramReportVolunteers_Temp"

230   strSQL = "qryMBO10YearProgramReportVolunteers_Append"
240   Set qdf = CurrentDb.QueryDefs(strSQL)
250   qdf.Parameters("argLocation").value = strLocation
260   qdf.Parameters("argYearFirst").value = intYearFirst
270   qdf.Parameters("argYearLast").value = intYearLast
280   qdf.Execute

      ' = = = = = = = = = =

      ' qryMBO10YearProgramReporVolunteers_Final
      ' ----------------------------------------------------------------------
      ' tblVolunteer LEFT OUTER JOIN tblMBO10YearProgramReportVolunteers_Temp
      '
      ' VolunteerID
      ' VolunteerCode
      ' VolunteerLastname
      ' VolunteerFirstnames
      ' VolunteerFullname: VolunteerFullname: [VolunteerFirstnames] & " " & [VolunteerLastName]
      ' YearEx
      '
      ' ORDER BY VolunteerLastname, VolunteerFirstnames, VolunteerCode. YearEx
      '
      ' SELECT VolunteerID, VolunteerCode, VolunteerLastname, VolunteerFirstnames, VolunteerFullname, YearEx

      ' Save the row#s for each volunteer in a dictionary

      Dim dic As Scripting.Dictionary
290   Set dic = New Scripting.Dictionary

300   strSQL = "qryMBO10YearProgramReporVolunteers_Final"
310   Set qdf = CurrentDb.QueryDefs(strSQL)
320   Set rst = qdf.OpenRecordset

330   row = 2

      Dim intYearVolunteerFirst As Integer

340   If Not rst.EOF Then
350       lngVolunteerID_Prior = -1

360       Do While Not rst.EOF
370           lngVolunteerID = Nz(rst("VolunteerID"))

380           If lngVolunteerID_Prior <> lngVolunteerID Then
390               If lngVolunteerID_Prior <> -1 Then
                      ' FTR
400                   row = row + 1
410               End If
                  ' HDR
420               strVolunteerCode = Nz(rst("VolunteerCode"))
430               strVolunteerLastname = Nz(rst("VolunteerLastname"))
440               strVolunteerFirstnames = Nz(rst("VolunteerFirstnames"))
450               strVolunteerFullname = Nz(rst("VolunteerFullname"))
460               lngVolunteerID_Prior = lngVolunteerID
470               .Cells(row, 1) = lngVolunteerID
480               .Cells(row, 2) = strVolunteerCode
490               .Cells(row, 3) = strVolunteerLastname
500               .Cells(row, 4) = strVolunteerFirstnames
510               .Cells(row, 5) = strVolunteerFullname
520               Call dic.Add(lngVolunteerID, row)
530           End If
              ' DETAIL
540           intYear = Nz(rst("YearEx"))
550           If intYear <> 0 Then
560               .range(.Cells(row, colYearFirst + intYear - intYearFirst), .Cells(row, colYearFirst + intYear - intYearFirst)).Interior.Color = RGB(200, 200, 200)
565               .Cells(row, colYearFirst + intYear - intYearFirst) = "x"
570           End If
580           rst.MoveNext
590       Loop
          ' FTR
600       row = row + 1
610   End If
620   rst.Close
630   Set rst = Nothing

      Dim strOverride As String

      ' Get and write the overrides

640   Set rst = CurrentDb.OpenRecordset("tblVolunteers_x_Years_Overrides")
650   Do While Not rst.EOF
660       lngVolunteerID = Nz(rst("VolunteerID"))
670       intYear = Nz(rst("YearEx"))
680       strOverride = Nz(rst("Override"))
690       If dic.Exists(lngVolunteerID) Then
700           row = dic.Item(lngVolunteerID)
701           If .Cells(row, colYearFirst + intYear - intYearFirst) <> "x" Then
710               .Cells(row, colYearFirst + intYear - intYearFirst) = strOverride
733           End If
720       End If

730       rst.MoveNext
740   Loop
750   rst.Close
760   Set rst = Nothing

770   .range(.columns(6), .columns(6 + intYearLast - intYearFirst + 2)).HorizontalAlignment = xlCenter
780   .range(.columns(1), .columns(6 + intYearLast - intYearFirst + 2)).AutoFit

790   .range("A2").Select
800   oExcel.ActiveWindow.FreezePanes = True

810   End With


      ' = = = = = Word = = = = =

      ' qryMBO10YearProgramReportVolunteers_Overrides_Add
      ' ---------------------------------------------------
      ' tblVolunteers_x_Years_Overrides
      '
      ' WHERE Override = "A"
      '
      ' SELECT VolunteerID, YearEx

      ' = = = = = = = = = =

      ' qryMBO10YearProgramReportVolunteers_Overrides_Delete
      ' ---------------------------------------------------
      ' tblVolunteers_x_Years_Overrides
      '
      ' WHERE Override = "D"
      '
      ' SELECT VolunteerID, YearEx

      ' = = = = = = = = = =

      ' qryMBO10YearProgramReportVolunteers_A
      ' ------------------------------------
      ' SELECT VolunteerID, YearEx FROM tblMBO10YearProgramReportVolunteers_Temp
      ' UNION
      ' SELECT VolunteerID, YearEx FROM qryMBO10YearProgramReportVolunteers_Overrides_Add

      ' = = = = = = = = = =

      ' qryMBO10YearProgramReportVolunteers_B
      ' ------------------------------------_
      ' qryMBO10YearProgramReporVolunteers_A LEFT OUTER JOIN qryMBO10YearProgramReporVolunteers_Overrides_Delete
      '
      ' WHERE tblVolunteers_x_Years_Overrides_Adds.VolunteerID = Null

      ' = = = = = = = = = =

      ' qryMBO10YearProgramReporVolunteers_C
      ' ---------------------------------------------------
      ' tblVolunteer, qryMBO10YearProgramReportVolunteers_B, tblVolunteer
      '
      ' VolunteerFullname: VolunteerFullname: [VolunteerFirstnames] & " " & [VolunteerLastName]
      ' YearEx
      '
      ' ORDER BY VolunteerLastname, VolunteerFirstnames, VolunteerID, YearEx
      '
      ' SELECT VolunteerID, VolunteerFullname, YearEx

      ' = = = = = = = = = =

      Dim range As Word.range

820   Set range = MoveInsertionPointToEndOfDocument(wd, doc)
830   range.InsertParagraphAfter

840   range.InsertBreak wdSectionBreakContinuous
850   With doc.Sections.Last.PageSetup
860       .LeftMargin = doc.Application.CentimetersToPoints(1.27)
870       .RightMargin = doc.Application.CentimetersToPoints(1.27)
880       .TopMargin = doc.Application.CentimetersToPoints(1.27)
890       .BottomMargin = doc.Application.CentimetersToPoints(1.27)
900   End With

910   With doc.Sections.Last.PageSetup.TextColumns
920       .SetCount NumColumns:=2
930       .Add EvenlySpaced:=True
940       .Spacing = doc.Application.CentimetersToPoints(0.6)
950   End With

      ' L1 control break report over qryMBO10YearProgramReporVolunteers_C
      ' L1 = VolunteerID
      ' Detail = YearEx

      'Dim lngVolunteerID As Long
      Dim lngVolunteerID_previous As Long
960   lngVolunteerID_previous = -99

970   strSQL = "qryMBO10YearProgramReporVolunteers_C"
980   Set qdf = CurrentDb.QueryDefs(strSQL)
990   Set rst = qdf.OpenRecordset

      Dim intYearEx As Integer
      ' Dim strVolunteerFullname As String

      Dim intState_Count As Integer
      Dim intState_Year1 As Integer
      Dim intState_Year2 As Integer
      Dim strList As String
      Dim strVolunteerFullName_Save As String
      Dim intCountYears As Integer
      Dim lngStrongStart As Long
      Dim lngStrongEnd As Long

1000  If Not rst.EOF Then

      '    get L1, details
1010      lngVolunteerID = Nz(rst("VolunteerID"))
1020      strVolunteerFullname = Nz(rst("VolunteerFullname"))
1030      intYearEx = Nz(rst("YearEx"))

      '    HR

      '    H1

1040      strVolunteerFullName_Save = strVolunteerFullname
          ' Debug.Print strVolunteerFullname & " ";
1050      intState_Count = 0
1060      strList = ""
1070      intCountYears = 0
          
      '    Detail
1080       Call AppendYear(intYearEx, intState_Count, intState_Year1, intState_Year2, strList)
1090       intCountYears = intCountYears + 1
           
1100       lngVolunteerID_previous = lngVolunteerID

1110       rst.MoveNext
1120       Do While Not rst.EOF
          
             ' get L1, details
1130          lngVolunteerID = Nz(rst("VolunteerID"))
1140          strVolunteerFullname = Nz(rst("VolunteerFullname"))
1150          intYearEx = Nz(rst("YearEx"))

1160          If lngVolunteerID <> lngVolunteerID_previous Then

      '           F1
1170              If intState_Count = 1 Then
1180                  If strList <> "" Then
1190                      strList = strList & ", "
1200                  End If
1210                  strList = strList & intState_Year1
1220              Else
1230                  If strList <> "" Then
1240                      strList = strList & ", "
1250                  End If
1260                  If intState_Year2 = intState_Year1 + 1 Then
1270                      strList = strList & intState_Year1 & ", " & intState_Year2
1280                  Else
1290                      strList = strList & intState_Year1 & "-" & intState_Year2
1300                  End If
1310              End If
                  
1320              lngStrongStart = range.End
1330              range.InsertAfter strVolunteerFullName_Save
1340              range.InsertAfter vbTab & strList
1350              range.InsertParagraphAfter
1360              range.ParagraphFormat.Style = "ddMultiYear_Volunteers"
                  
1370              If intCountYears >= 4 Then
1380                  doc.range(lngStrongStart, lngStrongStart + Len(strVolunteerFullName_Save)).Style = "Strong"
1390              End If
                      
      '           H1
1400              strVolunteerFullName_Save = strVolunteerFullname
1410              intState_Count = 0
1420              strList = ""
1430              lngVolunteerID_previous = lngVolunteerID
1440              intCountYears = 0
                  
1450          End If
              
          '   Detail
1460          Call AppendYear(intYearEx, intState_Count, intState_Year1, intState_Year2, strList)
1470          intCountYears = intCountYears + 1

1480          rst.MoveNext
1490      Loop
          
      '   F1
1500      If intState_Count = 1 Then
1510          If strList <> "" Then
1520              strList = strList & ", "
1530          End If
1540          strList = strList & intState_Year1
1550      Else
1560          If strList <> "" Then
1570              strList = strList & ", "
1580          End If
1590          If intState_Year2 = intState_Year1 + 1 Then
1600              strList = strList & intState_Year1 & ", " & intState_Year2
1610          Else
1620              strList = strList & intState_Year1 & "-" & intState_Year2
1630          End If
1640      End If
          
1650      lngStrongStart = range.End
1660      range.InsertAfter strVolunteerFullname
1670      range.InsertAfter vbTab & strList
1680      range.InsertParagraphAfter
1690      range.ParagraphFormat.Style = "ddMultiYear_Volunteers"
          
1700      If intCountYears >= 4 Then
1710          doc.range(lngStrongStart, lngStrongStart + Len(strVolunteerFullname)).Style = "Strong"
1720      End If
                  
      '   FR

1730  End If


          'DD Error Handler Start
Exit_label:
1740      Exit Sub
Err_label:
1750      Select Case Err.Number
          Case Else
1760     Call LogError("basMBO10YearProgramReporVolunteers", "MBO10YearProgramReportVolunteers")
1770      End Select
1780      Resume Exit_label
          ' DD Error Handler End

End Sub


'---------------------------------------------------------------------------------------
' AppendYear
'---------------------------------------------------------------------------------------

Private Sub AppendYear(ByVal intYearEx As Integer, ByRef intState_Count As Integer, ByRef intState_Year1 As Integer, _
                       ByRef intState_Year2 As Integer, ByRef strList As String)
                       
10       On Error GoTo Err_label

20        Select Case intState_Count
          Case 0:
30            intState_Count = 1
40            intState_Year1 = intYearEx
50        Case 1:
60            If intYearEx = intState_Year1 + 1 Then
70                intState_Count = 2
80                intState_Year2 = intYearEx
90            Else
100               If strList <> "" Then
110                   strList = strList & ", "
120               End If
130               strList = strList & CStr(intState_Year1)
140               intState_Count = 1
150               intState_Year1 = intYearEx
160           End If
170       Case 2:
180           If intYearEx = intState_Year2 + 1 Then
190               intState_Year2 = intYearEx
200           Else
210               If strList <> "" Then
220                   strList = strList & ", "
230               End If
240               If intState_Year2 = intState_Year1 + 1 Then
250                   strList = strList & CStr(intState_Year1) & "-" & CStr(intState_Year2)
260               Else
270                   strList = strList & CStr(intState_Year1) & "-" & CStr(intState_Year2)
280               End If
290               intState_Count = 1
300               intState_Year1 = intYearEx
310           End If
320       End Select

          

          'DD Error Handler Start
Exit_label:
330       Exit Sub
Err_label:
340       Select Case Err.Number
          Case Else
350            Call LogError("basMBO10YearProgramReporVolunteers", "AppendYear")
360       End Select
370       Resume Exit_label
          ' DD Error Handler End
                        
End Sub
