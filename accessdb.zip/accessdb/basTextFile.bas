'---------------------------------------------------------------------------------------
' Module: TextFile
' Author: David Davey
'---------------------------------------------------------------------------------------

Option Compare Database
Option Explicit


'---------------------------------------------------------------------------------------
' CreateHTMLDocument
'---------------------------------------------------------------------------------------

Public Sub CloseAndSaveHTMLDocument( _
    ByVal strBaseFilename As String, _
    ByRef strSaveFilepath As String, _
    ByRef ts As ADODB.Stream)

10    On Error GoTo Err_label

      Dim strSaveFilename As String
      Dim strSaveFolderPath As String
      
20    strSaveFolderPath = GetExportFolder()

30    strSaveFilename = strBaseFilename & _
          " generated " & _
           Format(Now, "yyyy-mm-dd hh\hnn") & _
          ".html"

40   strSaveFilepath = FileSaveDialogHTML(strSaveFilename, strSaveFolderPath, "")

50    If strSaveFilepath <> "" Then
60        strSaveFolderPath = FolderFromPath(strSaveFilepath)
          Call PutExportFolder(strSaveFolderPath)
70        ts.SaveToFile strSaveFilepath, adSaveCreateNotExist
80    End If

      'DD Error Handler Start
Exit_label:
90         Exit Sub
Err_label:
100        Select Case Err.Number
           Case Else
110       Call LogError("basTextFile", "CloseAndSaveHTMLDocument")
120        End Select
130        Resume Exit_label
      'DD Error Handler End

End Sub
