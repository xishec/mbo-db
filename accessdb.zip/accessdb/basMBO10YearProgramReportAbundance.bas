Option Compare Database
Option Explicit

' intAbundanceCounters() is allocated in MBO10YearProgramReportAbundance

Private intAbundanceCounters() As Integer  '  (AbundanceCategory: 1 to 7, colPeriodFirst to colPeriodLast)

' The following module constants are initialised in MBO10YearProgramReportAbundance

Private colSpecies As Integer
Private colPeriodFirst As Integer
Private colNOV As Integer
Private colDEC As Integer
Private colJAN As Integer
Private colFEB As Integer
Private colMAR As Integer
Private colSpringFirst As Integer
Private colSpringLast As Integer
Private colJUN As Integer
Private colJUL As Integer
Private colFallFirst As Integer
Private colFallLast As Integer
Private colPeriodLast As Integer
Private colDetailsBase As Integer

' The array of colour constants intAbundanceLineColour() is loaded in MBO10YearProgramReportSpeciesObservedAtMBO()

Private lngAbundanceLineColour(1 To 6) As Long

' The colour constant con_lngColourAlternate constant is loaded in MBO10YearProgramReportSpeciesObservedAtMBO()

Private con_lngColourAlternate As Long ' Background colour for alternate rows


''---------------------------------------------------------------------------------------
'' MBO10YearProgramReportAbundance
'' Appendix H
''
'' Called from                                               *** Suppressed: Reports > Abundance Chart  (fAbundanceChart = True)
''             DET > Reports > 5x-Year > section 5.1
''---------------------------------------------------------------------------------------
'
'Public Sub MBO10YearProgramReportAbundance( _
'    ByVal intYearFirst As Integer, _
'    ByVal intYearLast As Integer, _
'    ByVal strLocation As String, _
'    ByRef wd As Word.Application, _
'    ByRef doc As Word.Document, _
'    ByRef oExcel As Excel.Application, _
'    ByRef oBook As Excel.Workbook, _
'    ByVal fDebug As Boolean, _
'    Optional ByVal fAbundanceChart As Boolean = False)
'
'10    On Error GoTo Err_label
'
'      Dim intPeriodLastSpring As Integer
'      Dim intPeriodLastFall As Integer
'
'20    intPeriodLastSpring = getPeriodLast_Season("Spring")
'30    intPeriodLastFall = getPeriodLast_Season("Fall")
'
'      ' Initialise the module constants
'
'40    colSpecies = 1
'50    colPeriodFirst = colSpecies + 1
'
'60    If fAbundanceChart Then
'70        colJAN = colPeriodFirst
'80        colFEB = colJAN + 1
'90        colMAR = colFEB + 1
'100       colSpringFirst = colMAR + 1
'110       colSpringLast = colSpringFirst + intPeriodLastSpring - 1
'120       colJUN = colSpringLast + 1
'130       colJUL = colJUN + 1
'140       colFallFirst = colJUL + 1
'150       colFallLast = colFallFirst + intPeriodLastFall - 1
'160       colNOV = colFallLast + 1
'170       colDEC = colNOV + 1
'180       colPeriodLast = colDEC
'190   Else
'200       colNOV = colPeriodFirst
'210       colDEC = colNOV + 1
'220       colJAN = colDEC + 1
'230       colFEB = colJAN + 1
'240       colMAR = colFEB + 1
'250       colSpringFirst = colMAR + 1
'260       colSpringLast = colSpringFirst + intPeriodLastSpring - 1
'270       colJUN = colSpringLast + 1
'280       colJUL = colJUN + 1
'290       colFallFirst = colJUL + 1
'300       colFallLast = colFallFirst + intPeriodLastFall - 1
'310       colPeriodLast = colFallLast
'320   End If
'
'      ' Load lngAbundanceLineColour(1 to 6)
'
'330   lngAbundanceLineColour(1) = RGB(178, 161, 199)
'340   lngAbundanceLineColour(2) = RGB(0, 176, 240)
'350   lngAbundanceLineColour(3) = RGB(146, 208, 80)
'360   lngAbundanceLineColour(4) = RGB(255, 255, 0)
'370   lngAbundanceLineColour(5) = RGB(255, 192, 0)
'380   lngAbundanceLineColour(6) = RGB(255, 0, 0)
'
'390   con_lngColourAlternate = RGB(239, 245, 245)
'
'400   colDetailsBase = colPeriodLast + 1
'
'410   ReDim intAbundanceCounters(1 To 7, colPeriodFirst To colPeriodLast) As Integer
'
'      ' Output to Excel + generate summary statistics
'
''420   If Not fAbundanceChart Then
''430       Call ExcelOutput(intYearFirst, intYearLast, strLocation, oExcel, oBook, fDebug)
''440   End If
'
'      ' Output abundance data to tblMBO10YearProgramReport_Abundance_Temp
'
'450   SysCmd acSysCmdSetStatus, "Abundance - Generate Data"
'460   DoEvents
'
'470   Call LoadAbundanceTable(intYearFirst, intYearLast, fDebug)
'
'      Dim range As Word.range
'
'      Dim lngPageWidth As Long
'      Dim lngLeftMargin As Long
'      Dim lngRightMargin As Long
'
'480   lngPageWidth = doc.PageSetup.PageWidth
'490   lngLeftMargin = doc.PageSetup.LeftMargin
'500   lngRightMargin = doc.PageSetup.RightMargin
'
'      Dim lngXSpeciesStart As Long
'      Dim lngXPeriodWidth As Long
'      Dim lngNumberPeriods As Long
'      Dim lngXSpeciesWidth As Long
'
'510   Call TableWidth(doc, lngXSpeciesStart, lngXSpeciesWidth, lngNumberPeriods, lngXPeriodWidth, fAbundanceChart)
'
'520   If fAbundanceChart Then
'
'          ' Output the pictures
'
'530       SysCmd acSysCmdSetStatus, "Abundance Export to Word - Details"
'540       DoEvents
'
'550       Call Legend_Top(doc, lngPageWidth, lngLeftMargin, lngRightMargin, lngXSpeciesStart, lngXSpeciesWidth, lngNumberPeriods, lngXPeriodWidth)
'
'560       Set range = MoveInsertionPointToEndOfDocument(wd, doc)
'
'570       range.InsertParagraphAfter
'580       range.ParagraphFormat.Style = "ddBody"
'
'590       Set range = MoveInsertionPointToEndOfDocument(wd, doc)
'
'600       Call WordOutput_Detail(doc, lngPageWidth, lngLeftMargin, lngRightMargin, lngXSpeciesStart, lngXSpeciesWidth, lngNumberPeriods, lngXPeriodWidth, fAbundanceChart)
'
'610       Set range = MoveInsertionPointToEndOfDocument(wd, doc)
'
'620       range.InsertParagraphAfter
'630       range.ParagraphFormat.Style = "ddBody"
'
'640   Else
'
'          ' Output Summary
'
'650       SysCmd acSysCmdSetStatus, "Abundance Export to Word - Summary"
'660       DoEvents
'
'670       Set range = MoveInsertionPointToEndOfDocument(wd, doc)
'
'680       Call WordGenerateTableAbundance(doc, range, lngPageWidth, lngLeftMargin, lngRightMargin, lngXSpeciesStart, lngXSpeciesWidth, lngNumberPeriods, lngXPeriodWidth)
'
'          Dim table As Word.table
'690       Set table = range.Tables(1)
'
'          Dim row As Long
'          Dim col As Long
'          Dim intAbundanceCategory As Integer
'
'700       row = 2
'
'710       For intAbundanceCategory = 1 To 7
'720     For col = colPeriodFirst To colPeriodLast
'730         If intAbundanceCounters(intAbundanceCategory, col) = 0 Then
'740             table.Cell(row + intAbundanceCategory, col).range.Text = "-"
'750         Else
'760             table.Cell(row + intAbundanceCategory, col).range.Text = _
'                intAbundanceCounters(intAbundanceCategory, col)
'770         End If
'780         table.Cell(row + intAbundanceCategory, col).range.ParagraphFormat.Style = "ddMultiYearAbundanceSummaryData"
'790     Next
'800       Next
'
'810       SysCmd acSysCmdClearStatus
'820       DoEvents
'
'830   End If
'
'      'DD Error Handler Start
'Exit_label:
'840        Exit Sub
'Err_label:
'850        Select Case Err.Number
'           Case Else
'860     Call LogError("basMBO10YearProgramReportAbundance", "MBO10YearProgramReportAbundance")
'870        End Select
'880        Resume Exit_label
'      'DD Error Handler End
'
'End Sub

''---------------------------------------------------------------------------------------
'' ExcelOutput
''---------------------------------------------------------------------------------------
'' not called - needs changes
'
'Private Sub ExcelOutput( _
'    ByVal intYearFirst As Integer, _
'    ByVal intYearLast As Integer, _
'    ByVal strLocation As String, _
'    ByRef oExcel As Excel.Application, _
'    ByRef oBook As Excel.Workbook, _
'    ByVal fDebug As Boolean)
'
'      Dim oSheet As Excel.Worksheet
'
'      ' intAbundanceCounters( abundance category, column )
'      ' use abundance category 7 for the grand totals
'
'10    Set oSheet = InsertSheet(oBook, "Global")
'20    oSheet.Name = "Abundance_H"
'
'      Dim row As Long
'      Dim col As Integer
'
'      Dim strSQL As String
'      Dim qdf As dao.QueryDef
'      Dim rst As dao.Recordset
'
'      ' tblMBO10YearProgramReportSpecies
'      ' --------------------------------
'      ' Basically a copy of tblDETSpecies modified as follows:
'      ' Location = MBO
'      ' YearEx (report year) is in range
'      ' No restriction on Season
'      ' Removed ("TRFL","ALFL","WIFL","LSGO","GSGO","SNGO","UNSG","UNAC","UNEM","UNGU","UNSC","PAWA","UNPW")
'      ' Added SNGO = ("SNGO","GSGO","LSGO")
'      ' Added TRFL = ("TRFL","WIFL","ALFL")
'      '
'      ' Season, YearEx, Period, DateEx, Species, Banded, Returns, Repeats, Alien, Replacement, DET
'
'      ' qryMBO10YearProgramReportAbundance_YearsPresent_A
'      ' -------------------------------------------------
'      ' For each Season x YearEx x Period x Species: Sum the DET
'      ' -------------------------------------------------
'      ' tblMBO10YearProgramReportSpecies
'      ' WHERE Season IN ("Winter","Spring","Summer","Fall")
'      ' GROUP BY Season, YearEx, Period, Species
'      ' SumOfDET : SUM Nz(DET)
'      ' Report Season, YearEx, Period, Species, SumOfDET
'
'      ' qryMBO10YearProgramReportAbundance_YearsPresent_B
'      ' -------------------------------------------------
'      ' For each Season x Period x Species: Number of years where species was present for the season x period
'      ' -------------------------------------------------
'      ' qryMBO10YearProgramReportAbundance_YearsPresent_A
'      ' YearsPresent = COUNT IIf([SumOfDET]>0,1,0)
'      ' Report Season, Period, Species, YearEx, YearsPresent
'
'      ' qryMBO10YearProgramReportAbundance_CountDETDays_A
'      ' -------------------------------------------------
'      ' For each Season x YearEX x Period x DateEx: Sum of DET
'      ' -------------------------------------------------
'      ' tblMBO10YearProgramReportSpecies
'      ' Season IN ("Winter","Spring","Summer","Fall")
'      ' GROUP BY Season, YearEx, Period, DateEx
'      ' SUM DET
'      ' HAVING DET > 0
'      ' Report Season, YearEx, Period, DateEx, SumOfDET
'
'      ' qryMBO10YearProgramReportAbundance_CountDETDays_B
'      ' -------------------------------------------------
'      ' For each Season x Period : The number of DET Days
'      ' -------------------------------------------------
'      ' qryMBO10YearProgramReportAbundance_CountDETDays_A
'      ' GROUP BY Season,  Period
'      ' Count records
'      ' Report Season, Period, CountDETDays
'
'      ' qryMBO10YearProgramReportAbundance_TotalDET
'      ' -------------------------------------------------
'      ' For each Season x Period x Species: Sum of DET
'      ' -------------------------------------------------
'      ' qryMBO10YearProgramReportAbundance_YearsPresent_A
'      ' GROUP BY YearEx
'      ' SumOfDET = SUM SumOfDET
'      ' Report Season, Period, SumOfDET
'
'      ' qryMBO10YearProgramReportAbundance_A
'      ' -------------------------------------------------
'      ' qryMBO10YearProgramReportAbundance_YearsPresent_B
'      ' qryMBO10YearProgramReportAbundance_CountDETDays_B
'      ' qryMBO10YearProgramReportAbundance_TotalDET
'      ' tblSpecies
'      ' MeanDET = SumOfDET / CountDETDays
'      ' ORDER BY AOU
'      ' Report Season, Period, Species, SumOfDET, CountDETDays, YearsPresent, MeanDET, Abundance
'
'      Dim intPeriod As Integer
'
'30    With oSheet
'
'      ' The columns are Species, NOV, DEC, JAN, FEB, MAR, S1 to Smax, JUN, JUL, F1 to Fmax
'
'      Dim intPeriodLastSpring As Integer
'      Dim intPeriodLastFall As Integer
'
'40    intPeriodLastSpring = getPeriodLast_Season("Spring")
'50    intPeriodLastFall = getPeriodLast_Season("Fall")
'
'190   row = 1
'
'200   .Cells(row, colSpecies) = "Species"
'210   .Cells(row, colJAN) = "JAN"
'220   .Cells(row, colFEB) = "FEB"
'230   .Cells(row, colMAR) = "MAR"
'240   .Cells(row, colJUN) = "JUN"
'250   .Cells(row, colJUL) = "JUL"
'260   .Cells(row, colNOV) = "NOV"
'270   .Cells(row, colDEC) = "DEC"
'280   For intPeriod = 1 To intPeriodLastSpring
'290       .Cells(row, colSpringFirst + intPeriod - 1) = "S" & intPeriod
'300   Next
'310   For intPeriod = 1 To intPeriodLastFall
'320       .Cells(row, colFallFirst + intPeriod - 1) = "F" & intPeriod
'330   Next
'
'      ' Copy the headings from colSpecies .. colPeriodLast => colPeriodLast + 1 ..
'
'340   For col = colSpecies To colPeriodLast
'350       .Cells(row, col + colPeriodLast) = .Cells(row, col)
'360   Next
'
'' 380   ReDim intAbundanceCounters(1 To 7, colPeriodFirst To colPeriodLast) As Integer
'
'      Dim intAbundanceCategory As Integer
'
'370   For intAbundanceCategory = 1 To 7
'380       For col = colPeriodFirst To colPeriodLast
'390           intAbundanceCounters(intAbundanceCategory, col) = 0
'400       Next
'410   Next
'
'420   SysCmd acSysCmdSetStatus, "Abundance Export to Excel"
'430   DoEvents
'
'440   strSQL = "qryMBO10YearProgramReportAbundance_A"
'450   Set qdf = CurrentDb.QueryDefs(strSQL)
'460   Set rst = qdf.OpenRecordset
'
'      Dim strSpecies As String
'      Dim strSpeciesPrevious As String
'      Dim dblMeanDET As Double
'      Dim intYearsPresent As Integer
'      Dim intAbundance As Integer
'      Dim strSeason As String
'
'470   row = 2
'480   strSpeciesPrevious = ""
'
'      Dim intYearsRange As Integer
'490   intYearsRange = intYearLast - intYearFirst + 1
'
'500   Do While Not rst.EOF
'
'510       strSpecies = Nz(rst("Species"))
'
'520       SysCmd acSysCmdSetStatus, "Abundance Export to Excel - " & strSpecies
'530       DoEvents
'
'540       If strSpecies <> strSpeciesPrevious Then
'550           strSpeciesPrevious = strSpecies
'560           row = row + 1
'570           .Cells(row, colSpecies) = strSpecies
'580           .Cells(row, colPeriodLast + 1) = strSpecies
'590       End If
'600       dblMeanDET = Nz(rst("MeanDET"))
'610       intYearsPresent = Nz(rst("YearsPresent"))
'620       strSeason = Nz(rst("Season"))
'630       intPeriod = Nz(rst("Period"))
'
'640       intAbundance = getAbundance(dblMeanDET, intYearsPresent, strSeason, intPeriod, intYearFirst, intYearLast)
'
'650       Select Case strSeason
'          Case "Winter"
'660           Select Case intPeriod
'              Case 1
'670               col = colNOV
'680           Case 2
'690               col = colDEC
'720           Case 3
'730               col = colJAN
'740           Case 4
'750               col = colFEB
'760           Case 5
'770               col = colMAR
'780            End Select
'790       Case "Spring"
'800           col = colSpringFirst + intPeriod - 1
'810       Case "Summer"
'820           Select Case intPeriod
'              Case 1
'830               col = colJUN
'840           Case 2
'850               col = colJUL
'860           End Select
'870       Case "Fall"
'880           col = colFallFirst + intPeriod - 1
'890       End Select
'
'900       If intAbundance <> conAbundanceUnknown Then
'910           .Cells(row, col) = intAbundance
'920           .Cells(row, colDetailsBase + col - 1) = _
'                  FormatNumberEnglish(dblMeanDET, 1) & " (" & intYearsPresent & ")"
'930           intAbundanceCounters(intAbundance, col) = _
'                  intAbundanceCounters(intAbundance, col) + 1
'940           intAbundanceCounters(7, col) = intAbundanceCounters(7, col) + 1
'950       End If
'
'          Dim lngColour As Long
'960       Select Case intAbundance
'
'          Case conAbundanceVeryRare
'970           lngColour = RGB(178, 161, 199)
'980       Case conAbundanceRare
'990           lngColour = RGB(0, 176, 240)
'1000      Case conAbundanceUncommon
'1010          lngColour = RGB(146, 208, 80)
'1020      Case conAbundanceFairlyCommon
'1030          lngColour = vbYellow
'1040      Case conAbundanceCommon
'1050          lngColour = RGB(255, 192, 0)
'1060      Case conAbundanceAbundant
'1070          lngColour = vbRed
'1080      End Select
'1090      .Cells(row, col).Interior.Color = lngColour
'
'1100      rst.MoveNext
'1110  Loop
'1120  rst.Close
'1130  Set rst = Nothing
'
'1140  SysCmd acSysCmdSetStatus, "Abundance Export to Excel - Summary"
'1150  DoEvents
'
'1160  row = row + 1
'
'      ' Write out the abundance counters
'
'1170  .Cells(row + 1, 1) = "Very rare"
'1180  .Cells(row + 2, 1) = "Rare"
'1190  .Cells(row + 3, 1) = "Uncommon"
'1200  .Cells(row + 4, 1) = "Fairly common"
'1210  .Cells(row + 5, 1) = "Common"
'1220  .Cells(row + 6, 1) = "Abundant"
'1230  .Cells(row + 7, 1) = "TOTAL"
'
'1240  .Cells(row + 1, 1).Interior.Color = RGB(178, 161, 199)
'1250  .Cells(row + 2, 1).Interior.Color = RGB(0, 176, 240)
'1260  .Cells(row + 3, 1).Interior.Color = RGB(146, 208, 80)
'1270  .Cells(row + 4, 1).Interior.Color = vbYellow
'1280  .Cells(row + 5, 1).Interior.Color = RGB(255, 192, 0)
'1290  .Cells(row + 6, 1).Interior.Color = vbRed
'
'1300  .Cells(row + 7, 1).Font.Color = vbWhite
'1310  .Cells(row + 7, 1).Interior.Color = vbBlack
'1320  .Cells(row + 7, 1).Font.Bold = True
'
'
'1330  For intAbundanceCategory = 1 To 7
'1340      For col = colPeriodFirst To colPeriodLast
'1350          .Cells(row + intAbundanceCategory, col) = _
'                intAbundanceCounters(intAbundanceCategory, col)
'1360      Next
'1370  Next
'
'1380  .range(.Columns(colPeriodFirst), .Columns(colPeriodLast)).HorizontalAlignment = xlCenter
'1390  .range(.Columns(colPeriodLast + 2), .Columns(colPeriodLast + 2 + colPeriodLast - colPeriodFirst)).HorizontalAlignment = xlCenter
'1400  .range(.Columns(1), .Columns(63)).AutoFit
'
'1410  .range("A2").Select
'1420  oExcel.ActiveWindow.FreezePanes = True
'
'1430  End With
'
'1440  Set oSheet = Nothing
'
'End Sub

''---------------------------------------------------------------------------------------
'' LoadAbundanceTable tblMBO10YearProgramReport_Abundance_Temp
''---------------------------------------------------------------------------------------
''
'
'Private Sub LoadAbundanceTable(ByVal intYearFirst As Integer, ByVal intYearLast As Integer, ByVal fDebug As Boolean)
'
'      Dim strSQL As String
'      Dim qdf As dao.QueryDef
'      Dim rst As dao.Recordset
'      Dim row As Long
'      ' Dim col As Long
'      Dim strSpecies As String
'      Dim strSpeciesPrevious As String
'      Dim dblMeanDET As Double
'      Dim intYearsPresent As Integer
'      Dim intYearsRange As Integer
'      Dim intAbundance As Integer
'      Dim strSeason As String
'      Dim intPeriod As Integer
'
'      Dim intPeriodLastSpring As Integer
'      Dim intPeriodLastFall As Integer
'
'10    intPeriodLastSpring = getPeriodLast_Season("Spring")
'20    intPeriodLastFall = getPeriodLast_Season("Fall")
'
'      ' ZAP tblMBO10YearProgramReport_Abundance_Temp
'
'30       On Error GoTo Err_label
'
'40    DoCmd.SetWarnings False
'50    CurrentDb.Execute "DELETE * FROM tblMBO10YearProgramReport_Abundance_Temp"
'60    DoCmd.SetWarnings True
'
'            ' tblMBO10YearProgramReportSpecies
'            ' --------------------------------
'            ' Basically a copy of tblDETSpecies modified as follows:
'            ' Location = MBO
'            ' YearEx (report year) is in range
'            ' No restriction on Season
'            ' Removed ("TRFL","ALFL","WIFL","LSGO","GSGO","SNGO","UNSG","UNAC","UNEM","UNGU","UNSC","PAWA","UNPW")
'            ' Added SNGO = ("SNGO","GSGO","LSGO")
'            ' Added TRFL = ("TRFL","WIFL","ALFL")
'            '
'            ' Season, YearEx, Period, DateEx, Species, Banded, Returns, Repeats, Alien, Replacement, DET
'
'            ' qryMBO10YearProgramReportAbundance_YearsPresent_A
'            ' -------------------------------------------------
'            ' For each Season x YearEx x Period x Species: Sum the DET
'            ' -------------------------------------------------
'            ' tblMBO10YearProgramReportSpecies
'            ' WHERE Season IN ("Winter","Spring","Summer","Fall")
'            ' GROUP BY Season, YearEx, Period, Species
'            ' SumOfDET : SUM Nz(DET)
'            ' Report Season, YearEx, Period, Species, SumOfDET
'
'            ' qryMBO10YearProgramReportAbundance_YearsPresent_B
'            ' -------------------------------------------------
'            ' For each Season x Period x Species: Number of years where species was present for the season x period
'            ' -------------------------------------------------
'            ' qryMBO10YearProgramReportAbundance_YearsPresent_A
'            ' YearsPresent = COUNT IIf([SumOfDET]>0,1,0)
'            ' Report Season, Period, Species, YearEx, YearsPresent
'
'            ' qryMBO10YearProgramReportAbundance_CountDETDays_A
'            ' -------------------------------------------------
'            ' For each Season x YearEX x Period x DateEx: Sum of DET
'            ' -------------------------------------------------
'            ' tblMBO10YearProgramReportSpecies
'            ' Season IN ("Winter","Spring","Summer","Fall")
'            ' GROUP BY Season, YearEx, Period, DateEx
'            ' SUM DET
'            ' HAVING DET > 0
'            ' Report Season, YearEx, Period, DateEx, SumOfDET
'
'            ' qryMBO10YearProgramReportAbundance_CountDETDays_B
'            ' -------------------------------------------------
'            ' For each Season x Period : The number of DET Days
'            ' -------------------------------------------------
'            ' qryMBO10YearProgramReportAbundance_CountDETDays_A
'            ' GROUP BY Season,  Period
'            ' Count records
'            ' Report Season, Period, CountDETDays
'
'            ' qryMBO10YearProgramReportAbundance_TotalDET
'            ' -------------------------------------------------
'            ' For each Season x Period x Species: Sum of DET
'            ' -------------------------------------------------
'            ' qryMBO10YearProgramReportAbundance_YearsPresent_A
'            ' GROUP BY YearEx
'            ' SumOfDET = SUM SumOfDET
'            ' Report Season, Period, SumOfDET
'
'            ' qryMBO10YearProgramReportAbundance_A
'            ' -------------------------------------------------
'            ' qryMBO10YearProgramReportAbundance_YearsPresent_B
'            ' qryMBO10YearProgramReportAbundance_CountDETDays_B
'            ' qryMBO10YearProgramReportAbundance_TotalDET
'            ' tblSpecies
'            ' MeanDET = SumOfDET / CountDETDays
'            ' ORDER BY AOU
'            ' Report Season, Period, Species, SumOfDET, CountDETDays, YearsPresent, MeanDET, Abundance
'
'
'
'
'
'      Dim rstAbundance As dao.Recordset
'70    Set rstAbundance = CurrentDb.OpenRecordset("tblMBO10YearProgramReport_Abundance_Temp")
'
'80    strSQL = "qryMBO10YearProgramReportAbundance_A"
'90    Set qdf = CurrentDb.QueryDefs(strSQL)
'100   Set rst = qdf.OpenRecordset
'
'110   row = 1
'120   strSpeciesPrevious = ""
'
'
'      Dim intCountSpecies As Integer
'130   intCountSpecies = 0
'
'140   Do While Not rst.EOF
'
'150       strSpecies = Nz(rst("Species"))
'
'160       SysCmd acSysCmdSetStatus, "Load Abundance Table - " & strSpecies
'170       DoEvents
'
'180       If strSpecies <> strSpeciesPrevious Then
'
'190           If strSpeciesPrevious <> "" Then
'200               rstAbundance.Update
'210           End If
'220           intCountSpecies = intCountSpecies + 1
'
'230           If fDebug And intCountSpecies > 5 Then
'240               GoTo Exit_loop_label
'250           End If
'
'260           rstAbundance.AddNew
'270           rstAbundance("Species") = strSpecies
'280           rstAbundance("AOS") = Nz(rst("AOUOrder"))
'
'290           row = row + 1
'
'300           strSpeciesPrevious = strSpecies
'310       End If
'
'320       dblMeanDET = Nz(rst("MeanDET"))
'330       intYearsPresent = Nz(rst("YearsPresent"))
'340       strSeason = Nz(rst("Season"))
'350       intPeriod = Nz(rst("Period"))
'
'360       intAbundance = getAbundance(dblMeanDET, intYearsPresent, strSeason, intPeriod, intYearFirst, intYearLast)
'
'370       Select Case strSeason
'          Case "Winter"
'380           Select Case intPeriod
'              Case 1
'      '            col = colNOV
'390               rstAbundance("Nov") = intAbundance
'400           Case 2
'      '            col = colDEC
'410               rstAbundance("Dec") = intAbundance
'420           Case 3
'      '            col = colJAN
'430               rstAbundance("Jan") = intAbundance
'440           Case 4
'      '            col = colFEB
'450               rstAbundance("Feb") = intAbundance
'460           Case 5
'      '            col = colMAR
'470               rstAbundance("Mar") = intAbundance
'480            End Select
'490       Case "Spring"
'      '        col = colSpringFirst + intPeriod - 1
'500           If intPeriod <= intPeriodLastSpring Then
'510               rstAbundance("S" & intPeriod) = intAbundance
'520           End If
'530       Case "Summer"
'540           Select Case intPeriod
'              Case 1
'      '            col = colJUN
'550               rstAbundance("Jun") = intAbundance
'560           Case 2
'      '            col = colJUL
'570               rstAbundance("Jul") = intAbundance
'580           End Select
'590       Case "Fall"
'      '        col = colFallFirst + intPeriod - 1
'600           If intPeriod <= intPeriodLastFall Then
'610               rstAbundance("F" & intPeriod) = intAbundance
'620           End If
'630       End Select
'
'640       rst.MoveNext
'650   Loop
'660   rstAbundance.Update
'
'Exit_loop_label:
'
'670   rst.Close
'680   Set rst = Nothing
'
'
'          'DD Error Handler Start
'Exit_label:
'700       Exit Sub
'Err_label:
'710       Select Case Err.Number
'          Case Else
'720      Call LogError("basMBO10YearProgramReportAbundance", "LoadAbundanceTable")
'730       End Select
'740       Resume Exit_label
'          ' DD Error Handler End
'
'End Sub

'---------------------------------------------------------------------------------------
' Legend_Top
'---------------------------------------------------------------------------------------

Private Sub Legend_Top(ByRef doc As Word.Document, _
    ByVal lngPageWidth As Long, ByVal lngLeftMargin As Long, ByVal lngRightMargin As Long, _
    ByVal lngXSpeciesStart As Long, ByVal lngXSpeciesWidth As Long, _
    ByVal lngNumberPeriods As Long, ByVal lngXPeriodWidth As Long)
          
10    On Error GoTo Err_label
         
      Dim range As Word.range
      Dim row As Long
      Dim col As Long

'               doc.Application.Visible = True

20    With doc.PageSetup
30        .LeftMargin = lngLeftMargin
40        .RightMargin = lngRightMargin
50        .TopMargin = doc.Application.InchesToPoints(0.79)
60        .BottomMargin = doc.Application.InchesToPoints(0.79)
70    End With
          
80    Set range = MoveInsertionPointToEndOfDocument(doc.Application, doc)
90    range.InsertParagraphAfter

100   Set range = MoveInsertionPointToEndOfDocument(doc.Application, doc)

      '110   doc.tables.Add range:=range, NumRows:=6, NumColumns:=3

110   doc.Tables.Add range:=range, NumRows:=6, NumColumns:=3, DefaultTableBehavior:=wdWord9TableBehavior, _
          AutoFitBehavior:=wdAutoFitFixed

120   range.Expand (wdTable)
130   With range.Tables(1)

140     .TopPadding = doc.Application.CentimetersToPoints(0)
150     .BottomPadding = doc.Application.CentimetersToPoints(0)
160     .LeftPadding = doc.Application.CentimetersToPoints(0)
170     .RightPadding = doc.Application.CentimetersToPoints(0)
180     .Spacing = 0
190     .AllowPageBreaks = True
200     .AllowAutoFit = True

210       For row = 1 To 6
220           For col = 2 To 3
230             .Cell(row, col).LeftPadding = doc.Application.CentimetersToPoints(0.2)
240             .Cell(row, col).RightPadding = doc.Application.CentimetersToPoints(0.2)
250           Next
260       Next
       
270       .columns(1).Width = doc.Application.CentimetersToPoints(2.75)
280       .columns(2).Width = 20
290       .columns(3).Width = lngXSpeciesWidth + lngNumberPeriods * lngXPeriodWidth - .columns(1).Width - .columns(2).Width

300       .Cell(1, 1).range.Text = "Very rare"
310       .Cell(2, 1).range.Text = "Rare"
320       .Cell(3, 1).range.Text = "Uncommon"
330       .Cell(4, 1).range.Text = "Fairly common"
340       .Cell(5, 1).range.Text = "Common"
350       .Cell(6, 1).range.Text = "Abundant"
          
360       .Cell(1, 3).range.Text = "Generally limited to one occurrence (single individual or flock) per period"
370       .Cell(2, 3).range.Text = "Generally occurring in a period in at least two years, but with a mean daily count <1"
380       .Cell(3, 3).range.Text = "Generally occurring in a period annually, with a mean daily count between 1 and 4.9"
390       .Cell(4, 3).range.Text = "Generally occurring in a period annually, with a mean daily count between 5 and 9.9 "
400       .Cell(5, 3).range.Text = "Occurring in a period annually, with a mean daily count between 10 and 49.9"
410       .Cell(6, 3).range.Text = "Occurring in a period annually, with a mean daily count >50"
          
420       For row = 1 To 6
430           .Cell(row, 3).range.ParagraphFormat.Alignment = wdAlignParagraphLeft
440       Next
              
450       For row = 1 To 6
460           .Cell(row, 1).range.ParagraphFormat.Style = "ddMultiYearAbundanceTopLegendAbundanceLabel"
470           .Cell(row, 2).range.ParagraphFormat.Style = "ddMultiYearAbundanceTopLegendAbundanceImage"
480           .Cell(row, 3).range.ParagraphFormat.Style = "ddMultiYearAbundanceTopLegendAbundanceDescription"
490           .Cell(row, 1).VerticalAlignment = wdCellAlignVerticalCenter
500           .Cell(row, 1).VerticalAlignment = wdCellAlignVerticalCenter
510           .Cell(row, 3).VerticalAlignment = wdCellAlignVerticalCenter
520       Next
              
          ' Draw borders
          
530       For row = 1 To 6
540           .Rows(row).Borders(wdBorderTop).LineStyle = wdLineStyleSingle
550           For col = 1 To 3
560               .Cell(row, col).Borders(wdBorderLeft).LineStyle = wdLineStyleSingle
570           Next
580           .Cell(row, 3).Borders(wdBorderRight).LineStyle = wdLineStyleSingle
590       Next
600       .Rows(6).Borders(wdBorderBottom).LineStyle = wdLineStyleSingle
          
          Dim shpCanvas As Word.Shape
          Dim sh As Word.Shape
          
610       For row = 1 To 6
          
620           Set shpCanvas = doc.Shapes.AddCanvas(Left:=0, Top:=0, Width:=10, Height:=15, Anchor:=.Cell(row, 2).range)
                 
630           Set sh = shpCanvas.CanvasItems.AddLine( _
              BeginX:=0, _
              BeginY:=7, _
              EndX:=10, _
              EndY:=7)
640           sh.Line.Weight = row
650           sh.Line.ForeColor = lngAbundanceLineColour(row)
          
660       Next

670   End With

          'DD Error Handler Start
Exit_label:
680       Exit Sub
Err_label:
690       Select Case Err.Number
          Case Else
700      Call LogError("basMBO10YearProgramReportAbundance", "Legend_Top")
710       End Select
720       Resume Exit_label
          ' DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' TableWidth
'---------------------------------------------------------------------------------------
'
' For an 5-year report, the species width is just for the species code
' For an abundance chart, the species width is for the EN + FR names

Private Sub TableWidth(ByRef doc As Word.Document, _
    ByRef lngXSpeciesStart As Long, ByRef lngXSpeciesWidth As Long, _
    ByRef lngNumberPeriods As Long, ByRef lngXPeriodWidth As Long, _
    Optional fAbundanceChart As Boolean = False)
          
10    On Error GoTo Err_label

      Dim lngPageWidth As Long
      Dim lngLeftMargin As Long
      Dim lngRightMargin As Long
      
      Dim intPeriodLastSpring As Integer
      Dim intPeriodLastFall As Integer

20    intPeriodLastSpring = getPeriodLast_Season("Spring")
30    intPeriodLastFall = getPeriodLast_Season("Fall")

40    lngPageWidth = doc.PageSetup.PageWidth
50    lngLeftMargin = doc.PageSetup.LeftMargin
60    lngRightMargin = doc.PageSetup.RightMargin
70    lngNumberPeriods = 7 + intPeriodLastSpring + intPeriodLastFall
80    lngXSpeciesStart = 0
90    If fAbundanceChart Then
100       lngXSpeciesWidth = 250
110   Else
120       lngXSpeciesWidth = 37
130   End If
140   lngXPeriodWidth = (lngPageWidth - lngLeftMargin - lngRightMargin - lngXSpeciesWidth) / lngNumberPeriods - 0.1

          'DD Error Handler Start
Exit_label:
150       Exit Sub
Err_label:
160       Select Case Err.Number
          Case Else
170            Call LogError("basMBO10YearProgramReportAbundance", "TableWidth")
180       End Select
190       Resume Exit_label
          ' DD Error Handler End

End Sub

'---------------------------------------------------------------------------------------
' WordOutput_Detail
'---------------------------------------------------------------------------------------

Private Sub WordOutput_Detail(ByRef doc As Word.Document, _
    ByVal lngPageWidth As Long, ByVal lngLeftMargin As Long, ByVal lngRightMargin As Long, _
    ByVal lngXSpeciesStart As Long, ByVal lngXSpeciesWidth As Long, _
    ByVal lngNumberPeriods As Long, ByVal lngXPeriodWidth As Long, _
    Optional ByVal fAbundanceChart As Boolean = False)

10    On Error GoTo Err_label

      Dim intPeriodLastSpring As Integer
      Dim intPeriodLastFall As Integer

20    intPeriodLastSpring = getPeriodLast_Season("Spring")
30    intPeriodLastFall = getPeriodLast_Season("Fall")

      Dim lngSpeciesPerFirstPage As Integer

      Dim lngCanvasWidth As Long
40    lngCanvasWidth = lngXSpeciesWidth + lngNumberPeriods * lngXPeriodWidth + 2

50    If Not fAbundanceChart Then
60        lngSpeciesPerFirstPage = GetMBO10YearProgramReport_AbundanceRowsOnFirstPage()
70        If lngSpeciesPerFirstPage = 0 Then Exit Sub
80    End If

      Dim rst As DAO.Recordset

90    If fAbundanceChart Then

          ' qryMBO10YearProgramReport_AbundanceChart
          ' ----------------------------------------
          ' tblMBO10YearProgramReport_Abundance_Temp
          ' tblSpecies
          '
          ' SpEnglish: IIf(Nz([SpeciesEnglish])="",[SpeciesDescriptionMBO],[SpeciesEnglish])
          ' SpFrench: IIf(Nz([SpeciesFrenchEx])="",[SpeciesFrench],[SpeciesFrenchEx])
          ' SpScientific: IIf(Nz([SpeciesScientificEx])="",[SpeciesScientific],[SpeciesScientificEx])
          '
          ' ORDER BY AOS
          '
          ' SELECT * from tblMBO10YearProgramReport_Abundance_Temp, SpEnglish, SpFrench, SpScientific

100       Set rst = CurrentDb.OpenRecordset("qryMBO10YearProgramReport_AbundanceChart")
110   Else
120       Set rst = CurrentDb.OpenRecordset("SELECT * FROM tblMBO10YearProgramReport_Abundance_Temp ORDER BY AOS")
130   End If

      Dim range As Word.range
140   Set range = MoveInsertionPointToEndOfDocument(doc.Application, doc)

      Dim lngPageHeight As Long
      Dim lngFirstPageHeightRemaining As Long
      
150   lngPageHeight = doc.PageSetup.PageHeight - doc.PageSetup.TopMargin - doc.PageSetup.BottomMargin
160   lngFirstPageHeightRemaining = doc.PageSetup.PageHeight - doc.PageSetup.BottomMargin - range.Information(wdVerticalPositionRelativeToPage)

      Dim shpCanvas As Word.Shape

      Dim lngXPeriodStart As Long
170   lngXPeriodStart = lngXSpeciesStart + lngXSpeciesWidth

      Dim lngYSpeciesStart As Long
      Dim lngYSpeciesHeight As Long

180   lngYSpeciesStart = 10
190   lngYSpeciesHeight = 10

      Dim lngSpeciesPerPage As Long
200   lngSpeciesPerPage = (lngPageHeight / lngYSpeciesHeight) - 2

210   If fAbundanceChart Then
220       lngSpeciesPerFirstPage = (lngFirstPageHeightRemaining / lngYSpeciesHeight) - 2
230   End If

      Dim lngFirstCanvasHeight As Long
240   lngFirstCanvasHeight = lngSpeciesPerFirstPage * lngYSpeciesHeight + 10

      ' Calculate the number of species on the last page AND the height of the last canvas

      Dim lngSpeciesPerLastPage As Long
      Dim lngLastCanvasHeight As Long
      Dim intLastPage As Integer

      Dim lngCountSpecies As Long
250   lngCountSpecies = DCount("*", "tblMBO10YearProgramReport_Abundance_Temp", "True")
260   lngCountSpecies = lngCountSpecies - lngSpeciesPerFirstPage

270   intLastPage = 2

280   Do While True
290       If lngCountSpecies <= (lngSpeciesPerPage + 1) Then
300           lngSpeciesPerLastPage = lngCountSpecies
310           Exit Do
320       Else
330           lngCountSpecies = lngCountSpecies - lngSpeciesPerPage
340           intLastPage = intLastPage + 1
350       End If
360   Loop

370   lngLastCanvasHeight = (lngCountSpecies + 1) * lngYSpeciesHeight + 10

      ' Period col => lngXPeriod_Start + lngXPeriodWidth * col TO lngXPeriod_Start + (lngXPeriodWidth * (col+1) - 1
      ' Species row => lngYSpeciesStart + row * lngYSpeciesHeight TO lngYSpeciesStart * (row+1) + lngYSpeciesHeight - 1

      Dim lngLineWidth As Long
380   lngLineWidth = 1

      Dim row As Long
      Dim col As Long
      Dim sh As Word.Shape
      Dim lngStart1 As Long
      Dim lngEnd1 As Long
      Dim range1 As Word.range

390   row = 0

      Dim intPage As Integer
400   intPage = 0

410   Do While Not rst.EOF

420       If (intPage = 0) Or (intPage = 1 And row >= lngSpeciesPerFirstPage) Or (intPage > 1 And row >= lngSpeciesPerPage) Then
          
430           If intPage >= 1 Then
              
                  ' Process end of page
                                    
                  ' row is the row# of the last species row, i.e. lngSpeciesPerPage
          
                  ' Draw white vertical lines between periods
                  ' Draw light blue vertical lines between seasons
                  
440               For col = colPeriodFirst To colPeriodLast
450                   Set sh = shpCanvas.CanvasItems.AddLine( _
                          BeginX:=lngXPeriodStart + lngXPeriodWidth * (col - colPeriodFirst), _
                          BeginY:=0, _
                          EndX:=lngXPeriodStart + lngXPeriodWidth * (col - colPeriodFirst), _
                          EndY:=lngYSpeciesStart * (row) + lngYSpeciesHeight - 1)
460                   sh.Line.Style = msoLineSingle
470                   sh.Line.Weight = 1
480                   sh.Line.ForeColor = RGB(255, 255, 255)
490                   Select Case col
                      Case colPeriodFirst, colSpringFirst, colJUN, colFallFirst, colNOV
500                       Set sh = shpCanvas.CanvasItems.AddLine( _
                              BeginX:=lngXPeriodStart + lngXPeriodWidth * (col - colPeriodFirst), _
                              BeginY:=lngYSpeciesStart, _
                              EndX:=lngXPeriodStart + lngXPeriodWidth * (col - colPeriodFirst), _
                              EndY:=lngYSpeciesStart * row + lngYSpeciesHeight - 1)
510                       sh.Line.Style = msoLineSingle
520                       sh.Line.Weight = 1
530                       sh.Line.ForeColor = RGB(161, 190, 237)
540                   End Select
550                   Set sh = shpCanvas.CanvasItems.AddLine( _
                          BeginX:=lngXPeriodStart + lngXPeriodWidth * (colPeriodLast - colPeriodFirst + 1), _
                          BeginY:=lngYSpeciesStart, _
                          EndX:=lngXPeriodStart + lngXPeriodWidth * (colPeriodLast - colPeriodFirst + 1), _
                          EndY:=lngYSpeciesStart * row + lngYSpeciesHeight - 1)
560                   sh.Line.Style = msoLineSingle
570                   sh.Line.Weight = 1
580                   sh.Line.ForeColor = RGB(161, 190, 237)
                  
590               Next

600               Set sh = shpCanvas.CanvasItems.AddLine( _
                      BeginX:=0, _
                      BeginY:=lngYSpeciesStart, _
                      EndX:=0, _
                      EndY:=lngYSpeciesStart * row + lngYSpeciesHeight - 1)
610               sh.Line.Style = msoLineSingle
620               sh.Line.Weight = 1
630               sh.Line.ForeColor = RGB(161, 190, 237)
                  
640           End If
          
              ' Page header
              
650           Set range = MoveInsertionPointToEndOfDocument(doc.Application, doc)
660           lngStart1 = range.start
670           lngEnd1 = range.End
680           Set range1 = doc.range(lngStart1, lngEnd1)

              Dim lngStart_before_page_break
690           lngStart_before_page_break = range.start

700           range.InsertBreak wdPageBreak
710           If intPage = 0 Then
720               Set shpCanvas = doc.Shapes.AddCanvas(Left:=0, Top:=0, Width:=lngCanvasWidth, Height:=lngFirstCanvasHeight, Anchor:=range1)
730           ElseIf intPage + 1 = intLastPage Then
740               Set shpCanvas = doc.Shapes.AddCanvas(Left:=0, Top:=0, Width:=lngCanvasWidth, Height:=lngLastCanvasHeight, Anchor:=range1)
750           Else
760               Set shpCanvas = doc.Shapes.AddCanvas(Left:=0, Top:=0, Width:=lngCanvasWidth, Height:=lngPageHeight, Anchor:=range1)
770           End If

780           shpCanvas.WrapFormat.AllowOverlap = False
790           shpCanvas.WrapFormat.Type = wdWrapInline

              ' Column headings
        
800           Set sh = shpCanvas.CanvasItems.AddTextbox( _
                  msoTextOrientationHorizontal, _
                  Left:=0, _
                  Top:=0, _
                  Width:=lngXSpeciesWidth, _
                  Height:=lngYSpeciesHeight)
810           sh.TextFrame.TextRange.Text = "Species"
820           sh.TextFrame.TextRange.Font.Size = 8
830           sh.TextFrame.TextRange.ParagraphFormat.Alignment = wdAlignParagraphLeft
840           sh.Line.Weight = 0
850           sh.Line.Visible = msoFalse
860           sh.TextFrame.MarginLeft = 2
870           sh.TextFrame.MarginRight = 0
880           sh.TextFrame.MarginTop = 0
890           sh.TextFrame.MarginBottom = 0
900           sh.Fill.ForeColor = vbBlack ' RGB(161, 190, 237)
910           sh.TextFrame.TextRange.Font.Color = RGB(255, 255, 255)
              
              Dim strHeading As String
              
920           For col = colPeriodFirst To colPeriodLast
930               Set sh = shpCanvas.CanvasItems.AddTextbox( _
                    msoTextOrientationHorizontal, _
                    Left:=lngXPeriodStart + lngXPeriodWidth * (col - colPeriodFirst), _
                    Top:=0, _
                    Width:=lngXPeriodWidth, _
                    Height:=lngYSpeciesHeight)
                    
940                 Select Case col
                    Case colNOV:
950                     strHeading = "Nov"
960                 Case colDEC:
970                     strHeading = "Dec"
980                 Case colJAN:
990                     strHeading = "Jan"
1000                Case colFEB:
1010                    strHeading = "Feb"
1020                Case colMAR:
1030                    strHeading = "Mar"
1040                Case colSpringFirst To colSpringLast
1050                    strHeading = "S" & col - colSpringFirst + 1
1060                Case colJUN:
1070                    strHeading = "Jun"
1080                Case colJUL:
1090                    strHeading = "Jul"
1100                Case colFallFirst To colFallLast
1110                    strHeading = "F" & col - colFallFirst + 1
1120                End Select
                
1130              sh.TextFrame.TextRange.Text = strHeading
1140              sh.TextFrame.TextRange.Font.Size = 8
1150              sh.TextFrame.TextRange.ParagraphFormat.Alignment = wdAlignParagraphCenter
1160              sh.Line.Weight = 0
1170              sh.Line.Visible = msoFalse
1180              sh.TextFrame.MarginLeft = 0
1190              sh.TextFrame.MarginRight = 0
1200              sh.TextFrame.MarginTop = 0
1210              sh.TextFrame.MarginBottom = 0
1220              sh.Fill.ForeColor = vbBlack
1230              sh.TextFrame.TextRange.Font.Color = RGB(255, 255, 255)

1240          Next

1250          intPage = intPage + 1
1260          row = 0
              
1270      End If

      ' row is the current row# - rowa are numbered from 1 to lngSpeciesPerPage
      ' the header row is row# 0

1280      row = row + 1

          ' Horizontal bar

1290      If row Mod 2 = 0 Then
1300          Set sh = shpCanvas.CanvasItems.AddShape( _
                  msoShapeRectangle, _
                  Left:=0, _
                  Top:=lngYSpeciesStart + (row - 1) * lngYSpeciesHeight, _
                  Width:=lngXPeriodStart + lngXPeriodWidth * lngNumberPeriods, _
                  Height:=lngYSpeciesHeight)
1310          sh.Fill.ForeColor = con_lngColourAlternate
1320          sh.Line.Visible = msoFalse
1330      End If

          ' Row label
          
1340      If fAbundanceChart Then
1350          Set sh = shpCanvas.CanvasItems.AddTextbox( _
                  msoTextOrientationHorizontal, _
                  Left:=0, _
                  Top:=lngYSpeciesStart + (row - 1) * lngYSpeciesHeight, _
                  Width:=lngXSpeciesWidth / 2, _
                  Height:=lngYSpeciesHeight)
1360              sh.TextFrame.TextRange.Text = rst("SpEnglish")
1370          sh.TextFrame.TextRange.Font.Size = 8
1380          sh.Line.Weight = 0
1390          sh.Line.Visible = msoFalse
1400          sh.TextFrame.MarginLeft = 2
1410          sh.TextFrame.MarginRight = 0
1420          sh.TextFrame.MarginTop = 0
1430          sh.TextFrame.MarginBottom = 0
1440          If row Mod 2 = 0 Then
1450              sh.Fill.ForeColor = con_lngColourAlternate
1460          End If
              
1470          Set sh = shpCanvas.CanvasItems.AddTextbox( _
                  msoTextOrientationHorizontal, _
                  Left:=lngXSpeciesWidth / 2, _
                  Top:=lngYSpeciesStart + (row - 1) * lngYSpeciesHeight, _
                  Width:=lngXSpeciesWidth / 2, _
                  Height:=lngYSpeciesHeight)
1480              sh.TextFrame.TextRange.Text = rst("SpFrench")
1490          sh.TextFrame.TextRange.Font.Size = 8
1500          sh.Line.Weight = 0
1510          sh.Line.Visible = msoFalse
1520          sh.TextFrame.MarginLeft = 2
1530          sh.TextFrame.MarginRight = 0
1540          sh.TextFrame.MarginTop = 0
1550          sh.TextFrame.MarginBottom = 0
1560          If row Mod 2 = 0 Then
1570              sh.Fill.ForeColor = con_lngColourAlternate
1580          End If
          
1590      Else
1600          Set sh = shpCanvas.CanvasItems.AddTextbox( _
                  msoTextOrientationHorizontal, _
                  Left:=0, _
                  Top:=lngYSpeciesStart + (row - 1) * lngYSpeciesHeight, _
                  Width:=lngXSpeciesWidth, _
                  Height:=lngYSpeciesHeight)
1610          sh.TextFrame.TextRange.Text = rst("Species")
1620          sh.TextFrame.TextRange.Font.Size = 9
1630          sh.Line.Weight = 0
1640          sh.Line.Visible = msoFalse
1650          sh.TextFrame.MarginLeft = 2
1660          sh.TextFrame.MarginRight = 0
1670          sh.TextFrame.MarginTop = 0
1680          sh.TextFrame.MarginBottom = 0
1690          If row Mod 2 = 0 Then
1700              sh.Fill.ForeColor = con_lngColourAlternate
1710          End If
1720      End If

          ' Draw abundance line

1730      For col = colPeriodFirst To colPeriodLast
1740          Select Case col
                  Case colNOV
1750                  lngLineWidth = Nz(rst("Nov"))
1760              Case colDEC
1770                  lngLineWidth = Nz(rst("Dec"))
1780              Case colJAN
1790                  lngLineWidth = Nz(rst("Jan"))
1800              Case colFEB
1810                  lngLineWidth = Nz(rst("Feb"))
1820              Case colMAR
1830                  lngLineWidth = Nz(rst("Mar"))
1840              Case colSpringFirst To colSpringLast
1850                  lngLineWidth = Nz(rst("S" & col - colSpringFirst + 1))
1860              Case colJUN
1870                  lngLineWidth = Nz(rst("Jun"))
1880              Case colJUL
1890                  lngLineWidth = Nz(rst("Jul"))
1900              Case colFallFirst To colFallLast
1910                  lngLineWidth = Nz(rst("F" & col - colFallFirst + 1))
1920          End Select
1930          If lngLineWidth > 0 Then
1940              Set sh = shpCanvas.CanvasItems.AddLine( _
                      BeginX:=lngXPeriodStart + (col - colPeriodFirst) * lngXPeriodWidth, _
                      BeginY:=lngYSpeciesHeight / 2 + lngYSpeciesStart + (row - 1) * lngYSpeciesHeight, _
                      EndX:=lngXPeriodStart + (col - colPeriodFirst + 1) * lngXPeriodWidth, _
                      EndY:=lngYSpeciesHeight / 2 + lngYSpeciesStart + (row - 1) * lngYSpeciesHeight)
1950              sh.Line.Weight = lngLineWidth
1960              sh.Line.ForeColor = lngAbundanceLineColour(lngLineWidth)
1970          End If
1980      Next
          
1990      rst.MoveNext
2000  Loop
2010  rst.Close
2020  Set rst = Nothing

      ' Draw white vertical lines between periods
      ' Draw light blue vertical lines between seasons

2030  For col = colPeriodFirst To colPeriodLast
2040      Set sh = shpCanvas.CanvasItems.AddLine( _
              BeginX:=lngXPeriodStart + lngXPeriodWidth * (col - colPeriodFirst), _
              BeginY:=0, _
              EndX:=lngXPeriodStart + lngXPeriodWidth * (col - colPeriodFirst), _
              EndY:=lngYSpeciesStart * (row) + lngYSpeciesHeight - 1)
2050      sh.Line.Style = msoLineSingle
2060      sh.Line.Weight = 1
2070      sh.Line.ForeColor = RGB(255, 255, 255)
2080      Select Case col
          Case colPeriodFirst, colSpringFirst, colJUN, colFallFirst, colNOV
2090          Set sh = shpCanvas.CanvasItems.AddLine( _
                  BeginX:=lngXPeriodStart + lngXPeriodWidth * (col - colPeriodFirst), _
                  BeginY:=lngYSpeciesStart, _
                  EndX:=lngXPeriodStart + lngXPeriodWidth * (col - colPeriodFirst), _
                  EndY:=lngYSpeciesStart * row + lngYSpeciesHeight - 1)
2100          sh.Line.Style = msoLineSingle
2110          sh.Line.Weight = 1
2120          sh.Line.ForeColor = RGB(161, 190, 237)
2130      End Select
2140      Set sh = shpCanvas.CanvasItems.AddLine( _
              BeginX:=lngXPeriodStart + lngXPeriodWidth * (colPeriodLast - colPeriodFirst + 1), _
              BeginY:=lngYSpeciesStart, _
              EndX:=lngXPeriodStart + lngXPeriodWidth * (colPeriodLast - colPeriodFirst + 1), _
              EndY:=lngYSpeciesStart * row + lngYSpeciesHeight - 1)
2150      sh.Line.Style = msoLineSingle
2160      sh.Line.Weight = 1
2170      sh.Line.ForeColor = RGB(161, 190, 237)

2180  Next

2190  Set sh = shpCanvas.CanvasItems.AddLine( _
          BeginX:=0, _
          BeginY:=lngYSpeciesStart, _
          EndX:=0, _
          EndY:=lngYSpeciesStart * row + lngYSpeciesHeight - 1)
2200  sh.Line.Style = msoLineSingle
2210  sh.Line.Weight = 1
2220  sh.Line.ForeColor = RGB(161, 190, 237)

      ' Delete the last page break

2230    doc.range(lngStart_before_page_break, range.End).Find.Execute FindText:="^m", ReplaceWith:="", Replace:=wdReplaceAll
          
          'DD Error Handler Start
Exit_label:
2240      Exit Sub
Err_label:
2250      Select Case Err.Number
          Case Else
2260     Call LogError("basMBO10YearProgramReportAbundance", "WordOutput_Detail")
2270      End Select
2280      Resume Exit_label
          ' DD Error Handler End


End Sub



''---------------------------------------------------------------------------------------
'' MBO10YearProgramReportAbundance_Owling
''
'' There is no DET for Owling, so I use Captures instead.
''---------------------------------------------------------------------------------------
'
'Public Sub MBO10YearProgramReportAbundance_Owling( _
'    ByVal intYearFirst As Integer, _
'    ByVal intYearLast As Integer, _
'    ByVal strLocation As String, _
'    ByRef oExcel As Excel.Application, _
'    ByRef oBook As Excel.Workbook, _
'    ByVal fDebug As Boolean, _
'    Optional ByVal fAbundanceChart As Boolean = False)
'
'      ' Save parameters
'
'10    On Error GoTo Err_label
'
'      Dim oSheet As Excel.Worksheet
'
'      ' intAbundanceCounters( abundance category, column )
'      ' use abundance category 7 for the grand totals
'
'      Dim intAbundanceCounters(1 To 7, 2 To 31) As Integer
'
'      Dim intAbundanceCategory As Integer
'      Dim col As Integer
'
'20    For intAbundanceCategory = 1 To 7
'30        For col = 2 To 31
'40            intAbundanceCounters(intAbundanceCategory, col) = 0
'50        Next
'60    Next
'
'70    Set oSheet = InsertSheet(oBook, "Owling")
'80    oSheet.Name = "Abundance_H Owling"
'
'      Dim row As Long
'      ' Dim col As Integer
'
'      Dim strSQL As String
'      Dim qdf As dao.QueryDef
'      Dim rst As dao.Recordset
'
'      ' tblMBO10YearProgramReportSpecies
'      ' --------------------------------
'      ' Basically a copy of tblDETSpecies modified as follows:
'      ' Location = MBO
'      ' YearEx (report year) is in range
'      ' No restriction on Season
'      ' Removed ("TRFL","ALFL","WIFL","LSGO","GSGO","SNGO","UNSG","UNAC","UNEM","UNGU","UNSC","PAWA","UNPW")
'      ' Added SNGO = ("SNGO","GSGO","LSGO")
'      ' Added TRFL = ("TRFL","WIFL","ALFL")
'      '
'      ' Season, YearEx, Period, DateEx, Species, Banded, Returns, Repeats, DET
'
'      ' qryMBO10YearProgramReportAbundance_YearsPresent_A_Owling
'      ' --------------------------------------------------------
'      ' tblMBO10YearProgramReportSpecies
'      ' Season = "Owling"
'      ' Period =  toPeriodOwlingAbundance([DateEx])
'      ' GROUP BY Season, YearEx, Period, Species
'      ' SUM Captures:Nz( [Banded])+Nz([Returns])+Nz([Repeats])+Nz([Alien])+Nz([Replacement])   ' There is no DET value for Owling
'      ' Report Season, YearEx, Period, Species, Captures
'
'      ' qryMBO10YearProgramReportAbundance_YearsPresent_B_Owling
'      ' --------------------------------------------------------
'      ' qryMBO10YearProgramReportAbundance_YearsPresent_A_Owling
'      ' YearsPresent = IIf([Captures]>0,1,0)
'      ' GROUP BY Season, Period, Species
'      ' SUM YearsPresent
'      ' Report Season,  Period, Species, YearsPresent
'
'      ' qryMBO10YearProgramReportAbundance_CountDETDays_A_Owling
'      ' --------------------------------------------------------
'      ' tblMBO10YearProgramReportSpecies
'      ' Species = "Owling"
'      ' GROUP BY Season, YearEx, Period, DateEx
'      ' SUM Captures: Sum(Nz([Banded])+Nz([Returns])+Nz([Repeats])+Nz([Alien])+Nz([Replacement])) > 0
'      ' Report Season, YearEx, Period, DateEx, Captures
'
'      ' qryMBO10YearProgramReportAbundance_CountDETDays_B_Owling
'      ' --------------------------------------------------------
'      ' qryMBO10YearProgramReportAbundance_CountDETDays_A_Owling
'      ' GROUP BY Season,  Period
'      ' Count records
'      ' Report Season, Period, CountDETDays
'
'      ' qryMBO10YearProgramReportAbundance_TotalDET_Owling
'      ' --------------------------------------------------
'      ' qryMBO10YearProgramReportAbundance_YearsPresent_A_Owling
'      ' GROUP BY Season, YearEx, Period,
'      ' SumOfDET = SUM Captures
'      ' Report Season, Period, Captures
'
'      ' qryMBO10YearProgramReportAbundance_A_Owling
'      ' -------------------------------------------
'      ' qryMBO10YearProgramReportAbundance_YearsPresent_B_Owling
'      ' qryMBO10YearProgramReportAbundance_CountDETDays_B_Owling
'      ' qryMBO10YearProgramReportAbundance_TotalDET_Owling
'      ' tblSpecies
'      ' MeanDET = SumOfDET / CountDETDays
'      ' ORDER BY tblSpecies.AOU
'      ' Report Season, Period, Species, SumOfDET, CountDETDays, YearsPresent, MeanDET
'
'
'      Dim intPeriod As Integer
'
'      Const intCountPeriods As Integer = 7
'
'      ' columns 1 to 8 = abundance
'      ' column 9 blank
'      ' columns 10 to 17 = details
'
'90    With oSheet
'
'100   row = 1
'
'      Dim colBase As Integer
'
'110   colBase = 0
'120   .Cells(row, colBase + 1) = "Species"
'130   .Cells(row, colBase + 2) = "F9"
'140   .Cells(row, colBase + 3) = "F10"
'150   .Cells(row, colBase + 4) = "F11"
'160   .Cells(row, colBase + 5) = "F12"
'170   .Cells(row, colBase + 6) = "F13"
'180   .Cells(row, colBase + 7) = "Nov"
'190   .Cells(row, colBase + 8) = "Other"
'
'200   colBase = 9
'210   .Cells(row, colBase + 1) = "Species"
'220   .Cells(row, colBase + 2) = "F9"
'230   .Cells(row, colBase + 3) = "F10"
'240   .Cells(row, colBase + 4) = "F11"
'250   .Cells(row, colBase + 5) = "F12"
'260   .Cells(row, colBase + 6) = "F13"
'270   .Cells(row, colBase + 7) = "Nov"
'280   .Cells(row, colBase + 8) = "Other"
'
'290   SysCmd acSysCmdSetStatus, "Abundance Owling Export to Excel"
'300   DoEvents
'
'310   strSQL = "qryMBO10YearProgramReportAbundance_A_Owling"
'320   Set qdf = CurrentDb.QueryDefs(strSQL)
'330   Set rst = qdf.OpenRecordset
'
'      Dim strSpecies As String
'      Dim strSpeciesPrevious As String
'      Dim dblMeanDET As Double
'      Dim intYearsPresent As Integer
'      Dim intAbundance As Integer
'
'340   row = 1
'350   strSpeciesPrevious = ""
'
'Dim intYearsRange As Integer
'360   intYearsRange = intYearLast - intYearFirst + 1
'
'370   Do While Not rst.EOF
'
'380       strSpecies = Nz(rst("Species"))
'
'390       SysCmd acSysCmdSetStatus, "Abundance Owling Export to Excel - " & strSpecies
'400       DoEvents
'
'410       If strSpecies <> strSpeciesPrevious Then
'420           strSpeciesPrevious = strSpecies
'430           row = row + 1
'440           .Cells(row, 1) = strSpecies
'450           .Cells(row, 10) = strSpecies
'460       End If
'470       dblMeanDET = Nz(rst("MeanDET"))
'480       intYearsPresent = Nz(rst("YearsPresent"))
'
'490       intPeriod = Nz(rst("Period"))
'
'500       intAbundance = getAbundance(dblMeanDET, intYearsPresent, "Owling", intPeriod, intYearFirst, intYearLast)
'
'510       Select Case intPeriod
'          Case 1 To 6
'520           col = intPeriod + 1
'530       Case Else
'540           col = 8
'550       End Select
'
'560       If intAbundance <> conAbundanceUnknown Then
'570           .Cells(row, col) = intAbundance
'580           .Cells(row, 9 + col) = _
'                  FormatNumberEnglish(dblMeanDET, 1) & " (" & intYearsPresent & ")"
'590           intAbundanceCounters(intAbundance, col) = _
'                  intAbundanceCounters(intAbundance, col) + 1
'600           intAbundanceCounters(7, col) = intAbundanceCounters(7, col) + 1
'610       End If
'
'          Dim lngColour As Long
'620       Select Case intAbundance
'
'          Case conAbundanceVeryRare
'630           lngColour = RGB(178, 161, 199)
'640       Case conAbundanceRare
'650           lngColour = RGB(0, 176, 240)
'660       Case conAbundanceUncommon
'670           lngColour = RGB(146, 208, 80)
'680       Case conAbundanceFairlyCommon
'690           lngColour = vbYellow
'700       Case conAbundanceCommon
'710           lngColour = RGB(255, 192, 0)
'720       Case conAbundanceAbundant
'730           lngColour = vbRed
'740       End Select
'750       .Cells(row, col).Interior.Color = lngColour
'
'760       rst.MoveNext
'770   Loop
'780   rst.Close
'790   Set rst = Nothing
'
'800   SysCmd acSysCmdSetStatus, "Abundance Owling Export to Excel - Summary"
'810   DoEvents
'
'820   row = row + 1
'
'      ' Write out the abundance counters
'
'830   .Cells(row + 1, 1) = "Very rare"
'840   .Cells(row + 2, 1) = "Rare"
'850   .Cells(row + 3, 1) = "Uncommon"
'860   .Cells(row + 4, 1) = "Fairly common"
'870   .Cells(row + 5, 1) = "Common"
'880   .Cells(row + 6, 1) = "Abundant"
'890   .Cells(row + 7, 1) = "TOTAL"
'
'900   .Cells(row + 1, 1).Interior.Color = RGB(178, 161, 199)
'910   .Cells(row + 2, 1).Interior.Color = RGB(0, 176, 240)
'920   .Cells(row + 3, 1).Interior.Color = RGB(146, 208, 80)
'930   .Cells(row + 4, 1).Interior.Color = vbYellow
'940   .Cells(row + 5, 1).Interior.Color = RGB(255, 192, 0)
'950   .Cells(row + 6, 1).Interior.Color = vbRed
'
'960   .Cells(row + 7, 1).Font.Color = vbWhite
'970   .Cells(row + 7, 1).Interior.Color = vbBlack
'980   .Cells(row + 7, 1).Font.Bold = True
'
'
'990   For intAbundanceCategory = 1 To 7
'1000      For col = 2 To 8
'1010          .Cells(row + intAbundanceCategory, col) = _
'                intAbundanceCounters(intAbundanceCategory, col)
'1020      Next
'1030  Next
'
'1040  .range(.Columns(2), .Columns(8)).HorizontalAlignment = xlCenter
'1050  .range(.Columns(11), .Columns(17)).HorizontalAlignment = xlCenter
'1060  .range(.Columns(1), .Columns(17)).AutoFit
'
'1070  .range("A2").Select
'1080  oExcel.ActiveWindow.FreezePanes = True
'
'1090  End With
'
'
'1100  Set oSheet = Nothing
'
'1110  SysCmd acSysCmdClearStatus
'1120  DoEvents
'
'      'DD Error Handler Start
'Exit_label:
'1130       Exit Sub
'Err_label:
'1140       Select Case Err.Number
'           Case Else
'1150            Call LogError("basMBO10YearProgramReportAbundance", "MBO10YearProgramReportAbundance_Owling")
'1160       End Select
'1170       Resume Exit_label
'      'DD Error Handler End
'
'End Sub

'---------------------------------------------------------------------------------------
' WordGenerateTableAbundance
'---------------------------------------------------------------------------------------
' entry:  range = a collapsed range that is the insertion point for the table
' exit:   range = range that includes the table

Private Sub WordGenerateTableAbundance( _
    ByRef doc As Word.Document, ByRef range As Word.range, _
    ByVal lngPageWidth As Long, ByVal lngLeftMargin As Long, ByRef lngRightMargin As Long, _
    ByVal lngXSpeciesStart As Long, ByVal lngXSpeciesWidth As Long, _
    ByVal lngNumberPeriods As Long, ByVal lngXPeriodWidth As Long)
          
10       On Error GoTo Err_label
          
      '20        doc.Application.Visible = True
          
      Dim intPeriodLastSpring As Integer
      Dim intPeriodLastFall As Integer

20    intPeriodLastSpring = getPeriodLast_Season("Spring")
30    intPeriodLastFall = getPeriodLast_Season("Fall")

      Dim row As Integer
      Dim col As Integer

40    On Error GoTo Err_label

      Dim colAbundanceFirst As Integer
      Dim colAbundanceLast As Integer

      'With doc.PageSetup
      '    .LeftMargin = lngLeftMargin
      '    .RightMargin = lngRightMargin
      '    .TopMargin = doc.Application.InchesToPoints(0.79)
      '    .BottomMargin = doc.Application.InchesToPoints(0.79)
      'End With

50    colAbundanceFirst = 2
60    colAbundanceLast = 8 + intPeriodLastSpring + intPeriodLastFall

70    doc.Tables.Add range:=range, NumRows:=9, NumColumns:=colAbundanceLast, DefaultTableBehavior:=wdWord9TableBehavior, _
          AutoFitBehavior:=wdAutoFitFixed
          
80    range.Expand (wdTable)
90    With range.Tables(1)

100       .Rows.Alignment = wdAlignRowLeft

110       For col = 1 To colAbundanceLast
120           .Cell(1, col).VerticalAlignment = wdCellAlignVerticalCenter
130       Next

140       .Rows.WrapAroundText = False

150       .LeftPadding = doc.Application.InchesToPoints(0)
160       .RightPadding = doc.Application.InchesToPoints(0)
170       .TopPadding = doc.Application.InchesToPoints(0.02)
180       .Spacing = 0
190       .AllowPageBreaks = True
200       .AllowAutoFit = False
          
210       .columns(1).Width = lngXSpeciesWidth
220       For col = colAbundanceFirst To colAbundanceLast
230           .columns(col).Width = lngXPeriodWidth
240       Next

250       row = 1
          
260       .Cell(row, 1).range.InsertAfter "COUNT OF SPECIES OBSERVED DURING EACH TIME PERIOD:"
270       .Cell(row, 1).Merge .Cell(row, colPeriodLast)
280       .Cell(row, 1).range.Shading.BackgroundPatternColor = RGB(166, 166, 166)
290       .Cell(row, 1).range.ParagraphFormat.Style = "ddMultiYearAbundanceSummaryTitle"
          
300       row = 2

310       .Cell(row, colSpecies).range.Text = "Species"
320       .Cell(row, colNOV).range.Text = "Nov"
330       .Cell(row, colDEC).range.Text = "Dec"
340       .Cell(row, colJAN).range.Text = "Jan"
350       .Cell(row, colFEB).range.Text = "Feb"
360       .Cell(row, colMAR).range.Text = "Mar"
370       For col = colSpringFirst To colSpringLast
380           .Cell(row, col).range.Text = "S" & (col - colSpringFirst + 1)
390       Next
400       .Cell(row, colJUN).range.Text = "Jun"
410       .Cell(row, colJUL).range.Text = "Jul"
420       For col = colFallFirst To colFallLast
430           .Cell(row, col).range.Text = "F" & (col - colFallFirst + 1)
440       Next

        
          ' Format Header Row
          
450       Call FormatWordTableRowAsHeader(.Rows(2), "ddAbundanceHeaderRow1")
          
          ' All cells are centred
          
460       .range.ParagraphFormat.Alignment = wdAlignParagraphCenter
          
          ' Draw horizontal lines
          
470       For row = 1 To 9
480           .Rows(row).Borders(wdBorderTop).LineStyle = wdLineStyleSingle
490       Next
500       .Rows(9).Borders(wdBorderBottom).LineStyle = wdLineStyleSingle

          ' Draw vertical lines
          
510       For row = 3 To 9
520           For col = colAbundanceFirst To colAbundanceLast
530               .Cell(row, col).Borders(wdBorderLeft).LineStyle = wdLineStyleDot
540           Next
          
550           .Cell(row, colSpecies).Borders(wdBorderLeft).LineStyle = wdLineStyleSingle
560           .Cell(row, colPeriodFirst).Borders(wdBorderLeft).LineStyle = wdLineStyleSingle
570           .Cell(row, colMAR).Borders(wdBorderRight).LineStyle = wdLineStyleSingle
580           .Cell(row, colJUN).Borders(wdBorderLeft).LineStyle = wdLineStyleSingle
590           .Cell(row, colJUL).Borders(wdBorderRight).LineStyle = wdLineStyleSingle
600           .Cell(row, colPeriodLast).Borders(wdBorderRight).LineStyle = wdLineStyleSingle
              
610           .Cell(row, colPeriodFirst).Borders(wdBorderLeft).LineWidth = wdLineWidth150pt
620           .Cell(row, colMAR).Borders(wdBorderRight).LineWidth = wdLineWidth150pt
630           .Cell(row, colJUN).Borders(wdBorderLeft).LineWidth = wdLineWidth150pt
640           .Cell(row, colJUL).Borders(wdBorderRight).LineWidth = wdLineWidth150pt
650           .Cell(row, colPeriodLast).Borders(wdBorderRight).LineWidth = wdLineWidth150pt
660       Next

670       row = 3
680       .Cell(row, 1).range.Text = "V. rare"
690       row = row + 1
700       .Cell(row, 1).range.Text = "Rare"
710       row = row + 1
720       .Cell(row, 1).range.Text = "Uncom."
730       row = row + 1
740       .Cell(row, 1).range.Text = "F. com."
750       row = row + 1
760       .Cell(row, 1).range.Text = "Common"
770       row = row + 1
780       .Cell(row, 1).range.Text = "Abundant"
790       row = row + 1
800       .Cell(row, 1).range.Text = "TOTAL"
          
810       For row = 3 To 9
820           .Cell(row, 1).range.ParagraphFormat.Style = "ddMultiYearAbundanceSummaryAbundanceLabel"
830       Next

840       For row = 3 To 9
850           For col = colAbundanceFirst To colAbundanceLast
860         .Cell(row, col).range.ParagraphFormat.Style = "ddMultiYearAbundanceSummaryData"
870           Next
880       Next

890       .Rows(9).Shading.BackgroundPatternColor = RGB(217, 217, 217)

900   End With

          'DD Error Handler Start
Exit_label:
910       Exit Sub
Err_label:
920       Select Case Err.Number
          Case Else
930      Call LogError("basMBO10YearProgramReportAbundance", "WordGenerateTableAbundance")
940       End Select
950       Resume Exit_label
          ' DD Error Handler End

End Sub


'---------------------------------------------------------------------------------------
' toPeriodOwlingAbundance
'---------------------------------------------------------------------------------------
 
Public Function toPeriodOwlingAbundance(ByVal DateEx As Date) As Integer
      Dim intPeriod As Integer
      Dim datStandardizedDate As Date

10    On Error GoTo Err_label

20    datStandardizedDate = DateSerial(2000, Month(DateEx), Day(DateEx))
30    If datStandardizedDate < DateSerial(2000, 9, 26) Then
40        intPeriod = 0
50    ElseIf datStandardizedDate < DateSerial(2000, 10, 3) Then
60        intPeriod = 1
70    ElseIf datStandardizedDate < DateSerial(2000, 10, 10) Then
80        intPeriod = 2
90    ElseIf datStandardizedDate < DateSerial(2000, 10, 17) Then
100       intPeriod = 3
110   ElseIf datStandardizedDate < DateSerial(2000, 10, 24) Then
120       intPeriod = 4
130   ElseIf datStandardizedDate < DateSerial(2000, 10, 31) Then
140       intPeriod = 5
150   ElseIf datStandardizedDate < DateSerial(2000, 12, 1) Then
160       intPeriod = 6
170   Else
180       intPeriod = 0
190   End If

200   toPeriodOwlingAbundance = intPeriod

      'DD Error Handler Start
Exit_label:
210        Exit Function
Err_label:
220        Select Case Err.Number
           Case Else
230             Call LogError("basMBO10YearProgramReportAbundance", "toPeriodOwlingAbundance")
240        End Select
250        Resume Exit_label
      'DD Error Handler End
          
End Function

'---------------------------------------------------------------------------------------
' getAbundance
'
' This works for 5 or more years
'---------------------------------------------------------------------------------------

Private Function getAbundance(ByVal MeanDET As Double, ByVal YearsPresent As Integer, _
    ByVal strSeason As String, ByVal intPeriod As Integer, ByVal intYearFirst As Integer, ByVal intYearLast As Integer) As Integer
          
10    On Error GoTo Err_label
         
      Dim intYearsRange As Integer
         
20    If intPeriod = 14 Then
30        If strSeason = "Fall" Then
40            If intYearFirst < 2015 Then intYearFirst = 2015
50        End If
60    End If

70    intYearsRange = intYearLast - intYearFirst + 1
80    If intYearsRange < 5 Then
90        getAbundance = conAbundanceUnknown
100   ElseIf YearsPresent <= Round(0.2 * intYearsRange) Then
110       getAbundance = conAbundanceVeryRare
120   ElseIf MeanDET < 1 Then
130       getAbundance = conAbundanceRare
140   ElseIf MeanDET < 5 Then
150       getAbundance = conAbundanceUncommon
160   ElseIf MeanDET < 10 Then
170       getAbundance = conAbundanceFairlyCommon
180   ElseIf MeanDET < 50 Then
190       getAbundance = conAbundanceCommon
200   Else
210       getAbundance = conAbundanceAbundant
220   End If

          'DD Error Handler Start
Exit_label:
230       Exit Function
Err_label:
240       Select Case Err.Number
          Case Else
250      Call LogError("basDET", "getAbundance")
260       End Select
270       Resume Exit_label
          ' DD Error Handler End
          
End Function
