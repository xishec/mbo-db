'---------------------------------------------------------------------------------------
' Module: basUtilityFrontEnd
' Author: David Davey
'---------------------------------------------------------------------------------------

Option Compare Database
Option Explicit

'---------------------------------------------------------------------------------------
' PutVersion
'---------------------------------------------------------------------------------------
 
Public Sub PutVersion(ByVal strVersion As String)

10    On Error GoTo Err_label

      Dim strSQL As String

20    strSQL = "UPDATE tblUtilityFrontEnd SET Version = '" & strVersion & "' WHERE ID=1"
30    CurrentDb.Execute strSQL

40    Call MBODataEntryRefreshTitleBar
          'DD Error Handler Start
Exit_label:
50        Exit Sub
Err_label:
60        Select Case Err.Number
          Case Else
70       Call LogError("basUtilityFrontEnd", "PutVersion")
80        End Select
90        Resume Exit_label
          ' DD Error Handler End
End Sub

'---------------------------------------------------------------------------------------
' GetVersion
'---------------------------------------------------------------------------------------
 
Public Function GetVersion() As String

10    On Error GoTo Err_label

      Dim strVersion As String

20    strVersion = Nz(DLookup("Version", "tblUtilityFrontEnd", "ID=1"))
30    GetVersion = strVersion

          'DD Error Handler Start
Exit_label:
40        Exit Function
Err_label:
50        Select Case Err.Number
          Case Else
60       Call LogError("basUtilityFrontEnd", "GetVersion")
70        End Select
80        Resume Exit_label
          ' DD Error Handler End
End Function
