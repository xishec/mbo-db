'---------------------------------------------------------------------------------------
' Module    : basErrorLogging
' Author    : David Davey
'---------------------------------------------------------------------------------------

Option Compare Database
Option Explicit

'---------------------------------------------------------------------------------------
' LogError
'
' N.B. Abandon error logging if an error occurs during error logging
'---------------------------------------------------------------------------------------
 
Public Sub LogError(ByVal ModuleEx As String, ByVal ProcedureEx As String, _
                    Optional ByVal DeveloperMessage As String = "", _
                    Optional ByVal Silent As Boolean = False, _
                    Optional ByVal DeveloperErrNumber As Long = 0, _
                    Optional ByVal fEmailError As Boolean = True)


Dim strVersionFrontEnd As String
Dim datDateEx As Date
Dim lngErrNumber As Long
Dim strErrDescription As String
Dim lngErl As Long

' Save Err.Number, Err.Description and Erl
' before installing an error handler

lngErrNumber = Err.Number
strErrDescription = Err.Description
lngErl = Erl

On Error GoTo Err_label

strVersionFrontEnd = GetVersion()
datDateEx = Format(Now(), "dd mmm yyyy hh:nn")
    
' If the user chooses to see errors, then display the error
    
Dim fViewErrorsAsTheyOccur As Boolean

fViewErrorsAsTheyOccur = (GetSettingEx("ViewErrorsAsTheyOccur") = "True")
    
Dim str
    
Dim fDisplaySilentErrors As Boolean
fDisplaySilentErrors = GetDisplaySilentErrors()

' Log error in tblErrorLog

Dim lngID As Long

Dim rst As DAO.Recordset
Set rst = CurrentDb.OpenRecordset("tblErrorLog", dbOpenDynaset)
rst.AddNew
rst.Fields("DateEx") = datDateEx
rst.Fields("ErrNumber") = lngErrNumber
rst.Fields("ErrDescription") = Right(strErrDescription, 255)
rst.Fields("ModuleEx") = ModuleEx
rst.Fields("ProcedureEx") = ProcedureEx
rst.Fields("Erl") = lngErl
rst.Fields("VersionFrontEnd") = strVersionFrontEnd
rst.Fields("DeveloperMessage") = Right(DeveloperMessage, 255)
rst.Fields("DeveloperErrNumber") = DeveloperErrNumber
rst.Update
rst.Move 0, rst.LastModified
lngID = rst("ID")
rst.Close

' I disactivated the emailing of error messages 2025-03-05

'250   If fEmailError Then
'
'          ' Email the error message to David
'
'          Dim recErrorLogging As basTypes.ErrorLogging
'
'260       recErrorLogging.DateEx = datDateEx
'270       recErrorLogging.ErrNumber = lngErrNumber
'280       recErrorLogging.ErrDescription = strErrDescription
'290       recErrorLogging.ModuleEx = ModuleEx
'300       recErrorLogging.ProcedureEx = ProcedureEx
'310       recErrorLogging.Erl = lngErl
'320       recErrorLogging.VersionFrontEnd = strVersionFrontEnd
'330       recErrorLogging.DeveloperMessage = DeveloperMessage
'340       recErrorLogging.DeveloperErrNumber = DeveloperErrNumber
'350       Call EmailError(recErrorLogging)
'
'360   End If

' Display the error to the user

Dim strWhere As String

If (fViewErrorsAsTheyOccur And Not Silent) Or fDisplaySilentErrors Then
    strWhere = _
        " [ErrNumber] = " & lngErrNumber & " AND " & _
        " [ModuleEx] = '" & ModuleEx & "' AND " & _
        " [ProcedureEx] = '" & ProcedureEx & "' AND " & _
        " [Erl] = " & lngErl & " AND " & _
        " [DeveloperErrNumber] = " & DeveloperErrNumber

    If DCount("*", "tblErrorBlacklist", strWhere) = 0 Then
        If IsLoaded("frmErrorLogDialog") Then
            On Error Resume Next
            DoCmd.Close acForm, "frmErrorLogDialog"
            On Error GoTo Err_label
        End If
        DoCmd.OpenForm "frmErrorLogDialog", WhereCondition:="[ID] = " & lngID
    End If
End If


' Refresh txtCountErrors

If IsLoaded("frmErrorLog") Then
    Forms("frmErrorLog").Controls("txtCountErrors") = DCount("*", "tblErrorLog", "True")
End If

'DD Error Handler Start
Exit_label:
     Exit Sub
Err_label:
    Select Case Err.Number
    Case Else
        If fViewErrorsAsTheyOccur Then
           MsgBox "Error during error logging" & vbCrLf & _
               Err.Description & vbCrLf & _
               "Line = " & Erl & vbCrLf & _
               "Date = " & Format(datDateEx, "dd mmm yyyy")
        End If
    End Select

    Resume Exit_label
'DD Error Handler End

End Sub



'---------------------------------------------------------------------------------------
' EMailError
'
' Email the error to the address specified on the Maintenance form
' strFilespaec is the path to a file to be attached to the email.  Do not specify the stFilespec arguemnt if there is no attachment.
'
' If the database is running on David's PC do nothing
' If the Email address list is "", do nothing
'
' Verify we have not exceeded today's error logging emails limit
'---------------------------------------------------------------------------------------
' No longer called
 
Public Sub EmailError(ByRef recErrorLogging As ErrorLogging, Optional ByVal strFilespec As String = "")

      Const strFromAddress As String = "mbo.dell.dataentry@outlook.com"
      Const strFromMotDePasse As String = "twdg2437T"
      Const strSMTPServer As String = "smtp.office365.com"
      Const intSMTPServer_Port As Integer = 25


10    On Error GoTo Err_label

      Dim fDavid_PC As Boolean
      
20    fDavid_PC = isDavidPC()
30    If fDavid_PC Then GoTo Exit_label

      Dim strToAddress As String

40    strToAddress = GetEmailAddressListForErrors
50    If strToAddress = "" Then GoTo Exit_label

      ' Have we exceeded today's limit?

60    If Int(Now()) <> Int(GetErrorLoggingDateOfPreviousEmail()) Then
70        Call PutErrorLoggingDateOfPreviousEmail(Int(Now()))
80        Call PutErrorLoggingCountEmailsToday(1)
90    Else
100       If GetErrorLoggingCountEmailsToday() < GetErrorLoggingMaxEmailsPerDay() Then
110           Call PutErrorLoggingCountEmailsToday(GetErrorLoggingCountEmailsToday() + 1)
120       Else
130           GoTo Exit_label
140       End If
150   End If

      Dim strMessage As String
160   strMessage = ""
        
      Dim fSuccessEmail As Boolean
      Dim strSubject As String
      Dim strBodyHTML As String
      Dim strError As String

170   strSubject = "MBO Database Error"
180   strBodyHTML = _
          "Date = " & recErrorLogging.DateEx & vbCrLf & _
          "Err Number = " & recErrorLogging.ErrNumber & vbCrLf & _
          "Err Description = " & recErrorLogging.ErrDescription & vbCrLf & _
          "ModuleEx = " & recErrorLogging.ModuleEx & vbCrLf & _
          "ProcedureEx = " & recErrorLogging.ProcedureEx & vbCrLf & _
          "Erl = " & recErrorLogging.Erl & vbCrLf & _
          "VersionFrontEnd = " & recErrorLogging.VersionFrontEnd & vbCrLf & _
          "DeveloperMessage = " & recErrorLogging.DeveloperMessage & vbCrLf & _
          "DeveloperErrNumber = " & recErrorLogging.DeveloperErrNumber & vbCrLf
              
190   fSuccessEmail = SendEMail( _
          strSubject, _
          strFromAddress, _
          strFromMotDePasse, _
          strToAddress, _
          strBodyHTML, _
          strSMTPServer, _
          intSMTPServer_Port, _
          "", strError)


      ' If emailing the error message failed, then do nothing.  I'll eventually figure out that I'm not receiving emails with info about errors
      ' No point filling up the error log with error messages saying that the emailing failed

'200   If Not fSuccessEmail Then
'
'210       strError = strError & _
'              "Subject = " & strSubject & _
'              ", From Address = " & strFromAddress & _
'              ", To Address =  " & strToAddress & _
'              ", SMTP Server = " & strSMTPServer & _
'              ", Filespaec = " & strFilespec
'
'220       Call LogError("basErrorLogging", "EmailError", Silent:=True, DeveloperMessage:="Failed to send Error Email " & strError, DeveloperErrNumber:=1, fEmailError:=False)
'230   End If


          'DD Error Handler Start
Exit_label:
240       Exit Sub
Err_label:
250       Select Case Err.Number
          Case Else
260      Call LogError("basErrorLogging", "EmailError")
270       End Select
280       Resume Exit_label
          ' DD Error Handler End
End Sub
