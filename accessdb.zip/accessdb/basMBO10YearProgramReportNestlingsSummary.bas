'---------------------------------------------------------------------------------------
' Module    : basMBO10YearProgramReportNestlingsSummary
' Author    : David Davey
'---------------------------------------------------------------------------------------

Option Compare Database
Option Explicit

' Statistics

Const conNestlingsBirdsBanded As Integer = 0
Const conNestlingsSpeciesBanded As Integer = 1
Const conStatLast As Integer = 1

Private intYearFirst As Integer
Private intYearLast As Integer
Private strLocation As String
Private wd As Word.Application
Private doc As Word.Document
Private oExcel As Excel.Application
Private oBook As Excel.Workbook

Private dblStat() As Double                         ' stat x year

Private intNestlingsCount(conStatLast) As Integer
Private dblNestlingsTotal(conStatLast) As Double
Private dblNestlingsAverage(conStatLast) As Double

'---------------------------------------------------------------------------------------
' MBO10YearProgramReportNestlingSummary
'
' No need to process subspecies and superspecies
'---------------------------------------------------------------------------------------

 Public Sub MBO10YearProgramReportNestlingsSummary( _
    ByRef fValid As Boolean, _
    ByVal argYearFirst As Integer, _
    ByVal argYearLast As Integer, _
    ByVal argLocation As String, _
    ByRef arg_wd As Word.Application, _
    ByRef arg_doc As Word.Document, _
    ByRef arg_excel As Excel.Application, _
    ByRef arg_book As Excel.Workbook)
           
      ' Save parameters

10    On Error GoTo Err_label

20    intYearFirst = argYearFirst
30    intYearLast = argYearLast
40    strLocation = argLocation
50    Set wd = arg_wd
60    Set doc = arg_doc
70    Set oExcel = arg_excel
80    Set oBook = arg_book

      Dim qdf As QueryDef
      Dim rst As DAO.Recordset
      Dim lngCountBirds As Integer
      Dim intCountSpecies As Integer

      ' --------------------------------------
      ' Compute Information for Word table
      ' --------------------------------------

90    ReDim dblStat(conStatLast, intYearFirst To intYearLast) As Double

      Dim stat As Integer       ' 0 To conStatLast
      Dim Y As Integer          ' intYearFirst To intYearLast

100   For stat = 0 To conStatLast
110       For Y = intYearFirst To intYearLast
120           dblStat(stat, Y) = 0
130       Next
140   Next

      ' ----------------
      ' Nestlings Banded
      ' ----------------

      ' qryMBO10YearProgramReportNestlings_C
      ' ------------------------------------
      ' tblCaptures x tblPrograms
      ' WHERE MonitoringProgramSeason = "Nestbox"
      ' WHERE Location = "MBO"
      ' DETCategory = Banded
      ' Age IN ('2','4')
      ' YearEx BETWEEN [argYearFirst] AND [argYearLast]
      ' GROUP BY YearEx
      ' Report YearEx, CountBirds = count records

150   intNestlingsCount(conNestlingsBirdsBanded) = 0
160   dblNestlingsTotal(conNestlingsBirdsBanded) = 0

170   Set qdf = CurrentDb.QueryDefs("qryMBO10YearProgramReportNestlings_C")
180   qdf.Parameters("argYearFirst").value = intYearFirst
190   qdf.Parameters("argYearLast").value = intYearLast
200   Set rst = qdf.OpenRecordset

210   Do While Not rst.EOF
220       Y = Nz(rst("YearEx"))
230       lngCountBirds = Nz(rst("CountBirds"))
240       dblStat(conNestlingsBirdsBanded, Y) = lngCountBirds
250       intNestlingsCount(conNestlingsBirdsBanded) = _
              intNestlingsCount(conNestlingsBirdsBanded) + 1
260       dblNestlingsTotal(conNestlingsBirdsBanded) = _
              dblNestlingsTotal(conNestlingsBirdsBanded) + lngCountBirds
270       rst.MoveNext
280   Loop
290   rst.Close
300   Set rst = Nothing

310   If intNestlingsCount(conNestlingsBirdsBanded) > 0 Then
320       dblNestlingsAverage(conNestlingsBirdsBanded) = _
              dblNestlingsTotal(conNestlingsBirdsBanded) / _
              intNestlingsCount(conNestlingsBirdsBanded)
330   Else
340       dblNestlingsAverage(conNestlingsBirdsBanded) = 0
350   End If

      ' --------------
      ' Species Banded
      ' --------------

      ' qryMBO10YearProgramReportNestlings_A
      ' ------------------------------------
      ' tblCaptures x tblPrograms
      ' WHERE MonitoringProgramSason = "Nestbox" = NESTLINGS
      ' WHERE Location = "MBO"
      ' DETCategory = "Banded"
      ' Age IN ('2','4')
      ' YearEx BETWEEN [argYearFirst] AND [argYearLast]
      ' GROUP BY YearEx, Species

      ' qryMBO10YearProgramReportNestlings_B
      ' ------------------------------------
      ' qryMBO10YearProgramReportNestlings_A
      ' GROUP BY YearEx
      ' Report YearEx, count of records

360   intNestlingsCount(conNestlingsSpeciesBanded) = 0
370   dblNestlingsTotal(conNestlingsSpeciesBanded) = 0

380   Set qdf = CurrentDb.QueryDefs("qryMBO10YearProgramReportNestlings_B")
390   qdf.Parameters("argYearFirst").value = intYearFirst
400   qdf.Parameters("argYearLast").value = intYearLast
410   Set rst = qdf.OpenRecordset

420   Do While Not rst.EOF
430       Y = Nz(rst("YearEx"))
440       intCountSpecies = Nz(rst("CountSpecies"))
450       dblStat(conNestlingsSpeciesBanded, Y) = intCountSpecies
460       intNestlingsCount(conNestlingsSpeciesBanded) = _
              intNestlingsCount(conNestlingsSpeciesBanded) + 1
470       dblNestlingsTotal(conNestlingsSpeciesBanded) = _
              dblNestlingsTotal(conNestlingsSpeciesBanded) + intCountSpecies
480       rst.MoveNext
490   Loop
500   rst.Close
510   Set rst = Nothing

520   If intNestlingsCount(conNestlingsSpeciesBanded) > 0 Then
530       dblNestlingsAverage(conNestlingsSpeciesBanded) = _
              dblNestlingsTotal(conNestlingsSpeciesBanded) / _
              intNestlingsCount(conNestlingsSpeciesBanded)
540   Else
550       dblNestlingsAverage(conNestlingsSpeciesBanded) = 0
560   End If

570   dblNestlingsAverage(conNestlingsBirdsBanded) = Round(dblNestlingsAverage(conNestlingsBirdsBanded), 1)
580   dblNestlingsAverage(conNestlingsSpeciesBanded) = Round(dblNestlingsAverage(conNestlingsSpeciesBanded), 1)

      ' Global number of species

      ' qryMBO10YearProgramReportNestlings_D
      ' ------------------------------------
      ' tblCaptures x tblPrograms
      ' WHERE MonitoringProgramSeason = "Nestbox"
      ' WHERE Location = "MBO"
      ' WHERE DETCategory = "Banded"
      ' WHERE Age IN ('2','4')

      ' GROUP BY YearEx BETWEEN [argYearFirst] AND [argYearLast]
      ' GROUP BY Species

      ' qryMBO10YearProgramReportNestlings_E
      ' ------------------------------------
      ' qryMBO10YearProgramReportNestlings_D
      ' Report CountSpecies = count records

      Dim intGlobalNestlingSpeciesCount As Integer
590   intGlobalNestlingSpeciesCount = 0

600   Set qdf = CurrentDb.QueryDefs("qryMBO10YearProgramReportNestlings_E")
610   qdf.Parameters("argYearFirst").value = intYearFirst
620   qdf.Parameters("argYearLast").value = intYearLast
630   Set rst = qdf.OpenRecordset

640   If Not rst.EOF Then
650       intGlobalNestlingSpeciesCount = Nz(rst("CountSpecies"))
660   End If

      ' --------------------------------------
      ' Output Word Document
      ' --------------------------------------

      Dim lngStart As Long
      Dim range As Word.range
      Dim rangeTemplate As Word.range
      Dim lngEnd As Long

670   Set range = doc.Characters.Last

680   For Y = intYearFirst To intYearLast

          Dim intYearIndex As Integer
          Dim intYearIndexMod5 As Integer

690       intYearIndex = Y - intYearFirst
700       intYearIndexMod5 = intYearIndex Mod 5

710       If intYearIndexMod5 = 0 Then

          ' Delete colums we do not want from previous table, if any
          
720           If intYearIndex <> 0 Then
730               range.Tables(1).columns(8).Delete
740               range.Tables(1).columns(7).Delete
750           End If
        
760           Set range = MoveInsertionPointToEndOfDocument(wd, doc)
              
'              ' Insert a blank line between tables

770           If intYearIndex <> 0 Then
780               range.InsertParagraphAfter
790               range.Style = "ddSummarySpacingBetweenTables"
810               Set range = MoveInsertionPointToEndOfDocument(wd, doc)
820           End If
              
830           Call WordGenerateTableSummary(doc, range, "Nestbox")
               
'               ' Delete the rows we do not want
'
'840                range.tables(1).Rows(11).Delete
'850                range.tables(1).Rows(10).Delete
'860                range.tables(1).Rows(9).Delete
'870                range.tables(1).Rows(8).Delete
'880                range.tables(1).Rows(7).Delete
'890                range.tables(1).Rows(6).Delete
'900                range.tables(1).Rows(5).Delete
'910                range.tables(1).Rows(4).Delete
'920                range.tables(1).Rows(3).Delete
   
840       End If

          ' Fill in the header

850       range.Tables(1).Cell(1, intYearIndexMod5 + 2).range.Text = Y

          Dim tblRow As Integer
860       tblRow = 2

870       If dblStat(conNestlingsBirdsBanded, Y) > 0 Then
880           range.Tables(1).Cell(tblRow, intYearIndexMod5 + 2).range.Text = _
                  dblStat(conNestlingsBirdsBanded, Y) & " (" & dblStat(conNestlingsSpeciesBanded, Y) & ")"
890       Else
900           range.Tables(1).Cell(tblRow, intYearIndexMod5 + 2).range.Text = "0 (0)"
910       End If
          
920   Next

      ' Averages, Totals

      ' Fill in the header

930   range.Tables(1).Cell(1, 7).range.Text = "Average"
940   range.Tables(1).Cell(1, 8).range.Text = "Total"

950   If dblNestlingsTotal(conNestlingsBirdsBanded) > 0 Then
960       range.Tables(1).Cell(tblRow, 7).range.Text = _
              Round(dblNestlingsAverage(conNestlingsBirdsBanded), 0) & _
              " (" & Round(dblNestlingsAverage(conNestlingsSpeciesBanded), 0) & ")"
970       range.Tables(1).Cell(tblRow, 8).range.Text = _
               dblNestlingsTotal(conNestlingsBirdsBanded) & " (" & intGlobalNestlingSpeciesCount & ")"
980   Else
990       range.Tables(1).Cell(tblRow, 7).range.Text = "0 (0)"
1000      range.Tables(1).Cell(tblRow, 8).range.Text = "0 (0)"
1010  End If

      Dim oSheet As Excel.Worksheet
1020  Set oSheet = InsertSheet(oBook, "Nestbox")
1030  oSheet.Name = "Nestlings Summary"
1040  With oSheet

      ' qryMBO10YearProgramReportNestlings_F
      ' ------------------------------------
      ' tblCaptures x tblPrograms
      ' WHERE MonitoringProgramSeason  = "Nestbox"
      ' WHERE Location = "MBO"
      ' WHERE DETCategory = "Banded"
      ' WHERE Age = IN ('2','4')
 
      ' YearEx BETWEEN [argYearFirst] AND [argYearLast]
      ' Sort Species, YearEx
      ' GROUP BY Species, YearEx
      ' Report Species, YearEx, CountBirds = count records

1050  Set qdf = CurrentDb.QueryDefs("qryMBO10YearProgramReportNestlings_F")
1060  qdf.Parameters("argYearFirst").value = intYearFirst
1070  qdf.Parameters("argYearLast").value = intYearLast
1080  Set rst = qdf.OpenRecordset

1090  .Cells(1, 1) = "Nestbox at MBO, DET Category = Banded, Age is 2 or 4"
1100  .range(.Cells(1, 1), .Cells(1, 1)).Font.Bold = True

1110  .Cells(3, 1) = "Species"
1120  .Cells(3, 2) = "Year"
1130  .Cells(3, 3) = "# Nestlings"

      Dim row As Long
1140  row = 4

      Dim strSpecies As String
      Dim intYear As Integer
      ' Dim lngCountBirds As Long

1150  Do While Not rst.EOF
1160      strSpecies = Nz(rst("Species"))
1170      intYear = Nz(rst("YearEx"))
1180      lngCountBirds = Nz(rst("CountBirds"))
1190      .Cells(row, 1) = strSpecies
1200      .Cells(row, 2) = intYear
1210      .Cells(row, 3) = lngCountBirds
1220      row = row + 1
1230      rst.MoveNext
1240  Loop
1250  rst.Close
1260  Set rst = Nothing

1270  If row > 5 Then

          ' Create a pivot table
          
          Dim rngData As Excel.range
          Dim pvt As Excel.PivotTable
          Dim pvtfld As Excel.PivotField
          
1280      Set rngData = .range(.Cells(3, 1), .Cells(row - 1, 3))
1290      oBook.PivotCaches.Create(SourceType:=xlDatabase, SourceData:=rngData, _
              Version:=xlPivotTableVersion12).CreatePivotTable TableDestination:=.range("H2"), tableName:="PivotTable1", DefaultVersion:=xlPivotTableVersion12
              
1300      Set pvt = .PivotTables("PivotTable1")
1310      pvt.ManualUpdate = True
          
1320      With pvt.PivotFields("Species")
1330          .Orientation = xlRowField
1340          .Position = 1
1350      End With
          
1360      With pvt.PivotFields("Year")
1370          .Orientation = xlColumnField
1380      End With
          
1390      With pvt.PivotFields("# Nestlings")
1400          .Orientation = xlDataField
1410          .Function = xlSum
1420          .NumberFormat = "#"
1430      End With
          
1440      pvt.ManualUpdate = False

1450  End If

      ' qryMBO10YearProgramReportNestlings_G
      ' ------------------------------------
      ' tblCaptures
      ' Program = NESTLINGS
      ' Location = MBO
      ' DETCategory = <> "Banded" OR Age = NOT IN ('2','4')
      ' YearEx = Year(DateEx)
      ' YearEx BETWEEN [argYearFirst] AND [argYearLast]
      ' Sort Species, YearEx
      ' Report Species, YearEx, DETCategory, Age

1460  row = row + 1
1470  .Cells(row, 1) = "NESTLINGS at MBO, DET Category <> Banded OR Age is neither 2 nor 4"
1480  .range(.Cells(row, 1), .Cells(row, 1)).Font.Bold = True

1490  Set qdf = CurrentDb.QueryDefs("qryMBO10YearProgramReportNestlings_G")
1500  qdf.Parameters("argYearFirst").value = intYearFirst
1510  qdf.Parameters("argYearLast").value = intYearLast
1520  Set rst = qdf.OpenRecordset

1530  If rst.EOF Then
1540      .Cells(row, 1) = "There are none"
1550  Else

1560      row = row + 2
          
1570      .Cells(row, 1) = "Species"
1580      .Cells(row, 2) = "Year"
1590      .Cells(row, 3) = "Age code"
1600      .Cells(row, 4) = "DET Category"
          
1610      row = row + 1

          Dim strAge As String
          Dim strDETCategory As String
          
1620      Do While Not rst.EOF
1630          strSpecies = Nz(rst("Species"))
1640          intYear = Nz(rst("YearEx"))
1650          strAge = Nz(rst("Age"))
1660          strDETCategory = Nz(rst("DETCategory"))
1670          .Cells(row, 1) = strSpecies
1680          .Cells(row, 2) = intYear
1690          .Cells(row, 3) = strAge
1700          .Cells(row, 4) = strDETCategory
1710          row = row + 1
1720          rst.MoveNext
1730      Loop
1740  End If
          
      ' qryMBO10YearProgramReportNestlings_H
      ' ------------------------------------
      ' tblCaptures
      ' Program = NESTLINGS
      ' Location = MBO
      ' DETCategory
      ' Disposition NOT IN ('4','8')
      ' YearEx = Year(CaptureDate)
      ' YearEx BETWEEN [argYearFirst] AND [argYearLast]
      ' Sort Species, YearEx
      ' Report Species, YearEx, DETCategory, Age

1750  row = row + 1
1760  .Cells(row, 1) = "NESTBOX at MBO"
1770  .range(.Cells(row, 1), .Cells(row, 1)).Font.Bold = True

1780  Set qdf = CurrentDb.QueryDefs("qryMBO10YearProgramReportNestlings_H")
1790  qdf.Parameters("argYearFirst").value = intYearFirst
1800  qdf.Parameters("argYearLast").value = intYearLast
1810  Set rst = qdf.OpenRecordset

1820  If rst.EOF Then
1830      .Cells(row, 1) = "There are none"
1840  Else

1850      row = row + 2
          
1860      .Cells(row, 1) = "Species"
1870      .Cells(row, 2) = "Year"
1880      .Cells(row, 3) = "Age code"
1890      .Cells(row, 4) = "DET Category"
1900      .Cells(row, 5) = "Capture Date"
1910      .Cells(row, 6) = "JUN"
1920      .Cells(row, 7) = "JUL"
1930      .Cells(row + 1, 9) = "JUN JUL columns contain the month number of capture"
1940      .Cells(row + 2, 9) = "Capture months before JUN or after JUL are highlighted"
      ' 2000    .range(.Cells(row, 6), .Cells(row, 7)).HorizontalAlignment = xlRight
          
1950      row = row + 1

      Dim lngRowStart As Long
      Dim lngRowEnd As Long
1960  lngRowStart = row

          Dim datDate As Date
          
1970      Do While Not rst.EOF
1980          strSpecies = Nz(rst("Species"))
1990          intYear = Nz(rst("YearEx"))
2000          strAge = Nz(rst("Age"))
2010          datDate = Nz(rst("CaptureDate"))
2020          strDETCategory = Nz(rst("DETCategory"))
2030          .Cells(row, 1) = strSpecies
2040          .Cells(row, 2) = intYear
2050          .Cells(row, 3) = strAge
2060          .Cells(row, 4) = strDETCategory
2070          .Cells(row, 5) = datDate
2080          Select Case Month(datDate)
              Case Is < 6
2090               .Cells(row, 6) = Month(datDate)
2100               .range(.Cells(row, 6), .Cells(row, 6)).Interior.Color = vbYellow
2110          Case 6
2120               .Cells(row, 6) = Month(datDate)
2130          Case 7
2140               .Cells(row, 7) = Month(datDate)
2150          Case Is < 7
2160               .Cells(row, 7) = Month(datDate)
2170               .range(.Cells(row, 7), .Cells(row, 7)).Interior.Color = vbYellow
2180          End Select

2190          row = row + 1
2200          rst.MoveNext
2210      Loop
          
2220  lngRowEnd = row - 1
2230  .range(.Cells(lngRowStart, 5), .Cells(lngRowEnd, 5)).NumberFormat = "dd-mmm"
2240  .range(.Cells(lngRowStart - 1, 3), .Cells(lngRowEnd, 3)).HorizontalAlignment = xlCenter
2250  .range(.Cells(lngRowStart - 1, 5), .Cells(lngRowEnd, 6)).HorizontalAlignment = xlCenter
          
2260  End If

2270  .range(.columns(4), .columns(7)).AutoFit

2280  rst.Close
2290  Set rst = Nothing

2300  End With

2310  Set oSheet = Nothing
          
      'DD Error Handler Start
Exit_label:
2320       Exit Sub
Err_label:
2330       Select Case Err.Number
           Case Else
2340      Call LogError("basMBO10YearProgramReportNestlingsSummary", "MBO10YearProgramReportNestlingsSummary")
2350       End Select
2360       Resume Exit_label
      'DD Error Handler End
          
End Sub
